# `crv.validation` module
## Functionality
Tests and summary functions for performance testing of credit risk models. Tests are applicable to PD, LGD, and/or EAD/CCF models, and are sorted into submodules based on testing dimension.

## Submodules
### `calibration.py`
Functions for testing the accuracy of model calibration.

### `differentiation.py`
Functions for testing the risk differentiation of model calibration.

### `stability.py`
Functions for testing the stability of models.

### `summary.py`
Functions for summarizing customer level data as specified by the user. Contains both `pandas` and `pyspark` implementations for handling in- and out-of-memory data sets, respectively.

### `monte_carlo.py`
Monte Carlo simulations of summarized default data.
