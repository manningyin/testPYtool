"""
############
Introduction
############
The ECB guideline "Annex 2 - Instructions for reporting the validation results of internal models" of February 2019 describe the following dimensions along which the performance of the performance of the Pillar I credit risk models can be assessed:
    
* Calibration
* Differentiation
* Stability

This file contains the validation tools that provide insight into the calibration accuracy (or predictive ability) of Pillar I credit risk models.These validation tools can be PD, LGD, EAD/CCF model specific, but can also be PD, LGD, EAD/CCF model agnostic. 
    
Validation tools
================
This section gives an overview of the validation tools available to determine calibration accuracy of the Pillar I credit risk models; categorised by PD, LGD, EAD/CCF model. 

PD
--
The analysis of calibration (or predictive ability) is aimed at ensuring that the PD parameter adequately predicts the occurrence of defaults –– i.e. that PD estimates constitute reliable forecasts of default rates.

* **Jeffreys test**: Assesses the predictive ability of PD estimates at the level of individual rating grades and at portfolio level.

* **Binomial test normal approximation**: Test whether the PD predicted for a particular rating grade is closely associated with the default rate of the rating grade; based on a normal distribution of estimated PD per rating grade.

* **Binomial test exact approximation**: Test whether the PD predicted for a particular rating grade is closely associated with the default rate of the rating grade; based on a chi-square distribution of estimated PD per rating grade.

* **Confidence intervals**: Calculates the upper and lower confidence intervals from the default data provided in the Adf summary table.

* **Hosmer Lemeshow test**: Calculates the calibration accuracy of the PD model under the hypothesis that all the PD forecasts match the true PDs; using a chi-squared distribution. 

* **Pearson's Chi squared test for homogeneity/heterogeneity**: Calculates the Chi square test statistic of the 2 x 2 contingency table for a pair of rating grades in a given year.
    
LGD
---
The analysis of predictive ability (or calibration) is aimed at ensuring that the LGD parameter adequately predicts the loss rate in the event of a default, i.e. that LGD estimates constitute reliable forecasts of realised loss rates.

* **t-test**: The objective of this validation tool (LGD back-testing using a one-sample t-test for paired observations) is to assess the predictive ability of LGD estimates at portfolio level, as well as at grade/pool or segment level.
    
EAD/CCF
-------
The analysis of predictive ability (or calibration) aims to ensure that the CCF risk parameter facilitates a good prediction of EAD.

* **t-test**:  The objective of this validation tool (CCF back--testing using a one-sample t-test for paired observations) is to assess the predictive ability of CCF estimates at facility grade or pool level.

Warning
=======
The functions herein assume the data has been correctly processed up to this point. See other modules if data processing is needed. This implies that data has been extracted and contain the required variables. Variables required for the test should be stated in the function header.

Notes
=====
Author: N440730, G01679

###################
Test implementation
###################
"""

from typing import List, Optional, Union
import numpy as np
import pandas as pd
import pyspark.sql.functions as f
import pyspark.sql.dataframe as psd
from pyspark.sql.window import Window
from scipy.stats import beta, norm, chi2, chi2_contingency
import warnings

from typing_extensions import Literal
from crv.validation.summary import adf_summary
from crv.utils.validation_helper import _create_bins_labels
from statsmodels.stats.proportion import proportion_confint
from scipy.stats import t

__all__ = [
    "jeffreys_test",
    "binomial_test_norm_approx",
    "binomial_test",
    "confidence_intervals",
    "hosmer_lemeshow_test",
    "homogeneity_heterogeneity_test",
    "t_test",
]


def jeffreys_test(
    adf_table: pd.DataFrame,
    default_count_col: str,
    customer_count_col: str,
    pd_col: str,
    alpha: float = 0.95,
) -> pd.DataFrame:
    """
    Calculates results of a Jeffreys test given an ADF summary table in
    accordance with section 2.5.3.1 in ECB's "Annex 2 - Instructions for
    reporting the validation results of internal models (February 2019)".

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding PD.

        alpha (float): Significance level for the test.
         Default value is 0.95 if omitted.

    Returns:
        (pandas.DataFrame): A table corresponding to 'PD 3.0 - Predictive
         Ability', section 2.5.3 in Annex 2, inlcuding the Jeffreys test
         results. A 'Passed' column, that is based on alpha, is added
         to the table.

    Examples:
        Call function in Python like this::

            df_jeffreys = jeffreys_test(df, 'D', 'N', 'PD')

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    df = adf_table.copy()
    original_cols = list(df.columns)
    _D, _N, _PD = default_count_col, customer_count_col, pd_col

    # Jeffreys test calculation over whole DataFrame.
    df["a"] = 0.5 + df[_D]
    df["b"] = 0.5 + df[_N] - df[_D]
    df["p-value"] = df.apply(lambda row: beta.cdf(row[_PD], row["a"], row["b"]), axis=1)
    df["Passed"] = df["p-value"] > 1 - alpha

    # Reorder columns.
    col_order = original_cols + ["p-value", "Passed"]
    df = df[col_order]

    return df


def binomial_test_norm_approx(
    adf_table: pd.DataFrame,
    default_count_col: str,
    customer_count_col: str,
    pd_col: str,
    alpha: float = 0.95,
) -> pd.DataFrame:
    """
    Calculates results of a binomial test given an ADF summary table in
    accordance with given a summary table. The test is implemented according
    to "Validation Guideline - IRB Models - v 1.7", section B.6.1.

    Returns a pandas.DataFrame

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding PD.

        alpha (float): Significance level for the test. Default value
            is 0.95 if omitted.

    Returns:
        (pandas.DataFrame): The ADF table with confidence intervals and a
            'Passed' column, based on aplpha, as extra columns.

    Examples:
        Call function in Python like this::

            df_binom = binomial_test_norm_approx(adf_table, 'D', 'N', 'PD')

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # Setup column name variables, copy data, remove PD nulls, save original columns.
    _D, _N, _PD = default_count_col, customer_count_col, pd_col
    df = adf_table.copy()
    df = df.loc[pd.notna(df[_PD])]
    original_cols = list(df.columns)

    # Binomial test calculation over whole DataFrame.
    df["nPD"] = df[_N] * df[_PD]
    df["PHI_inv"] = norm.ppf((alpha + 1) / 2) * np.sqrt(df["nPD"] * (1 - df[_PD]))
    df["k_L"] = df["nPD"] - df["PHI_inv"]
    df["k_H"] = df["nPD"] + df["PHI_inv"]
    df["LCL"] = df["k_L"] / df[_N]
    df["UCL"] = df["k_H"] / df[_N]
    df["Passed"] = (df["k_L"] <= df[_D]) & (df[_D] <= df["k_H"])

    # Reorder columns.
    col_order = original_cols + ["k_L", "k_H", "LCL", "UCL", "Passed"]
    df = df[col_order]

    return df


def binomial_test(
    adf_table: pd.DataFrame,
    default_count_col: str,
    customer_count_col: str,
    pd_col: str,
    alpha: float = 0.95,
) -> pd.DataFrame:
    """
    Calculates results of an exact binomial test given an ADF summary table.
    Test implemented using statsmodels.stats.proportion.proportion_confint

    Note: This implementation is confirmed with R code
    R-package prevalence::propCI()

    Returns a pandas.DataFrame

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding PD.

        alpha (float): Significance level for the test. Default value
         is 0.95 if omitted.

    Returns:
        (pandas.DataFrame): The ADF table with confidence intervals and
         a 'Passed' column, based on alpha, as extra columns.

    Examples:
        Call function in Python like this::

            df_binom = binomial_test(adf_table, 'D', 'N', 'PD')

    Raises:
        ValueError: if alpha<=0 or alpha>=1.

        ValueError: if column PD_ <=0 or column PD_>=1.

        ValueError: if column _D < 0.

        ValueError: if column _N <= 0.

    Notes:
        Author: Reinout Kool <G85538>
    """

    # Setup column name variables, copy data, remove PD nulls,
    # save original columns.
    _D, _N, _PD = default_count_col, customer_count_col, pd_col
    df = adf_table.copy()
    df = df.loc[pd.notna(df[_PD])]
    original_cols = list(df.columns)

    # Checking validity of input parameters
    if (alpha <= 0) | (alpha >= 1):
        raise ValueError(
            "Significance level 'alpha' must be between " "0 and 1, exclusively."
        )

    if any(df[_D] < 0):
        raise ValueError(f"Column {_D} in dataframe cannot be negative.")

    if any(df[_N] <= 0):
        raise ValueError(f"Column {_N} in dataframe cannot be zero " "or negative.")

    if any(df[_PD] <= 0) | any(df[_PD] >= 1):
        raise ValueError(
            f"Column {_PD} in dataframe must be between " "0 and 1, exclusively."
        )

    # Calculate upper and lower bounds.
    def exact_conf_lower(n, p, alpha):
        q = 1 - alpha
        lower, upper = proportion_confint(int(n * p), n, alpha=q, method="beta")
        return max(lower * n, 0)

    def exact_conf_upper(n, p, alpha):
        q = 1 - alpha
        lower, upper = proportion_confint(int(n * p), n, alpha=q, method="beta")
        return max(upper * n, 0)

    df["k_L"] = df.apply(lambda row: exact_conf_lower(row[_N], row[_PD], alpha), axis=1)
    df["k_H"] = df.apply(lambda row: exact_conf_upper(row[_N], row[_PD], alpha), axis=1)

    df["LCL"] = df["k_L"] / df[_N]
    df["UCL"] = df["k_H"] / df[_N]

    # Round the upper and lower bounds.
    df["k_L"] = df["k_L"].apply(np.ceil).astype(int)
    df["k_H"] = df["k_H"].apply(np.floor).astype(int)

    # Calculate whether the binomial test has passed.
    df["Passed"] = (df["k_L"] <= df[_D]) & (df[_D] <= df["k_H"])

    # Reorder columns.
    col_order = original_cols + ["k_L", "k_H", "LCL", "UCL", "Passed"]
    df = df[col_order]

    return df


def confidence_intervals(
    adf_table: pd.DataFrame, pd_col: str, rho: float = 0.02, alpha: float = 0.95
) -> pd.DataFrame:
    """
    Calculates the upper and lower confidence intervals from the
    default data provided in the AdfSummary object.

    The confidence intervals are calculated according to the
    CRMV "Validation Guidelines - IRB Models" v 1.7,
    section B.6.2, "Confidence test when defaults are modelled
    as dependent".

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        pd_col (str): Name of the column containing the corresponding PD.

        rho (float): Asset correlation, assumed to be the
                            same for all customers in consideration.

        alpha (float): Significance level for the test.
                            Default value is 0.95 if omitted.

    Returns:
        (pands.DataFrame): The ADF table with confidence intervals
            and a 'Passed', based on aplpha, as extra columns.

    Raises:
        ValueError: if rho<0 or rho>1.

        ValueError: if alpha<=0 or alpha>=1.

        Examples:
            Call function like this from Python::

                df_ci = confidence_intervals(adf_table, 'PD', rho)
    """
    df = adf_table.copy()
    _PD = pd_col
    original_cols = list(df.columns)

    if (rho < 0) | (rho > 1):
        raise ValueError(
            "Asset correlation value 'rho' must be between " "0 and 1, inclusively."
        )
    if (alpha <= 0) | (alpha >= 1):
        raise ValueError(
            "Significance level 'alpha' must be between " "0 and 1, exclusively."
        )

    df["LCL"] = norm.cdf(
        (norm.ppf(1 - alpha) * np.sqrt(rho) + norm.ppf(df[_PD])) / np.sqrt(1 - rho)
    )
    df["UCL"] = norm.cdf(
        (norm.ppf(alpha) * np.sqrt(rho) + norm.ppf(df[_PD])) / np.sqrt(1 - rho)
    )

    df["Passed"] = (df["LCL"] <= df["ADF"]) & (df["ADF"] < df["UCL"])

    col_order = original_cols + ["LCL", "UCL", "Passed"]
    df = df[col_order]

    return df


def hosmer_lemeshow_test(
    adf_table: pd.DataFrame,
    rating_class_col: str,
    default_count_col: str,
    customer_count_col: str,
    pd_col: str,
    dof: int = None,
) -> pd.DataFrame:
    """
    Calculates results of the Hosmer Lemeshow test (chi-squared test)
    given an ADF summary table, according to the "Model Testing Framework",
    v2.5, section 7.4, "Chi-Square (Hosmer–Lemeshow) Test".

    The Hosmer Lemeshow test statistic determines the calibration accuracy
    of the PD model under the hypothesis that all the PD forecasts match the
    true PDs. The Hosmer-Lemeshow test statistic has a chi squared
    distribution with degrees of freedom equal to the number of rating
    grades.

    The Hosmer-Lemeshow test statistic is under the assumption that default
    events and assets in the rating grades are independent.

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        rating_class_col (str): Name of column containing the rating
                                    class names.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding PD.

        dof (int): Number of degrees of freedom to use in the chi squared
                            value test. Default = None, implying it will be
                            equal to the number of rating grades minus two in
                            the adf_table.

    Returns:
        (pands.DataFrame): The ADF table ordered on the relative contribution
         of a rating class to the total X-squared statistic.

        (float): x_squared is the chi-squared test statistic

        (int): _dof is the degrees of freedom used to calculate the
         p-value under the chi-squared distribution.

        (float): pvalue determines the calibration accuracy of the overall PD
         model, using the traffic light approach:
            Green: p-value > 0.5
             Fail to reject the 𝐻0 at a 50% significance level - Signifies accurate calibration.
            Orange: 0.05 < p-value <= 0.5
             Fail to reject the 𝐻0 at a 5% significance level - Signifies concern on accuracy of calibration.
            Red: <= 0.05
             Reject the 𝐻0 at a 5% significance level - Signifies inaccurate calibration

    Examples:
        Call function in Python like this::

            df, x_squared_sum, degree_freedom, pvalue =
            hosmer_lemeshow_test(adf_table, 'rating', 'D', 'N', 'PD')

    Raises:
        ValueError: if column PD_ <=0 or column PD_>=1.

        ValueError: if column _D < 0.

        ValueError: if column _N <= 0.

    Notes:
        Author: Reinout Kool <G85538>
    """

    # Setup column name variables, copy data, remove PD nulls,
    # save original columns.
    _rating, _D, _N, _PD = (
        rating_class_col,
        default_count_col,
        customer_count_col,
        pd_col,
    )
    df = adf_table.copy()
    df = df.loc[pd.notna(df[_PD])]
    _dof = max(len(df) - 2, 1) if dof is None else dof

    # Checking validity of input parameters
    if any(df[_D] < 0):
        raise ValueError(f"Column {_D} in dataframe cannot be negative.")

    if any(df[_N] <= 0):
        raise ValueError(f"Column {_N} in dataframe cannot be zero " "or negative.")

    if any(df[_PD] <= 0) | any(df[_PD] >= 1):
        raise ValueError(
            f"Column {_PD} in dataframe must be between " "0 and 1, exclusively."
        )

    if _dof is not None and not isinstance(_dof, int) or _dof < 1:
        raise ValueError(
            "Degrees of freedom (d_freedom) must be an integer "
            "and larger or equal to 1."
        )

    # Calculate the x-squared statistic
    df["ED"] = df[_N] * df[_PD]
    df["X_sq"] = ((df[_D] - df["ED"]) ** 2) / (df["ED"] * (1 - df[_PD]))
    df["relative_X_sq"] = df["X_sq"] / df["X_sq"].sum()

    # Ordering the columns
    col_order = [_rating, _N, _PD, "ED", _D, "X_sq", "relative_X_sq"]
    df = df[col_order]

    # Calculate the p-value
    x_squared_sum = df["X_sq"].sum()
    pvalue = chi2.sf(x_squared_sum, _dof)

    return df, x_squared_sum, _dof, pvalue


def homogeneity_heterogeneity_test(A: List[Union[pd.DataFrame, np.array]]) -> float:
    """
    Function to compute the Pearson Chi squared test statistic of a 2x2
    contingency table of rating grades.

    There is two instances of the test.
    - The heterogeneity test investigates a selected pair of neighbouring
    rating grades by comparing their default and non-default counts.
    - The homogeneity tests selects one rating grade and splits it in half,
    thus also obtaining a pair of neighbouring grades.

    The null hypothesis for both tests is that the two grades are homogeneous
    in terms of the observed default / non-default frequencies, i.e. there is
    no statistically significant difference in their PDs.

    For the heterogeneity test, not rejecting the null hypothesis means that
    the rating grade structure is not optimal and needs to be reviewed.
    In particular, the 2 examined grades should be considered for merging.
    For the homogeneity test, rejecting the null means that the rating grade
    under investigation is likely too wide and should be considered for
    being split in two sub-grades.

    References
    Model Testing Framework V2.5 (approved: 10 February 2020). Sec. 7.16 Heterogeneity test for grades.
    Model Testing Framework V2.5 (approved: 10 February 2020). Sec. 7.17 Homogeneity test for grades
    Pearson's Chi-sqrd test: https://en.wikipedia.org/wiki/Pearson%27s_chi-squared_test

    Args:
        A (pd.Dataframe/numpy array): Contingency table, can either be a 2x2 or 3x3 numpy
                                        array or dataframe. Rows should represent rating
                                        grades and the columns represent the number of
                                        default and non-default customers/cases.
                                        In case of 3x3 input, the third row and column
                                        should represent the total number of defaults/non defaults
                                        and counts within each rating grade respectively.

    Returns:
        T (float): test statistic

    Raises:
        ValueError: If input array/dataframe is not of appropriate size.

        ValueError: If at least one expected count is zero, resulting in division by zero.

        Warning: If any of expected counts is below 5.

    Examples:
        Call function in Python like this::

            T = homogeneity_heterogeneity_test(my_df) # my_df is a pd.Dataframes

            T = homogeneity_heterogeneity_test(A) # A is a numpy array

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    if not (isinstance(A, pd.DataFrame) or isinstance(A, np.ndarray)):
        raise ValueError("Input A must be of pd.Dataframe or numpy array.")

    # Check input arg shape.
    m, n = A.shape[0], A.shape[1]
    if any(np.array([m, n]) > 3) or any(np.array([m, n]) < 2) or (m != n):
        raise ValueError("Input A must be a 2x2 or 3x3 numpy array or pd.DataFrame.")

    # Convert to numpy.
    if isinstance(A, pd.DataFrame):
        # convert A to numpy if data frame
        A = A.to_numpy()
        A = np.asarray(A, dtype=np.float64)

    A = A[:2, :2]

    # Check if both instances of default count are zero.
    if np.sum(A[:, 0]) == 0:
        raise ValueError("Both default counts are zero")

    # Check if total count within one rating grade is zero.
    if any(np.sum(A, axis=1) == 0):
        raise ValueError("Both counts within one rating grade is zero.")

    # Compute total counts if they are not present in input.
    if A.shape == (2, 2):
        A = np.append(A, np.sum(A, axis=1, keepdims=1), axis=1)
        A = np.append(A, np.sum(A, axis=0, keepdims=1), axis=0)

    # Compute the overall probability of default
    PDtotal = A[2, 0] / A[2, 2]

    # Compute the expected count under the null hypothesis that PD in each grade is the same
    E = A[:2, 2].reshape(2, 1) * np.array([PDtotal, (1 - PDtotal)])

    # Check for values below 5 in E
    if np.sum(E < 5) > 0:
        warnings.warn(
            "One or more of the expected default counts is below 5 resulting in unreliable test statistic."
        )

    if E.any() == 0:
        raise ValueError(
            "At least one expected default count is zero which results in division by zero."
        )

    T = np.sum((A[:2, :2] - E) ** 2 / E)

    return T


def _p_value_t_test(
    t_statistic: float,
    side: Literal["right_tailed", "left_tailed", "two_side"],
    dof: float,
) -> float:
    """
    Internal function to compute the p-value of a t-test.

    Args:
        t_statistic (float): The t-test statistic value.

        side (string): Side of alternative hypothesis. One of the following "right_tailed",
            "left_tailed" or "two_sided".

        dof (float): Degrees of freedom.

    Returns:
        result (float): The p-value for the specified t-statistic, side & degrees of freedom.
    """

    if side == "right_tailed":
        _cdf_t = t.cdf(t_statistic, dof)
        p_value = 1 - _cdf_t
    elif side == "left_tailed":
        _cdf_t = t.cdf(t_statistic, dof)
        p_value = _cdf_t
    elif side == "two_sided":
        _cdf_t = t.cdf(abs(t_statistic), dof)
        p_value = 2 * (1 - _cdf_t)
    return p_value


def _paired_t(
    data: Union[pd.DataFrame, psd.DataFrame],
    dof: float,
    side: Literal["right_tailed", "left_tailed", "two_side"],
    col_names: dict,
) -> list:
    """
    Internal t test function for paired samples.

    The t test for paired samples applies when we have two values for the same
    subject (e.g. observed & estimated LGD per facility). The t test implementation
    is based on document "ECB Instructions
    for reporting the validation results of internal models, February 2019."
    Section 2.6.2.1 & 2.9.3.1. The test, in the context of credit risk modelling,
    is used to evaluate the calibration of a LGD/CCF model.

    Args:
        data (pandas.DataFrame or pyspark.sql.DataFrame):  DataFrame that includes
                the columns specified in col_names.

        dof (float, optional): Degrees of freedom. If None the degrees
            will be set equal to [N - 1] to match the value in ECB Instructions
            Sections 2.6.2.1 & 2.9.3.1.

        side (string, optional): Side of alternative hypothesis. One of the following "right_tailed",
            "left_tailed" or "two_sided".

        col_names (dictionary): Dictionary of the form col_names = {'id_col': <'your_data_id_col_name'>,
                                                            'est_col': <'your_data_est_col_name'>,
                                                            'act_col' : <'your_data_act_col_name'>}.
                        Needed for test_type = 'paired'. 'id_col' corresponds to the unique id of facilities
                        or clients, 'est_col' should be the predicted (estimated) LGD/CCF & 'act_col' should
                        be the observed (actual) LGD/CCF.

    Returns:
        result (list): A list with resulting values of number of unique facility id's, mean of
                       estimated (or predicted) value column, mean of actual (or realised) value column,
                       estimated variance, the t statistic value, & the p_value.
    """
    if isinstance(data, pd.DataFrame):
        # Number of unique facilities/customers
        _N_1 = data.count()[0]

        _N_1 = np.nan if _N_1 == 0 else _N_1

        _ratio = 1 / _N_1

        # Extract degrees of freedom
        if dof is None:
            dof0 = _N_1 - 1
        else:
            dof0 = dof

        # Average estimated LGD
        _mean_estimated = data[col_names["est_col"]].mean()

        # Average actual LGD
        _mean_actual = data[col_names["act_col"]].mean()

        # Calculate mean difference
        _diff = data[col_names["act_col"]] - data[col_names["est_col"]]
        _md = _diff.sum() * _ratio

        # Calculate variance
        variance = ((_diff - _md) ** 2).sum() * (1 / dof0)
    else:
        # Number of unique facilities/customers
        _N_1 = data.count()
        _N_1 = np.nan if _N_1 == 0 else _N_1
        _ratio = 1 / _N_1

        # Extract degrees of freedom
        if dof is None:
            dof0 = _N_1 - 1
        else:
            dof0 = dof

        # Average estimated LGD
        _mean_estimated = data.agg(f.mean(col_names["est_col"])).collect()[0][0]

        # Average actual LGD
        _mean_actual = data.agg(f.mean(col_names["act_col"])).collect()[0][0]

        # Calculate mean difference
        data = data.withColumn(
            "diff", (data[col_names["act_col"]] - data[col_names["est_col"]])
        )

        _sd = data.agg(f.sum("diff")).collect()[0][0]

        _sd = np.nan if _sd == None else _sd

        _md = _sd * _ratio

        data = data.withColumn("mdiff", (data["diff"] - _md) ** 2)

        dof0 = np.nan if dof0 == 0 else dof0

        # Calculate variance
        _sdm = data.agg(f.sum("mdiff")).collect()[0][0]

        _sdm = np.nan if _sdm is None else _sdm

        variance = (_sdm) * (1 / dof0)

    # Calculate t_statistic
    t_statistic = _md / np.sqrt(variance) * np.sqrt(_N_1)

    # Calculate p-value
    p_value = _p_value_t_test(t_statistic, side, dof0)

    result = [
        _N_1,
        _N_1,
        _mean_estimated,
        _mean_actual,
        variance,
        t_statistic,
        p_value,
        side,
    ]

    return result


def _unpaired_equal_var_t(
    group_1_data: Union[pd.Series, psd.DataFrame],
    group_2_data: Union[pd.Series, psd.DataFrame],
    dof: Optional[list],
    side: str,
) -> list:
    """
    Internal t_test function for unpaired samples & equal variances.

    This test is used to test for differences in means of two independent
    samples (i.e. unpaired) with equal variances. The implementation is based
    on the document https://en.wikipedia.org/wiki/Student%27s_t-test Section
    "Equal or unequal sample sizes, similar variances".

    Args:
        group_1_data (pandas.Series or pyspark.sql.DataFrame): Dataframe with the
                sample of the first group.

        group_2_data (pandas.Series or pyspark.sql.DataFrame): Dataframe with the
                sample of the second group.

        dof (list, optional): List of size two with degrees of freedom of
            group_1 & group_2. First (second) member of the list refers to the degrees of
            freedom of group_1_data (group_2_data) sample. If None the degrees will be
            set equal to [_N_1 - 1, _N_2 - 1] as to align to the value in document
            https://en.wikipedia.org/wiki/Student%27s_t-test Section "Equal or unequal
            sample sizes, similar variances".

        side (string): Side of alternative hypothesis. One of the following "right_tailed",
            "left_tailed" or "two_sided".

    Returns:
        result (list): A list with resulting values of sample size per group, mean of
                       group 1 column, mean of group 2 column, estimated variance,
                       the t statistic value, & the p_value.
    """

    # Number of unique facilities/customers
    _N_1 = group_1_data.count()
    _N_2 = group_2_data.count()

    _N_1 = np.nan if _N_1 == 0 else _N_1
    _N_2 = np.nan if _N_2 == 0 else _N_2

    # Extract degrees of freedom
    if dof is None:
        dof1, dof2 = _N_1 - 1, _N_2 - 1
    else:
        dof1, dof2 = dof

    dof1 = np.nan if dof1 == 0 else dof1

    dof2 = np.nan if dof2 == 0 else dof2

    if isinstance(group_1_data, psd.DataFrame):
        # Mean of each group & mean difference
        _mean_group_1 = group_1_data.agg(f.mean(group_1_data.columns[0])).collect()[0][
            0
        ]
        _mean_group_2 = group_2_data.agg(f.mean(group_2_data.columns[0])).collect()[0][
            0
        ]

        _mean_group_1 = np.nan if (_mean_group_1 is None) else _mean_group_1

        _mean_group_2 = np.nan if (_mean_group_2 is None) else _mean_group_2

        _md = _mean_group_1 - _mean_group_2

        # Calculate variances of each group
        group_1_data = group_1_data.withColumn(
            "mdiff_1", (group_1_data[group_1_data.columns[0]] - _mean_group_1) ** 2
        )
        group_2_data = group_2_data.withColumn(
            "mdiff_2", (group_2_data[group_2_data.columns[0]] - _mean_group_2) ** 2
        )

        _m_diff_1 = group_1_data.agg(f.sum("mdiff_1")).collect()[0][0]
        _m_diff_2 = group_2_data.agg(f.sum("mdiff_2")).collect()[0][0]

        _m_diff_1 = np.nan if (_m_diff_1 is None) else _m_diff_1

        _m_diff_2 = np.nan if (_m_diff_2 is None) else _m_diff_2

        _var_1 = (_m_diff_1) / dof1
        _var_2 = (_m_diff_2) / dof2
    else:
        # Mean of each group & mean difference
        _mean_group_1 = group_1_data.mean()
        _mean_group_2 = group_2_data.mean()
        _md = _mean_group_1 - _mean_group_2

        # Calculate variances of each group
        _var_1 = ((group_1_data - _mean_group_1) ** 2).sum() / dof1
        _var_2 = ((group_2_data - _mean_group_2) ** 2).sum() / dof2

    # Calculate pooled standard deviation
    _s_p_num = (_N_1 - 1) * _var_1 + (_N_2 - 1) * _var_2
    _s_p_den = dof1 + dof2

    _s_p_den = np.nan if _s_p_den == 0 else _s_p_den

    _s_p = np.sqrt(_s_p_num / _s_p_den)

    t_statistic = _md / (_s_p * np.sqrt(1 / _N_1 + 1 / _N_2))

    # Calculate p-value
    p_value = _p_value_t_test(t_statistic, side, dof1 + dof2)

    result = [
        _N_1,
        _N_2,
        _mean_group_1,
        _mean_group_2,
        (_s_p) ** 2,
        t_statistic,
        p_value,
        side,
    ]

    return result


def _unpaired_unequal_var_t(
    group_1_data: Union[pd.Series, psd.DataFrame],
    group_2_data: Union[pd.Series, psd.DataFrame],
    dof: Optional[list],
    side: str,
) -> list:
    """
    Internal t_test function for unpaired samples & equal variances.

    This test is used to test for differences in means of two independent
    samples (i.e. unpaired) with equal variances. The implementation is based
    on the document https://en.wikipedia.org/wiki/Student%27s_t-test Section
    "Equal or unequal sample sizes, unequal variances".

    Args:
        group_1_data (pandas.Series or pyspark.sql.DataFrame): Dataframe with
                        the sample of the first group.

        group_2_data (pandas.Series or pyspark.sql.DataFrame): Dataframe with
                        the sample of the second group.

        dof (list, optional): List of size two with degrees of freedom of
            group_1 & group_2. First (second) member of the list refers to the degrees of
            freedom of group_1_data (group_2_data) sample. If None the degrees will be
            set equal to [_N_1 - 1, _N_2 - 1]. The degrees of freedom will be
            combined to compute the effective (pooled) degrees of freedom as in
            https://en.wikipedia.org/wiki/Welch%E2%80%93Satterthwaite_equation.

        side (string): Side of alternative hypothesis. One of the following "right_tailed",
            "left_tailed" or "two_sided".

    Returns:
        result (list): A list with resulting values of sample size per group, mean of
                       group 1 column, mean of group 2 column, estimated variance,
                       the t statistic value, & the p_value.
    """
    # Number of unique facilities/customers
    _N_1 = group_1_data.count()
    _N_2 = group_2_data.count()

    _N_1 = np.nan if _N_1 == 0 else _N_1
    _N_2 = np.nan if _N_2 == 0 else _N_2

    # Extract degrees of freedom
    if dof is None:
        dof1, dof2 = _N_1 - 1, _N_2 - 1
    else:
        dof1, dof2 = dof

    dof1 = np.nan if dof1 == 0 else dof1

    dof2 = np.nan if dof2 == 0 else dof2

    if isinstance(group_1_data, psd.DataFrame):
        # Mean of each group & mean difference
        _mean_group_1 = group_1_data.agg(f.mean(group_1_data.columns[0])).collect()[0][
            0
        ]
        _mean_group_2 = group_2_data.agg(f.mean(group_2_data.columns[0])).collect()[0][
            0
        ]

        _mean_group_1 = np.nan if (_mean_group_1 is None) else _mean_group_1

        _mean_group_2 = np.nan if (_mean_group_2 is None) else _mean_group_2

        _md = _mean_group_1 - _mean_group_2

        # Calculate variances of each group
        group_1_data = group_1_data.withColumn(
            "mdiff_1", (group_1_data[group_1_data.columns[0]] - _mean_group_1) ** 2
        )
        group_2_data = group_2_data.withColumn(
            "mdiff_2", (group_2_data[group_2_data.columns[0]] - _mean_group_2) ** 2
        )

        _m_diff_1 = group_1_data.agg(f.sum("mdiff_1")).collect()[0][0]
        _m_diff_2 = group_2_data.agg(f.sum("mdiff_2")).collect()[0][0]

        _m_diff_1 = np.nan if (_m_diff_1 is None) else _m_diff_1

        _m_diff_2 = np.nan if (_m_diff_2 is None) else _m_diff_2

        _var_1 = (_m_diff_1) / dof1
        _var_2 = (_m_diff_2) / dof2
    else:
        # Mean of each group & mean difference
        _mean_group_1 = group_1_data.mean()
        _mean_group_2 = group_2_data.mean()
        _md = _mean_group_1 - _mean_group_2

        # Calculate variances of each group
        _var_1 = ((group_1_data - _mean_group_1) ** 2).sum() / dof1
        _var_2 = ((group_2_data - _mean_group_2) ** 2).sum() / dof2

    # Calculate standard deviation
    _s_p = np.sqrt(_var_1 / _N_1 + _var_2 / _N_2)

    # Calculate t_statistic
    t_statistic = _md / _s_p

    # Calculate pooled degrees of freedom
    num = ((_var_1 / (dof1 + 1)) + (_var_2 / (dof2 + 1))) ** 2
    den = ((_var_1 / (dof1 + 1)) ** 2) / dof1 + ((_var_2 / (dof2 + 1)) ** 2) / dof2
    pooled_df = num / den

    # Calculate p-value
    p_value = _p_value_t_test(t_statistic, side, pooled_df)

    result = [
        _N_1,
        _N_2,
        _mean_group_1,
        _mean_group_2,
        (_s_p) ** 2,
        t_statistic,
        p_value,
        side,
    ]

    return result


def _pandas_t_test(
    col_names: dict,
    dof: Optional[Union[list, float]],
    side: Optional[str],
    group_1_data: Union[pd.Series, pd.DataFrame],
    group_2_data: Union[pd.Series, pd.DataFrame],
    binning_type: Optional[Literal["manual", "auto", "lgd", "ecb", "auto"]] = "auto",
    bins=Optional[list],
    test_type: Optional[
        Literal["paired", "unpaired_equal_variances", "unpaired_unequal_variances"]
    ] = "unpaired_equal_variances",
) -> pd.DataFrame:
    """
    pandas t_test implementation.

    The function allows for the t test statistic & p value computation of paired samples & unpaired samples
    with equal & unequal variances based on data of pandas.Series or pandas.DataFrame types.

    Args:
        col_names (dictionary): Dictionary of the form col_names = {'id_col': <'your_data_id_col_name'>,
                                                                    'est_col': <'your_data_est_col_name'>,
                                                                    'act_col' : <'your_data_act_col_name'>}.
                                Needed for test_type = 'paired'. 'id_col' corresponds to the unique id of facilities
                                or clients, 'est_col' should be the predicted (estimated) LGD/CCF & 'act_col' should
                                be the observed (actual) LGD/CCF.

        dof (list or float, optional):   Degrees of freedom. Defaults to None and in this case the
                            degrees will be set to the value in documentation of each
                            of the types of tests. N - 1 for test_type = "paired"; [N_1 - 1, N_2 - 1]
                            for test_type = "unpaired_equal_variances" &
                            test_type = "unpaired_unequal_variances". If specified by the user, the
                            value should be a list of size 2 for test_type = "unpaired_equal_variances" &
                            test_type = "unpaired_unequal_variances" & a float for test_type = "paired".

        side (string, optional):   Side of alternative hypothesis. One of the following "right_tailed",
                      "left_tailed". Defaults to "two_sided".

        group_1_data (pandas.Series, pandas.DataFrame):  First group sample data.
                                If test_type = "paired", the data should be a pandas.DataFrame
                                including the columns specified in col_names.

        group_2_data (pandas.Series):  Second group sample data. If test_type = "paired",

        binning_type (string, optional):   The type of binning required for segments of group_1 values.
                              Must be one of the following: "manual", "auto", "lgd", "ecb".
                              "auto" by default.

        bins (list, optional):   The desired bins when binning_type = "manual".
                                this data frame should not be specified.

        test_type (string, optional): The type of t test. One of the following "paired",
                        "unpaired_equal_variances" or "unpaired_unequal_variances".
                        Defaults to "unpaired_equal_variances".

    Returns:
        result_df (pandas.DataFrame):   The data frame with the sample size of each group, group_1 mean,
                                    group_2 mean, estimated variance, t_test value & p-value. If sample
                                    size of both groups are equal the data frame will contain results
                                    at the portafolio (first row of data frame) & segment levels
                                    (one segment per row). If sample sizes differ the result will be given
                                    at the portfolio level only.

    Raises:
        Warning: when either group_1_data or group_2_data are empty.

        ValueError: If test_type == "paired" & 'id_col' contains duplicate values.
    """
    print(type(group_1_data))
    result = []
    col_index = [
        "N_group1",
        "N_group2",
        "mean_group1",
        "mean_group2",
        "var",
        "t_stat",
        "p_value",
        "side",
    ]

    # Verify if input data is empty
    if (test_type != "paired" and (group_1_data.empty or group_2_data.empty)) or (
        test_type == "paired" and group_1_data.empty
    ):
        warnings.warn(
            "Either group_1_data or group_2_data or both are empty. "
            "Returning an empty dataframe"
        )
        new_index = ["portfolio"]
        result_df = pd.DataFrame(result, columns=col_index, index=new_index)
        return result_df
    else:
        # ValueError Raise for duplicate id's in paired t test
        if test_type == "paired":
            df_length = group_1_data[col_names["id_col"]].count()
            unique_ids = group_1_data[col_names["id_col"]].nunique()
            # Check if duplicate or null values are found in ID pd.Dataframe.
            if df_length != unique_ids:
                raise ValueError(f"Values for facility id in id_data are not distinct.")

        # Computation of t tests
        # Define a list with methods
        methods = {
            "unpaired_equal_variances": _unpaired_equal_var_t,
            "unpaired_unequal_variances": _unpaired_unequal_var_t,
        }

        if test_type == "paired":
            grouping_data = group_1_data[col_names["est_col"]]
        elif group_1_data.size == group_2_data.size:
            grouping_data = group_1_data.copy()

        if test_type == "paired" or group_1_data.size == group_2_data.size:
            # Result for equal sample size
            # Creating the bins and labels
            val_pools = sorted(grouping_data.unique())

            if binning_type == "auto" and len(val_pools) <= 20:
                # If less than or equal to 20 lgd pools, use lgd estimates as bins
                input_bins = [round(i, 3) for i in val_pools]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                if (0 not in val_pools) and (min(val_pools) > 0):
                    index_labels = bins[1:-1]
                    labels = labels[1:]
                else:
                    index_labels = bins[:-1]

            elif binning_type == "auto" and len(val_pools) > 20:
                # Use ECB bins
                input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                index_labels = labels.copy()
                index_labels[-1] = ">= 1"

            elif binning_type == "ecb":
                input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                index_labels = labels.copy()
                index_labels[-1] = ">= 1"

            elif binning_type == "lgd":
                input_bins = [round(i, 3) for i in val_pools]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                if (0 not in val_pools) and (min(val_pools) > 0):
                    index_labels = bins[1:-1]
                    labels = labels[1:]
                else:
                    index_labels = bins[:-1]

            elif binning_type == "manual":
                bins, labels = _create_bins_labels(grouping_data, sorted(bins))
                index_labels = labels.copy()
                index_labels[-1] = ">= " + str(bins[-2])

            # Define test and run
            # Run t_test at the portfolio & segment levels
            for label0 in labels[0 : len(labels) - 1]:
                if test_type == "paired":
                    mask = (label0.left <= group_1_data[col_names["est_col"]]) & (
                        group_1_data[col_names["est_col"]] < label0.right
                    )
                    df1 = group_1_data[mask]
                    _result = _paired_t(df1, dof, side, col_names)
                else:
                    mask = (label0.left <= group_1_data) & (group_1_data < label0.right)
                    df1, df2 = group_1_data[mask], group_2_data[mask]
                    _result = methods[test_type](df1, df2, dof, side)
                result.append(_result)

            # Subsetting to include most right value of last bin
            # that is also the maximum estimated value.
            if test_type == "paired":
                mask = labels[-1].left <= group_1_data[col_names["est_col"]]
                df1 = group_1_data[mask]
                _result = _paired_t(df1, dof, side, col_names)
            else:
                mask = labels[-1].left <= group_1_data
                df1, df2 = group_1_data[mask], group_2_data[mask]
                _result = methods[test_type](df1, df2, dof, side)
            result.append(_result)

            if test_type == "paired":
                result.insert(0, _paired_t(group_1_data, dof, side, col_names))
            else:
                result.insert(
                    0, methods[test_type](group_1_data, group_2_data, dof, side)
                )

            new_index = ["portfolio"] + index_labels
            result_df = pd.DataFrame(result, columns=col_index, index=new_index)

        else:
            # Result for unequal sample size
            result.insert(0, methods[test_type](group_1_data, group_2_data, dof, side))
            new_index = ["portfolio"]
            result_df = pd.DataFrame(result, columns=col_index, index=new_index)

        return result_df


def _spark_t_test(
    group_1_data: psd.DataFrame,
    group_2_data: psd.DataFrame,
    col_names: dict,
    bins: Optional[list],
    test_type: Optional[
        Literal["paired", "unpaired_equal_variances", "unpaired_unequal_variances"]
    ] = "unpaired_equal_variances",
    dof: Optional[Union[list, float]] = None,
    side: Literal["two-sided"] = "two-sided",
    binning_type: Literal["manual", "auto", "lgd", "ecb", "auto"] = "auto",
) -> pd.DataFrame:
    """
    t_test implementation.

    The function allows for the t test statistic & p value computation of paired samples & unpaired samples
    with equal & unequal variances.

    Args:
        group_1_data (pyspark.sql.DataFrame):  First group sample data.
                        If test_type = "paired", the data should be a pyspark.sql.DataFrame
                        including the columns specified in col_names.

        group_2_data (pyspark.sql.DataFrame):  Second group sample data. If test_type = "paired",
                                this data frame should not be specified.

        test_type (string, optional): The type of t test. One of the following "paired",
                        "unpaired_equal_variances" or "unpaired_unequal_variances".
                        Defaults to "unpaired_equal_variances".

        col_names (dictionary): Dictionary of the form col_names = {'id_col': <'your_data_id_col_name'>,
                                                                    'est_col': <'your_data_est_col_name'>,
                                                                    'act_col' : <'your_data_act_col_name'>}.
                                Needed for test_type = 'paired'. 'id_col' corresponds to the unique id of facilities
                                or clients, 'est_col' should be the predicted (estimated) LGD/CCF & 'act_col' should
                                be the observed (actual) LGD/CCF.

        bins (list, optional):   The desired bins when binning_type = "manual".

        dof (list or float, optional):   Degrees of freedom. Defaults to None and in this case the
                            degrees will be set to the value in documentation of each
                            of the types of tests. N - 1 for test_type = "paired"; [N_1 - 1, N_2 - 1]
                            for test_type = "unpaired_equal_variances" &
                            test_type = "unpaired_unequal_variances". If specified by the user, the
                            value should be a list of size 2 for test_type = "unpaired_equal_variances" &
                            test_type = "unpaired_unequal_variances" & a float for test_type = "paired".

        side (string, optional):   Side of alternative hypothesis. One of the following "right_tailed",
                      "left_tailed". Defaults to "two_sided".

        binning_type (string, optional):   The type of binning required for segments of group_1 values.
                              Must be one of the following: "manual", "auto", "lgd", "ecb".
                              "auto" by default.

    Returns:
        result_df (pandas.DataFrame):   The data frame with the sample size of each group, group_1 mean,
                                    group_2 mean, estimated variance, t_test value & p-value. If sample
                                    size of both groups are equal the data frame will contain results
                                    at the portafolio (first row of data frame) & segment levels
                                    (one segment per row). If sample sizes differ the result will be given
                                    at the portfolio level only.

    Raises:
        Warning: when either group_1_data or group_2_data are empty.

        ValueError: If test_type == "paired" & id_col contains duplicate values.
    """
    result = []
    col_index = [
        "N_group1",
        "N_group2",
        "mean_group1",
        "mean_group2",
        "var",
        "t_stat",
        "p_value",
        "side",
    ]

    # Verify if input data is empty
    if (
        test_type != "paired"
        and (group_1_data.rdd.isEmpty() or group_2_data.rdd.isEmpty())
    ) or (test_type == "paired" and group_1_data.rdd.isEmpty()):
        warnings.warn(
            "Either group_1_data or group_2_data or both are empty. "
            "Returning an empty dataframe"
        )
        new_index = ["portfolio"]
        result_df = pd.DataFrame(result, columns=col_index, index=new_index)
        return result_df
    else:
        # ValueError Raise for duplicate id's in paired t test
        if test_type == "paired":
            df_length = group_1_data.count()
            unique_ids = group_1_data.select(col_names["id_col"]).distinct().count()
            # Check if duplicate or null values are found in ID pd.Dataframe.
            if df_length != unique_ids:
                raise ValueError(f"Values for facility id in id_data are not distinct.")

        # Computation of t tests
        # Define a list with methods
        methods = {
            "unpaired_equal_variances": _unpaired_equal_var_t,
            "unpaired_unequal_variances": _unpaired_unequal_var_t,
        }

        if test_type == "paired":
            grouping_data = group_1_data.select(col_names["est_col"])
        elif group_1_data.count() == group_2_data.count():
            grouping_data = group_1_data

        if test_type == "paired" or group_1_data.count() == group_2_data.count():
            # Result for equal sample size
            # Create an extra column with a contiguous row number id for test
            # types that are not paired.
            if test_type != "paired":
                w = Window().partitionBy(f.lit("a")).orderBy(f.lit("a"))
                group_1_data = group_1_data.withColumn(
                    "row_num", f.row_number().over(w)
                )
                group_2_data = group_2_data.withColumn(
                    "row_num", f.row_number().over(w)
                )

            # Creating the bins and labels
            val_pools = sorted(grouping_data.distinct().toPandas().to_numpy().ravel())

            if binning_type == "auto" and len(val_pools) <= 20:
                # If less than or equal to 20 lgd pools, use lgd estimates as bins
                input_bins = [round(i, 3) for i in val_pools]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                if (0 not in val_pools) and (min(val_pools) > 0):
                    index_labels = bins[1:-1]
                    labels = labels[1:]
                else:
                    index_labels = bins[:-1]

            elif binning_type == "auto" and len(val_pools) > 20:
                # Use ECB bins
                input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                index_labels = labels.copy()
                index_labels[-1] = ">= 1"

            elif binning_type == "ecb":
                input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                index_labels = labels.copy()
                index_labels[-1] = ">= 1"

            elif binning_type == "lgd":
                input_bins = [round(i, 3) for i in val_pools]
                bins, labels = _create_bins_labels(grouping_data, input_bins)
                if (0 not in val_pools) and (min(val_pools) > 0):
                    index_labels = bins[1:-1]
                    labels = labels[1:]
                else:
                    index_labels = bins[:-1]

            elif binning_type == "manual":
                bins, labels = _create_bins_labels(grouping_data, sorted(bins))
                index_labels = labels.copy()
                index_labels[-1] = ">= " + str(bins[-2])

            # Define test and run
            # Run t_test at the portfolio & segment levels
            for label0 in labels[0 : len(labels) - 1]:
                if test_type == "paired":
                    df1 = group_1_data.filter(
                        (f.col(col_names["est_col"]) >= label0.left)
                        & (f.col(col_names["est_col"]) < label0.right)
                    )
                    _result = _paired_t(df1, dof, side, col_names)
                else:
                    df1 = group_1_data.filter(
                        (f.col(group_1_data.columns[0]) >= label0.left)
                        & (f.col(group_1_data.columns[0]) < label0.right)
                    )
                    ## Join group_2_data where row numbers coincide. Keep only the column
                    ## on the original group_2_data pyspark.sql.DataFrame
                    df2 = df1.join(
                        group_2_data, df1.row_num == group_2_data.row_num
                    ).select(group_2_data.columns[0])

                    _result = methods[test_type](df1, df2, dof, side)
                result.append(_result)

            # Subsetting to include most right value of last bin
            # that is also the maximum estimated value.
            if test_type == "paired":
                df1 = group_1_data.filter(
                    (f.col(col_names["est_col"]) >= labels[-1].left)
                )
                _result = _paired_t(df1, dof, side, col_names)
            else:
                df1 = group_1_data.filter(
                    (f.col(group_1_data.columns[0]) >= labels[-1].left)
                )

                df2 = df1.join(
                    group_2_data, df1.row_num == group_2_data.row_num
                ).select(group_2_data.columns[0])

                _result = methods[test_type](df1, df2, dof, side)

            result.append(_result)

            if test_type == "paired":
                result.insert(0, _paired_t(group_1_data, dof, side, col_names))
            else:
                result.insert(
                    0, methods[test_type](group_1_data, group_2_data, dof, side)
                )

            new_index = ["portfolio"] + index_labels
            result_df = pd.DataFrame(result, columns=col_index, index=new_index)

        else:
            # Result for unequal sample size
            result.insert(0, methods[test_type](group_1_data, group_2_data, dof, side))
            new_index = ["portfolio"]
            result_df = pd.DataFrame(result, columns=col_index, index=new_index)

        return result_df


def t_test(
    group_1_data: Union[pd.Series, pd.DataFrame, psd.DataFrame],
    group_2_data: Union[pd.Series, psd.DataFrame] = None,
    col_names: dict = None,
    dof: Optional[List[Union[list, float]]] = None,
    side: Optional[Literal["right_tailed", "left_tailed", "two-sided"]] = "two_sided",
    binning_type: Literal["manual", "auto", "lgd", "ecb", "auto"] = "auto",
    bins: Optional[List[Literal[None, "manual"]]] = None,
    test_type: Optional[
        Literal["paired", "unpaired_equal_variances", "unpaired_unequal_variances"]
    ] = "unpaired_equal_variances",
) -> pd.DataFrame:
    """
    t_test implementation.

    The function allows for the t test statistic & p value computation of paired samples & unpaired samples
    with equal & unequal variances.

    More details about the t test & its variants can be found in
    https://en.wikipedia.org/wiki/Student%27s_t-test

    Args:
        group_1_data (pandas.Series, pandas.DataFrame or pyspark.sql.DataFrame):  First group sample data.
         If test_type = "paired", the data should be either a pandas.DataFrame or a
         pyspark.sql.DataFrame including the columns specified in col_names.

        group_2_data (pandas.Series or pyspark.sql.DataFrame):  Second group sample data.
         If test_type = "paired", this data frame should not be specified.

        test_type (string, optional): The type of t test. One of the following "paired",
         "unpaired_equal_variances" or "unpaired_unequal_variances". Defaults to "unpaired_equal_variances".

        col_names (dictionary): Needed for test_type = 'paired'. 'id_col' corresponds to the unique
         id of facilities or clients, 'est_col' should be the predicted (estimated) LGD/CCF & 'act_col'
         should be the observed (actual) LGD/CCF. Dictionary should take the form::

            col_names = {'id_col': <'your_data_id_col_name'>, 'est_col': <'your_data_est_col_name'>, 'act_col' : <'your_data_act_col_name'>}

        dof (list or float, optional): Degrees of freedom. Defaults to None and in this case the
         degrees will be set to the value in documentation of each of the types of tests.
         N - 1 for test_type = "paired"; [N_1 - 1, N_2 - 1] for test_type = "unpaired_equal_variances" &
         test_type = "unpaired_unequal_variances". If specified by the user, the
         value should be a list of size 2 for test_type = "unpaired_equal_variances" &
         test_type = "unpaired_unequal_variances" & a float for test_type = "paired".

        side (string, optional):   Side of alternative hypothesis. One of the following "right_tailed",
                      "left_tailed". Defaults to "two_sided".

        binning_type (string, optional):   The type of binning required for segments of group_1 values.
                              Must be one of the following: "manual", "auto", "lgd", "ecb".
                              "auto" by default.

        bins (list, optional):   The desired bins when binning_type = "manual".

    Returns:
        result_df (pandas.DataFrame):   The data frame with the sample size of each group, group_1 mean,
                                    group_2 mean, estimated variance, t_test value & p-value. If sample
                                    size of both groups are equal the data frame will contain results
                                    at the portafolio (first row of data frame, containing the results
                                    obtained using the complete dataset) & segment levels (one segment
                                    per row). If sample sizes differ the result will be given
                                    at the portfolio level only.

    Raises:
        ValueError: when test_type is not one of the following options:
            ['paired', 'unpaired_equal_variances', 'unpaired_unequal_variances']

        ValueError: when side is not one of the following options:
            ['right_tailed', 'left_tailed', 'two_sided']

        ValueError: If test_type == "paired" & col_names is not
            specified.

        ValueError: test_type == "unpaired_equal_variances" or
            test_type == "unpaired_unequal_variances" and dof
            is not a list.

        ValueError: binning_type is "manual" and bins is not a list
            containing at least one element >= 0.

        ValueError: when binning_type is not one of the following options:
            [auto, lgd, ecb, manual]

    Example:
        The function is called (from python) like this::

            result_t_test = t_test(group_1_data = df,
                                    test_type = "paired",
                                    col_names = {'id_col': 'ID',
                                                'est_col': 'LGD_est'>,
                                                'act_col' : 'LGD_act'},
                                    side = "right_tailed")

            result_t_test = t_test(group_1_data = df,
                                    test_type = "paired",
                                    col_names = {'id_col': 'ID',
                                                'est_col': 'LGD_est'>,
                                                'act_col' : 'LGD_act'},
                                    side = "right_tailed",
                                    binning_type = 'manual',
                                    bins = [0.05, 0.1, 0.5, 0.7, 0.9])

            result_t_test = t_test(LGD_estimate,
                                LGD_realised,
                                side = "right_tailed")

    Notes:
        Author: Diana Lucatero, G85544
    """
    # Value error raise for incorrect t test type
    if test_type not in [
        "paired",
        "unpaired_equal_variances",
        "unpaired_unequal_variances",
    ]:
        raise ValueError(
            "'test_type' must be one of the options: "
            "[paired, unpaired_equal_variances, "
            "unpaired_unequal_variances]"
        )

    # Value error raise for incorrect side
    if side not in ["right_tailed", "left_tailed", "two_sided"]:
        raise ValueError(
            "'side' must be one of the options: "
            "[right_tailed, left_tailed, "
            "two_sided]"
        )

    # ValueError Raise for paired t test and required id_data not in input
    if (test_type == "paired") and (col_names is None):
        raise ValueError(
            f"For test type '{test_type}', a dictionary with "
            "column names for 'id_col', 'est_col' "
            "and 'act_col' needs to be specified"
        )

    # ValueError Raise for paired t test and required id_data not in input
    if test_type != "paired" and dof is not None and not isinstance(dof, list):
        raise ValueError(
            f"The type of the dof argument of test types 'unpaired_equal_variances' & "
            "'unpaired_unequal_variances' needs to be a list of size two."
        )

    # Check correct input of manual bins
    if binning_type == "manual":
        if not isinstance(bins, list) or not len(bins) > 0 or min(bins) < 0:
            raise ValueError(
                "If binning_type = 'manual', you must specify a "
                "list with bins equal to or greater than zero on "
                "which the estimated and realised values will be "
                "discretised. For example: "
                "t_test_result, _ = t_test(data, "
                "'lgd_estimate', 'LGD', 'manual', "
                "bins=[0.25, 0.5, 0.75, 1])"
            )

    # Check correct input of binning type
    if binning_type not in ["auto", "lgd", "ecb", "manual"]:
        raise ValueError(
            "'binning_type' must be one of the options: " "[auto, lgd, ecb, manual]"
        )

    # Direct arguments to t_test functions.
    if test_type == "paired":
        if isinstance(group_1_data, pd.DataFrame):
            return _pandas_t_test(
                col_names=col_names,
                dof=dof,
                side=side,
                group_1_data=group_1_data,
                group_2_data=group_2_data,
                binning_type=binning_type,
                bins=bins,
                test_type=test_type,
            )
        elif isinstance(group_1_data, psd.DataFrame):
            return _spark_t_test(
                col_names=col_names,
                dof=dof,
                side=side,
                group_1_data=group_1_data,
                group_2_data=group_2_data,
                binning_type=binning_type,
                bins=bins,
                test_type=test_type,
            )
        else:
            raise TypeError(
                "Argument 'group_1_data' must be either a "
                "pandas.DataFrame or a pyspark.sql.DataFrame"
            )
    else:
        if isinstance(group_1_data, pd.Series) and isinstance(group_2_data, pd.Series):
            return _pandas_t_test(
                col_names=col_names,
                dof=dof,
                side=side,
                group_1_data=group_1_data,
                group_2_data=group_2_data,
                binning_type=binning_type,
                bins=bins,
                test_type=test_type,
            )
        elif isinstance(group_1_data, psd.DataFrame) and isinstance(
            group_2_data, psd.DataFrame
        ):
            return _spark_t_test(
                col_names=col_names,
                dof=dof,
                side=side,
                group_1_data=group_1_data,
                group_2_data=group_2_data,
                binning_type=binning_type,
                bins=bins,
                test_type=test_type,
            )
        else:
            raise TypeError(
                "Arguments 'group_1_data' and 'group_2_data' must both "
                "be either pandas.Series or pyspark.sql.DataFrame"
            )
