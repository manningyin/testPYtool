"""
############
Introduction
############
This module contains a class with functionality for generating randomly simulated summary tables with customer and default counts per row. This is then used to generate confidence intervals for a given test.

**Note:** Only the `auc` test (from `crv.validation.differentiation`) will work with the `MonteCarloPD` class. The class and its methods will be ammended as further tests are required.

MonteCarloPD
--------------
Use this class to construct an object containing the starting summary table. Class methods can be used as follows, please see the implementation for details and arguments:
 * `.run()` - Used to generate a list of results, must be called before `.get_ci()`.
 * `.get_ci()` - Returns the confidence interval of the test results for a given alpha level.
 * `.get_test_results()` - Returns the single result of running the specified test function on the supplied summary data. This is the same as directly running the test function on the data, but it is a wrapper for convenience.

Notes
=====
Author: Lee MacKenzie Fischer <G01679>

##############
Implementation
##############
"""

# Imports.
import sys
import time
from typing import Callable
import pandas as pd
import numpy as np
from crv.validation.differentiation import auc
from multiprocessing import Pool, cpu_count
from numbers import Number

__all__ = ["MonteCarloPD"]


class MonteCarloPD:
    """
    A class containing generalized functionality for performing a
    Monte Carlo simulation of probability of default using summarized
    credit risk data. Currently accepts 'auc' as the test function.

    Results of the 'test_func' are collected for each run and the returned
    value or values are


    Args:
        data (pandas.DataFrame): A summarized table of data, usually
            grouped by rating.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding
            estimated PD values.

        test_func (function): The test function to be used to summarize each
            Monte Carlo round.

    Returns:
        (MonteCarloPD object): An object instance of this class.

    Example:
        Create the object in Python like this::

            mc_obj = MonteCarloPD(data=df, 'default', 'N', 'PD_estimate')

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """

    def __init__(
        self,
        data: pd.DataFrame,
        default_count_col: str = "D",
        customer_count_col: str = "N",
        pd_col: str = "PD",
        test_func: Callable = auc,
    ):
        """
        Constructor.

        """
        self.data = data.copy()
        self._D, self._N, self._PD = default_count_col, customer_count_col, pd_col
        self.test_func = test_func

    def _run_single_round(self, _) -> Callable:
        """
        Executes a single round of simulation.

        Args:
            _ (...): An unused dummy variable, required for multiprocessing.

        Returns:
            (...): The results of 'test_func'.
        """
        dfi = self.data.copy()
        dfi["D_MC"] = np.random.binomial(dfi[self._N], dfi[self._PD], dfi.shape[0])

        return self.test_func(
            dfi, default_count_col="D_MC", customer_count_col=self._N, pd_col=self._PD
        )

    def run(self, num_rounds: int = 100) -> None:
        """
        Runs the simulation. Overwrites any previous results stored in
        the object.

        Args:
            num_rounds (int): Number of rounds to run of the simulation.

        Returns:
            (None)
        """
        # Setup timing.
        start_time = time.time()
        # Setup multiprocessing pool.
        pool = Pool(cpu_count())
        # Setup results and jobs collectors.
        sample_result = self.get_test_results()
        sample_result = (
            [sample_result]
            if not isinstance(sample_result, (list, tuple, set))
            else sample_result
        )
        self.results = [[] for k in range(len(sample_result))]

        jobs = pool.imap_unordered(
            self._run_single_round, [1 for i in range(num_rounds)]
        )
        # Process asynchronous output, report progress and progress bar.
        max_prog_bar_len = 25
        for i, job_i in enumerate(jobs, 1):
            job_i_list = [job_i] if not isinstance(job_i, (list, tuple, set)) else job_i
            for j, job_val in enumerate(job_i_list):
                self.results[j].append(job_val)
            num_fill = int((i / num_rounds) * max_prog_bar_len)
            prog_bar_string = (
                "|" + num_fill * "#" + (max_prog_bar_len - num_fill) * " " + "|"
            )
            sys.stderr.write(
                f"\r{prog_bar_string} Completed {i} of {num_rounds} simulation rounds."
            )
        pool.close()
        pool.join()
        exec_time = time.time() - start_time
        print(
            f"Execution time: {int(exec_time/60)} minutes {round(exec_time%60, 1)} seconds"
        )

    def get_test_results(self) -> Callable:
        """
        Returns the results of the 'test_func' test (not simulated).

        Returns:
            (...): The same value(s) as the 'test_func'.
        """
        return self.test_func(
            self.data,
            default_count_col=self._D,
            customer_count_col=self._N,
            pd_col=self._PD,
        )

    def get_ci(self, alpha: float = 0.95) -> float:
        """
        Returns the confidence intervals for the results of 'test_func'.
        If the test function result was a list-like object the quantiles
        will be returned in a list of lists of the same length as the
        result, in the same order as the test function result.

        Args:
            alpha (float): The confidence level (as a fraction) for the
             interval to return. Default is 0.95 (95%).

        Returns:
            (...): The same types as the 'test_func' returns, with each
             scalar value replaced with a tuple of (LCL, UCL). If the test
             function result was a list-like object the quantiles will be returned
             in a list of lists of the same length as the result, in the
             same order as the test function result.
        """
        alpha_diff = (1 - alpha) / 2
        quantiles = [alpha_diff, 1 - alpha_diff]
        return [np.quantile(result, quantiles) for result in self.results]
