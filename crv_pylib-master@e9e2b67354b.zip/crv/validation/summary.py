"""
############
Introduction
############
The ECB guideline "Annex 2 - Instructions for reporting the validation results of internal models" of February 2019 describe a common set of statistical tests and analyses (validation tools) to verify the adequacy, robustness and reliability of Pillar I models relating to credit risk.

Part of these validation tools are summary tables, which provide a consolidated view of credit risk model output. In addition, these summary tables provide the basis for the calculation of other validation metrics. 
    
Validation tools
================
This section gives an overview of the validation tools available to provide a consolidated view of the output from PD, LGD, EAD/CCF models. 

PD
--
Validation tools to assess the performance of PD models are calculated at a consolidated rating grade level or portfolio level (or both). 

* **PD portfolio information**: A consolidated view on the output of the PD model for the application portfolio; including information such as the RWEA for the portfolio, portfolio's exposure at default, portfolio's exposure value for defaulted cutomers, the number of customers, the number of rating grades and the number of defaults

* **ADF summary table**: A consolidated view on actual default frequency (ADF) for the specified grouping columns (e.g. rating grades).
 
* **Migration matrix**: A function for calculating and containing the migration matrix of before-and-after PD data sets that will give insight into the migration of customers across rating grades.

* **Migration matrix summary**: Summarizes the square portion of the migration matrix (rating grade to rating grade, excludes defaults/model change/termination) by counting the number of customers that moved up or down 1, 2 or more grades in the migration matrix.

LGD
---
Validation tools to assess the performance of LGD models are calculated at a consolidated facility grade or pool level, at portfolio level (or both). 

* **LGD contingency table**: A function for calculating a two-way contingency table with all possible combinations of (discretised) estimated LGD and discretised realised LGD and the observed frequencies for each combination for all pairs of defaulted facilities.

EAD/CCF
-------
Validation tools to assess the performance of CCF/EAD models are calculated at a consolidated facility grade or pool or segment level, at portfolio level (or both). 

* **LGD contingency table**: A function for calculating a two-way contingency table with all possible combinations of (discretised) estimated CCF and discretised realised CCF and the observed frequencies for each combination for all pairs of defaulted facilities.

Warning
=======
The functions herein assume the data has been correctly processed up to this point. See other modules if data processing is needed. This implies that data has been extracted and contain the required variables. Variables required for the test should be stated in the function header.

Notes
=====
Author: N440730, G01679, G85538, G85544

###################
Test implementation
###################

"""

from typing import List, Union
import warnings
import numpy as np
import pandas as pd
import pyspark.sql.functions as f
import pyspark.sql.dataframe as psd
from pyspark.ml.feature import Bucketizer
from typing_extensions import Literal
from crv.utils.dataframe_helper import rating_cats
from crv.utils.validation_helper import _create_bins_labels

__all__ = [
    "pd_portfolio_information",
    "adf_summary",
    "migration_matrix",
    "mm_summary",
    "lgd_contingency_table",
]


def pandas_pd_portfolio_information(
    df1: pd.DataFrame, df2: pd.DataFrame, d_colnames: dict
) -> pd.DataFrame:
    """
    Summarizes the two input DataFrames into a single table as per
    Section 2.4.3 of ECB document "Annex 2 - Instructions for reporting
    the validation results of internal models", February 2019.

    Accepts only pandas.DataFrames.

    Args:
        df1 (pandas.DataFrame): The data for the beginning of the observation
         period.

        df2 (pandas.DataFrame): The data for the end of the observation period.

        d_colnames (dict): A dictionary to map the column names found in
         the input DataFrames. The dictionary shall be of the following
         form::

                {'RWEA': ..., 'EAD': ..., 'cust_id': ..., 'rating': ..., 'default': ...}

    Returns:
        (pandas.DataFrame): The summary table summing the totals for each
         column in the dictionary in each observation period, as well as
         a fractional change across the periods.

    Raises:
        ValueError: If the input DataFrames are not pandas.DataFrames.

        ValueError: If the d_colnames dictionary does not contain all the information needed.

        ValueError: If the DataFrames do not contain all the columns needed.

        ValueError: If the column names in d_colnames are repeated.

        ValueError: If customer ID column contains non-unique values.

        ValueError: If values other than '1', an d'0' are found in the default flag column.

    Examples:
        Call function in Python like this::

            df_port_inf = pandas_pd_portfolio_information(df_start,df_end, d_cols)

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # Errors for ID non-uniqueness and default flag values, and DataFrame type.
    for df in [df1, df2]:
        # Raise error if df1 nor df2 are pd.DataFrame type
        if not isinstance(df, pd.DataFrame):
            raise ValueError("Input data must be of pandas" "DataFrame types.")
        # Setup 'invalid_flag' for checking unique values of 'default_col'.
        default_values = df[d_colnames["default"]].unique()
        invalid_flag = False
        for val in default_values:
            if (val != 1) and (val != 0):
                invalid_flag = True
                break
        df_length = df.shape[0]
        unique_ids = len(df[d_colnames["cust_id"]].unique())
        # Raise error if duplicate or null values are found in the customer ID column.
        if df_length != unique_ids:
            raise ValueError(
                f"Values for customer id in '{d_colnames['cust_id']}' are not distinct."
                " Values in migration matrix will be incorrect."
            )
        # Raise error if incorrect values are found in the default flag column.
        if (len(default_values) > 2) or invalid_flag:
            raise ValueError(
                f"Too many or invalid values are found for default flag in '{d_colnames['default']}'."
                f" Accepted values are (1, 0) or (1.0, 0.0), instead found values: {default_values}"
            )

    # Return an error when d_colnames is not of expected format.
    key_ = ["RWEA", "EAD", "cust_id", "rating", "default"]
    if len(set(list(d_colnames.keys())) & set(key_)) != 5:
        raise ValueError(
            "Input passed to argument d_colnames"
            " must be a dictionary of the form "
            "{'RWEA': ...,"
            "'EAD': ...,"
            "'cust_id': ...,"
            "'rating': ...,"
            "'default': ...}"
        )

    # Check if the required columns are found in both data sets.
    for col in list(d_colnames.values()):
        if (col not in df1.columns) or (col not in df2.columns):
            raise ValueError(
                f"Column name '{col}' must exist " "in both input DataFrames."
            )

    # Check that the column names are different.
    if len(d_colnames.values()) > len(set(d_colnames.values())):
        raise ValueError("Column names in d_colnames must be " "distinct.")

    df_list = []
    meas_labels = [
        "RWEA",
        "EAD",
        "Number of customers",
        "Number of rating grades",
        "Exposure value of customers in default",
        "Number of defaults",
    ]
    for df in [df1, df2]:
        d = {
            "Measure": meas_labels,
            "val": [
                df[d_colnames["RWEA"]].sum(),
                df[d_colnames["EAD"]].sum(),
                df[d_colnames["cust_id"]].count(),
                df[d_colnames["rating"]].nunique(),
                df[df[d_colnames["default"]] == 1][d_colnames["EAD"]].sum(),
                df[d_colnames["default"]].sum(),
            ],
        }
        df_list.append(pd.DataFrame.from_dict(data=d))

    df_list[0] = df_list[0].rename(
        columns={"val": "Beginning of the observation period"}
    )
    df_list[1] = df_list[1].rename(columns={"val": "End of the observation period"})
    df = df_list[0].merge(right=df_list[1], how="left", on="Measure")
    df["Change"] = (
        df["End of the observation period"] - df["Beginning of the observation period"]
    ) / df["Beginning of the observation period"]
    return df


def spark_pd_portfolio_information(
    df1: psd.DataFrame, df2: psd.DataFrame, d_colnames: dict
) -> pd.DataFrame:
    """
    Summarizes the two input DataFrames into a single table as per
    Section 2.4.3 of ECB document "Annex 2 - Instructions for reporting
    the validation results of internal models", February 2019.

    Accepts only pyspark.sql.DataFrames.

    Args:
        df1 (pyspark.sql.DataFrame): The data for the beginning of the observation
         period.

        df2 (pyspark.sql.DataFrame): The data for the end of the observation period.

        d_colnames (dict): A dictionary to map the column names found in
         the input DataFrames. The dictionary shall be of the following
         form::
                {'RWEA': ...,
                'EAD': ...,
                'cust_id': ...,
                'rating': ...,
                'default': ...}

    Returns:
        (pandas.DataFrame): The summary table summing the totals for each
         column in the dictionary in each observation period, as well as
         a fractional change across the periods.

    Raises:
        ValueError - If the d_colnames dictionary
            does not contain all the information needed.
        ValueError - If the DataFrames do not contain
            all the columns needed.
        ValueError - If the column names in dcolnames
            are repeated.

    Examples:
        Call function in Python like this::

            df_port_inf = spark_pd_portfolio_information(df_start, df_end,
                                                   d_cols)

    Notes:
        Author: Diana Lucatero <G85544>
    """
    # Return an error when d_colnames is not of expected format
    key_ = ["RWEA", "EAD", "cust_id", "rating", "default"]
    if len(set(list(d_colnames.keys())) & set(key_)) != 5:
        raise ValueError(
            "Input passed to argument d_colnames"
            " must be a dictionary of the form "
            "{'RWEA': ...,"
            "'EAD': ...,"
            "'cust_id': ...,"
            "'rating': ...,"
            "'default': ...}"
        )

    # Check if the required columns are found in both data sets.
    for col in list(d_colnames.values()):
        if (col not in df1.columns) or (col not in df2.columns):
            raise ValueError(
                f"Column name '{col}' must exist " "in both input DataFrames."
            )

    # Check that the column names are different.
    if len(d_colnames.values()) > len(set(d_colnames.values())):
        raise ValueError("Column names in d_colnames must be " "distinct.")

    # Check for customer ID uniqueness and allowed default flag values.
    for df in [df1, df2]:
        # Setup 'invalid_flag' for checking unique values of 'default_col'.
        default_values = (
            df.select(d_colnames["default"])
            .distinct()
            .toPandas()[d_colnames["default"]]
            .to_list()
        )
        invalid_flag = False
        for val in default_values:
            if (val != 1) and (val != 0):
                invalid_flag = True
                break
        df_length = df.count()
        unique_ids = df.select(d_colnames["cust_id"]).distinct().count()
        # Check if duplicate or null values are found in the customer ID column.
        if df_length != unique_ids:
            raise ValueError(
                f"Values for customer id in '{d_colnames['cust_id']}' are not distinct."
                " Values in migration matrix will be incorrect."
            )
        # Check if incorrect values are found in the default flag column.
        if (len(default_values) > 2) or invalid_flag:
            raise ValueError(
                f"Too many or invalid values are found for default flag in '{d_colnames['default']}'."
                f" Accepted values are (1, 0) or (1.0, 0.0), instead found values: {default_values}"
            )

    # Summary labels
    meas_labels = [
        "RWEA",
        "EAD",
        "Number of customers",
        "Number of rating grades",
        "Exposure value of customers in default",
        "Number of defaults",
    ]

    # Aggregation pyspark.DataFrames.
    df_list = []
    key_.append("EAD_in_default")
    # Aggregate & collect to memory of driver to obtain a list instead of
    # pyspark DataFrame object.
    for df in [df1, df2]:
        df = df.agg(
            f.sum(f.col(d_colnames["RWEA"])).alias(key_[0]),
            f.sum(f.col(d_colnames["EAD"])).alias(key_[1]),
            f.count(f.col(d_colnames["cust_id"])).alias(key_[2]),
            f.countDistinct(f.col(d_colnames["rating"])).alias(key_[3]),
            f.sum(
                f.when(
                    f.col(d_colnames["default"]) == 1, f.col(d_colnames["EAD"])
                ).otherwise(0)
            ).alias(key_[5]),
            f.sum(f.col(d_colnames["default"])).alias(key_[4]),
        ).collect()
        # Create a list of aggregation values
        value = [
            df[0].RWEA,
            df[0].EAD,
            df[0].cust_id,
            df[0].rating,
            df[0].EAD_in_default,
            df[0].default,
        ]
        # Create a dictionary of aggregation values
        d = {"Measure": meas_labels, "val": value}

        df_list.append(pd.DataFrame.from_dict(data=d))

    df_list[0] = df_list[0].rename(
        columns={"val": "Beginning of the observation period"}
    )
    df_list[1] = df_list[1].rename(columns={"val": "End of the observation period"})
    df = df_list[0].merge(right=df_list[1], how="left", on="Measure")
    df["Change"] = (
        df["End of the observation period"] - df["Beginning of the observation period"]
    ) / df["Beginning of the observation period"]
    return df


def pd_portfolio_information(
    df1: Union[pd.DataFrame, psd.DataFrame],
    df2: Union[pd.DataFrame, psd.DataFrame],
    d_colnames: dict,
) -> pd.DataFrame:
    """
    Summarizes the two input DataFrames into a single table as per
    Section 2.4.3 of ECB document "Annex 2 - Instructions for reporting
    the validation results of internal models", February 2019.

    Accepts either pandas.DataFrames or pyspark.sql.DataFrames,
    but both DataFrames must be of the same type.

    Args:
        df1 (pandas.DataFrame, pyspark.sql.DataFrame): The data for the
         beginning of the observation period. Must be the same type as
         'df2'.

        df2 (pandas.DataFrame, pyspark.sql.DataFrame): The data for the end
         of the observation period. Must be the same type as 'df1'.

        d_colnames (dict): A dictionary to map the column names found in
         the input DataFrames. The dictionary shall be of the following
         form::
                {'RWEA': ...,
                'EAD': ...,
                'cust_id': ...,
                'rating': ...,
                'default': ...}

    Returns:
        (pandas.DataFrame): The summary table summing the totals for each
         column in the dictionary in each observation period, as well as
         a fractional change across the periods.

    Raises:
        ValueError - If the input DataFrames are neither of the pandas or
         pyspark variety.

        ValueError - If the input DataFrames are not of the same type.

    Examples:
        Call function in Python like this::

            df_port_inf = spark_pd_portfolio_information(df_start, df_end,
                                                   d_cols)

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # Check that data arguments are the same type.
    if type(df1) != type(df2):
        raise TypeError("Arguments 'df1' and 'df2' must be of the " "same type.")
    # Direct arguments to summary functions.
    if isinstance(df1, pd.DataFrame):
        return pandas_pd_portfolio_information(df1, df2, d_colnames)
    elif isinstance(df1, psd.DataFrame):
        return spark_pd_portfolio_information(df1, df2, d_colnames)
    else:
        raise TypeError(
            "Arguments 'df1' and 'df2' must be either "
            f"pandas or pyspark DataFrames, not {type(df1)}."
        )


def pandas_adf_summary(
    data: pd.DataFrame,
    customer_col: str,
    default_col: str,
    group_list: List[str] = None,
    sum_list: List[str] = None,
    pd_col: str = None,
    supress_empty: bool = True,
) -> pd.DataFrame:
    """
    A summary table class, from which tests can be called.

    Given the data set ready for summarizing (e.g. defaults flagged,
    duplicates removed), the constructor creates a summary table
    according to the given summary and grouping columns. The
    constructor for this table requires that the following data is
    present in the input table: unique customer id, default
    flag.

    Accepts only pandas.DataFrames.

    Args:
        data (pandas.DataFrame): The data.

        customer_col (string): Column name of the unique identifier (e.g.
         customer, group).

        default_col (string): Column name with default flag. Methods assume
         that the default column is an integer with 1 indicating default and 0
         indicating nondefault.

        group_list (list): List of column names that will be used for
         grouping in the ADF table. Default is None, resulting in the
         table being compressed to a single line.

        sum_list (list): List of column names that will be summed as the
         groups compress the data set. Default is None, resulting in no
         summed columns.

        pd_col (str): Column name of the numeric PD values, the mean
         will be calculated per grouping. Default is None, which does not
         calculate a mean PD and excludes this column.

        supress_empty (bool): Applicable only to pandas.DataFrames. Setting
         to False will allowing groupings (ratings, countries, etc.) with no
         customers or records to be present in the grouped table. Default is True.
         Ratings with no observations are introduced on the basis that the
         input DataFrame has a rating column that is of Categorical type (or
         will be converted to one within the function), and so ratings without
         observations will be included as a row of zeros based on that category's
         existence in the column metadata. Conversion to categorical can be
         done manually using 'crv.utils.dataframe_helper.rating_cats'.

        Returns:
            (pandas.DataFrame): The summarized table.

        Warnings:
            UserWarning - non-numeric column in sum_list is excluded

        Raises:
            Error - column names in default_col and customer_col
             cannot also be passed in group_list or sum_list

        Examples:
            Call function like this from Python::

                adf_table = adf_summary(data,
                                    default_col='defflag',
                                    customer_col='group',
                                    sum_list=['EAD'],
                                    group_list=['Rating'])
    """
    # Store relevant columns in variables.
    _N = customer_col
    _D = default_col
    _ADF = "ADF"
    _group = [] if isinstance(group_list, type(None)) else group_list
    _sum = [] if isinstance(sum_list, type(None)) else sum_list
    # Turn a string into a list of that string.
    _group = [_group] if isinstance(_group, str) else _group
    _sum = [_sum] if isinstance(_sum, str) else _sum

    # Check and raise exception if the mandatory variables are also
    # in group_list or sum_list, since they can't be used for both.
    for col in [default_col, customer_col]:
        if (col in _sum) or (col in _group):
            raise ValueError(
                f"{col} cannot be included in the "
                + "'sum_list' or 'group_list' if it is "
                + "already passed as one of: "
                + "'default_col', 'customer_col'."
            )

    # Check and warn about sum columns that are not numeric.
    if len(_sum) > 0:
        not_summed = [c for c in _sum if not (pd.api.types.is_numeric_dtype(data[c]))]
        _sum = [c for c in _sum if c not in not_summed]
        for ns in not_summed:
            warn_string = (
                f"Column '{ns}' is not a numeric data type "
                + "and has been excluded from the summary table."
            )
            warnings.warn(warn_string, UserWarning)

    # Setup grouping and aggregation dictionaries and lists.
    ls_group_1 = [_N] + _group
    if isinstance(pd_col, str):
        d_agg_1 = {**{_D: "max"}, **{c: "sum" for c in _sum}, **{pd_col: "mean"}}
        d_agg_2 = {
            **{_N: "count", _D: "sum"},
            **{c: "sum" for c in _sum},
            **{pd_col: "mean"},
        }
    else:
        d_agg_1 = {**{_D: "max"}, **{c: "sum" for c in _sum}}
        d_agg_2 = {**{_N: "count", _D: "sum"}, **{c: "sum" for c in _sum}}

    # apply first group, reduce to 1 customer per line.
    adf_1 = data.groupby(ls_group_1, observed=True).agg(d_agg_1).reset_index()

    # Apply second group, reudce to required summary level.
    if len(_group) > 0:
        adf_2 = adf_1.groupby(_group, observed=supress_empty).agg(d_agg_2).reset_index()
    else:
        adf_2 = adf_1.agg(d_agg_2)
        adf_2 = pd.DataFrame(adf_2).transpose()

    # Force integer type.
    adf_2[_N] = adf_2[_N].astype("int")
    adf_2[_D] = adf_2[_D].astype("int")

    # Calculate the ADF.
    adf_2[_ADF] = adf_2[_D] / adf_2[_N]

    # Replace column names to something sensible.
    customer_col_rename = "N"
    default_col_rename = "D"
    adf_2 = adf_2.rename(columns={_N: customer_col_rename, _D: default_col_rename})
    _N = customer_col_rename
    _D = default_col_rename

    # Reorder columns for return.
    _base_col_order = _group + [_N, _D, _ADF]
    if isinstance(pd_col, str):
        _base_col_order.append(pd_col)
    col_order = _base_col_order + _sum
    _sum_table = adf_2[col_order]

    return _sum_table.copy()


def spark_adf_summary(
    spark_df: psd.DataFrame,
    customer_col: str,
    default_col: str,
    group_list: List[str] = None,
    sum_list: List[str] = None,
    pd_col: str = None,
) -> pd.DataFrame:
    """
    Given a Spark.DataFrame, calculates the actual default frequency (ADF) for
    the specified grouping columns (if specified). Sums (dictated by sum
    columns) are also calcuated per the grouping columns.

    Accepts only pyspark.sql.DataFrames.

    Args:
        spark_df (pyspark.sql.DataFrame): The data to summarize.

        customer_col (str): Column name of the customer-level
         identifier by which to count.

        default_col (str): Column name with the default flag.
         Assumes that the flag is either boolean or 1/0 in
         string, integer, or float format.

        group_list (str, list): Column name or list of column
         names that will be used for grouping and sorting.
         Default is None, meaning no grouping will be done.
         If multiple columns are provided, the grouping and will
         be done in the order provided in the list.

        sum_list (str, list): Column name or list of column
         names that will be summed per group. Default is None,
         meaning no columns will be summed.

        pd_col (str): Column name of the numeric PD values, the mean
         will be calculated per grouping. Default is None, which does not
         calculate a mean PD and excludes this column.

    Returns:
        (pandas.DataFrame): The summarized ADF table.

    Raises:
        ValueError - If the customer_col or default_col is found in
         the group or sum lists.

    Examples:
        Call from Python::

            adf = spark_adf_summary(df, 'customer_id', 'default_flag')
    """
    final_colnames = {"defaults": "D", "cust_count": "N", "adf": "ADF"}
    # Set group and sum arguments to lists.
    group_list = [group_list] if isinstance(group_list, str) else group_list
    sum_list = [sum_list] if isinstance(sum_list, str) else sum_list

    # Set None to empty list.
    group_list = group_list if isinstance(group_list, list) else []
    sum_list = sum_list if isinstance(sum_list, list) else []

    # Raise error if customer or default column in group or sum list.
    if (customer_col in group_list + sum_list) or (
        default_col in group_list + sum_list
    ):
        raise ValueError(
            "'group_list' and 'sum_list' argument values must not contain the same values passed to 'customer_col' or 'default_col'."
        )

    # Setup grouping column lists.
    total_cols = [customer_col, default_col] + group_list + sum_list
    if isinstance(pd_col, str):
        total_cols.append(pd_col)
    group_cols_1 = [customer_col] + group_list if group_list else [customer_col]
    group_cols_2 = group_list

    # First reducing phase:
    # Reduces customers to one occurence per group.
    adf = spark_df.select(*total_cols).groupBy(*group_cols_1)
    if sum_list:
        if isinstance(pd_col, str):
            adf = adf.agg(
                f.max(f.col(default_col).astype("integer")).alias(
                    final_colnames["defaults"]
                ),
                f.max(f.col(pd_col).astype("float")).alias(pd_col),
                *[f.sum(f.col(s)).alias(s) for s in sum_list],
            )
        else:
            adf = adf.agg(
                f.max(f.col(default_col).astype("integer")).alias(
                    final_colnames["defaults"]
                ),
                *[f.sum(f.col(s)).alias(s) for s in sum_list],
            )
    else:
        if isinstance(pd_col, str):
            adf = adf.agg(
                f.max(f.col(default_col).astype("integer")).alias(
                    final_colnames["defaults"]
                ),
                f.max(f.col(pd_col).astype("float")).alias(pd_col),
            )
        else:
            adf = adf.agg(
                f.max(f.col(default_col).astype("integer")).alias(
                    final_colnames["defaults"]
                )
            )

    # Second reducing phase.
    # Reduce to group level and count customer.
    if group_cols_2:
        adf = adf.groupBy(*group_cols_2)
    if sum_list:
        if isinstance(pd_col, str):
            adf = adf.agg(
                f.count(f.col(customer_col)).alias(final_colnames["cust_count"]),
                f.sum(f.col(final_colnames["defaults"])).alias(
                    final_colnames["defaults"]
                ),
                f.mean(f.col(pd_col)).alias(pd_col),
                *[f.sum(f.col(s)).alias(s) for s in sum_list],
            )
        else:
            adf = adf.agg(
                f.count(f.col(customer_col)).alias(final_colnames["cust_count"]),
                f.sum(f.col(final_colnames["defaults"])).alias(
                    final_colnames["defaults"]
                ),
                *[f.sum(f.col(s)).alias(s) for s in sum_list],
            )
    else:
        if isinstance(pd_col, str):
            adf = adf.agg(
                f.count(f.col(customer_col)).alias(final_colnames["cust_count"]),
                f.sum(f.col(final_colnames["defaults"])).alias(
                    final_colnames["defaults"]
                ),
                f.mean(f.col(pd_col)).alias(pd_col),
            )
        else:
            adf = adf.agg(
                f.count(f.col(customer_col)).alias(final_colnames["cust_count"]),
                f.sum(f.col(final_colnames["defaults"])).alias(
                    final_colnames["defaults"]
                ),
            )

    # Calculate the actual default frequency.
    adf = adf.withColumn(
        final_colnames["adf"],
        f.col(final_colnames["defaults"]) / f.col(final_colnames["cust_count"]),
    )

    # Convert to pandas.DataFrame and order.
    if group_list:
        adf = adf.orderBy(*group_list)
    adf = adf.toPandas()

    if group_list:
        col_names_order = group_list.copy() + [
            final_colnames["cust_count"],
            final_colnames["defaults"],
            final_colnames["adf"],
        ]
    else:
        col_names_order = [
            final_colnames["cust_count"],
            final_colnames["defaults"],
            final_colnames["adf"],
        ]
    if isinstance(pd_col, str):
        col_names_order.append(pd_col)
    if sum_list:
        col_names_order += sum_list

    adf = adf[col_names_order]

    return adf


def adf_summary(
    df: Union[pd.DataFrame, psd.DataFrame],
    customer_col: str,
    default_col: str,
    group_list: List[str] = None,
    sum_list: List[str] = None,
    pd_col: str = None,
    supress_empty: bool = True,
) -> pd.DataFrame:
    """
    Given a DataFrame, calculates the actual default frequency (ADF) for
    the specified grouping columns (if specified). Sums (dictated by sum
    columns) are also calcuated per the grouping columns.

    This top-level function accepts either pandas.DataFrames or
    pyspark.sql.DataFrames.

    Args:
        df (pandas.DataFrame, pyspark.sql.DataFrame): The data to summarize.

        customer_col (str): Column name of the customer-level
         identifier by which to count.

        default_col (str): Column name with the default flag.
         Assumes that the flag is either boolean or 1/0 in
         string, integer, or float format.

        group_list (str, list): Column name or list of column
         names that will be used for grouping and sorting.
         Default is None, meaning no grouping will be done.
         If multiple columns are provided, the grouping and will
         be done in the order provided in the list.

        sum_list (str, list): Column name or list of column
         names that will be summed per group. Default is None,
         meaning no columns will be summed.

        pd_col (str): Column name of the numeric PD values, the mean
         will be calculated per grouping. Default is None, which does not
         calculate a mean PD and excludes this column.

        supress_empty (bool): Applicable only to pandas.DataFrames. Setting
         to False will allowing groupings (ratings, countries, etc.) with no
         customers or records to be present in the grouped table. Default is True.
         Ratings with no observations are introduced on the basis that the
         input DataFrame has a rating column that is of Categorical type (or
         will be converted to one within the function), and so ratings without
         observations will be included as a row of zeros based on that category's
         existence in the column metadata. Conversion to categorical can be
         done manually using 'crv.utils.dataframe_helper.rating_cats'.

    Returns:
        (pandas.DataFrame): The summarized ADF table.

    Raises:
        ValueError - If the input table 'df' is not a pandas or pyspark DataFrame.

    Examples:
        Call from Python::

            adf = adf_summary(df, 'customer_id', 'default_flag')
    """
    # Direct arguments to summary functions. Raise error if incorrect type found.
    if isinstance(df, pd.DataFrame):
        return pandas_adf_summary(
            df, customer_col, default_col, group_list, sum_list, pd_col, supress_empty
        )
    elif isinstance(df, psd.DataFrame):
        return spark_adf_summary(
            df, customer_col, default_col, group_list, sum_list, pd_col, supress_empty
        )
    else:
        raise TypeError(
            f"Argument 'df' must be either a pandas or a pyspark DataFrame, not {type(df)}."
        )


def pandas_migration_matrix(
    data_0: pd.DataFrame,
    data_1: pd.DataFrame,
    id_col: str,
    rating_col: str,
    model_col: str,
    default_col: str,
    force_square=False,
) -> pd.DataFrame:
    """
    A function for calculating and containing the migration matrix of
    before-and-after PD data sets. Also facilitates methods which are
    statistical tests which use the migration matrix as a base.

    Accepts only pandas.DataFrames.

    Args:
        data_0 (pandas.DataFrame): The initial or
         the "before" data, containing the rating grades FROM which the
         customers migrated.

        data_1 (pandas.DataFrame): The final or
         "after" data, containing the rating grades TO which the
         customers migrated.

        id_col  (string): The column name with the unique account
         or customer identifiers.

        rating_col (string): The column name with the rating grades.

        model_col (string): The column name indicating the model used.

        default_col (string): The column name indicating the default
         flag in 'data_0'. The default flag column in 'data_1' is ignored.

        force_square (bool): Only refers to the ratings rows/columns.
         If False, only the rows or columns of ratings with
         at least one non-zero entry will appear in the matrix. This means that
         the matrix could potentially be non-square (i.e. ratings could be
         missing from rows and not columns). If True, all combinations of ratings
         will be present, including rows and columns with all zeros, but the
         matrix will remain square.

    Returns:
        (pd.DataFrame): The migration matrix.

    Raises:
        ValueError: If the input DataFrame is not of pandas type.

        ValueError: If the input DataFrames are not of the same type.

        ValueError: If either the rating_col, id_col,
         default_col or model_col are not found in data_0 or data_1.

        ValueError: If the 'default_col' contains values other than '1' or '0'.

        ValueError: If the 'id_col' contains non-distinct values.

    Examples:
        Construct method::

            df_mm = migration_matrix(df0, df1, 'group', 'Rating',
                                    'Model', 'df_2')
    """
    # Checks and error-raising.
    # Check that the inputs are of correct type before proceeding.
    if not isinstance(data_0, pd.DataFrame):
        raise ValueError(
            "Inputs passed to arguments 'data_0' and "
            "'data_1' must be of one of the following "
            "types: pandas.DataFrame"
        )
    # Check that both input DataFrames are the same type (simplifies things).
    if type(data_0) != type(data_1):
        raise ValueError(
            f"Input 'data_1' must be of the same type as "
            f"'data_0'. 'data_0' type is '{type(data_0)}'"
        )
    # Check if the required columns are found in both data sets.
    for col in [id_col, rating_col, model_col, default_col]:
        if (col not in data_0.columns) or (col not in data_1.columns):
            raise ValueError(
                "Column names passed to 'id_col', "
                "'rating_col', 'default_col', and 'model_col' "
                "must be present in both input DataFrames."
            )
    for dff in [data_0, data_1]:
        # Setup 'invalid_flag' for checking unique values of 'default_col'.
        default_values = dff[default_col].unique()
        invalid_flag = False
        for val in default_values:
            if (val != 1) and (val != 0):
                invalid_flag = True
                break
        df_length = dff.shape[0]
        unique_ids = len(dff[id_col].unique())
        # Check if duplicate or null values are found in 'id_col'.
        if df_length != unique_ids:
            raise ValueError(
                f"Values for customer id in '{id_col}' are not distinct."
                " Values in migration matrix will be incorrect."
            )
        # Check if incorrect values are found in 'pd_col'.
        if (len(default_values) > 2) or invalid_flag:
            raise ValueError(
                f"Too many or invalid values are found for default flag in '{default_col}'."
                f" Accepted values are (1, 0) or (1.0, 0.0), instead found values: {default_values}"
            )

    # Process the first DataFrame.
    data = (
        data_0[[id_col, rating_col, model_col, default_col]]
        .copy()
        .rename(
            columns={
                id_col: "act",
                rating_col: "rat_0",
                model_col: "mod_0",
                default_col: "df_0",
            }
        )
    )

    # If rating_col and/or model_col are categorical we add new categories.
    extra_cats_d_0 = {
        "rat_0": ["Missing rating", "Missing model"],
        "mod_0": ["Missing"],
    }
    for col, extra_cats in extra_cats_d_0.items():
        if data[col].dtype.name == "category":
            for cat in extra_cats:
                if cat not in data[col].cat.categories:
                    data[col] = data[col].cat.add_categories(cat)

    data = data.fillna(value={"rat_0": "Missing rating", "mod_0": "Missing"})

    data.loc[data.mod_0 == "Missing", "rat_0"] = "Missing model"

    if data["rat_0"].dtype.name != "category":
        data = rating_cats(data, "rat_0")

    # Merge to a single DataFrame.
    data = data.merge(
        data_1[[id_col, rating_col, model_col]].rename(
            columns={id_col: "act", rating_col: "rat_1", model_col: "mod_1"}
        ),
        on="act",
        how="left",
        indicator="mcheck",
    )

    # If rating_col and/or model_col are categorical we add new categories.
    extra_cats_d_1 = {
        "rat_1": [
            "Missing rating",
            "Missing model",
            "Defaults",
            "Other model",
            "Relationship terminated",
        ],
        "mod_1": ["Missing"],
    }
    for col, extra_cats in extra_cats_d_1.items():
        if data[col].dtype.name == "category":
            for cat in extra_cats:
                if cat not in data[col].cat.categories:
                    data[col] = data[col].cat.add_categories(cat)

    data = data.fillna(value={"rat_1": "Missing rating", "mod_1": "Missing"})

    # Fix model categories so they can be compared.
    if data["mod_0"].dtype.name == "category" or data["mod_1"].dtype.name == "category":
        sets = {}
        for col in ("mod_0", "mod_1"):
            if data[col].dtype.name != "category":
                data[col] = data[col].astype("category")
            sets[col] = set(data[col].cat.categories.tolist())
        data["mod_0"] = data["mod_0"].cat.add_categories(sets["mod_1"] - sets["mod_0"])
        data["mod_1"] = data["mod_1"].cat.add_categories(sets["mod_0"] - sets["mod_1"])

    # Flag rat_1 column with relevant label for customers that have
    # defaulted, changed model, or are no longer with the bank.
    data.loc[data.df_0 == 1, "rat_1"] = "Defaults"
    data.loc[
        (data.df_0 == 0) & (data.mcheck == "left_only"), "rat_1"
    ] = "Relationship terminated"
    data.loc[
        (data.df_0 == 0) & (data.mcheck == "both") & (data.mod_1 == "Missing"), "rat_1"
    ] = "Missing model"
    data.loc[
        (data.df_0 == 0)
        & (data.mcheck == "both")
        & (data.mod_1 != "Missing")
        & (data.mod_0 != data.mod_1),
        "rat_1",
    ] = "Other model"

    if data["rat_1"].dtype.name != "category":
        data = rating_cats(data, col="rat_1")

    # Build migration matrix.
    migbase = data.groupby(by=["rat_0", "rat_1"], observed=not force_square)[
        "act"
    ].count()

    df_m = pd.DataFrame()
    for tup in migbase.index:
        df_m.loc[tup[0], tup[1]] = migbase[tup]
    n_i = df_m.sum(axis=1)
    df_m = df_m.div(n_i, axis=0).fillna(0)

    # Order columns in final dataframe.
    col_order = [cn for cn in data.rat_1.cat.categories if cn in df_m.columns]
    df_m = df_m[col_order]
    df_m["N"] = n_i

    # Return the resulting matrix.
    return df_m.copy()


def spark_migration_matrix(
    data_0: pd.DataFrame,
    data_1: pd.DataFrame,
    id_col: str,
    rating_col: str,
    model_col: str,
    default_col: str,
) -> pd.DataFrame:
    """
    A function for calculating and containing the migration matrix of
    before-and-after PD data sets in spark. Also facilitates methods which are
    statistical tests which use the migration matrix as a base.

    Accepts only pyspark.sql.DataFrames.

    Args:
        data_0 (pyspark.sql.DataFrame): The initial or
        the "before" data, containing the rating grades FROM which the
        customers migrated.

        data_1 (pyspark.sql.DataFrame): The final or
        "after" data, containing the rating grades TO which the
        customers migrated.

        id_col (string): The column name with the unique account
        or customer identifiers.

        rating_col (string): The column name with the rating grades.

        model_col (string): The column name indicating the model used.

        default_col (string): The column name indicating the default
        flag in 'data_0'. The default flag column in 'data_1' is ignored.

    Returns:
        (pandas.DataFrame): The migration matrix.

    Raises:
        ValueError: If either the rating_col, id_col,
         default_col or model_col are not found in data_0 or data_1.

        ValueError: If the 'default_col' contains values other than '1' or '0'.

        ValueError: If the 'id_col' contains non-distinct values.

    Examples:
        Construct method::

            df_mm = spark_migration_matrix(df0, df1, 'group', 'Rating',
                                    'Model', 'df_2')
    """
    # Checks and error-raising.
    # Check if the required columns are found in both data sets.
    for col in [id_col, rating_col, model_col, default_col]:
        if (col not in data_0.columns) or (col not in data_1.columns):
            raise ValueError(
                "Column names passed to 'id_col', "
                "'rating_col', 'default_col', and 'model_col' "
                "must be present in both input DataFrames."
            )
    for dff in [data_0, data_1]:
        # Setup 'invalid_flag' for checking unique values of 'default_col'.
        default_values = (
            dff.select(default_col).distinct().toPandas()[default_col].to_list()
        )
        invalid_flag = False
        for val in default_values:
            if (val != 1) and (val != 0):
                invalid_flag = True
                break
        df_length = dff.count()
        unique_ids = dff.select(id_col).distinct().count()
        # Check if duplicate or null values are found in 'id_col'.
        if df_length != unique_ids:
            raise ValueError(
                f"Values for customer id in '{id_col}' are not distinct."
                " Values in migration matrix will be incorrect."
            )
        # Check if incorrect values are found in 'pd_col'.
        if (len(default_values) > 2) or invalid_flag:
            raise ValueError(
                f"Too many or invalid values are found for default flag in '{default_col}'."
                f" Accepted values are (1, 0) or (1.0, 0.0), instead found values: {default_values}"
            )

    # Process the first DataFrame.
    data = data_0.select(
        f.col(id_col).alias("act"),
        f.col(rating_col).alias("rat_0"),
        f.col(model_col).alias("mod_0"),
        f.col(default_col).alias("df_0"),
    )

    data = data.na.fill({"rat_0": "Missing rating", "mod_0": "Missing"})

    data = data.withColumn(
        "rat_0",
        f.when(data["mod_0"] == "Missing", "Missing model").otherwise(data["rat_0"]),
    )

    # Process the second DataFrame.
    data_1 = data_1.select(
        f.col(id_col).alias("act_1"),
        f.col(rating_col).alias("rat_1"),
        f.col(model_col).alias("mod_1"),
    )

    # Merge to a single DataFrame.
    data = data.join(data_1, data["act"] == data_1["act_1"], "left")

    data = data.withColumn(
        "mcheck", f.when(data["act_1"].isNull(), "left_only").otherwise("both")
    ).drop("act_1")

    data = data.na.fill({"rat_1": "Missing rating", "mod_1": "Missing"})

    # Flag rat_1 column with relevant label for customers that have
    # defaulted, changed model, or are no longer with the bank.
    data = data.withColumn(
        "rat_1", f.when(data["df_0"] == 1, "Defaults").otherwise(data["rat_1"])
    )
    data = data.withColumn(
        "rat_1",
        f.when(
            (data["df_0"] == 0) & (data["mcheck"] == "left_only"),
            "Relationship terminated",
        ).otherwise(data["rat_1"]),
    )
    data = data.withColumn(
        "rat_1",
        f.when(
            (data["df_0"] == 0)
            & (data["mcheck"] == "both")
            & (data["mod_1"] == "Missing"),
            "Missing model",
        ).otherwise(data["rat_1"]),
    )
    data = data.withColumn(
        "rat_1",
        f.when(
            (data["df_0"] == 0)
            & (data["mcheck"] == "both")
            & (data["mod_1"] != "Missing")
            & (data["mod_0"] != data["mod_1"]),
            "Other model",
        ).otherwise(data["rat_1"]),
    )

    # Build migration matrix.
    migbase = data.crosstab("rat_0", "rat_1")

    col_names = migbase.columns
    col_names.remove("rat_0_rat_1")

    migbase = migbase.withColumn("N", sum(migbase[col] for col in col_names))

    for field in col_names:
        migbase = migbase.withColumn(field, f.col(field) / f.col("N"))

    # Convert Spark.DataFrame to pandas.DataFrame and format the output table.
    pandas_mm = migbase.toPandas()
    pandas_mm = rating_cats(pandas_mm, "rat_0_rat_1").sort_values("rat_0_rat_1")
    rating_list = pandas_mm["rat_0_rat_1"].tolist()
    pandas_mm = pandas_mm.set_index("rat_0_rat_1")
    other_cols_list = [
        col
        for col in ["Defaults", "Other model", "Relationship terminated", "N"]
        if col in pandas_mm.columns
    ]
    pandas_mm = pandas_mm[rating_list + other_cols_list]
    pandas_mm.index.name = None

    # Return the resulting matrix.
    return pandas_mm


def migration_matrix(
    data_0: Union[pd.DataFrame, psd.DataFrame],
    data_1: Union[pd.DataFrame, psd.DataFrame],
    id_col: str,
    rating_col: str,
    model_col: str,
    default_col: str,
    force_square=False,
) -> pd.DataFrame:
    """
    A function for calculating and containing the migration matrix of
    before-and-after PD data sets. Also facilitates methods which are
    statistical tests which use the migration matrix as a base.

    This top-level function accepts both pandas and pyspark DataFrames.

    **Note:** It is recommended that you apply categories to the rating
    columns with the proper order (best to worst) as this will ensure
    the matrix can be formed square should there be any columns with all
    zeros. This is generally not an issue in Spark data.

    Args:
        data_0 (pandas.DataFrame, pyspark.sql.DatFrame): The initial or
         the "before" data, containing the rating grades FROM which the
         customers migrated.

        data_1 (pandas.DataFrame, pyspark.sql.DataFrame): The final or
         "after" data, containing the rating grades TO which the
         customers migrated.

        id_col (string): The column name with the unique account
         or customer identifiers.

        rating_col (string): The column name with the rating grades.

        model_col (string): The column name indicating the model used.

        default_col (string): The column name indicating the default
         flag in 'data_0'. The default flag column in 'data_1' is ignored.

        force_square (bool): Only refers to the ratings rows/columns.
         If False, only the rows or columns of ratings with
         at least one non-zero entry will appear in the matrix. This means that
         the matrix could potentially be non-square (i.e. ratings could be
         missing from rows and not columns). If True, all combinations of ratings
         will be present, including rows and columns with all zeros, but the
         matrix will remain square. Only relevant for pandas DataFrames.

    Returns:
        (pd.DataFrame): The migration matrix.

    Raises:
        ValueError: If the input DataFrames are not pandas.DataFrame
         or pyspark.sql.DataFrames.

        ValueError: If the input DataFrames are not of the same type.

    Examples:
        Call from Python like this::

            df_mm = migration_matrix(df0, df1, 'group', 'Rating',
                                    'Model', 'df_2')
    """
    # Check that data arguments are the same type.
    if type(data_0) != type(data_1):
        raise TypeError(
            "Input data arguments 'data_0' and 'data_1' must " "be of the same type."
        )
    # Direct arguments to summary functions. Throw error if not
    # pandas or pyspark DataFrames.
    if isinstance(data_0, pd.DataFrame):
        mm = pandas_migration_matrix(
            data_0, data_1, id_col, rating_col, model_col, default_col, force_square
        )
    elif isinstance(data_0, psd.DataFrame):
        mm = spark_migration_matrix(
            data_0, data_1, id_col, rating_col, model_col, default_col
        )
    else:
        raise TypeError(
            "Input data arguments 'data_0' and 'data_1' must be "
            f"either pandas or pyspark DataFrames, not {type(data_0)}"
        )
    # Cast N column as int.
    mm["N"] = mm["N"].astype(int)
    # Arrange result.
    # Collect index values.
    added_indices = ["Missing model", "Missing rating"]
    added_columns = [
        "Missing model",
        "Missing rating",
        "Defaults",
        "Other model",
        "Relationship terminated",
        "N",
    ]
    idx_order = [i for i in mm.index if i not in added_indices]
    col_order = [c for c in mm.columns if c not in added_columns]
    for add_idx in added_indices:
        if add_idx in mm.index:
            idx_order.append(add_idx)
    for add_col in added_columns:
        if add_col in mm.columns:
            col_order.append(add_col)
    return mm.loc[idx_order, col_order].copy()


def mm_summary(mig_matrix: pd.DataFrame) -> pd.DataFrame:
    """
    Summarizes a square migration matrix (rating grades to rating grades only)
    and returns a pandas.DataFrame counting the number of customers that have
    remained in the same grade, or moved up or down by one, two, or more grades
    from one period to the next.

    Args:
        mig_matrix (pandas.DataFrame): The migration matrix, specifically the
         output of the 'crv.validation.summary.migration_matrix' function.
         This function expects a pandas.DataFrame layout and column names
         to be the same as that in the output of the 'migration_matrix'
         function.

    Returns:
        (pandas.DataFrame): The summary of the square components of
         the migration matrix.

    Raises:
        None.

    Notes:
        Author: Lee MacKenzie Fischer (G01679)
    """
    # Convert the relevant part of the migration matrix to
    # a numpy.array to use matrix math.
    mm_arr = mig_matrix[mig_matrix.index].multiply(mig_matrix["N"], axis=0).to_numpy()

    # Summarize the matrix.
    d_sum = {
        ">2 Up": [sum([np.trace(mm_arr, -i) for i in range(3, mm_arr.shape[0])])],
        "2 Up": [np.trace(mm_arr, -2)],
        "1 Up": [np.trace(mm_arr, -1)],
        "Hit": [np.trace(mm_arr, 0)],
        "1 Down": [np.trace(mm_arr, 1)],
        "2 Down": [np.trace(mm_arr, 2)],
        ">2 Down": [sum([np.trace(mm_arr, i) for i in range(3, mm_arr.shape[0])])],
    }
    # Convert to a pandas.DataFrame.
    df_sum = pd.DataFrame.from_dict(
        d_sum, orient="index", columns=["Number of Obs"]
    ).astype(int)
    # Add a column for showing the values as a fraction.
    df_sum["Percent"] = df_sum["Number of Obs"] / df_sum["Number of Obs"].sum()
    return df_sum


def pandas_lgd_contingency_table(
    data: pd.DataFrame,
    pred_lgd_col: str,
    act_lgd_col: str,
    binning_type: Literal["auto", "lgd", "ecb", "manual"] = "auto",
    bins: list = None,
) -> pd.DataFrame:

    """
    Given a Pandas dataframe, creates a two way contingency table with all possible
    combinations of discretised estimated LGD and realised LGD and the observed
    frequencies for each combination for all pairs of defaulted facilities
    within the sample.

    This function is implemented as per section 3.2 of the ECB
    guideline "Annex 2 - Instructions for reporting the validation
    results of internal models", February 2019.

    Args:
        data (pandas.DataFrame): The dataframe containing the LGD data.

        pred_lgd_col (string): Column name of the estimated lgd per facility.

        act_lgd_col (string): Column name of the realised lgd per facility.

        binning_type (string): Indicates the binning methods.
            Options:
                'auto': (Default) If the model is based on 20 facility pools
                    or less, estimated and realised LGD values are discretised
                    on the basis of the estimated LGD for those facility pools.
                    (similar to option 'lgd')

                    If the model is continuous or based on more than 20
                    facility pools, an ordinal segmentation of LGD is applied
                    using the ECB segments. (similar to option 'ecb')

                'lgd': Estimated LGD is clustered on the basis of the LGD
                    estimates for facility pools and ordered from low to high.
                    Realised LGD values are then discretised on the basis of
                    the estimated LGD for those facility pools and ordered from
                    low to high as well.

                    The first class of realised LGD consists of all facilities
                    with realised LGD that is smaller than or equal to the
                    smallest estimated LGD; the second class consists of all
                    facilities with realised LGD that is smaller than or equal
                    to the second smallest estimated LGD which are not already
                    part of the first class, and so on. The last class of
                    realised LGD consists of all facilities with realised LGD
                    that is greater than the greatest estimated LGD.

                'ecb': Ordinal segmentation of estimated and realised LGD is
                    applied using the ECB segments:
                    [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, >1]
                    See (LEICode_LGD_ModelID_EndOfObservationPeriod_versionNumber.xlsx)

                'manual': Option to specify your own bins. If this option is
                    selected, you must provide a list with bins in argument
                    'bins'.
            Note: Realised LGD values < 0 will be added to the first bin. E.g.
                For the ECB binning case, this negative realised LGD value will
                be discretised to bin (0, 0.05]

        bins (list): (Default=None). List with bins on which the estimated
            and realised LGD will be discretised. Note: values specified in the
            list will be the rightmost edge of the bin and must be equal to
            or greater than zero.

    Returns:
        (pandas.DataFrame): The two way contingency table with all possible
            combinations of discretised estimated LGD and realised LGD and the
            observed frequencies for each combination for all pairs of
            defaulted facilities within the sample.

    Raises:
        ValueError - binning_type is "manual" and bins is not a list
            containing at least one element >= 0.

        ValueError - when binning_type is not one of the following options:
            [auto, lgd, ecb, manual]

    Examples:
        Call function like this from Python for binning_type = 'auto'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'auto')

        Call function like this from Python for binning_type = 'ecb'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'ecb')

        Call function like this from Python for binning_type = 'lgd'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'lgd')

        Call function like this from Python for binning_type = 'manual'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'manual', bins=[0.25, 0.5, 0.75, 1])

    Author:
        Reinout Kool <G85538>
    """
    # ValueError
    if binning_type == "manual":
        if not isinstance(bins, list) or not len(bins) > 0 or min(bins) < 0:
            raise ValueError(
                "If binning_type = 'manual', you must specify a "
                "list with bins equal to or greater than zero on "
                "which the estimated and realised LGD will be "
                "discretised. For example: "
                "lgd_matrix = lgd_pool_estimate_summary(data, "
                "'lgd_estimate', 'LGD', 'manual', "
                "bins=[0.25, 0.5, 0.75, 1])"
            )

    if binning_type not in ["auto", "lgd", "ecb", "manual"]:
        raise ValueError(
            "'binning_type' must be one of the options: " "[auto, lgd, ecb, manual]"
        )

    # Extract data
    df = data[[pred_lgd_col, act_lgd_col]].copy()

    # Creating the bins and labels
    lgd_pools = sorted(df[pred_lgd_col].unique())

    pred_min = df[[act_lgd_col, pred_lgd_col]].min().min()
    pred_max = df[[act_lgd_col, pred_lgd_col]].max().max()

    if binning_type == "auto" and len(lgd_pools) <= 20:
        # If less than or equal to 20 lgd pools, use lgd estimates as bins
        input_bins = [round(i, 3) for i in lgd_pools]
        bins, labels = _create_bins_labels(
            df[act_lgd_col],
            input_bins,
            right=True,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    elif binning_type == "auto" and len(lgd_pools) > 20:
        # Use ECB bins
        input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        bins, labels = _create_bins_labels(
            df[act_lgd_col],
            input_bins,
            right=False,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    elif binning_type == "ecb":
        input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        bins, labels = _create_bins_labels(
            df[act_lgd_col],
            input_bins,
            right=False,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    elif binning_type == "lgd":
        input_bins = [round(i, 3) for i in lgd_pools]
        bins, labels = _create_bins_labels(
            df[act_lgd_col],
            input_bins,
            right=True,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    elif binning_type == "manual":
        bins, labels = _create_bins_labels(
            df[act_lgd_col], bins, right=False, pred_min=pred_min, pred_max=pred_max
        )

    # Change the last label name
    labels[-1] = ">" + str(bins[-2]) if binning_type == "lgd" else ">=" + str(bins[-2])

    # Discretise the predicted and realised LGD into bins using pd.cut
    if binning_type == "auto" and len(lgd_pools) <= 20 or binning_type == "lgd":
        df["pred_lgd_binned"] = df[pred_lgd_col]
        df["act_lgd_binned"] = pd.cut(
            df[act_lgd_col], bins, labels=labels, include_lowest=True, duplicates="drop"
        )
    else:
        df["pred_lgd_binned"] = pd.cut(
            df[pred_lgd_col],
            bins,
            labels=labels,
            include_lowest=True,
            duplicates="drop",
            right=False,
        )
        df["act_lgd_binned"] = pd.cut(
            df[act_lgd_col],
            bins,
            labels=labels,
            include_lowest=True,
            duplicates="drop",
            right=False,
        )

    # Create contingency frequency matrix
    df1 = df[["act_lgd_binned", "pred_lgd_binned", act_lgd_col]]
    freq_mat = (
        df1.groupby(["act_lgd_binned", "pred_lgd_binned"]).count().unstack(level=0)
    )

    freq_mat = freq_mat.fillna(0).apply(np.int64)
    freq_mat.columns = freq_mat.columns.get_level_values(1)

    return freq_mat


def spark_lgd_contingency_table(
    data: psd.DataFrame,
    pred_lgd_col: str,
    act_lgd_col: str,
    binning_type: Literal["auto", "lgd", "ecb", "manual"] = "auto",
    bins: list = None,
) -> pd.DataFrame:
    """
    Given a PySpark dataframe, creates a two way contingency table with all possible
    combinations of discretised estimated LGD and realised LGD and the observed
    frequencies for each combination for all pairs of defaulted facilities
    within the sample.

    This function is implemented as per section 3.2 of the ECB
    guideline "Annex 2 - Instructions for reporting the validation
    results of internal models", February 2019.

    Args:
        data (pyspark.sql.DataFrame): Pyspark dataframe containing the LGD data.

        pred_lgd_col (string): Column name of the estimated lgd per facility.

        act_lgd_col (string): Column name of the realised lgd per facility.

        binning_type (string): Indicates the binning methods.
            Options:
                'auto': (Default) If the model is based on 20 facility pools
                    or less, estimated and realised LGD values are discretised
                    on the basis of the estimated LGD for those facility pools.
                    (similar to option 'lgd')

                    If the model is continuous or based on more than 20
                    facility pools, an ordinal segmentation of LGD is applied
                    using the ECB segments. (similar to option 'ecb')

                'lgd': Estimated LGD is clustered on the basis of the LGD
                    estimates for facility pools and ordered from low to high.
                    Realised LGD values are then discretised on the basis of
                    the estimated LGD for those facility pools and ordered from
                    low to high as well.

                    The first class of realised LGD consists of all facilities
                    with realised LGD that is smaller than or equal to the
                    smallest estimated LGD; the second class consists of all
                    facilities with realised LGD that is smaller than or equal
                    to the second smallest estimated LGD which are not already
                    part of the first class, and so on. The last class of
                    realised LGD consists of all facilities with realised LGD
                    that is greater than the greatest estimated LGD.

                'ecb': Ordinal segmentation of estimated and realised LGD is
                    applied using the ECB segments:
                    [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, >1]
                    See (LEICode_LGD_ModelID_EndOfObservationPeriod_versionNumber.xlsx)

                'manual': Option to specify your own bins. If this option is
                    selected, you must provide a list with bins in argument
                    'bins'.
            Note: Realised LGD values < 0 will be added to the first bin. E.g.
                For the ECB binning case, this negative realised LGD value will
                be discretised to bin (0, 0.054]

        bins (list): (Default=None). List with bins on which the estimated
            and realised LGD will be discretised. Note: values specified in the
            list will be the rightmost edge of the bin and must be equal to
            or greater than zero.

    Returns:
        (pandas.DataFrame): The two way contingency table with all possible
            combinations of discretised estimated LGD and realised LGD and the
            observed frequencies for each combination for all pairs of
            defaulted facilities within the sample.

    Raises:
        ValueError - binning_type is "manual" and bins is not a list
            containing at least one element >= 0.

        ValueError - when binning_type is not one of the following options:
            [auto, lgd, ecb, manual]

    Examples:
        Call function like this from Python for binning_type = 'auto'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'auto')

        Call function like this from Python for binning_type = 'ecb'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'ecb')

        Call function like this from Python for binning_type = 'lgd'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'lgd')

        Call function like this from Python for binning_type = 'manual'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'manual', bins=[0.25, 0.5, 0.75, 1])

    Author:
        Reinout Kool <G85538>
    """
    # ValueError
    if binning_type == "manual":
        if not isinstance(bins, list) or not len(bins) > 0 or min(bins) < 0:
            raise ValueError(
                "If binning_type = 'manual', you must specify a "
                "list with bins equal to or greater than zero on "
                "which the estimated and realised LGD will be "
                "discretised. For example: "
                "lgd_matrix = lgd_pool_estimate_summary(data, "
                "'lgd_estimate', 'LGD', 'manual', "
                "bins=[0.25, 0.5, 0.75, 1])"
            )

    if binning_type not in ["auto", "lgd", "ecb", "manual"]:
        raise ValueError(
            "'binning_type' must be one of the options: " "[auto, lgd, ecb, manual]"
        )

    # Determine minimum and maximum
    act_lgd_min = data.agg({act_lgd_col: "min"}).collect()[0][0]
    pred_lgd_min = data.agg({pred_lgd_col: "min"}).collect()[0][0]
    pred_min = min(act_lgd_min, pred_lgd_min)
    act_lgd_max = data.agg({act_lgd_col: "max"}).collect()[0][0]
    pred_lgd_max = data.agg({pred_lgd_col: "max"}).collect()[0][0]
    pred_max = max(act_lgd_max, pred_lgd_max)

    # Determine binning_type if "auto" was selected
    lgd_pools = sorted(
        [i[pred_lgd_col] for i in data.select(pred_lgd_col).distinct().collect()]
    )
    if binning_type == "auto" and len(lgd_pools) <= 20:
        binning_type = "lgd"
    elif binning_type == "auto" and len(lgd_pools) > 20:
        binning_type = "ecb"

    # Create bins and labels
    if binning_type == "lgd":
        input_bins = [round(i, 3) for i in lgd_pools]
        bins, labels = _create_bins_labels(
            data.select(pred_lgd_col),
            input_bins,
            right=True,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    elif binning_type == "ecb":
        input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        bins, labels = _create_bins_labels(
            data.select(pred_lgd_col),
            input_bins,
            right=False,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    elif binning_type == "manual":
        input_bins = sorted(bins)
        bins, labels = _create_bins_labels(
            data.select(pred_lgd_col),
            bins,
            right=False,
            pred_min=pred_min,
            pred_max=pred_max,
        )

    # Discretise the realised LGD into bins
    bucketizer = Bucketizer(
        splits=bins + [float("Inf")], inputCol=act_lgd_col, outputCol="buckets"
    )
    df_buck = bucketizer.setHandleInvalid("keep").transform(data)

    # Create contingency table
    if binning_type == "ecb" or binning_type == "manual":
        # Discretise the estimated LGD into bins
        output_col = pred_lgd_col + "_class"
        bucketizer2 = Bucketizer(
            splits=bins + [float("Inf")], inputCol=pred_lgd_col, outputCol=output_col
        )
        df_buck = bucketizer2.setHandleInvalid("keep").transform(df_buck)

        # Create contingency table
        freq_mat = df_buck.crosstab(output_col, "buckets").toPandas()
        bucket_col = output_col + "_buckets"

        # Add missing rows (with zero values)
        current_rows = [int(float(i)) for i in freq_mat[bucket_col].tolist()]
        required_rows = [i for i in range(len(labels))]
        missing_rows = np.setdiff1d(required_rows, current_rows)

        for index in missing_rows:
            freq_mat.loc[len(freq_mat)] = 0
            freq_mat.at[len(freq_mat) - 1, bucket_col] = index

        # Sort rows
        freq_mat[bucket_col] = pd.to_numeric(freq_mat[bucket_col])
        freq_mat = freq_mat.sort_values(by=[bucket_col])

        # Provide labels to rows and set as index
        freq_mat[bucket_col] = labels
        freq_mat = freq_mat.rename(
            columns={pred_lgd_col + "_class_buckets": "pred_lgd_binned"}
        )
        freq_mat = freq_mat.set_index("pred_lgd_binned")

    elif binning_type == "lgd":
        # Create contingency table
        freq_mat = df_buck.crosstab(pred_lgd_col, "buckets").toPandas()
        freq_mat = freq_mat.rename(
            columns={pred_lgd_col + "_buckets": "pred_lgd_binned"}
        )
        freq_mat = freq_mat.set_index("pred_lgd_binned")
        freq_mat = freq_mat.sort_index(axis=0)

    # Add missing rows (and fill with zero values)
    freq_mat.columns = [labels[int(float(i))] for i in freq_mat.columns.tolist()]
    for label in labels:
        if label not in freq_mat.columns:
            freq_mat[label] = 0

    # Sort columns,  change last column name and columsn title
    freq_mat = freq_mat[labels]
    last_label = ">" + str(bins[-2]) if binning_type == "lgd" else ">=" + str(bins[-2])
    freq_mat = freq_mat.rename(columns={labels[-1]: last_label})
    freq_mat.columns.name = "act_lgd_binned"

    return freq_mat


def lgd_contingency_table(
    data: Union[pd.DataFrame, psd.DataFrame],
    pred_lgd_col: str,
    act_lgd_col: str,
    binning_type: Literal["auto", "lgd", "ecb", "manual"] = "auto",
    bins: list = None,
) -> pd.DataFrame:
    """
    Given a DataFrame, calculates the actual default frequency (ADF) for
    the specified grouping columns (if specified). Sums (dictated by sum
    columns) are also calcuated per the grouping columns.

    This top-level function accepts either pandas.DataFrames or
    pyspark.sql.DataFrames.

    Args:
        data (pandas.DataFrame, pyspark.sql.DataFrame): The data to summarize.

        pred_lgd_col (string): Column name of the estimated lgd per facility.

        act_lgd_col (string): Column name of the realised lgd per facility.

        binning_type (string): Indicates the binning methods.
            Options:
                'auto': (Default) If the model is based on 20 facility pools
                    or less, estimated and realised LGD values are discretised
                    on the basis of the estimated LGD for those facility pools.
                    (similar to option 'lgd')

                    If the model is continuous or based on more than 20
                    facility pools, an ordinal segmentation of LGD is applied
                    using the ECB segments. (similar to option 'ecb')

                'lgd': Estimated LGD is clustered on the basis of the LGD
                    estimates for facility pools and ordered from low to high.
                    Realised LGD values are then discretised on the basis of
                    the estimated LGD for those facility pools and ordered from
                    low to high as well.

                    The first class of realised LGD consists of all facilities
                    with realised LGD that is smaller than or equal to the
                    smallest estimated LGD; the second class consists of all
                    facilities with realised LGD that is smaller than or equal
                    to the second smallest estimated LGD which are not already
                    part of the first class, and so on. The last class of
                    realised LGD consists of all facilities with realised LGD
                    that is greater than the greatest estimated LGD.

                'ecb': Ordinal segmentation of estimated and realised LGD is
                    applied using the ECB segments:
                    [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, >1]
                    See (LEICode_LGD_ModelID_EndOfObservationPeriod_versionNumber.xlsx)

                'manual': Option to specify your own bins. If this option is
                    selected, you must provide a list with bins in argument
                    'bins'.
            Note: Realised LGD values < 0 will be added to the first bin. E.g.
                For the ECB binning case, this negative realised LGD value will
                be discretised to bin (0, 0.054]

        bins (list): (Default=None). List with bins on which the estimated
            and realised LGD will be discretised. Note: values specified in the
            list will be the rightmost edge of the bin and must be equal to
            or greater than zero.

    Returns:
        (pandas.DataFrame): The two way contingency table with all possible
            combinations of discretised estimated LGD and realised LGD and the
            observed frequencies for each combination for all pairs of
            defaulted facilities within the sample.

    Raises:
        ValueError - If the input table 'data' is not a pandas or pyspark DataFrame.

    Examples:
        Call function like this from Python for binning_type = 'auto'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'auto')

        Call function like this from Python for binning_type = 'ecb'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'ecb')

        Call function like this from Python for binning_type = 'lgd'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'lgd')

        Call function like this from Python for binning_type = 'manual'::

            lgd_matrix = lgd_pool_estimate_summary(data, 'lgd_estimate', 'LGD',
                              'manual', bins=[0.25, 0.5, 0.75, 1])

    Author:
        Reinout Kool <G85538>)
    """
    # Direct arguments to summary functions. Raise error if incorrect type found.
    if isinstance(data, pd.DataFrame):
        return pandas_lgd_contingency_table(
            data, pred_lgd_col, act_lgd_col, binning_type=binning_type, bins=bins
        )
    elif isinstance(data, psd.DataFrame):
        return spark_lgd_contingency_table(
            data, pred_lgd_col, act_lgd_col, binning_type=binning_type, bins=bins
        )
    else:
        raise TypeError(
            f"Argument 'df' must be either a pandas or a pyspark DataFrame, not {type(data)}."
        )
