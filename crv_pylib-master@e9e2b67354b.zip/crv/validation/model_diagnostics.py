"""
############
Introduction
############
This module contains functions related to models diagostics to evaluate model assumptions and the 
structure of the model.

Diagnostic functions
====================
* **VIF** - This function detects multicollinearity in regression analysis. Multicollinearity 
    is when there’s correlation between predictors (i.e. independent variables) in a model. it’s 
    presence can adversely affect the regression results. The VIF estimates how much the variance 
    of a regression coefficient is inflated due to multicollinearity in the model. 

* **Cook's distance** - This function (often referred to as Cook’s D) is a common measurement of 
    a data point’s influence. It’s a way to find influential outliers in a set of predictor 
    variables when performing a least-squares regression analysis.

* **Glejser test** - A common test for heteroscedasticity. Regresses on the linear regression residuals
    and tests if the slope coefficient is significantly different from zero. Note that this test is not
    asymptotically valid under asymmetric disturbances.

Notes
=====
Author: Adam Szpilewicz <M016673>

##############
Implementation
##############
"""

import numpy as np
import pandas as pd
import pyspark.sql.dataframe as psd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
from typing import List, Union
import warnings

__all__ = ["vif", "cooks_distance", "glejser_test"]


def vif(df: pd.DataFrame, vif_columns: List[str]) -> pd.DataFrame:
    """
    Function calculates variance inflation factor, VIF for columns from passed
     data frame 'df' and with the names included in the list 'vif_columns'.

    References:
        https://en.wikipedia.org/wiki/Variance_inflation_factor

    Args:
        df (pandas.DataFrame): Input table. It must be non-empty.

        vif_columns (list of strings): List with the name of columns from 'df'
            for which VIF should be calculated (features).

    Returns:
        (padnas.DataFrame): A table with two columns (first with the name of feature
        and seond with the VIF values)

    Raises:
        TypeError: if df is not of type pandas.DataFrame

        TypeError: if vif_columns is not of type list

        ValueError: if any of the following: NaN, inf, None passed in 'df'

        ValueError: if one or more names from vif_columns not present in df.columns

    Examples:
        Call function in Python like this::

            vif = vif(df=X, vif_columns=["feature_01", "feature_02"])

    Notes:
        Author: Adam Szpilewicz (M016673), Lee MacKenzie Fischer (G01679)
    """
    # Check for correct input data type
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a type of pandas.DataFrame")
    if not np.isfinite(df.to_numpy()).all():
        raise ValueError(
            "Data passed to argument 'df' may not contain any of the following: NaN, inf, None"
        )
    if not isinstance(vif_columns, list):
        raise TypeError("vif_columns must be a type of list")
    if not all(name in df.columns for name in vif_columns):
        raise ValueError(
            "names from list passed as 'vif_columns' have to be present"
            " in 'df' column names"
        )

    X = df.copy()[vif_columns]
    # adding intercept as it is needed for the proper VIF calculation. For details
    # please check:
    # 1. https://stackoverflow.com/questions/42658379/variance-inflation-factor-in-python
    # 2. https://github.com/statsmodels/statsmodels/issues/2376
    X["intercept"] = 1

    # VIF dataframe
    vif_data = pd.DataFrame()
    vif_data["feature"] = X.columns

    # calculating VIF for each feature
    vif_data["VIF"] = [
        variance_inflation_factor(X.values, i) for i in range(len(X.columns))
    ]
    vif_data = vif_data.loc[vif_data["feature"] != "intercept"]
    return vif_data


def cooks_distance(y: Union[pd.DataFrame, pd.Series], X: pd.DataFrame) -> pd.DataFrame:
    """
    Function calculates cooks' distance and corresponding p-value for each
    observation passed in the argument 'X'.

    References:
        https://en.wikipedia.org/wiki/Cook%27s_distance

    Args:
        y (pandas.DataFrame or pandas.Series): Input table containing the values of
         dependent variable (outcome variable). It must be non-empty.

        X (pandas.DataFrame or pandas.Series): Input table containing the values of
         independent variables, where each column contains the values of one feature.
         It must be non-empty.

    Returns:
        (pandas.DataFrame): A table with two columns (first with the values of
         cooks' distance and the second with the corresponding p-value)

    Raises:
        TypeError: if 'y' is not of type pandas.DataFrame or not pandas.Series

        TypeError: if 'X' is not of type pandas.DataFrame or not pandas.Series

        TypeError: if 'y' is not of type numeric

        TypeError: if 'X' is not of type numeric

        ValueError: if any of the following: NaN, inf, None passed in 'y'

        ValueError: if any of the following: NaN, inf, None passed in 'x'

    Examples:
        Call function in Python like this::

            cooks_distance = cooks_distance(y=y, X=X)

    Notes:
        Author: Adam Szpilewicz (M016673)
    """
    if isinstance(y, pd.Series):
        y = pd.DataFrame(y.copy())
    if isinstance(X, pd.Series):
        X = pd.DataFrame(X.copy())
    if not isinstance(y, pd.DataFrame) and not isinstance(y, pd.Series):
        raise TypeError(
            "The value passed to argument 'y' must be a type of pandas.DataFrame"
            " or pandas.Series."
        )
    if not isinstance(X, pd.DataFrame) and not isinstance(X, pd.Series):
        raise TypeError(
            "The value passed to argument 'X' must be a type of pandas.DataFrame"
            " or pandas.Series"
        )
    # Check if all vakues are type of numeric
    is_numeric_X = all(
        [pd.to_numeric(X[col], errors="coerce").notnull().all() for col in X.columns]
    )
    if not is_numeric_X:
        raise TypeError(
            "Data passed to argument 'X' has to be type of numeric and "
            "cannot contains NaN, inf, None"
        )
    is_numeric_y = all(
        [pd.to_numeric(y[col], errors="coerce").notnull().all() for col in y.columns]
    )
    if not is_numeric_y:
        raise TypeError(
            "Data passed to argument 'y' has to be type of numeric and "
            "cannot contains NaN, inf, None"
        )
    if not np.isfinite(y.to_numpy()).all():
        raise ValueError(
            "Data passed to argument 'y' may not contain any of the following: NaN, inf, None"
        )
    if not np.isfinite(X.to_numpy()).all():
        raise ValueError(
            "Data passed to argument 'X' may not contain any of the following: NaN, inf, None"
        )

    y = y.copy().to_numpy()
    X = X.copy().to_numpy()
    X_with_constant = sm.add_constant(X)
    reg_model = sm.OLS(y, X_with_constant).fit()
    cooks_values, p_value = reg_model.get_influence().cooks_distance
    results = pd.DataFrame({"cooks_distance": cooks_values, "p-value": p_value})
    return results


def glejser_test(
    data: pd.DataFrame, y_col: str, x_cols: Union[str, List], alpha: float = 0.05
) -> pd.DataFrame:
    """
    Tests the variables in the passed DataFrame for heteroscedasticity. Note that this
    test is only valid under conditional symmetry.

    For each X column, a linear regression is performed the the X-Y combination. The
    absolute value of these residuals are then regressed against 4 transformations
    of the X variable. The best fit (highest R^2) is chosen and a T-distribution is
    used to evaluate if the slope coefficient is significanly non-zero, signifying
    a "strong" or "weak" heteroscedasticity, or none at all.

    References:
        1. https://en.wikipedia.org/wiki/Glejser_test
        2. Model Testing Framework v2.5

    Args:
        data (pandas.DataFrame): The data to be tested.

        y_col (str): The name of the column of the dependent variable.

        x_cols (str, list): The name or names of the independent variables.

        alpha (float): Significance level for T-test, between 0 and 1. Default is 0.05.

    Returns:
        (pandas.DataFrame): For each X column, returns the T-statistic and
         heteroscedasticity evaluation as one of the following: "strongly heteroscedastic",
         "mildly heteroscedastic", "not heteroscedastic".

    Raises:
        NotImplementedError - If a pyspark.DataFrame is passed to 'data'

        TypeError - If the variable passed to the 'data' argument is not a pandas.DataFrame

        TypeError - If the variable passed to 'y_col' is not a string

        TypeError - If the variable passed to 'x_cols' is not a string or list

        ValueError - If the variable passed to 'alpha' is not between 0 and 1

    Examples:
        Call function in Python like this::

            glejser_results = glejser_test(data=df, y_col='PRICE', x_cols=['SIZE_SQM', 'DIST'])

    Author: Lee MacKenzie Fischer (G01679)
    """
    # Error checks.
    if not isinstance(y_col, str):
        raise TypeError(
            f"Value passed to argument 'y_col' must be of type: str. Received type: {type(y_col)}"
        )
    if not isinstance(x_cols, (str, list)):
        raise TypeError(
            f"Value passed to argument 'x_cols' must be of type: str, list. Received type: {type(x_cols)}"
        )
    if (alpha < 0) | (alpha > 1):
        raise ValueError(
            f"Value passed to argument 'alpha' must be between 0 and 1, inclusive."
        )
    if isinstance(data, pd.DataFrame):
        return _glejser_test_pandas(data, y_col, x_cols, alpha)
    elif isinstance(data, psd.DataFrame):
        raise NotImplementedError(
            "Glejser test support for pyspark.DataFrame input type is not yet implemented."
        )
    else:
        raise TypeError(
            f"Value passed to argument 'data' must be of type: pandas.DataFrame. Received type: {type(data)}"
        )


def _single_glejser_pandas(x: np.ndarray, y: np.ndarray, alpha: float = 0.05) -> List:
    """
    Glejser test for single X-Y pair. Calculates residuals and applies transforms
    to the x-variables, chooses the best auxillary fit, applies a t-test to the
    coefficient, and evaluates the result and assigns result text. Transformations
    applied are: x, log(x), exp(x), 1/x.

    Execution of this test is a combination of the Wikipedia definition
    (https://en.wikipedia.org/wiki/Glejser_test) for method, and the Model
    Tesitng Framework v2.5 for evaluation metrics.

    Args:
        x (numpy.ndarray): 1-D array of X values.

        y (numpy.ndarray): 1-D array of Y values.

        alpha (float):  Significance level for T-test, between 0 and 1. Default is 0.05.

    Returns:
        (list): Result array consisting of R^2, P-value, T-statistic,
         and text indicative of the evaluation.

    Raises:
        UserWarning - If an x-transformation is skipped due to an infiinte
         value being found.

    Author: Lee MacKenzie Fischer (G01679)
    """
    alpha2 = alpha / 2
    num_obs = max(y.shape)
    results = []
    residuals = sm.OLS(y, sm.add_constant(x), missing="drop").fit().resid

    # X transformations.
    x_log = np.log(x)
    x_exp = np.exp(x)
    x_inv = np.reciprocal(x)
    x_transforms = [x, x_log, x_exp, x_inv]
    x_func_labels = ["f(x) = x", "f(x) = log(x)", "f(x) = exp(x)", "f(x) = 1/x"]

    for i, xn in enumerate(x_transforms):
        if np.isinf(xn).any():
            warnings.warn(
                f"Transformation skipped due to 'inf' found: {x_func_labels[i]}",
                UserWarning,
            )
            continue
        model = sm.OLS(abs(residuals), sm.add_constant(xn), missing="drop").fit()
        # --------------------------------------------------------------------
        # Test statistic from R, compared to chi2 distribution.
        # Not used here due to conflict with Model Testing Framework v2.5.
        # aux_residuals = model.resid
        # t_stat = (
        #     sum([i ** 2 for i in abs(residuals)])
        #     - num_obs * np.mean(abs(residuals)) ** 2
        #     - sum([i ** 2 for i in aux_residuals])
        # ) / ((1 / num_obs) * sum([i ** 2 for i in abs(residuals)]) * (1 - 2 / np.pi))
        # --------------------------------------------------------------------
        results.append((model.rsquared, model.pvalues[1], model.tvalues[1]))

    results = np.array(results)
    i_test = results[:, 0].argmax()
    top_result = list(results[i_test].copy())

    # Comparing the T-statistic to quantiles for evaluation.
    Q_outer = abs(stats.t.ppf(alpha2 / 2, num_obs - 2))
    Q_inner = abs(stats.t.ppf(alpha / 2, num_obs - 2))
    top_result.append((round(Q_inner, 3), round(Q_outer, 3)))

    if abs(top_result[2]) > Q_outer:
        top_result.append(f"Strongly heteroscedastic")
    elif abs(top_result[2]) >= Q_inner:
        top_result.append(f"Weakly heteroscedastic")
    else:
        top_result.append(f"Not heteroscedastic")

    return top_result


def _glejser_test_pandas(
    data: pd.DataFrame, y_col: str, x_cols: Union[str, List], alpha: float = 0.05
) -> pd.DataFrame:
    """
    Glejser test for all specified columns in a pandas.DataFrame.

    Args:
        data (pandas.DataFrame): The data to be tested.

        y_col (str): The name of the column of the dependent variable.

        x_cols (str, list): The name or names of the independent variables.

        alpha (float): Significance level for T-test, between 0 and 1. Default is 0.05.

    Returns:
        (pandas.DataFrame): For each X column, returns the T-statistic and
         heteroscedasticity evaluation as one of the following: "strongly heteroscedastic",
         "mildly heteroscedastic", "not heteroscedastic".

    Author: Lee MacKenzie Fischer (G01679)
    """
    if isinstance(x_cols, str):
        x_cols = [x_cols]
    d_results = {
        "Feature": [],
        "P-value": [],
        "T-statistic": [],
        "T-distribution quantiles": [],
        "Evaluation": [],
    }
    for xc in x_cols:
        df = data[[y_col, xc]].copy()
        result_i = _single_glejser_pandas(
            df[xc].to_numpy(), df[y_col].to_numpy(), alpha
        )
        d_results["Feature"].append(xc)
        d_results["P-value"].append(result_i[1])
        d_results["T-statistic"].append(result_i[2])
        d_results["T-distribution quantiles"].append(result_i[3])
        d_results["Evaluation"].append(result_i[4])
    df_result = pd.DataFrame.from_dict(d_results)
    return df_result
