"""
############
Introduction
############
The ECB guideline "Annex 2 - Instructions for reporting the validation results of internal models" of February 2019 describe the following dimensions along which the performance of the performance of the Pillar I credit risk models can be assessed:
        
* Calibration
* Differentiation
* Stability
    
This file contains the validation tools that provide insight into the stability of Pillar I credit risk models. These validation tools can be PD, LGD, EAD/CCF model specific, but can also be PD, LGD, EAD/CCF model agnostic. 
    
Validation tools
================
This section gives an overview of the validation tools available to determine stability of the Pillar I credit risk models; categorised by PD, LGD, EAD/CCF model. 

PD
--
The analysis of stability is aimed at ensuring that the ranking of customers that results from the rating process is stable over time.

* **Stability of the migration matrix**: This function calculates the z-test statistic as well as the p-value confidence level for a given migration matrix.

* **Migration matrix weighted bandwidth**: This function calculates two statistics (MWB) in order to summarise upgrades and downgrades, i.e. respective values above and below the diagonal of the migration matrix. The objective of that statistics is to analyse the migration of customers across rating grades during the relevent observation period. 

General use
-----------
Stability tests that are not aimed at specific models or data.

* **Concentration test**: This function monitors the concentration of exposures in each rating grade. The model should be able differentiate risky customers from less riskier customers and thus to spread out the exposures on more rating grades.

* **Likelihood ratio test**: This function compares the likelihood of two models, an unrestricted model, that contains all variables in consideration, versus a restricted model, to which a constraint has been imposed (e.g. by removing variables from the unrestricted model).

* **Population stability index test**: This function computes the population stability index for a non-summarized data set. 

Warning
=======
The functions herein assume the data has been correctly processed up to this point. See other modules if data processing is needed. This implies that data has been extracted and contain the required variables. Variables required for the test should be stated in the function header.

Notes
=====
Author: N440730, G01679

###################
Test implementation
###################
"""
# Imports.
from typing import List, Optional, Union
import numpy as np
import pandas as pd
import warnings

from scipy.stats import norm, chi2
from typing_extensions import Literal

from crv.utils.validation_helper import _create_bins_labels

__all__ = [
    "concentration_test",
    "psi_test",
    "population_stability_index",
    "z_test",
    "mm_stability_test",
    "likelihood_ratio_test",
    "matrix_weighted_bandwidth",
]


def _exec_adj_conc_test(dfi: pd.DataFrame, adjacent_conc_limit: float) -> pd.DataFrame:
    """
    Execute the adjacent concentration limit test for a given DataFrame.
    A sub-function that encapsulates the calculation of the results
    for the Adjacent Concentration Limit test.

    Args:
        dfi (pandas.DataFrame): The table or slice of table.

        adjacent_conc_limit (float): The limit for the sum of adjacent ratings.

    Returns:
        (pandas.DataFrame): The input table with the concentration columns.
    """
    df = dfi.copy()
    df.loc[:, "adj_conc"] = df["Concentration"] + df["Concentration"].shift(1)

    df.loc[df["adj_conc"].notnull(), "Adjacent Concentration Limit Passed"] = (
        df.loc[df["adj_conc"].notnull(), "adj_conc"] < adjacent_conc_limit
    )
    return df


def concentration_test(
    summary_table: pd.DataFrame,
    rating_column: str,
    value_column: str,
    group_columns: List[Union[str, int]] = None,
    single_conc_limit: float = 0.3,
    adjacent_conc_limit: float = 0.5,
) -> pd.DataFrame:
    """
    Calculates the concentration of a given variable ('value_column', e.g. EAD,
    number of customers) per label ('rating_column', e.g. rating, pool).
    Additional group columns can be passed via
    'group_columns', which will calculate separate totals per those groups.

    This test is implemented as described in Section 7.6 of the CRMV
    "Model Testing Framework" v2.5 (page 49).

    Args:
        summary_table (pandas.DataFrame): A table summarized to the rating/pool
         level for concentration testing.

        rating_column (str): Column name of values of groupings (e.g. rating,
         pool, segment) to be tested. If the values are not numeric they
         should be cast as Categorical type with a specific order, since
         this function will use it for sorting.

        value_column (str): Column name of values for which concentration
         will be assessed, e.g. exposure or number of customers.

        group_columns (str, list): Column name(s) of additional groupings to
         be made for assessing concentration. Default is None which performs
         no additional groupings.

        single_conc_limit (float): The limit as a fraction of the total (or
         total per additional groups) for the concentration in any single group.
         Test will FAIL if concentration is GREATER THAN OR EQUAL TO this limit.
         Default is 0.3, as in the framework reference. Must be between 0 and 1.

        adjacent_conc_limit (float): The limit as a fraction of the total (or
         total per additional groups) for the sum of the concentration in any
         two adjecent groups. Test will FAIL if concentration is GREATER THAN
         OR EQUAL TO this limit. Default is 0.5, as in the framework reference.
         Must be between 0 and 1.

    Returns:
        (pandas.DataFrame): The summary table with the concentrations and
         pass/fail status in an additional column.

    Examples:
        Call function in Python like this::

            df_results = concentration_test(df, 'rating', 'EAD')

    Raises:
        ValueError: If the 'single_conc_limit' is not between 0 and 1.

        ValueError: If the 'adjacent_conc_limit' is not between 0 and 1.

        ValueError: If the column referred to by 'value_column' is not a
        numeric data type.
    """
    df = summary_table.copy()

    # Check for value errors.
    if (single_conc_limit > 1) | (single_conc_limit < 0):
        raise ValueError("Argument 'single_conc_limit' must be between 0 and 1.")
    if (adjacent_conc_limit > 1) | (adjacent_conc_limit < 0):
        raise ValueError("Argument 'adjacent_conc_limit' must be between 0 and 1.")
    if not pd.api.types.is_numeric_dtype(df[value_column]):
        raise ValueError(
            "Argument 'value_column' must refer to a column that "
            "is of a numeric data type."
        )

    # Convert group_columns to list if string, else None.
    group_columns = [group_columns] if isinstance(group_columns, str) else group_columns

    if group_columns:
        group_totals = df.groupby(group_columns, observed=True, as_index=False).agg(
            {value_column: "sum"}
        )
        group_totals = group_totals.rename(columns={value_column: "group_totals"})
        df = df.merge(group_totals, how="left", on=group_columns)
    else:
        group_totals = df[value_column].sum()
        df["group_totals"] = group_totals

    # Single concentration limit.
    df["Concentration"] = df[value_column] / df["group_totals"]
    df["Single Concentration Limit Passed"] = df["Concentration"] < single_conc_limit

    # Adjacent concentration limit.
    df["adj_conc"] = np.nan
    df["Adjacent Concentration Limit Passed"] = np.nan

    if group_columns:
        # Handle the concentrations of each group.
        for name, _ in df.groupby(group_columns, observed=True):
            filt = True
            if not isinstance(name, tuple):
                filt = df[group_columns[0]] == name
            else:
                for i in range(len(name)):
                    filt = filt & (df[group_columns[i]] == name[i])
            df.loc[filt] = _exec_adj_conc_test(df.loc[filt], adjacent_conc_limit)
    else:
        df = _exec_adj_conc_test(df, adjacent_conc_limit)

    return df


def _pandas_group_population(
    data: pd.DataFrame,
    population_col: str,
    binning_type: Literal["lgd", "ecb", "auto", "manual", "column"],
    binning_col: str,
    minimum_value: int = 1,
    bins: Optional[List[str]] = None,
    check_cols=None,
) -> pd.DataFrame:
    """
    Data arrangement function. Produces a matrix where the rows are defined by the
    values of the 'binning_col' and the columns are defined by the values of
    the 'population_col'.

    Args:
        data (pandas.DataFrame): Raw data table.

        population_col (str): Column name containing values by which the
         population will be grouped..

        binning_type (str): Setting options: 'lgd', 'ecb', 'auto', 'manual', 'column'.
         Binning by 'column' does grouping by a single column name, while
         the other require the LGD pool.

        binning_col (str): Column name.

        minimum_value (int): Minimum value of population count. Needed when
         the frequency of the observed value on a given population &
         binning cell is equal to zero. This is required to prevent
         divide-by-zero and logarithm errors. Default value is 1.

        bins (list, optional):   The desired bins when binning_type = "manual"

        check_cols (list): Two values indicating the two populations that are to
         be compared in the PSI test. If both columns contain zeros at the same
         row index, then that row shall be removed (according to specification).
         Values passed to this argument must be present in the 'population_col'.

    Returns:
        (pandas.DataFrame): Grouped population data.

    Raises:
        ValueError - If the value passed to 'minimum_value' is zero or less.

        ValueError - If the binning type is not one of: 'lgd', 'ecb',
         'auto', 'manual', 'column'.

        ValueError - If not exactly 2 values are passed to the 'check_cols'
         argument.

        Warning - If a zero value (or less) is found at the same row index for
         both of the 'check_cols'.

        Warning - If a value of zero or less is found anywhere in the
         grouped DataFrame, but it is not an instance of values of zero
         or less appearing in the same row of the populations described in
         the 'check_cols' argument.

    Notes:
        Author: Lee MacKenzie Fischer (G01679)
    """
    # Initial checks.
    # Raises error if 'minimum_value' is zero or less.
    if minimum_value <= 0.0:
        raise ValueError(
            "Value for the argument 'minimum_value' must be " "greater than zero (0)."
        )

    # Build population list.
    population_list = list(data[population_col].unique())

    if binning_type in ["lgd", "ecb", "auto", "manual"]:
        # Build bin intervals for grouping.
        val_pools = sorted(data[binning_col].unique())

        if binning_type == "auto":
            if len(val_pools) <= 20:
                # If less than or equal to 20 lgd pools, use lgd estimates as bins
                binning_type = "lgd"
            else:
                # Use ECB bins
                binning_type = "ecb"

        if binning_type == "ecb":
            input_bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
            bins, labels = _create_bins_labels(data[binning_col], input_bins)
            index_labels = labels.copy()
            index_labels[-1] = ">= 1"
            labels[-1] = pd.Interval(left=labels[-1].left, right=np.inf)

        elif binning_type == "lgd":
            input_bins = [round(i, 3) for i in val_pools]
            bins, labels = _create_bins_labels(data[binning_col], input_bins)
            if (0 not in val_pools) and (min(val_pools) > 0):
                index_labels = bins[1:-1]
                labels = labels[1:]
            else:
                index_labels = bins[:-1]

        elif binning_type == "manual":
            bins, labels = _create_bins_labels(data[binning_col], sorted(bins))
            index_labels = labels.copy()
            index_labels[-1] = ">= " + str(bins[-2])
            labels[-1] = pd.Interval(left=labels[-1].left, right=np.inf)

        # Group data.
        d_grouped = {pop_i: [] for pop_i in population_list}
        for row_idx in labels:
            for pop_i in d_grouped.keys():
                data_mask = (
                    (data[population_col] == pop_i)
                    & (data[binning_col] >= row_idx.left)
                    & (data[binning_col] < row_idx.right)
                )
                d_grouped[pop_i].append(len(data[data_mask]))

    elif binning_type is "column":
        # Build index labels.
        index_labels = list(data[binning_col].unique())

        # Group data.
        d_grouped = {pop_i: [] for pop_i in population_list}
        for row_idx in index_labels:
            for pop_i in d_grouped.keys():
                data_mask = (data[population_col] == pop_i) & (
                    data[binning_col] == row_idx
                )
                d_grouped[pop_i].append(len(data[data_mask]))

    else:
        raise ValueError(
            "Argument 'binning_type' must be one of: "
            "'lgd', 'ecb', 'auto', 'manual', 'column'"
        )

    # Convert grouped dictionary to pandas.DataFrame.
    grouped_data = pd.DataFrame.from_dict(d_grouped)
    grouped_data.index = index_labels

    # Check for coinciding zeros in each row of
    # the 'check_cols'.
    if isinstance(check_cols, list) or isinstance(check_cols, tuple):
        if len(check_cols) != 2:
            raise ValueError("Argument 'check_cols' must contain exactly 2 values.")
        if (
            (grouped_data[check_cols[0]] <= 0) & (grouped_data[check_cols[1]] <= 0)
        ).any():
            remove_indices = grouped_data[
                (grouped_data[check_cols[0]] <= 0) & (grouped_data[check_cols[1]] <= 0)
            ].index.tolist()
            warnings.warn(
                "Coinciding values of zero or less have been found at "
                f"the following indices: {remove_indices}.\nThese indices have been dropped."
            )
            grouped_data = grouped_data.drop(labels=remove_indices, axis=0)

    # Replace zeros with minimum_value and
    # calculate population proportions.
    if (grouped_data <= 0).any().any():
        warnings.warn(
            "Values of zero of less have been found in summarized table. "
            "All values of zero or less will be replaced with the 'minimum_value'."
        )
        grouped_data[grouped_data <= 0] = minimum_value

    # Convert counts to proportions (summing to 1).
    grouped_data = grouped_data / grouped_data.sum()

    return grouped_data


def psi_test(grouped_table: pd.DataFrame, pop_col_1: str, pop_col_2: str) -> float:
    """
    The population stability index (PSI) test to be executed
    on summarized data. The input data table must be grouped, with
    each date column containing the population proportion and
    summing to 1.

    The PSI algorithm is implemented as per pages 36 and 58 of the
    ECB guideline document "Annex 2: Instructions for reporting the validation
    results of internal models. IRB Pillar I models for credit risk".

    grouped_table (pandas.DataFrame): Data table with row indices
     describing groups (e.g. LGD pools, industries), and two columns
     indicating two different time periods.

    pop_col_1 (str): Name of column containing the population proportions
     for the first population group.

    pop_col_2 (str): Name of column containing the population proportions
     for the second population group.

    Returns:
        (float): The population stability index.

    Raises:
        ValueError - If any of the columns does not sum to 1.0.

        ValueError - If a value of 0 is found in any of the table cells.

    Notes:
        Author: Lee MacKenzie Fischer (G01679)
    """

    for col in [pop_col_1, pop_col_2]:
        # Check that the sum of each col is 1.
        if round(sum(grouped_table[col]), 5) != 1.0:
            raise ValueError(
                f"Population proportions in column '{col}' must sum to 1.0"
            )
        if (grouped_table[col] == 0).any():
            raise ValueError(
                f"No cells in the input data may contain a value of '0'. A zero value was found in column '{col}'"
            )

    # Calculate index.
    pop_1 = grouped_table[pop_col_1]
    pop_2 = grouped_table[pop_col_2]
    psi = sum((pop_2 - pop_1) * np.log(pop_2 / pop_1))
    return psi


def population_stability_index(
    data: pd.DataFrame,
    population_col: str,
    population_1: str,
    population_2: str,
    binning_type: Literal["lgd", "ecb", "auto", "manual", "column"],
    binning_col: str,
    minimum_value: int = 1,
    bins: Optional[List["str"]] = None,
) -> float:
    """
    Top-level function for calculating the population stability index (PSI)
    from data that has not been summarized.

    The PSI algorithm is implemented as per pages 36 and 58 of the
    ECB guideline document "Annex 2: Instructions for reporting the validation
    results of internal models. IRB Pillar I models for credit risk".

    Args:
        data (pandas.DataFrame): Raw data table. The table must contain a column
         labelling the populations, as well as either LGD values by which to bin, or
         another column for grouping and splitting the population.

        population_col (str): Column name containing population labels by which
         to group.

        population_1 (*): The first population label which will be used to calculate
         the PSI. This value may be a string, float, int or other data type, but
         must be found within the 'population_col' column.

        population_2 (*): The second population label which will be used to calculate
         the PSI. This value may be a string, float, int or other data type, but
         must be found within the 'population_col' column.

        binning_type (str): Setting options: 'lgd', 'ecb', 'auto', 'manual', 'column'.
         Binning by 'column' does grouping by a single column name, while
         the other require the LGD pool.

        binning_col (str): Column name which will be used for grouping or binning.

        minimum_value (int): Minimum value of population count. Needed when
         the frequency of the observed value on a given population &
         binning cell is equal to zero. This is required to prevent
         divide-by-zero and logarithm errors. Default value is 1.

        bins (list, optional): The desired bins when binning_type = "manual"

    Returns:
        (float): The population stability index.

    Raises:
        None. Errors are handled in subfunctions.

    Examples:
        Call function from Python like this::

            >>> population_stability_index(
                data=df_lgd,
                population_col='year',
                population_1='2014',
                population_2='2015',
                binning_type='lgd',
                minimum_value=1
            )

    Notes:
        Author: Lee MacKenzie Fischer (G01679)
    """
    # Bin and group raw data.
    grouped_data = _pandas_group_population(
        data=data,
        population_col=population_col,
        binning_type=binning_type,
        binning_col=binning_col,
        minimum_value=minimum_value,
        bins=bins,
        check_cols=[population_1, population_2],
    )

    # Return population stability index.
    return psi_test(grouped_data, population_1, population_2)


def z_test(
    element_1: float,
    element_2: float,
    N_count: int,
    upper_or_lower: Literal["upper", "lower"],
) -> tuple:
    """
    Single calculation of the z-test. Implemented as per page 25
    in the ECB document 'Annex 2. Instructions for reporting the
    validation results of internal models. IRB Pillar I models for
    credit risk'.

    This test is one-sided. This test is also asymptotic, meaning that
    it relies on N being large. The test may be unreliable in small samples.

    Note that if either of the elements or the N_count are zero, the test
    will return a NaN value.

    Args:
        element_1 (float): The p_(i,j) element from the z-test algorithm.

        element_2 (float): The p_(i, j+1) element from the z-test algorithm.

        N_count (int): The total number of customers in the p_(i,j) element's row (row total for i).

        upper_or_lower (str): Value passed is either 'upper' or 'lower' to indicate
         whether the positive or negative variant of the algorithm will be returned.

    Returns:
        (tuple): The z-test statistic and p-value parameter.

    Raises:
        None.

    Notes:
        Author: Lee MacKenzie Fischer (G01679)
    """
    # Check arguments for ValueErrors.
    if upper_or_lower not in ["upper", "lower"]:
        raise ValueError(
            "Argument 'upper_or_lower' must be passed one of: 'upper', 'lower'."
        )

    z_stat = (element_1 - element_2) / np.sqrt(
        (element_1 * (1 - element_1) / N_count)
        + (element_2 * (1 - element_2) / N_count)
        + (2 * element_1 * element_2 / N_count)
    )

    if upper_or_lower == "lower":
        z_stat = (-1) * z_stat

    # Calculate p-value.
    p_value = norm.cdf(z_stat)

    return z_stat, p_value


def mm_stability_test(mig_matrix: pd.DataFrame, N_data: pd.Series) -> tuple:
    """
    Returns the z-test and p-value matrices from a migration matrix, in
    accordance with page 24 of the ECB document 'Annex 2. Instructions for
    reporting the validation results of internal models. IRB Pillar I models
    for credit risk'.

    The z-test (crv.validation.stability.z_test) is applied to adjacent cells
    in the migratoin matrix and is one-sided. This test returns 2 matrices,
    with the second being a matrix of p-values from each of the cell tests.
    The user must choose a relevant significance level and compare to the
    p-value matrix.

    Note that the z-test is asymptotic, meaning that it relies on N being large.
    The test may be unreliable in small samples.

    Also note that if the row count (N_data) or any of the cells have a zero
    value, the test will return a NaN for both the z-test statistic and the
    p-value, and nothing can be concluded from these cells.

    Args:
        mig_matrix (pandas.DataFrame): The migration matrix, specifically the
         output of the 'crv.validation.summary.migration_matrix' function.
         This function expects a pandas.DataFrame layout and column names
         to be the same as that in the output of the 'migration_matrix'
         function. This function must be applied correctly on two relevant
         time periods for this test to have meaning.

        N_data (pandas.Series): The row totals from the migration matrix as a
         pandas.Series. This is typically the 'N' column from the output
         from the 'migration_matrix' function, e.g. mm['N'].

    Returns:
        (tuple): pandas.DataFrames containing z-test and p-value results, respectively.

    Raises:
        None.

    Example:
        Call function from Python like this, given 'mig_matrix' as
         the result of the 'migration_matrix()' function::

            z_matrix, p_matrix = mm_stability_test(mig_matrix, mig_matrix['N'])

    Notes:
        Author: Lee MacKenzie Fischer (G01679)
    """
    matrix_length = len(mig_matrix)
    z_matrix = np.zeros((matrix_length, matrix_length))
    p_matrix = np.zeros((matrix_length, matrix_length))
    N = N_data.tolist()

    for i in range(matrix_length):
        for j in range(matrix_length):
            if i != j:
                u_or_l = "upper" if i < j else "lower"
                if u_or_l == "upper":
                    z_stat, p_val = z_test(
                        mig_matrix.iloc[i, j - 1], mig_matrix.iloc[i, j], N[i], u_or_l
                    )
                else:
                    z_stat, p_val = z_test(
                        mig_matrix.iloc[i, j], mig_matrix.iloc[i, j + 1], N[i], u_or_l
                    )
                z_matrix[i, j] = z_stat
                p_matrix[i, j] = p_val
            else:
                z_matrix[i, j] = np.nan
                p_matrix[i, j] = np.nan

    # Convert to pandas.DataFrame.
    df_z = pd.DataFrame(z_matrix, index=mig_matrix.index, columns=mig_matrix.index)
    df_p = pd.DataFrame(p_matrix, index=mig_matrix.index, columns=mig_matrix.index)

    # Zero thresholding.
    df_z[df_z.abs() < 1e-8] = 0
    df_p[df_p.abs() < 1e-8] = 0

    return df_z, df_p


def matrix_weighted_bandwidth(mig_matrix: pd.DataFrame, N_data: pd.Series) -> tuple:
    """
    Returns the lower and upper matrix-weighted bandwith (MWB) of a migration
    matrix respectively, in accordance with page 23 of the ECB document 'Annex 2. Instructions
    for reporting the validation results of internal models. IRB Pillar I models
    for credit risk'.

    MWB values are calculated to summarise the transitions above (lower) and
    below (above) the diagonal of the migration matrix.

    Args:
        mig_matrix (pandas.DataFrame): The migration matrix has to be delivered as square matrix
         with probability of transistions between rating classes. If no transitions were reported
         for the particular rating groups then it should be marked as 0.

        N_data (pandas.Series): The number of transitions from the particular rating class
         for the delivered mig_matrix.

    Returns:
        (tuple): The tuple with lower and upper matrix-weighted bandwith.

    Raises:
        ValueError - if mig_matrix has different dimensions i.e. not square matrix
        TypeError - if mig_matrix is not pd.DataFrame
        TypeError - if N_data is not pd.Series
        ValueError - if there are negative values in mig_matrix
        ValueError - if there are greater than 1 values in mig_matrix
        ValueError - if there are negative numbers N_data
        ValueError - if N_data has different number of rows than mig_matrix

    Examples:
        Calculate results in Python like this::

            lower_bound, upper_bound = matrix_weighted_bandwidth(df_migration_matrix, n_count_migrations_in_a_row)

    """
    # mig_matrix is instance of pd.DataFrame
    if not isinstance(mig_matrix, pd.DataFrame):
        raise TypeError("mig_matrix argument has to be a type of pd.DataFrame")
    # N_data is instance of pd.Series
    if not isinstance(N_data, pd.Series):
        raise TypeError("N_data argument has to be type a of pd.Series")
    # square dataframe
    row, col = mig_matrix.shape
    if row != col:
        raise ValueError("the mig_matrix has to have the same dimensions")
    # negative values in dataframes
    if (mig_matrix.values < 0).any():
        raise ValueError("values in the migration matrix cannot be negative")
    # values greater than 1 in dataframes
    if (mig_matrix.values > 1).any():
        raise ValueError("values in the migration matrix cannot be greater than 1")
    # negative numbers in N_data
    if (N_data.values < 0).any():
        raise ValueError("values in the N_data cannot be negative")
    # the same row numbers in mig_matrix and N_data
    if N_data.shape[0] != row:
        raise ValueError(
            f"the argument N_data has to have the same number of rows as the mig_matrix"
        )

    K = len(mig_matrix)
    results_mwb = {}
    for upper_or_lower in ["lower", "upper"]:
        if upper_or_lower == "upper":
            start_row = 1
            end_row = K - 1
        else:
            start_row = 2
            end_row = K
        M_norm = 0
        mwb_numerator = 0
        for i in range(start_row, end_row + 1):
            sum_frequencies = 0
            if upper_or_lower == "upper":
                start_col = i + 1
                end_col = K
            else:
                start_col = 1
                end_col = i - 1

            for j in range(start_col, end_col + 1):
                sum_frequencies += mig_matrix.iloc[i - 1, j - 1]
                mwb_numerator += (
                    abs(i - j) * N_data.iloc[i - 1] * mig_matrix.iloc[i - 1, j - 1]
                )
            M_norm += max(abs(i - K), (i - 1)) * N_data.iloc[i - 1] * sum_frequencies

        results_mwb[upper_or_lower] = round(mwb_numerator / M_norm, 8)

    return results_mwb["lower"], results_mwb["upper"]


def likelihood_ratio_test(
    log_likelihood_unrestricted: float,
    log_likelihood_restricted: float,
    num_parameters_unrestricted: int,
    num_parameters_restricted: int,
) -> tuple:
    """
    Likelihood Ratio Test.

    General purpose test that can be applied when a model is estimated by Maximum
    Likelihood (MLE). The test is suitable for various null hypotheses (or constraints).
    The only restriction is that the model under the null hypothesis (the restricted model)
    is nested, i.e. is part or a special case of the original model (the unrestricted model).

    More details about the test can be found in https://en.wikipedia.org/wiki/Likelihood-ratio_test.

    Args:
        log_likelihood_unrestricted (float): log-likelihood of unrestricted model.

        log_likelihood_restricted (float): : log-likelihood of restricted model.

        num_parameters_unrestricted (int): Number of parameters of unrestricted model.

        num_parameters_restricted (int): Number of parameters of restricted model.

    Returns:
        result (tuple): Contains the likelihood ratio value and the p-value.

    Raises:
        ValueError: if log_likelihood_restricted > log_likelihood_unrestricted.

        ValueError: if num_parameters_unrestricted <= num_parameters_restricted.

        ValueError: if number of parameters are not integers.

    Example:
        Call function from Python like this::

            likelihood_ratio = likelihood_ratio_test(log_likelihood_unrestricted = -56.069,
                                                     log_likelihood_restricted = -65.871,
                                                     num_parameters_unrestricted = 4,
                                                     num_parameters_restricted = 3)

    Notes:
        Author: Diana Lucatero (G85544)
    """
    # Checking validity of log-likelihoods
    if log_likelihood_restricted > log_likelihood_unrestricted:
        raise ValueError(
            "log-likehood of restricted model should be "
            "lower than or equal to the log-likehood of the unrestricted "
            "model."
        )

    # Checking validity of number of parameters magnitudes
    if num_parameters_restricted >= num_parameters_unrestricted:
        raise ValueError(
            "number of parameters of restricted model should be "
            "lower than the number of parameters of of the "
            "unrestricted model."
        )

    # Checking validity of number of parameters
    if not isinstance(num_parameters_unrestricted, int) or not isinstance(
        num_parameters_restricted, int
    ):
        raise ValueError("number of parameters of both models " "should be an integer.")

    # Compute likelihood ratio
    lr = -2 * (log_likelihood_restricted - log_likelihood_unrestricted)

    # Compute degrees of freedom
    _dof = num_parameters_unrestricted - num_parameters_restricted
    # Compute cdf value of a chi-squared at the lr
    _cdf = chi2.cdf(x=lr, df=_dof)
    # Compute p-value
    p_value = 1 - _cdf

    return lr, p_value
