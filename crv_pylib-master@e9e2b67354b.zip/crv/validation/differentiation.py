"""
############
Introduction
############
The ECB guideline "Annex 2 - Instructions for reporting the validation results of internal models" of February 2019 describe the following dimensions along which the performance of the performance of the Pillar I credit risk models can be assessed:
    
* Calibration
* Differentiation
* Stability

This file contains the validation tools that provide insight into the differentiation power of Pillar I credit risk models. These validation tools can be PD, LGD, EAD/CCF model specific, but can also be PD, LGD, EAD/CCF model agnostic. 
    
Validation tools
================
This section gives an overview of the validation tools available to determine differentiation power of the Pillar I credit risk models; categorised by PD, LGD, EAD/CCF model. 

PD
--
The analysis of differentiation power is aimed at ensuring that the ranking of customers that results from the rating process appropriately separates riskier and less risky customers.
    
* **AUC**: AUC measures the model’s ability to distinguish between high and low PDs.
    
* **Herfindahl index**: The objective of this validation tool is to assess whether rating grades have meaningful dispersion.

* **Two-sample Kolmogorov Smirnov test**: The Two-sample Kolmogorov Smirnov test tests for the null hypothesis that two independent samples are drawn from the same continuous distribution.

* **Somers' D**: A measure of ordinal association (i.e. rank correlation).
            
LGD
---
The analysis of differentiation power is aimed at ensuring that LGD models are able to discriminate between facilities with high and low values for LGD.  

* **Generalised AUC**: Calculates the difference between the number of concordant pairs and the number of discordant pairs divided by the total number of pairs not tied on the independent variable
    
* **Generalised AUC test statistic**: Calculates the test statistic, variance, and p-value from the AUC scores from two years of data as per section 2.6.3.1 of "Annex 2 - Instructions for reporting validation results of internal models", February 2019.

* **Loss Capture Ratio**: An approach that has been designed to measure the discriminatory power on the LGDs ability to capture the portfolio’s final observed loss amount.

* **Two-sample Kolmogorov Smirnov test**: The Two-sample Kolmogorov Smirnov test tests for the null hypothesis that two independent samples are drawn from the same continuous distribution.

EAD/CCF
-------
The assessment of differentiation power is aimed at ensuring that EAD/CCF models are able to discriminate between facilities with high and low EAD/CCF values.
    
* **Generalised AUC**: Calculates the difference between the number of concordant pairs and the number of discordant pairs divided by the total number of pairs not tied on the independent variable

* **Generalised AUC test statistic**: Calculates the test statistic, variance, and p-value from the AUC scores from two years of data as per section 2.6.3.1 of "Annex 2 - Instructions for reporting validation results of internal models", February 2019.

* **Two-sample Kolmogorov Smirnov test**: The Two-sample Kolmogorov Smirnov test tests for the null hypothesis that two independent samples are drawn from the same continuous distribution.

Warning
=======
The functions herein assume the data has been correctly processed up to this point. See other modules if data processing is needed. This implies that data has been extracted and contain the required variables. Variables required for the test should be stated in the function header.

Notes:
Author: N440730, G01679

###################
Test implementation
###################
"""

from typing import Tuple, Union
import numpy as np
import pandas as pd
from math import gcd
from scipy.stats import beta, norm, chi2, ks_2samp, kstwobign
from scipy.stats.stats import (
    _compute_prob_outside_square,
    _compute_prob_inside_method,
    _count_paths_outside_method,
    Ks_2sampResult,
)
import scipy.special as special
import pyspark
from pyspark.sql import SparkSession
from pyspark.ml.feature import QuantileDiscretizer
from crv.utils.spark_helper import spark_create_index_col, spark_searchsorted
import warnings
import pyspark.sql.functions as f
import pyspark.sql.dataframe as psd
from pyspark.sql.window import Window
from typing_extensions import Literal
from typing import Union
from crv.validation.summary import adf_summary
from statsmodels.stats.proportion import proportion_confint

__all__ = [
    "auc",
    "herfindahl_index",
    "g_auc",
    "g_auc_test_stats",
    "loss_capture_ratio",
    "_pandas_kolmogorov_smirnov_2_sample",
    "somers_d",
]


def auc(
    adf_table: pd.DataFrame,
    default_count_col: str,
    customer_count_col: str,
    pd_col: str,
) -> tuple:
    """
    Calculates AUC & it's standard deviation for an ADF table, grouped by PD (rating),
    according to section 3.1 in ECB's "Annex 2 - Instructions for
    reporting the validation results of internal models (February 2019)".

    For this to be meaningful the ADF table should be grouped by rating.
    If it is not grouped it will output 0.5.
    If it is grouped by some other variable the AUC will be calculated
    based on that grouping, using PD value as rating proxy.

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding PD.

    Returns:
        (tuple): Calculated AUC value and standard deviation s.

    Raises:
        ValueError: when adf_table is not one a pandas.DataFrame.

    Examples:
        Call function in Python like this::

            auc_result = auc(data, 'D', 'N', 'PD')

    Notes:
        Author: Aron Moberg <N440730>
    """
    # Check for correct input data type
    if not isinstance(adf_table, pd.DataFrame):
        raise ValueError("adf_table must be a pandas.DataFrame")

    df = adf_table.copy()
    _D, _N, _PD = default_count_col, customer_count_col, pd_col
    # Remove Nan PD then group by PD and keep N and D columns.
    # Grouping by PD is the same as grouping by rating as long as we do not
    # use customer specific PDs. Groupby orders ascending by default.
    df = df.loc[df[_PD] < 1].groupby(by=_PD, sort=True)[[_N, _D]].sum()
    df["ND"] = df[_N] - df[_D]

    # Add 0.5 for each (ND, D) pair with same rating
    U = df["ND"].dot(df[_D]) / 2

    # Initiate variable to keep track of total defaults in lower rating grades.
    defs_above = df[_D].sum()

    # For-loop to create column with defs_above for each PD (rating)
    for PD_level in df.index:
        # Update defs_above by subtracting defaults in current rating grade
        defs_above -= df.loc[PD_level, _D].item()
        df.loc[PD_level, "defs_above"] = defs_above

    # Number of times PD(ND) < PD(D) for each a in A
    df["defs_below"] = df["ND"].cumsum() - df["ND"]

    # Add 1 for each (ND, D) pair where rating(D) > rating(ND)
    U += df["ND"].dot(df["defs_above"])
    A = df[_D].copy()
    B = df["ND"].copy()

    # Computation of AUC
    auc = U / (A.sum() * B.sum())

    # Creation of V_10 & V_01 vectors
    df["v_10"] = (B / 2 + df["defs_below"]) / B.sum()
    df["v_01"] = (A / 2 + df["defs_above"]) / A.sum()

    # Compute mean and variance of V_10 & V_01 vectors
    mean_a = (df["v_10"] * A).sum() / A.sum()
    mean_b = (df["v_01"] * B).sum() / B.sum()

    var_a = (((df["v_10"] - mean_a) ** 2) * A).sum() * (1 / (A.sum() - 1))
    var_b = (((df["v_01"] - mean_b) ** 2) * B).sum() * (1 / (B.sum() - 1))

    # Computation of standard deviation
    s = np.sqrt(var_a / A.sum() + var_b / B.sum())

    return auc, s


def somers_d(
    adf_table: pd.DataFrame,
    default_count_col: str,
    customer_count_col: str,
    pd_col: str,
) -> tuple:
    """
    Somers' D is a measure of ordinal association (i.e. rank correlation) between
    two random variables. Unlike Pearson correlation coefficient, Somers' D can be
    computed for ordinal categorical random variables too. The Somers' D statistic
    takes values from -1 (perfect inverse association) to +1 (perfect association).

    Note: The Somers' D is equivalent to the Gini coefficient with respect to
     PD analysis.

    Somers' D application is particularly suitable in the following situations:
    - X (i.e. explanatory variable) = (continuous, numeric) score;
       Y (i.e. dependent variable) = default indicator;
    - X = (categorical) rating;
       Y = default indicator;

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        default_count_col (str): Name of column containing the default count.

        customer_count_col (str): Name of column containing the customer count.

        pd_col (str): Name of the column containing the corresponding PD.

    Returns:
        (tuple): Calculated Somers' D value and it's standard deviation sd.

    Raises:
        ValueError: when adf_table is not one a pandas.DataFrame.

    Examples:
        Call function in Python like this::

            adf_table = adf_summary(data, 'customer_id', 'default_flag', group_list=['rating'])
            adf_table = adf_table.join(pd_table, on='rating', how='left')
            somers_d_result, somers_d_sd = somers_d(adf_table, 'D', 'N', 'PD')

    Notes:
        Author: Adam Szpilewicz <M016673>
    """
    auc_, s_ = auc(
        adf_table=adf_table,
        default_count_col=default_count_col,
        customer_count_col=customer_count_col,
        pd_col=pd_col,
    )
    somers_d, sd = 2 * auc_ - 1, 2 * s_
    return somers_d, sd


def herfindahl_index(
    adf_table: pd.DataFrame, pd_col: str, weight: str = None, CV_init: float = None
) -> tuple:
    """
    Calculates Herfindahl index for an ADF table, usually grouped by PD
    (rating), according to section 2.5.5.3 in ECBs "Annex 2 -
    Instructions for reporting the validation results of internal models"

    Args:
        adf_table (pandas.DataFrame): The summarized ADF table.

        pd_col (str): Name of the column containing the corresponding PD.

        weight (column name): The weight used for the calculation, usually
         N or ORGEXP. Will be N if left empty.

        CV_init (float) Initial CV (optional), used to calculate p-value.

    Returns:
        (tuple): Returns (HI - herfindahl index,
                          CV - coefficient of variation,
                          p-value - calculated against CV_init if given as input variable)

    Examples:
        Call function in Python like this::

            HI = herfindahl_index(data, 'PD', 'N')

    Warnings:
        UserWarning - if 'CV_init' is not between 0 and 1.

    Notes:
        Author: Aron Moberg <N440730>
    """
    df = adf_table.copy()
    _PD = pd_col
    # Remove Nan PD then group by PD and keep the weight column.
    # Grouping by PD is the same as grouping by rating as long as we do not
    # use customer specific PDs. Groupby orders ascending by default.
    if isinstance(weight, type(None)):
        weight = "N"
    df = df.loc[df[_PD] < 1].groupby(by=_PD, sort=True)[weight].sum().reset_index()
    N = df[weight].sum()
    K = df[weight].count()
    # if K == 1 then HI is one by defenition but will be set to np.nan:
    # as we are dividing by log(K) below
    df["Ri"] = df[weight] / N
    df["Ri_term"] = (df["Ri"] - 1 / K) ** 2
    CV = np.sqrt(K * df["Ri_term"].sum())
    if K == 1:
        HI = 1
    else:
        HI = 1 + np.log((CV ** 2 + 1) / K) / np.log(K)

    p = None
    # Calculate p if CV_init is correctly given as a float between 0 and 1
    if CV_init != None:
        if isinstance(CV_init, float):
            if (0 < CV_init < 1) & (CV > 0):
                p = 1 - norm.cdf(
                    np.sqrt(K - 1)
                    * (CV - CV_init)
                    / np.sqrt((CV ** 2) * (0.5 + CV ** 2))
                )
        else:
            warn_string = "CV_init should be a float between 0 and 1"
            warnings.warn(warn_string, UserWarning)
    return HI, CV, p


def g_auc(lgd_matrix: Union[pd.DataFrame, np.array]) -> float:
    """
    A risk differentiation test for LGD and EAD/CCF models.

    Calculates the generalized AUC for a single observation period as per
    section 2.6.3.1 of the ECB guideline "Annex 2 - Insutrctions for reporting
    the validation results of internal models", February 2019.

    The algorithm assumes estimated values are in rows and realized values
    are in columns, the table is filled with frequencies (counts) and the
    estimated and realized values are ranked in order from low to high
    across rows (going down) and columns (going right).

    The AUC algorithm is implemented as per section 3.2 of the ECB
    guideline "Annex 2 - Insutrctions for reporting the validation
    results of internal models", February 2019.

    Args:
        lgd_matrix (pandas.DataFrame, numpy.array)

    Returns:
        (float): The generalized AUC score.

        (float): The standard deviation of the AUC score.

    Examples:
        Call function like this from Python::

            auc, s = g_auc(df_lgd)

    Author:
        Lee MacKenzie Fischer <G01679>
    """
    # Convert to numpy.array and get basic count matrices if DataFrame.
    a = (
        lgd_matrix.to_numpy()
        if isinstance(lgd_matrix, pd.DataFrame)
        else lgd_matrix.copy()
    )  # Data matrix
    r = a.sum(axis=1)  # Row totals.
    F = a.sum()  # The matrix total.

    A = np.zeros(a.shape)
    D = np.zeros(a.shape)

    # Sum frequency counts for off-axis cells.
    for i in range(a.shape[0]):
        for j in range(a.shape[1]):
            upper_left_sum = a[:i, :j].sum()
            lower_right_sum = a[i + 1 :, j + 1 :].sum()
            A[i, j] = upper_left_sum + lower_right_sum

            lower_left_sum = a[i + 1 :, :j].sum()
            upper_right_sum = a[:i, j + 1 :].sum()
            D[i, j] = lower_left_sum + upper_right_sum

    # Summarize total agreements and disagreements.
    P_arr = a * A
    Q_arr = a * D
    P = (
        P_arr.sum()
    )  # Twice the number of agreements in the ordering of the cell indices when all pairs are compared.
    Q = Q_arr.sum()  # Twice the number of disagreements.

    # Calculate standard deviation.
    w_r = F ** 2 - (r ** 2).sum()
    d = A - D
    b2 = np.zeros(a.shape)
    for i in range(a.shape[0]):
        for j in range(a.shape[1]):
            b2[i, j] = a[i, j] * (w_r * d[i, j] - (P - Q) * (F - r[i])) ** 2
    s = ((1 / w_r) ** 2) * np.sqrt(b2.sum())  # The standard deviation in the gAUC test.

    # Calculate the gAUC value.
    somers_D = (P - Q) / w_r
    g_auc = (somers_D + 1) / 2

    return g_auc, s


def g_auc_test_stats(
    g_auc_init: float, g_auc_curr: float, s_curr: float
) -> Tuple[float]:
    """
    A risk differentiation test for LGD and EAD/CCF models.

    Calculates the test statistic, variance, and p-value from the AUC scores
    from two years of data as per section 2.6.3.1 of "Annex 2 - Instructions
    for reporting validation results of internal models", February 2019.

    Args:
        g_auc_init (float): The generalized AUC score (as calculated by the 'g_auc'
         function) from the initial (e.g. previous) year.

        g_auc_curr (float): The generalized AUC score (as calculated by the 'g_auc'
         function) from the current year.

        s_curr (float): The standard deviation (as calculated by the 'g_auc'
         function, second returned parameter) for the current year.

    Returns:
        (float): The test statistic.

        (float): The variance in the current AUC score.

        (float): The p-value of the test statistic.

    Examples:
        Call function from Python like this::

            t_stat, var, p = g_auc_test_stats(auc_1, auc_2, stdev_2)

    Author:
        Lee MacKenzie Fischer <G01679>
    """
    test_statistic = (g_auc_init - g_auc_curr) / s_curr
    var = s_curr ** 2
    p = 1 - norm.cdf(test_statistic)
    return test_statistic, var, p


def loss_capture_ratio(
    df: Union[pd.DataFrame, psd.DataFrame],
    obs_col: str,
    pred_col: str,
    order_by: Literal["observed", "predicted"] = "observed",
    calc_method: Literal["deciles", "all_observations"] = "all_observations",
) -> dict:
    """
    Loss Capture Ratio

    The Loss Capture Ratio (LCR) is calculated to analyse the discriminatory
    power of the LGD model by measuring the ability of the model to distinguish
    high LGD’s from low ones.

    To calculate the LCR the cumulative realised loss amount is captured by
    ordering from highest to lowest the predicted or observed LGD in line
    with the passed argument `order_by`.

    This loss capture curve is compared to the perfect model curve,
    which is defined as the cumulative realised loss amount captured by
    ordering the realised LGD from highest to lowest; and to the random model
    curve, which is a 45 degree line representing a random model. The LCR
    is calculated by dividing the area between the loss capture curve and the
    random model curve by the area between the perfect model curve and the
    random model curve.

    Note:
        Outliers and duplicates should be dropped from the input data table.

        If LCR should be calcualted with LGD weighted by EAD then parameters
         `obs_col` and `pred_col` should be delivered after weighting.

        Result values less than zero should be viewed as suspicious and input
         data should be inspected.

    Important caveats related to `calc_method="deciles"`:
        * | the pandas and spark implementations of `loss_capture_ratio`
          | can lead to small differences in the values of AUC and LCR. The difference
          | is due to the "distributed nature of the calculation when using Spark". The
          | used algorithm to calculate deciles in spark: bin ranges are chosen using an
          | approximate algorithm (see the documentation for
          | :py:meth:`org.apache.spark.sql.DataFrameStatFunctions.DataFrameStatFunctions.approxQuantile`
          | for a detailed description)

        * | the differences in results diminsish with the increased size of sample data;
          | the quantification of difference abs[(pandas_lcr / spark_lcr) - 1]:

            * ~0.8% for less than 100 000 of observations
            * ~0.44% for 500 000 of observations
            * ~0.07% for 1 000 000 of observations

    Args:
        df (pandas.DataFrame): The input data table
         containing observed and predicted LGD at account level.

        obs_col (str): The name of the column containing the values
         for the observed (realised) LGD values.

        pred_col (str): The name of the column containing the values
         for the predicted (estimated) LGD values.

        order_by (str): One of ``observed`` or ``predicted``. Default is ``observed``:
            * | ``observed`` - Model's capture curve is identified by ordering data
              | in delivered data frame by observed (real) values. Based
              | on that ordering predicted AUC is calculated.
            * | ``predicted`` - Model's capture curve is identified by ordering data
              | in delivered data frame by predicted (from model) values.
              | Based on that ordering predicted AUC is calculated. This
              | approach was introduced to reflect the modelers'
              | approach to the calculation of predicted AUC.

        calc_method (str) - One of ``deciles`` or ``all_observations``. Default is ``all_observations``:
            * | ``deciles`` - in this approach the calculation of the loss capture curve
              | bases on deciles computed from delivered data on the exposure level
            * | ``all_observations`` - in this approach the calculation of the
              | loss capture curve bases on the exposure level (no prior
              | deciles computation)

    Returns:
        (dict): A dictionary containing the results:
            * ``Predicted AUC`` - The AUC from the LGD estimates from the model data.
            * ``Perfect AUC`` - The AUC from the observed LGD as a perfect model.
            * ``LCR`` - The loss capture ratio from the calculation.
            * ``data`` - A pandas.DataFrame containing the data for plotting the model data.

    Raises:
        ValueError - if input to argument `df` is not a pandas.DataFrame

        ValueError - if `df` is empty

        ValueError - if `obs_col` or `pred_col` not found within `df` columns names

        ValueError - if string passed to the argument `order_by` is other than `predicted`
         or `observed`

        ValueError - if string passed to the argument `calc_method` is other than `deciles`
         or `all_observations`

    Examples:
        Calculate results in Python like this::

            lcr_results = lcr(df, `obs_col`, `pred_col`, `observed`, `all_observations`)

        Plot the results using CRV functions like this::

            from crv.io.plotting import line_plot
            fig, axs, lgnd = line_plot(lcr_results[`data`],
                                       `Percent Accumulated Population`,
                                       [`Perfect Model`, `Current Model`, `Random Model`],
                                       return_axes=True, force_axis_zero=`both`)
            ax[0].set_ylabel(`Observed Loss`)
            ax[0].set_xlabel(`Accumulated Population`)
            plt.show()

    Notes:
        Author: Adam Szpilewicz (M016673)
    """
    if not isinstance(df, pd.DataFrame) and not isinstance(df, psd.DataFrame):
        raise ValueError(
            "Value passed to argument `df` must be pandas.DataFrame"
            " or pyspark.sql.dataframe"
        )
    if isinstance(df, pd.DataFrame):
        if df.empty:
            raise ValueError("Input to argument `df` must not be empty.")
    elif df.count() == 0:
        raise ValueError("Input to argument `df` must not be empty.")
    if not {obs_col, pred_col}.issubset(df.columns):
        raise ValueError(
            "One or more of the required columns were not found "
            f"in the input DataFrame: {obs_col}, {pred_col}"
        )
    if order_by not in ["predicted", "observed"]:
        raise ValueError(
            "Allowed values of input argument `order_by` are `predicted` or `observed`"
        )
    if calc_method not in ["all_observations", "deciles"]:
        raise ValueError(
            "Allowed values of input argument `calc_method` are `all_observations` or `deciles`"
        )

    dict_func = {"pandas": _pandas_lcr, "spark": _spark_lcr}
    func_to_call = (
        dict_func.get("pandas")
        if isinstance(df, pd.DataFrame)
        else dict_func.get("spark")
    )

    return func_to_call(
        df=df,
        obs_col=obs_col,
        pred_col=pred_col,
        order_by=order_by,
        calc_method=calc_method,
    )


def _pandas_lcr(
    df: pd.DataFrame,
    obs_col: str,
    pred_col: str,
    order_by: Literal["observed", "predicted"] = "predicted",
    calc_method: Literal["all_observations", "deciles"] = "all_observations",
) -> dict:
    """
    Loss Capture Ratio, pandas implementation.

    Args:
        df (pandas.DataFrame): The input data table containing the
         observed and predicted LGD at account level.

        obs_col (str): The name of the column containing the values
         for the observed (realised) LGD values.

        pred_col (str): The name of the column containing the values
         for the predicted (estimated) LGD values.

        order_by (str): observed - Model's capture curve is identified by ordering
                                observed values and deriving the cumulative predicted
                                values
                        predicted - Model's capture curve is identified by ordering
                                predicted values and deriving the cumulative observed
                                values

        calc_method (str): The approach towards numbers of observations used in the
         calculation: possible values `all_observations` or `deciles`

    Notes:
        Author: Adam Szpilewicz (M016673)
    """

    df = df[[obs_col, pred_col]].copy()
    df = _add_deciles_pandas(df=df, rank_column=obs_col)
    df = _add_deciles_pandas(df=df, rank_column=pred_col)

    # calculate perfect model AUC
    df_obs = df.sort_values(by=[obs_col], ascending=[False])
    if calc_method == "deciles":
        sort_col = f"decile_rank_{obs_col}"
        df_obs = df.groupby(by=[sort_col]).agg(
            obs_col=(obs_col, sum), pred_col=(pred_col, sum), population=(sort_col, len)
        )
        df_obs.columns = [obs_col, pred_col, "population"]
        df_obs = df_obs.sort_values(by=sort_col, ascending=[False])
    df_obs = _calculate_cumulative_percentage(
        df=df_obs, obs_col=obs_col, pred_col=pred_col
    )
    df_obs["accum_pop"] = np.arange(len(df_obs)) + 1
    df_obs["perc_accum_pop"] = df_obs["accum_pop"] / df_obs["accum_pop"].max()
    if calc_method == "deciles":
        df_obs["accum_pop"] = df_obs["population"].cumsum()
        df_obs["perc_accum_pop"] = df_obs["accum_pop"] / df_obs["accum_pop"].max()

    perfect_model_auc = (
        np.trapz(df_obs["perc_accum_obs_loss"], x=df_obs["perc_accum_pop"]) - 0.5
    )

    if order_by == "observed":
        pred_model_auc = (
            np.trapz(df_obs["perc_accum_pred_loss"], x=df_obs["perc_accum_pop"]) - 0.5
        )

    # calculate predicted model AUC
    if order_by == "predicted":
        df_pred = df.sort_values(by=[pred_col], ascending=[False])
        if calc_method == "deciles":
            sort_col = f"decile_rank_{pred_col}"
            df_pred = df.groupby(by=[sort_col]).agg(
                obs_col=(obs_col, sum),
                pred_col=(pred_col, sum),
                population=(sort_col, len),
            )
            df_pred.columns = [obs_col, pred_col, "population"]
            df_pred = df_pred.sort_values(by=sort_col, ascending=[False])
        df_pred = _calculate_cumulative_percentage(
            df=df_pred, obs_col=obs_col, pred_col=pred_col
        )
        df_pred["accum_pop"] = np.arange(len(df_pred)) + 1
        df_pred["perc_accum_pop"] = df_pred["accum_pop"] / df_pred["accum_pop"].max()
        if calc_method == "deciles":
            df_pred["accum_pop"] = df_pred["population"].cumsum()
            df_pred["perc_accum_pop"] = (
                df_pred["accum_pop"] / df_pred["accum_pop"].max()
            )
        df_pred["perc_accum_loss"] = (
            df_pred["accum_obs_loss"] / df_pred["accum_obs_loss"].max()
        )
        pred_model_auc = (
            np.trapz(df_pred["perc_accum_loss"], x=df_pred["perc_accum_pop"]) - 0.5
        )

    lcr = pred_model_auc / perfect_model_auc
    df_plotting = _lcr_plotting(df_obs=df, df_pred=df)

    return {
        "Predicted AUC": pred_model_auc,
        "Perfect AUC": perfect_model_auc,
        "LCR": lcr,
        "data": df_plotting[
            [
                "Percent Accumulated Population",
                "Perfect Model",
                "Current Model",
                "Random Model",
            ]
        ],
    }


def _spark_lcr(
    df: psd.DataFrame,
    obs_col: str,
    pred_col: str,
    order_by: Literal["observed", "predicted"] = "observed",
    calc_method: Literal["deciles", "all_observations"] = "all_observations",
):
    """
    Loss Capture Ratio, spark implementation.

    Args:
        df (pyspark.sql.DataFrame): The input data table containing the
         observed and predicted LGD at account level.

        obs_col (str): The name of the column containing the values
         for the observed (realised) LGD values.

        pred_col (str): The name of the column containing the values
         for the predicted (estimated) LGD values.

        order_by (str): observed - Model's capture curve is identified by ordering
                                observed values and deriving the cumulative predicted
                                values
                        predicted - Model's capture curve is identified by ordering
                                predicted values and deriving the cumulative observed
                                values

        calc_method (str): The approach towards numbers of observations used in the
         calculation: possible values `all_observations` or `deciles`

    Notes:
        Author: Adam Szpilewicz (M016673)
    """
    df = df.select(obs_col, pred_col)
    df = _add_deciles_spark(df=df, rank_column=obs_col)
    df = _add_deciles_spark(df=df, rank_column=pred_col)

    # calculate perfect model AUC
    df_obs = df.orderBy(df[obs_col].desc())
    df_obs = df_obs.withColumn("idx", f.monotonically_increasing_id())
    window_ = Window.orderBy(f.col("idx"))
    if calc_method == "deciles":
        sort_col = f"decile_rank_{obs_col}"
        df_obs = (
            df.groupBy(df[sort_col]).agg(
                f.sum(obs_col).alias(obs_col),
                f.sum(pred_col).alias(pred_col),
                f.count("*").alias("population"),
            )
        ).orderBy(f.col(obs_col).desc())
        df_obs = df_obs.withColumn("idx", f.monotonically_increasing_id())
        window_ = Window.orderBy(f.col("idx"))
    df_obs = _calculate_cumulative_percentage_spark(
        df=df_obs, obs_col=obs_col, pred_col=pred_col, window_=window_
    )
    df_obs = df_obs.withColumn("accum_pop", f.row_number().over(window_))
    max_accum_pop = df_obs.agg({"accum_pop": "max"}).collect()[0][0]
    df_obs = df_obs.withColumn("perc_accum_pop", df_obs.accum_pop / max_accum_pop)
    if calc_method == "deciles":
        df_obs = df_obs.withColumn("accum_pop", f.sum("population").over(window_))
        max_accum_pop = df_obs.agg({"accum_pop": "max"}).collect()[0][0]
        df_obs = df_obs.withColumn("perc_accum_pop", df_obs.accum_pop / max_accum_pop)

    df_obs = df_obs.withColumn(
        "inc_obs_trap_area",
        _trapz_spark("perc_accum_pop", "perc_accum_obs_loss", window_=window_),
    ).withColumn(
        "inc_pred_trap_area",
        _trapz_spark("perc_accum_pop", "perc_accum_pred_loss", window_=window_),
    )
    perfect_model_auc = (
        df_obs.agg({"inc_obs_trap_area": "sum"}).collect()[0]["sum(inc_obs_trap_area)"]
        - 0.5
    )

    if order_by == "observed":
        pred_model_auc = (
            df_obs.agg({"inc_pred_trap_area": "sum"}).collect()[0][
                "sum(inc_pred_trap_area)"
            ]
            - 0.5
        )

    # calculate predicted model AUC
    if order_by == "predicted":
        df_pred = df.orderBy(df[pred_col].desc())
        df_pred = df_pred.withColumn("idx", f.monotonically_increasing_id())
        window_ = Window.orderBy(f.col("idx"))
        if calc_method == "deciles":
            sort_col = f"decile_rank_{pred_col}"
            df_pred = (
                df.groupBy(df[sort_col])
                .agg(
                    f.sum(obs_col).alias(obs_col),
                    f.sum(pred_col).alias(pred_col),
                    f.count("*").alias("population"),
                )
                .orderBy(f.col(sort_col).desc())
            )
            df_pred = df_pred.withColumn("idx", f.monotonically_increasing_id())
            window_ = Window.orderBy(f.col("idx"))
        df_pred = _calculate_cumulative_percentage_spark(
            df=df_pred, obs_col=obs_col, pred_col=pred_col, window_=window_
        )
        df_pred = df_pred.withColumn("accum_pop", f.row_number().over(window_))
        max_accum_pop = df_pred.agg({"accum_pop": "max"}).collect()[0][0]
        df_pred = df_pred.withColumn(
            "perc_accum_pop", df_pred.accum_pop / max_accum_pop
        )

        if calc_method == "deciles":
            df_pred = df_pred.withColumn("accum_pop", f.sum("population").over(window_))
            max_accum_pop = df_pred.agg({"accum_pop": "max"}).collect()[0][0]
            df_pred = df_pred.withColumn(
                "perc_accum_pop", df_pred.accum_pop / max_accum_pop
            )
        max_accum_obs_loss = df_pred.agg({"accum_obs_loss": "max"}).collect()[0][0]
        df_pred = df_pred.withColumn(
            "perc_accum_loss", df_pred.accum_obs_loss / max_accum_obs_loss
        )
        df_pred = df_pred.withColumn(
            "inc_pred_trap_area",
            _trapz_spark("perc_accum_pop", "perc_accum_loss", window_=window_),
        )
        pred_model_auc = (
            df_pred.agg({"inc_pred_trap_area": "sum"}).collect()[0][
                "sum(inc_pred_trap_area)"
            ]
            - 0.5
        )

    lcr = pred_model_auc / perfect_model_auc
    df_plotting = _lcr_plotting(df_obs=df.toPandas(), df_pred=df.toPandas())

    return {
        "Predicted AUC": pred_model_auc,
        "Perfect AUC": perfect_model_auc,
        "LCR": lcr,
        "data": df_plotting[
            [
                "Percent Accumulated Population",
                "Perfect Model",
                "Current Model",
                "Random Model",
            ]
        ],
    }


def _add_deciles_pandas(df: pd.DataFrame, rank_column: str) -> pd.DataFrame:
    """
    The pandas implementation of `_add_deciles` function
    """
    column_with_deciles = f"decile_rank_{rank_column}"
    df[column_with_deciles] = pd.qcut(
        df[rank_column], q=10, labels=False, duplicates="drop"
    )
    df.loc[
        (df[column_with_deciles] == 0) & (df[rank_column] == 0),
        column_with_deciles,
    ] = -1
    # Numbering the bins from 1-10
    df[column_with_deciles] = df[column_with_deciles] + 2
    return df


def _add_deciles_spark(df: psd.DataFrame, rank_column: str) -> psd.DataFrame:
    """
    The spark implementation of `_add_deciles` function
    """
    column_with_deciles = f"decile_rank_{rank_column}"
    df = (
        QuantileDiscretizer(
            numBuckets=10,
            inputCol=rank_column,
            outputCol="decile",
            relativeError=0.01,
            handleInvalid="error",
        )
        .fit(df)
        .transform(df)
    )
    df = df.withColumn(
        column_with_deciles,
        f.when((df[rank_column] == 0) & (df.decile == 1), 1).otherwise(df.decile + 1),
    ).drop("decile")
    return df


def _trapz_spark(col_pop: str, col_loss: str, window_: pyspark.sql.Window) -> float:
    """
    The helper function to calculate the area under curve in line with trapezoidal rule:
    https://en.wikipedia.org/wiki/Trapezoidal_rule

    Args:
        col_pop (str): the name of the column storing values that will be used for
         the calcualtion of trapezoids height (X-axis)
        col_loss (str): the name of the column storing values that will be used for
         the calcualtion of trapezoids bases (Y-axis)
        window_ (pyspark.sql.Window): pyspark.sql.Window

    Returns:
        float
    """
    return (
        (f.col(col_pop) - f.lag(col_pop, 1).over(window_))
        * (f.lag(col_loss, 1).over(window_) + f.col(col_loss))
        / 2.0
    )


def _calculate_cumulative_percentage(
    df: pd.DataFrame, obs_col: str, pred_col: str
) -> pd.DataFrame:
    """
    The helper function that calculates cumulative sum of `obs_col` and `pred_col`
    and extendes the passed `df` with these columns

    Args:
        df (pandas.DataFrame): data frame that should be extended with cumulative sums
        obs_col (str): the name of the first column for the calcualtion of cumulative
         sum
        pred_col (str): the name of the second column for the calcualtion of cumulative
         sum

    Returns:
        pandas.DataFrame: extended by the two columns with the cumulative sum
    """
    df["accum_obs_loss"] = df[obs_col].cumsum()
    df["accum_pred_loss"] = df[pred_col].cumsum()
    df["perc_accum_obs_loss"] = df["accum_obs_loss"] / df["accum_obs_loss"].max()
    df["perc_accum_pred_loss"] = df["accum_pred_loss"] / df["accum_pred_loss"].max()
    return df


def _calculate_cumulative_percentage_spark(
    df: psd.DataFrame, obs_col: str, pred_col: str, window_: pyspark.sql.window.Window
) -> psd.DataFrame:
    """
    The spark implementation of the functionc _calculate_cumulative_percentage
    """
    df = df.withColumn("accum_obs_loss", f.sum(df[obs_col]).over(window_)).withColumn(
        "accum_pred_loss", f.sum(df[pred_col]).over(window_)
    )
    max_obs_loss = df.agg({"accum_obs_loss": "max"}).collect()[0][0]
    max_pred_loss = df.agg({"accum_pred_loss": "max"}).collect()[0][0]
    df = df.withColumn(
        "perc_accum_obs_loss", df.accum_obs_loss / max_obs_loss
    ).withColumn("perc_accum_pred_loss", df.accum_pred_loss / max_pred_loss)
    return df


def _lcr_plotting(df_obs: pd.DataFrame, df_pred: pd.DataFrame) -> pd.DataFrame:
    """
    The helper function that prepares data frame with data to plot

    Args:
        df_obs (pandas.DataFrame): data frame with the observed loss curve
        df_pred (pandas.DataFrame): data frame with the predicted loss curve

    Returns:
        pandas.DataFrame: data frame with data for plotting
    """
    # Append a [0, 0] to the beginning of each DataFrame for plotting purposes,
    # since it may not actually exist in the real data.
    df_obs = pd.concat(
        [
            pd.DataFrame.from_dict({"perc_accum_pop": [0], "perc_accum_obs_loss": [0]}),
            df_obs,
        ],
        sort=False,
    )
    df_pred = pd.concat(
        [
            pd.DataFrame.from_dict({"perc_accum_pop": [0], "perc_accum_obs_loss": [0]}),
            df_pred,
        ],
        sort=False,
    )

    # Collect plotting data into pandas.DataFrame.
    df_obs = df_obs.rename(
        columns={
            "perc_accum_pop": "Percent Accumulated Population",
            "perc_accum_obs_loss": "Perfect Model",
        }
    )
    df_pred = df_pred.rename(
        columns={
            "perc_accum_pop": "Percent Accumulated Population",
            "perc_accum_obs_loss": "Current Model",
        }
    )
    df_random = pd.DataFrame.from_dict(
        {"Percent Accumulated Population": [0, 1], "Random Model": [0, 1]}
    )
    return pd.concat(
        objs=[df_obs, df_pred, df_random],
        axis=0,
        join="outer",
        ignore_index=True,
        sort=False,
    )


def _pandas_kolmogorov_smirnov_2_sample(
    data1: np.array,
    data2: np.array,
    alternative: Literal["two-sided", "less", "greater"] = "two-sided",
    mode: str = "auto",
) -> Tuple[float]:
    """
    Two-sample Kolmogorov Smirnov test, pandas implementation.

    Two-sample Kolmogorov Smirnov test as described in Model Testing Framework
    v2.5.pdf, section 7.20 - Kolmogorov-Smirnov Statistic for discriminatory
    power. The Two-sample Kolmogorov Smirnov test tests for the null hypothesis
    that 2 independent samples are drawn from the same continuous distribution.
    The distribution is assumed to be continuous. H0: The two samples come from
    the same distribution.

    This function uses the scipy.stats.ks_2samp, which is calculated according
    to the methodology specified in "Hodges, J.L. Jr.,  "The Significance
    Probability of the Smirnov Two-Sample Test," Arkiv fiur Matematik, 3,
    No. 43 (1958), 469-86".

    Args:

        data1, data2: (array-like, 1-Dimensional) Two arrays of sample
            observations from the same continuous distribution. Sample sizes can
            be different. data1 and data2 can be of type "pd.Series", "list",
            "np.array".

        alternative (str): (default="two-sided") Defines the alternative
            hypothesis. The following options are available:

            * 'two-sided' - performs a two-sided test
            * 'less' - one-sided test, where the alternative is that the
                empirical cumulative distribution function F(x) of the data1 variable
                is "less" than the empirical cumulative distribution function G(x)
                of the data2 variable, ``F(x)<=G(x)``
            * 'greater' - one-sided test, where the alternative is that the
                empirical cumulative distribution function F(x) of the data1 variable
                is "greater" than the empirical cumulative distribution function G(x)
                of the data2 variable, ``F(x)>=G(x)``

        mode (str): (default="auto") Defines the method used for calculating
        the p-value. The following options are available:

            * 'auto' : the computation is exact if the sample sizes are
                less than 10000.  For larger sizes, the computation uses the
                Kolmogorov-Smirnov distributions to compute an
                approximate value.
            * 'exact' : use exact distribution of test statistic
            * 'asymp' : use asymptotic distribution of test statistic

     Returns:
        statistic (float): The KS statistic

        p_value (float): The p-value

    Special information to user:
        Note that the outcome of the KS test is sensitive to using the exact
        or asymptotic approach, i.e. the KS test may reject the null hypothesis
        using the exact approach, while accepting the null hypothesis using
        the asymptotic approach. This sensitivity stems from using the exact
        approach, where a rise in the sample size can cause a discrete
        jump in the p-value. The 'asymp' mode appears stable over the
        number of observations. Therefore, caution is required  interpreting the
        results (especially when sample sizes are close to 10,000 observations).
         When encountering such a situation, it is recommended to swithc to
         mode 'asymp'. This situation is illustrated in the example below.

        The Python implementation coincides with the official R package
        (KS.test). The two implementations have been tested and the results
        have been compared; and both produce the same results.

        Example of a discrete jump in the p-value using the mode='exact'::
            from crv.validation.differentiation import _pandas_kolmogorov_smirnov_2_sample
            import numpy as np

            np.random.seed(123)

            n_1_list = [180, 1800, 18000]
            n_2 = 5000
            mu1, sigma1 = 0, 0.1
            mu2, sigma2 = 0, 0.18

            for n_1 in n_1_list:
                data1 = np.random.normal(mu1, sigma1, n_1)
                data2 = np.random.normal(mu2, sigma2, n_2)
                statistic, p_value = _pandas_kolmogorov_smirnov_2_sample(data1,
                                                                         data2)
                accept = "H0 accepted" if p_value>0.05 else "H0 rejected"
                print(f"{accept} with n_1: {n_1} and n_2: {n_2}: "
                      "{round(statistic, 6)}, {round(p_value, 6)}")

        This Python code yields the following result:
            H0 rejected with n_1: 180 and n_2: 5000: 0.141378, 0.001712
            H0 accepted with n_1: 1800 and n_2: 5000: 0.143644, 1.0
            H0 rejected with n_1: 18000 and n_2: 5000: 0.147944, 0.0

    Raises:
        ValueError - if mode is not one of the options: "auto", "exact",
            "asymp"

        ValueError - if alternative is not one of the options: "two-sided",
            "less", "greater"

    Notes:
        Author: Reinout Kool (G85538)
    """
    # Raise error
    if mode not in ["auto", "exact", "asymp"]:
        raise ValueError(
            f"Invalid value for mode: {mode}. Mode must be "
            f'one of the options: "auto", "exact", "asymp".'
        )
    if alternative not in ["two-sided", "less", "greater"]:
        raise ValueError(
            f"Invalid value for alternative: {alternative} "
            f"alternative must be one of the options: "
            f'"two-sided", "less", "greater".'
        )

    # calculate the 2-sample statistic and p-value
    statistic, p_value = ks_2samp(
        data1=data1, data2=data2, alternative=alternative, mode=mode
    )

    return statistic, p_value


def kolmogorov_smirnov_2_sample(
    data1, data2, spark_session=None, alternative="two-sided", mode="auto"
):
    """
    Two-sample Kolmogorov Smirnov test as described in Model Testing Framework
    v2.5.pdf, section 7.20 - Kolmogorov-Smirnov Statistic for discriminatory
    power. The Two-sample Kolmogorov Smirnov test tests for the null hypothesis
    that two independent samples are drawn from the same continuous distribution.
    The distribution is assumed to be continuous. H0: The two samples come from
    the same distribution.

    This function is based on the scipy.stats.ks_2samp, which is calculated
    according to the methodology specified in "Hodges, J.L. Jr.,  "The
    Significance Probability of the Smirnov Two-Sample Test," Arkiv fiur
    Matematik, 3, No. 43 (1958), 469-86".

    When running the function on two samples of data that are of type
    "pd.Series", "list", "np.array", use parameters "data1" and "data2".

    When running the function on two samples of data that are of type
    "pyspark.sql.DataFrame", use the parameters "spark_session", "spark_df",
    "spark_col_1", "spark_col_2".

    Args:
        data1, data2 (array-like, 1-Dimensional): Two arrays of
            sample observations from the same continuous distribution.
            Sample sizes can be different. data1 and data2 can be of type
            "pd.Series" (e.g. df['column_name]), "list", "np.array" or
            "pyspark.DataFrame" (e.g. df.select('column_name'))

        spark_session (spark.Session): (Default=None) The
            spark session created when running the function on a spark
            dataframe. When the function is run on other types of data (e.g.
            pd.Series, np.array, list), this parameter is None.

        alternative (str): (default="two-sided") Defines the alternative
            hypothesis. The following options are available:

            * 'two-sided' - performs a two-sided test
            * 'less' - one-sided test, where the alternative is that the
                empirical cumulative distribution function F(x) of the data1 variable
                is "less" than the empirical cumulative distribution function G(x)
                of the data2 variable, ``F(x)<=G(x)``
            * 'greater' - one-sided test, where the alternative is that the
                empirical cumulative distribution function F(x) of the data1 variable
                is "greater" than the empirical cumulative distribution function G(x)
                of the data2 variable, ``F(x)>=G(x)``

        mode (str): (default="auto") Defines the method used for calculating
        the p-value. The following options are available:

            * 'auto' : the computation is exact if the sample sizes are
                less than 10000.  For larger sizes, the computation uses the
                Kolmogorov-Smirnov distributions to compute an
                approximate value.
            * 'exact' : use exact distribution of test statistic
            * 'asymp' : use asymptotic distribution of test statistic

     Returns:
        statistic (float): The KS statistic

        p_value (float): The p-value

    Raises:
        ValueError - 'data1' and 'data2' must be of same type, such as
            'pd.Series' (e.g. df['column_name]), 'list', 'np.array'
            or 'pyspark.sql.DataFrame' (e.g. df.select('column_name'))

    Example:
        Pandas - Calculate results like this::

            import numpy as np
            import pandas as pd

            np.random.seed(42)

            mu1, sigma1 = 0, 0.1
            mu2, sigma2 = 0.1, 0.2
            data1 = np.random.normal(mu1, sigma1, 9000)
            data2 = np.random.normal(mu2, sigma2, 9000)
            numpy_data = np.array([data1, data2]).transpose()

            df = pandas.DataFrame(data=numpy_data, columns=["data1", "data2"])

            statistic, p_value = kolmogorov_smirnov_2_sample(
                                    data1=df['data1'],
                                    data2=df['data2'])

        Spark - Calculate results like this (equal sample size of data1 and data2)::

            from pyspark.sql import SparkSession
            import numpy as np
            import pandas as pd

            spark = SparkSession.builder.getOrCreate()

            mu1, sigma1 = 0, 0.1
            mu2, sigma2 = 0.1, 0.2
            data1 = np.random.normal(mu1, sigma1, 100)
            data2 = np.random.normal(mu2, sigma2, 100)

            numpy_data = np.array([data1, data2]).transpose()
            df_pandas = pandas.DataFrame(data=numpy_data, columns=["data1", "data2"])
            df_spark = self.spark.createDataFrame(df_pandas)
            data1 = df_spark.select("data1")
            data2 = df_spark.select("data2")

            statistic, p_value = kolmogorov_smirnov_2_sample(
                                            data1=data1,
                                            data2=data2,
                                            spark_session=spark,
                                            alternative='two-sided',
                                            mode="auto")

        Spark - Calculate results like this (different sample size of data1 and data2)::

            from pyspark.sql import SparkSession
            import numpy as np
            import pandas as pd

            spark = SparkSession.builder.getOrCreate()

            mu1, sigma1 = 0, 0.1
            mu2, sigma2 = 0.1, 0.2
            data1 = np.random.normal(mu1, sigma1, 50)
            data2 = np.random.normal(mu2, sigma2, 100)

            df_pandas_1 = pandas.DataFrame(data=data1, columns=["data1"])
            df_spark_1 = spark.createDataFrame(df_pandas_1)
            df_pandas_2 = pandas.DataFrame(data=data1, columns=["data2"])
            df_spark_2 = spark.createDataFrame(df_pandas_2)
            data1 = df_spark_1.select("data1")
            data2 = df_spark_2.select("data2")

            statistic, p_value = kolmogorov_smirnov_2_sample(
                                            data1=data1,
                                            data2=data2,
                                            spark_session=spark,
                                            alternative='two-sided',
                                            mode="auto")

    Notes:
        Author: Reinout Kool (G85538)
    """
    # Raise errors
    if not type(data1) == type(data2):
        raise ValueError(
            "'data1' and 'data2' must be of same type, such as "
            "'pd.Series' (e.g. df['column_name]), 'list' "
            ", 'np.array' or 'pyspark.DataFrame' (e.g. "
            "df.select('column_name'))"
        )

    run_type = "spark" if isinstance(data1, psd.DataFrame) else "no_spark"

    # Calling the pandas or spark function
    if run_type == "no_spark":
        return _pandas_kolmogorov_smirnov_2_sample(data1, data2, alternative, mode)
    elif run_type == "spark":
        return _spark_kolmogorov_smirnov_2_sample(
            spark_session, data1, data2, alternative, mode
        )


def _spark_kolmogorov_smirnov_2_sample(
    spark, data1, data2, alternative="two-sided", mode="auto"
):
    """
    Two-sample Kolmogorov Smirnov test, pyspark implementation.

    Two-sample Kolmogorov Smirnov test as described in Model Testing Framework
    v2.5.pdf, section 7.20 - Kolmogorov-Smirnov Statistic for discriminatory
    power. The Two-sample Kolmogorov Smirnov test tests for the null hypothesis
    that two independent samples are drawn from the same continuous distribution.
    The distribution is assumed to be continuous. H0: The two samples come from
    the same distribution.

    This function replicates the scipy.stats.ks_2samp, which is calculated
    according to the methodology specified in "Hodges, J.L. Jr.,  "The
    Significance Probability of the Smirnov Two-Sample Test," Arkiv fiur
    Matematik, 3, No. 43 (1958), 469-86".

    Args:
        spark (spark.Session): The spark session created before running
            the function.

        df_1 (pyspark.DataFrame): The input data table. Note that if
            sample sizes are different, data array 1 is a column in df_1
            when using spark. If sample sizes are similar in data array 1 and
            data array 2, df_1 can be the same dataframe as df_2.

        col_name1 (str): The column containing the first sample of observations
        from the same continuous distribution in df_1.

        df_2 (pyspark.sql.DataFrame): The second input data table. Note that if
            sample sizes are different, data array 2 is a column in df_2
            when using spark.

        col_name2 (str): The column containing the second sample of
            observations from the same continuous distribution in df_2. If
            sample sizes are similar in data array 1 and data array 2, df_1
            can be the same dataframe as df_2.

        alternative (str): (default="two-sided") Defines the alternative
            hypothesis. The following options are available:

            * 'two-sided' - performs a two-sided test
            * 'less' - one-sided test, where the alternative is that the
                empirical cumulative distribution function F(x) of the data1 variable
                is "less" than the empirical cumulative distribution function G(x)
                of the data2 variable, ``F(x)<=G(x)``
            * 'greater' - one-sided test, where the alternative is that the
                empirical cumulative distribution function F(x) of the data1 variable
                is "greater" than the empirical cumulative distribution function G(x)
                of the data2 variable, ``F(x)>=G(x)``

        mode (str): (default="auto") Defines the method used for calculating
        the p-value. The following options are available:

            * 'auto' : the computation is exact if the sample sizes are
                less than 10000.  For larger sizes, the computation uses the
                Kolmogorov-Smirnov distributions to compute an
                approximate value.
            * 'exact' : use exact distribution of test statistic
            * 'asymp' : use asymptotic distribution of test statistic

     Returns:
        statistic (float): The KS statistic

        p_value (float): The p-value

    Raises:
        ValueError - if spark is not of type "pyspark.sql.session.SparkSession"

        ValueError - if df_1 is not of type "pyspark.sql.DataFrame"

        ValueError - if df_2 is not of type "pyspark.sql.DataFrame"

        ValueError - if df_1 is an empty dataframe of type
            "pyspark.sql.DataFrame"

        ValueError - if df_2 is an empty dataframe of type
            "pyspark.sql.DataFrame"

        ValueError - if mode is not one of the options: "auto", "exact",
            "asymp"

        ValueError - if alternative is not one of the options: "two-sided",
            "less", "greater"

    Notes:
        Author: Reinout Kool (G85538)
    """
    # Error checks
    if not isinstance(spark, SparkSession):
        raise ValueError(
            f"Input to argument 'spark' must be a "
            f"pyspark.sql.session.SparkSession, not "
            f"{type(spark)}."
        )

    if not isinstance(data1, psd.DataFrame):
        raise ValueError(
            f"Input to argument 'data1' must be a "
            f"pyspark.sql.DataFrame, not {type(data1)}."
        )

    if not isinstance(data2, psd.DataFrame):
        raise ValueError(
            f"Input to argument 'data2' must be a "
            f"pyspark.sql.DataFrame, not {type(data2)}."
        )

    n1 = data1.count()
    n2 = data2.count()
    if min(n1, n2) == 0:
        raise ValueError("Data passed to ks_2samp must not be empty")

    if mode not in ["auto", "exact", "asymp"]:
        raise ValueError(
            f"Invalid value for mode: {mode}. Mode must be "
            f'one of the options: "auto", "exact", "asymp".'
        )

    if alternative not in ["two-sided", "less", "greater"]:
        raise ValueError(
            f"Invalid value for alternative: {alternative} "
            f"alternative must be one of the options: "
            f'"two-sided", "less", "greater".'
        )

    # 'auto' will attempt to be exact if n1,n2 <= LARGE_N
    LARGE_N = 10000

    # 2. Sort values.
    col_name1 = data1.schema.names[0]
    col_name2 = data2.schema.names[0]

    # Determine number of partitions for repartitioning
    #    if n1 >= n2:
    #        num_partitions = data1.rdd.glom().count()
    #    else:
    #        num_partitions = data2.rdd.glom().count()

    data1 = (
        data1.orderBy(col_name1, ascending=[True])
        .withColumn("idx", f.monotonically_increasing_id())
        .select(col_name1)
    )
    #        .coalesce(num_partitions)
    data2 = (
        data2.orderBy(col_name2, ascending=[True])
        .withColumn("idx", f.monotonically_increasing_id())
        .select(col_name2)
    )
    #        .coalesce(num_partitions)

    # using searchsorted solves equal data problem
    data_all = data1.union(data2)
    cdf1 = (
        spark_searchsorted(spark, data1, col_name1, data_all, col_name1, "right")
        .select(["search_sort_col"])
        .withColumn("search_sort_col", f.round(f.col("search_sort_col") / n1, 6))
        .withColumnRenamed("search_sort_col", "ss_col1")
    )
    #                .coalesce(num_partitions)
    cdf2 = (
        spark_searchsorted(spark, data2, col_name2, data_all, col_name1, "right")
        .select(["search_sort_col"])
        .withColumn("search_sort_col", f.round(f.col("search_sort_col") / n2, 6))
        .withColumnRenamed("search_sort_col", "ss_col2")
    )
    #                .coalesce(num_partitions)

    cdf1 = spark_create_index_col(cdf1, order="asc", index_name="idx")
    cdf2 = spark_create_index_col(cdf2, order="asc", index_name="idx")

    del data1, data2, data_all

    cddiffs = (
        cdf1.join(f.broadcast(cdf2), on="idx", how="left")
        .withColumn("ccdiffs", f.round(f.col("ss_col1") - f.col("ss_col2"), 12))
        .select("ccdiffs")
    )  #    .coalesce(num_partitions)

    del cdf1, cdf2

    cddiffs.persist()
    minS = -(cddiffs.agg({"ccdiffs": "min"}).collect()[0][0])
    maxS = cddiffs.agg({"ccdiffs": "max"}).collect()[0][0]
    cddiffs.unpersist()

    del cddiffs

    alt2Dvalue = {"less": minS, "greater": maxS, "two-sided": max(minS, maxS)}
    d = alt2Dvalue[alternative]
    g = gcd(n1, n2)
    n1g = n1 // g
    n2g = n2 // g
    prob = -np.inf
    original_mode = mode
    if mode == "auto":
        if max(n1, n2) <= LARGE_N:
            mode = "exact"
        else:
            mode = "asymp"
    elif mode == "exact":
        # If lcm(n1, n2) is too big, switch from exact to asymp
        if n1g >= np.iinfo(np.int).max / n2g:
            mode = "asymp"
            warnings.warn(
                "Exact ks_2samp calculation not possible with samples sizes "
                "%d and %d. Switching to 'asymp' " % (n1, n2),
                RuntimeWarning,
            )

    saw_fp_error = False
    if mode == "exact":
        lcm = (n1 // g) * n2
        h = int(np.round(d * lcm))
        d = h * 1.0 / lcm
        if h == 0:
            prob = 1.0
        else:
            try:
                if alternative == "two-sided":
                    if n1 == n2:
                        prob = _compute_prob_outside_square(n1, h)
                    else:
                        prob = 1 - _compute_prob_inside_method(n1, n2, g, h)
                else:
                    if n1 == n2:
                        prob = 1.0
                        for j in range(h):
                            prob = (n1 - j) * prob / (n1 + j + 1)
                    else:
                        num_paths = _count_paths_outside_method(n1, n2, g, h)
                        bin = special.binom(n1 + n2, n1)
                        if (
                            not np.isfinite(bin)
                            or not np.isfinite(num_paths)
                            or num_paths > bin
                        ):
                            raise FloatingPointError()
                        prob = num_paths / bin

            except FloatingPointError:
                # Switch mode
                mode = "asymp"
                saw_fp_error = True
            finally:
                if saw_fp_error:
                    if original_mode == "exact":
                        warnings.warn(
                            "ks_2samp: Exact calculation overflowed. "
                            "Switching to mode=%s" % mode,
                            RuntimeWarning,
                        )
                else:
                    if prob > 1 or prob < 0:
                        mode = "asymp"
                        if original_mode == "exact":
                            warnings.warn(
                                "ks_2samp: Exact calculation incurred large"
                                " rounding error. Switching to mode=%s" % mode,
                                RuntimeWarning,
                            )

    if mode == "asymp":
        # The product n1*n2 is large.  Use Smirnov's asymptoptic formula.
        if alternative == "two-sided":
            en = np.sqrt(n1 * n2 / (n1 + n2))
            prob = kstwobign.sf(en * d)
        else:
            m, n = max(n1, n2), min(n1, n2)
            z = np.sqrt(m * n / (m + n)) * d
            # Use Hodges' suggested approximation Eqn 5.3
            expt = -2 * z ** 2 - 2 * z * (m + 2 * n) / np.sqrt(m * n * (m + n)) / 3.0
            prob = np.exp(expt)

    prob = 0 if prob < 0 else (1 if prob > 1 else prob)
    return Ks_2sampResult(d, prob)
