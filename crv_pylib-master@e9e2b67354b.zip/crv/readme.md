# `CRV` - Library functions
This folder contains the actual user functions of the library.

### `analysis`
Data exploration and quality analysis.

### `io`
Import and export of data, and displaying results in graphs and tables.

### `utils`
General utility functions used in the rest of the library.

### `validation`
Performance testing and data summaries.
