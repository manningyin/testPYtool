"""
############
Introduction
############
The EBA guidelines "EBA-RTS-2016-03_IRB" Article 76 - describe in  the following dimensions along which data quality of Pillar I credit risk datasets can be assessed:
    
* completeness: the values are present in the attributes that require them.
* accuracy: the data is substantively error-free.
* consistency: a  given  set  of  data  can  be  matched  across  different  data  sources  of  the institution.
* timeliness: the data values are up to date.
* uniqueness: the  aggregate  data  is  free  from  any  duplication  given  by  filters  or  other transformations of source data.
* validity: the data is founded on an adequate system of classification, rigorous enough to compel acceptance.
* traceability: the  history,  processing  and  location  of  data  under  consideration  can  be  easily traced.

This file contains the validation tools that provide insight into the **timeliness** of datasets.
    
Validation tools
================
This section gives an overview of the validation tools available to determine timeliness of datasets. These validation tools are model agnostic and thus can be used on any type of dataset.

* **Outdated values** - This function calculates the missing values per column for a given Pandas or Spark DataFrame. 
    
Notes
=====
Author: G85544

###################
Test implementation
###################
"""
from typing import List, Union
import numpy as np
import pandas as pd
from datetime import date, datetime
import pyspark.sql.dataframe as psd
import pyspark.sql.functions as f

__all__ = ["outdated_values"]


def _pandas_outdated_values(
    df: pd.DataFrame,
    date_col_name: str,
    date_to_compare: List[Union[np.datetime64, str]],
    max_age_allowed: int,
) -> tuple:
    """
    Function that identifies outdated values in a pd.DataFrame.

    The function takes as input a pd.DataFrame and computes the
    difference (in months) between the date in date_col_name and
    the desired date (date_to_compare) per each row in the data
    frame.

    The input data frame will be extended to include a column
    with the age of the data (in months) and a column with a value
    of 1 if the age of the data exceeds the user specified
    max_age_allowed and 0 otherwise.

    The function also returns the absolute number of outdated records
    and the percentage of outdated records relative to the number of total
    records.

    Args:
        df (pd.DataFrame). Pandas DataFrame with data to be assessed for timeliness.

        date_col_name (str). Name of the column in df that contains the date of the
            data (or records). Note that the type of the column has to be converted to
            datetime64 dtype.

        date_to_compare (np.datetime64 or str 'YYYY-MM-DD'). Date to which date of records will
            be compared to. Defaults to current date. Note that if a date string is specified it
            has to be of format 'YYYY-MM-DD'.

        max_age_allowed (int). Maximum allowed age of records in months. Needed to create the
            outdated record flag in updated pd.DataFrame.

    Returns:
        df_updated (pd.DataFrame). Input Data Frame updated to contain the age of each of
            the rows (column df_updated['date_diff']) and a flag of 1 if this age exceeds the
            maximum allowed (column df_updated['outdated_flag']).

        num_outdated_values (int). Number of records (rows) which age (column df_updated['date_diff'])
            exceeds the maximum age allowed.

        per_outdated_values (float). Percentage of records with age exceeding the maximum allowed.

    Raises:

        ValueError - if 'date_col_name' is not a column of df.

        ValueError - if 'date_col_name' is not of type np.datetime64.
    """
    # Check if date_col_name column is in df
    if not any(date_col_name in s for s in list(df.columns)):
        raise ValueError(f"{date_col_name} should be a column" f" in input 'df'. ")

    # Check for correct date_col_name dtype
    if not (str(df[date_col_name].dtype).startswith("datetime64")):
        raise ValueError(f"{date_col_name} column is not of type np.datetime64")

    data_original = df.copy()
    # Compute age of records
    data_original["date_diff"] = np.round_(
        (date_to_compare - data_original[date_col_name]) / np.timedelta64(1, "M")
    )

    # Flag outdated records
    data_original["outdated_flag"] = np.where(
        data_original["date_diff"] > max_age_allowed, 1, 0
    )

    # Total and relative number of outdated records
    num_outdated_values = data_original["outdated_flag"].sum()
    per_outdated_values = (num_outdated_values / data_original.shape[0]) * 100

    return data_original, num_outdated_values, per_outdated_values


def _spark_outdated_values(
    df: psd.DataFrame,
    date_col_name: str,
    date_to_compare: List[Union[np.datetime64, str]],
    max_age_allowed: int,
) -> tuple:
    """
    Function that identifies outdated values in a pyspark.sql.DataFrame.

    The function takes as input a pyspark.sql.DataFrame and computes the
    difference (in months) between the date in date_col_name and
    the desired date (date_to_compare) per each row in the data
    frame.

    The input data frame will be extended to include a column
    with the age of the data (in months) and a column with a value
    of 1 if the age of the data exceeds the user specified
    max_age_allowed and 0 otherwise.

    The function also returns the absolute number of outdated records
    and the percentage of outdated records relative to the number of total
    records.

    Args:
        df (pyspark.sql.DataFrame). Pandas DataFrame with data to be assessed for timeliness.

        date_col_name (str). Name of the column in df that contains the date of the
            data (or records). Note that the type of the column has to be converted to
            datetime64 dtype.

        date_to_compare (np.datetime64 or 'YYYY-MM-DD'). Date to which date of records will
            be compared to. Defaults to current date. Note that if a date string is specified it
            has to be of format 'YYYY-MM-DD'.

        max_age_allowed (int). Maximum allowed age of records in months. Needed to create the
            outdated record flag in updated pd.DataFrame.

    Returns:
        df_updated (pyspark.sql.DataFrame). Input Data Frame updated to contain the age of each of
            the rows (column df_updated['date_diff']) and a flag of 1 if this age exceeds the
            maximum allowed (column df_updated['outdated_flag']).

        num_outdated_values (int). Number of records (rows) which age (column df_updated['date_diff'])
            exceeds the maximum age allowed.

        per_outdated_values (float). Percentage of records with age exceeding the maximum allowed.

    Raises:

        ValueError - if 'date_col_name' is not a column of df.

        ValueError - if 'date_col_name' is not of type date.
    """

    # Check if date_col_name column is in df
    if not any(date_col_name in s for s in list(df.columns)):
        raise ValueError(f"{date_col_name} should be a column" f" in input 'df'. ")

    # Check for correct date_col_name dtype
    if not (str(dict(df.dtypes)[date_col_name]).startswith("date")):
        raise ValueError(f"{date_col_name} column is not of type date")

    # Compute age of records
    df = df.withColumn("date_to_compare", f.to_date(f.lit(date_to_compare)))

    df = df.withColumn(
        "date_diff", f.round(f.months_between(df.date_to_compare, df[date_col_name]))
    )
    df = df.drop("date_to_compare")

    # Flag outdated records
    df = df.withColumn(
        "outdated_flag", f.when(df.date_diff > max_age_allowed, 1).otherwise(0)
    )

    ## Total and relative number of outdated records
    num_outdated_values = df.agg(f.sum("outdated_flag")).collect()[0][0]
    per_outdated_values = (num_outdated_values / df.count()) * 100

    return df, num_outdated_values, per_outdated_values


def outdated_values(
    df: pd.DataFrame,
    date_col_name: str,
    date_to_compare: List[Union[np.datetime64, str]] = None,
    max_age_allowed: int = 24,
) -> Union[pd.DataFrame, psd.DataFrame]:
    """
    Function that identifies outdated values in a pandas.DataFrame or
    pyspark.sql.DataFrame.

    The function takes as input a pandas.DataFrame or a pyspark.sql.DataFrame
    and computes the difference (in months) between the date in date_col_name and
    the desired date (date_to_compare) per each row in the data
    frame.

    The input data frame will be extended to include a column
    with the age of the data (in months) and a column with a value
    of 1 if the age of the data exceeds the user specified
    max_age_allowed and 0 otherwise.

    The function also returns the absolute number of outdated records
    and the percentage of outdated records relative to the number of total
    records.

    Args:
        df (pandas.DataFrame or pyspark.sql.DataFrame). DataFrame with data to be assessed
            for timeliness.

        date_col_name (str). Name of the column in df that contains the date of the
            data (or records). Note that the type of the column has to be converted to
            datetime64 dtype.

        date_to_compare (np.datetime64 or 'YYYY-MM-DD'). Date to which date of records will
            be compared to. Defaults to None & in this case it will be set equal to the
            current date. Note that if a date string is specified it has to be of format
            'YYYY-MM-DD'.

        max_age_allowed (int). Maximum allowed age of records in months. Needed to create the
            outdated record flag in updated pd.DataFrame.

    Returns:
        df_updated (pandas.DataFrame or pyspark.sql.DataFrame). Input Data Frame updated to contain
            the age of each of the rows (column df_updated['date_diff']) and a flag of 1 if this
            age exceeds the maximum allowed (column df_updated['outdated_flag']).

        num_outdated_values (int). Number of records (rows) which age (column df_updated['date_diff'])
            exceeds the maximum age allowed.

        per_outdated_values (float). Percentage of records with age exceeding the maximum allowed.

    Raises:

        ValueError - if 'date_to_compare' is not a string, np.datetime64 or datetime.

        ValueError - if 'date_to_compare' is not a string of format YYYY-MM-DD.

        ValueError - if df is not a pandas.DataFrame or pyspark.sql.DataFrame.

    Examples:
        Call function in Python like this::

            df_with_age, outdated_num_records, per_outdated_records = outdated_values(my_df, 'date',
                    '2018-04-30',
                    max_age_allowed = 30):

    Notes:
        Author: Diana Lucatero <G85544>
    """
    if date_to_compare is None:
        date_to_compare = pd.to_datetime(date.today())

    # Check for correct date_to_compare type
    if not isinstance(date_to_compare, (str, np.datetime64, datetime)):
        raise ValueError(
            "date_to_compare must be either a string, np.datetime64 or datetime"
        )

    # Check for correct date string
    if isinstance(date_to_compare, str):
        if (
            (len(date_to_compare) != 10)
            or (date_to_compare[4] != "-")
            or (date_to_compare[7] != "-")
            or (int(date_to_compare[5:7]) > 12)
        ):
            raise ValueError(
                "If date_to_compare is a string, it should be a string with format YYYY-MM-DD"
            )

    # Direct arguments to summary functions. Raise error if incorrect type found.
    if isinstance(df, pd.DataFrame):
        return _pandas_outdated_values(
            df, date_col_name, date_to_compare, max_age_allowed
        )
    elif isinstance(df, psd.DataFrame):
        return _spark_outdated_values(
            df, date_col_name, date_to_compare, max_age_allowed
        )
    else:
        raise TypeError(
            f"Argument 'df' must be either a pandas or a pyspark DataFrame, not {type(df)}."
        )
