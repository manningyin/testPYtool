# `crv.analysis` module

## Functionality
Functions and scripts for automated analysis of raw credit risk data, including tools to perform:
* exploratory data analysis
* data quality analysis

## Submodules
### `accuracy.py`
Functions for determining that the data is error free.

### `anomaly_detection.py`
Functions for automatically detecting and labeling potential outliers in raw data, both globally and sequentially.

### `completeness.py`
Functions for determining that the attributes which require values actually contain them.

### `timeliness.py`
Functions for determining that the values in the data are up to date.

### `uniqueness.py`
Functions for determining if the aggregate data is free from any duplication.
