"""
#################
Anomaly Detection
#################
A set of functions for discovering anomalies in data. Detection is available for both single and multivariate data.

Detection functions return a list of indices that fit the outlier criteria of the function. These indices can be passed to the plotting funcitons to display where the outliers are found in the data.

Detection
=========
 * ``detect_frac_change``: Detects a specified fractional change (e.g. 5%, 10%) from the previous data point.
 * ``global_normal_outliers``: Flags data points that are outside a specified number of standard deviations.
 * ``step_outliers``: Flag a data point if it is outside a specified number of standard deviations as calculated across the previous N data points.
 * ``isolation_forest_outliers``: Applies the isolation forest algorithm to the data set globally to identify outliers.

Plotting
========
 * ``plot_outliers``: Plots the data and overlays outliers as described by a list of indices.
 * ``plotting_frac_outliers``: Plots the data and overlays outliers and 4 levels of fractional change. Can be combined with other outlier indices.
    
Notes
=====
Author: G01679

##############
Implementation
##############
"""


# Imports.
from typing import List
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.signal import savgol_filter
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.manifold import Isomap
from typing_extensions import Literal

__all__ = [
    "detect_frac_change",
    "global_normal_outliers",
    "step_outliers",
    "isolation_forest_outliers",
    "plot_outliers",
    "plotting_frac_outliers",
]


def plot_outliers(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    outlier_idx: List[int],
    figsize: tuple = (12, 6),
) -> None:
    """
    Plots the data with outliers in different colors.

    Args:
        df (pandas.DataFrame) The data.

        x_col (str) Column name containing x-axis data.

        y_col (str) Column name containing y-axis data.

        outlier_idx (pandas.DataFrame.index) The indices of the outliers.

        figsize (tuple) The figure size (width, height) in inches.

    Returns:
        None
    """
    # Define zoom selection.
    fig, ax = plt.subplots(nrows=1, ncols=1, figsize=figsize)

    # Plot base.
    ax.plot(df[x_col].to_numpy(), df[y_col].to_numpy(), linestyle="--", color="blue")
    # Plot outliers.
    ax.scatter(
        df.loc[outlier_idx, x_col].to_numpy(),
        df.loc[outlier_idx, y_col].to_numpy(),
        marker="d",
        color="red",
    )
    # Label everything.
    ax.set_xlabel(x_col)
    ax.set_ylabel(y_col)

    plt.show()
    return None


def savgol_flatten(arr: np.array, **kwargs) -> np.array:
    """
    Flattens the input data array by subtracting a Savitzky-Golay-filtered
    array from the raw data. This removes the overall trend (flattens to zero)
    but makes the steps and spikes more pronounced.

    Args:
        arr (numpy.array) 1-D or 2-D array of the data.

        kwargs (dict or arguments) Keyword arguments to
         scipy.signal.savgol_filter.

    Returns:
        (numpy.array) The flattened data.
    """
    arr_savgol = savgol_filter(arr, **kwargs)
    return arr - arr_savgol


def detect_frac_change(
    df: pd.DataFrame, col: str, frac_change: float = 0.2
) -> pd.DataFrame.index:
    """
    Returns the index of outliers defined by a fractional
    change since the previous value.

    Args:
        df (pandas.DataFrame): The data.
        col (str): The name of the target column.
        frac_change (float): The fraction change to trigger detection.

    Returns:
        (pandas.DataFrame.index): The indices of outliers from the DataFrame.
    """
    p = ((df[col] - df[col].shift(1)).abs() / df[col].shift(1)).abs() > frac_change
    return p[p == True].index


def global_normal_outliers(
    dff: pd.DataFrame,
    column: str,
    outlier_frac: float = 0.05,
    flatten: bool = False,
    window_length: int = 9,
    polyorder: int = 2,
) -> pd.DataFrame.index:
    """
    Finds observations that are a certain amount away from the
    mean of the 'column' data.
    ASSUMES NORMAL DISTRIBUTION.

    Args:
        dff (pandas.DataFrame) The data to inspect.

        column (str) The name of the column to inspect.

        outlier_frac (float) The fraction of expected outliers.
        Default is 0.05.

        flatten (bool) If True, applies flattening of the data via the
         savgol_flatten function.

        window_length (int) The length of the filter window. Must be odd.
         Only relevant if 'flatten' is True.

        polyorder (int) The order of the polynomial used to fit.
         Only relevant if 'flatten' is True.

    Returns:
        (pands.DataFrame.index) Index of the observations selected
        as outliers.
    """
    # Flatten the data if required.
    if flatten:
        data_arr = savgol_flatten(
            dff[column].to_numpy(), window_length=window_length, polyorder=polyorder
        )
        df_data = pd.DataFrame(data=data_arr, columns=[column], index=dff.index)
    else:
        df_data = dff[[column]].copy()
    # Calculate global statistics.
    col_std = df_data[column].std()
    col_mean = df_data[column].mean()
    inside_frac = 1 - outlier_frac
    f = norm.ppf(inside_frac + (1 - inside_frac) / 2)
    return df_data[
        (df_data[column] > col_mean + f * col_std)
        | (df_data[column] < col_mean - f * col_std)
    ].index


def step_outliers(
    dff: pd.DataFrame, column: str, window: int = 5, n_std_threshold: float = 1.96
) -> pd.DataFrame.index:
    """
    Finds outliers that are a sudden step or spike from the data trend.

    Args:
        dff (pandas.DataFrame) the data to inspect.

        column (str) The name of the column to inspect.

    Returns:
        (pandas.DataFrame.index) Index of the observations selected
        as outliers.
    """
    df = dff[[column]].copy()
    df["outlier"] = 0
    # Calculate rolling statistics.
    df["roll_mean"] = df[column].rolling(window).mean().shift(1)
    df["roll_std"] = df[column].rolling(window).std().shift(1)
    df.loc[
        df[column] > df["roll_mean"] + n_std_threshold * df["roll_std"], "outlier"
    ] = 1
    df.loc[
        df[column] < df["roll_mean"] - n_std_threshold * df["roll_std"], "outlier"
    ] = -1
    return df[df["outlier"].abs() == 1].index


def isolation_forest_outliers(
    df: pd.DataFrame,
    cols: List[str],
    flatten: bool = False,
    window_length: int = 9,
    polyorder: int = 2,
    **kwargs,
) -> pd.DataFrame.index:
    """
    Uses an Isolation Forest model to detect outlier observations.
    See documentation for sklearn.ensemble.IsolationForest for more details.

    Args:
        df (pandas.DataFrame) The data.

        cols (list) List of strings of column names to use for fitting.

        flatten (bool) If True, applies flattening of the data via the
         savgol_flatten function.

        window_length (int) The length of the filter window. Must be odd.
         Only relevant if 'flatten' is True.

        polyorder (int) The order of the polynomial used to fit.
         Only relevant if 'flatten' is True.

        kwargs (dict or keywords) Keyword arguments to pass to
         sklearn.ensemble.IsolationForest

    Returns:
        (pandas.DataFrame.index) The indices of the outlier observations.
    """
    # Setup Isolation Forest model.
    isof = IsolationForest(**kwargs, behaviour="new", contamination="legacy")
    # Flatten the data if required.
    if flatten:
        data_arr = savgol_flatten(
            df[cols].to_numpy(),
            window_length=window_length,
            polyorder=polyorder,
            axis=0,
        )
    else:
        data_arr = df[cols].to_numpy()
    isof.fit(data_arr)
    # Predict outliers. Outliers are -1, inliers are 1.
    df_outliers = pd.DataFrame(
        data=isof.predict(data_arr), columns=["outliers"], index=df.index
    )
    idx = df_outliers[df_outliers["outliers"] == -1].index
    return idx


def combine_outliers(
    list_of_indices: List[int], how: Literal["and", "or"] = "and"
) -> List:
    """
    Returns a list of indices that is the intersection of all
    indices in the list provided by the user.

    Args:
        list_of_indices (list): List of indices from multiple detection methods.

        how (str): How to combine the indices. Available options are: 'and', 'or'.

    Returns:
        (list): Intersecting list of indices.

    Raises:
        ValueError - If the value specified for arguemnt 'how' is not one
         of the valid options.
    """
    set_list = [set(s) for s in list_of_indices]
    if how == "and":
        combined = list(set.intersection(*set_list))
    elif how == "or":
        combined = list(set.union(*set_list))
    else:
        raise ValueError(
            "Invalid option chosen for argument 'how'. Must be one of: 'and', 'or'."
        )

    return combined


def plotting_frac_outliers(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    and_idx: List[int] = None,
    figsize: tuple = (12, 6),
) -> None:
    """
    Plots the outliers given a 10%, 15%, 20%, and 25% fractional change threshold.

    Args:
        df (pandas.DataFrame): The data set.

        x_col (str): The name of the column providing the x-axis data.

        y_col (str): The name of the column providing the y-axis data.

        and_idx (pandas.DataFrame.index, list): Indices to combine, default is None
         which does not combine the indices.

        figsize (tuple): Figure size (width, height) in inches.

    Returns:
        (None)
    """
    # Colours, fractions, and a container for results.
    colours = ["yellowgreen", "gold", "darkorange", "firebrick"][::-1]
    fracs = [0.10, 0.15, 0.20, 0.25][::-1]

    print("\nColour key:")
    for i in range(len(colours)):
        print(f"\t{colours[i]} : {fracs[i]*100}%")

    # Setup axes and plot data.
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(df[x_col].to_numpy(), df[y_col].to_numpy(), linestyle="--", color="blue")

    # Calculate indices unique to each fraction.
    super_set = set()
    for i_c, colour in enumerate(colours):
        idx = detect_frac_change(df, y_col, frac_change=fracs[i_c])
        if i_c > 0:
            idx = list(
                set(idx) - super_set
            )  # Remove events seen previously at higher threshold.
        super_set = set.union(super_set, set(idx))  # Add events to those already seen.

        # Combine indices if indices are passed in 'and_idx', else don't.
        if not isinstance(and_idx, type(None)):
            idx = combine_outliers([idx, and_idx], how="and")

        ax.scatter(
            df.loc[idx, x_col].to_numpy(),
            df.loc[idx, y_col].to_numpy(),
            marker="d",
            color=colour,
            s=70,
        )  # Plot each array.

    # Basic formatting.
    ax.set_xlabel(x_col)
    ax.set_ylabel(y_col)
    ax.grid(True, which="both", axis="both")

    plt.show()
