"""
############
Introduction
############

Art 76 in EBA guidelines "EBA-RTS-2016-03_IRB" describes the following 
dimensions along which data quality of Pillar I credit risk datasets should 
be assessed:

* completeness: the values are present in the attributes that require them.
* accuracy: the data is substantively error-free.
* consistency: a  given  set  of  data  can  be  matched  across  different  
  data  sources  of  the institution.
* timeliness: the data values are up to date.
* uniqueness: the  aggregate  data  is  free  from  any  duplication  given  
  by  filters  or  other transformations of source data.
* validity: the data is founded on an adequate system of classification, 
  rigorous enough to compel acceptance.
* traceability: the  history,  processing  and  location  of  data  under  
  consideration  can  be  easily traced.

This file contains definitions of functions that provide insight 
into the accuracy of a dataset.

Validation tools
================
This section gives an overview of the validation tools available to determine **accuracy** of datasets. These validation tools are model agnostic and thus can be used on any type of dataset.

* **Descriptive statistics** - This function computes the descriptive statistics of wanted columns with the choice of grouping/splitting variables for a given Pandas or Spark DataFrame. 
        
Notes
=====
Authors: AC30171, G80944

###################
Implementation
###################
"""

# Imports
import pandas as pd
import numpy as np
from itertools import compress
import warnings
from functools import reduce
import pyspark.sql.functions as f
import pyspark.sql.dataframe as psd
import pyspark.sql
from pyspark.sql.types import (
    IntegerType,
    StringType,
    DoubleType,
    DateType,
    BooleanType,
    FloatType,
    LongType,
)
from pyspark.sql import DataFrame
from pyspark.sql import DataFrameStatFunctions as statFunc
from pyspark.sql.column import Column, _to_java_column, _to_seq
from pyspark.sql import SparkSession
from typing import Callable, List, Optional, Union

__all__ = ["descriptive_statistics"]


def descriptive_statistics(
    df_original: Union[pd.DataFrame, pyspark.sql.DataFrame],
    selected_columns: Optional[List[str]] = None,
    quantiles: Optional[List[float]] = None,
    groupby_vars: Optional[List[Union[str, int]]] = None,
    spark_session: SparkSession = None,
) -> pd.DataFrame:
    """
    Function that generates descriptive statistics of pd.DataFrame and pyspark.sql.DataFrame.

    This function is part of the tool kit for data quality analysis.
    In particular, it is meant to be used to assess data accuracy, as defined
    in EBA guidelines "EBA-RTS-2016-03_IRB", Article 76.1 (b). The details of
    the required validation analysis are found in Section 3.2.3 Data quality
    in the Validation Guidelines - Credit Risk Models v1.0.

    The following statistics are reported per column in the input dataset:

    * For a numeric variable (types 'int32','int64', 'float64', 'datetime64', 'timedelta' for pandas,
        types 'DoubleType', 'IntegerType', 'FloatType' and 'LongType' for spark):
        * count = total number of observations;
        * mean;
        * std = standard deviation;
        * min;
        * requested quantiles/quantiles, including median;
        * max;
        * sum.

    * For a boolean variable (types 'boolean', 'bool' for pandas, 'BooleanType' for spark):
        * count = total number of observations;
        * top = most frequent value;
        * freq = count for the most frequent value;
        * count of trues.

    * For a categorical variable (all remaining data types, incl. 'object', 'category', 'period' for pandas,
        'StringType' for spark):
        * count = total number of observations;
        * unique = number of unique elements;
        * top = most frequent value;
        * freq = count for the most frequent value.

    * For a 'datetime' variable (type 'DateType' for spark):
        * count = total number of observations;
        * min = the earliest date in the sample;
        * max = the latest date in the sample;
        * top = most frequent value;
        * freq = count for the most frequent value.

    Args:
        df_original (pandas.DataFrame or pyspark.sql.DataFrame): Input table. It must be non-empty.

        selected_columns (list-like of strings): (Default=None) Names of columns in
        the dataset for which to return descriptive statistics. If None, all
        columns in the dataset will be included. All elements of selected_columns
        must be strings and must be present among column names of the input table.
        If statistics for one specific column are needed, don't forget to list it with [].

        quantiles (list-like of numbers): (Default=None) A list-like object of requested quantiles (needed
        for numeric data types). All elements of quantiles must be
        numeric and lie within (0,1).

        groupby_vars (list-like of numbers or strings): (Default=None) A list-like object of requested grouping variables.

        spark_session (spark.Session): (Default = None) The spark session created for running the function
            on a spark dataframe. This parameter is mandatory for a spark dataframe. When the function
            is run on other types of data (e.g. pd dataframe), this parameter is None.

    Returns:
        (pandas.DataFrame): A table with requested descriptive statistics.

    Raises:
        TypeError - if df_orginal is neither a pandas or spark dataframe.

        ValueError - if 'selected_columns' is not a list;

        ValueError - if any element of 'selected_columns' is not a string;

        ValueError - if 'groupby_vars' is not a list;

        ValueError - if any element of 'groupby_vars' is not a string;

        ValueError - if 'groupby_vars' and 'selected_columns' contain common elements;

        ValueError - if 'quantiles' is not a list;

        ValueError - if any element of 'quantiles' isn't numeric;

        ValueError - if any element of 'quantiles' isn't inside (0,1).

    Examples:
        Call function in Python like this for pandas dataframe::

            descr_stats = descriptive_statistics(df_original = df,
                                                 selected_columns = ['x1', 'x2'],
                                                 quantiles = [0.1, 0.35, 0.87],
                                                 groupby_vars = None)

        Call function in Python like this for spark dataframe::

            spark = SparkSession.builder.getOrCreate()
            descr_stats = descriptive_statistics(df_original = df,
                                                 selected_columns = ['x1', 'x2'],
                                                 quantiles = [0.1, 0.35, 0.87],
                                                 groupby_vars = None,
                                                 spark_session = spark)

    Notes:
        * For pandas.DataFrames, the data types explicitely accounted for in this function are:
          'int32','int64', 'float64', 'datetime64', 'timedelta', 'boolean',
          'bool', 'object', 'category', and 'period'. Any other data type will
          be processed in the same way as 'object'.

        * For pyspark.sql.DataFrames, the data types explicitely accounted for in this function are:
          'DoubleType', 'IntegerType', 'FloatType', 'LongType', 'BooleanType', 'StringType', 'DateType'.
          Any other data type will not be processed.

        * For pandas.DataFrames, variables of 'period' data type are treated as 'objects'. If e.g. Year
          is needed to be analysed as numeric, translate to 'int' before envoking
          this function.

        * Datetime inputs as strings will be treated as objects. Translate
          explicitely to 'datetime64' (for pandas.DataFrames) or 'date' (for pyspark.sql.DataFrame)
          type to treat them as datetimes.

        * Author: Camilla Trinderup <G80944>
    """
    # Check that 'selected_columns' is a list:.
    if not selected_columns is None and not isinstance(selected_columns, list):
        raise ValueError(f"Input to argument 'selected_columns' must be a list.")

    # Check that all elements of 'selected_columns' are strings:
    if not selected_columns is None and not all(
        isinstance(x, str) for x in selected_columns
    ):
        raise ValueError(f"{selected_columns} contains values that are not strings.")

    # Check that 'groupby_vars' is a list:
    if not groupby_vars is None and not isinstance(groupby_vars, list):
        raise ValueError(f"Input to argument 'groupby_vars' must be a list.")

    # Check that all elements of 'groupby_vars' are strings:
    if not groupby_vars is None and not all(isinstance(x, str) for x in groupby_vars):
        raise ValueError(f"Argument 'groupby_vars' must only contain string elements.")

    # Check that all elements of 'groupby_vars' and 'selected_columns' are different:
    if (
        not groupby_vars is None
        and not selected_columns is None
        and bool(set(groupby_vars) & set(selected_columns))
    ):
        raise ValueError(
            f"Input to argument 'selected_columns' must be different from 'groupby_vars'."
        )

    # Check that 'quantiles' is a list:
    if not quantiles is None and not isinstance(quantiles, list):
        raise ValueError(f"Input to argument 'quantiles' must be a list.")

    # Check that all elements of 'quantiles' are numeric:
    if not quantiles is None and not all(
        isinstance(x, (int, float)) for x in quantiles
    ):
        raise ValueError(f"{quantiles} contains non-numeric values.")

    # Check that all elements of 'quantiles' are inside (0,1)
    if not quantiles is None and not all((x > 0 and x < 1) for x in quantiles):
        raise ValueError(
            f"{quantiles} contains values that are outside of the (0,1) interval."
        )

    # Direct arguments to summary functions. Raise error if incorrect type found.
    if isinstance(df_original, pd.DataFrame):
        return _pandas_descriptive_statistics(
            df_original, selected_columns, quantiles, groupby_vars
        )
    elif isinstance(df_original, psd.DataFrame):
        return _spark_descriptive_statistics(
            df_original, spark_session, selected_columns, quantiles, groupby_vars
        )
    else:
        raise TypeError(
            f"Argument 'df_original' must be either a pandas or a pyspark DataFrame, not {type(df_original)}."
        )


def _pandas_descriptive_statistics_ungrouped(
    df_ug: pd.DataFrame,
    selected_columns_ug: Optional[List[str]],
    quantiles_ug: Optional[List[float]] = None,
):
    """
    This function is part of the tool kit for data quality analysis.
    In particular, it is meant to be used to assess data accuracy, as defined
    in EBA guidelines "EBA-RTS-2016-03_IRB", Article 76.1 (b). The details of
    the required validation analysis are found in Section 3.2.3 Data quality
    in the Validation Guidelines - Credit Risk Models v1.0.

    This function returns descriptive statistics for a given ungrouped pandas
    dataset. It is the main building block for function
    '_pandas_descriptive_statistics' (see below), which will call this
    function to perform its operations.

    The following statistics are reported per column in the input dataset:

    * For a numeric variable ('integer', 'float', 'timedelta'):
        * count = total number of observations;
        * mean;
        * std = standard deviation;
        * min;
        * requested quantiles, including median;
        * max;
        * sum.

    * For a boolean variable ('boolean', 'bool'):
        * count = total number of observations;
        * top = most frequent value;
        * freq = count for the most frequent value;
        * count of trues.

    * For a categorical variable (all remaining data types, incl. 'object', 'category', 'period'):
        * count = total number of observations;
        * unique = number of unique elements;
        * top = most frequent value;
        * freq = count for the most frequent value.

    * For a 'datetime' variable:
        * count = total number of observations;
        * min = the earliest date in the sample;
        * max = the latest date in the sample;
        * top = most frequent value;
        * freq = count for the most frequent value.

    Args:
        df_ug (pandas.DataFrame): Input table. It must be non-empty.

        selected_columns_ug (list of strings): (Default=None) Names of columns in
        the dataset for which to return descriptive statistics. If None, all
        columns in the dataset will be included. All elements of 'selected_columns_ug'
        must be strings and must be present among column names of the input table.
        If statistics for one specific column are needed, don't forget to list it with [].

        quantiles_ug (list of numbers): (Default=None) A list
        of requested quantiles (needed for numeric data types). All elements
        of 'quantiles_ug' must be numeric and lie within (0,1).

    Returns:
        (pandas.DataFrame): A table with requested descriptive statistics.

    Examples:
        Call function in Python like this::

            descr_stats = _pandas_descriptive_statistics_ungrouped(df_ug = df,
                                                 selected_columns_ug=['x1', 'x2'],
                                                 quantiles_ug=[0.1, 0.35, 0.87])

    Notes:
        * Data types explicitely accounted for in this function are:
          'int16','int32','int64', 'float32','float64', 'datetime64',
          'timedelta', 'boolean', 'bool', 'object', 'category', and 'period'.
          Any other data type will be processed in the same way as 'object'.

        * 'float16' data type crashes pandas .describe(), as well as .mean(),
          .std(), and .sum(). Variables of this type are automatically translated
          to 'float32' before applying this function. A warning is given.

        * Variables of 'period' data type are treated as 'objects'. If e.g. Year
          is needed to be analysed as numeric, translate it to 'integer' before
          envoking this function.

        * Datetime inputs as strings will be treated as objects. Translate
          explicitely to 'datetime64' type to treat them as datetimes.

        * This code was built under pandas 1.1.1.
          The 'datetime_is_numeric=True'-option in pandas.describe() function will
          be removed in the next pandas version. The 'datetime_is_numeric=True'-behaviour
          will become default. When that happens, 'datetime_is_numeric=True' in
          pandas.describe() will simply need to be deleted to restore the
          current functionality.

        * Author: Mark Rubtsov <AC30171>
    """

    # Create an empty dataFrame to collect the outputs:
    descr_stat = pd.DataFrame()

    # Choose columns for which descriptive statistics are required,
    # making a copy of the original data table:
    if selected_columns_ug is None:
        df_selected = df_ug.copy()
    else:
        df_selected = df_ug[selected_columns_ug].copy()

    # See if 'float16' data are present. If so, translate to 'float32' and give a warning:
    data_group = df_selected.select_dtypes(include=["float16"])
    if not data_group.empty:
        df_selected[data_group.columns.values] = df_selected[
            data_group.columns.values
        ].astype("float32")
        warnings.warn(
            f"Input dataset contains 'float16' columns: {data_group.columns.values}. Data have been translated to 'float32' data type before applying this function."
        )

    # Select numeric columns:
    data_group = df_selected.select_dtypes(
        include=["int16", "int32", "int64", "float32", "float64", "timedelta"]
    )
    if not data_group.empty:
        #     !!!
        #     This code was built under pandas 1.1.1.
        #     The 'datetime_is_numeric=True'-option in pandas.describe() function will
        #     be removed in the next pandas version. The 'datetime_is_numeric=True'-behaviour
        #     will become default. When that happens, 'datetime_is_numeric=True' in
        #     pandas.describe() will simply need to be deleted to restore the
        #     current functionality.
        descr_stat_group = data_group.describe(
            datetime_is_numeric=True, percentiles=quantiles_ug
        ).transpose()
        descr_stat_group["sum"] = pd.DataFrame(data_group.sum(skipna=True))
        descr_stat = pd.concat([descr_stat, descr_stat_group], sort=False)

    # Select boolean columns:
    data_group = df_selected.select_dtypes(include=["boolean", "bool"])
    if not data_group.empty:
        descr_stat_group = data_group.describe().transpose().drop("unique", axis=1)
        descr_stat_group["count of trues"] = pd.DataFrame(data_group.sum(skipna=True))
        descr_stat = pd.concat([descr_stat, descr_stat_group], sort=False)

    # Select categorical columns:
    data_group = df_selected.select_dtypes(
        exclude=[
            "int16",
            "int32",
            "int64",
            "float16",
            "float32",
            "float64",
            "datetime64",
            "timedelta",
            "boolean",
            "bool",
        ]
    )
    if not data_group.empty:
        descr_stat_group = data_group.describe().transpose()
        descr_stat = pd.concat([descr_stat, descr_stat_group], sort=False)

    # Select 'datetime' columns:
    data_group = df_selected.select_dtypes(include=["datetime64"])
    if not data_group.empty:
        #     !!!
        #     This code was built under pandas 1.1.1.
        #     The 'datetime_is_numeric=True'-option in pandas.describe() function will
        #     be removed in the next pandas version. The 'datetime_is_numeric=True'-behaviour
        #     will become default. When that happens, 'datetime_is_numeric=True' in
        #     pandas.describe() will simply need to be deleted to restore the
        #     current functionality.
        descr_stat_group = data_group.describe(datetime_is_numeric=True).transpose()[
            ["count", "min", "max"]
        ]

        # Translate results to strings to improve readability:
        descr_stat_group.loc[:, "max"] = descr_stat_group.loc[:, "max"].apply(
            lambda x: x.strftime("%Y-%m-%d") if not pd.isnull(x) else np.nan
        )
        descr_stat_group.loc[:, "min"] = descr_stat_group.loc[:, "min"].apply(
            lambda x: x.strftime("%Y-%m-%d") if not pd.isnull(x) else np.nan
        )

        # Convert 'datetime' columns to strings to collect remaining statistics:
        for col_name in data_group.columns.values:
            date_to_string = data_group.loc[:, col_name].apply(
                lambda x: x.strftime("%Y-%m-%d") if not pd.isnull(x) else ""
            )
            df_selected = df_selected.drop(col_name, axis=1)
            df_selected[col_name] = date_to_string

        descr_stat_group = pd.concat(
            [
                descr_stat_group,
                df_selected[data_group.columns.values]
                .describe()
                .transpose()[["top", "freq"]],
            ],
            sort=False,
            axis=1,
        )
        descr_stat = pd.concat([descr_stat, descr_stat_group], sort=False)

    return descr_stat.transpose()


def _pandas_descriptive_statistics(
    df_original: pd.DataFrame,
    selected_columns: Optional[List[str]],
    quantiles: Optional[List[float]],
    groupby_vars: Optional[Union[List[str]]],
) -> pd.DataFrame:
    """
    This function is part of the tool kit for data quality analysis.
    In particular, it is meant to be used to assess data accuracy, as defined
    in EBA guidelines "EBA-RTS-2016-03_IRB", Article 76.1 (b). The details of
    the required validation analysis are found in Section 3.2.3 Data quality
    in the Validation Guidelines - Credit Risk Models v1.0.

    This function returns descriptive statistics for a given pandas dataset. It calls function
    '_pandas_descriptive_statistics_ungrouped' (see above) to perform its operations.
    The behaviour of the function will be different depending on the value of
    'groupby_vars' provided by the user. If 'groupby_vars=None', then
    '_pandas_descriptive_statistics_ungrouped' is called without any extras.
    If 'groupby_vars' are provided by the user, then the data in the input table
    are first grouped, and then '_pandas_descriptive_statistics_ungrouped' is
    applied to each data chunk.

    The descriptive statistics returned by this function are the same as those
    for '_pandas_descriptive_statistics_ungrouped'.

    Args:
        df_original (pandas.DataFrame): Input data table. It must be non-empty.

        selected_columns (list of strings): (Default=None) Names of columns in
        the input dataset for which to return descriptive statistics. If None, all
        columns in the dataset will be included. All elements of 'selected_columns'
        must be strings and must be present among column names of the input table.
        If statistics for one specific column are needed, don't forget to list it with [].
        Elements of 'selected_columns' must be different from those of 'groupby_vars'.

        quantiles (list of numbers): (Default=None) A list
        of requested quantiles (needed for numeric data types). All elements
        of 'quantiles' must be numeric and lie within (0,1).

        groupby_vars (list of strings): (Default=None) Names of variables
        (i.e. columns) in the original dataset by which the data (and outputs)
        are to be grouped. If None, no groupby operation is going to be performed,
        i.e. descriptive statistics for the original data are to be returned.
        All elements of 'groupby_vars' must be strings and must be present among
        column names of the input table. If only one groupby variable is provided,
        don't forget to list it with []. Elements of 'groupby_vars' must be
        different from those of 'selected_columns'.

    Returns:
        (pandas.DataFrame): A table with requested descriptive statistics.

    Raises:

        ValueError - if 'df_original' is empty;

        ValueError - if any element of 'selected_columns' is not among the
                     column names of the input table;

        ValueError - if any element of 'groupby_vars' is not among the
                     column names of the input table;

        Warning -    if 'df_original' contains 'float16' data. Function
                     operation is not interrupted.

        Warning -    if any of the 'groupby_vars' contains NaNs.

    Examples:
        Call function in Python like this::

            descr_stats = _pandas_descriptive_statistics(df_original = df,
                                                 selected_columns=['x1', 'x2'],
                                                 quantiles=[0.1, 0.35, 0.87],
                                                 groupby_vars=['y1','y2'])

    Notes:
        * Data types explicitely accounted for in this function are:
          'int16','int32','int64', 'float32','float64', 'datetime64',
          'timedelta', 'boolean', 'bool', 'object', 'category', and 'period'.
          Any other data type will be processed in the same way as 'object'.

        * 'float16' data type crashes pandas .describe(), as well as .mean(),
          .std(), and .sum(). Variables of this type are automatically translated
          to 'float32' before applying this function. A warning is given.

        * Variables of 'period' data type are treated as 'objects'. If e.g. Year
          is needed to be analysed as numeric, translate it to 'integer' before
          envoking this function.

        * Datetime inputs as strings will be treated as objects. Translate
          explicitely to 'datetime64' type to treat them as datetimes.

        * This code was built under pandas 1.1.1.
          The 'datetime_is_numeric=True'-option in pandas.describe() function will
          be removed in the next pandas version. The 'datetime_is_numeric=True'-behaviour
          will become default. When that happens, 'datetime_is_numeric=True' in
          pandas.describe() will simply need to be deleted to restore the
          current functionality.

        * If a particular record has a missing value (NaN) in 'groupby_vars', that record
          will be excluded from the reported statistics. If descriptive statistics are required
          for 'NaN' as a separate groupby category, use pd.fillna(...) prior to
          calling this function to explicitely replace NaNs with e.g. 'Unknown'.

        * Author: Mark Rubtsov <AC30171>
    """

    # Check that the input table is not empty:
    if df_original.empty:
        raise ValueError(f"Input to argument 'df_original' must be non-empty.")

    # Check that all elements of 'selected_columns' are among the column names of the input table:
    if not selected_columns is None and not set(selected_columns).issubset(
        set(df_original.columns.values)
    ):
        raise ValueError(
            f"Input to argument 'selected_columns' must only contain column names present in the input table 'df_original'."
        )

    # Check that all elements of 'groupby_vars' are among the column names of the input table:
    if not groupby_vars is None and not set(groupby_vars).issubset(
        set(df_original.columns.values)
    ):
        raise ValueError(
            f"Input to argument 'groupby_vars' must only contain column names present in the input table 'df_original'."
        )

    if groupby_vars is None:
        result = _pandas_descriptive_statistics_ungrouped(
            df_ug=df_original,
            selected_columns_ug=selected_columns,
            quantiles_ug=quantiles,
        )
    else:
        # In case 'selected_columns'=None, remove 'groupby_vars' from the list of analysed columns, if any:
        if selected_columns is None:
            selected_columns = [
                s for s in df_original.columns.values if not s in groupby_vars
            ]

        # See if there are NaNs in 'groupby_vars'. If so, give a warning:
        for col_name in groupby_vars:
            if df_original[col_name].isnull().values.any():
                print("\n")
                warnings.warn(
                    f" \n Groupby column {col_name} contains missing values (NaN). The corresponding records will be excluded from the reported statistics. Use pd.fillna(...) prior to calling this function to obtain statistics for 'NaN' as a separate groupby category."
                )

        result = df_original.groupby(groupby_vars).apply(
            lambda x: _pandas_descriptive_statistics_ungrouped(
                df_ug=x, selected_columns_ug=selected_columns, quantiles_ug=quantiles
            )
        )

    return result.reset_index().rename(
        columns={
            "level_1": "Statistics",
            "level_2": "Statistics",
            "level_3": "Statistics",
            "level_4": "Statistics",
            "index": "Statistics",
        }
    )


def _spark_descriptive_statistics(
    df_spark: pyspark.sql.DataFrame,
    spark_session: SparkSession,
    selected_columns: Optional[List[Union[int, str]]],
    quantiles: Optional[List[float]],
    groupby_vars: Optional[List[Union[int, str]]],
) -> pd.DataFrame:
    """
    Function that generates descriptive statistics of a pyspark.sql.DataFrame.

    This function is part of the tool kit for data quality analysis.
    In particular, it is meant to be used to assess data accuracy, as defined
    in EBA guidelines "EBA-RTS-2016-03_IRB", Article 76.1 (b). The details of
    the required validation analysis are found in Section 3.2.3 Data quality
    in the Validation Guidelines - Credit Risk Models v1.0.

    The following statistics are reported per column in the input dataset:

    * For a numeric variable ('FloatType', 'DoubleType','IntegerType'):
        * count = total number of observations;
        * mean;
        * std = standard deviation;
        * min;
        * requested quantiles, including median;
        * max;
        * sum.

    * For a boolean variable ('BooleanType'):
        * count = total number of observations;
        * top = most frequent value;
        * freq = count for the most frequent value;
        * count of trues

    * For a categorical variable ('StringType'):
        * count = total number of observations;
        * unique = number of unique elements;
        * top = most frequent value;
        * freq = count for the most frequent value.

    * For a 'datetime' variable (DateType):
        * count = total number of observations;
        * min = the earliest date in the sample;
        * max = the latest date in the sample;
        * top = most frequent value;
        * freq = count for the most frequent value.

    Args:
        df_spark (pyspark.sql.DataFrame): Input table. It must be non-empty.

        spark_session (spark.Session): TO DO

        selected_columns (list-like of strings): (Default=None) Names of columns in
        the dataset for which to return descriptive statistics. If None, all
        columns in the dataset will be included. All elements of selected_columns
        must be strings and must be present among column names of the input table.
        If statistics for one specific column are needed, don't forget to list it with [].

        quantiles (list-like of numbers): (Default=None) A list-like object of
            requested quantiles (needed for numeric data types). All elements of
            quantiles must be numeric and lie within (0,1).

        groupby_vars (list-like of numbers): (Default=None) A list-like
            object of requested grouping variables.

    Returns:
        (pandas.DataFrame): A table with requested descriptive statistics.

    Raises:

        ValueError - if spark_session is not of type 'SparkSession';

        ValueError - if the parameter 'df_spark' is empty;

        ValueError - if any element of 'selected_columns' is not among the
                     column names of the input table;

        ValueError - if any element of 'groupby_vars' is not among the
                     column names of the input table;

        Warning    - if any columns are pure null values. These columns
                    will be removed from the descriptive statistics.

    Examples:

    """
    # Check for spark session
    if not isinstance(spark_session, SparkSession):
        raise TypeError(
            f"Input to argument 'spark' must be a "
            f"pyspark.sql.session.SparkSession, not "
            f"{type(spark_session)}."
        )

    # Check that the spark dataframe is not empty
    if df_spark.count() == 0:
        raise ValueError(
            f"Input parameter 'df_spark' " f"only accepts a non-empty spark DataFrame."
        )

    # Check that all elements of 'selected_columns' are among the column names of the input table
    if not selected_columns is None and not set(selected_columns).issubset(
        set(df_spark.columns)
    ):
        raise ValueError(
            f"{selected_columns} contains elements that are not among the column names of the input table."
        )

    # Check that all elements of 'groupby_vars' are among the column names of the input table
    if not groupby_vars is None and not set(groupby_vars).issubset(
        set(df_spark.columns)
    ):
        raise ValueError(
            f"{groupby_vars} contains elements that are not among the column names of the input table."
        )

    # Choose columns for which descriptive statistics are required
    if selected_columns is None:
        df_selected = df_spark
    else:
        if groupby_vars is None:
            df_selected = df_spark.select(selected_columns)
        else:
            selected_columns = list(set().union(groupby_vars, selected_columns))
            df_selected = df_spark.select(selected_columns)

    # Checking for columns of pure null values.
    N = df_selected.count()
    null_counts = [
        df_selected.where(df_selected[name].isNull()).count() == N
        for name in df_selected.columns
    ]

    # Exclude columns of pure null values.
    if sum(null_counts) > 0:
        exclude = list(compress(df_selected.columns, null_counts))
        include = list(set.difference(set(df_selected.columns), set(exclude)))

        df_selected = df_selected.select(include)
        warnings.warn(
            f"These columns of the input dataset are pure null values: {exclude}. They will be excluded from descriptive statistics."
        )

    # Filtering groupby columns
    if not groupby_vars is None:
        for name in groupby_vars:
            df_selected = df_selected.filter(df_selected[name].isNotNull())

    # Dataframe for final output variable.
    descr_stat = pd.DataFrame()

    # Identify columns of numeric type.
    float_cols = [
        c.name
        for c in df_selected.schema.fields
        if (
            isinstance(c.dataType, DoubleType)
            or isinstance(c.dataType, IntegerType)
            or isinstance(c.dataType, FloatType)
            or isinstance(c.dataType, LongType)
        )
    ]

    if not groupby_vars is None:
        float_cols = list(set(float_cols) - set(groupby_vars))

    # Compute statistics for numeric columns.
    if len(float_cols) > 0:
        if groupby_vars is not None:
            float_cols = list(set.difference(set(float_cols), set(groupby_vars)))

        descr_stat_numeric, column_names = _compute_numeric_stats(
            df_spark=df_selected,
            spark_session=spark_session,
            quantiles=quantiles,
            groupby_vars=groupby_vars,
            float_cols=float_cols,
        )

        descr_stat = pd.concat([descr_stat, descr_stat_numeric])

    # Identify columns of boolean type.
    bool_cols = [
        c.name for c in df_selected.schema.fields if isinstance(c.dataType, BooleanType)
    ]
    if not groupby_vars is None:
        bool_cols = list(set(bool_cols) - set(groupby_vars))

    # Compute statistics for boolean variables
    if len(bool_cols) > 0:
        descr_stat_bool = _compute_bool_stats(
            df_selected, groupby_vars=groupby_vars, bool_cols=bool_cols
        )

        if groupby_vars is None:
            descr_stat = pd.concat([descr_stat, descr_stat_bool])
        else:
            descr_stat = descr_stat.join(descr_stat_bool, how="outer")

    # Identify columns of categorical type.
    cat_cols = [
        c.name
        for c in df_selected.schema.fields
        if (isinstance(c.dataType, StringType))
    ]
    if not groupby_vars is None:
        cat_cols = list(set(cat_cols) - set(groupby_vars))

    # Compute statistics for categorical columns.
    if len(cat_cols) > 0:

        if groupby_vars is not None:
            cat_cols = list(set.difference(set(cat_cols), set(groupby_vars)))

        descr_stat_cat = _compute_categorical_stats(df_selected, groupby_vars, cat_cols)

        if groupby_vars is None:
            descr_stat = pd.concat([descr_stat, descr_stat_cat])
        else:
            descr_stat = descr_stat.join(descr_stat_cat, how="outer")

    # Identify columns of date type.
    date_cols = [
        c.name for c in df_selected.schema.fields if isinstance(c.dataType, DateType)
    ]
    if not groupby_vars is None:
        date_cols = list(set(date_cols) - set(groupby_vars))

    # Compute statistics for date columns.
    if len(date_cols) > 0:

        if groupby_vars is not None:
            date_cols = list(set.difference(set(date_cols), set(groupby_vars)))

        descr_stat_dates = _compute_date_stats(df_selected, groupby_vars, date_cols)

        if groupby_vars is None:
            descr_stat = pd.concat([descr_stat, descr_stat_dates])
        else:
            descr_stat = descr_stat.join(descr_stat_dates, how="outer")

    if groupby_vars is None:
        return descr_stat.T
    else:
        # Define order for statistical outputs
        descr_stat.reset_index(inplace=True)
        stat_order = (
            ["count", "mean", "std", "min"]
            + column_names
            + ["max", "sum", "count of trues", "top", "freq", "unique"]
        )
        descr_stat["stat"] = pd.Categorical(descr_stat["stat"], stat_order)

        # Sort output data frame according to groupby_vars and stats
        groupby_vars.append("stat")
        descr_stat = descr_stat.sort_values(by=groupby_vars)
        descr_stat = descr_stat.reset_index(drop=True)

        return descr_stat


def _blank_as_null(name: str) -> Column:
    """Subfunction for identifying missing values for a single column in a spark dataframe
    and replacing them with Null's/None.

    Args:
        name (String): Column for which should empty cells should be identified.

    Returns:
        (column) : A copy of the input column, but with missing values replaced by Null.

    Examples:
        df_spark = df_spark.withColumn(name, _blank_as_null('name'))

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    return f.when(f.col(name) != "", f.col(name)).otherwise(None)


def _not_nan(name: str) -> bool:
    """Subfunction for excluding nans from a single column in a spark dataframe.

    Args:
        name (string): Column for which nan's should be identified.

    Returns:
        bool: The indices of the cells that are not nan's.

    Examples:
        column_sum = data_group.agg(f.sum(_not_nan('column_name)).alias('column_name'))

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    return f.when(~f.isnan(f.col(name)), f.col(name))


def _from_name(sc, func_name: str, *params) -> Callable:
    """Function to create call by function name, when it is not possible
    to use groupBy with aggregation functions, e.g. when finding modes/quantiles.

    Args:
        sc (sparkContext): Sparkcontext from current spark session.
        func_name (string): Name of statistic to compute.
        *params (): Additional parameters necessary for computation of statistic.

    Returns:
        func (): Result of computing func_name on the wanted column. Output format is dependent on what the function returns.

    Examples:
        See _quantile_func where the function is called.

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    callUDF = sc._jvm.org.apache.spark.sql.functions.callUDF
    func = callUDF(func_name, _to_seq(sc, *params, _to_java_column))

    return Column(func)


def _quantile_func(
    name: str, quantiles: List[float], spark: SparkSession
) -> pyspark.sql.Column:
    """Subfunction for computing the quantiles requested of a numerical variable.
    This is a pandas UDF, and it is dependent on the function from_name.

    Args:
        name (string): name of column to find quantiles for
        quantiles (list of numerics): quantile values wanted.

    Returns:
        target (pyspark.sql.column): List of quantiles

    Examples:
        quantiles = [0.01, 0.99]
        # apply function for each group
        df_spark.groupBy(["Year","YearMonth"] ).agg(*[median_func(col, quantiles).alias(col)
                                            for col in float_cols]).orderBy('Year').show()

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    target = _from_name(
        spark.sparkContext,
        "percentile",
        [
            f.when(~f.isnan(f.col(name)), f.col(name)),
            f.array([f.lit(x) for x in quantiles]),
        ],
    )  # f.lit(0.5)])

    return target


def _compute_quantiles(
    df_spark: pyspark.sql.DataFrame,
    groupby_vars: List[Union[str, int]],
    float_cols: pyspark.sql.DataFrame.columns,
    column_names: List[str],
    quantiles: List[float],
    spark: SparkSession,
) -> pyspark.sql.Column:
    """Subfunction for computing the quantiles requested of a numerical variable.

    Args:
        name (string): name of column to find quantiles for
        quantiless (list of numerics): quantiless wanted.

    Returns:
        target (column): Column for spark dataframe with.

    Examples:
        quantiless = [0.01, 0.99]
        # apply function for each group
        df_spark.groupBy(["Year","YearMonth"] ).agg(*[_quantile_func(col, quantiles).alias(col)
                                            for col in float_cols]).orderBy('Year').show()

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    # Apply function for each group.
    if groupby_vars is None:
        df_quant = df_spark.agg(
            *[_quantile_func(col, quantiles, spark).alias(col) for col in float_cols]
        ).toPandas()
        size = df_quant.shape[0]

        for name in float_cols:
            df_quant.loc[df_quant[name].isnull(), name] = [[np.nan] * len(quantiles)]

        # Reshape and explode lists returned by _quantile_func.
        df_quant_extended = df_quant.apply(
            lambda x: x.explode() if x.name in float_cols else x
        )
        df_quant_extended.index = column_names

    else:
        df_quant = (
            df_spark.groupBy(groupby_vars)
            .agg(
                *[
                    _quantile_func(col, quantiles, spark).alias(col)
                    for col in float_cols
                ]
            )
            .orderBy(groupby_vars)
            .toPandas()
        )

        for name in float_cols:
            df_quant[name] = df_quant[name].apply(
                lambda x: [np.nan] * len(quantiles) if x is None else x
            )

        size = df_quant.shape[0]

        # Reshape and explode lists returned by _quantile_func.
        df_quant_extended = df_quant.apply(
            lambda x: x.explode() if x.name in float_cols else x
        )
        df_quant_extended.insert(len(groupby_vars), "stat", column_names * size)

    return df_quant_extended


def _stat_values_numeric_groupby(
    df_spark: pyspark.sql.DataFrame, groupby_vars: List[Union[str, int]], name: str
) -> pd.DataFrame:
    """Subfunction for computing the statistics of a numeric variable/column.

    Args:
        df_spark (spark dataframe): Data frame containing column name.
        groupby_vars (list): List of variables to group by.
        name (string): Name of column to compute statistics for.

    Returns:
        stats (pd.DataFrame): Pandas data frame holding the statistics.

    Examples:

        stats_numeric = [_stat_values_numeric(df_spark, groupby_vars, name) for name in df_spark.columns]

    Notes:
        Author: Camilla Trinderup (G80944)

    """

    # Compute numeric statistics by aggregation.
    df_stats = (
        df_spark.groupBy(groupby_vars)
        .agg(
            f.count(_not_nan(name)).alias("count"),
            f.mean(_not_nan(name)).alias("mean"),
            f.stddev(_not_nan(name)).alias("std"),
            f.min(_not_nan(name)).alias("min"),
            f.max(_not_nan(name)).alias("max"),
            f.sum(_not_nan(name)).alias("sum"),
        )
        .orderBy(groupby_vars)
        .toPandas()
        .set_index(groupby_vars)
    )

    # Reset index.
    df_stats.reset_index(inplace=True)

    # Unpivot dataframe.
    df_out = df_stats.melt(
        id_vars=groupby_vars,
        value_vars=["count", "mean", "std", "min", "max", "sum"],
        var_name="stat",
        value_name=name,
    ).sort_values(by=groupby_vars)

    return df_out


def _stat_values_categorical(
    df_spark: pyspark.sql.DataFrame, groupby_vars: List[Union[str, int]], name: str
) -> pd.DataFrame:
    """Subfunction for computing the descriptive statistics of a categorical
    column in a spark dataframe. The descriptive statistics are in this case

        - most frequent value
        - count for the most frequent value
        - total number of observations of column (excluding Null values)
        - number of unique elements of column (excluding Null values)

    Args:
        df_spark (spark dataframe): Dataframe
        name (string): Column for which nan's should be identified.

    Returns:
        df (pandas dataframe): Dataframe representing the descriptive statistics.

    Examples:
        stats_column = [_stat_values_categorical(df_spark, groupby_vars, 'column_name')

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    if groupby_vars is None:
        # Select column of interest
        df_column = df_spark.withColumn(name, _blank_as_null(name)).select(name)

        # Compute dataframe representing unique values and their individual counts
        df = (
            df_column.where(df_column[name].isNotNull())
            .groupBy(name)
            .count()
            .orderBy(f.col("count").desc())
            .toPandas()
        )

        # if df.empty:
        #    df_out = pd.DataFrame(columns = ['top', 'freq', 'count', 'unique'])

        # else:
        # Extract relevant values from the above dataframe
        no_obs = df["count"].sum()
        unique_elements = df.shape[0]
        most_freq = df.iloc[0, 0]
        freq_count = df.iloc[0, 1]

        # Define output as data frame
        df_out = pd.DataFrame(
            [[most_freq, freq_count, no_obs, unique_elements]],
            index=[name],
            columns=["top", "freq", "count", "unique"],
        )
    else:
        # Ensure empty cells are represented as null
        df_spark = df_spark.withColumn(name, _blank_as_null(name))

        # Extract relevant columns
        group_cols = groupby_vars.copy()
        group_cols.append(str(name))
        df_tmp = df_spark.select(group_cols)

        # Compute dataframe representing unique values and their individual counts
        df = (
            df_tmp.where(df_tmp[name].isNotNull())
            .groupBy(group_cols)
            .count()
            .orderBy(groupby_vars)
            .toPandas()
            .set_index(groupby_vars)
        )
        df = df.rename(columns={name: "top", "count": "freq"})
        df.reset_index(inplace=True)

        df_top = df.loc[df.groupby(groupby_vars)["freq"].idxmax()]
        df_top = df_top.melt(
            id_vars=groupby_vars,
            value_vars=["top", "freq"],
            var_name="stat",
            value_name=name,
        )

        # Compute data frame for counts
        df_sum = (
            df_tmp.where(df_tmp[name].isNotNull())
            .groupBy(groupby_vars)
            .count()
            .orderBy(groupby_vars)
            .toPandas()
            .set_index(groupby_vars)
        )
        df_sum.reset_index(inplace=True)
        df_count = df_sum.melt(
            id_vars=groupby_vars, value_vars="count", var_name="stat", value_name=name
        )

        # Count unique values.
        df_unique = (
            df_tmp.where(df_tmp[name].isNotNull())
            .groupBy(groupby_vars)
            .agg(f.countDistinct(name).alias("unique"))
            .toPandas()
            .set_index(groupby_vars)
        )
        df_unique.reset_index(inplace=True)
        df_unique = df_unique.melt(
            id_vars=groupby_vars, value_vars="unique", var_name="stat", value_name=name
        )

        # Define output.
        df_out = pd.concat([df_top, df_count, df_unique], axis=0)
        groupby_vars = groupby_vars + ["stat"]
        df_out = df_out.set_index(groupby_vars)
        # df_out = df_out.reset_index(drop = True)

    return df_out


def _stat_values_boolean(
    df_spark: pyspark.sql.DataFrame, name: str, groupby_vars: List[Union[str, int]]
) -> pd.DataFrame:
    """Subfunction for computing the descriptive statistics of a boolean
    column in a spark dataframe. The descriptive statistics are in this case

        - count of trues
        - total number of observations of column (excluding Null values)
        - most frequent value
        - count for the most frequent value
        - number of unique elements of column (excluding Null values)

    Args:
        df_spark (spark dataframe): Dataframe
        name (string): Column for which nan's should be identified.

    Returns:
        df (pandas dataframe): Dataframe representing the descriptive statistics.

    Examples:
        stats_column = [_stat_values_boolean(df_spark, 'column_name')

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    df_column = df_spark.select(name)

    if groupby_vars is None:
        df = (
            df_column.where(df_column[name].isNotNull())
            .groupBy(name)
            .count()
            .orderBy(f.col("count"))
            .toPandas()
        )

        # count of trues
        trues = df.loc[df[name] == True, "count"]
        trues = trues.values[0]

        # total number of observations
        no_obs = df["count"].iloc[:2].sum()

        # most frequent value
        freq_idx = df["count"].idxmax()

        # count for the most frequent value
        # freq_count = df['count'].iloc[most_freq]
        most_freq = df[name].iloc[freq_idx]
        freq_count = df["count"].iloc[freq_idx]

        # define output dataframe
        df_out = pd.DataFrame(
            [[trues, no_obs, most_freq, freq_count]],
            index=[name],
            columns=["count of trues", "count", "top", "freq"],
        )
    else:

        # select sub dataframe with grouping columns and current boolean column
        group_cols = groupby_vars.copy()
        group_cols.append(str(name))
        # df_tmp = df_spark.select(group_cols).withColumn('binary', f.when(df_spark[name]==True, 1).otherwise(0))
        df_tmp = df_spark.withColumn(
            "binary", f.when(df_spark[name] == True, 1).otherwise(0)
        )
        df_tmp = df_tmp.withColumn(
            "neg_binary", f.when(df_spark[name] == True, 0).otherwise(1)
        )

        # find count of trues and false
        count_trues = (
            df_tmp.groupBy(groupby_vars)
            .agg(f.sum("binary").alias("count of trues"))
            .orderBy(groupby_vars)
            .toPandas()
            .set_index(groupby_vars)
        )
        count_false = (
            df_tmp.groupBy(groupby_vars)
            .agg(f.sum("neg_binary").alias("count of false"))
            .orderBy(groupby_vars)
            .toPandas()
            .set_index(groupby_vars)
        )

        # Find statistics for all groupings for current boolean column
        df_out = count_trues
        df_out["count of false"] = count_false["count of false"]
        df_out["top"] = df_out["count of trues"] > df_out["count of false"]
        df_out["freq"] = np.where(
            df_out["top"] == True, df_out["count of trues"], df_out["count of false"]
        )
        df_out["count"] = count_trues["count of trues"] + count_false["count of false"]

        # Set index to column names
        df_out.reset_index(inplace=True)

        # Unpivot data frame
        df_out = df_out.melt(
            id_vars=groupby_vars,
            value_vars=["count of trues", "top", "freq", "count"],
            var_name="stat",
            value_name=name,
        ).sort_values(by=groupby_vars)

    return df_out


def _compute_numeric_stats(
    df_spark: pyspark.sql.DataFrame,
    spark_session: SparkSession,
    quantiles: List[float],
    groupby_vars: List[Union[str, int]],
    float_cols: pyspark.sql.DataFrame.columns,
) -> pd.DataFrame:
    """Subfunction for computing the descriptive statistics of the numeric columns of
    a spark dataframe. The descriptive statistics are in this case

        - sum
        - mean
        - stddev
        - median
        - min
        - max
        - quantiles/quantiles
        - total number of observations of column (excluding Null values)

    Args:
        df_spark (spark dataframe): Dataframe with numeric columns for which statistics are wanted.
        quantiles (list): List of quantiles.

    Returns:
        df (pandas dataframe): Dataframe representing the descriptive statistics (rows = variables, columns = statistics).

    Examples:
        df_numeric_stat = _compute_numeric_stats(df_spark)

    Notes:
        Author: Camilla Trinderup (G80944)

    """

    # Adding mode for median computation
    if quantiles == None:
        quantiles = [0.25, 0.5, 0.75]
        column_names = ["25%", "50%", "75%"]
    else:
        if 0.5 not in quantiles:
            quantiles.append(0.5)

        # sort quantiles for nicer output
        quantiles = sorted(quantiles)
        N = len(quantiles)

        # Make quantile names similar to pandas.describe output
        percentages = [quantiles[i] * 100 for i in range(0, N)]
        percentages = [
            int(percentages[i])
            if (percentages[i] - round(percentages[i])) == 0
            else percentages[i]
            for i in range(0, N)
        ]
        column_names = [str(percentages[i]) + "%" for i in range(0, N)]

    # column names to loop over
    if float_cols is None:
        cols = df_spark.columns
    else:
        cols = float_cols

    # Compute statistics for all columns
    if groupby_vars is None:
        count = (
            df_spark.agg(*[f.count(_not_nan(c)).alias(c) for c in cols])
            .toPandas()
            .rename(index={0: "count"})
        )
        mean_val = (
            df_spark.agg(*[f.mean(_not_nan(c)).alias(c) for c in cols])
            .toPandas()
            .rename(index={0: "mean"})
        )
        sd_val = (
            df_spark.agg(*[f.stddev(_not_nan(c)).alias(c) for c in cols])
            .toPandas()
            .rename(index={0: "std"})
        )
        min_val = (
            df_spark.agg(*[f.min(_not_nan(c)).alias(c) for c in cols])
            .toPandas()
            .rename(index={0: "min"})
        )
        max_val = (
            df_spark.agg(*[f.max(_not_nan(c)).alias(c) for c in cols])
            .toPandas()
            .rename(index={0: "max"})
        )
        sum_val = (
            df_spark.agg(*[f.sum(_not_nan(c)).alias(c) for c in cols])
            .toPandas()
            .rename(index={0: "sum"})
        )
        df_quantiles = _compute_quantiles(
            df_spark=df_spark,
            groupby_vars=None,
            float_cols=cols,
            column_names=column_names,
            quantiles=quantiles,
            spark=spark_session,
        )

        # collect in dataframe
        dfs = [count, mean_val, sd_val, min_val, max_val, sum_val, df_quantiles]

        descr_stat_numeric = pd.concat(dfs, axis=0).T

    else:

        stats_numeric = [
            _stat_values_numeric_groupby(df_spark, groupby_vars, name)
            for name in float_cols
        ]

        descr_stat_numeric = pd.concat(stats_numeric, axis=1)
        descr_stat_numeric = descr_stat_numeric.loc[
            :, ~descr_stat_numeric.columns.duplicated()
        ]

        df_quantiles = _compute_quantiles(
            df_spark,
            groupby_vars=groupby_vars,
            float_cols=float_cols,
            column_names=column_names,
            quantiles=quantiles,
            spark=spark_session,
        )

        # collect results
        descr_stat_numeric = pd.concat([descr_stat_numeric, df_quantiles])
        descr_stat_numeric = descr_stat_numeric.reset_index(drop=True)

        # Re index for concatenation with other descriptive statistics
        index_columns = groupby_vars.copy() + ["stat"]
        descr_stat_numeric = descr_stat_numeric.set_index(index_columns)

    return descr_stat_numeric, column_names


def _compute_bool_stats(
    df_spark: pyspark.sql.DataFrame,
    groupby_vars: List[Union[str, int]],
    bool_cols: bool,
) -> pd.DataFrame:
    """Subfunction for computing the descriptive statistics of the boolean columns of
    a spark dataframe. The descriptive statistics are in this case

        - count of trues
        - total number of observations
        - most frequent value
        - count for most frequent value

    Args:
        df_spark (spark dataframe): Dataframe representing the boolean columns for
                                    which statistics are wanted.

    Returns:
        df (pandas dataframe): Dataframe representing the descriptive statistics (rows = variables, columns = statistics).

    Examples:
        df_bool_stats = _compute_bool_stats(df_spark)

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    # Compute statistics for all columns
    stats = [_stat_values_boolean(df_spark, name, groupby_vars) for name in bool_cols]

    # Concatenate list results to one data frame
    if groupby_vars is None:
        df_bool_stats = pd.concat(stats, axis=0)
    else:
        df_bool_stats = pd.concat(stats, axis=1)
        df_bool_stats = df_bool_stats.loc[:, ~df_bool_stats.columns.duplicated()]

        # Re index for concatenation with other descriptive statistics
        index_columns = groupby_vars.copy() + ["stat"]
        df_bool_stats = df_bool_stats.set_index(index_columns)

    return df_bool_stats


def _compute_categorical_stats(
    df_spark: pyspark.sql.DataFrame, groupby_vars: List[Union[str, int]], cat_cols
) -> psd.DataFrame:
    """Subfunction for computing the descriptive statistics of the categorical columns of
    a spark dataframe. The descriptive statistics are in this case

        - most frequent value
        - count for most frequent value
        - total number of observations
        - number of unique elements

    Args:
        df_spark (spark dataframe): Dataframe representing the boolean columns for
                                    which statistics are wanted.

    Returns:
        df (spark dataframe): Dataframe representing the descriptive statistics (rows = variables, columns = statistics).

    Examples:
        df_cat_stats = _compute_categorical_stats(df_spark)

    Notes:
        Author: Camilla Trinderup (G80944)

    """
    # Compute statistics for all columns
    stats = [
        _stat_values_categorical(df_spark, groupby_vars, name) for name in cat_cols
    ]

    # Concatenate statistics
    if groupby_vars is None:

        df_cat_stats = pd.concat(stats, axis=0)

    else:

        df_cat_stats = pd.concat(stats, axis=1)
        df_cat_stats = df_cat_stats.loc[:, ~df_cat_stats.columns.duplicated()]

        # Re index for concatenation with other descriptive statistics
        # index_columns = groupby_vars.copy() + ['stat']
        # df_cat_stats = df_cat_stats.set_index(index_columns)

    return df_cat_stats


def _stat_values_dates_groupby(
    df_spark: psd.DataFrame, groupby_vars: List[Union[str, int]], name: str
) -> pd.DataFrame:

    # Extract relevant columns
    group_cols = groupby_vars.copy()
    group_cols.append(str(name))
    df_tmp = df_spark.select(group_cols)

    # Compute dataframe representing unique values and their individual counts
    df = (
        df_tmp.where(df_tmp[name].isNotNull())
        .groupBy(group_cols)
        .count()
        .orderBy(groupby_vars)
        .toPandas()
        .set_index(groupby_vars)
    )  # .orderBy(f.col('count').desc()).show()
    df = df.rename(columns={name: "top", "count": "freq"})
    df.reset_index(inplace=True)

    # Identify most frequent value.
    df_top = df.loc[df.groupby(groupby_vars)["freq"].idxmax()]
    df_top = df_top.melt(
        id_vars=groupby_vars,
        value_vars=["top", "freq"],
        var_name="stat",
        value_name=name,
    )

    # Count distinct values for each group of grouping variables.
    df_unique = (
        df_spark.where(df_spark[name].isNotNull())
        .groupBy(groupby_vars)
        .agg(f.countDistinct(name).alias(name))
        .toPandas()
        .set_index(groupby_vars)
    )
    df_unique.reset_index(inplace=True)

    # Insert 'stat' column.
    size = df_unique.shape[0]
    df_unique.insert(len(groupby_vars), "stat", ["unique"] * size)

    # Concatenate results in dataframe.
    df_out = pd.concat([df_top, df_unique], axis=0)
    df_out = df_out.reset_index(drop=True)

    return df_out


def _compute_date_stats(
    df_spark: psd.DataFrame, groupby_vars: List[Union[str, int]], date_cols: List[str]
) -> pd.DataFrame:
    """Subfunction for computing the descriptive statistics of the date type columns of
    a spark dataframe. The descriptive statistics are in this case

    *min date
    *max date
    *most frequent date
    *count for most frequent date
    *total number of observations

    Args:
        df_spark (spark dataframe): Dataframe representing the boolean columns for
        which statistics are wanted.

    Returns:
        df (pandas dataframe): Dataframe representing the
        descriptive statistics (rows = variables, columns = statistics).

    Examples:
        df_date_stats = _compute_date_stats(df_spark)

    Notes:
        Author: Camilla Trinderup (G80944)
    """

    if groupby_vars is None:
        # Find column names
        df_spark = df_spark.select(date_cols)
        cols = df_spark.columns

        # Compute min, max values
        min_val = pd.DataFrame(
            df_spark.agg(*[f.min(f.col(c)).alias(c) for c in cols]).collect(),
            columns=cols,
            index=["min"],
        )
        max_val = pd.DataFrame(
            df_spark.agg(*[f.max(f.col(c)).alias(c) for c in cols]).collect(),
            columns=cols,
            index=["max"],
        )

        # Number of unique dates.
        unique_dates = pd.DataFrame(
            df_spark.agg(*[f.countDistinct(f.col(c)).alias(c) for c in cols]).collect(),
            columns=cols,
            index=["unique"],
        )

        # Total number of observations.
        counts = pd.DataFrame(
            df_spark.agg(*[f.count(f.col(c)).alias(c) for c in cols]).collect(),
            columns=cols,
            index=["count"],
        )

        # Sum up current results.
        tmp_df = pd.concat([min_val.T, max_val.T, unique_dates.T, counts.T], axis=1)

        # Define dataframe for output results or most frequent value.
        freq_vals = pd.DataFrame(index=cols, columns=["top", "freq"])

        for name in cols:

            # Compute frequent values.
            stats = (
                df_spark.where(df_spark[name].isNotNull())
                .groupBy(name)
                .count()
                .orderBy(f.col("count").desc())
                .toPandas()
            )

            # Write values to dataframe.
            freq_vals.loc[name, "top"] = stats[name].iloc[0]
            freq_vals.loc[name, "freq"] = stats["count"].iloc[0]

        # Concatenate final statistics.
        df_date_stats = pd.concat([tmp_df, freq_vals], axis=1)

    else:
        # Minimim value / first date.
        min_val = (
            df_spark.groupBy(groupby_vars)
            .agg(*[f.min(f.col(c)).alias(c) for c in date_cols])
            .toPandas()
            .set_index(groupby_vars)
        )
        min_val.reset_index(inplace=True)
        column_names = ["min"]
        size = min_val.shape[0]
        min_val.insert(len(groupby_vars), "stat", column_names * size)

        # Maximum value / last date.
        max_val = (
            df_spark.groupBy(groupby_vars)
            .agg(*[f.max(f.col(c)).alias(c) for c in date_cols])
            .toPandas()
            .set_index(groupby_vars)
        )
        max_val.reset_index(inplace=True)
        stat_name = ["max"]
        max_val.insert(len(groupby_vars), "stat", stat_name * size)

        # Compute count for each column.
        counts = (
            df_spark.groupBy(groupby_vars)
            .agg(*[f.count(f.col(c)).alias(c) for c in date_cols])
            .toPandas()
            .set_index(groupby_vars)
        )
        counts.reset_index(inplace=True)
        counts.insert(len(groupby_vars), "stat", ["count"] * size)

        # Find number of unique values and freq.
        unique_and_top = [
            _stat_values_dates_groupby(df_spark, groupby_vars, name)
            for name in date_cols
        ]
        df_unique_and_top = pd.concat(unique_and_top, axis=1)
        df_unique_and_top = df_unique_and_top.loc[
            :, ~df_unique_and_top.columns.duplicated()
        ]

        # Collect stats in one dataframe.
        df_date_stats = pd.concat([min_val, max_val, counts, df_unique_and_top])

        # Set index for concatenation with other descriptive statistics.
        index_columns = groupby_vars.copy() + ["stat"]
        df_date_stats = df_date_stats.set_index(index_columns)

        # Remove nan indexes.
        c = df_date_stats.index.names
        df_date_stats = df_date_stats.reset_index().dropna().set_index(c)

    return df_date_stats
