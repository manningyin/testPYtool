"""
############
Introduction
############
The EBA guidelines "EBA-RTS-2016-03_IRB" Article 76 - describe in  the following dimensions along which data quality of Pillar I credit risk datasets can be assessed:
    
* completeness: the values are present in the attributes that require them.
* accuracy: the data is substantively error-free.
* consistency: a  given  set  of  data  can  be  matched  across  different  data  sources  of  the institution.
* timeliness: the data values are up to date.
* uniqueness: the  aggregate  data  is  free  from  any  duplication  given  by  filters  or  other transformations of source data.
* validity: the data is founded on an adequate system of classification, rigorous enough to compel acceptance.
* traceability: the  history,  processing  and  location  of  data  under  consideration  can  be  easily traced.

This file contains the validation tools that provide insight into the **completeness** of datasets.
    
Validation tools
================
This section gives an overview of the validation tools available to determine completeness of datasets. These validation tools are model agnostic and thus can be used on any type of dataset.

* **Missing values** - This function calculates the missing values per column for a given Pandas or Spark DataFrame. 
    
Notes
=====
Author: G85538

###################
Test implementation
###################
"""

from typing import List, Union
import pandas as pd
import numpy as np
import itertools
import pyspark.sql.functions as f
import pyspark.sql.dataframe as psd
import pyspark.sql
from pyspark.sql.functions import isnan, when, count, col, mean

# from pyspark.sql import SparkSession

__all__ = ["missing_values"]


def missing_values(df, col_names=None, groupby_cols=None, missing_vals_def=[]):
    """
    This function identifies and summarises the number of
    missing values per specified column per grouping for a
    given Pandas or Spark DataFrame. The function is part of
    the Data Quality testing framework, constituting to the
    EBA recommended DAMA dimension Completeness.
    (EBA-RTS-2016-03_IRB Article 76).

    The function identifies numpy.nan as missing values for
    pandas.DataFrames. The function identifies numpy.nan as
    well as null as missing values for pyspark.sql.DataFrames.
    In addition, the user can specify other definitions of
    missing values in the function (e.g. empty string "" or
    "NA" or "Zero" or 0).

    This function enables the user to deep dive
    into the missing values data by providing multiple levels
    of granularity; for example:

        * Level one aggregation: Calculation of missing values
          per column.
        * Level two aggregation: Calculation of missing values
          per column grouped by another column (e.g. years).
        * Level three aggregation: Calculation of missing
          values per column grouped by two other columns
          (e.g. years and industry).
        * Etcetera.

    Args:
        df (pandas.DataFrame or pyspark.sql.DataFrame): Input dataset.

        col_names (list): (Default=None) Names of columns in
        the dataset to check for missing values. If None, all
        columns in the dataset will be checked for missing
        values.

        groupby_cols (list): (Default=None) List of
        columns to provide groupby calculations on. If None,
        missing values will be calculated on total column level.

        missing_vals_def (list): (Default=[]) A list in which the user can
        specify additional definitions for missing values. The function will
        always check for numpy.nan values in the pandas dataframe
        and numpy.nan and null values in the spark dataframe.

    Returns:
        (dict): A dictionary containing summary table(s) with
        missing values information. The output dataframes
        in the dictionary depends on the level of aggregation
        specified by the user:

        Level one aggregation: Output table (pandas.DataFrame), where

            * column 1: variables.
            * column 2: absolute number of missing values for
              missing value definition 1.
            * column 3: percentage of missing values for
              missing value definition 1.
            * column 4: absolute number of missing values for
              missing value definition 2.
            * column 5: percentage of missing values for
              missing value definition 2.

        Level two or more aggregation: Two output tables (pandas.DataFrame) per
        specified missing values definition (one containing absolute
        missing values for missing values defitnion i and one
        containing relative number of missing values for
        missing values definition i), where the table
        consists of:

            * column 1: groupby_column values.
            * column 2 to n-1: Number missing values.
            * column n: Total number of missing values per
              groupby value.

    Raises:

        ValueError - if df is not a pandas.DataFrame or
        pyspark.sql.DataFrame

    Examples:
        Call function in Python like this::

            dict_miss_vals = missing_values(df,
                            col_names = ['x1', 'x2'],
                            groupby_cols=['x3', 'x4', 'x5']
                            missing_vals_def=["NaN", "Zero"])

    Notes:
        Author: Reinout Kool <G85538>
    """
    # Direct arguments to summary functions. Raise error if incorrect type found.
    if isinstance(df, pd.DataFrame):
        return pandas_missing_values(
            df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )
    elif isinstance(df, psd.DataFrame):
        return spark_missing_values(
            df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )
    else:
        raise TypeError(
            f"Argument 'df' must be either a "
            f"pandas.DataFrame or a "
            f"pyspark.sql.DataFrame, not "
            f"{type(df)}."
        )


def pandas_missing_values(
    df: pd.DataFrame,
    col_names: List[Union[str, int]] = None,
    groupby_cols: List[Union[str, int]] = None,
    missing_vals_def: List[str] = [],
) -> dict:
    """
    This function identifies and summarises the number of
    missing values per specified column per grouping for a
    given Pandas DataFrame. The function is part of
    the Data Quality testing framework, constituting to the
    EBA recommended DAMA dimension Completeness.
    (EBA-RTS-2016-03_IRB Article 76).

    The function identifies numpy.nan as missing values for
    pandas.DataFrames. In addition, the user can specify other
    definitions of missing values in the function (e.g.
    empty string "" or "NA" or "Zero" or 0).

    This function enables the user to deep dive
    into the missing values data by providing multiple levels
    of granularity; for example:

        * Level one aggregation: Calculation of missing values
          per column.
        * Level two aggregation: Calculation of missing values
          per column grouped by another column (e.g. years).
        * Level three aggregation: Calculation of missing
          values per column grouped by two other columns
          (e.g. years and industry).
        * Etcetera.

    Args:
        df (pandas.DataFrame): Input dataset.

        col_names (list): (Default=None) Names of columns in
        the dataset to check for missing values. If None, all
        columns in the dataset will be checked for missing
        values.

        groupby_cols (list): (Default=None) List of
        columns to provide groupby calculations on. If None,
        missing values will be calculated on total column level.

        (Default=[]) A list in which the user can specify additional
        definitions for missing values. The function will always check for
        numpy.nan missing values.

    Returns:
        (dict): A dictionary containing summary table(s) with
        missing values information. The output dataframes
        in the dictionary depends on the level of aggregation
        specified by the user:

        Level one aggregation: Output table (pandas.DataFrame), where

            * column 1: variables.
            * column 2: absolute number of missing values for
              missing value definition 1.
            * column 3: percentage of missing values for
              missing value definition 1.
            * column 4: absolute number of missing values for
              missing value definition 2.
            * column 5: percentage of missing values for
              missing value definition 2.

        Level two or more aggregation: Two output tables (pandas.DataFrame) per
        specified missing values definition (one containing absolute
        missing values for missing values defitnion i and one
        containing relative number of missing values for
        missing values definition i), where the table
        consists of:

            * column 1: groupby_column values.
            * column 2 to n-1: Number missing values.
            * column n: Total number of missing values per
              groupby value.

    Raises:

        ValueError - if df is not a Pandas DataFrame

        ValueError - if df is an empty Pandas DataFrame

        ValueError - if col_names is not a list

        ValueError - if col_names is notan empty list

        ValueError - if missing_vals_def is not a list

        ValueError - if groupby_cols is not a list

        ValueError - if groupby_cols is an empty list

    Examples:
        Call function in Python like this::

            dict_miss_vals = pandas_missing_values(df,
                            col_names = ['x1', 'x2'],
                            groupby_cols=['x3', 'x4', 'x5']
                            missing_vals_def=["Zero"])

    Notes:
        Author: Reinout Kool <G85538>
    """
    # Check if df is a Pandas DataFrame
    if not isinstance(df, pd.DataFrame):
        raise ValueError(
            f"df is not a Pandas DataFrame. Input parameter 'df' "
            f"only accepts Pandas DataFrames as input."
        )

    # Check if df is not empty
    if not len(df) > 0:
        raise ValueError(
            f"Df is an empty Pandas DataFrame. Input parameter 'df' "
            f"only accepts non-empty Pandas DataFrames as input."
        )

    # Check if missing_vals_def is a list
    if not isinstance(missing_vals_def, list):
        raise ValueError(
            f"{missing_vals_def} is not a list. Input parameter "
            f"'missing_vals_def' only accepts a list as input."
        )

    # Check if col_names is a list
    if not isinstance(col_names, list) and not col_names is None:
        raise ValueError(
            f"{col_names} is not a list. Input parameter "
            f"'col_names' only accepts a list as input."
        )

    # Check if col_names is not empty
    if not col_names is None:
        if not len(col_names) > 0:
            raise ValueError(
                f"{col_names} is an empty list. Input parameter "
                f"'col_names' only accepts non-empty lists as "
                f"input."
            )

    # Check if groupby_cols is a list
    if not isinstance(groupby_cols, list) and not groupby_cols is None:
        raise ValueError(
            f"{groupby_cols} is not a list. Input parameter "
            f"'groupby_cols' only accepts a list as input."
        )

    # Check if groupby_cols is not empty
    if not groupby_cols is None:
        if not len(groupby_cols) > 0:
            raise ValueError(
                f"{groupby_cols} is an empty list. Input parameter "
                f"'groupby_cols' only accepts non-empty lists as "
                f"input."
            )

    # Determine level of aggregation and set columns to
    # perform missing_value calculation on.
    if groupby_cols is None:
        agg_level = 1
        if col_names is None:
            col_names = df.columns.tolist()
    else:
        agg_level = 2
        if col_names is None:
            col_names = df.columns.tolist()
            for column in groupby_cols:
                col_names.remove(column)

    # Create dictionary which will store created output dataframes
    df_dict = {}

    # Aggregation level one (Total missing values per column)
    if agg_level == 1:
        # Default calculation for numpy.nan
        missing_vals = []
        # absolute
        missing_vals.append([df[column].isna().sum() for column in col_names])
        # relative
        missing_vals.append(
            [df[column].isna().sum() / len(df[column]) for column in col_names]
        )

        # Check for other definitions
        for mis_def in missing_vals_def:
            # absolute
            missing_vals.append(
                [df[column].isin([mis_def]).sum(axis=0) for column in col_names]
            )
            # relative     \
            missing_vals.append(
                [
                    df[column].isin([mis_def]).sum(axis=0) / len(df[column])
                    for column in col_names
                ]
            )

        # Create index
        missing_vals_def = ["numpy_nan"] + missing_vals_def
        listone = [str(e) for e in missing_vals_def]
        listtwo = ["_absolute", "_relative"]
        index = list("".join(e) for e in itertools.product(listone, listtwo))

        df_dict["df_missing_values"] = pd.DataFrame(
            missing_vals, columns=col_names, index=index
        ).T

    # Aggregation level two (Missing values per column grouped by columns
    # listed in groupby_cols)
    if agg_level == 2:
        # Default calculation for numpy.nan
        df_1 = df[col_names + groupby_cols]
        groupby_level = [i for i in range(len(groupby_cols))]
        df_1 = (
            df_1.set_index(groupby_cols)
            .isna()
            .groupby(level=groupby_level)
            .sum()
            .sort_index()
            .astype(int)
        )

        # Relative missing values
        df_2 = df[groupby_cols]
        df_2 = df_2.groupby(groupby_cols).size().sort_index()
        df_rel = df_1.div(df_2, axis=0)

        # Total for columns (only for absolute values)
        for column in df_1.columns:
            df_1.loc["Total", column] = df_1.sum(axis=0)[column]

        # Total for rows (only for absolute values)
        df_1["Total"] = df_1.sum(axis=1)

        # Add to dictionary
        df_dict["df_numpy_nan_absolute"] = df_1
        df_dict["df_numpy_nan_relative"] = df_rel

        # calculation for other defitions
        for mis_def in missing_vals_def:
            df_1 = df[col_names].isin([mis_def])
            df_1[groupby_cols] = df[groupby_cols]
            df_1 = df_1.groupby(groupby_cols).sum().astype(int).sort_index()

            # relative missing values
            df_rel = df_1.div(df_2, axis=0)

            # Total for columns (only for absolute values)
            for column in df_1.columns:
                df_1.loc["Total", column] = df_1.sum(axis=0)[column]

            # Total for rows (only for absolute values)
            df_1["Total"] = df_1.sum(axis=1)

            # Add to dictionary
            df_dict["df_" + str(mis_def) + "_absolute"] = df_1
            df_dict["df_" + str(mis_def) + "_relative"] = df_rel

    return df_dict


def spark_missing_values(
    df: psd.DataFrame,
    col_names: List[Union[str, int]] = None,
    groupby_cols: List[Union[str, int]] = None,
    missing_vals_def: List[str] = [],
) -> dict:
    """
    This function identifies and summarises the number of
    missing values per specified column per grouping for a
    given Spark DataFrame. The function is part of
    the Data Quality testing framework, constituting to the
    EBA recommended DAMA dimension Completeness.
    (EBA-RTS-2016-03_IRB Article 76).

    The function identifies numpy.nan as well as null as
    missing values for pyspark.sql.DataFrames. In addition,
    the user can specify other definitions of missing values
    in the function (e.g. empty string "" or "NA" or "Zero"
    or 0).

    This function enables the user to deep dive into the
    missing values data by providing multiple levels of
    granularity; for example:

        * Level one aggregation: Calculation of missing values
          per column.
        * Level two aggregation: Calculation of missing values
          per column grouped by another column (e.g. years).
        * Level three aggregation: Calculation of missing
          values per column grouped by two other columns
          (e.g. years and industry).
        * Etcetera.

    Args:
        df (pyspark.sql.DataFrame): Input dataset.

        col_names (list): (Default=None) Names of columns in
        the dataset to check for missing values. If None, all
        columns in the dataset will be checked for missing
        values.

        groupby_cols (list): (Default=None) List of
        columns to provide groupby calculations on. If None,
        missing values will be calculated on total column level.

        missing_vals_def (list): (Default=[]) A list in which the user can
        specify additional definitions for missing values. The function will
        always check for numpy.nan and null missing values.

    Returns:
        (dict): A dictionary containing summary table(s) with
        missing values information. The output dataframes
        in the dictionary depends on the level of aggregation
        specified by the user:

        Level one aggregation: Output table (pandas.DataFrame), where

            * column 1: variables,
            * column 2: absolute number of missing values for
              missing value definition 1.
            * column 3: percentage of missing values for
              missing value definition 1.
            * column 4: absolute number of missing values for
              missing value definition 2.
            * column 5: percentage of missing values for
              missing value definition 2.

        Level two or more aggregation: Two output tables
        (pandas.DataFrame) per specified missing values
        definition (one containing absolute missing values
        for missing values defitnion i and one containing
        relative number of missing values for missing values
        definition i), where the table consists of:

            * column 1: groupby_column values.
            * column 2 to n-1: Number missing values.
            * column n: Total number of missing values per
              groupby value.

    Raises:

        ValueError - if df is not a pyspark.sql.DataFrame

        ValueError - if df is an empty pyspark.sql.DataFrame

        ValueError - if col_names is not a list

        ValueError - if col_names is an empty list

        ValueError - if missing_vals_def is not a list

        ValueError - if groupby_cols is not a list

        ValueError - if groupby_cols is an empty list

    Examples:
        Call function in Python like this::

            dict_miss_vals = spark_missing_values(df,
                            col_names = ['x1', 'x2'],
                            groupby_cols=['x3', 'x4', 'x5']
                            missing_vals_def=["NaN", "Zero"])

    Notes:
        Author: Reinout Kool <G85538>
    """
    # Check if df is a Spark DataFrame
    if not isinstance(df, pyspark.sql.dataframe.DataFrame):
        raise ValueError(
            f"df is not a pyspark.sql.DataFrame. Input parameter 'df' "
            f"only accepts pyspark.sql.DataFrame as input."
        )

    # Check if df is not empty
    if not df.count() > 0:
        raise ValueError(
            f"Df is an empty pyspark.sql.DataFrame. "
            f"Input parameter 'df' only accepts "
            f"non-empty pyspark.sql.DataFrame as input."
        )

    # Check if missing_vals_def is a list
    if not isinstance(missing_vals_def, list):
        raise ValueError(
            f"{missing_vals_def} is not a list. Input parameter "
            f"'missing_vals_def' only accepts a list as input."
        )

    # Check if col_names is a list
    if not isinstance(col_names, list) and not col_names is None:
        raise ValueError(
            f"{col_names} is not a list. Input parameter "
            f"'col_names' only accepts a list as input."
        )

    # Check if col_names is not empty
    if not col_names is None:
        if not len(col_names) > 0:
            raise ValueError(
                f"{col_names} is an empty list. Input parameter "
                f"'col_names' only accepts non-empty lists as "
                f"input."
            )

    # Check if groupby_cols is a list
    if not isinstance(groupby_cols, list) and not groupby_cols is None:
        raise ValueError(
            f"{groupby_cols} is not a list. Input parameter "
            f"'groupby_cols' only accepts a list as input."
        )

    # Check if groupby_cols is not empty
    if not groupby_cols is None:
        if not len(groupby_cols) > 0:
            raise ValueError(
                f"{groupby_cols} is an empty list. Input parameter "
                f"'groupby_cols' only accepts non-empty lists as "
                f"input."
            )

    # Determine level of aggregation and set columns to
    # perform missing_value calculation on.
    if groupby_cols is None:
        agg_level = 1
        if col_names is None:
            col_names = df.columns
    else:
        agg_level = 2
        if col_names is None:
            col_names = df.columns
            for column in groupby_cols:
                col_names.remove(column)

    # Create dictionary which will store created output dataframes
    df_dict = {}

    # Aggregation level one (Total missing values per column)
    if agg_level == 1:
        df_missing_values = None

        # Default calculation for numpy.nan and null output in transposed pandas df
        df_nan = (
            df.select([count(when(f.isnan(c), c)).alias(c) for c in col_names])
            .toPandas()
            .T
        )
        df_null = (
            df.select([count(when(f.isnull(c), c)).alias(c) for c in col_names])
            .toPandas()
            .T
        )

        # Rename cols
        df_nan.rename(columns={0: "numpy_nan_absolute"}, inplace=True)
        df_null.rename(columns={0: "null_absolute"}, inplace=True)

        # relative values
        total = df.count()
        df_nan["numpy_nan_relative"] = df_nan["numpy_nan_absolute"] / total
        df_null["null_relative"] = df_null["null_absolute"] / total

        # Create total dataframe
        df_missing_values = df_nan.merge(
            right=df_null, left_index=True, right_index=True
        )

        # Calculation for other definitions
        for mis_def in missing_vals_def:
            missing_vals = []
            # absolute
            abs_val_list = []
            for column in col_names:
                # Create new df with binary values  for each column
                # (1 if value == mis_def) ( 0 if value != misdef)
                df1 = df.select(column)
                df1 = df1.withColumn(
                    column, when(df1[column] == mis_def, 1).otherwise(0)
                )
                abs_val_list.append(df1.select(f.sum(f.col(column))).collect()[0][0])
            # relative
            missing_vals.append(abs_val_list)
            total = df.count()
            missing_vals.append([miss_val / total for miss_val in abs_val_list])

            # Create index
            index = [str(mis_def) + "_absolute", str(mis_def) + "_relative"]

            # Create total dataframe
            df_pre_merge = pd.DataFrame(missing_vals, columns=col_names, index=index).T
            df_missing_values = df_missing_values.merge(
                right=df_pre_merge, left_index=True, right_index=True
            )

        df_dict["df_missing_values"] = df_missing_values

    else:
        # Default calculation for numpy.nan and null
        # np.nan missing values
        df_nan_abs = (
            df.groupBy(groupby_cols)
            .agg(*[count(when(f.isnan(c), c)).alias(c) for c in col_names])
            .toPandas()
            .set_index(groupby_cols)
            .sort_index()
        )

        # null missing values
        df_null_abs = (
            df.groupBy(groupby_cols)
            .agg(*[count(when(f.isnull(c), c)).alias(c) for c in col_names])
            .toPandas()
            .set_index(groupby_cols)
            .sort_index()
        )

        # Relative missing values
        df_2 = (
            df.groupBy(groupby_cols)
            .count()
            .orderBy("count")
            .toPandas()
            .set_index(groupby_cols)
            .sort_index()
        )
        df_nan_rel, df_null_rel = df_nan_abs.copy(), df_null_abs.copy()
        for column in df_nan_abs.columns:
            df_nan_rel[column] = df_nan_abs[column] / df_2["count"]
            df_null_rel[column] = df_null_abs[column] / df_2["count"]

        # Total for columns
        for column in df_nan_abs.columns:
            df_nan_abs.loc["Total", column] = df_nan_abs.sum(axis=0)[column]
        for column in df_null_abs.columns:
            df_null_abs.loc["Total", column] = df_null_abs.sum(axis=0)[column]

        # Add total for rows
        df_nan_abs["Total"] = df_nan_abs.sum(axis=1)
        df_null_abs["Total"] = df_null_abs.sum(axis=1)

        # Add to dictionary
        df_dict["df_numpy_nan_absolute"] = df_nan_abs
        df_dict["df_numpy_nan_relative"] = df_nan_rel
        df_dict["df_null_absolute"] = df_null_abs
        df_dict["df_null_relative"] = df_null_rel

        for mis_def in missing_vals_def:
            # absolute
            df1 = df.select(col_names + groupby_cols)
            # Create new df with binary values  for each column
            # (1 if value == mis_def) ( 0 if value != misdef)
            for column in col_names:
                df1 = df1.withColumn(
                    column, when(df1[column] == mis_def, 1).otherwise(0)
                )

            # Create output df
            df_1 = df1.groupBy(groupby_cols).sum(*col_names).toPandas()
            df_1.set_index(groupby_cols, inplace=True)
            df_1.columns = col_names
            df_1 = df_1.sort_index()

            df_rel = df_1.copy()
            for column in df_1.columns:
                df_rel[column] = df_1[column] / df_2["count"]

            # Total for columns
            for column in df_1.columns:
                df_1.loc["Total", column] = df_1.sum(axis=0)[column]

            # Add total for rows
            df_1["Total"] = df_1.sum(axis=1)

            # Add to dictionary
            df_dict["df_" + str(mis_def) + "_absolute"] = df_1
            df_dict["df_" + str(mis_def) + "_relative"] = df_rel

    return df_dict
