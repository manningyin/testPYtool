"""
############
Introduction
############
The EBA guidelines "EBA-RTS-2016-03_IRB" Article 76 - describe in the following dimensions along which data quality of Pillar I credit risk datasets can be assessed:

* completeness: the values are present in the attributes that require them.
* accuracy: the data is substantively error-free.
* consistency: a  given  set  of  data  can  be  matched  across  different  data  sources  of  the institution.
* timeliness: the data values are up to date.
* uniqueness: the  aggregate  data  is  free  from  any  duplication  given  by  filters  or  other transformations of source data.
* validity: the data is founded on an adequate system of classification, rigorous enough to compel acceptance.
* traceability: the  history,  processing  and  location  of  data  under  consideration  can  be  easily traced.

This file contains the validation tools that provide insight into the **uniqueness** of datasets.
    
Validation tools
================
This section gives an overview of the validation tools available to determine uniqueness of datasets. These validation tools are model agnostic and thus can be used on any type of dataset.

* **Identify and summarise duplicates** - This function identifies the duplicates per column or a combination of columns for a given Pandas or Spark DataFrame. 
    
Notes
=====
Author: G85538

###################
Test implementation
###################
"""
from typing import List, Union
import pandas as pd
import numpy as np
import pyspark.sql.functions as f
from pyspark.sql.window import Window as w
from pyspark.sql.types import StructType, StructField, StringType
import pyspark.sql.dataframe as psd
import pyspark.sql
from pyspark.sql.functions import isnan, when, count, col, mean
from typing_extensions import Literal
from crv.utils.spark_helper import spark_create_index_col

__all__ = ["duplicates"]


def duplicates(
    df: Union[pd.DataFrame, psd.DataFrame],
    col_names: List[Union[str, int]] = None,
    groupby_cols: List[Union[str, int]] = None,
    single_or_combination: Literal["single", "combination"] = "single",
    mark_duplicates: Literal[None, "all", "first", "last"] = None,
) -> dict:
    """
    This function identifies and summarises the number of
    duplicated values for specified columns or a combination of columns per
    grouping for a given Pandas DataFrame. The function is part of the Data
    Quality testing framework, constituting to the EBA recommended DAMA
    dimension Uniqueness.(EBA-RTS-2016-03_IRB Article 76).

    The function outputs a summary table with statistics on the number of
    duplicates. In addition, the function has the option to output a dataframe
    with the positions of duplicates in the input dataframe, which allows the
    user to further investigate the duplicates.

    For the output table containing the summary statistics, the user has the
    optionality to view the statistics on an aggregation level, i.e. view
    the absolute and relative number of duplicated values per column or a
    combination of columns); but also on grouped-by level(s), i.e. view
    the absolute and relative number of duplicated values per column or a
    combination of columns for each groupby group. Note that the in case of
    the groupby functionality, the function first identifies duplicated values
    on a total table level and then identifies how much of these duplicated
    values fall in a specific group.

    Args:
        df (pandas.DataFrame, pyspark.sql.DataFrame): Input dataset.

        col_names (list): (Default=None) Names of columns in
        the dataset to check for duplicates. If None, all
        columns in the dataset will be checked for duplicates.

        groupby_cols (list): (Default=None) List of
        columns to provide groupby calculations on. If None,
        duplicates will be identified and summarised on total column level.

        single_or_combination (str): (default='single') Options are 'single'
        and 'combination'. 'single' checks for duplicates per specified column
        in col_names. 'combination' checks for duplicate records in a
        combination of columns as specified in col_names.

        mark_duplicates (str): (default=None) Options are None, 'all', 'first',
        'last'. This parameter provides the user the option to return a
        dataframe (df_duplicate_marks) in which the positions of duplicates in
        the input df are marked. If mark_duplicates = None, df_duplicate_marks
        is not returned. If mark_duplicates = 'all', all duplicate records are
        marked in df_duplicate_marks with True for duplicate and False for
        non-duplicate. If mark_duplicates = 'first', the first duplicate
        records are marked in df_duplicate_marks with True for duplicate and
        False for non-duplicate. If mark_duplicates = 'last', the last duplicate
        records are marked in df_duplicate_marks with True for duplicate and
        False for non-duplicate.

    Returns:
        (dict): A dictionary containing dataframes with duplicates information:

            df_duplicates_statistics (pandas.DataFrame): Dataframe containing
            summary statistics on the number of duplicates (absolute and relative)

            df_duplicate_marks (pandas.DataFrame, pyspark.sql.DataFrame):
            Dataframe containing the positions of duplicates of the input
            df statistics with True for duplicate and False for non-duplicate.

            df_duplicates_absolute_statistics (pandas.DataFrame): Dataframe
            containing the absolute number of summary statistics for single
            grouped-by columns. Note: this dataframe is only returned when
            single_or_combination='single' and groupby_cols is not None.

            df_duplicates_relative_statistics (pandas.DataFrame): Dataframe
            containing the relative number of summary statistics for single
            grouped-by columns. Note: this dataframe is only returned when
            single_or_combination='single' and groupby_cols is not None.

    Raises:

        ValueError - if df is not a pandas.DataFrame or
        pyspark.sql.DataFrame

    Examples:
        Call function in Python like this::

            dict_dupl_vals = duplicates(df,
                            col_names = ['x1', 'x2'],
                            groupby_cols=['x3', 'x4', 'x5'],
                            single_or_combination='single',
                            mark_duplicates="all")

    Notes:
        Author: Reinout Kool <G85538>
    """
    # Direct arguments to summary functions. Raise error if incorrect type found.
    if isinstance(df, pd.DataFrame):
        return _pandas_duplicates(
            df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )
    elif isinstance(df, psd.DataFrame):
        return _spark_duplicates(
            df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )
    else:
        raise TypeError(
            f"Argument 'df' must be either a "
            f"pandas.DataFrame or a "
            f"pyspark.sql.DataFrame, not "
            f"{type(df)}."
        )


def _pandas_duplicates(
    df,
    col_names=None,
    groupby_cols=None,
    single_or_combination="single",
    mark_duplicates=None,
):

    """
    This function identifies and summarises the number of
    duplicates values for specified columns or a combination of columns per
    grouping for a given PandasDataFrame. The function is part of the Data
    Quality testing framework, constituting to the EBA recommended DAMA
    dimension Uniqueness.(EBA-RTS-2016-03_IRB Article 76).

    The function outputs a summary table with statistics on the number of
    duplicates. In addition, the function has the option to output a dataframe
    with the positions of duplicates in the input dataframe, which allows the
    user to further investigate the duplicates.

    For the output table containing the summary statistics, the user has the
    optionality to view the statistics on an aggregation level, i.e. view
    the absolute and relative number of duplicated values per column or a
    combination of columns); but also on grouped-by level(s), i.e. view
    the absolute and relative number of duplicated values per column or a
    combination of columns for each groupby group. Note that the in case of
    the groupby functionality, the function first identifies duplicated values
    on a total table level and then identifies how much of these duplicated
    values fall in a specific group.

    Args:
        df (pandas.DataFrame): Input dataset.

        col_names (list): (Default=None) Names of columns in
        the dataset to check for duplicates. If None, all
        columns in the dataset will be checked for duplicates.

        groupby_cols (list): (Default=None) List of
        columns to provide groupby calculations on. If None,
        duplicates will be identified and summarised on total column level.

        single_or_combination (str): (default='single') Options are 'single'
        and 'combination'. 'single' checks for duplicates per specified column
        in col_names. 'combination' checks for duplicate records in a
        combination of columns as specified in col_names.

        mark_duplicates (str): (default=None) Options are None, 'all', 'first',
        'last'. This parameter provides the user the option to return a
        dataframe (df_duplicate_marks) in which the positions of duplicates in
        the input df are marked. If mark_duplicates = None, df_duplicate_marks
        is not returned. If mark_duplicates = 'all', all duplicate records are
        marked in df_duplicate_marks with True for duplicate and False for
        non-duplicate. If mark_duplicates = 'first', the first duplicate
        records are marked in df_duplicate_marks with True for duplicate and
        False for non-duplicate. If mark_duplicates = 'last', the last duplicate
        records are marked in df_duplicate_marks with True for duplicate and
        False for non-duplicate.

    Returns:
        (dict): A dictionary containing dataframes with duplicates information:

            df_duplicates_statistics (pandas.DataFrame): Dataframe containing
            summary statistics on the number of duplicates (absolute and relative)

            df_duplicate_marks (pandas.DataFrame): Dataframe containing the
            positions of duplicates of the input df statistics with True for
            duplicate and False for non-duplicate.

            df_duplicates_absolute_statistics (pandas.DataFrame): Dataframe
            containing the absolute number of summary statistics for single
            grouped-by columns. Note: this dataframe is only returned when
            single_or_combination='single' and groupby_cols is not None.

            df_duplicates_relative_statistics (pandas.DataFrame): Dataframe
            containing the relative number of summary statistics for single
            grouped-by columns. Note: this dataframe is only returned when
            single_or_combination='single' and groupby_cols is not None.

    Raises:

        ValueError - if df is not a Pandas DataFrame

        ValueError - if df is an empty Pandas DataFrame

        ValueError - if col_names is not a list

        ValueError - if col_names is an empty list

        ValueError - if groupby_cols is not a list

        ValueError - if groupby_cols is an empty list

        ValueError - if single_or_combination is not either of the options:
            'single' or 'combination'.

        ValueError - if mark_duplicates is not either of the options: None,
        'all', 'first', 'last'.

    Examples:
        Call function in Python like this::

            dict_dupl_vals = _pandas_duplicates(df,
                            col_names = ['x1', 'x2'],
                            groupby_cols=['x3', 'x4', 'x5'],
                            single_or_combination='single',
                            mark_duplicates="all")

    Notes:
        Author: Reinout Kool <G85538>
    """

    # Check if df is a Pandas DataFrame
    if not isinstance(df, pd.DataFrame):
        raise ValueError(
            f"df is not a pandas.DataFrame. Input parameter 'df' "
            f"only accepts pandas.DataFrames as input."
        )

    # Check if df is not empty
    if not len(df) > 0:
        raise ValueError(
            f"df is an empty pandas.DataFrame. Input parameter 'df' "
            f"only accepts non-empty pandas.DataFrames as input."
        )

    # Check if groupby_cols is a list
    if not isinstance(groupby_cols, list) and groupby_cols is not None:
        raise ValueError(
            f"{groupby_cols} is not a list. Input parameter "
            f"'groupby_cols' only accepts a list as input."
        )

    # Check if groupby_cols is not empty
    if groupby_cols is not None and not len(groupby_cols) > 0:
        raise ValueError(
            f"{groupby_cols} is an empty list. Input parameter "
            f"'groupby_cols' only accepts non-empty lists as "
            f"input."
        )

    # Check if col_names is a list
    if not isinstance(col_names, list) and col_names is not None:
        raise ValueError(
            f"{col_names} is not a list. Input parameter "
            f"'col_names' only accepts a list as input."
        )

    # Check if col_names is not empty
    if col_names is not None and not len(col_names) > 0:
        raise ValueError(
            f"{col_names} is an empty list. Input parameter "
            f"'col_names' only accepts non-empty lists as "
            f"input."
        )

    # Check if single_or_combination is either 'single' or 'combination'.
    if single_or_combination not in ["single", "combination"]:
        raise ValueError(
            f"{single_or_combination} must be either of value 'single' or "
            f"'combination'. "
        )

    # Check if mark_duplicates is either None, 'all', 'first', 'last'
    if mark_duplicates not in [None, "all", "first", "last"]:
        raise ValueError(
            f"{single_or_combination} must be either of value None, 'all', "
            f"'first', 'last'. "
        )

    # Output dictionary
    dict_dup = {}

    # Define col_names and remove groupby cols from col_names
    if col_names is None:
        col_names = df.columns.tolist()
        if groupby_cols is not None:
            col_names = [column for column in col_names if column not in groupby_cols]
    else:
        if groupby_cols is not None:
            col_names = [column for column in col_names if column not in groupby_cols]

    if single_or_combination == "single":
        # Calculate the duplicates statistics - no groupby
        # (number and percentage of duplicates per column)
        if groupby_cols is None:
            abs_vals = [df.duplicated(column, keep=False).sum() for column in col_names]
            rel_vals = [
                df.duplicated(column, keep=False).sum() / len(df)
                for column in col_names
            ]

            # Create df and write to dictionary
            dict_dup["df_duplicates_statistics"] = pd.DataFrame(
                list(zip(col_names, abs_vals, rel_vals)),
                columns=["Column", "Number of duplicates", "Percentage of duplicates"],
            )

        # Calculate the duplicates statistics - groupby
        # (number and percentage of duplicates per column)
        else:
            # mark duplicates (1=duplicate, 0=no duplicate)
            dup_marks = {
                column: list(df.duplicated(column, keep=False)) for column in col_names
            }
            df_dup_marks = pd.DataFrame(dup_marks)
            df_1 = df[groupby_cols].join(df_dup_marks)

            # Count duplicates grouped by
            df_abs = df_1.groupby(groupby_cols).sum().sort_index()
            df_rel = df_abs / len(df)

            # Add row containing total
            for column in df_abs.columns:
                df_abs.loc["Total", column] = df_abs.sum(axis=0)[column]
                df_rel.loc["Total", column] = df_rel.sum(axis=0)[column]

            # Write to dictionary
            dict_dup["df_duplicates_absolute_statistics"] = df_abs.astype(int)
            dict_dup["df_duplicates_relative_statistics"] = df_rel.round(3)

        # Provide a dataframe with positions of duplicates
        if mark_duplicates is not None:
            dict_mark_labels = {"first": "last", "last": "first", "all": False}

            mark_labels = dict_mark_labels[mark_duplicates]

            dup_marks = {
                column: list(df.duplicated(column, keep=mark_labels))
                for column in col_names
            }
            dict_dup["df_duplicate_marks"] = pd.DataFrame(dup_marks)

    if single_or_combination == "combination":
        # Calculate the duplicates statistics - no groupby
        # (number and percentage of duplicates per column)
        if groupby_cols is None:
            abs_vals = int(df.duplicated(col_names, keep=False).sum())
            rel_vals = abs_vals / len(df)

            # Names for combination of columns
            for i in range(len(col_names)):
                if i == 0:
                    comb_col_names = col_names[i]
                else:
                    comb_col_names = comb_col_names + " & " + col_names[i]

            dict_dup["df_duplicates_statistics"] = pd.DataFrame(
                {
                    "Combination of columns": comb_col_names,
                    "Number of duplicates": abs_vals,
                    "Percentage of duplicates": rel_vals,
                },
                index=[0],
            )

        # Calculate the duplicates statistics - groupby (number and percentage of duplicates)
        else:
            dup_marks = {"duplicate count": df.duplicated(col_names, keep=False)}
            df_dup_marks = pd.DataFrame(dup_marks)
            df_1 = df[groupby_cols].join(df_dup_marks)

            # Count duplicates grouped by
            df_1 = df_1.groupby(groupby_cols).sum().sort_index().astype(int)
            df_1["Percentage of duplicates"] = df_1 / len(df)

            for column in df_1:
                df_1.loc["Total", column] = df_1.sum(axis=0)[column]

            dict_dup["df_duplicates_statistics"] = df_1

        # Provide a dataframe with positions of duplicates
        if mark_duplicates is not None:
            # Names for combination of columns
            for i in range(len(col_names)):
                if i == 0:
                    comb_col_names = col_names[i]
                else:
                    comb_col_names = comb_col_names + " & " + col_names[i]

            dict_mark_labels = {"first": "last", "last": "first", "all": False}

            mark_labels = dict_mark_labels[mark_duplicates]

            dup_marks = {comb_col_names: df.duplicated(col_names, keep=mark_labels)}
            dict_dup["df_duplicate_marks"] = pd.DataFrame(dup_marks)

    return dict_dup


def _spark_duplicates(
    df: pd.DataFrame,
    col_names: List[Union[str, int]] = None,
    groupby_cols: List[Union[str, int]] = None,
    single_or_combination: Literal["single", "combination"] = "single",
    mark_duplicates: Literal[None, "all", "first", "last"] = None,
) -> dict:
    """
    This function identifies and summarises the number of
    duplicated values for specified columns or a combination of columns per
    grouping for a given Spark DataFrame. The function is part of the Data
    Quality testing framework, constituting to the EBA recommended DAMA
    dimension Uniqueness.(EBA-RTS-2016-03_IRB Article 76).

    The function outputs a summary table with statistics on the number of
    duplicates. In addition, the function has the option to output a dataframe
    with the positions of duplicates in the input dataframe, which allows the
    user to further investigate the duplicates.

    For the output table containing the summary statistics, the user has the
    optionality to view the statistics on an aggregation level, i.e. view
    the absolute and relative number of duplicated values per column or a
    combination of columns); but also on grouped-by level(s), i.e. view
    the absolute and relative number of duplicated values per column or a
    combination of columns for each groupby group. Note that the in case of
    the groupby functionality, the function first identifies duplicated values
    on a total table level and then identifies how much of these duplicated
    values fall in a specific group.

    Args:
        df (pyspark.sql.DataFrame): Input dataset.

        col_names (list): (Default=None) Names of columns in
        the dataset to check for duplicates. If None, all
        columns in the dataset will be checked for duplicates.

        groupby_cols (list): (Default=None) List of
        columns to provide groupby calculations on. If None,
        duplicates will be identified and summarised on total column level.

        single_or_combination (str): (default='single') Options are 'single'
        and 'combination'. 'single' checks for duplicates per specified column
        in col_names. 'combination' checks for duplicate records in a
        combination of columns as specified in col_names.

        mark_duplicates (str): (default=None) Options are None, 'all', 'first',
        'last'. This parameter provides the user the option to return a
        dataframe (df_duplicate_marks) in which the positions of duplicates in
        the input df are marked. If mark_duplicates = None, df_duplicate_marks
        is not returned. If mark_duplicates = 'all', all duplicate records are
        marked in df_duplicate_marks with True for duplicate and False for
        non-duplicate. If mark_duplicates = 'first', the first duplicate
        records are marked in df_duplicate_marks with True for duplicate and
        False for non-duplicate. If mark_duplicates = 'last', the last duplicate
        records are marked in df_duplicate_marks with True for duplicate and
        False for non-duplicate.

    Returns:
        (dict): A dictionary containing dataframes with duplicates information:

            df_duplicates_statistics (pandas.DataFrame): Dataframe containing
            summary statistics on the number of duplicates (absolute and relative)

            df_duplicate_marks (pyspark.sql.DataFrame): Dataframe containing
            the positions of duplicates of the input df statistics with True
            for duplicate and False for non-duplicate.

            df_duplicates_absolute_statistics (pandas.DataFrame): Dataframe
            containing the absolute number of summary statistics for single
            grouped-by columns. Note: this dataframe is only returned when
            single_or_combination='single' and groupby_cols is not None.

            df_duplicates_relative_statistics (pandas.DataFrame): Dataframe
            containing the relative number of summary statistics for single
            grouped-by columns. Note: this dataframe is only returned when
            single_or_combination='single' and groupby_cols is not None.

    Raises:

        ValueError - if df is not a pyspark.sql.DataFrame

        ValueError - if df is an empty pyspark.sql.DataFrame

        ValueError - if col_names is not a list

        ValueError - if col_names is an empty list

        ValueError - if groupby_cols is not a list

        ValueError - if groupby_cols is an empty list

        ValueError - if single_or_combination is not either of the options:
            'single' or 'combination'.

        ValueError - if mark_duplicates is not either of the options: None,
        'all', 'first', 'last'.

    Examples:
        Call function in Python like this::

            dict_dupl_vals = _spark_duplicates(df,
                            col_names = ['x1', 'x2'],
                            groupby_cols=['x3', 'x4', 'x5'],
                            single_or_combination='single',
                            mark_duplicates="all")

    Notes:
        Author: Reinout Kool <G85538>
    """

    # Check if df is a Pandas DataFrame
    if not isinstance(df, pyspark.sql.DataFrame):
        raise ValueError(
            f"df is not a pyspark.sql.DataFrame. Input parameter "
            f"'df' only accepts pyspark.sql.DataFrame as input."
        )

    # Check if df is not empty
    if not df.count() > 0:
        raise ValueError(
            f"df is an empty pyspark.sql.DataFrame. Input "
            f"parameter 'df' only accepts non-empty "
            f"pyspark.sql.DataFrame as input."
        )

    # Check if groupby_cols is a list
    if not isinstance(groupby_cols, list) and groupby_cols is not None:
        raise ValueError(
            f"{groupby_cols} is not a list. Input parameter "
            f"'groupby_cols' only accepts a list as input."
        )

    # Check if groupby_cols is not empty
    if groupby_cols is not None and not len(groupby_cols) > 0:
        raise ValueError(
            f"{groupby_cols} is an empty list. Input parameter "
            f"'groupby_cols' only accepts non-empty lists as "
            f"input."
        )

    # Check if col_names is a list
    if not isinstance(col_names, list) and col_names is not None:
        raise ValueError(
            f"{col_names} is not a list. Input parameter "
            f"'col_names' only accepts a list as input."
        )

    # Check if col_names is not empty
    if col_names is not None and not len(col_names) > 0:
        raise ValueError(
            f"{col_names} is an empty list. Input parameter "
            f"'col_names' only accepts non-empty lists as "
            f"input."
        )

    # Check if single_or_combination is either 'single' or 'combination'.
    if single_or_combination not in ["single", "combination"]:
        raise ValueError(
            f"{single_or_combination} must be either of value 'single' or "
            f"'combination'. "
        )

    # Check if mark_duplicates is either None, 'all', 'first', 'last'
    if mark_duplicates not in [None, "all", "first", "last"]:
        raise ValueError(
            f"{single_or_combination} must be either of value None, 'all', "
            f"'first', 'last'. "
        )

    # Function to mark all duplicates
    def write_column_duplicates(
        df: psd.DataFrame, mark_col: str, column: str, dup_marks: psd.DataFrame = None
    ) -> psd.DataFrame:
        """
        This sub-function is to write duplicate columns to a joint spark df.
        This sub-function is specific to _spark_duplicates and has been created
        to avoid double coding.

        Args:
            df (pyspark.sql.DataFrame): Input Spark dataframe containing the
            to be added marked duplicate column

            mark_col (str): Column that needs to be added

            column (str): Name of the column to be added

            df_mark (pyspark.sql.DataFrame): (Default=None) Spark dataframe to
            which the marked duplicate columns should be added to. If option
            is None, df_mark will be created containing the duplicated values
            of the column specified in 'mark_col'.

        Returns:
            df (pyspark.sql.DataFrame): Joint spark df

        Examples:
            Call function in Python like this::

                write_column_duplicates(df, df_mark=None, column)

        Notes:
            Author: Reinout Kool <G85538>
        """
        if dup_marks is None:
            dup_marks = df.select(col("idx").alias("idx"), col(mark_col).alias(column))
        else:
            df = df.select(col("idx").alias("idx1"), col(mark_col).alias(column))
            dup_marks = dup_marks.join(df, dup_marks.idx == df.idx1).drop("idx1")

        return dup_marks

    # Counter
    def counter(
        df: psd.DataFrame, column: List[Union[str, int]], index: str
    ) -> psd.DataFrame:
        """
        Spark counter function which cumulatively calculates the number
        of observations per group. This sub-function is specific to
        _spark_duplicates and has been created to avoid double coding.

        Args:
            df (pyspark.sql.DataFrame): Input Spark dataframe containing the
            to be added marked duplicate column

            column (str, list): Name(s) of the column on which to cumulatively
            calculate the number of observations per group

            index (str): Name of the index column

        Returns:
            df (pyspark.sql.DataFrame): Input df with an added column (named
            "mark") entailing the cumulative counter

        Examples:
            Call function in Python like this::

                df = counter(df, column="col1", index="idx")

        Notes:
            Author: Reinout Kool <G85538>
        """
        if isinstance(column, str):
            part_list = [column, "mark"]
        else:
            part_list = column + ["mark"]

        # counter
        partition = w.partitionBy(part_list).orderBy(index)
        df = df.withColumn("counter", f.count("*").over(partition))

        return df

    # Output dictionary
    dict_dup = {}

    # Define col_names and remove groupby cols from col_names
    if col_names is None:
        col_names = df.columns
        if groupby_cols is not None:
            col_names = [column for column in col_names if column not in groupby_cols]
    else:
        if groupby_cols is not None:
            col_names = [column for column in col_names if column not in groupby_cols]

    if single_or_combination == "single":
        # Mark the duplicates in the input df
        for column in col_names:
            # Select column
            df_col = df.select(column)

            # Create an index
            df_col = spark_create_index_col(df_col, order="asc", index_name="idx")

            # Mark duplicates per column
            df_col = df_col.join(
                df_col.groupBy(column).agg(
                    (f.count("*") > 1).cast("int").alias("mark")
                ),
                on=column,
                how="inner",
            ).orderBy(f.asc("idx"))

            # Write marked duplicates per column to dup_marks
            if column == col_names[0]:
                dup_marks = write_column_duplicates(
                    df_col, "mark", column, dup_marks=None
                )
            else:
                dup_marks = write_column_duplicates(
                    df_col, "mark", column, dup_marks=dup_marks
                )

        # Calculate the duplicates statistics - no groupby
        # (number and percentage of duplicates per column)
        if groupby_cols is None:
            # Create df_duplicates_statistics
            df_dup_stats = (
                dup_marks.groupBy().sum().toPandas().drop(columns=["sum(idx)"])
            )
            df_dup_stats.columns = col_names
            df_dup_stats = df_dup_stats.T
            df_dup_stats = df_dup_stats.reset_index().rename(
                columns={"index": "Column", 0: "Number of duplicates"}
            )
            df_dup_stats["Percentage of duplicates"] = (
                df_dup_stats["Number of duplicates"] / df.count()
            )

            dict_dup["df_duplicates_statistics"] = df_dup_stats

        # Calculate the duplicates statistics - grouped by
        # (number and percentage of duplicates per column - output: 2 dataframes)
        else:
            # Create grouped-by columns
            df_col = df.select(groupby_cols)

            # Create an index for df_col
            df_col = spark_create_index_col(df_col, order="asc", index_name="idx1")

            # Merge groupedby cols with duplicates marks (dup_marks)
            df_dup_abs = (
                dup_marks.join(df_col, dup_marks.idx == df_col.idx1)
                .orderBy(f.asc("idx"))
                .drop("idx")
                .drop("idx1")
            )

            # Absolute duplicates statistics
            df_dup_abs = df_dup_abs.groupBy(groupby_cols).sum(*col_names).toPandas()
            df_dup_abs.set_index(groupby_cols, inplace=True)
            df_dup_abs.columns = col_names
            df_dup_abs = df_dup_abs.sort_index()

            dict_dup["df_duplicates_absolute_statistics"] = df_dup_abs.astype(int)

            # Relative duplicates statistics
            df_dup_rel = df_dup_abs / df.count()
            dict_dup["df_duplicates_relative_statistics"] = df_dup_rel.round(3)

        if mark_duplicates == "all":
            dict_dup["df_duplicate_marks"] = dup_marks.orderBy(f.asc("idx")).drop("idx")

        if mark_duplicates == "last":
            for column in col_names:
                # Select column
                df_col = df.select(column)

                # Create an index
                df_col = spark_create_index_col(df_col, order="asc", index_name="idx")

                # Mark duplicates per column
                df_col = df_col.join(
                    df_col.groupBy(column).agg(
                        (f.count("*") > 1).cast("int").alias("mark")
                    ),
                    on=column,
                    how="inner",
                ).orderBy(f.asc("idx"))

                # De-mark first duplicates
                df_col = counter(df_col, column, "idx")
                df_col = df_col.withColumn(
                    "last_marks",
                    when((df_col["mark"] == 1) & (df_col["counter"] == 1), 0)
                    .when(df_col["counter"] > 1, 1)
                    .otherwise(0),
                )

                df_col = df_col.orderBy(f.asc("idx"))

                # Write marked duplicates per column to dup_marks
                if column == col_names[0]:
                    dup_marks = write_column_duplicates(
                        df_col, "last_marks", column, dup_marks=None
                    )
                else:
                    dup_marks = write_column_duplicates(
                        df_col, "last_marks", column, dup_marks=dup_marks
                    )

            dict_dup["df_duplicate_marks"] = dup_marks.orderBy(f.asc("idx")).drop("idx")

        if mark_duplicates == "first":
            for column in col_names:
                # Select column
                df_col = df.select(column)

                # Create an ascending index
                df_col = spark_create_index_col(df_col, order="asc", index_name="idx")

                # Create a descending index
                df_col = spark_create_index_col(
                    df_col, order="desc", index_name="idx_desc"
                )

                # Mark duplicates per row
                df_col = df_col.join(
                    df_col.groupBy(column).agg(
                        (f.count("*") > 1).cast("int").alias("mark")
                    ),
                    on=column,
                    how="inner",
                ).orderBy(f.asc("idx_desc"))

                # De-mark last duplicates
                df_col = counter(df_col, column, "idx_desc")
                df_col = df_col.withColumn(
                    "last_marks",
                    when((df_col["mark"] == 1) & (df_col["counter"] == 1), 0)
                    .when(df_col["counter"] > 1, 1)
                    .otherwise(0),
                )

                df_col = df_col.orderBy(f.asc("idx"))

                # Write marked duplicates per column to dup_marks
                if column == col_names[0]:
                    dup_marks = write_column_duplicates(
                        df_col, "last_marks", column, dup_marks=None
                    )
                else:
                    dup_marks = write_column_duplicates(
                        df_col, "last_marks", column, dup_marks=dup_marks
                    )

            dict_dup["df_duplicate_marks"] = dup_marks.orderBy(f.asc("idx")).drop("idx")

    if single_or_combination == "combination":
        # Select columns
        df_col = df.select(col_names)

        # Create an index
        df_col = spark_create_index_col(df_col, order="asc", index_name="idx")

        # Mark duplicates per row
        dup_marks = df_col.join(
            df_col.groupBy(col_names).agg((f.count("*") > 1).cast("int").alias("mark")),
            on=col_names,
            how="inner",
        ).orderBy(f.asc("idx"))

        for column in col_names:
            dup_marks = dup_marks.drop(column)

        # Names for combination of columns
        for i in range(len(col_names)):
            if i == 0:
                comb_col_names = col_names[i]
            else:
                comb_col_names = comb_col_names + " & " + col_names[i]

        # Calculate the duplicates statistics - no groupby
        # (number and percentage of duplicates per column)
        if groupby_cols is None:

            dup_marks = dup_marks.drop("idx")
            abs_vals = int(dup_marks.groupBy().sum().toPandas().values[0][0])
            rel_vals = abs_vals / df.count()

            dict_dup["df_duplicates_statistics"] = pd.DataFrame(
                {
                    "Combination of columns": comb_col_names,
                    "Number of duplicates": abs_vals,
                    "Percentage of duplicates": rel_vals,
                },
                index=[0],
            )
        else:
            # Create df_duplicates_statistics
            df_col = df.select(groupby_cols)

            # Create an index
            df_col = spark_create_index_col(df_col, order="asc", index_name="idx1")

            # Mark duplicates per column
            dup_marks = (
                dup_marks.join(df_col, dup_marks.idx == df_col.idx1)
                .orderBy(f.asc("idx"))
                .drop("idx")
                .drop("idx1")
            )

            # Absolute duplicates statistics
            df_dup_stats = dup_marks.groupBy(groupby_cols).sum(*["mark"]).toPandas()
            df_dup_stats.set_index(groupby_cols, inplace=True)
            df_dup_stats.columns = [comb_col_names + "_absolute"]
            df_dup_stats = df_dup_stats.sort_index()
            df_dup_stats[comb_col_names + "_relative"] = (
                df_dup_stats[comb_col_names + "_absolute"] / df.count()
            )
            df_dup_stats[comb_col_names + "_relative"] = df_dup_stats[
                comb_col_names + "_relative"
            ].round(3)

            dict_dup["df_duplicates_statistics"] = df_dup_stats

        if mark_duplicates == "all":
            df_col = dup_marks.select(col("mark").alias(comb_col_names))
            dict_dup["df_duplicate_marks"] = df_col

        if mark_duplicates == "last":
            # Select columns
            df_col = df.select(col_names)

            # Create an index
            df_col = spark_create_index_col(df_col, order="asc", index_name="idx")

            # Mark duplicates per row
            dup_marks = df_col.join(
                df_col.groupBy(col_names).agg(
                    (f.count("*") > 1).cast("int").alias("mark")
                ),
                on=col_names,
                how="inner",
            ).orderBy(f.asc("idx"))

            # De-mark first duplicates
            dup_marks = counter(dup_marks, col_names, "idx")
            dup_marks = dup_marks.withColumn(
                "last_marks",
                when((dup_marks["mark"] == 1) & (dup_marks["counter"] == 1), 0)
                .when(dup_marks["counter"] > 1, 1)
                .otherwise(0),
            )

            dup_marks = dup_marks.orderBy(f.asc("idx"))

            dict_dup["df_duplicate_marks"] = dup_marks.select(
                col("last_marks").alias(comb_col_names)
            )

        if mark_duplicates == "first":
            # Select columns
            df_col = df.select(col_names)

            # Create an ascending index
            df_col = spark_create_index_col(df_col, order="asc", index_name="idx")
            # Create a descending index
            df_col = spark_create_index_col(df_col, order="desc", index_name="idx_desc")

            # Mark duplicates per row
            dup_marks = df_col.join(
                df_col.groupBy(col_names).agg(
                    (f.count("*") > 1).cast("int").alias("mark")
                ),
                on=col_names,
                how="inner",
            ).orderBy(f.asc("idx_desc"))

            # De-mark first duplicates
            dup_marks = counter(dup_marks, col_names, "idx_desc")
            dup_marks = dup_marks.withColumn(
                "last_marks",
                when((dup_marks["mark"] == 1) & (dup_marks["counter"] == 1), 0)
                .when(dup_marks["counter"] > 1, 1)
                .otherwise(0),
            )

            dup_marks = dup_marks.orderBy(f.asc("idx"))

            dict_dup["df_duplicate_marks"] = dup_marks.select(
                col("last_marks").alias(comb_col_names)
            )

    return dict_dup
