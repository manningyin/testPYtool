"""
############
Introduction
############
This submodule contains functions for plotting and exporting graphs of test results. This submodule is built from `matplotlib.pyplot` API components.

Nordea colours are applied as default, and further formatting is available in each function.
    
Visualization tools
===================
This section gives an overview of the plotting functions available. 

* **line_plot**: Plot data as a solid, dashed or dotted line, single or multiple series, with the ability to create subplots. Additional options can be seen in the implementation section.

* **scatter_plot**: Plot data as scattered points, single or multiple series, with the ability to create subplots. Additional options can be seen in the implementation section.

* **bar_plot**: Plot data as solid bars, single or stacked, with the ability to create subplots. Additional options can be seen in the implementation section.

* **histogram**: Plot data as histograms; multiple per plot or spread across multiple subplots.

* **boxplot**: Plot data as boxplots; multiple per plot or spread across multiple subplots, with or without an x-axis.

Warning
=======
The functions herein assume the data has been correctly processed up to this point. See other modules if data processing is needed. This implies that data has been extracted and contain the required variables. Variables required for the test should be stated in the function header.

Notes
=====
Author: N440730, G01679

##############
Implementation
##############
"""


from typing import List, Union
import matplotlib
import numpy as np
import pandas as pd
from typing_extensions import Literal
from crv.utils.visual_helper import (
    build_plotting_dict,
    get_subplot_dims,
    setup_figure_axes,
    nordea_axis_formatter,
    setup_legend,
    axis_cleanup,
    get_xy_tick_format,
    get_nordea_colour,
)
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from warnings import warn
import seaborn as sns

__all__ = ["line_plot", "scatter_plot", "bar_plot", "histogram", "boxplot"]


def line_plot(
    data: pd.DataFrame,
    x_col: str,
    y_cols: str,
    split_col: str = None,
    subplot_by: str = None,
    subplot_layout: Literal["square", "tall", "wide"] = "square",
    y_scale: Literal["linear", "log", "symlog", "logit"] = "linear",
    figsize: tuple = (12, 8),
    gridlines_on: str = None,
    share_x: bool = False,
    share_y: bool = False,
    share_ylim: bool = False,
    plot_title: str = "",
    legend_title: str = "",
    text_scale: float = 1.0,
    line_scale: float = 1.0,
    x_format: Union[str, list, int] = "default",
    y_format: Union[str, list, int] = "default",
    return_axes: bool = False,
    force_axis_zero: str = None,
    x_tick_rotation: float = 0,
    y_tick_rotation: float = 0,
    hide_axis_labels: str = None,
    share_axis_labels: str = None,
    output_path: str = None,
) -> Union[matplotlib.pyplot.figure, matplotlib.pyplot.axes]:
    """
    Convenience function for creating matplotlib  line plot with
    Nordea formatting.

    Args:
        data (pandas.DataFrame): Data ready for plotting.

        x_col (string): Column name for x-axis variable.

        y_cols (string or list): Column name(s) for y_axis, variables.

        split_col (string): Column name for grouping data series.

        subplot_by (stirng): How the figure will be split into
         subplots. Accepted values are 'split_col', 'y_cols'. Argument is
         ignored if 'split_col' is None.

        subplot_layout (string): How the subplots will be arranged in
         the figure. Accepted values are 'square', 'tall', 'wide'.
         Argument is ignored if 'split_col' is None.

        y_scale  (string): Plots the y-axis on a specified scale.
         Default is 'linear', options are 'log', 'symlog', 'logit'.

        figsize (tuple): Figure size in inches, (width, height).

        gridlines_on (string): Shows gridlines of the axis specified
         in the string. Default is None (no gridlines), options are 'x',
         'y', 'both'.

        share_x (bool): pyplot.figure option to share x-axis.

        share_y (bool): pyplot.figure option to share y-axis.

        share_ylim (bool): Scales all y-axes ranges to be the same.

        plot_title (string): Title for whole figure.

        legend_title (string): The for the figure legend.

        text_scale (float): Scaling factor for all text in the figure.

        line_scale (float): Scaling factor for the lines in the figure.

        x_format (string, int, list): How to format the values on the
         x-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        y_format (string, int, list): How to format the values on the
         y-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        return_axes (bool): Returns the figure and axes handles for
         further modification. Default is 'False'. If 'True', plt.show()
         must be called after this function to show the figure.

        force_axis_zero (string): Forces the minimum of the specifed
         axis to be exactly zero. Default is None (no forcing), options
         are 'x', 'y', 'both'.

        x_tick_rotation (float): Rotation to apply to the tick labels
         of the x-axis.

        y_tick_rotation (float): Rotation to apply to the tick labels
         of the y-axis.

        hide_axis_labels (string): Hides the axis x- and/or y-axis
         label, or both. Accepted strings are 'x', 'y', or 'both'. Default
         (None) does not hide any axis labels.

        share_axis_labels (string): Creates a common axis label for
         the whole figure, instead of for each subplot. Valid
         argument options are 'x', 'y', or 'both'. Default (None)
         does not create common axis labels for any axis.

        output_path (string): Filepath and filename (with extension)
         to save the figure.

    Return:
        (matplotlib.pyplot.figure, matplotlib.pyplot.axes):  Optional,
         if 'return_axes' is True, the figure and axes handles are
         returned.

    Raises:
        None, errors are handled in a subfunction.

    Examples:
        Call function from Python like this::

            line_plot(df_ADF, x_col='rating', y_cols=['PD, 'ADF'],
            split_col='country', subplot_by='split_col',
            subplot_layout='square', y_scale='linear',
            figsize=(12, 8), gridlines_on=None,
            sharex=False, sharey=False, share_ylim=False,
            plot_title='', legend_title='',
            text_scale=1.0, line_scale=1.0,
            x_format='default', y_format='default', return_axes=False,
            force_axis_zero=None,
            output_path="C:\\some_folder\\adf_vs_rating.png")

    Warnings:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>

    """
    # Setting general plotting options
    plot_dim = min(figsize)
    plot_linewidth = line_scale * plot_dim / 4
    alpha = 0.8

    # convert a string to a list for uniform processing
    if isinstance(y_cols, str):
        y_cols = [y_cols]

    # warn if common y-label could be misleading
    if (
        (len(y_cols) > 1)
        and (subplot_by == "y_cols")
        and (share_axis_labels in ["y", "both"])
    ):
        warn(
            "Subplots have potentially different y-axis values. A "
            "common y-axis label may be misleading. Check data accordingly.",
            UserWarning,
        )

    # Collect plotting data in a nested dictionary.
    plotting_dict = build_plotting_dict(
        data=data,
        x_col=x_col,
        y_cols=y_cols,
        split_col=split_col,
        subplot_by=subplot_by,
    )
    num_plots = len(plotting_dict)

    num_rows, num_columns = get_subplot_dims(
        num_plots=num_plots, subplot_layout=subplot_layout
    )

    fig, axs = setup_figure_axes(
        num_rows=num_rows,
        num_columns=num_columns,
        figsize=figsize,
        text_scale=text_scale,
        sharex=share_x,
        sharey=share_y,
        plot_title=plot_title,
    )

    x_format, y_format = get_xy_tick_format(
        x_format=x_format, y_format=y_format, num_plots=len(plotting_dict)
    )

    # start index counter to get last axis plotted
    last_axi = 0
    # dictionary for consolidating a common legend
    legend_dict = {}

    # plotting via the plotting_dict
    for i, series in plotting_dict.items():
        last_axi = i
        for xdata, ydata, label, colour, lstyle in series[2]:
            line_j = axs[i].plot(
                xdata.to_numpy(),
                ydata.to_numpy(),
                alpha=alpha,
                label=label,
                color=colour,
                linestyle=lstyle,
                linewidth=plot_linewidth,
                zorder=2,
            )
            if label not in legend_dict.keys():
                legend_dict[label] = line_j[0]

        # grab the x and labels for setting them if common
        common_x_label, common_y_label = "", ""
        if share_axis_labels in ["x", "y", "both"]:
            if (
                isinstance(hide_axis_labels, str)
                and hide_axis_labels != share_axis_labels
            ):
                hide_axis_labels = "both"
            else:
                hide_axis_labels = share_axis_labels
            if share_axis_labels in ["x", "both"]:
                common_x_label = x_col
            if share_axis_labels in ["y", "both"]:
                common_y_label = series[1]

        nordea_axis_formatter(
            axs[i],
            figsize=figsize,
            axis_title=None if num_plots == 1 else series[0],
            x_label=x_col,
            y_label=series[1],
            x_format=x_format[i],
            y_format=y_format[i],
            y_scale=y_scale,
            force_axis_zero=force_axis_zero,
            gridlines_on=gridlines_on,
            text_scale=text_scale,
            x_tick_rotation=x_tick_rotation,
            y_tick_rotation=y_tick_rotation,
            hide_axis_labels=hide_axis_labels,
        )

    # common legend setup and format
    legend = setup_legend(
        fig=fig,
        legend_dict=legend_dict,
        figsize=figsize,
        text_scale=text_scale,
        legend_title=legend_title,
    )

    axis_cleanup(
        fig=fig,
        axs=axs,
        share_ylim=share_ylim,
        sharex=share_x,
        last_axis_index=last_axi,
        num_columns=num_columns,
        text_scale=text_scale,
        common_x_label=common_x_label,
        common_y_label=common_y_label,
    )

    plt.tight_layout(pad=5)

    # figure output
    if not isinstance(output_path, type(None)) and not return_axes:
        plt.savefig(output_path, dpi=300)

    if return_axes:
        return fig, axs, legend
    else:
        plt.show()
        return None


def scatter_plot(
    data: pd.DataFrame,
    x_col: str,
    y_cols: str,
    split_col: str = None,
    subplot_by: str = None,
    subplot_layout: Literal["square", "tall", "wide"] = "square",
    y_scale: Literal["linear", "log", "symlog", "logit"] = "linear",
    figsize: tuple = (12, 8),
    gridlines_on: str = None,
    share_x: bool = False,
    share_y: bool = False,
    share_ylim: bool = False,
    plot_title: str = "",
    legend_title: str = "",
    text_scale: float = 1.0,
    line_scale: float = 1.0,
    alpha: float = 0.8,
    x_format: str = "default",
    y_format: str = "default",
    return_axes: bool = False,
    force_axis_zero: str = None,
    point_scale: float = 1.0,
    x_tick_rotation: float = 0,
    y_tick_rotation: float = 0,
    hide_axis_labels: float = None,
    share_axis_labels: str = None,
    output_path: str = None,
) -> Union[matplotlib.pyplot.figure, matplotlib.pyplot.axes]:
    """
    Convenience function for creating matplotlib scatter plot with
    Nordea formatting.

    Args:
        data (pandas.DataFrame): Data ready for plotting.

        x_col (string): Column name for x-axis variable.

        y_cols (string or list): Column name(s) for y_axis, variables.

        split_col (string): Column name for grouping data series.

        subplot_by (stirng): How the figure will be split into
         subplots. Accepted values are 'split_col', 'y_cols'. Argument is
         ignored if 'split_col' is None.

        subplot_layout (string): How the subplots will be arranged in
         the figure. Accepted values are 'square', 'tall', 'wide'.
         Argument is ignored if 'split_col' is None.

        y_scale (string): Plots the y-axis on a specified scale.
         Default is 'linear', options are 'log', 'symlog', 'logit'.

        figsize (tuple): Figure size in inches, (width, height).

        gridlines_on (string): Shows gridlines of the axis specified
         in the string. Default is None (no gridlines), options are 'x',
         'y', 'both'.

        share_x (bool): pyplot.figure option to share x-axis.

        share_y (bool): pyplot.figure option to share y-axis.

        share_ylim (bool): Scales all y-axes ranges to be the same.

        plot_title (string): Title for whole figure.

        legend_title (string): The for the figure legend.

        text_scale (float): Scaling factor for all text in the figure.

        line_scale (float): Scaling factor for the lines in the figure.

        x_format (string, int, list): How to format the values on the
         x-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        y_format (string, int, list): How to format the values on the
         y-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        return_axes (bool): Returns the figure and axes handles for
         further modification. Default is 'False'. If 'True', plt.show()
         must be called after this function to show the figure.

        force_axis_zero (string): Forces the minimum of the specifed
         axis to be exactly zero. Default is None (no forcing), options
         are 'x', 'y', 'both'.

        x_tick_rotation (float): Rotation to apply to the tick labels
         of the x-axis.

        y_tick_rotation (float): Rotation to apply to the tick labels
         of the y-axis.

        point_scale (float): Change the scale of the scatter points.

        hide_axis_labels (string): Hides the axis x- and/or y-axis
         label, or both. Accepted strings are 'x', 'y', or 'both'.
         Default (None) does not hide any axis labels.

        output_path (string): Filepath and filename (with extension)
         to save the figure.

    Return:
        (matplotlib.pyplot.figure, matplotlib.pyplot.axes): Optional,
         if 'return_axes' is True, the figure and axes handles are
         returned.

    Raises:
        None, errors are handled in a subfunction.

    Examples:
        Call function from Python like this::

            line_plot(df_ADF, x_col='rating', y_cols=['PD, 'ADF'],
            split_col='country', subplot_by='split_col',
            subplot_layout='square', y_scale='linear',
            figsize=(12, 8), gridlines_on=None,
            sharex=False, sharey=False, share_ylim=False,
            plot_title='', legend_title='',
            text_scale=1.0, line_scale=1.0,
            x_format='default', y_format='default', return_axes=False,
            force_axis_zero=None,
            output_path="C:\\some_folder\\adf_vs_rating.png")

    Warnings:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>

    """
    # Setting general plotting options
    plot_dim = min(figsize)
    plot_linewidth = line_scale * plot_dim / 20

    # convert a string to a list for uniform processing
    if isinstance(y_cols, str):
        y_cols = [y_cols]

    # warn if common y-label could be misleading
    if (
        (len(y_cols) > 1)
        and (subplot_by == "y_cols")
        and (share_axis_labels in ["y", "both"])
    ):
        warn(
            "Subplots have potentially different y-axis values. A "
            "common y-axis label may be misleading. Check data accordingly.",
            UserWarning,
        )

    # Collect plotting data in a nested dictionary.
    plotting_dict = build_plotting_dict(
        data=data,
        x_col=x_col,
        y_cols=y_cols,
        split_col=split_col,
        subplot_by=subplot_by,
        plot_type="scatter",
    )
    num_plots = len(plotting_dict)

    num_rows, num_columns = get_subplot_dims(
        num_plots=num_plots, subplot_layout=subplot_layout
    )

    fig, axs = setup_figure_axes(
        num_rows=num_rows,
        num_columns=num_columns,
        figsize=figsize,
        text_scale=text_scale,
        sharex=share_x,
        sharey=share_y,
        plot_title=plot_title,
    )

    x_format, y_format = get_xy_tick_format(
        x_format=x_format, y_format=y_format, num_plots=len(plotting_dict)
    )

    # start index counter to get last axis plotted
    last_axi = 0
    # dictionary for consolidating a common legend
    legend_dict = {}

    # plotting via the plotting_dict
    for i, series in plotting_dict.items():
        last_axi = i
        for xdata, ydata, label, colour, mstyle in series[2]:
            path_j = axs[i].scatter(
                xdata.to_numpy(),
                ydata.to_numpy(),
                alpha=alpha,
                label=label,
                c=colour,
                s=10 * plot_dim * point_scale,
                edgecolor="black",
                marker=mstyle,
                linewidth=plot_linewidth,
                clip_on=False,
                zorder=2,
            )
            if label not in legend_dict.keys():
                legend_dict[label] = path_j

        # grab the x and labels for setting them if common
        common_x_label, common_y_label = "", ""
        if share_axis_labels in ["x", "y", "both"]:
            if (
                isinstance(hide_axis_labels, str)
                and hide_axis_labels != share_axis_labels
            ):
                hide_axis_labels = "both"
            else:
                hide_axis_labels = share_axis_labels
            if share_axis_labels in ["x", "both"]:
                common_x_label = x_col
            if share_axis_labels in ["y", "both"]:
                common_y_label = series[1]

        nordea_axis_formatter(
            axs[i],
            figsize=figsize,
            axis_title=None if num_plots == 1 else series[0],
            x_label=x_col,
            y_label=series[1],
            x_format=x_format[i],
            y_format=y_format[i],
            y_scale=y_scale,
            force_axis_zero=force_axis_zero,
            gridlines_on=gridlines_on,
            text_scale=text_scale,
            x_tick_rotation=x_tick_rotation,
            y_tick_rotation=y_tick_rotation,
            hide_axis_labels=hide_axis_labels,
        )

    # common legend setup and format
    legend = setup_legend(
        fig=fig,
        legend_dict=legend_dict,
        figsize=figsize,
        text_scale=text_scale,
        legend_title=legend_title,
    )

    axis_cleanup(
        fig=fig,
        axs=axs,
        share_ylim=share_ylim,
        sharex=share_x,
        last_axis_index=last_axi,
        num_columns=num_columns,
        text_scale=text_scale,
        common_x_label=common_x_label,
        common_y_label=common_y_label,
    )

    plt.tight_layout(pad=5)

    # figure output
    if not isinstance(output_path, type(None)) and not return_axes:
        plt.savefig(output_path, dpi=300)

    if return_axes:
        return fig, axs, legend
    else:
        plt.show()
        return None


def bar_plot(
    data: pd.DataFrame,
    x_col: str,
    y_cols: Union[str, List[str]],
    split_col: str = None,
    subplot_by: Literal["split_col", "y_cols"] = None,
    subplot_layout: Literal["square", "tall", "wide"] = "square",
    y_scale: Literal["linear", "log", "symlog", "logit"] = "linear",
    figsize: tuple = (12, 8),
    gridlines_on: str = None,
    share_x: bool = False,
    share_y: bool = False,
    share_ylim: bool = False,
    plot_title: str = "",
    legend_title: str = "",
    text_scale: float = 1.0,
    alpha: float = 0.8,
    x_format: Union[str, list, int] = "default",
    y_format: Union[str, list, int] = "default",
    return_axes: bool = False,
    force_axis_zero: str = None,
    x_tick_rotation: float = 0,
    y_tick_rotation: float = 0,
    hide_axis_labels: str = None,
    share_axis_labels: str = None,
    output_path: str = None,
) -> Union[matplotlib.pyplot.figure, matplotlib.pyplot.axes]:
    """
    Convenience function for creating matplotlib bar plot with
    Nordea formatting. Note that bars from separate series within
    the same subplot will stack, however if there is more than
    one y-value per x-value per series the function will
    throw an error.

    Args:
        data (pandas.DataFrame): Data ready for plotting.

        x_col (string): Column name for x-axis variable.

        y_cols (string or list): Column name(s) for y_axis, variables.

        split_col (string): Column name for grouping data series.

        subplot_by (stirng): How the figure will be split into
         subplots. Accepted values are 'split_col', 'y_cols'. Argument is
         ignored if 'split_col' is None.

        subplot_layout (string): How the subplots will be arranged in
         the figure. Accepted values are 'square', 'tall', 'wide'.
         Argument is ignored if 'split_col' is None.

        y_scale (string): Plots the y-axis on a specified scale.
         Default is 'linear', options are 'log', 'symlog', 'logit'.

        figsize (tuple): Figure size in inches, (width, height).

        gridlines_on (string): Shows gridlines of the axis specified
         in the string. Default is None (no gridlines), options are 'x',
         'y', 'both'.

        share_x (bool): pyplot.figure option to share x-axis.

        share_y (bool): pyplot.figure option to share y-axis.

        share_ylim (bool): Scales all y-axes ranges to be the same.

        plot_title (string): Title for whole figure.

        legend_title (string): The for the figure legend.

        text_scale (float): Scaling factor for all text in the figure.

        line_scale (float): Scaling factor for the lines in the figure.

        x_format (string, int, list): How to format the values on the
         x-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        y_format (string, int, list): How to format the values on the
         y-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        return_axes (bool): Returns the figure and axes handles for
         further modification. Default is 'False'. If 'True', plt.show()
         must be called after this function to show the figure.

        force_axis_zero (string): Forces the minimum of the specifed
         axis to be exactly zero. Default is None (no forcing), options
         are 'x', 'y', 'both'.

        x_tick_rotation (float): Rotation to apply to the tick labels
        of the x-axis.

        y_tick_rotation (float): Rotation to apply to the tick labels
         of the y-axis.

        hide_axis_labels (string): Hides the axis x- and/or y-axis
         label, or both. Accepted strings are 'x', 'y', or 'both'.
         Default (None) does not hide any axis labels.

        output_path (string): Filepath and filename (with extension)
         to save the figure.

    Return:
        (matplotlib.pyplot.figure, matplotlib.pyplot.axes):  Optional,
         if 'return_axes' is True, the figure and axes handles are
         returned.

    Raises:
        None, errors are handled in a subfunction.

    Examples:
        Call function from Python like this::

            line_plot(df_ADF, x_col='rating', y_cols=['PD, 'ADF'],
            split_col='country', subplot_by='split_col',
            subplot_layout='square', y_scale='linear',
            figsize=(12, 8), gridlines_on=None,
            sharex=False, sharey=False, share_ylim=False,
            plot_title='', legend_title='',
            text_scale=1.0, line_scale=1.0,
            x_format='default', y_format='default', return_axes=False,
            force_axis_zero=None,
            output_path="C:\\some_folder\\adf_vs_rating.png")

    Warnings:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # Setting general plotting options
    plot_dim = min(figsize)

    # convert a string to a list for uniform processing
    if isinstance(y_cols, str):
        y_cols = [y_cols]

    # warn if common y-label could be misleading
    if (
        (len(y_cols) > 1)
        and (subplot_by == "y_cols")
        and (share_axis_labels in ["y", "both"])
    ):
        warn(
            "Subplots have potentially different y-axis values. A "
            "common y-axis label may be misleading. Check data accordingly.",
            UserWarning,
        )

    # Collect plotting data in a nested dictionary.
    plotting_dict = build_plotting_dict(
        data=data,
        x_col=x_col,
        y_cols=y_cols,
        split_col=split_col,
        subplot_by=subplot_by,
        plot_type="bar",
    )
    num_plots = len(plotting_dict)

    num_rows, num_columns = get_subplot_dims(
        num_plots=num_plots, subplot_layout=subplot_layout
    )

    fig, axs = setup_figure_axes(
        num_rows=num_rows,
        num_columns=num_columns,
        figsize=figsize,
        text_scale=text_scale,
        sharex=share_x,
        sharey=share_y,
        plot_title=plot_title,
    )

    x_format, y_format = get_xy_tick_format(
        x_format=x_format, y_format=y_format, num_plots=len(plotting_dict)
    )

    # start index counter to get last axis plotted
    last_axi = 0
    # dictionary for consolidating a common legend
    legend_dict = {}

    # plotting via the plotting_dict
    for i, series in plotting_dict.items():
        last_axi = i
        bottom = np.zeros(len(series[2][0][0]))
        for xdata, ydata, label, colour, mstyle in series[2]:
            if len(xdata.unique()) < len(xdata):
                raise ValueError(
                    "Values on the x-axis likely have "
                    "more than 1 associated y-value, which "
                    "will result in overlapping bars and "
                    "nonsensical plotting. Check your "
                    "data and try again."
                )
            path_j = axs[i].bar(
                xdata.to_numpy(),
                height=ydata.to_numpy(),
                bottom=bottom,
                alpha=alpha,
                label=label,
                color=colour,
                edgecolor="white",
                linewidth=0,
                hatch=mstyle,
                clip_on=False,
                zorder=2,
            )
            bottom = np.add(bottom, ydata.to_numpy())
            if label not in legend_dict.keys():
                legend_dict[label] = path_j

        # grab the x and labels for setting them if common
        common_x_label, common_y_label = "", ""
        if share_axis_labels in ["x", "y", "both"]:
            if (
                isinstance(hide_axis_labels, str)
                and hide_axis_labels != share_axis_labels
            ):
                hide_axis_labels = "both"
            else:
                hide_axis_labels = share_axis_labels
            if share_axis_labels in ["x", "both"]:
                common_x_label = x_col
            if share_axis_labels in ["y", "both"]:
                common_y_label = series[1]

        nordea_axis_formatter(
            axs[i],
            figsize=figsize,
            axis_title=None if num_plots == 1 else series[0],
            x_label=x_col,
            y_label=series[1],
            x_format=x_format[i],
            y_format=y_format[i],
            y_scale=y_scale,
            force_axis_zero=force_axis_zero,
            gridlines_on=gridlines_on,
            text_scale=text_scale,
            x_tick_rotation=x_tick_rotation,
            y_tick_rotation=y_tick_rotation,
            hide_axis_labels=hide_axis_labels,
        )

    # common legend setup and format
    legend = setup_legend(
        fig=fig,
        legend_dict=legend_dict,
        figsize=figsize,
        text_scale=text_scale,
        legend_title=legend_title,
    )

    axis_cleanup(
        fig=fig,
        axs=axs,
        share_ylim=share_ylim,
        sharex=share_x,
        last_axis_index=last_axi,
        num_columns=num_columns,
        text_scale=text_scale,
        common_x_label=common_x_label,
        common_y_label=common_y_label,
    )

    plt.tight_layout(pad=5)

    # figure output
    if not isinstance(output_path, type(None)) and not return_axes:
        plt.savefig(output_path, dpi=300)

    if return_axes:
        return fig, axs, legend
    else:
        plt.show()
        return None


def highlight_range(
    ax: str,
    x_ranges: Union[list, tuple] = None,
    y_ranges: Union[list, tuple] = None,
    colour: str = get_nordea_colour("Accent Yellow"),
    alpha: float = 0.5,
) -> None:
    """
    Highlights the x- or y-range in the given axis,
    using the specified colour. Can only highlight an x- or y-range,
    not both. x_range will override y_range.

    Args:
        ax  (matplotlib.axes object):  The axis to highlight.

        x_ranges  (list, tuple):  The x-range to highlight. Default
        is 'None' which will highlight the entire x-range. Multiple
        x-ranges can be passed as a list of tuples, (start, stop).

        y_ranges  (list, tuple):  The y-range to highlight. Default
        is 'None' which will highlight the entire y-range.  Multiple
        x-ranges can be passed as a list of tuples, (start, stop).
        If both x_range and y_range are provided y_range will
        be ignored.

        colour  (string):  A matplotlib-compatible colour.

    Return:
        None.

    Raises:
        None

    Examples:
        Call function in Python like this::

            highlight_range(ax=ax, x_range=(2, 10), colour='yellow')

    Warning:
        None

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    if isinstance(x_ranges, tuple):
        x_ranges = [x_ranges]
    if isinstance(y_ranges, tuple):
        y_ranges = [y_ranges]

    if isinstance(y_ranges, list) and isinstance(x_ranges, type(None)):
        haxis = "y"
        highlight_ranges = y_ranges
    elif isinstance(x_ranges, list):
        haxis = "x"
        highlight_ranges = x_ranges
    else:
        haxis = None
    if not isinstance(haxis, type(None)):
        for hr_i in highlight_ranges:
            if "datetime" in str(type(hr_i)):
                hr = [mdates.date2num(hr_i[0]), mdates.date2num(hr_i[1])]
            else:
                hr = hr_i
            if haxis == "x":
                ax.axvspan(xmin=hr[0], xmax=hr[1], color=colour, alpha=alpha, zorder=1)
            elif haxis == "y":
                ax.axhspan(ymin=hr[0], ymax=hr[1], color=colour, alpha=alpha, zorder=1)
    return None


def histogram(
    data: pd.DataFrame,
    y_cols: Union[str, list],
    split_col: str = None,
    subplot_layout: Literal["square", "tall", "wide"] = "square",
    subplot_by: Literal["y_cols", "split_col"] = None,
    bins: int = None,
    plot_kde: bool = False,
    plot_hist: bool = True,
    plot_vert: bool = True,
    alpha: float = 1.0,
    return_axes: bool = False,
    figsize: tuple = (12, 8),
    gridlines_on: str = None,
    share_x: bool = False,
    share_y: bool = False,
    share_ylim: bool = False,
    plot_title: str = "",
    legend_title: str = "",
    text_scale: float = 1.0,
    x_format: Union[str, list, tuple] = "default",
    y_format: Union[str, list, tuple] = "default",
    x_tick_rotation: float = 0,
    y_tick_rotation: float = 0,
    hide_axis_labels: str = None,
    share_axis_labels: str = None,
    output_path: str = None,
) -> Union[matplotlib.pyplot.figure, matplotlib.pyplot.axes]:
    """
    Plotting histogram with Nordea colours and options.

    Args:
        data (pandas.DataFrame): Data ready for plotting

        y_cols(string or list): Column name(s) for target variable(s).
         If a list is specified, each column name will receive its own series
         to be plotted on either the same plot or separate subplots, depending
         on the 'subplot_by'.

        split_col (string): (Default=None) Column name used for grouping of
         the target variable(s). The groupings will be shown within the same
         subplot or given their own subplots, as dictated by the
         'subplot_by' argument.

        subplot_layout (string): (Default='square') How the subplots will
         be arranged in the figure. Accepted values are 'square', 'tall',
         'wide'. Argument is ignored if 'y_cols' is a string.

        subplot_by  (stirng): (Default=None) How the figure will be split into
         subplots. Accepted values are 'split_col', 'y_cols'. Argument is
         ignored if 'split_col' is None. Behaviours are as follows:
            * | 'y_cols' - Each column specified in the argument 'y_cols' will
              | be plotted on a separate subplot, and each group within those
              |columns (specified by 'split_col') will be plotted as separate
              | histograms in each subplot.
            * | 'split_col' - All columns specified in 'y_cols' are plotted on
              | all subplots, with each specific group (as specified in the
              | 'split_col' column) being plotted on a separate subplot.

        bins (int): (Default=None) Specify the number of histogram bins. If
         None, the default seaborn rule is used to estimate the number
         of bins required.

        plot_kde (bool): (Default=False) Whether to plot a gaussian kernel
         density estimate. If True implies the KDE function is plotted on
         y-axis, with density values written on y-axis.

        plot_hist (bool): (Default=True) Plot histogram bars.

        plot_vert (bool): (Default=True) Makes histogram boxes plot vertical,
         from bottom to top. If False, histogram bars are plotting
         extending horizontally, left to right. Axis labels and formatting
         will be switched accordingly is False (e.g. x-axis formatting will
         be applied to the vertical axis if False).

        alpha (float): (Default=1.0) Opacity value for all bars in the
         figure. KDE lines will always have an alpha of 1.0.

        return_axes (bool): (Default=False) Returns the figure, axes, and legend
         handles for further modification. If 'True', plt.show() must be called
         after this function to show the figure.

        figsize (tuple): (Default=(12,8)) Figure size in inches, (width, height).

        gridlines_on (string): (Default=None) Shows gridlines of
         the axis specified in the string. Default is None (no gridlines),
         options are 'x', 'y', 'both'.

        share_x (bool): (Default=False) pyplot.figure option to share x-axis.

        share_y (bool): (Default=False) pyplot.figure option to share y-axis.

        share_ylim (bool): (Default=False) Scales all y-axes ranges to be the same.

        plot_title (string): (Default='') Title for whole figure.

        legend_title (string): (Default='') The title for the figure legend.

        text_scale (float): (Default=1.0) Scaling factor for all text in the figure.

        x_format (string, int, list): (Default='default') How to format the
         values on the x-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        y_format (string, int, list): (Default='default') How to format the
         values on the y-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        x_tick_rotation (float): (Default=0) Rotation to apply to the
         tick labels of the x-axis.

        y_tick_rotation (float): (Default=0) Rotation to apply to the
         tick labels of the y-axis.

        hide_axis_labels (string): (Default=None) Hides the axis
         x- and/or y-axis label, or both. Accepted strings
         are 'x', 'y', or 'both'. Default (None) does not hide any axis labels.

        share_axis_labels (string): (Default=None) Creates a common axis
         label for the whole figure, instead of for each subplot. Valid
         argument options are 'x', 'y', or 'both'. Default (None)
         does not create common axis labels for any axis.

        output_path (string): (Default=None) Filepath and filename (with extension)
         to save the figure. Default (None) does not save the figure.

    Returns:
        (matplotlib.pyplot.figure, matplotlib.pyplot.axes):  Optional,
         if 'return_axes' is True, the figure, axes handles, and legend are
         returned.

    Raises:
        Warning - If multiple columns are plotting, a warning informs the user that
         the units may not match if plotted on the same subplots. This is something
         that the user must control in the data.

    Examples:
        Call in Python notebook like this::

            >>> histogram(df, y_cols=['LGD', 'lgd_estimate'], split_col='countryofbooking',
            subplot_by='split_col', figsize=(10,8), plot_kde=True, plot_hist=False,
            gridlines_on='both', share_x=True, share_y=True, plot_vert=True, x_tick_rotation=45)

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # Setting general plotting options.
    y_col_label = "Density" if plot_kde else "Frequency"

    # Convert a string to a list for uniform processing.
    y_cols = [y_cols] if isinstance(y_cols, str) else y_cols

    # Warn if common y-label could be misleading.
    if (
        (len(y_cols) > 1)
        and (subplot_by == "y_cols")
        and (share_axis_labels in ["y", "both"])
    ):
        warn(
            "Subplots have potentially different y-axis values. A "
            "common y-axis label may be misleading. Check data accordingly.",
            UserWarning,
        )

    # Collect plotting data in a nested dictionary.
    plotting_dict = build_plotting_dict(
        data=data,
        x_col=y_cols[0],
        y_cols=y_cols,
        split_col=split_col,
        subplot_by=subplot_by,
    )
    num_plots = len(plotting_dict)

    num_rows, num_columns = get_subplot_dims(
        num_plots=num_plots, subplot_layout=subplot_layout
    )

    fig, axs = setup_figure_axes(
        num_rows=num_rows,
        num_columns=num_columns,
        figsize=figsize,
        text_scale=text_scale,
        sharex=share_x,
        sharey=share_y,
        plot_title=plot_title,
    )

    x_format, y_format = get_xy_tick_format(
        x_format=x_format, y_format=y_format, num_plots=len(plotting_dict)
    )

    # start index counter to get last axis plotted
    last_axi = 0
    # dictionary for consolidating a common legend
    legend_dict = {}

    # plotting via the plotting_dict
    for i, series in plotting_dict.items():
        last_axi = i
        for _, ydata, label, colour, _ in series[2]:
            line_j = sns.distplot(
                ydata.to_numpy(),
                bins=bins,
                kde=plot_kde,
                hist=plot_hist,
                ax=axs[i],
                label=label,
                color=colour,
                vertical=not plot_vert,
                hist_kws=dict(alpha=alpha),
            )
            if plot_kde and not plot_hist and split_col is not None:
                axs[i].get_legend().set_visible(False)
            if label not in legend_dict.keys():
                if plot_hist:
                    legend_dict[label] = mpatches.Patch(color=colour, label=label)
                else:
                    legend_dict[label] = mlines.Line2D(
                        [], [], color=colour, label=label
                    )

        # grab the x and labels for setting them if common
        common_x_label, common_y_label = "", ""
        if share_axis_labels in ["x", "y", "both"]:
            if (
                isinstance(hide_axis_labels, str)
                and hide_axis_labels != share_axis_labels
            ):
                hide_axis_labels = "both"
            else:
                hide_axis_labels = share_axis_labels
            if share_axis_labels in ["x", "both"]:
                common_x_label = series[1]
            if share_axis_labels in ["y", "both"]:
                common_y_label = y_col_label

        nordea_axis_formatter(
            axs[i],
            figsize=figsize,
            axis_title=None if num_plots == 1 else series[0],
            x_label=series[1] if plot_vert else y_col_label,
            y_label=y_col_label if plot_vert else series[1],
            x_format=x_format[i] if plot_vert else y_format[i],
            y_format=y_format[i] if plot_vert else x_format[i],
            gridlines_on=gridlines_on,
            text_scale=text_scale,
            x_tick_rotation=x_tick_rotation if plot_vert else y_tick_rotation,
            y_tick_rotation=y_tick_rotation if plot_vert else x_tick_rotation,
            hide_axis_labels=hide_axis_labels,
        )

    # common legend setup and format
    legend = setup_legend(
        fig=fig,
        legend_dict=legend_dict,
        figsize=figsize,
        text_scale=text_scale,
        legend_title=legend_title,
    )

    axis_cleanup(
        fig=fig,
        axs=axs,
        share_ylim=share_ylim,
        sharex=share_x,
        last_axis_index=last_axi,
        num_columns=num_columns,
        text_scale=text_scale,
        common_x_label=common_x_label,
        common_y_label=common_y_label,
    )

    plt.tight_layout(pad=5)

    # figure output
    if not isinstance(output_path, type(None)) and not return_axes:
        plt.savefig(output_path, dpi=300)

    if return_axes:
        return fig, axs, legend
    else:
        plt.show()
        return None


def boxplot(
    data: pd.DataFrame,
    y_cols: Union[str, list],
    x_col: str = None,
    split_col: str = None,
    subplot_by: Literal["y_cols", "split_col"] = None,
    order_split: list = None,
    show_obs: bool = False,
    subplot_layout: Literal["square", "tall", "wide"] = "square",
    y_scale: Literal["linear", "log", "symlog", "logit"] = "linear",
    figsize: tuple = (12, 8),
    gridlines_on: str = None,
    share_x: bool = False,
    share_y: bool = False,
    share_ylim: bool = False,
    plot_title: str = "",
    legend_title: str = "",
    text_scale: float = 1.0,
    x_format: Union[str, list, int] = "default",
    y_format: Union[str, list, int] = "default",
    return_axes: bool = False,
    force_axis_zero: str = None,
    x_tick_rotation: float = 0,
    y_tick_rotation: float = 0,
    hide_axis_labels: str = None,
    share_axis_labels: str = None,
    output_path: str = None,
) -> Union[matplotlib.pyplot.figure, matplotlib.pyplot.axes]:
    """
    Convenience function for creating a seaborn boxplot with
    Nordea formatting.

    Args:
        data (pandas.DataFrame): Data ready for plotting.

        y_cols  (string or list): Column name(s) for y_axis, variables.
         Boxes or subplots will be plotted in the order in which they
         are specified in this list.

        x_col (string):  (Default=None) Column name for x-axis variable. If None,
         There is no x-axis label or tick values, since all data in
         the table is plotted in a singleb box.

        split_col (string): Column name for grouping data series.

        subplot_by (stirng): How the figure will be split into
         subplots. Accepted values are 'split_col', 'y_cols'. Argument is
         ignored if 'split_col' is None. Behaviours are as follows:
            * | 'y_cols' - Each column specified in the argument 'y_cols' will
              | be plotted on a separate subplot, and each group within those
              | columns (specified by 'split_col') will be plotted as separate
              | histograms in each subplot.
            * | 'split_col' - All columns specified in 'y_cols' are plotted on
              | all subplots, with each specific group (as specified in the
              | 'split_col' column) being plotted on a separate subplot.

        order_split (list): (Default=None) An ordered list of the unique
         values found in the column name passed to the 'split_col'
         argument. The order of this list determines the order in which
         the boxes or subplots will be plotted in the figure.

        show_obs (bool): (Default=False) If True, the number of observations
         for each x-axis value is shown below the tick label.

        subplot_layout (string):  How the subplots will be arranged in
         the figure. Accepted values are 'square', 'tall', 'wide'.
         Argument is ignored if 'split_col' is None.

        y_scale (string): Plots the y-axis on a specified scale.
         Default is 'linear', options are 'log', 'symlog', 'logit'.

        figsize (tuple): Figure size in inches, (width, height).

        gridlines_on (string): Shows gridlines of the axis specified
         in the string. Default is None (no gridlines), options are 'x',
         'y', 'both'.

        share_x (bool): pyplot.figure option to share x-axis.

        share_y (bool): pyplot.figure option to share y-axis.

        share_ylim (bool): Scales all y-axes ranges to be the same.

        plot_title (string): Title for whole figure.

        legend_title (string): The for the figure legend.

        text_scale (float): Scaling factor for all text in the figure.

        x_format (string, int, list): How to format the values on the
         x-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        y_format (string, int, list): How to format the values on the
         y-axis ticks. Default is 'default', which applies default
         matplotlib formatting. Options are 'percent' (for % formatting),
         'thousand' (for using a thousands separator), or provide an
         integer to specify the number of decimal places. Provide a list
         to set different formatting for each axis.

        return_axes (bool): Returns the figure and axes handles for
         further modification. Default is 'False'. If 'True', plt.show()
         must be called after this function to show the figure.

        force_axis_zero (string): Forces the minimum of the specifed
         axis to be exactly zero. Default is None (no forcing), options
         are 'x', 'y', 'both'.

        x_tick_rotation (float): Rotation to apply to the tick labels
         of the x-axis.

        y_tick_rotation (float): Rotation to apply to the tick labels
         of the y-axis.

        hide_axis_labels (string): Hides the axis x- and/or y-axis
         label, or both. Accepted strings are 'x', 'y', or 'both'. Default
         (None) does not hide any axis labels.

        share_axis_labels (string): Creates a common axis label for
         the whole figure, instead of for each subplot. Valid
         argument options are 'x', 'y', or 'both'. Default (None)
         does not create common axis labels for any axis.

        output_path (string): Filepath and filename (with extension)
         to save the figure.

    Return:
        (matplotlib.pyplot.figure, matplotlib.pyplot.axes): Optional,
         if 'return_axes' is True, the figure and axes handles are
         returned.

    Raises:
        None, errors are handled in a subfunction.

    Examples:
        Call function from Python like this::

            >>> boxplot(df_lgd, x_col='countryofbooking', y_cols=['lgd_estimate'],
            split_col='year', subplot_by='y_cols', subplot_layout='wide',
            order_split=['2010', '2011', '2012'], figsize=(18,8), show_obs=True,
            output_path="C:\\some_folder\\lgd_boxplot.png")

    Warnings:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # convert a string to a list for uniform processing
    if isinstance(y_cols, str):
        y_cols = [y_cols]

    # warn if common y-label could be misleading
    if (
        (len(y_cols) > 1)
        and (subplot_by == "y_cols")
        and (share_axis_labels in ["y", "both"])
    ):
        warn(
            "Subplots have potentially different y-axis values. A "
            "common y-axis label may be misleading. Check data accordingly.",
            UserWarning,
        )

    plot_data = data.copy()
    if x_col is None:
        x_col = " "
        plot_data[x_col] = " "

    # Collect plotting data in a nested dictionary.
    plotting_dict = build_plotting_dict(
        data=plot_data,
        x_col=x_col,
        y_cols=y_cols,
        split_col=split_col,
        subplot_by=subplot_by,
        plot_type="boxplot",
        order_split=order_split,
    )
    num_plots = len(plotting_dict)

    num_rows, num_columns = get_subplot_dims(
        num_plots=num_plots, subplot_layout=subplot_layout
    )

    fig, axs = setup_figure_axes(
        num_rows=num_rows,
        num_columns=num_columns,
        figsize=figsize,
        text_scale=text_scale,
        sharex=share_x,
        sharey=share_y,
        plot_title=plot_title,
    )

    x_format, y_format = get_xy_tick_format(
        x_format=x_format, y_format=y_format, num_plots=len(plotting_dict)
    )

    # start index counter to get last axis plotted
    last_axi = 0
    # dictionary for consolidating a common legend
    legend_dict = {}

    # plotting via the plotting_dict
    for i, series in plotting_dict.items():
        last_axi = i
        # Need to reform plotting ´_dict into DataFrames for seaborn.
        df_i_list = []
        for xdata, ydata, label, colour, hstyle in series[2]:
            df_i = pd.DataFrame(
                [xdata.to_numpy(), ydata.to_numpy()], index=[x_col, "ycol"]
            ).transpose()
            df_i["split_col"] = label
            df_i_list.append(df_i)

        df_sns_plot = pd.concat(df_i_list, sort=False)

        obs_counts = df_sns_plot.groupby([x_col])["ycol"].count()

        boxplot_j = sns.boxplot(
            data=df_sns_plot,
            x=x_col,
            y="ycol",
            hue="split_col",
            # hue_order=order_split,
            ax=axs[i],
            palette=sns.color_palette([s[3] for s in series[2]]),
        )

        if show_obs:
            y_lims = axs[i].get_ylim()
            y_pos_for_obs = y_lims[0] - (y_lims[1] - y_lims[0]) / 15

            for xtick in axs[i].get_xticks():
                axs[i].text(
                    xtick,
                    y_pos_for_obs,
                    f"(N = {obs_counts.iloc[xtick]})",
                    horizontalalignment="center",
                    size=int(text_scale * 8),
                    color="black",
                    weight="semibold",
                )

        axs[i].get_legend().set_visible(False)

        for xdata, ydata, label, colour, hstyle in series[2]:
            if label not in legend_dict.keys():
                legend_dict[label] = mpatches.Patch(color=colour, label=label)

        # grab the x and labels for setting them if common
        common_x_label, common_y_label = "", ""
        if share_axis_labels in ["x", "y", "both"]:
            if (
                isinstance(hide_axis_labels, str)
                and hide_axis_labels != share_axis_labels
            ):
                hide_axis_labels = "both"
            else:
                hide_axis_labels = share_axis_labels
            if share_axis_labels in ["x", "both"]:
                common_x_label = x_col
            if share_axis_labels in ["y", "both"]:
                common_y_label = series[1]

        nordea_axis_formatter(
            axs[i],
            figsize=figsize,
            axis_title=None if num_plots == 1 else series[0],
            x_label=x_col,
            y_label=series[1],
            x_format=x_format[i],
            y_format=y_format[i],
            y_scale=y_scale,
            force_axis_zero=force_axis_zero,
            gridlines_on=gridlines_on,
            text_scale=text_scale,
            x_tick_rotation=x_tick_rotation,
            y_tick_rotation=y_tick_rotation,
            hide_axis_labels=hide_axis_labels,
        )

    # common legend setup and format
    legend = setup_legend(
        fig=fig,
        legend_dict=legend_dict,
        figsize=figsize,
        text_scale=text_scale,
        legend_title=legend_title,
    )

    axis_cleanup(
        fig=fig,
        axs=axs,
        share_ylim=share_ylim,
        sharex=share_x,
        last_axis_index=last_axi,
        num_columns=num_columns,
        text_scale=text_scale,
        common_x_label=common_x_label,
        common_y_label=common_y_label,
    )

    plt.tight_layout(pad=5)

    # figure output
    if not isinstance(output_path, type(None)) and not return_axes:
        plt.savefig(output_path, dpi=300)

    if return_axes:
        return fig, axs, legend
    else:
        plt.show()
        return None
