"""
############
Introduction
############
This submodule contains functions for exporting data to Microsoft Excel tables.

* **df2excel**: Sends a ``pandas.DataFrame`` to a spreadsheet in an Excel ``.xlsx`` file. The table will be formatted with Nordea fonts and colors, and can be modified by the numerous optional arguments. 

Notes
=====
Author: G85538

##############
Implementation
##############
"""

import openpyxl as pyxl
from openpyxl.styles import PatternFill, Alignment, Font, Border, Side
from openpyxl.formatting.rule import ColorScaleRule, IconSet, FormatObject, IconSetRule
from numbers import Number
import warnings
from crv.utils import visual_helper

__all__ = ["df2excel"]

# importing colours
_NORDEA_BLUE = visual_helper.get_nordea_colour("Nordea Blue").replace("#", "")
_LIGHT_BG = visual_helper.get_nordea_colour("Light Background").replace("#", "")
_WHITE = "ffffff"
_BLACK = "000000"
_ACCENT_RED = visual_helper.get_nordea_colour("Accent Red").replace("#", "")
_ACCENT_GREEN = visual_helper.get_nordea_colour("Accent Green").replace("#", "")


def df2rows(df, index=False, header=True):
    """
    Helper function to convert a data frame to an iterator that returns
    each row (including header if desired) as lists.
    """
    if index:
        if header:
            yield [df.index.name] + df.columns.tolist()
        for i, row in df.iterrows():
            yield [i] + row.tolist()
    else:
        if header:
            yield df.columns.tolist()
        for index, row in df.iterrows():
            yield row.tolist()


def df2excel(
    df,
    workbook: str,
    sheet: str = "Table",
    header: bool = True,
    index: bool = False,
    header_formats: dict = {},
    index_formats: dict = {},
    data_formats: dict = {},
    column_formats: dict = {},
    column_conditional_formats: list = [],
    traffic_light_formats: dict = {'apply_traffic': False, 
                             'traffic_cols': [],
                             'traffic_lights':{'upperbound': 0.5,'lowerbound': 0.5}, 
                             'reverse_icons':False}, 
    header_height: float = None,  # Wrapping sets header height if not specified
    max_index_width: int = 15,
    row_height: int = 15,
    max_col_width: int = 10,
    specific_row_height: dict = {},
    specific_col_width: dict = {},
) -> None:
    """
    Function for exporting data from a pandas.DataFrame to
    Microsoft Excel spreadsheet.

    Args:
        df (pandas.DataFrame): The DataFrame to export

        workbook (string): The file path for the exported file, including the
         filename and '.xlsx' extension.

        sheet (string):´The sheet name in the workbook to which to
         write the table. Specifying the same 'workbook' and with different
         'sheet' names will write to the same workbook but put tables in
         different tabs.

        header (bool): If True, puts the DataFrame's column names as the
         first row. Defualt is True.

        index (bool): If True, writes the DataFrame index as the left-most
         column in the spreadsheet. Default is False.

        header_formats (dict):
            Dictionary with header format options. Default options are::

                {'font_name': 'Calibri',
                 'font_color': white,
                 'font_size': 12,
                 'bold': True,
                 'italic': False,
                 'fg_color': nordea_blue,
                 'bg_color': white,
                 'fill_type': 'solid',
                 'horizontal': 'center',
                 'vertical': 'center',
                 'wrap_text': True,
                 'border': {'left': 'none',
                            'right': 'none',
                            'top': 'none',
                            'bottom': 'none'},
                 'border_color': white
                }

        index_formats (dict):
            Dictionary with index format options. Default options are::

                {'font_name': 'Calibri',
                 'font_color': white,
                 'font_size': 12,
                 'bold': True,
                 'italic': False,
                 'fg_color': nordea_blue,
                 'bg_color': white,
                 'fill_type': 'solid',
                 'horizontal': 'right',
                 'vertical': 'bottom',
                 'wrap_text': True,
                 'border': {'left': 'none',
                           'right': 'none',
                           'top': 'none',
                           'bottom': 'none'},
                 'border_color': white

        data_formats (dict):
            Default options are::

                {'font_name': 'Calibri light',
                 'font_color': black,
                 'font_size': 10,
                 'bold': False,
                 'italic': False,
                 'fg_color': [white, light_bg],
                 'bg_color': white,
                 'fill_type': 'solid',
                 'horizontal': 'auto',  # Numbers are 'right', text is 'left'
                 'vertical': 'bottom',
                 'wrap_text': False,
                 'border': {'left': 'none',
                           'right': 'none',
                           'top': 'none',
                           'bottom': 'none'},
                 'border_color': white}

        column_formats (dict):
            Dictionary with column number formats. Default format is 'General'.
            For possible inputs see:
            https://openpyxl.readthedocs.io/en/stable/_modules/openpyxl/styles/numbers.html
            https://docs.microsoft.com/en-us/dotnet/standard/base-types/custom-numeric-format-strings

        column_conditional_formats (list): Column names on which to apply
         conditional formatting. Default is empty (no names provided).
         
        traffic_light_formats (dict): Argument to apply excel traffic light formatting. 
            Contains the following sub-args:

            * 'apply_traffic' (boolean): (default=False) Indicator whether to apply traffic light formatting;
            * 'traffic_cols' (str, list): Column names in df on which to apply traffic lights;
            * 'traffic_lights' (dict): Upper and lower bound of the traffic lights. If upper and lower bounds are equal, a red-green traffic light is used, e.g. {'upperbound': 0.5,'lowerbound': 0.5}. Otherwise, a red-amber-green (RAG) traffic light is used, e.g. {'upperbound': 0.5,'lowerbound': 0.3}. 
            * 'reverse_icons' (boolean): Indicates whether you want to reverse the colouring of the traffic lights, e.g. red when value is greater than the upper bound.
        
        header_height (float): Height of the header row in points.
         Default is None, which is auto.

        max_index_width (float): Maximum width of the index column, will
         be scaled when under. Default is 15.

        row_height (int): Height of all rows except the header.
         Default is 15.

        max_col_width (int): The maximum width of all columns, will be
         scaled when under. Default is 10.

        specific_row_height (dict): Dictionary with index positions
         as keys and heights as values. This overrules general row height.

        specific_col_width (dict): Dictionary with column names as keys
         and widths as values. This overrules general column width.

    Return:
        None

    Raises:
        None, errors are handled in a subfunction.

    Examples:
        Call function from Python like this::

            >>> df2excel('somepath\\filename.xlsx', sheet='Data')

            >>> df2excel('somepath/filename.xlsx', sheet='Data',
                    header = False, index = True, header_height=50,
                    row_height = 20, col_width = 15,
                    specific_row_height = {1: 50, 3:25},
                    specific_col_width = {'colname1': 20, 'colname2': 30},
                    header_formats = {
                        'font_name': 'Calibri',
                        'font_color': '00ff00',
                        'font_size': 28,
                        'horizontal': 'center',
                        'italic': True
                    },
                    data_formats = {
                        'font_name': 'Times',
                        'font_color': '0000ff',
                        'font_size': 14
                    },
                    column_formats = {
                        'colname1': '0.00',
                        'colname2': '#.##',
                        'colname3': '0.0#%'
                    })

    Warnings:
        UserWarning: If user overwrites an existing sheet.
        UserWarning: If user tries to format a column that does not exist.
        UserWarning: If user tries to add conditional formatting to a column
        that does not exist.

    Notes:
        Author: Aron Moberg <N440730>

    """
    # Open or create the workbook and sheet.
    try:
        wb = pyxl.load_workbook(workbook)
    except FileNotFoundError:
        wb = pyxl.Workbook()
        ws = wb.active
        ws.title = sheet
    else:
        try:
            wb.remove(wb[sheet])
        except KeyError:
            pass
        else:
            warning = f'Existing sheet "{sheet}" is overwritten'
            warnings.warn(warning)
        ws = wb.create_sheet(sheet)

    # Convert row and column index to string format before writing.
    df_cleaned = df.copy()
    df_cleaned.index = df_cleaned.index.astype(str)
    df_cleaned.columns = df_cleaned.columns.astype(str)

    # Populate the Excel sheet with DataFrame data.
    for r in df2rows(df_cleaned, index, header):
        ws.append(r)

    # Header formatting.
    if header:
        #: Base values for header_formats
        hfmt = {
            "font_name": "Arial",
            "font_color": _WHITE,
            "font_size": 12,
            "bold": True,
            "italic": False,
            "fg_color": _NORDEA_BLUE,
            "bg_color": _WHITE,
            "fill_type": "solid",
            "horizontal": "center",
            "vertical": "center",
            "wrap_text": True,
            "border": {
                "left": "none",
                "right": "none",
                "top": "none",
                "bottom": "none",
            },
            "border_color": _WHITE,
        }
        if header_formats:
            hfmt = {**hfmt, **header_formats}
        hborder = hfmt["border"]
        hformat = {
            "font": Font(
                name=hfmt["font_name"],
                size=hfmt["font_size"],
                color=hfmt["font_color"],
                bold=hfmt["bold"],
                italic=hfmt["italic"],
            ),
            "fill": PatternFill(
                fill_type=hfmt["fill_type"],
                fgColor=hfmt["fg_color"],
                bgColor=hfmt["bg_color"],
            ),
            "alignment": Alignment(
                horizontal=hfmt["horizontal"],
                vertical=hfmt["vertical"],
                wrap_text=hfmt["wrap_text"],
                shrink_to_fit=False,
            ),
            "border": Border(
                left=Side(style=hborder["left"], color=hfmt["border_color"]),
                right=Side(style=hborder["right"], color=hfmt["border_color"]),
                top=Side(style=hborder["top"], color=hfmt["border_color"]),
                bottom=Side(style=hborder["bottom"], color=hfmt["border_color"]),
            ),
        }
        for cell in ws[1]:
            cell.font = hformat["font"]
            cell.fill = hformat["fill"]
            cell.alignment = hformat["alignment"]
            cell.border = hformat["border"]

        if header_height:
            ws.row_dimensions[1].height = header_height

    # Index formatting.
    if index:
        ifmt = {
            "font_name": "Arial",
            "font_color": _WHITE,
            "font_size": 12,
            "bold": True,
            "italic": False,
            "fg_color": _NORDEA_BLUE,
            "bg_color": _WHITE,
            "fill_type": "solid",
            "horizontal": "right",
            "vertical": "bottom",
            "wrap_text": True,
            "border": {
                "left": "none",
                "right": "none",
                "top": "none",
                "bottom": "none",
            },
            "border_color": _WHITE,
        }
        if index_formats:
            ifmt = {**ifmt, **index_formats}
        iborder = ifmt["border"]
        iformat = {
            "font": Font(
                name=ifmt["font_name"],
                size=ifmt["font_size"],
                color=ifmt["font_color"],
                bold=ifmt["bold"],
                italic=ifmt["italic"],
            ),
            "fill": PatternFill(
                fill_type=ifmt["fill_type"],
                fgColor=ifmt["fg_color"],
                bgColor=ifmt["bg_color"],
            ),
            "alignment": Alignment(
                horizontal=ifmt["horizontal"],
                vertical=ifmt["vertical"],
                wrap_text=ifmt["wrap_text"],
                shrink_to_fit=False,
            ),
            "border": Border(
                left=Side(style=iborder["left"], color=ifmt["border_color"]),
                right=Side(style=iborder["right"], color=ifmt["border_color"]),
                top=Side(style=iborder["top"], color=ifmt["border_color"]),
                bottom=Side(style=iborder["bottom"], color=ifmt["border_color"]),
            ),
        }
        for cell in ws["A"]:
            cell.font = iformat["font"]
            cell.fill = iformat["fill"]
            cell.alignment = iformat["alignment"]
            cell.border = iformat["border"]

        # Auto-scale index width.
        index_width = (
            min(
                max_index_width,
                max([len(str(cell.value)) for cell in ws["A"][header:]]),
            )
            * 1.2
        )  # Scaling factor when exporting to workbook.
        ws.column_dimensions["A"].width = index_width

    # Data column formatting.
    dfmt = {
        "font_name": "Arial",
        "font_color": _BLACK,
        "font_size": 10,
        "bold": False,
        "italic": False,
        "fg_color": [_WHITE, _LIGHT_BG],
        "bg_color": _WHITE,
        "fill_type": "solid",
        "horizontal": "auto",
        "vertical": "bottom",
        "wrap_text": False,
        "border": {"left": "none", "right": "none", "top": "none", "bottom": "none"},
        "border_color": _WHITE,
    }
    if data_formats:
        dfmt = {**dfmt, **data_formats}
    dborder = dfmt["border"]
    dfont = Font(
        name=dfmt["font_name"],
        size=dfmt["font_size"],
        color=dfmt["font_color"],
        bold=dfmt["bold"],
        italic=dfmt["italic"],
    )
    if type(dfmt["fg_color"]) == list:
        dfill = []
        for fillcolor in dfmt["fg_color"]:
            dfill.append(
                PatternFill(
                    fill_type=dfmt["fill_type"],
                    fgColor=fillcolor,
                    bgColor=dfmt["bg_color"],
                )
            )
    elif type(dfmt["fg_color"]) == str:
        dfill = PatternFill(
            fill_type=dfmt["fill_type"],
            fgColor=dfmt["fg_color"],
            bgColor=dfmt["bg_color"],
        )

    dborder = Border(
        left=Side(style=dborder["left"], color=dfmt["border_color"]),
        right=Side(style=dborder["right"], color=dfmt["border_color"]),
        top=Side(style=dborder["top"], color=dfmt["border_color"]),
        bottom=Side(style=dborder["bottom"], color=dfmt["border_color"]),
    )

    # Handle specific or default horizontal alignment.
    col_align = []
    for c in df.columns:
        if dfmt["horizontal"] == "auto":
            if isinstance(df[c].iloc[0], Number):
                col_align.append(
                    Alignment(
                        horizontal="right",
                        vertical=dfmt["vertical"],
                        wrap_text=dfmt["wrap_text"],
                        shrink_to_fit=False,
                    )
                )
            else:
                col_align.append(
                    Alignment(
                        horizontal="left",
                        vertical=dfmt["vertical"],
                        wrap_text=dfmt["wrap_text"],
                        shrink_to_fit=False,
                    )
                )
        else:
            col_align.append(
                Alignment(
                    horizontal=dfmt["horizontal"],
                    vertical=dfmt["vertical"],
                    wrap_text=dfmt["wrap_text"],
                    shrink_to_fit=False,
                )
            )

    # Loop and set data formatting.
    for i, row in enumerate(ws.iter_rows(min_row=1 + header)):
        ws.row_dimensions[i + 1 + header].height = row_height
        for j, cell in enumerate(row[index:]):
            cell.font = dfont
            if type(dfill) == list:
                cell.fill = dfill[i % len(dfill)]
            else:
                cell.fill = dfill
            cell.alignment = col_align[j]
            cell.border = dborder

    # Set data border for top left cell if both header and index.
    if header & index:
        ws["A1"].border = dborder

    # Columns.
    cols = {}
    for col in ws.iter_cols(min_col=index + 1):
        cols[col[0].value] = col[1:]
        apply_col_width = (
            min(max_col_width, max([len(str(cell.value)) for cell in col[header:]]))
            * 1.3
        )  # Scaling factor upon export.
        ws.column_dimensions[col[0].column_letter].width = apply_col_width
    if column_formats:
        for col_name, numformat in column_formats.items():
            try:
                column = cols[col_name]
            except KeyError:
                warning = f'column_formats: Column "{col_name}" does not exist'
                warnings.warn(warning)
            else:
                for cell in column:
                    cell.number_format = numformat

    # Apply conditional formatting.
    if column_conditional_formats:
        if type(column_conditional_formats) == str:
            column_conditional_formats = [column_conditional_formats]
        for col_name in column_conditional_formats:
            try:
                column = cols[col_name]
            except KeyError:
                warning = (
                    f'column_conditional_formats: Column "{col_name}" does not exist'
                )
                warnings.warn(warning)
            else:
                # Excel does not handle boolean values very well
                # so custom code is needed for that.
                if df[col_name].dtype == bool:
                    for cell in column:
                        if cell.value:
                            cell.fill = PatternFill(
                                fill_type="solid", fgColor=_ACCENT_GREEN
                            )
                        else:
                            cell.fill = PatternFill(
                                fill_type="solid", fgColor=_ACCENT_RED
                            )
                else:
                    columnrange = column[0].coordinate + ":" + column[-1].coordinate
                    ws.conditional_formatting.add(
                        columnrange,
                        ColorScaleRule(
                            start_type="min",
                            start_color=_ACCENT_RED,
                            end_type="max",
                            end_color=_ACCENT_GREEN,
                        ),
                    )
    
    # Apply traffic light conditional formatter
    if traffic_light_formats['apply_traffic']:
        # Create list of columns
        format_cols = traffic_light_formats['traffic_cols']
        if type(format_cols) == str:
            format_cols = [format_cols]
        
        # Find Excel columns
        excel_col = []
        for col in format_cols:
            alphabet_index = df.columns.to_list().index(col) + 1
            alphabet_letter = chr(ord('@')+alphabet_index)
            excel_col.append(alphabet_letter)
        
        # Define traffic light values
        upper_val = traffic_light_formats['traffic_lights']['upperbound']
        lower_val =  traffic_light_formats['traffic_lights']['lowerbound']
        
        # Find Excel end range
        end_range = len(df) + 1
        
        # Conditional formatting for 3 traffic lights
        iconset = IconSetRule('3TrafficLights1', 'num', 
                              [0, lower_val, upper_val], 
                              showValue=True, 
                              percent=False, 
                              reverse=traffic_light_formats['reverse_icons'])
        
        for col in excel_col:
            columnrange = f'{col}2:{col}{end_range}'
            ws.conditional_formatting.add(
                    columnrange, 
                    iconset)
            
    # Set specific row and column dimensions.
    if specific_row_height:
        rows = {}
        for i, row in df.iterrows():
            rows[i] = i + 1 + header
        for i, height in specific_row_height.items():
            ws.row_dimensions[rows[i]].height = height
    if specific_col_width:
        for col, width in specific_col_width.items():
            col_letter = cols[col][0].column_letter
            ws.column_dimensions[col_letter].width = width
    ws.protection.sheet = False
    wb.save(workbook)
    print(f'Dataframe exported to "{workbook}", sheet="{sheet}"')
