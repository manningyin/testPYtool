"""
############
Introduction
############
This submodule contains functions for extracting model recommendations from extracted MRMS record files.

* **mrms_recommendation_status**: Summarizes model recommendations and exports to a Microsoft Excel spreadsheet.

Notes
=====
Author: G85538

##############
Implementation
##############
"""

from typing import Tuple
import openpyxl
import pandas as pd
import time
import os
import re
import datetime
import warnings

from typing_extensions import Literal
from crv.io.exceltables import df2excel

__all__ = ["mrms_recommendation_status"]


def mrms_recommendation_status(
    recs_id: list, mrms_input_data: str, output_file_path: str, output_file_name: str
):
    """
    Summarises the status of specified model recommendations and corresponding
    resolving actions by retrieving this information from an Excel input file
    containing MRMS information.

    Args:
        recs_id (list): The list containing the recommendation IDs for which to
        summarise the status and corresponding resolving actions.

        mrms_input_data (str): The location to the MRMS input Excel file (.xls
        and .xlsx file formats allowed).

        output_file_path (str): The location to the folder where the output
        Excel file will be written to.

        output_file_name (str): The name to the output file (must have
        a .xlsx extension)

    Returns:
        (.xlsx file): The summary table containing the status of the specified
        model recommendation and corresponding resolving actions, saved in the
        specified output_file_path.

    Raises:

        FileNotFoundError - If the input file 'mrms_input_data' does not exist.

        FileNotFoundError - If the output folder 'output_file_path' does not
        exist.

        ValueError - If the input file 'mrms_input_data' does not contain the
        required sheets ['Recommendations', 'Action Plans',
        'Recommendation|Action Plan', 'Action Plan|Owner', 'Users']

        ValueError - If the input file 'mrms_input_data' is a .xls or .xlsx
        file.

        ValueError - If the 'recs_id' is not a Python list.

        ValueError - If the 'recs_id' is a empty Python list.

        ValueError - If the output file does not end with '.xlsx' extension

    Examples:
        Call function in Python like this::

            from crv.io.mrms_reporting import mrms_recommendation_status
            recs_id = ["F_CRMV-val-819533888-1","F_CRMV-val-1718360099-2"]
            input_MRMS_file = "C:/Users/g85538/Nordea/CRV_PYLIB - Documents/General/MRMS/Follow-up memo table/Input_2020-06-02.xls"
            output_folder = "C:/Users/g85538/Documents/Projects/MRMS_reporting/output"
            output_file_name = "MRMS_output.xlsx"
            mrms_recommendation_status(recs_id, input_MRMS_file, output_folder, output_file_name)

    Notes:
        Author: Reinout Kool <G85338>
    """
    # Fuction parameter input errors
    req_sheets = [
        "Recommendations",
        "Action Plans",
        "Recommendation|Action Plan",
        "Action Plan|Owner",
        "Users",
    ]

    # Check if recs_id is a Python list
    if not isinstance(recs_id, list):
        raise ValueError(
            f"{recs_id} is not a list. Input parameter 'recs_id' only "
            f"accepts a list as input."
        )

    # Check if recs_id is not empty
    if not len(recs_id) > 0:
        raise ValueError(
            f"{recs_id} is an empty list. Input parameter 'recs_id' "
            f"only accepts non-empty lists as input."
        )

    # FileNotFoundError - Check if input file exists
    if not os.path.exists(mrms_input_data):
        raise FileNotFoundError(
            f"The input file specified in the following "
            + f"location does not exist: {mrms_input_data}"
        )

    # FileNotFoundError - Check if output folder exists
    if not os.path.exists(output_file_path):
        raise FileNotFoundError(
            f"The output folder in by following "
            + f"location does not exist: {output_file_path}"
        )

    # ValueError - Check if is excel (.xls or .xlsx)
    file_extension = os.path.splitext(mrms_input_data)[1]
    if not file_extension == ".xls" and not file_extension == ".xlsx":
        raise ValueError(
            f"The input file specified in the following "
            + f"location is not a .xls or .xlsx file: {mrms_input_data}"
        )

    # ValueError, check if available sheets are available
    xl_sheets = pd.ExcelFile(mrms_input_data).sheet_names
    if not set(req_sheets).issubset(xl_sheets):
        raise ValueError(
            f"The input file location "
            + "does not contain the required "
            + f"sheets: {req_sheets}"
        )

    # FileNotFoundError - Check if output folder exists
    if not str(output_file_name)[-5:] == ".xlsx":
        raise ValueError(
            f"The output file name {output_file_name} does "
            + f"not end with a '.xlsx' extension."
        )

    # Import data from Excel sheets
    sheets_rec = [
        "ID",
        "Initiation date",
        "Recommendation",
        "Severity",
        "Issue",
        "Closed",
        "Name",
    ]
    sheets_rec_act = ["Recommendation", "Action Plan"]
    sheets_act_owner = ["Action Plan", "Owner"]
    sheets_user = ["ID", "Name"]
    dict_sheets_cols = {
        "Recommendations": sheets_rec,
        "Action Plans": "All columns",
        "Recommendation|Action Plan": sheets_rec_act,
        "Action Plan|Owner": sheets_act_owner,
        "Users": sheets_user,
    }

    df_list = df_read_excel_sheets(mrms_input_data, dict_sheets_cols)
    df_recs = df_list["Recommendations"]
    df_actions = df_list["Action Plans"]
    df_recs_actions_keys = df_list["Recommendation|Action Plan"]
    df_actions_owner_keys = df_list["Action Plan|Owner"]
    df_user_owner_keys = df_list["Users"]
    del df_list

    df_report, df_ex_deadline = mrms_data_consolidator(
        recs_id,
        df_recs,
        df_actions,
        df_recs_actions_keys,
        df_actions_owner_keys,
        df_user_owner_keys,
    )

    # Create output excel
    file_location = create_output_excel(df_report, output_file_path, output_file_name)

    # Write to output excel (sheet per recommendation)
    for _, row in df_report.iterrows():
        df_sheet_content, sheet_name, column_title = output_per_recommendation(
            df_report, row, df_ex_deadline
        )
        write_to_excel(df_sheet_content, sheet_name, column_title, file_location)


def rec_id_in_action_id_check(
    recs_id: list, df_recs: pd.DataFrame, df_recs_actions_keys: pd.DataFrame
) -> list:
    """
    Adjacent function to check whether the specified recommendation IDs can be
    linked to recommendation IDs and Action IDs from MRMS.

    Args:
        recs_id (list): List of recommendation IDs.

        df_recs (Pandas.DataFrame): DataFrame containing Recommendation IDs
        from MRMS.

        df_recs_actions_keys (Pandas.DataFrame): DataFrame containing Action
        IDs from MRMS.

    Raises:
        KeyError - If none of the recommendation IDs in recs_id can be linked
        to a recommendation ID from MRMS.

        Warning - If some of the recommendation IDs in recs_id cannot be linked
        to a recommendation ID from MRMS.

        KeyError - If none of recommendation IDs in recs_id can be linked to an
        Action ID from MRMS.

        Warning - If some of the recommendation IDs in recs_id cannot be linked
        to an Action ID from MRMS.

    Returns:
        recs_id_act (list): a subset of recommendation IDs that can be linked
        to Recommendation IDs and Action IDs from MRMS.
    """

    # KeyError - Check if Recommendation ID exists
    recs_id_recs = [i for i in recs_id if i in df_recs["ID"].values.tolist()]
    recs_id_not = [i for i in recs_id if not i in df_recs["ID"].values.tolist()]
    if recs_id_recs == []:
        raise KeyError(
            f"\n The following Recommendation ID(s) {recs_id_not} "
            f"cannot be linked to a Recommendation ID in MRMS. \n"
        )
    if len(recs_id_recs) < len(recs_id):
        warnings.warn(
            f"\n The following Recommendation ID(s) {recs_id_not} "
            f"cannot be linked to a Recommendation ID in MRMS. \n"
        )

    # Check if Action ID is available for Recommendation ID
    recs_id_act = [
        i
        for i in recs_id_recs
        if i in df_recs_actions_keys["Recommendation"].values.tolist()
    ]
    recs_id_not = [
        i
        for i in recs_id_recs
        if not i in df_recs_actions_keys["Recommendation"].values.tolist()
    ]
    # Attach Open/Closed status
    df_recs["Closed"] = df_recs["Closed"].replace({False: "Closed", True: "Open"})
    rec_status = {}
    for recommendation in recs_id_not:
        rec_status[recommendation] = df_recs.loc[
            df_recs["Recommendation"] == recommendation, "Closed"
        ].name
    if recs_id_act == []:
        raise UserWarning(
            f"\n The following Recommendation ID(s) with"
            f" a corresponding open/closed status cannot be linked"
            f" to an Action ID {rec_status} \n"
        )
    if len(recs_id_act) < len(recs_id_recs):
        warnings.warn(
            f"\n The following Recommendation ID(s) with "
            f" a corresponding open/closed status cannot be linked"
            f" to an Action ID {rec_status} \n"
        )

    # If there are still recommendation IDs that can be linked to a
    # recommendation ID and Action ID in MRMS
    print(
        f"\n Analysis performed for the following "
        f"Recommendation ID(s) {recs_id_act} \n"
    )

    return recs_id_act


def df_read_excel_sheets(excel_location: str, dict_sheets_cols: list) -> list:
    """
    Adjacent function to read from the excel file specified under
    mrm_input_data the sheets specified under dict_sheets_cols.

    Args:
        excel_location (str): The location to the MRM input Excel file (.xls
        and .xlsx file formats allowed).

        dict_sheets_cols (list): List of sheets that should be will be read
        from the excel_location.

    Returns:
        df_list (list): List of Pandas DataFrames
    """
    df_list = {}
    for sheet in dict_sheets_cols:
        if dict_sheets_cols[sheet] == "All columns":
            df_list[sheet] = pd.read_excel(excel_location, sheet_name=sheet)
        else:
            df_list[sheet] = pd.read_excel(
                excel_location, sheet_name=sheet, usecols=dict_sheets_cols[sheet]
            )

    return df_list


def merge_df(
    df_left: pd.DataFrame,
    df_right: pd.DataFrame,
    left_ID: str,
    right_ID: str,
    validate: str,
    how: Literal["inner", "outer", "left", "right"] = "inner",
    drop_cols: list = None,
    rename_cols: list = None,
) -> pd.DataFrame:
    """
    Adjacent function to merge two dataframe.

    Args:
        df_left (Pandas.DataFrame): The left DataFrame to merge with.

        df_right (Pandas.DataFrame): The right DataFrame to merge with.

        left_ID (str): Column nams to join on in the left DataFrame.

        right_ID (str): Column nams to join on in the right DataFrame.

        validate (str): Checks if merge is of specified type. Aligns with the
        options specified under pandas.DataFrame.merge:
            * one_to_one or 1:1: check if merge keys are unique in both left and right datasets.
            * one_to_many or 1:m: check if merge keys are unique in left dataset.
            * many_to_one or m:1: check if merge keys are unique in right dataset.
            * many_to_many or m:m: allowed, but does not result in checks.

        how (str): Type of merge to be performed. Aligns with the options
        specified under pandas.DataFrame.merge:
            * left: use only keys from left frame, similar to a SQL left outer
              join; preserve key order.
            * right: use only keys from right frame, similar to a SQL right
              outer join; preserve key order.
            * outer: use union of keys from both frames, similar to a SQL full
              outer join; sort keys lexicographically.
            * inner (default): use intersection of keys from both frames,
              similar to a SQL inner join; preserve the order of the left keys.

        drop_cols (list): List of column names that should be dropped after
        the merge.

        rename_cols (dict): Dictionary of old column names with corresponding
        new column names for renaming after the merge.

    Returns:
        df_left (Pandas.DataFrame): A merged Pandas Dataframes
    """
    df_left = df_left.merge(
        df_right, left_on=left_ID, right_on=right_ID, how=how, validate=validate
    )

    if not drop_cols is None:
        df_left = df_left.drop(columns=drop_cols)

    if not rename_cols is None:
        df_left = df_left.rename(columns=rename_cols)

    return df_left


def single_rec_per_recommendation(
    df: pd.DataFrame, sort_values_cols: list, duplicate_cols: list, exchange_cols: list
) -> pd.DataFrame:
    """
    Adjacent function to obtain the most recent actions per recommendation.
    The most recent actions are identified by filtering the most
    recent resolve status from the column 'Action name'; e.g. filter out
    action that has 'resolve 2' from the following three actions with resolve
    status: 'resolve 0', 'resolve 1', 'resolve 2').

    If there is an action with a break-down of resolve status, the function
    filters out the actions with latest resolve status; e.g. filter out
    actions that have 'resolve 2a' and 'resolve 2b' from the following four
    actions with resolve status: 'resolve 0', 'resolve 1', 'resolve 2a',
    'resolve 2b').

    Args:
        df (Pandas.DataFrame): The object DataFrame.

        sort_values_cols (list): List of column names that require sorting
        before dropping duplicates.

        duplicate_cols (list): List of column names on which duplicates will
        be dropped.

        exchange_cols (list): Two sort_values and duplicate drops take place.
        The first includes the original information when the recommendation
        was created. The second contains latest information on the
        recommendation. exchange_cols specifies the column names that should
        contain the latest information.

    Returns:
        df (Pandas.DataFrame): A filtered Pandas Dataframes
    """
    # Create column retrieving resolve status from column "Action name"
    df["sort_col"] = df["Action name"].str.extract("(\d)", expand=True)

    # -----------------------
    df["sort_col"] = pd.to_numeric(df["sort_col"])

    # Following code is an alternative to:
    # df_max = df.groupby(['ID Recommendation']).max()['sort_col'].reset_index()
    # df_max['tuple'] = list(zip(df_max['ID Recommendation'], df_max['sort_col']))
    # df_min = df.groupby(['ID Recommendation']).min()['sort_col'].reset_index()
    # df_min['tuple'] = list(zip(df_min['ID Recommendation'], df_min['sort_col']))
    # The code df.groupby().min() and df.groupby().max() do not work in
    # pandas versions > 1.0.0, which is a bug in pandas and may be resolved
    # in future releases of pandas.
    unique_rec_id = df["ID Recommendation"].unique()
    max_list = []
    min_list = []
    for rec_id in unique_rec_id:
        df_filter = df[df["ID Recommendation"] == rec_id]
        max_list.append(df_filter["sort_col"].max())
        min_list.append(df_filter["sort_col"].min())

    df_max = pd.DataFrame(
        list(zip(unique_rec_id, max_list, tuple(zip(unique_rec_id, min_list)))),
        columns=["ID Recommendation", "sort_col", "tuple"],
    )
    df_min = pd.DataFrame(
        list(zip(unique_rec_id, max_list, tuple(zip(unique_rec_id, max_list)))),
        columns=["ID Recommendation", "sort_col", "tuple"],
    )

    df_2 = df[
        df[["ID Recommendation", "sort_col"]].apply(tuple, axis=1).isin(df_min["tuple"])
    ]
    df_2 = df_2[["ID Recommendation", "Action name"] + exchange_cols]

    df_1 = df[
        df[["ID Recommendation", "sort_col"]].apply(tuple, axis=1).isin(df_max["tuple"])
    ]
    df_1 = df_1.drop(exchange_cols + ["Action name"], axis=1)

    df_1 = (
        df_1.sort_values("Extended_deadline", ascending=[True])
        .drop_duplicates(subset=duplicate_cols, keep="first")
        .reset_index()
    )

    df_1 = merge_df(
        df_left=df_1,
        df_right=df_2,
        left_ID="ID Recommendation",
        right_ID="ID Recommendation",
        validate="one_to_many",
        drop_cols=["sort_col"],
    )

    return df_1


def create_output_excel(
    df: pd.DataFrame, output_file_path: str, output_file_name: str
) -> str:
    """
    Adjacent function to create an output Excel file in a specified folder.

    Args:
        df (Pandas.DataFrame): The object DataFrame.

        output_file_path (str): Path to the folder in which the output
        Excel should be stored.

        output_file_name (str): The name to the output file (must have
        a .xlsx extension)

    Returns:
        location (str): Location to the created output Excel file.
    """
    # Create name
    location = output_file_path + "/" + output_file_name

    # Check if file exists and deltes
    if os.path.exists(location):
        os.remove(location)

    # Create excel
    wb = openpyxl.Workbook()
    ws = wb.active

    if len(df[df["ID Recommendation"] == df.at[0, "ID Recommendation"]]) > 1:
        sheet_name = (
            str(df.at[0, "ID Recommendation"]) + "-" + str(df.at[0, "ID Action"])[-1]
        )
    else:
        sheet_name = df.at[0, "ID Recommendation"]

    ws.title = sheet_name
    wb.save(location)

    return location


def output_per_recommendation(
    df: pd.DataFrame, row: pd.DataFrame, df_ex_deadline: pd.DataFrame
) -> pd.DataFrame:
    """
    Adjacent function to create the final dataframe per recommendation.

    Args:
        row (Pandas.DataFrame): A DataFrame that is a row from the larger
        DataFrame.

        df_ex_deadline (Pandas.DataFrame): DataFrame containing the number of
        extended deadlines for an action.

    Returns:
        df_sheet (Pandas.DataFrame): DataFrame that can be written to the
        final Excel file.

        sheet_name (str): Name of the sheet to which df_sheet will be written.

        column_title (str): Name of the column containing the data.
    """
    # Create sheet names and title for the table per sheet
    try:
        action_num = row["Name"].split("- ")[1].capitalize()
        recommendation = row["Recommendation"].capitalize()
        column_title = f"{action_num} - {recommendation}"
    except:
        action_num = row["Name"]
        recommendation = row["Recommendation"].capitalize()
        column_title = recommendation

    # Try getting properly formatted datetimes
    try:
        rec_init_date = row["Recommendation creation date"].strftime("%d %B %Y")
    except:
        rec_init_date = row["Recommendation creation date"]
    try:
        act_init_date = row["Initiation date action"].strftime("%d %B %Y")
    except:
        act_init_date = row["Initiation date action"]
    try:
        mat_sub_date = row["Material submission date"].strftime("%d %B %Y")
    except:
        mat_sub_date = row["Material submission date"]
    try:
        orig_deadline = row["Original deadline"].strftime("%d %B %Y")
    except:
        orig_deadline = row["Original deadline"]

    # Change affected models to "All models" if recommendation is general rec
    if "G" in action_num.capitalize():
        model_fam = "All models"
    else:
        model_family_list = row["Full Classification"].split("Model family")[1:]
        model_fam = ""
        for family in model_family_list:
            model = family.split(",")[0].split(">")[-1][1:]
            model_fam = model if model_fam == "" else model_fam + f", {model}"

    # Content of table per sheet
    dict = {
        "MRMS ID": [row["ID Recommendation"]],
        "Priority": [row["Severity"]],
        "Affected models": [model_fam],
        "Recommendation description": [row["Issue"]],
        "Recommendation creation date": [rec_init_date],
        "Action plan and deadline": ["Action plan and deadline"],
        "Issue owner": [row["Issue Owner"]],
        "Action plan": [row["Description"]],
        "Action plan ID": [row["ID Action"]],
        "Date of last review": [act_init_date],
        "Material Submission date": [mat_sub_date],
        "Original deadline": [orig_deadline],
    }

    for i in range(1, len(df_ex_deadline.columns) - 1):
        dead_line_column = "Extended deadline " + str(i)
        if not row[dead_line_column] == "Unregistered":
            try:
                dict[dead_line_column] = row[dead_line_column].strftime("%d %B %Y")
            except:
                dict[dead_line_column] = row[dead_line_column]

    df_sheet = pd.DataFrame(data=dict, index=[column_title])
    df_sheet = df_sheet.T
    if len(df[df["ID Recommendation"] == row["ID Recommendation"]]) > 1:
        sheet_name = str(row["ID Recommendation"]) + "-" + str(row["ID Action"])[-1]
    else:
        sheet_name = row["ID Recommendation"]

    return df_sheet, sheet_name, column_title


def write_to_excel(
    df_sheet: pd.DataFrame, sheet_name: str, column_title: str, location: str
):
    """
    Adjacent function to write the output DataFrame to sheets in the
    output Excel.

    Args:
        df_sheet (Pandas.DataFrame): The object DataFrame.

        sheet_name (str): Name of the sheet to which df_sheet will be written.

        column_title (str): Name of the column containing the data.

        location (str): Location to the created output Excel file.
    """
    df2excel(
        df=df_sheet,
        workbook=location,
        sheet=sheet_name,
        index=True,
        max_index_width=30,
        specific_col_width={column_title: 100},
        header_formats={"font_size": 10, "fg_color": "002060", "horizontal": "left"},
        data_formats={
            "horizontal": "left",
            "fg_color": ["ffffff"],
            "border_color": "000000",
            "border": {
                "left": "thin",
                "right": "thin",
                "top": "thin",
                "bottom": "thin",
            },
        },
        index_formats={
            "font_size": 10,
            "fg_color": "c5d9f1",
            "font_color": "000000",
            "border_color": "000000",
            "horizontal": "center",
            "border": {
                "left": "thin",
                "right": "thin",
                "top": "thin",
                "bottom": "thin",
            },
        },
    )


def mrms_data_consolidator(
    recs_id: list,
    df_recs: pd.DataFrame,
    df_actions: pd.DataFrame,
    df_recs_actions_keys: pd.DataFrame,
    df_actions_owner_keys: pd.DataFrame,
    df_user_owner_keys: pd.DataFrame,
) -> Tuple[pd.DataFrame]:
    """
    Adjacent function that summarises the status of specified model
    recommendations and corresponding resolving actions by retrieving this
    information from four dataframes containing MRMRS information for an
    Excel input file.

    Args:
        recs_id (list): The list containing the recommendation IDs for which to
        summarise the status and corresponding resolving actions.

        df_recs (Pandas.DataFrame): Dataframe containing data on Recommendation
        specifications.

        df_actions (Pandas.DataFrame): Dataframe containing data on Action
        specifications.

        df_recs_actions_keys (Pandas.DataFrame): Dataframe containing data on
        Recommendation IDs and Action IDs to merge the df_recs and df_actions.

        df_user_owner_keys (Pandas.DataFrame): Dataframe containing data on
        User specifications

        df_actions_owner_keys (Pandas.DataFrame): Dataframe containing data on
        recommendation IDs and User IDs to merge the df_recs and
        df_user_owner_keys.

    Returns:
        df_report (Pandas.DataFrame): The summary DataFrame containing the
        status of the specified model recommendation and corresponding
        resolving actions.

        df_ex_deadline (Pandas.DataFrame): The DataFrame containing the
        details on (extended) deadlines for the Actions.

    Raises:

        ValueError - If recs_id is not a list

        ValueError - If recs_id is an empty list

        ValueError - If df_recs is not a Pandas.DataFrame

        ValueError - If df_actions is not a Pandas.DataFrame

        ValueError - If df_recs_actions_keys is not a Pandas.DataFrame

        ValueError - If df_user_owner_keys is not a Pandas.DataFrame

        ValueError - If df_actions_owner_keys is not a Pandas.DataFrame
    Notes:
        Author: Reinout Kool <G85338>

    """
    # Check if recs_id is a Python list
    if not isinstance(recs_id, list):
        raise ValueError(
            f"{recs_id} is not a list. Input parameter 'recs_id' only "
            f"accepts a list as input."
        )

    # Check if recs_id is not empty
    if not len(recs_id) > 0:
        raise ValueError(
            f"{recs_id} is an empty list. Input parameter 'recs_id' "
            f"only accepts non-empty lists as input."
        )

    # Check if df_recs is a Pandas.DataFrame
    if not type(df_recs) == pd.DataFrame:
        raise ValueError(
            f"df_recs is not a Pandas.DataFrame. Input parameter "
            f"'df_recs' only accepts a list as input."
        )

    # Check if df_actions is a Pandas.DataFrame
    if not type(df_actions) == pd.DataFrame:
        raise ValueError(
            f"df_actions is not a Pandas.DataFrame. Input parameter "
            f"'df_actions' only accepts a list as input."
        )

    # Check if df_recs_actions_keys is a Pandas.DataFrame
    if not type(df_recs_actions_keys) == pd.DataFrame:
        raise ValueError(
            f"df_recs_actions_keys is not a Pandas.DataFrame. "
            f"Input parameter 'df_recs_actions_keys' only accepts "
            f"a list as input."
        )

    # Check if df_user_owner_keys is a Pandas.DataFrame
    if not type(df_user_owner_keys) == pd.DataFrame:
        raise ValueError(
            f"df_user_owner_keys is not a Pandas.DataFrame. Input "
            f"parameter 'df_user_owner_keys' only accepts a list "
            f"as input."
        )

    # Check if df_actions_owner_keys is a Pandas.DataFrame
    if not type(df_actions_owner_keys) == pd.DataFrame:
        raise ValueError(
            f"df_actions_owner_keys is not a Pandas.DataFrame. "
            f"Input parameter 'df_actions_owner_keys' only accepts "
            f"a list as input."
        )

    # Check if Action ID is available for Recommendation ID
    recs_id = rec_id_in_action_id_check(recs_id, df_recs, df_recs_actions_keys)

    # Filtering the dataframes
    df_recs = df_recs.loc[df_recs["ID"].isin(recs_id)].copy()

    df_recs_actions_keys = df_recs_actions_keys.loc[
        df_recs_actions_keys["Recommendation"].isin(recs_id)
    ].copy()

    df_actions = df_actions.loc[
        df_actions["ID"].isin(df_recs_actions_keys["Action Plan"])
    ].copy()

    df_actions_owner_keys = df_actions_owner_keys.loc[
        df_actions_owner_keys["Action Plan"].isin(df_recs_actions_keys["Action Plan"])
    ].copy()

    df_user_owner_keys = df_user_owner_keys.loc[
        df_user_owner_keys["ID"].isin(df_actions_owner_keys["Owner"])
    ].copy()

    # Merging the dataframes
    # Link Action ID to recommendation ID
    df_actions = merge_df(
        df_left=df_actions,
        df_right=df_recs_actions_keys,
        left_ID="ID",
        right_ID="Action Plan",
        validate="one_to_one",
        rename_cols={"Name": "Action name"},
    )

    # Link Action ID to recommendation description
    rename_cols_after_merge = {
        "ID_x": "ID Action",
        "ID_y": "ID Recommendation",
        "Initiation date_x": "Initiation date action",
        "Initiation date_y": "Initiation date recommendation",
        "Recommendation_y": "Recommendation",
        "Due date for closure": "Extended_deadline",
    }
    df_actions = merge_df(
        df_left=df_actions,
        df_right=df_recs,
        left_ID="Recommendation",
        right_ID="ID",
        validate="many_to_one",
        drop_cols=["Recommendation_x"],
        rename_cols=rename_cols_after_merge,
    )

    # Link owner ID to action owner name
    df_actions_owner_keys = merge_df(
        df_left=df_actions_owner_keys,
        df_right=df_user_owner_keys,
        left_ID="Owner",
        right_ID="ID",
        validate="many_to_one",
        drop_cols=["ID"],
    )
    df_actions_owner_keys = df_actions_owner_keys.drop_duplicates(subset="Action Plan")

    # Link  action owner name to recommendation ID
    rename_cols_after_merge = {
        "Recommendation": "Rec_recs_action",
        "Owner": "User ID",
        "Name": "Issue Owner",
    }
    df_recs_actions_keys = merge_df(
        df_left=df_recs_actions_keys,
        df_right=df_actions_owner_keys,
        left_ID="Action Plan",
        right_ID="Action Plan",
        validate="many_to_one",
        drop_cols=["Action Plan"],
        rename_cols=rename_cols_after_merge,
    )

    # Obtain dataset with one record per recommendation
    exchange_cols = [
        "ID Action",
        "Description",
        "Initiation date action",
        "Material submission date",
    ]
    df_report = single_rec_per_recommendation(
        df_actions,
        ["ID Recommendation", "Initiation date action"],
        "ID Recommendation",
        exchange_cols,
    )

    # Add columns for number of extended deadlines
    df_actions["Extended_deadline"] = df_actions["Extended_deadline"].replace(
        {pd.NaT: "No deadline registered"}
    )
    df_actions = df_actions.sort_values(
        ["ID Recommendation", "sort_col"], ascending=[True, True]
    )
    df_ex_deadline = (
        df_actions.assign(
            flag=df_actions.groupby("ID Recommendation").Extended_deadline.cumcount()
        )
        .pivot_table(
            index="ID Recommendation",
            columns="flag",
            values="Extended_deadline",
            aggfunc="first",
        )
        .add_prefix("Extended deadline ")
    )
    df_ex_deadline["ID"] = df_ex_deadline.index
    # Add row for IDs that have missing deadlines
    if not set(["ID", "Extended deadline 0"]).issubset(df_ex_deadline.columns):
        df_ex_deadline = pd.DataFrame(columns=["ID", "Extended deadline 0"])
    for id in recs_id:
        if not id in df_ex_deadline["ID"]:
            row_num = len(df_ex_deadline)
            df_ex_deadline.at[row_num, "ID"] = id

    df_report = merge_df(
        df_left=df_report,
        df_right=df_ex_deadline,
        left_ID="ID Recommendation",
        right_ID="ID",
        validate="many_to_one",
        drop_cols=["ID", "Extended_deadline"],
        rename_cols={"Extended deadline 0": "Original deadline"},
    )

    # Link unique recommendation ID to action owner name
    df_recs_actions_keys = df_recs_actions_keys.drop_duplicates(
        subset="Rec_recs_action", keep="first"
    )
    df_report = merge_df(
        df_left=df_report,
        df_right=df_recs_actions_keys,
        left_ID="ID Recommendation",
        right_ID="Rec_recs_action",
        how="left",
        validate="many_to_one",
        drop_cols=["Rec_recs_action"],
    )

    # Fill empty values
    df_report = df_report.fillna("Unregistered")
    df_report = df_report.replace({pd.NaT: "Unregistered"})

    # Rename columns
    column_new_names = {
        "MRMS ID": "ID Recommendation",
        "Priority": "Severity",
        "Affected models": "Most Specific Model family",
        "Recommendation description": "Issue",
        "Recommendation creation date": "Recommendation creation date",
        "Model owner response": "Model owner response",
        "Issue owner": "Issue owner",
        "Action plan": "Description",
        "Action plan ID": "ID Action",
        "Date of last follow-up": "Date of last follow-up",
        "Material Submission date": "Material Submission date",
        "Initiation date recommendation": "Recommendation creation date",
    }

    df_report = df_report.rename(columns=column_new_names)

    return df_report, df_ex_deadline
