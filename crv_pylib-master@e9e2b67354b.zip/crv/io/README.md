# `crv.io` module
## Functionality
Handling getting data into and out of the Python validation environment.

## Submodules
### `exceltables.py`
Format and export `pandas.DataFrame`s to Microsoft Excel spreadsheets.

### `mrms_reporting.py`
Read and summarize MRMS data from a given Microsoft Excel input file.

### `plotting.py`
Format and export data visualizations based on `pandas.DataFrame`s. Graphs are constructed using `matplotlib` and Nordea colour schemes.
