"""
Utility functions for converting and handling data using PySpark.

Notes:
    Author: G01679
"""

# Imports.
import os
import time
from typing import Union
import pyspark.sql.dataframe as psd
from pyspark.sql import SparkSession
from pyspark.sql.window import Window as w
import pyspark.sql.functions as f
import pyspark.sql
from pyspark.sql.types import IntegerType
from typing_extensions import Literal


def spark_csv2parquet(
    input_filepath: str,
    output_filepath: str,
    partition_by: Union[int, str, list] = None,
    sort_by: Union[str, list] = None,
    ascending: bool = True,
    overwrite: bool = False,
    header: bool = True,
    delimiter: str = ",",
    num_cores: int = 2,
    use_memory: str = "4g",
) -> None:
    """
    Converts a CSV file to a PARQUET file format, as specified in the input and output
    arguments. Function can also perform partitioning, and has options for
    overwriting existing files and including a header.

    Args:
        input_filepath: (str) File path and file name (including extension) for input csv file.

        output_filepath: (str) File path and file name (including extension) for output parquet file.

        partition_by: (int, str, list) If integer, it is the number of partitions to create. If string,
        it is the column name by which to partition. If a list of strings is submitted, the
        partitioning will happen in the order of the list. Default is None, and no repartitioning will
        take place.

        sort_by: (str, list) The column name or list of column names by which to sort the DataFrame.
        ascending: (bool) Sort the DataFrame in ascending order. Default is True.

        overwrite: (bool) Whether or not to overwrite and existing file of the same name.
        Default is False.

        header: (bool) Whether or not to include the column header. Default is True.

        delimiter: (str) The character to use as data separator. Default is ','.

        num_cores: (int) Number of CPU cores to use in parallel. Default is 2.

        use_memory: (str) Amount of system RAM to use in total. For example, 100MB is '100m',
        3 GB is '3g'. Default value is '4g'.

    Returns:
        None

    Raises:
        ValueError: if not all elements of 'partition_by' list are strings
        ValueError: if 'partition_by' is not of type int, str, or list
        ValueError: if the specified output file already exists and overwrite=False

    Examples:
        Call function in Python like this::

            spark_csv2parquet('Sample_Data\\2019_accounts.csv', 'converted\\2019_accounts.parquet')

    """
    # --- Run through checks before reading large files ---
    # check if 'partition_by' is a list, and if every item is a string
    if isinstance(partition_by, list):
        for p_by in partition_by:
            if not isinstance(p_by, str):
                raise ValueError(
                    """If argument 'partition_by' is a list, every element must be a string."""
                )
    elif not (
        isinstance(partition_by, int)
        or isinstance(partition_by, str)
        or isinstance(partition_by, type(None))
    ):
        raise ValueError(
            "Argument 'partition_by' must be of type 'str', 'int', or 'list' only."
        )

    # check if output file exists before reading CSV
    if (not overwrite) & (
        os.path.isfile(output_filepath) | os.path.isdir(output_filepath)
    ):
        raise ValueError(
            f"File or folder '{output_filepath}' already exists. Please choose another 'output_filepath'."
        )

    # check if 'sort_by' columns are strings
    if isinstance(sort_by, list):
        for s_by in sort_by:
            if not isinstance(s_by, str):
                raise ValueError(
                    """If argument 'sort_by' is a list, every element must be a string."""
                )
    elif isinstance(sort_by, str):
        sort_by = [sort_by]
    elif not isinstance(sort_by, type(None)):
        raise ValueError("Argument 'sort_by' must be of type 'str' or 'list' only.")

    filename = input_filepath.split("\\")[-1]
    print(f"== Converting CSV file '{filename}' to PARQUET format ==")

    # Create Spark Session and load CSV.
    spark = (
        SparkSession.builder.appName("csv2parquet")
        .config("spark.executor.instances", num_cores)
        .config("spark.driver.memory", use_memory)
        .getOrCreate()
    )
    start_time = time.time()
    print(f"[ ] Reading CSV file...", end="")
    df = spark.read.option("delimiter", delimiter).csv(
        input_filepath, header=header, inferSchema=True
    )
    read_time_split = time.time()
    read_time = read_time_split - start_time
    print(
        f"\r[X] Reading CSV file complete. {' '*3}Read time: {int(read_time//60)}m {read_time%60:.1f}s"
    )

    # Sort the DataFrame.
    if not isinstance(sort_by, type(None)):
        df = df.orderBy(*sort_by, ascending=ascending)

    # Repartition if desired, and write to file.
    overwrite_mode = "overwrite"
    header_str = "true" if header else "false"
    if isinstance(partition_by, type(None)):
        print(f"[ ] Writing to PARQUET format...", end="")
        df.write.option("header", header_str).mode(overwrite_mode).parquet(
            output_filepath
        )
    else:
        print(f"[ ] Repartitioning and writing to PARQUET format...", end="")
        if isinstance(partition_by, int):
            df.repartition(partition_by).write.option("header", header_str).mode(
                overwrite_mode
            ).parquet(output_filepath)
        elif isinstance(partition_by, str):
            df.repartition(partition_by).write.option("header", header_str).mode(
                overwrite_mode
            ).partitionBy(partition_by).parquet(output_filepath)
        elif isinstance(partition_by, list):
            df.repartition(*partition_by).write.option("header", header_str).mode(
                overwrite_mode
            ).partitionBy(*partition_by).parquet(output_filepath)

    # Stop the Spark Session.
    spark.stop()

    # Print the execution time.
    stop_time = time.time()
    write_time = stop_time - read_time_split
    total_time = stop_time - start_time
    print(
        f"\r[X] Writing to PARQUET complete. Write time: {int(write_time//60)}m {write_time%60:.1f}s"
    )
    print("-" * 54)
    print(
        f"{' '*22}Total conversion time: {int(total_time//60)}m {total_time%60.:.1f}s"
    )


# Function to create a Spark index column
def spark_create_index_col(
    df: psd.DataFrame, order: Literal["asc", "desc"] = "asc", index_name: str = "idx"
) -> psd.DataFrame:
    """
    This function creates an index for a Spark dataframe.

    Args:
        df (pyspark.sql.DataFrame): Input Spark dataframe.

        order (str): (Default="asc") (options="asc", "desc"). Specifies
        sort order, where "asc" creates an ascending index column
        (starting at 1) and "desc" creates an descending index column.

        index_name (str): (Default="idx") Name of the to-be created
        index column.

    Returns:
        df (pyspark.sql.DataFrame): Input Spark dataframe with an extra
        column containing the index

    Raises:
        ValueError - if df is not a pyspark.sql.DataFrame

        ValueError - if df is an empty pyspark.sql.DataFrame

        ValueError - if order is not a string

        ValueError - if index_name is not a string

        ValueError - if order is not either of the options: 'asc' or 'desc'.

    Examples:
        Call function in Python like this::

            df = create_spark_index_col(df,
                            order="asc",
                            index_name="idx")

    Notes:
        Author: Reinout Kool <G85538>
    """
    # Check if df is a Pandas DataFrame
    if not isinstance(df, pyspark.sql.DataFrame):
        raise ValueError(
            f"df is not a pyspark.sql.DataFrame. Input parameter "
            f"'df' only accepts pyspark.sql.DataFrame as input."
        )

    # Check if df is not empty
    if not df.count() > 0:
        raise ValueError(
            f"df is an empty pyspark.sql.DataFrame. Input "
            f"parameter 'df' only accepts non-empty "
            f"pyspark.sql.DataFrame as input."
        )

    # Check if order is a string
    if not isinstance(order, str):
        raise ValueError(
            f"{order} is not a string. Input parameter "
            f"'order' only accepts a string as input."
        )

    # Check if index_name is a string
    if not isinstance(index_name, str):
        raise ValueError(
            f"{index_name} is not a string. Input parameter "
            f"'index_name' only accepts a string as input."
        )

    # Check if order is either 'asc' or 'desc'.
    if order not in ["asc", "desc"]:
        raise ValueError(f"{order} must be either of value 'asc' or " f"'desc'. ")

    # Create an index
    df = df.withColumn(index_name, f.monotonically_increasing_id())
    if order == "asc":
        windowSpec = w.orderBy(f.asc(index_name))
    elif order == "desc":
        windowSpec = w.orderBy(f.desc(index_name))
    df = df.withColumn(index_name, f.row_number().over(windowSpec))

    return df


def spark_searchsorted(
    spark: SparkSession,
    df_a: psd.DataFrame,
    col_name_a: str,
    df_v: psd.DataFrame,
    col_name_v: str,
    side: Literal["left", "right"] = "left",
):
    """
    Spark replication of the numpy.searchsorted function.

    NumPy description of searchsorted: Find indices where elements should
    be inserted to maintain order. Find the indices into a sorted array
    a such that, if the corresponding elements in v were inserted before
    the indices, the order of a would be preserved.

    Assuming that a is sorted:

        left: a[i-1] < v <= a[i]
        right: a[i-1] <= v < a[i]

    Args:
        spark (spark.Session): The spark session created when running the
            function on a spark dataframe.

        df_a (pyspark.DataFrame): DataFrame in combination with col_name1
            will represent argument 'a' in the np.searchsorted function,
            which is the input array.

        col_name_a (str): Column name in combination with df1 will
            represent argument 'a' in the np.searchsorted function, which
            is the input array

        df_v (pyspark.DataFrame): DataFrame in combination with col_name2
            will represent argument 'v' in the np.searchsorted function,
            which is the input array containing the values that need to be
            inserted into a. Note that it is possible that df1 and df2
            are the same dataframe.

        col_name_v (str): Column name in combination with df2 will
            represent argument 'v' in the np.searchsorted function, which
            is the input array containing the values that need to be
            inserted into a.

    Returns:
        df_out (pyspark.DataFrame): Input dataframe df_v containing an
            additional column (search_sort_col), consisting of the
            insertion points.

    Examples:

        Calculate results in Python like this::

            import numpy as np
            import pandas as pd
            from pyspark.sql import SparkSession
            from crv.utils.spark_helper import spark_searchsorted

            spark = SparkSession.builder.getOrCreate()

            d = np.random.normal(56, 8, 1500)
            n_d = np.random.normal(82, 11, 1500)
            df_pandas = pd.DataFrame({'d': d, 'n_d': n_d})

            df_spark = spark.createDataFrame(df_pandas)

            spark_searchsorted(
                spark = spark,
                df_a = df_spark,
                col_name_a = 'd',
                df_v = df_spark,
                col_name_v = 'n_d',
                side="left"
            ).show()

    """
    # Create broadcast variable
    data_a = df_a.select(col_name_a)
    data_a = (
        data_a.orderBy(col_name_a, ascending=[True])
        .withColumn("idx", f.monotonically_increasing_id())
        .select(col_name_a)
    )
    data_a = spark_create_index_col(data_a, order="asc", index_name="idx")

    index = spark.sparkContext.broadcast(data_a.collect())

    idx_max = int(data_a.count())

    # Implement binary search
    def nearest_value(value):
        # Input values
        value = float(value)
        last_value = float(index.value[0][col_name_a])
        max_value = float(index.value[-1][col_name_a])
        idx_ = int(0)

        # Search index
        for row in index.value:
            next_value = float(row[col_name_a])
            if side == "left":
                if last_value < value and value <= next_value:
                    idx_ = int(row["idx"])
                    break
                elif value > max_value:
                    idx_ = idx_max
                    break
            if side == "right":
                if last_value <= value and value < next_value:
                    idx_ = int(row["idx"] - 1)
                    break
                elif value >= max_value:
                    idx_ = idx_max
                    break
            last_value = next_value

        return int(idx_)

    # Create UDF
    nearest_value_udf = f.udf(nearest_value, IntegerType())

    # Use UDF
    df_out = df_v.withColumn("search_sort_col", nearest_value_udf(f.col(col_name_v)))
    return df_out
