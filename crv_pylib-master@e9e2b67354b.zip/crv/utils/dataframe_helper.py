"""
Utility functions for pandas DataFrames.

Notes:
    Author: N440730
"""

import pandas as pd


def rating_cats_list():
    """
    Function-container for the ordered list of Nordea credit ratings.
    """
    return [
        "6+",
        "6",
        "6-",
        "5+",
        "5",
        "5-",
        "4+",
        "4",
        "4-",
        "3+",
        "3",
        "3-",
        "2+",
        "2",
        "2-",
        "1+",
        "1",
        "1-",
        "0+",
        "0",
        "0-",
        "U",
    ]


def scoring_cats_list():
    """
    Function-container for the ordered list of Nordea credit scores.
    """
    return [
        "A+",
        "A",
        "A-",
        "B+",
        "B",
        "B-",
        "C+",
        "C",
        "C-",
        "D+",
        "D",
        "D-",
        "E+",
        "E",
        "E-",
        "F+",
        "F",
        "F-",
        "0+",
        "0",
        "0-",
        "U",
    ]


def pandas_rating_cats(
    df: pd.DataFrame, col: str, category_list: list = rating_cats_list()
) -> pd.DataFrame:
    """
    Creates ordered rating categories for rating columns.

    NOTE: Function operates on pandas.DataFrame object.
    Returns an updated pandas.DataFrame and updates a given column to
    categorical with ordered Nordea rating categories as default.
    Ordered from 6+ (best) to 0- (worst). If scoring categories
    ordered from A+ (best) to 0- (worst) are needed instead the
    category_list input can be updated. It can also take any
    custom list as categories input.
    See functions 'rating_cats_list()' and 'scoring_cats_list()'
    for more information.

    Args:
        df    (pandas.DataFrame): The data frame you want to update

        col   (string): The column you want to categorise

        category_list (list): List with ordered categories
                              (optional - defaults to rating categories)

    Returns:
        (pandas.DataFrame):     Returns the updated pandas.DataFrame

    Example:
        The module is called (from Python) like this::

            df = pandas_rating_cats(df, "rating_column_name")
            df = rating_cats(df, "scoring_column_name",
                             category_list = scoring_cats_list())
            df = rating_cats(df, "scoring_column_name",
                             category_list = ['A', 'B', 'C'])

    Notes:
        Author: N440730
    """
    cats_not_in_list = [cn for cn in df[col].unique() if cn not in category_list]
    category_list = category_list + cats_not_in_list
    df[col] = pd.Categorical(values=df[col], categories=category_list, ordered=True)
    return df


def rating_cats(
    df: pd.DataFrame, col: str, category_list: list = rating_cats_list()
) -> pd.DataFrame:
    """
    Creates ordered rating categories for rating columns.

    NOTE: Function is pseudo-overloaded to perform the same operation
    on the pandas.DataFrame object.
    Returns an updated DataFrame and updates a given column to
    categorical with ordered  rating categories as default.
    Ordered from 6+ (best) to 0- (worst). If scoring categories
    ordered from A+ (best) to 0- (worst) are needed instead the
    category_list input can be updated. It can also take any
    custom list as categories input.
    See functions 'rating_cats_list()' and 'scoring_cats_list()'
    for more information.

    UPDATE [2020-05-01]: dask functionality is being removed. This
     function will remain for the sake of not breaking the API, and
     to allow the possibility of overloading in the future.

    Args:
        df    (pd.DataFrame): The data frame you
                                                    want to update

        col   (string): The column you want to categorise

        category_list (list): List with ordered categories
                              (optional - defaults to rating categories)

    Returns:
        (pandas.DataFrame):   Returns the updated pandas.DataFrame

    Example:
        The module is called (from Python) like this::

            df = rating_cats(df, "rating_column_name")
            df = rating_cats(df, "scoring_column_name",
                             category_list = scoring_cats_list())
            df = rating_cats(df, "scoring_column_name",
                             category_list = ['A', 'B', 'C'])

    Notes:
        Author: G01679
    """
    if isinstance(df, pd.DataFrame):
        df = pandas_rating_cats(df, col, category_list=category_list)
    else:
        raise TypeError(
            "Argument 'df' must be of one of the following " "dtypes: pandas.DataFrame"
        )

    return df


def pandas_downcast_floats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Downcasts floats to save space.

    NOTE: Function operates on pandas.DataFrame object.
    Searches all the columns in the pandas.DataFrame.
    Downcast columns with dtype 'float' if possible.

    Args:
        df    (pandas.DataFrame): The data frame you want to update

    Returns:
        (pandas.DataFrame):     Returns the updated the pandas.DataFrame

    Example:
        The module is called (from Python) like this::

            df = pandas_downcast_floats(df)

    Notes:
        Author: N440730
    """
    df[df.select_dtypes(include=["float"]).columns] = df.select_dtypes(
        include=["float"]
    ).apply(pd.to_numeric, downcast="float")

    return df


def downcast_floats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Downcasts floats to save space.

    This is a wrapper function. This function calls pandas_downcast_floats if
    a pandas.DataFrame is passed, otherwise returns a error.

    Args:
        df  (pandas.DataFrame):     The DataFrame you want to update.

    Returns:
        (pandas.DataFrame):         The updated DataFrame.

    Example:
        The function is called (from Python) like this::

        df = downcast_floats(df)

    Notes:
        Author: G01679
    """
    if isinstance(df, pd.DataFrame):
        df = pandas_downcast_floats(df)
    else:
        raise TypeError("""Argument 'df' must be a pandas.DataFrame""")

    return df


def pandas_categorize(
    df: pd.DataFrame, force: bool = False, columns: list = None
) -> pd.DataFrame:
    """
    Change columns with object dtypes to category to save space.

    NOTE: Function returns an updated pandas.DataFrame object.
    If no list is provided to the 'columns' argument, the function will
    search the pandas.DataFrame for all columns with dtype 'object'
    and update those to dtype 'category' if the column has less than
    50% unique values, or the 'force' argument is set to 'True'. If a
    list of columns is provided, the function will convert those to
    dtype 'category' under the aforementioned logic.

    Args:
        df    (pandas.DataFrame):   The data frame you want to update

        force (boolean):            If you want to force categorization
                                    for all columns even if they have
                                    more than 50% unique values.
                                    Default False.

        columns (list):             Optional list of columns to
                                    categorize. Default is None and
                                    will consider all columns of the
                                    pandas.DataFrame that are of
                                    dtype 'object'.

    Returns:
        (pandas.DataFrame):     Returns the updated pandas.DataFrame

    Example:
        The module is called (from python) like this::

            df = pandas_categorize(df) or
            df = pandas_categorize(df, force=True)
            df = pandas_categorize(df, force=False, columns=['Column A',
                                                            'Column B'])

    Notes:
        Author: N440730
    """
    if isinstance(columns, type(None)):
        all_obj_cols = list(df.select_dtypes(include=["object"]).columns)
    else:
        all_obj_cols = columns

    for col in all_obj_cols:
        num_unique_values = len(df[col].unique())
        num_total_values = len(df[col])
        if force or num_unique_values / num_total_values < 0.5:
            df[col] = pd.Categorical(values=df[col])

    return df


def categorize(
    df: pd.DataFrame, force: bool = False, columns: list = None
) -> pd.DataFrame:
    """
    Change columns with object dtypes to category to save space.

    NOTE: Function is pseudo-overloaded to perform the same operation
    on both pandas.DataFrame and dask.DataFrame objects.
    If no list is provided to the 'columns' argument, the function will
    search the DataFrame for all columns with dtype 'object'
    and update those to dtype 'category' if the column has less than
    50% unique values, or the 'force' argument is set to 'True'. If a
    list of columns is provided, the function will convert those to
    dtype 'category' under the aforementioned logic.

    UPDATE [2020-05-01]: dask functionality is being removed. This
     function will remain for the sake of not breaking the API, and
     to allow the possibility of overloading in the future.

    Args:
        df (pandas.DataFrame): The data frame you want to update

        force (boolean): If you want to force categorization for all
         columns even if they have more than 50% unique values. Default False.

        columns (list): Optional list of columns to categorize. Default is None and
         will consider all columns of the pandas.DataFrame that are of
         dtype 'object'.

    Returns:
        (pandas.DataFrame): Returns the updated DataFrame

    Example:
        The module is called (from python) like this::

            df = categorize(df)
            df = categorize(df, force=True)
            df = categorize(df, force=False, columns=['Column A',
                                                      'Column B'])

    Notes:
        Author: G01679
    """
    if isinstance(df, pd.DataFrame):
        df = pandas_categorize(df, force, columns)
    else:
        raise TypeError(
            "Argument 'df' must be of one of the following " "dtypes: pandas.DataFrame"
        )

    return df
