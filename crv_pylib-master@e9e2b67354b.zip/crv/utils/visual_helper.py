"""
Utility functions for assisting the visualisation moudle.

Notes:
    Author: N440730, G01679
"""

import matplotlib
import pandas as pd
from typing import Tuple, Union
import numpy as np
import matplotlib.pyplot as plt
from math import ceil

from typing_extensions import Literal

# relevant imports here


def get_nordea_colour(c_string: str) -> str:
    """
    Returns the hexcode of the specified colour. Available Nordea colours
    are:
        'Accent Red'
        'Accent Yellow'
        'Accent Green'
        'Deep Blue'
        'Nordea Blue'
        'Vivid Blue'
        'Medium Blue'
        'Light Blue'
        'Dark Pink'
        'Nordea Pink'
        'Light Pink'
        'Dark Grey'
        'Nordea Grey'
        'Medium Grey'
        'Light Grey'
        'Medium Background'
        'Light Background'

    Args:
        c_string    (string):   A string from the above list

    Returns:
        (string):   The hexadecimal colour code for the chosen colour.

    Raises:
        KeyError: If an invalid colour string is passed.

    Warnings:
        None

    Examples:
        Call like this::

            colour = get_nordea_colour('Nordea Blue')

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # Nordea colours - master dictionary
    d_colour = {
        "Deep Blue": "#00005e",  # B5. Deep Blue
        "Nordea Blue": "#0000a0",  # B4. Nordea Blue
        "Vivid Blue": "#0000ff",  # B3. Vivid Blue
        "Medium Blue": "#3399ff",  # B2. Medium Blue
        "Light Blue": "#99ccff",  # B1. Light Blue
        "Dark Pink": "#f0c1ae",  # P3. Dark Pink
        "Nordea Pink": "#fbd9ca",  # P2. Nordea Pink
        "Light Pink": "#fdece4",  # P1. Light Pink
        "Dark Grey": "#474748",  # G4. Dark Grey
        "Nordea Grey": "#8b8a8d",  # G3. Nordea Grey
        "Medium Grey": "#c9c7c7",  # G2. Medium Grey
        "Light Grey": "#e6e4e3",  # G1. Light Grey
        "Medium Background": "#d1dde7",  # BG2. Medium Background
        "Light Background": "#e5f2ff",  # BG1. Light Background
        "Accent Red": "#fc6161",  # A1. Accent Red
        "Accent Yellow": "#ffe183",  # A2. Accent Yellow
        "Accent Green": "#40bfa3",  # A3. Accent Green
    }
    if c_string not in d_colour.keys():
        raise KeyError(
            f"'{c_string}' is not a valid Nordea color choice. "
            f"Colour must be chosen from: {list(d_colour.keys())}"
        )
    else:
        return d_colour[c_string]


def get_plotting_colours() -> list:
    """
    Returns a list of Nordea colours.

    Args:
         None.

    Return:
         (list): An list containing the required number of
         colours.

    Raises:
        None.

    Examples:
        Call function in Python like this::

            colours = get_plotting_colours()

    Warnings:
        None

    Notes:
        Author: Lee MacKenzie Fischer <G01679>

    """
    starter_c_strings = [
        "Nordea Blue",
        "Medium Blue",
        "Light Blue",
        "Nordea Pink",
        "Medium Grey",
        "Nordea Grey",
        "Dark Grey",
    ]
    starter_colours = [get_nordea_colour(cs) for cs in starter_c_strings]
    return starter_colours


def get_linestyles() -> list:
    """
    Returns an list of line styles.

    Args:
        None.

    Return:
        (list):  List of line styles.

    Raises:
        None.

    Examples:
        Call function in Python like this::

            ls = get_linestyles()

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    dashdot_spacing = 3
    line_seq = [
        (0, ()),  # solid
        (0, (5, 5)),  # dashed
        (0, (1, 1)),  # dotted
        (0, (3, dashdot_spacing, 1, dashdot_spacing)),  # dashdotted
        (
            0,
            (3, dashdot_spacing, 1, dashdot_spacing, 1, dashdot_spacing),
        ),  # dashdotdotted
        (0, (5, 10)),  # loosely dashed
        (0, (1, 10)),  # loosely dotted
        (0, (3, 10, 1, 10)),  # loosely dashdotted
        (0, (3, 10, 1, 10, 1, 10)),  # loosely dashdotdotted
        (0, (5, 1)),  # densely dashed
        (0, (1, 1)),  # densely dotted
        (0, (3, 1, 1, 1)),  # densely dashdotted
        (0, (3, 1, 1, 1, 1, 1)),  # densely dashdotdotted
    ]
    return line_seq


def get_line_styles() -> iter:
    """
    Returns an iterator of combinations of line colours and styles
    for plotting a large number of different series.

    Agrs:
        None.

    Return:
        (iterator):  list of tuples of colours and linestyles.

    Raises:
        None.

    Examples:
        Call from Python like this::

            cs_iter = get_line_styles()

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    colour_list = get_plotting_colours()
    style_list = get_linestyles()
    cs_list = []
    for s in style_list:
        for c in colour_list:
            cs_list.append((c, s))
    return iter(cs_list)


def get_scatter_styles() -> iter:
    """
    Returns an iterator of combinations of markers and colours
    for plotting a large number of different series.

    Agrs:
        None.

    Return:
        (iterator):  list of tuples of colours and marker styles.

    Raises:
        None.

    Examples:
        Call from Python like this::

            cm_iter = get_scatter_styles()

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    c_strings = [
        "Nordea Blue",
        "Medium Blue",
        "Light Blue",
        "Nordea Pink",
        "Medium Grey",
        "Nordea Grey",
        "Dark Grey",
    ]
    colour_list = [get_nordea_colour(ci) for ci in c_strings]
    marker_list = [
        "o",
        "v",
        "^",
        "<",
        ">",
        "8",
        "s",
        "p",
        "*",
        "h",
        "H",
        "D",
        "d",
        "P",
        "X",
    ]
    ms_list = []
    for m in marker_list:
        for c in colour_list:
            ms_list.append((c, m))
    return iter(ms_list)


def get_hatch_styles() -> iter:
    """
    Returns an iterator of combinations of hatch styles
    and colours for plotting a large number of different series.

    Agrs:
        None.

    Return:
        (iterator):  list of tuples of colours and marker styles.

    Raises:
        None.

    Examples:
        Call from Python like this::

            cm_iter = get_scatter_styles()

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    c_strings = [
        "Nordea Blue",
        "Medium Blue",
        "Light Blue",
        "Nordea Pink",
        "Medium Grey",
        "Nordea Grey",
        "Dark Grey",
    ]
    colour_list = [get_nordea_colour(ci) for ci in c_strings]
    hatch_list = ["", "//", r"\\", "xx", "++"]
    ms_list = []
    for h in hatch_list:
        for c in colour_list:
            ms_list.append((c, h))
    return iter(ms_list)


def get_xy_tick_format(
    x_format: Union[str, int, list], y_format: Union[str, int, list], num_plots: int
) -> list:
    """
    Returns a list of formatting options for a given number of axes.

    Args:
        x_format  (string, int, list):  How to format the values on the
        x-axis ticks. Default is 'default', which applies default
        matplotlib formatting. Options are 'percent' (for % formatting),
        'thousand' (for using a thousands separator), or provide an
        integer to specify the number of decimal places. Provide a list
        to set different formatting for each axis.

        y_format  (string, int, list):  How to format the values on the
        y-axis ticks. Default is 'default', which applies default
        matplotlib formatting. Options are 'percent' (for % formatting),
        'thousand' (for using a thousands separator), or provide an
        integer to specify the number of decimal places. Provide a list
        to set different formatting for each axis.

        num_plots  (int):  The number of subplots in the figure.

    Return:
        (list), (list): A list of the x-axis formatting and y-axis
        formatting options.

    Raises:
        ValueError:  If the list of x formatting options does not match
        the number of plots.

        ValueError:  If the list of y formatting options does not match
        the number of plots.

    Examples:
        Call function in Python like this::

            x_fmt, y_fmt = get_xy_tick_format(x_format, y_format,
            number_of_plots)

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>

    """
    if (
        (not isinstance(x_format, str))
        and (not isinstance(x_format, int))
        and (not isinstance(x_format, list))
    ):
        raise ValueError(
            f"Value passed to argument 'x_format' must " f"be of type: str, int, list"
        )
    if (
        not isinstance(y_format, str)
        and not isinstance(y_format, int)
        and not isinstance(y_format, list)
    ):
        raise ValueError(
            f"Value passed to argument 'y_format' must " f"be of type: str, int, list"
        )

    if isinstance(x_format, str) or isinstance(x_format, int):
        x_format = [x_format for a in range(num_plots)]
    elif len(x_format) != num_plots:
        raise ValueError(
            f"List of 'x_format' values must be of the "
            f"same length as the number of subplots. "
            f"Number of subplots = {num_plots}"
        )

    if isinstance(y_format, str) or isinstance(y_format, int):
        y_format = [y_format for a in range(num_plots)]
    elif len(y_format) != num_plots:
        raise ValueError(
            f"List of 'y_format' values must be of the "
            f"same length as the number of subplots. "
            f"Number of subplots = {num_plots}"
        )
    return x_format, y_format


def nordea_axis_formatter(
    ax: str,
    figsize: tuple,
    text_scale: float = 1.0,
    x_label: str = "",
    y_label: str = "",
    axis_title: str = "",
    x_format: Union[str, int] = "default",
    y_format: Union[str, int] = "default",
    y_scale: Literal["linear", "log", "symlog", "logit"] = "linear",
    gridlines_on: str = None,
    force_axis_zero: str = None,
    x_tick_rotation: float = 0,
    y_tick_rotation: float = 0,
    hide_axis_labels: str = None,
) -> None:
    """
    Applies formatting to an axis (subplot) using Nordea specified
    fonts and colors.

    Args:
        ax  (matplotlib.axes object):  The axis handle to format.

        figsize  (tuple):  Figure size, (width, height).

        text_scale  (float):  Scaling factor for all text in the figure.

        line_scale  (float):  Scaling factor for the lines in the figure.

        x_label  (string):  Label for x-axis.

        y_label  (string):  Label for y-axis.

        axis_title  (string):  Title for the individual subplot.

        x_format  (string or int):  How to format the values on the
        x-axis ticks. Default is 'default', which applies default
        matplotlib formatting. Options are 'percent' (for % formatting),
        'thousands' (for using a thousands separator), or provide an
        integer to specify the number of decimal places.

        y_format  (string or int):  How to format the values on the
        y-axis ticks. Default is 'default', which applies default
        matplotlib formatting. Options are 'percent' (for % formatting),
        'thousands' (for using a thousands separator), or provide an
        integer to specify the number of decimal places.

        y_scale  (string):  Plots the y-axis on a specified scale.
        Default is 'linear', options are 'log', 'symlog', 'logit'.

        gridlines_on  (string):  Shows gridlines of the axis specified
        in the string. Default is None (no gridlines), options are 'x',
        'y', 'both'.

        force_axis_zero  (string):  Forces the minimum of the specifed
        axis to be exactly zero. Default is None (no forcing), options
        are 'x', 'y', 'both'.

        x_tick_rotation  (float):  Rotation to apply to the tick labels
        of the x-axis.

        y_tick_rotation  (float):  Rotation to apply to the tick labels
        of the y-axis.

        hide_axis_labels  (string):  Hides the axis x- and/or y-axis
        label, or both. Accepted strings are 'x', 'y', or 'both'.
        Default (None) does not hide any axis labels.

    Return:
        None.

    Raises:
        ValueError: If invalid value is passed to 'gridlines_on'.

        ValueError: If invalid value is passed to 'force_axis_zero'.

    Examples:
        Call function in Python like this::

            nordea_axis_formatter(ax, figsize, text_scale=1.0,
                          x_label='', y_label='', axis_title='',
                          x_format='default', y_format='default',
                          y_scale='linear', gridlines_on=False,
                          force_axis_zero=None)

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # General option settings
    plot_dim = min(figsize)
    fontname = "Arial"
    size_deno = 10
    title_size = text_scale * (22 / size_deno) * plot_dim
    x_axis_label_size = text_scale * (20 / size_deno) * plot_dim
    y_axis_label_size = text_scale * (20 / size_deno) * plot_dim
    tick_label_size = text_scale * (16 / size_deno) * plot_dim
    axis_colour = get_nordea_colour("Deep Blue")
    title_colour = "black"
    background_colour = "white"
    # tick_size= (length, width); width also sets the axis linewidth
    tick_size = ((8 / size_deno) * plot_dim, (1.5 / size_deno) * plot_dim)
    highlight_colour = get_nordea_colour("Accent Yellow")

    # title options
    ax.set_title(
        label=axis_title,
        fontdict={"color": title_colour, "fontsize": title_size, "fontname": fontname},
    )

    # axis label options
    if hide_axis_labels in ["x", "both"]:
        ax.set_xlabel("")
    else:
        ax.set_xlabel(x_label)
        ax.xaxis.set_label_coords(0.5, -0.075)
        ax.xaxis.label.set_color(None)
        ax.xaxis.label.set_color(axis_colour)
        ax.xaxis.label.set_fontname(fontname)
        ax.xaxis.label.set_fontsize(x_axis_label_size)
        ax.tick_params(axis="x", labelrotation=x_tick_rotation)

    if hide_axis_labels in ["y", "both"]:
        ax.set_ylabel("")
    else:
        ax.set_ylabel(y_label)
        ax.yaxis.label.set_color(None)
        ax.yaxis.label.set_color(axis_colour)
        ax.yaxis.label.set_fontname(fontname)
        ax.yaxis.label.set_fontsize(y_axis_label_size)
        ax.tick_params(axis="y", labelrotation=y_tick_rotation)

    # axis tick options
    ax.tick_params(
        colors=axis_colour,
        length=tick_size[0],
        width=tick_size[1],
        labelsize=tick_label_size,
    )

    # y-axis formatting
    ax.set_yscale(y_scale)
    if y_format == "thousand":
        ax.get_yaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: f"{int(x):,}")
        )
    elif y_format == "percent":
        ylim = ax.get_ylim()
        y_range = ylim[1] - ylim[0]
        y_dec = abs(min(0, int(np.log10(y_range))))
        ax.get_yaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: "{0:.{1}%}".format(x, y_dec))
        )
    elif isinstance(y_format, int):
        ax.get_yaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: f"{x:,.{y_format}f}")
        )

    # x-axis formatting
    if x_format == "thousand":
        ax.get_xaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: f"{int(x):,}")
        )
    elif x_format == "percent":
        xlim = ax.get_xlim()
        x_range = xlim[1] - xlim[0]
        x_dec = abs(min(0, int(np.log10(x_range))))
        ax.get_xaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: "{0:.{1}%}".format(x, x_dec))
        )
    elif isinstance(x_format, int):
        ax.get_xaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: f"{x:,.{x_format}f}")
        )

    # gridlines
    if not isinstance(gridlines_on, type(None)):
        if gridlines_on == "both":
            ax.grid(
                color=get_nordea_colour("Nordea Grey"),
                linewidth=1,
                linestyle=":",
                alpha=0.8,
            )
        elif gridlines_on == "x":
            ax.xaxis.grid(
                color=get_nordea_colour("Nordea Grey"),
                linewidth=1,
                linestyle=":",
                alpha=0.8,
            )
        elif gridlines_on == "y":
            ax.yaxis.grid(
                color=get_nordea_colour("Nordea Grey"),
                linewidth=1,
                linestyle=":",
                alpha=0.8,
            )
        else:
            raise ValueError(
                "Invalid value passed to argument "
                "'gridlines_on'. Valid options are: "
                "'x', 'y', 'both'."
            )

    # forcing an axis to minimum zero
    if not isinstance(force_axis_zero, type(None)):
        if force_axis_zero == "both":
            ax.set_xlim(0, ax.get_xlim()[1])
            ax.set_ylim(0, ax.get_ylim()[1])
        elif force_axis_zero == "x":
            ax.set_xlim(0, ax.get_xlim()[1])
        elif force_axis_zero == "y":
            ax.set_ylim(0, ax.get_ylim()[1])
        else:
            raise ValueError(
                "Invalid value passed to argument "
                "'force_axis_zero'. Valid options are: "
                "'x', 'y', 'both'."
            )

    # axis lines options
    ax.spines["bottom"].set_color(axis_colour)
    ax.spines["left"].set_color(axis_colour)
    ax.spines["top"].set_color(None)
    ax.spines["right"].set_color(None)
    ax.spines["left"].set_linewidth(tick_size[1])
    ax.spines["bottom"].set_linewidth(tick_size[1])
    ax.margins(x=0)
    ax.set_facecolor(background_colour)
    return None


def vanish_axis(ax: str) -> None:
    """
    Makes an axis invisible. Useful for hiding an unused portion of
    a subplot figure.

    Args:
        ax  (matplotlib.axes object):  The axis handle to format.

    Return:
        None.

    Raises:
        None.

    Examples:
        Call function in Python like this::

            vanish_axis(ax)

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    ax.spines["bottom"].set_color(None)
    ax.spines["left"].set_color(None)
    ax.spines["top"].set_color(None)
    ax.spines["right"].set_color(None)
    ax.xaxis.label.set_color(None)
    ax.yaxis.label.set_color(None)
    plt.setp(ax.get_yticklabels(), visible=False)
    plt.setp(ax.get_xticklabels(), visible=False)
    plt.setp(ax.get_yticklines(), visible=False)
    plt.setp(ax.get_xticklines(), visible=False)
    return None


def get_subplot_dims(num_plots: int, subplot_layout: str) -> Tuple[int]:
    """
    Returns the subplot dimensions.

    Args:
        num_plots  (int):  The number of required subplots.

        subplots_layout  (string):  The layout in which to arrange the
        subplots. Options are 'square', 'tall', and 'wide'.

    Returns:
        (int, int):  The number of rows and the number of columns.

    Raises:
        ValueError: If the value passed to 'subplot_layout' is
        invalid.

    Examples:
        Call function from Python like this::

            n_rows, n_cols = get_subplot_dims(6, 'tall')

    Warnings:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    if subplot_layout == "square":
        num_rows = ceil(np.sqrt(num_plots))
        num_columns = num_rows
        num_subs = num_rows * num_columns
        if (num_subs - num_plots) >= num_columns:
            num_columns = num_columns - 1
    elif subplot_layout == "tall":
        num_rows = num_plots
        num_columns = 1
    elif subplot_layout == "wide":
        num_columns = num_plots
        num_rows = 1
    else:
        raise ValueError(
            "Value passed to argument 'subplot_layout' "
            "must be one of: 'square', 'tall', 'wide'"
        )
    return num_rows, num_columns


def build_plotting_dict(
    data: pd.DataFrame,
    x_col,
    y_cols=None,
    split_col=None,
    subplot_by=None,
    plot_type="line",
    order_split=None,
) -> dict:
    """
    Constructs the 'plotting_dict' for the plotting functions. This
    logic is standard for all plotting functions.

    Args:
        data  (pandas.DataFrame):  Data ready for plotting.

        x_col  (string):  Column name for x-axis variable.

        y_cols  (string or list): Column name(s) for y_axis, variables.

        split_col  (string):  Column name for grouping data series.

        subplot_by  (stirng):  How the figure will be split into
         subplots. Accepted values are 'split_col', 'y_cols'. Argument is
         ignored if 'split_col' is None.

        plot_type  (string):  Type of plot to provide styles.

        order_split (list): The explicit order in which to plot the
         values found in the 'split_col'. Default is to accept the order
         returned by pandas.Series.unique().

    Return:
        (dict):  The plotting dictionary.

    Raises:
        ValueError:  If 'split_col' is passed an invalid value.

        ValueError:  If 'split_col' is passed an invalid value.

    Examples:
        Call function in Python like this::

            plotting_d = build_plotting_dict(df, 'rating', ['PD, ADF'],
            'country', 'y_cols')

    Warnings:
        None

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    if plot_type == "line":
        style_iter = get_line_styles()  # create line style iterator
    elif plot_type == "scatter":
        style_iter = get_scatter_styles()  # create scatter style iterator
    elif plot_type in ["bar", "boxplot", "histogram"]:
        style_iter = get_hatch_styles()  # create hatch style iterator

    # begin dealing with different plotting arrangements
    if not isinstance(split_col, type(None)):
        # handle cases where the user passes a value to 'split_col'
        if order_split is not None:
            split_list = order_split.copy()
        else:
            split_list = list(data[split_col].unique())
        if subplot_by == "y_cols":
            # generate axis data for each y-column, color by split
            style_dict = {sc: style_iter.__next__() for sc in split_list}
            plotting_dict = {
                i: [
                    yc,
                    yc,
                    [
                        (
                            data[data[split_col] == sc][x_col],  # x data
                            data[data[split_col] == sc][yc],  # y data
                            sc,  # series label
                            style_dict[sc][0],  # series colour
                            style_dict[sc][1],
                        )  # series linestyle
                        for sc in split_list
                    ],
                ]
                for i, yc in enumerate(y_cols)
            }
        elif subplot_by == "split_col":
            # generate axis data for each unique group in split_col
            style_dict = {yc: style_iter.__next__() for yc in y_cols}
            plotting_dict = {
                i: [
                    sc,
                    ", ".join(y_cols),
                    [
                        (
                            data[data[split_col] == sc][x_col],  # x data
                            data[data[split_col] == sc][yc],  # y data
                            yc,  # series label
                            style_dict[yc][0],  # series colour
                            style_dict[yc][1],
                        )  # series linestyle
                        for yc in y_cols
                    ],
                ]
                for i, sc in enumerate(split_list)
            }
        else:
            raise ValueError(
                "If a column name is passed to 'split_col' "
                "the value passed to argument 'subplot_by' "
                "must be one of: 'y_cols', 'split_col'."
            )
    else:
        if isinstance(subplot_by, type(None)):
            # no split_col and subplot_by is None
            style_dict = {yc: style_iter.__next__() for yc in y_cols}
            plotting_dict = {
                i: [
                    sc,
                    ", ".join(y_cols),
                    [
                        (
                            data[x_col],  # x data
                            data[yc],  # y data
                            yc,  # series label
                            style_dict[yc][0],  # series colour
                            style_dict[yc][1],
                        )  # series linestyle
                        for yc in y_cols
                    ],
                ]
                for i, sc in enumerate([""])
            }
        elif subplot_by == "y_cols":
            # no split_col and generate axis data for each y-column
            split_list = [""]
            # how to handle styles for y_col subplot
            style_dict = {sc: style_iter.__next__() for sc in split_list}
            plotting_dict = {
                i: [
                    yc,
                    yc,
                    [
                        (
                            data[x_col],  # x data
                            data[yc],  # y data
                            sc,  # series label
                            style_dict[sc][0],  # series colour
                            style_dict[sc][1],
                        )  # series linestyle
                        for sc in split_list
                    ],
                ]
                for i, yc in enumerate(y_cols)
            }
        else:
            raise ValueError(
                "If no column name is passed to 'split_col', "
                "the value passed to argument 'subplot_by' "
                "must be one of: 'y_cols', None."
            )
    return plotting_dict


def setup_figure_axes(
    num_rows: int,
    num_columns: int,
    figsize: tuple,
    text_scale: float,
    sharex: bool,
    sharey: bool,
    plot_title: str,
):
    """
    Sets up the figure and creates the required number of subplots in
    the specified arrangement.
    Note: This function should be updated to grant more control over
    figure and axis placement.

    Args:
        num_rows  (int):  Number of rows of subplots to create.

        num_columns  (int):  Number of columns of subplots to create.

        figsize  (tuple):  Figure size in inches, (width, height).

        text_scale  (float):  Scaling factor for all text in the figure.

        sharex  (bool):  pyplot.figure option to share x-axis.

        sharey  (bool):  pyplot.figure option to share y-axis.

        share_ylim  (bool):  Scales all y-axes ranges to be the same.

        plot_title  (string):  Title for whole figure.

    Return:
        (matplotlib.figure), (list of matplotlib.axes):  The figure and
        list of axes that have been setup.

    Raises:
        None.

    Examples:
        Call function in Python like this::

            f, ax = setup_figure_axes(num_rows, num_columns,
            figsize, text_scale, sharex, sharey, plot_title)

    Warning:
         None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    plot_dim = min(figsize)
    # setup and format figure
    fig, axs = plt.subplots(
        nrows=num_rows, ncols=num_columns, figsize=figsize, sharex=sharex, sharey=sharey
    )
    fig_title_size = text_scale * (22 / 10) * plot_dim
    fig.suptitle(plot_title, fontsize=fig_title_size, fontweight="semibold")
    fig.patch.set_facecolor("white")
    # turn the figure axes into a linear list of axes
    axs = fig.get_axes()
    return fig, axs


def setup_legend(
    fig: matplotlib.figure,
    legend_dict: dict,
    figsize: tuple,
    text_scale: float,
    legend_title: str,
) -> matplotlib.legend:
    """
    Create, format, and return the figure legend.

    Args:
        fig  (matplotlib.figure object):  The handle to the figure
        object.

        legend_dict  (dict):  The dictionary containing all formatting
        for the common legend.

        figsize  (tuple):  Figure size in inches, (width, height).

        text_scale  (float):  Scaling factor for all text in the figure.

        legend_title  (string):  The for the figure legend.

    Return:
        (matplotlib.legend object):  The figure legend.

    Raises:
        None.

    Examples:
        Call function in Python like this::

            lgnd = setup_legend(fig, legend_dict, figsize,
            text_scale, legend_title)

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    # common legend setup and format
    plot_dim = min(figsize)
    legend_text_size = (16 / 10) * plot_dim
    legend_background_colour = get_nordea_colour("Light Background")
    legend_title_size = text_scale * (20 / 10) * plot_dim
    if len(legend_dict) > 1:
        lgd = fig.legend(
            legend_dict.values(),
            legend_dict.keys(),
            loc="lower center",
            bbox_to_anchor=(0.5, 0.0),
            ncol=10,
            fontsize=text_scale * legend_text_size,
            title_fontsize=text_scale * legend_title_size,
            title=legend_title,
            facecolor=legend_background_colour,
            edgecolor=get_nordea_colour("Deep Blue"),
        )
    else:
        lgd = None
    return lgd


def axis_cleanup(
    fig: matplotlib.figure,
    axs: list,
    share_ylim: bool,
    sharex: bool,
    last_axis_index: int,
    num_columns: int,
    text_scale: float,
    common_x_label: str = "",
    common_y_label: str = "",
) -> None:
    """
    Performs a final adjustment of the axes in the figure before
    displaying the figure, as well as common axis labels.

    Args:
        fig  (matplotlib.figure object): The figure handle.

        axs  (list of matplotlib.axes object):  List of the azxes
        objects in the figure.

        share_ylim  (bool):  Scales all y-axes ranges to be the same.

        sharex  (bool):  pyplot.figure option to share x-axis.

        last_axis_index  (int):  The index of the last axis in the
        figure that contains data. All axes after this will be
        rendered invisible.

        num_columns  (int):  Number of columns of subplots in the
        figure.

        text_scale  (float):  Scaling factor for all text in the figure.

        common_x_label  (string):  The common x-axis label to apply to
        the whole figure. Default is empty string, which does not
        apply a common x-axis label.

        common_y_label  (string):  The common y-axis label to apply to
        the whole figure. Default is empty string, which does not
        apply a common y-axis label.

    Return:
        None.

    Raises:
        None.

    Examples:
        Call function in Python like this::

            axis_cleanup(axs, share_ylim, sharex,
            last_axis_index, num_columns)

    Warning:
        None.

    Notes:
        Author: Lee MacKenzie Fischer <G01679>
    """
    figsize = fig.get_size_inches()
    plot_dim = min(figsize)
    axis_label_size = text_scale * (20 / 10) * plot_dim
    d_font = {"size": axis_label_size}

    # set all y-axis ranges to be the same
    if share_ylim:
        y_min = min([ax.get_ylim()[0] for ax in axs])
        y_max = max([ax.get_ylim()[1] for ax in axs])
        for axi in axs:
            axi.set_ylim((y_min, y_max))

    # handle x-axis labels in case of sharex
    if sharex:
        for ai in range(last_axis_index - num_columns + 1):
            axs[ai].set_xlabel(None)

    # make any remaining unused axes invisible
    while last_axis_index < len(axs) - 1:
        last_axis_index += 1
        vanish_axis(axs[last_axis_index])

    # apply common x and y labels, if provided
    if len(common_x_label) > 0:
        fig.text(0.5, 0.04, common_x_label, ha="center", fontdict=d_font)
    if len(common_y_label) > 0:
        fig.text(
            0.04, 0.5, common_y_label, va="center", rotation="vertical", fontdict=d_font
        )

    return None
