"""
Utility functions for perparing data with regard to validation tests.

Notes:
    Author: N440730, G01679
"""

from typing import Union
import pandas as pd
import pyspark.sql.functions as f
import pyspark.sql.dataframe as psd
from crv.utils import dataframe_helper


def set_defs(
    df: pd.DataFrame, expclasses: list, defaultcolumn: str, groupvar: str
) -> pd.DataFrame:
    """
    Creates a default flag column and sets it based on the rating.
    Default flag is set to '1' if the rating column cotains a '0',
    otherwise the default flag is a '0'.

    Args:
        df          (DataFrame):    Input DataFrame.

        expclasses  (list):         List of strings of the exposures
                                    to consider.

        defaultcolumn   (string):   Name to use for the default
                                    flag column.

        groupvar  (string):         The variable by which to group.

    Returns:
        (DataFrame):    The DataFrame updated with the new default
                        flag column.

    Raises:
        None

    Examples:
        Call function in Python like this::

            df = set_defs(df, ['I02', 'I03'], 'default', 'group')

    Warnings:
        None

    Notes:
        Author: Aron Moberg <N440730>

    """
    outdf = df[df["BA_1EXPCLO"].isin(expclasses)].copy()
    outdf[defaultcolumn] = 0
    # Series.where() must be used since dask doesn't support .loc assignment
    outdf[defaultcolumn] = outdf[defaultcolumn].where(
        ~outdf["rating"].str.contains("0"), 1
    )
    outdf = outdf.groupby(groupvar).agg({defaultcolumn: "max"})
    return outdf


def treat_PD_FIRB_data(obsdf: pd.DataFrame, perdf: pd.DataFrame) -> pd.DataFrame:
    """
    Prepares and arranges datasets for backtesting defaults.

    Adapted from the Credit_Risk_Validation repository:
    PD_FIRB / 2. Transform / 1_Validationdataset.sas

    Given the observation and performance data, this function cleans
    and groups the data into an ADF (Actual Default Frequency) table.

    Args:
        obsdf   (DataFrame):    The observation data.

        perdf   (DataFrame):    The performance data.

    Returns:
        (DataFrame):    The dataset

    Example:
        Call function in Python like this::

            pd_df = treat_pPD_FIRB_data(df)

    Warnings:
        None

    Notes:
        Author: Aron Moberg <N440730>

    """
    # Enforce that only pandas.DataFrames are used here.
    if (not isinstance(obsdf, pd.DataFrame)) or (not isinstance(perdf, pd.DataFrame)):
        raise TypeError(
            "Arguments 'obsdf' and 'perfdf' must both be of type pandas.DataFrame."
        )

    # Create mr_all from observation period data.
    # Only include non-default rating_group.
    mr_all = obsdf[~obsdf.rating_group.str.contains("0")]

    # Create default data
    defaults_I03 = set_defs(perdf, ["I02", "I03"], "default", "group")
    defaults_I04 = set_defs(perdf, ["I04"], "default", "group")
    if isinstance(mr_all, pd.DataFrame):
        defaults = pd.DataFrame()
        defaults["default"] = defaults_I03.default.combine_first(defaults_I04.default)
        defaults.index.name = "group"
        mr_all = mr_all.merge(defaults, how="left", on="group", validate="many_to_one")
    else:
        defaults = defaults_I03[["default"]].copy()
        defaults = defaults.combine_first(other=defaults_I04)
        mr_all = mr_all.merge(defaults, how="left", on="group")

    mr_all["default"] = mr_all["default"].fillna(0)

    mr_all2 = mr_all.drop(["rating"], axis=1).rename(
        columns={"rating_group": "rating", "bankkod": "country"}
    )
    mr_all2["country"] = mr_all2["country"].str.title()

    ratingdict = {
        "6+": 0.000300,
        "6": 0.000340,
        "6-": 0.000413,
        "5+": 0.000652,
        "5": 0.001019,
        "5-": 0.001505,
        "4+": 0.002596,
        "4": 0.003381,
        "4-": 0.005724,
        "3+": 0.008793,
        "3": 0.013940,
        "3-": 0.024615,
        "2+": 0.073184,
        "2": 0.084025,
        "2-": 0.097121,
        "1+": 0.147371,
        "1": 0.188898,
        "1-": 0.247010,
    }

    ratings = pd.DataFrame.from_dict(ratingdict, orient="index", columns=["PD"])
    ratings.index.rename("rating", inplace=True)

    if isinstance(mr_all2, pd.DataFrame):
        valdf = mr_all2.merge(ratings, how="left", on="rating", validate="many_to_one")
        valdf = dataframe_helper.rating_cats(valdf, "rating")
        valdf = valdf.sort_values(
            by=["group", "country", "rating"], ascending=[True, True, False]
        )
        valdf = valdf.groupby(["group", "country"]).head(1)
    else:
        valdf = mr_all2.merge(ratings, how="left", on="rating")

    return valdf


def _create_bins_labels(
    data: Union[pd.DataFrame, psd.DataFrame, pd.Series],
    bins: list,
    right: bool = False,
    pred_min: float = None,
    pred_max: float = None,
) -> tuple:
    """
    Creates the bins and labels that are used in the pandas.cut function to
    discretise sample data into bins.

    Args:
        data (pandas.DataFrame, pandas.Series, pyspark.sql.DataFrame): The
            dataframe containing the data to be discretised.

        bins (list): List with bins on which sample data
            will be discretised.

        right (boolean): (default=False) Indicates whether bins includes the
            rightmost edge or not. If right == True (the default), then the
            bins [1, 2, 3, 4] result in interval labels (1,2], (2,3], (3,4].

        pred_min (float): (default=None) Overwrites the minimum value that
            will otherwise be calculated from 'data'.

        pred_max (float): (default=None) Overwrites the maximum value that
            will otherwise be calculated from 'data'.

    Returns:
        bins (list): List with bins with which the sample data
            will be discretised. If the lowest value (e.g. estimated LGD) < smallest
            specified bin, an extra element will be added to the bins list
            equal to the lowest value (e.g. estimated LGD). If the highest value >
            largest given bin, an extra element will be added to the bins
            list equal to highest value.

        labels (list): Labels to be be used to index the output dataframe of
            the crv.validation.stability._pandas_group_population' function.

    Raises:
        ValueError - If 'data' is not a pandas.DataFrame, pandas.Series or
            pyspark.sql.DataFrame

        ValueError - If 'data' is a pandas.DataFrame or pyspark.sql.DataFrame
            but does not contain just one column

    Examples:
        Call function like this from Python::

            bins, labels = _create_bins_labels(data, bins)

    Notes:
        Author: Reinout Kool <G85538>
    """
    # If 'data' is not a pandas.DataFrame, pandas.Series or pyspark.sql.DataFrame
    if type(data) not in [pd.DataFrame, pd.Series, psd.DataFrame]:
        raise ValueError(
            "Input parameter 'data' must be of type "
            "pandas.DataFrame, pandas.Series or "
            "pyspark.sql.DataFrame"
        )

    # If 'data' is a pd.DataFrame or pyspark.sql.DataFrame but not contain just 1 column
    if not isinstance(data, pd.Series) and not len(data.columns) == 1:
        raise ValueError("Dataframe 'data' can only include one column")

    # If data is pyspark.sql.DataFrame
    if isinstance(data, psd.DataFrame):
        # Add zero bin boundary if lowest specified bin value is greater than 0
        if pred_min is None:
            pred_min = data.agg(f.min(data.columns[0])).collect()[0][0]
        add_bottom_bin = True if bins[0] > 0 else False
        if add_bottom_bin:
            bins = [0] + bins

        # Add upper bin boundary when largest value > largest specified bin value
        if pred_max is None:
            pred_max = data.agg(f.max(data.columns[0])).collect()[0][0]
        add_top_bin = True if bins[-1] < pred_max else False

        if right:
            bins = bins + [pred_max + 1] if add_top_bin else bins + [bins[-1] + 1]
            labels = list(pd.cut(bins, bins).categories)
            # Add negative values to bins (should not be included in labels
            # because labels are [0, i))
            bins[0] = pred_min - 1 if pred_min < 0 else bins[0]
        else:
            bins = bins + [pred_max + 1] if add_top_bin else bins + [bins[-1] + 1]
            labels = list(pd.cut(bins, bins, right=False).categories)
            # Add negative values to lower bin (should not be included in labels
            # because labels are [0, i))
            bins[0] = pred_min if pred_min < 0 else bins[0]

    # If data is pandas.DataFrame, pandas.Series
    elif isinstance(data, pd.DataFrame) or isinstance(data, pd.Series):
        # Add zero bin boundary if lowest specified bin value is greater than 0
        pred_min = data.min() if pred_min is None else pred_min
        add_bottom_bin = True if bins[0] > 0 else False
        if add_bottom_bin:
            bins = [0] + bins

        # Add upper bin boundary when largest value > largest specified bin value
        pred_max = data.max() if pred_max is None else pred_max
        add_top_bin = True if bins[-1] < pred_max else False

        if right:
            bins = bins + [pred_max] if add_top_bin else bins + [bins[-1] + 1]
            labels = list(pd.cut(data, bins).cat.categories)
            # Add negative values to lower bin (should not be included in labels
            # because labels are [0, i))
            bins[0] = pred_min - 1 if pred_min < 0 else bins[0]
        else:
            bins = bins + [pred_max + 1] if add_top_bin else bins + [bins[-1] + 1]
            labels = list(pd.cut(data, bins, right=False).cat.categories)
            # Add negative values to lower bin (should not be included in labels
            # because labels are [0, i))
            bins[0] = pred_min if pred_min < 0 else bins[0]

    return bins, labels
