# `crv.utils` module

## Functionality
Utility functions kept in a central location to assist with computations in other modules.

## Submodules
### `dataframe_helper.py`
Provides reading and commonly used numerical/categorical functions.

### `scoring_helper.py`
Translation dictionaries for rating grades and scores.

### `spark_helper.py`
Utility functions for converting and handling data using `pyspark`.

### `validation_helper.py`
Utility functions for preparing data with regard to validation tests.

### `visual_helper.py`
Utility functions for assisting the plotting and table export functions.
