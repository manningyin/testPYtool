"""
Experimental implementation of the Jeffreys test.

This script uses sample data to calculate the metrics from the 
Jeffreys test, as per section 2.5.3.1 "PD back-testing using a Jeffreys
test" from "Annex 2 - Instructions for reporting the validation results
of internal models".

Notes:
    Author: Lee MacKenzie Fischer <g01679>
"""

import saspy
import pandas as pd
import dask.dataframe as dd
from crv.io.sas import get_PD_FIRB_data
from crv.utils.dataframe_helper import categorize, rating_cats
from crv.utils.validation_helper import treat_PD_FIRB_data
from crv.utils.sas_helper import import_sas_to_string
from collections import Counter
from scipy.stats import beta

import dask
import time

"""
#perf_year = 2017

#get_years = [2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018]
get_years = [2008]
d_adf = {}

def adf_dict(yr):
    perf_year = yr
    obs_year = perf_year - 1
    df = get_PD_FIRB_data(perf_year=perf_year,
                          sas_server='vda1cs4756',
                          return_format='pandas')
    
    df_obs = df[df['CALMONTH']==str(obs_year)+'12'].copy()
    df_perf = df[df['CALMONTH']==str(perf_year)+'12'].copy()
    
    valdf = treat_PD_FIRB_data(df_obs, df_perf)
    
    adf = valdf.groupby(['rating', 'group']).agg({'default':'max',
                                                  'PD': 'median'}).reset_index(inplace=False)
    adf2 = adf.groupby(['rating']).agg({'group':'count',
                                        'default':'sum',
                                        'PD': 'median'}).reset_index(inplace=False)
    adf2 = adf2.rename(columns={'group': 'num_customers',
                                'default': 'num_defaults'}, inplace=False)
    adf2 = rating_cats(adf2, 'rating')
    adf2 = adf2.sort_values(by='rating', ascending=True, inplace=False)
    adf2['ADF'] = adf2['num_defaults'] / adf2['num_customers']
        
    return {str(yr): adf2}


start_time = time.time()
d_serial = []
for yr in [2008, 2009, 2010]:
    df = adf_dict(yr)
    d_serial.append(df)
print("Serial execuation of three years:", time.time() - start_time, " seconds")


start_time = time.time()
delayed_results = []
for yr in [2008, 2009, 2010]:
    ddf = dask.delayed(adf_dict)(yr)
    delayed_results.append(ddf)
d_parallel = dask.compute(*delayed_results)
print("Parallel execution of three years:", time.time() - start_time, " seconds")




# summarize
df_summary = d_adf['2009'].copy()
df_summary = df_summary.rename(columns={'ADF':'mean_adf'})
df_summary['num_customers'] = pd.DataFrame([d_adf[str(y)]['num_customers'] for y in get_years]).sum(axis=0)
df_summary['num_defaults'] = pd.DataFrame([d_adf[str(y)]['num_defaults'] for y in get_years]).sum(axis=0)
df_summary['mean_adf'] = pd.DataFrame([d_adf[str(y)]['ADF'] for y in get_years]).mean(axis=0)
df_summary['calc_adf'] = df_summary['num_defaults'] / df_summary['num_customers']

"""

incl_country = []
year_list = [2008, 2009]
# build the DataFrame dictionary using pandas
adf_dict = {}
adf_dict[2008] = (
    df2008[~df2008.rating.str.contains("0")].set_index("rating", inplace=False).copy()
)
adf_dict[2009] = (
    df2009[~df2009.rating.str.contains("0")].set_index("rating", inplace=False).copy()
)

# build the DataFrame dictionary using dask
# add some code here, maybe

# sum customers, defaults, average ADF
d_agg = {}
d_agg["total_customers"] = pd.DataFrame(
    [adf_dict[yr]["num_customers"] for yr in year_list]
).sum(axis=0)
d_agg["total_defaults"] = pd.DataFrame(
    [adf_dict[yr]["num_defaults"] for yr in year_list]
).sum(axis=0)
d_agg["mean_adf"] = pd.DataFrame([adf_dict[yr]["ADF"] for yr in year_list]).mean(axis=0)

# combine aggregation into a single DataFrame
adf_total = pd.DataFrame(d_agg)

adf_total = adf_total.reset_index(inplace=False)
