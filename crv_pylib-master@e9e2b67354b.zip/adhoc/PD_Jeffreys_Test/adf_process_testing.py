# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 16:44:31 2019

@author: N440730
"""


import dask.dataframe as dd
import pandas as pd
from crv.io.sas import get_sas_data, get_sascfg_filepath
from crv.utils.dataframe_helper import categorize, rating_cats
from crv.utils.validation_helper import treat_PD_FIRB_data
from crv.validation.quant_tests import build_adf_table, build_adf_summary, jeffreys_test

from collections import Counter
from scipy.stats import beta

# file and folder locations
data_folder = (
    "\\\\DCD02CB-EVS02\\ValidationTeam1\\Projects\\CRV_PYLIB\\test_data\\Jeffreys Test"
)
sasdata_2016 = "adf2016_final_improved"
sasdata_2017 = "adf2017_final_improved"

# df2016 = get_sas_data(get_sascfg_filepath(), 'vdd1cs2016', sasdata_2016, 'pandas', data_folder)
# df2017 = get_sas_data(get_sascfg_filepath(), 'vdd1cs2016', sasdata_2017, 'pandas', data_folder)

adf_sample = pd.read_excel(
    data_folder
    + "\\2016 Confidence interval methodologies - examples PD Corporate.xlsx",
    sheet_name="Jeff_sample",
)
adf_sample = adf_sample.drop(
    ["a", "b", "Upper conf limit", "Upper conf limit/PD"], axis=1
)

df_obs = df2016.copy()
df_perf = df2017.copy()

df_obs = df_obs.sample(frac=1).reset_index(drop=True)
df_perf = df_perf.sample(frac=1).reset_index(drop=True)

ddf_obs = dd.from_pandas(df_obs, npartitions=1)
ddf_perf = dd.from_pandas(df_perf, npartitions=1)

valdf = treat_PD_FIRB_data(df_obs, df_perf)
val_ddf = treat_PD_FIRB_data(ddf_obs, ddf_perf)
val_ddfc = val_ddf.compute()

d_names_wo_country = {
    "rating": "rating",
    "cid": "group",
    "default": "default",
    "pd": "PD",
}

d_names_incl_country = {
    "rating": "rating",
    "cid": "group",
    "default": "default",
    "pd": "PD",
    "country": "country",
}

adf = build_adf_table(valdf, d_names_wo_country)
a_ddf = build_adf_table(val_ddf, d_names_wo_country)


use_server = "vdd1cs2016"
"""
# =============================================================================
print("# 1. build_adf_table()")
print("## 1.a. from DataFrame")
print("### 1.a.i. without country")
adf_fromDf_wo_country = build_adf_table(df=valdf, d_colname=d_names_wo_country)

print("### 1.a.ii. including country")
adf_fromDf_incl_country = build_adf_table(df=valdf, d_colname=d_names_incl_country)

print("## 1.b. from servers")
print("### 1.b.i. without country")
adf_fromCRA_wo_country = build_adf_table(perf_year=2017,
                                         sas_server=use_server,
                                         by_country=False)

print("### 1.b.ii. including country")
adf_fromCRA_incl_country = build_adf_table(perf_year=2017,
                                           sas_server=use_server,
                                           by_country=True)

# =============================================================================
print("# 2. build_adf_summary()")
print("## 2.a. from DataFrame")
print("### 2.a.i. without country")
adf_summ_fromDf_wo_country = build_adf_summary([adf_sample, adf_sample, adf_sample, adf_sample],
                                               {'num_customers': 'Customers',
                                                'num_defaults': 'Number of defaults',
                                                'pd': 'PD',
                                                'adf': 'ADF avg incl MoC'})

print("### 2.a.ii. including country")
a_list = [adf_fromDf_incl_country for i in range(6)]
adf_summ_fromDf_incl_country = build_adf_summary(a_list,
                                                  {'num_customers': 'num_customers',
                                                   'num_defaults': 'num_defaults',
                                                   'pd': 'PD',
                                                   'adf': 'ADF'})

print("## 2.b. from servers")
print("### 2.b.i. without country serial")
y_list = [2017 for i in  range(6)]
adf_summ_fromCRA_wo_country_serial = build_adf_summary(year_list=y_list,
                                                       sas_server=use_server,
                                                       by_country=False,
                                                       multiproc=False)

print("### 2.b.ii. without country parallel")
adf_summ_fromCRA_wo_country_parallel = build_adf_summary(year_list=y_list,
                                                         sas_server=use_server,
                                                         by_country=False,
                                                         multiproc=True)

print("### 2.b.iii. with country serial")
adf_summ_fromCRA_incl_country_serial = build_adf_summary(year_list=y_list,
                                                         sas_server=use_server,
                                                         by_country=True,
                                                         multiproc=False)

print("### 2.b.iv. with country parallel")
adf_summ_fromCRA_incl_country_parallel = build_adf_summary(year_list=y_list,
                                                           sas_server=use_server,
                                                           by_country=True,
                                                           multiproc=True)

# =============================================================================
print("# 3. jeffreys_test()")
print("## 3.a. from DataFrame")
jt = jeffreys_test(adf_fromDf_wo_country, {'num_customers': 'num_customers',
                                           'num_defaults': 'num_defaults',
                                           'pd': 'PD'})
"""
