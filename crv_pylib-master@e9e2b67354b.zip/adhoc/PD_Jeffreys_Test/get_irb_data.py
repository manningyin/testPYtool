# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 16:44:31 2019

@author: N440730
"""


import pandas as pd
from crv.io.sas import get_sas_data, get_sascfg_filepath
from crv.utils.dataframe_helper import categorize, rating_cats
from collections import Counter
from scipy.stats import beta

# file and folder locations
data_folder = (
    "\\\\DCD02CB-EVS02\\ValidationTeam1\\Projects\\CRV_PYLIB\\test_data\\Jeffreys Test"
)
sasdata_2016 = "adf2016_final_improved"
sasdata_2017 = "adf2017_final_improved"

firb_cols = [
    "CALDAY",
    "CALMONTH",
    "FRNAPPRO",
    "FRNRWCON",
    "FGRC",
    "FGLFLG",
    "FSUBGRC",
    "FBP13CTRY",
    "BA_1BPART",
    "FBPARTM",
    "BA_1EAD",
    "BA_1EXPCLO",
    "BA_1ORGEXP",
    "BA_1PD",
    "FRATINGO",
    "FGRAD_MET",
    "FINDUSTRY",
    "FCRU",
    "FGRAD_MET",
    "FSMEEFLG",
    "COMP_CODE",
    "FRNAPPRO",
    "FGRC",
    "BA_1IOFLOW",
    "BA_1PDO",
]

exp_list = ["I02", "I03", "I04"]
exposure_list = ",".join([f"'{ix}'" for ix in exp_list])
# approach_list = ','.join(['03', '06'])
calmonth_list = ",".join(['"201612"', '"201712"'])
keep_list = " ".join(firb_cols)

print(calmonth_list)
print(exposure_list)

irb_load_code = f"""
libname SAPDDP meta library="SAPDDP";
data CADATA;
	set sapddp.ZACR_N_V(
		keep = {keep_list}

		where =(
		CALMONTH in ({calmonth_list}) and 
		BA_1EXPCLO in ({exposure_list}) and
		FRNAPPRO = 'N' and
		FGRC = '5000GROUP' and 
		FGLFLG = '1' and
		BA_1IOFLOW not in ('1','2')
		)
		);
        if calmonth = "201612" and BA_1EXPCLO = 'I04' then delete;
        
run;

data CADATA;
    length bankkod $10;
	set CADATA;
        if FSUBGRC = '1005GROUP' or FSUBGRC = '' or comp_code = 5501 then FSUBGRC = '1000GROUP';

    	if comp_code in (2001,2002,2003) then	bankkod = 'Sweden';
    	else if comp_code in (1007,2004,2007,2005,2008) then bankkod = 'IU';
    	else if comp_code = 5501 then bankkod = 'Russia';
    	else if FSUBGRC = '1000GROUP' then bankkod = 'Sweden';
    	else if FSUBGRC = '2000GROUP' then bankkod = 'Finland'; /* contains 99% of the finish customers */
    	else if FSUBGRC = '3000GROUP' then bankkod = 'Norway';
    	else if FSUBGRC = '4000GROUP' then bankkod = 'Denmark';
    
    	if bankkod = 'IU' and fsubgrc = '2000GROUP' then bankkod = 'Finland'; 
        else if bankkod = 'IU' then bankkod = 'Sweden'; 
run;
"""

"""
df = get_sas_data(sascfg_file=get_sascfg_filepath(),
                  sascfg_profile='vdd1cs2016',
                  table_name='CADATA',
                  return_format='pandas',
                  limit_obs=None,
                  autoexec=irb_load_code)

"""
df6 = df[df["CALMONTH"] == "201612"].copy()
print(df6.shape)

group_cols = [
    "CALMONTH",
    "CALDAY",
    "FGRC",
    "BA_1EXPCLO",
    "BA_1BPART",
    "FBPARTM",
    "bankkod",
    "FBP13CTRY",
    "FGLFLG",
    "FCRU",
    "FINDUSTRY",
    "FGRAD_MET",
    "BA_1PD",
    "FRATINGO",
    "FSMEEFLG",
]


def agg_pd(dfi, group_cols, agg_func):

    dd = dfi.groupby(group_cols).agg(agg_func).reset_index(inplace=False)
    return dd


# df6 = df6[df6['PD_ID'].isin(cust_2016)].copy()
# print(df6.shape)
gg16 = agg_pd(
    df6, group_cols, {"BA_1EAD": "sum", "BA_1ORGEXP": "sum", "BA_1PDO": "mean"}
)
print(gg16.shape)

gg16b = df6.groupby(group_cols)["BA_1EAD", "BA_1ORGEXP"].sum()
print(gg16b.shape)
