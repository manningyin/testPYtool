"""
Experimental implementation of the Jeffreys test.

This script uses sample data to calculate the metrics from the 
Jeffreys test, as per section 2.5.3.1 "PD back-testing using a Jeffreys
test" from "Annex 2 - Instructions for reporting the validation results
of internal models".

Notes:
    Author: Lee MacKenzie Fischer <g01679>
"""

import saspy
import pandas as pd
import dask.dataframe as dd
from crv.io.sas import get_sas_data, get_sascfg_filepath
from crv.utils.dataframe_helper import categorize, rating_cats
from crv.utils.validation_helper import (
    strip_rating_grades,
    set_default_flag,
    set_defs,
    treat_PD_FIRB_data,
)
from crv.utils.sas_helper import import_sas_to_string
from collections import Counter
from scipy.stats import beta


# perf_year = 2017

get_years = [2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018]
d_adf = {}

for yr in get_years:
    perf_year = yr
    obs_year = perf_year - 1

    # team library directory for PD_FIRB repo
    extract_dir = "\\\\DCD02CB-EVS02\\ValidationTeam1\\Projects\\CRV_PYLIB\\packages\\pd_firb\\1.Extract\\"

    # set libarary
    lib_code = 'libname SAPDDP meta library="SAPDDP";'
    # import SAS code from PD_FIRB library
    macro_code = import_sas_to_string(extract_dir + "1_Macro.sas")
    load_code = import_sas_to_string(
        extract_dir + "2_Loaddata.sas",
        replace_dict={
            "&validationyear.": str(obs_year),
            "&performanceyear.": str(perf_year),
        },
    )
    # customized 5_Uploaddata.sas, with concatenate into single table
    # for use with get_sas_data()
    upload_code = f"""
    /* save output datasets */
    data adf{obs_year}_final_improved (rename = (FBPARTM=group BA_1BPART=kundnrin bp1_partner_local=kundnrin_original));
    	    set CADATA_AGG3(where=(calmonth = "{obs_year}12"));
    	        if ratmodel eq 'TOA' and orgexp<2000000 and bankkod eq 'NDFI' then delete;
    run;
    
    data adf{perf_year}_final_improved (rename = (FBPARTM=group BA_1BPART=kundnrin bp1_partner_local=kundnrin_original));
    	    set CADATA_AGG3(where=(calmonth = "{perf_year}12"));
    run;
    
    /* Macro to aggregate rating and defaults to group level  */
    %group_rating(adf{obs_year}_final_improved);
    %group_rating(adf{perf_year}_final_improved);
    
    /* Concatenate both tables together, for easy Python import */
    proc append base=adf{obs_year}_final_improved data=adf{perf_year}_final_improved;
    run;
    """

    # combine SAS code before submitting
    submit_code = lib_code + macro_code + load_code + upload_code

    # make structured call to SAS
    df = get_sas_data(
        sascfg_file=get_sascfg_filepath(),
        sascfg_profile="vdd1cs2016",
        table_name=f"adf{obs_year}_final_improved",
        return_format="pandas",
        limit_obs=None,
        csv_path=None,
        autoexec=submit_code,
    )

    df_obs = df[df["CALMONTH"] == str(obs_year) + "12"].copy()
    df_perf = df[df["CALMONTH"] == str(perf_year) + "12"].copy()

    valdf = treat_PD_FIRB_data(df_obs, df_perf)

    adf = (
        valdf.groupby(["rating", "group"])
        .agg({"default": "max", "PD": "median"})
        .reset_index(inplace=False)
    )
    adf2 = (
        adf.groupby(["rating"])
        .agg({"group": "count", "default": "sum", "PD": "median"})
        .reset_index(inplace=False)
    )
    adf2 = adf2.rename(
        columns={"group": "num_customers", "default": "num_defaults"}, inplace=False
    )
    adf2 = rating_cats(adf2, "rating")
    adf2 = adf2.sort_values(by="rating", ascending=True, inplace=False)
    adf2["ADF"] = adf2["num_defaults"] / adf2["num_customers"]

    d_adf[str(yr)] = adf2


"""
# summarize
df_summary = d_adf['2009'].copy()
df_summary = df_summary.rename(columns={'ADF':'mean_adf'})
df_summary['num_customers'] = pd.DataFrame([d_adf[str(y)]['num_customers'] for y in get_years]).sum(axis=0)
df_summary['num_defaults'] = pd.DataFrame([d_adf[str(y)]['num_defaults'] for y in get_years]).sum(axis=0)
df_summary['mean_adf'] = pd.DataFrame([d_adf[str(y)]['ADF'] for y in get_years]).mean(axis=0)
df_summary['calc_adf'] = df_summary['num_defaults'] / df_summary['num_customers']


"""
