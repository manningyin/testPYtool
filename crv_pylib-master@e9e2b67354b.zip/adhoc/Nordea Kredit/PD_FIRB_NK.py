# ## Replication of the PD FIRB validation from the validation dataset
import pandas as pd
from adhoc.PD_FIRB import PD_FIRB_functions

# Set validation year (2015, 2016, or 2017):
year = input("Set validation year (2015, 2016, or 2017): ")
print(year)

# Specify path to the validation dataset
path = f"C:/Users/n440730/OneDrive - Nordea/Data/Validation/PD_FIRB/{year}/"
results = f"PD_FIRB_NK_{year}.xlsx"
nk_customers = (
    f"C:/Users/n440730/OneDrive - Nordea/Data/Validation/NK_customers/NK_{year}12.csv"
)

# import PD_FIRB_treat_data

obsdf = PD_FIRB_functions.get(path + "adfobs_final_improved.sas7bdat")
perdf = PD_FIRB_functions.get(path + "adfper_final_improved.sas7bdat")

print(obsdf.shape)
nkg_obs = pd.read_csv(nk_customers, squeeze=True)
obsdf = obsdf.loc[obsdf["group"].isin(nkg_obs), :]
print(obsdf.shape)

PD_FIRB_functions.treat_data(obsdf, perdf, results)
