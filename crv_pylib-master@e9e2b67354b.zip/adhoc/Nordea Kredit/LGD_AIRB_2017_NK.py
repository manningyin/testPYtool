import pandas as pd
from adhoc.LGD_AIRB import LGD_AIRB_functions as lgd_funcs

root = "\\\\VDA1cs4756\\LGD_CCF_MODELS\\5. LGD and CCF Models\\2017 Estimation"
path = "\\2. Output\\Corporate\\201801 for validation\\03. LGD Estimation\\"
estpath = "\\1. Input\\Corporate\\Estimates\\2017\\"
results = "LGD_AIRB_NK_2017.xlsx"
nk_customers = (
    "C:/Users/n440730/OneDrive - Nordea/Data/Validation/NK_customers/NK_tot.csv"
)

lgd, estimates, estresults = lgd_funcs.get_data(
    root + path + "_lgd_17v04_val.sas7bdat",
    root + estpath + "outgoing_lgd_2017.sas7bdat",
    root + path + "LGD_RESULTS_17V04_VAL.sas7bdat",
)

# Inner merge the lgd dataset with NK customers
nk_custs = pd.read_csv(nk_customers, sep=";")
nk_custs.rename(
    columns={"CALMONTH": "data_period", "BA_1BPART": "customerid"}, inplace=True
)

lgd = lgd.merge(nk_custs, on=["data_period", "customerid"])

lgd_funcs.treat_data(lgd, estimates, estresults, results)
