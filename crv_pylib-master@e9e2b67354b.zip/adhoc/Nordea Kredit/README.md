#### Analysis of Nordea Kredit customers for
* PD Corp
* LGD Corp
* PD RIRB
* LGD RIRB

Nordea Kredit customers have been extracted from CAD and the validation datasets have then been filtered to include only customers matching this extract. Below is the code for LGD Corp.
Before running this analysis, extract that data using the sas-files and place it in the Data/XXX folders.

```
proc sql;
	create table NK_tot as
	select distinct calmonth, BA_1BPART
	from sapddp.zacr_n_v
	where calmonth > '1'
	and BA_1EXPCLO in ('I03','I02','I04')
	and comp_code = '4026'
	order by calmonth, BA_1BPART
	;
quit;

```
