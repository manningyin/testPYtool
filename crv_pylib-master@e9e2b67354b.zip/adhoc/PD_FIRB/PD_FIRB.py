#!/usr/bin/env python
# coding: utf-8

# ## Replication of the PD FIRB validation from the validation dataset
import PD_FIRB_functions

# Set validation year (2015, 2016, or 2017):
year = input("Set validation year (2015, 2016, or 2017): ")
print(year)

# Specify path to the validation dataset
path = f"C:/Users/g01679/Nordea/Moberg, Aron - Data/Validation/PD_FIRB/{year}/"
results = f"PD_corp_{year}.xlsx"

# import PD_FIRB_treat_data

obsdf = PD_FIRB_functions.get(path + "adfobs_final_improved.sas7bdat")
perdf = PD_FIRB_functions.get(path + "adfper_final_improved.sas7bdat")

PD_FIRB_functions.treat_data(obsdf, perdf, results)
