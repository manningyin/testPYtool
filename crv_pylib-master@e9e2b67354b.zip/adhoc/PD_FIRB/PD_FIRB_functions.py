########### READ DATA #########################################################
import pandas as pd
from crv.utils import dataframe_helper


def get(file):

    outdf = pd.read_sas(file, encoding="iso-8859-1")

    # Lower memsize by converting objects to categorical variables
    # and downcatsting floats:

    # Change the dtype of rating and rating_group to ordered rating categories
    dataframe_helper.rating_cats(outdf, "rating")
    dataframe_helper.rating_cats(outdf, "rating_group")

    # #### Downcast floats from float64 to float32
    dataframe_helper.downcast_floats(outdf)

    # Change variables that have less than 50% unique values to categorical
    dataframe_helper.categorize(outdf)

    return outdf


def set_defs(df, expclasses, defaultcolumn, groupvar):
    outdf = pd.DataFrame(df[df["BA_1EXPCLO"].isin(expclasses)])
    outdf.loc[outdf.rating.str.contains("0"), defaultcolumn] = 1
    outdf.loc[~outdf.rating.str.contains("0"), defaultcolumn] = 0
    outdf = pd.DataFrame(outdf.groupby(groupvar)[defaultcolumn].max())
    return outdf


########## TREAT DATA #########################################################


def treat_data(obsdf, perdf, results):
    # Create mr_all from observation period data.
    # Only include non-default rating_group.
    mr_all = obsdf[~obsdf.rating_group.str.contains("0")]

    # Create default data
    defaults_I03 = set_defs(perdf, ["I02", "I03"], "default", "group")
    defaults_I04 = set_defs(perdf, ["I04"], "default", "group")
    defaults = pd.DataFrame()
    defaults["default"] = defaults_I03.default.combine_first(defaults_I04.default)

    mr_all = mr_all.merge(defaults, how="left", on="group", validate="many_to_one")

    mr_all["default"] = mr_all["default"].fillna(0)

    mr_all2 = mr_all.drop(["rating"], axis=1).rename(
        columns={"rating_group": "rating", "bankkod": "country"}
    )
    mr_all2["country"] = mr_all2["country"].str.title()
    mr_all2_group = mr_all2.copy()
    mr_all2_group["country"] = "Nordea Group"
    mr_all2 = mr_all2.append(mr_all2_group)

    test = pd.DataFrame(mr_all2.groupby("group")["default"].mean())
    print("TEST: Should be empty")
    print(test[~test["default"].isin([0, 1])])
    print("END TEST")

    mr_all3 = mr_all2.sort_values(
        by=["group", "country", "rating"], ascending=[True, True, False]
    )

    mr_all = mr_all3.groupby(["group", "country"]).head(1)

    ratingdict = {
        "6+": 0.000300,
        "6": 0.000340,
        "6-": 0.000413,
        "5+": 0.000652,
        "5": 0.001019,
        "5-": 0.001505,
        "4+": 0.002596,
        "4": 0.003381,
        "4-": 0.005724,
        "3+": 0.008793,
        "3": 0.013940,
        "3-": 0.024615,
        "2+": 0.073184,
        "2": 0.084025,
        "2-": 0.097121,
        "1+": 0.147371,
        "1": 0.188898,
        "1-": 0.247010,
    }

    ratings = pd.DataFrame.from_dict(ratingdict, orient="index", columns=["PD"])
    ratings.index.rename("rating", inplace=True)

    valdf = mr_all.merge(ratings, how="left", on="rating", validate="many_to_one")
    dataframe_helper.rating_cats(valdf, "rating")

    adf_rg_means = valdf.groupby(["country", "rating"])["PD", "default"].mean()
    adf_rg_means.rename(columns={"default": "ADF"}, inplace=True)
    adf_rg_defs = valdf.groupby(["country", "rating"])["default"].agg(["count", "sum"])
    adf_rg_defs.rename(columns={"count": "obs", "sum": "defaults"}, inplace=True)
    adf_rg = adf_rg_means.join(adf_rg_defs)
    adf_rg_group = adf_rg.loc[("Nordea Group", slice("6+", "1-")), :].copy()
    adf_rg_group["obs"] = adf_rg_group["obs"].astype("uint")
    adf_rg_group["defaults"] = adf_rg_group["defaults"].astype("uint")

    adf_rg_group[["PD", "ADF"]].plot()
    # adf_rg_group['obs'].plot()

    adf_means = valdf.groupby("country")["PD", "default"].mean()
    adf_means.rename(columns={"default": "ADF"}, inplace=True)
    adf_defs = valdf.groupby("country")["default"].agg(["count", "sum"])
    adf_defs.rename(columns={"count": "obs", "sum": "defaults"}, inplace=True)
    adf_defs["defaults"] = adf_defs["defaults"].astype("uint")
    adf = adf_means.join(adf_defs)

    adf.round(decimals=5)

    writer = pd.ExcelWriter(results)
    adf.to_excel(writer, "country")
    adf_rg_group.to_excel(writer, "ratings_group")
    writer.save()


###############################################################################
