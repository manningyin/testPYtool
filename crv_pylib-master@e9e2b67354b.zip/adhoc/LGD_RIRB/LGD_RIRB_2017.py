import LGD_RIRB_functions as lgd_funcs

root = "\\\\VDA1cs4756\\LGD_CCF_MODELS\\5. LGD and CCF Models\\2017 Estimation"
path = "\\2. Output\Retail\\2017_v45\\"
estpath = "\\1. Input\\Retail\\2017\\Estimates\\"
results = "LGD_RIRB_2017.xlsx"

lgd, estimates, estresults = lgd_funcs.get_data(
    root + path + "lgd_v45.sas7bdat",
    root + estpath + "lgd_estimates_mb.sas7bdat",
    root + path + "data_overview_dk_lgd.sas7bdat",
)

lgd_funcs.treat_data(lgd, estimates, estresults, results)
