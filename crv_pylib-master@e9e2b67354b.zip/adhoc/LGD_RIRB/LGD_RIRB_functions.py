import pandas as pd


def get_data(lgdfile, estimatesfile, estresultsfile):
    """
    Return lgddata, estimates, and estresults for comparison.

    Input paths to the files:
        lgdfile
        estimatesfile
        estresultsfile
    """
    estresults = pd.read_sas(estresultsfile, encoding="iso-8859-1")

    estresults = estresults.loc[estresults.E235 == "DK", slice(None)]
    estresults.rename(
        columns={
            "lgd_est": "lgd_est_chk",
            "lgd": "lgd_chk",
            "lgd_sm": "lgd_sm_chk",
            "lgd_dt": "lgd_dt_chk",
            "riskfree_rate": "riskfree_rate_chk",
            "discount_rate": "discount_rate_chk",
            "obs": "obs_chk",
            "num_cured": "num_cured_chk",
            "cure_rate": "cure_rate_chk",
            "std_lgd": "std_lgd_chk",
            "EAD": "EAD_chk",
        },
        inplace=True,
    )

    estimates = pd.read_sas(estimatesfile, encoding="iso-8859-1")
    estimates = estimates.loc[estimates.E235 == "DK", slice("E235", "Estimate")]
    estimates.rename(
        columns={"Segment": "customer_type_ad", "Pool": "lgd_pool"}, inplace=True
    )

    lgd = pd.read_sas(lgdfile, encoding="iso-8859-1")

    return lgd, estimates, estresults


def treat_data(lgd, estimates, estresults, results):
    """
    Create a results file with the general output and comparison to SAS
    estimation. Input lgd data, estimates, SAS validation estresults,
    and the results excel file.
    """

    tables1 = lgd.copy()
    tables1 = tables1.loc[(tables1.E235 == "DK") & (tables1.nff_flag == "0"), :]
    tables1.dropna(subset=["nom_loss"], inplace=True)

    tables2 = tables1.merge(estimates, on=["E235", "customer_type_ad", "lgd_pool"])

    tables2 = tables2[tables2.extreme == 0]

    groupvars = ["customer_type_ad", "Secured", "E235", "nff_flag", "lgd_pool"]

    lgd_means = tables2.groupby(groupvars)[
        "Estimate",
        "nom_loss",
        "nom_loss_sm",
        "lgd_dt",
        "riskfree_rate",
        "discount_rate",
        "cured_in_workout",
    ].mean()

    lgd_means.rename(
        columns={
            "Estimate": "lgd_est",
            "nom_loss": "lgd",
            "nom_loss_sm": "lgd_sm",
            "cured_in_workout": "cure_rate",
        },
        inplace=True,
    )

    lgd_obs = tables2.groupby(groupvars).lgd_pool.count()
    lgd_obs.name = "obs"

    lgd_cured = tables2.groupby(groupvars).cured_in_workout.sum()
    lgd_cured.name = "num_cured"

    lgd_std = tables2.groupby(groupvars).nom_loss.std()
    lgd_std.name = "std_lgd"

    lgd_ead = tables2.groupby(groupvars).ead.sum() / 1000000
    lgd_ead.name = "EAD"

    data_overview = lgd_means.copy()

    data_overview["obs"] = lgd_obs
    data_overview["num_cured"] = lgd_cured
    data_overview["std_lgd"] = lgd_std
    data_overview["EAD"] = lgd_ead

    test = data_overview.merge(estresults, on=groupvars)

    for col in test.loc[:, slice("lgd_est", "EAD")].columns:
        test[col + "_test"] = test[col] - test[col + "_chk"]

    writer = pd.ExcelWriter(results)
    data_overview.to_excel(writer, "data_overview")
    test.to_excel(writer, "diff")
    writer.save()
