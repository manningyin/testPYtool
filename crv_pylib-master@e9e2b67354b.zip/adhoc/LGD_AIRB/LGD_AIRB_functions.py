import pandas as pd


def get_data(lgdfile, estimatesfile, estresultsfile):
    """
    Return lgddata, estimates, and estresults for comparison.

    Input paths to the files:
        lgdfile
        estimatesfile
        estresultsfile
    """
    estresults = pd.read_sas(estresultsfile, encoding="iso-8859-1")
    estresults.rename(
        columns={
            "LGD_estimate": "LGD_estimate_chk",
            "_FREQ_": "obs_chk",
            "NomLoss": "NomLoss_chk",
            "NomLossObsC2": "NomLossObsC2_chk",
            "LGD": "LGD_chk",
        },
        inplace=True,
    )

    estimates = pd.read_sas(estimatesfile, encoding="iso-8859-1")

    lgd = pd.read_sas(lgdfile, encoding="iso-8859-1")

    return lgd, estimates, estresults


def treat_data(lgd, estimates, estresults, results):
    """
    Create a results file with the general output and comparison to SAS
    estimation. Input lgd data, estimates, SAS validation estresults,
    and the results excel file.
    """
    lgd = lgd[pd.isna(lgd.deletereason)].copy()
    lgd["EAD_Meur"] = lgd["EAD_EUR"] / 1000000
    lgd["LGD_nominal"] = lgd["NomLossObsC2"]
    lgd.loc[lgd.secured == 0, "sec_unsec"] = "Unsecured"
    lgd.loc[lgd.secured == 1, "sec_unsec"] = "Secured"
    lgd.sec_unsec = lgd.sec_unsec.fillna("ERROR")

    lgd = lgd.merge(estimates, on="LGD_POOL", how="left")

    lgd.loc[
        ~lgd.countryofbooking.isin(["SE", "DK", "FI", "NO"]), "countryofbooking"
    ] = "IU"

    lgd.groupby(["countryofbooking"]).count()

    groupvars = ["sec_unsec", "Pool_name", "lgd_estimate"]

    means = lgd.groupby(groupvars)[
        "deletereason", "NomLoss", "LGD_nominal", "LGD_dt", "LGD"
    ].mean()

    obs = lgd.groupby(groupvars)["LGD"].count()

    means["obs"] = obs

    test = means.reset_index().merge(estresults, on=["Pool_name"])
    test = test.set_index(groupvars)

    test["Test_obs"] = test["obs"] - test["obs_chk"]
    test["Test_NL"] = test["NomLoss"] - test["NomLoss_chk"]
    test["Test_LGDnom"] = test["LGD_nominal"] - test["NomLossObsC2_chk"]
    test["Test_LGD"] = test["LGD"] - test["LGD_chk"]

    writer = pd.ExcelWriter(results)
    means.to_excel(writer, "means")
    test.to_excel(writer, "diff")
    writer.save()
