# `adhoc`
This is the place for functions and scripts that have not gone through the proper channel of specification, unit testsing, and review to belong to the library proper. This is an uncontrolled environment without quality. Use at own risk.
