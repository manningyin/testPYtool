import numpy as np
import pandas as pd
import scipy as scipy
from matplotlib import pyplot as plt
from crv.validation.differentiation import loss_capture_ratio
from crv.io.exceltables import df2excel


def _pandas_powerstats(
    df,
    obs_col,
    pred_col,
    ead_col,
    lgd_target,
    ead_weighted=False,
    method="crmv",
    ead_population=False,
):
    """
    Powerstats (ie. Loss Capture Ratio or accuracy ratio), pandas implementation.

    Args:
        df (pandas.DataFrame): The input data table containing the EAD and
         observed and predicted LGD at account level.

        ead_col (str): The name of the column containing the EAD values.

        obs_col (str): The name of the column containing the values
         for the observed (realised) LGD values.

        pred_col (str): The name of the column containing the values
         for the predicted (estimated) LGD values.

        ead_weighted (boolean): If True the actual and predicted values are EAD
        weighted ie. the loss amount instead of percentage.
        [May be better to control this by the columns containing the observed
        and predicted values (obs_col and pred_col)]

        method (str): crmv - Model's capture curve is identified by ordering observed values and deriving the cumulative predicted values
                      rimo - Model's capture curve is identified by ordering predicted values and deriving the cumulative observed values

        ead_population (boolean): Acummulate EAD instead of number of observations on x-axis.

    Returns:
        (dict): A dictionary containing the results:
            'Predicted AUC' - The AUC from the LGD estimates from the model data.
            'Perfect AUC' - The AUC from the observed LGD as a perfect model.
            'LCR' - The loss capture ratio from the calculation.
            'data' - A pandas.DataFrame containing the data for plotting the
             model data.

    Raises:
        ValueError - if input to argument 'df' is not a pandas.DataFrame.

        ValueError - if input to argument 'df' is empty.

        ValueError - if the column names for 'ead_col', 'obs_lgd_col', or
         'pred_lgd_col' are not found in the input DataFrame.

    Notes:
        Author: Frederik Secher (G85537)
    """
    # Error checks.
    if not isinstance(df, pd.DataFrame):
        raise ValueError(
            f"Input to argument 'df' must be a pandas.DataFrame, not {type(df)}."
        )
    if df.empty:
        raise ValueError("Input to argument 'df' must not be empty.")
    if not {ead_col, obs_col, pred_col}.issubset(df.columns):
        raise ValueError(
            "One or more of the required columns were not found "
            f"in the input DataFrame: {ead_col}, {obs_col}, {pred_col}"
        )

    # Setup DataFrames.
    if lgd_target == True:
        df_obs = df[[ead_col, obs_col]].copy()
        df_pred = df[[ead_col, obs_col, pred_col]].copy()
    else:
        df_obs = df[[obs_col]].copy()
        df_pred = df[[obs_col, pred_col]].copy()

    # 1. Calculate observed loss = observed LGD * EAD.
    if ead_weighted == True & lgd_target == True:
        df_obs["obs_loss_amount"] = df_obs[ead_col] * df_obs[obs_col]
        df_pred["obs_loss_amount"] = df_pred[ead_col] * df_pred[obs_col]
        df_pred["pred_loss_amount"] = df_pred[ead_col] * df_pred[pred_col]
    else:
        df_obs["obs_loss_amount"] = df_obs[obs_col]
        df_pred["obs_loss_amount"] = df_pred[obs_col]
        df_pred["pred_loss_amount"] = df_pred[pred_col]

    # 2. Sort values.
    df_obs = df_obs.sort_values(by=["obs_loss_amount"], ascending=[False])
    if method == "rimo":
        df_pred = df_pred.sort_values(by=["obs_loss_amount"], ascending=[False])
    else:
        df_pred = df_pred.sort_values(by=["pred_loss_amount"], ascending=[False])

    # 3. Cumulate observed loss.
    # 4. Calculate accumulated observed LGD/EAD percentage.
    df_obs["accum_obs_"] = df_obs["obs_loss_amount"].cumsum()
    df_obs["perc_accum_obs_"] = df_obs["accum_obs_"] / df_obs["accum_obs_"].max()
    if method == "rimo":
        df_pred["accum_obs_"] = df_pred["pred_loss_amount"].cumsum()
    else:
        df_pred["accum_obs_"] = df_pred["obs_loss_amount"].cumsum()
    df_pred["perc_accum_obs_"] = df_pred["accum_obs_"] / df_pred["accum_obs_"].max()

    # 5. Cumulate EAD.
    # 6. Calculate accumulated number of defaults percentage.
    if ead_population == False:
        df_obs["accum_pop"] = np.arange(len(df_obs)) + 1
        df_pred["accum_pop"] = np.arange(len(df_pred)) + 1
    else:
        df_obs["accum_pop"] = df_obs[ead_col].cumsum()
        df_pred["accum_pop"] = df_pred[ead_col].cumsum()
    df_obs["perc_accum_pop"] = df_obs["accum_pop"] / df_obs["accum_pop"].max()
    df_pred["perc_accum_pop"] = df_pred["accum_pop"] / df_pred["accum_pop"].max()

    # 7. Calculate AUC.
    perfect_model_auc = (
        np.trapz(df_obs["perc_accum_obs_"], x=df_obs["perc_accum_pop"]) - 0.5
    )
    pred_model_auc = (
        np.trapz(df_pred["perc_accum_obs_"], x=df_pred["perc_accum_pop"]) - 0.5
    )
    print(perfect_model_auc, pred_model_auc)
    print(df_obs[["perc_accum_obs_", "perc_accum_pop"]])
    print(df_pred[["perc_accum_obs_", "perc_accum_pop"]])
    print(df_pred)
    df_pred.to_clipboard()
    # 8. Compute LCR.
    lcr = pred_model_auc / perfect_model_auc

    # Append a [0, 0] to the beginning of each DataFrame for plotting purposes,
    # since it may not actually exist in the real data.
    df_obs = pd.concat(
        [
            pd.DataFrame.from_dict({"perc_accum_pop": [0], "perc_accum_obs_": [0]}),
            df_obs,
        ],
        sort=False,
    )
    df_pred = pd.concat(
        [
            pd.DataFrame.from_dict({"perc_accum_pop": [0], "perc_accum_obs_": [0]}),
            df_pred,
        ],
        sort=False,
    )

    # Collect plotting data into pandas.DataFrame.
    df_obs = df_obs.rename(
        columns={
            "perc_accum_pop": "Percent Accumulated Population",
            "perc_accum_obs_": "Perfect Model",
        }
    )
    df_pred = df_pred.rename(
        columns={
            "perc_accum_pop": "Percent Accumulated Population",
            "perc_accum_obs_": "Current Model",
        }
    )
    df_random = pd.DataFrame.from_dict(
        {"Percent Accumulated Population": [0, 1], "Random Model": [0, 1]}
    )
    df_plotting = pd.concat(
        objs=[df_obs, df_pred, df_random],
        axis=0,
        join="outer",
        ignore_index=True,
        sort=False,
    )

    return {
        "Predicted AUC": pred_model_auc,
        "Perfect AUC": perfect_model_auc,
        "LCR": lcr,
        "data": df_plotting[
            [
                "Percent Accumulated Population",
                "Perfect Model",
                "Current Model",
                "Random Model",
            ]
        ],
    }


# RIMO computes LCR by deciles instead of each observation...
def _rimo_powerstats(
    df, obs_col, pred_col, ead_col, lgd_target=False, ead_weighted=False
):

    # Setup DataFrames.
    if lgd_target == True:
        df_rank = df[[ead_col, obs_col, pred_col]].copy()
    else:
        df_rank = df[[pred_col, obs_col]].copy()

    # 1. Calculate observed loss = observed LGD * EAD.
    if ead_weighted == True & lgd_target == True:
        df_rank["obs_loss_amount"] = df_rank[ead_col] * df_rank[obs_col]
        df_rank["pred_loss_amount"] = df_rank[ead_col] * df_rank[pred_col]
    else:
        df_rank["obs_loss_amount"] = df_rank[obs_col]
        df_rank["pred_loss_amount"] = df_rank[pred_col]

    # Set deciles/bins
    # Too many observations with 0 realised LGD thus the bins are merged (duplicates='drop')
    df_rank["Decile_rank"] = pd.qcut(
        df_rank["obs_loss_amount"], q=10, labels=False, duplicates="drop"
    )

    # OBS: ONLY FOR LGD.....
    if lgd_target == True:
        # Split the "merged" decile/bin into two; one for all observations with 0 realised LGD and one for the remaining observations
        df_rank.loc[
            (df_rank["Decile_rank"] == 0) & (df_rank["obs_loss_amount"] == 0),
            "Decile_rank",
        ] = -1
        # Numbering the bins from 1-10
        df_rank["Decile_rank"] = df_rank["Decile_rank"] + 2
    # OBS: ONLY FOR LGD.....

    # Aggregate grouped by the deciles/bins
    grouped_df = (
        df_rank[["Decile_rank", "obs_loss_amount", "pred_loss_amount"]]
        .groupby(["Decile_rank"])
        .sum()
    )
    grouped_df["_count_"] = df_rank.groupby(["Decile_rank"]).size()

    # Sort realised LGD from highest to lowest
    grouped_df = grouped_df.sort_values(by=["Decile_rank"], ascending=[False])

    # Accumulate number of observations in each decile/bin
    grouped_df["accum_pop"] = grouped_df["_count_"].cumsum()
    grouped_df["perc_accum_pop"] = (
        grouped_df["accum_pop"] / grouped_df["accum_pop"].max()
    )

    # Accumulate realised (ie. actual) and predicted LGD
    grouped_df["accum_actual"] = grouped_df["obs_loss_amount"].cumsum()
    grouped_df["perc_accum_actual"] = (
        grouped_df["accum_actual"] / grouped_df["accum_actual"].max()
    )
    grouped_df["accum_predict"] = grouped_df["pred_loss_amount"].cumsum()
    grouped_df["perc_accum_predict"] = (
        grouped_df["accum_predict"] / grouped_df["accum_predict"].max()
    )

    # Calculate the area under the respective curves
    perfect_model_auc = (
        np.trapz(grouped_df["perc_accum_actual"], x=grouped_df["perc_accum_pop"]) - 0.5
    )
    pred_model_auc = (
        np.trapz(grouped_df["perc_accum_predict"], x=grouped_df["perc_accum_pop"]) - 0.5
    )

    # Compute LCR.
    lcr = pred_model_auc / perfect_model_auc

    # Append a [0, 0] to the beginning of each DataFrame for plotting purposes,
    # since it may not actually exist in the real data.
    grouped_df = pd.concat(
        [
            pd.DataFrame.from_dict(
                {
                    "perc_accum_pop": [0],
                    "perc_accum_actual": [0],
                    "perc_accum_predict": [0],
                }
            ),
            grouped_df,
        ],
        sort=False,
    )

    # Collect plotting data into pandas.DataFrame.
    grouped_df = grouped_df.rename(
        columns={
            "perc_accum_pop": "Percent Accumulated Population",
            "perc_accum_actual": "Perfect Model",
            "perc_accum_predict": "Current Model",
        }
    )
    df_random = pd.DataFrame.from_dict(
        {"Percent Accumulated Population": [0, 1], "Random Model": [0, 1]}
    )
    df_plotting = pd.concat(
        objs=[grouped_df, df_random],
        axis=0,
        join="outer",
        ignore_index=True,
        sort=False,
    )

    return {
        "Predicted AUC": pred_model_auc,
        "Perfect AUC": perfect_model_auc,
        "LCR": lcr,
        "data": df_plotting[
            [
                "Percent Accumulated Population",
                "Perfect Model",
                "Current Model",
                "Random Model",
            ]
        ],
    }


data = pd.DataFrame(
    [
        [1, 0.000000, 50.922045],
        [1, 154.833891, 7192.859088],
        [1, 0.000000, 13031.110116],
        [1, 98.477891, 10308.211324],
        [1, 0.000000, 21.138367],
        [1, 0.000000, 28.323184],
        [1, 0.000000, 497.694498],
        [1, 0.000000, 15126.853090],
        [1, 48839.549037, 14197.308552],
        [1, 0.000000, 23.812374],
    ],
    columns=["ead_col", "obs_col", "pred_col"],
)

res = _pandas_powerstats(
    df=data,
    obs_col="obs_col",
    ead_col="ead_col",
    pred_col="pred_col",
    lgd_target=False,
    ead_weighted=False,
    method="rimo",
)

print(res)
