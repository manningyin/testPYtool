crv.validation.calibration
==========================

.. automodule:: crv.validation.calibration
    :members:
    :undoc-members:
    :show-inheritance:
