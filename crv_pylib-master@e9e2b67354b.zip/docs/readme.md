# CRV_PYLIB Sphinx documentation

How to get `make html` command working

1. Go to command prompt
1. Go to a local folder in which you want to create a virtual environment (venv) using `cd`
1.  Create a venv by typing: `python -m venv sphinx-env`
1. When the venv have been created, enter the folder by typing `cd sphinx-env` in your command prompt
1. `pip install sphinx` in your command prompt
1. Navigate to the "Scripts" folder in the sphinx-env: `cd Scripts`
1. Activate the venv by typing: `activate.bat`
1. Go to your environmental variables (in Windows menu, type: `Edit environmental variables for your account`)
1. Add a new environmental variable with:
    * variable name: SPHINXBUILD
    * variable path: location to sphinx-build in your venv. For example:
    C:\Users\g85538\Documents\Projects\Virtual_environment\sphinx-env\Scripts\sphinx-build
1. Go back to your command prompt
1. Now navigate to the git project containing the Sphinx docs. For example:
`cd C:\Users\g85538\Documents\git_projects\crv_pylib\docs`
1. Type in your command prompt `make html`
1. You may receive messages in your command prompt that you miss certain Python packages, so `pip install` the listed python packages.
