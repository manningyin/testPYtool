crv.validation.summary
======================

.. automodule:: crv.validation.summary
    :members:
    :undoc-members:
    :show-inheritance:
