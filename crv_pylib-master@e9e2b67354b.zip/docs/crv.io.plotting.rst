crv.io.plotting
===============

.. automodule:: crv.io.plotting
    :members:
    :undoc-members:
    :show-inheritance:
