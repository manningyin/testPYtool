crv.utils.visual_helper
=======================

.. automodule:: crv.utils.visual_helper
    :members:
    :undoc-members:
    :show-inheritance:
