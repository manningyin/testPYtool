# Setup file for CRV_PYLIB

from setuptools import setup

if __name__ == "__main__":
    setup()
