# **`CRV_PYLIB`: Credit Risk Model Validation Python code library**
**Repository owner:** *adam.szpilewicz@nordea.com* (M016673)

A Python repository containing functionality for performance testing credit risk models. See API documentation and release notes for further information on available methods.

---
# `CRV_PYLIB` v1.3.2 - Release Notes 2021.07.02
## Summary
**Logic in `crv.io.exceltables.df2xcel` sheets in exported excel are not protected.** 

## Details
The following is the current contents of the release. New functionality added this release is marked with ***NEW***, while changes and fixes are marked with ***UPDATED***.
### Performance test functions
#### Calibration tests - `crv.validation.calibration`
 * Jeffreys test, section 2.5.3.1 in [1]. 
 * Exact and Normally-approximated binomial test, section B.6.1 in [2].
 * Nordea's confidence intervals, section B.6.2 in [2].
 * Hosmer-Lemeshow test, section 7.4 in [3].
 * T-test, section 2.6.2.1 and 2.9.3.1 in [1].
 * Pearson's Chi-squared test for homogeneity/heterogeneity, section 7.16 and 7.17 [3].

#### Discriminatory power tests - `crv.validation.differentiation`
 * AUC score (ECB summary method), section 3.1 in [1], now with standard deviation.
 * Herfindahl index, section 2.5.5.3 in [1].
 * Generalized AUC (gAUC, ECB summary method), section 2.6.3.1 in [1].
 * Loss capture ratio [4].
 * Two-sample Kolmogorov-Smirnov test [5].
 * Somers' D, [3].

#### Stability tests - `crv.validation.stability`
 * Concentration test, section 7.6 in [3].
 * Stability of the migration matrix, section 2.5.5.2 in [1].
 * Population stability index, section 2.6.4.2 in [1].
 * Likelihood ratio test, [6].
 * Migration matrix weighted bandwidth, [1].

#### Model diagnostics - `crv.validation.model_diagnostics`
 * VIF (variance inflaction factor), [3].
 * Cook's distance, [3].
 * Glejser test, [3].

### Summary functions - `crv.validation.summary`
 * PD Portfolio Information, section 2.4.3 in [1].
 * Actual default frequency (ADF) summary, required input format for PD tests. 
 * Migration matrix, section 2.5.5.1 in [1].
 * Contingency table, section 3.2 in [1].
 * Migration matrix summary, custom.

### Analyses
#### Accuracy - `crv.analysis.accuracy`
 * Descriptive statistics on tabular data.

#### Anomaly detection - `crv.analysis.anomaly_detection`
 * Functions for both sequential (time-series) and non-sequential data.

#### Completeness - `crv.analysis.completeness`
 * Summary of missing values.

#### Timeliness - `crv.analysis.timeliness`
 * Identification of outdated values.

#### Uniqueness - `crv.analysis.uniqueness`
 * Identification and summarization of duplicates.

### Report output
#### MRMS reporting - `crv.io.mrms_reporting`
 * Functionality for arranging Excel table output from the MRMS.

#### Plotting - `crv.io.plotting`
 * Line plot.
 * Scatter plot.
 * Bar plot.
 * Histogram.
 * Boxplot.

#### Writing to Excel tables - `crv.io.exceltables` ***UPDATED***
 * Exported excel has unprotected sheets.

### Documentation
API documentation for `CRV_PYLIB` can be found in the `docs` folder. Upon successfully cloning the repository, navigate to the `/crv_pylib/docs/html/` folder and double-click on the `index.html` file to open the front page of the documentation. Index and search functionality is also available.

### Demonstration
The `demo` folder of the repository contains several notebooks dedicated to demostrating how to use all test and summary functions in the `crv.validation` submodule. Please copy these to a location on your local drive and open using Jupyter Lab or Jupyter Notebook.

## References
[1]: Annex 2 - Instructions for reporting the validation results of internal models (February 2019)

[2]: Validation Guideline - IRB Models - v1.7

[3]: Model Testing Framework v2.5

[4]: Li, D., Bhariok, R., Keenan, S., Santilli, S. (2009). "Validation techniques and performance metrics for loss given default models". The Journal of Risk Model Validation, 33, 3-26.

[5]: Hodges, J.L. Jr., "The Significance Probability of the Smirnov Two-Sample Test," Arkiv fiur Matematik, 3, No. 43 (1958), 469-86.

[6]: Wikipedia article on likelihood ratio test, https://en.wikipedia.org/wiki/Likelihood-ratio_test


##### (End of release notes for `CRV_PYLIB` v1.3.1)

---
