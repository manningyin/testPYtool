"""
User acceptance test script for issue CRVPYLIB-147.

Author: Reinout Kool (G85538)
"""

# Imports
from crv.io.mrms_reporting import mrms_recommendation_status
import os

# ========================================================
# This script imports a pandas.DataFrames from a .xls file
# and extracts relevant information that is written to
# an output file. Reviewer inspects the output Microsoft
# Excel files as per the criteria in the pull request.
# ========================================================

# ========================================================
# Test 1

# Path to input file
mrms_input_data = "input_MRMS_file.xls"

# Path to output file
output_file_path = os.getcwd() + "\\output\\"

output_file_name = "output_uat.xlsx"

# Test recommendation IDs
recs_id = [
    "F_CRMV-val-819533888-1",
    "F_CRMV-val-1718360099-2",
    "F_CRMV-val-1542854020-8",
    "F_15707",
    "F_CRMV-val-2695042663-15",
    "F_15761",
    "F_15762",
]

# Activate function
mrms_recommendation_status(recs_id, mrms_input_data, output_file_path, output_file_name)
