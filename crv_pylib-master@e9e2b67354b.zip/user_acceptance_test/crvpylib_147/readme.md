# `CRVPYLIB-147-mrms-reporting-functions`
## **User acceptance test material**
The material contained herein is used as an acceptance test for the above named implementation task.

### Application of user acceptance testing
 * User acceptance testing is to be used when unit testing is unsuitable or infeasible, e.g. data visualizations.

### File structure
 * All input files (if any) are prefixed with `input_`, and are contained within this folder.
 * All output files (if any) are prefixed with `output_`, and are written to the output folder within this folder.
 * This folder contains a single Python script that will execute all functions to be tested for this implementation task. This script will be prefixed with `uat_`, i.e. user acceptance test.

### Test and review process
 * Test criteria will be written as numbered bullets in the pull request. This criteria will be agreed upon by the reviewer and tester.
 * The reviewer will run the test script and check the output against the acceptance criteria. The results will be written as either 'Pass' for meeting the criteria, or 'Fail' plus a brief explanation of the failure to meet the criteria.
 * The implementation, data (if any) and/or test script will be modified as dictated by the failure description, and the test will be repeated until successful.