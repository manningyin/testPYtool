"""
User acceptance test script for issue CRVPYLIB-132.

Author: Lee MacKenzie Fischer (G01679)
"""

# Imports.
import pandas as pd
from crv.io.exceltables import df2excel

# ========================================================
# This script imports a pandas.DataFrames from a pickle
# files and applies formatting via the function options.
# Reviewer inspects the output Microsoft Excel files
# as per the criteria in the pull request.
# ========================================================

output_workbook = "output_tables.xlsx"

# ========================================================
# Test 1
print(
    "Test 1 - Exporting LGD contingency matrix with "
    "Intervals as row and column indices: "
)
# Import LGD contingency matrix.
lgd_matrix = pd.read_pickle("input_lgd_matrix.pkl")

# Export to Microsoft Excel.
df2excel(
    df=lgd_matrix,
    workbook=output_workbook,
    sheet="LGD_contingency_matrix",
    header=True,
    index=True,
    header_formats={},
    index_formats={},
    data_formats={},
    column_formats={},
    column_conditional_formats=[],
    header_height=None,
    max_index_width=1000,
    row_height=15,
    max_col_width=1000,
    specific_row_height={},
    specific_col_width={},
)

print("Test complete.\n")

# ========================================================
# Test 2
print("Test 2 - Exporting T-test results with decimal and " "percent formatting: ")

# Import T-test results.
ttest = pd.read_pickle("input_ttests_years_perf_elbe.pkl")

# Export to Microsoft Excel.
df2excel(
    df=ttest,
    workbook=output_workbook,
    sheet="T_test",
    header=True,
    index=True,
    header_formats={},
    index_formats={},
    data_formats={},
    column_formats={
        "mean_est": "#.#%",
        "mean_act": "0.00%",
        "var": "0.000",
        "t_stat": "0.0",
    },
    column_conditional_formats=[],
    header_height=None,
    max_index_width=1000,
    row_height=15,
    max_col_width=1000,
    specific_row_height={},
    specific_col_width={},
)

print("Test complete.\n")
