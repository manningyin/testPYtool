def my_function_name(info, var_a, var_b):
    """
    One line description. Then an empty line - followed by multi-line detailed description.

    Args:
        arg_name    (type): Description

    Returns:
        (type): Description

    Example:
        The module is called (from python) like this::

            # Code Example Here...

    Notes:
        Author: gxxxxx
    """
