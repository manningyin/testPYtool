import unittest


class TestEquityQuotientCalc(unittest.TestCase):
    """ "
    DEMO of a vanilla Unit Test Case

    Unit Test DATA
    A unit test has 3 kinds of data:
    - Input:    Fixed set of input data used by the tested component
    - Expected: The output expected from the component, given the fixed input.
    - Actual:   The actual output from "this" test of the component.

    Unit Test STEPS
    A unit test has 3 steps, known as the AAA:
    - Arrange:  Set-up everything needed to invoke the tested component, and evaluating the result
                The "Input" and "Expected" data is arranged
    - Act:      Invoke the tested component using the input from the "Arrange" section
                The "Actual" data is created here
    - Assert:   Compare the "Expected" and the "Actual"

    Example:
        def test_my_function_simple_use(self):
            # ==========
            # Arrange
            # ==========
            a = 3
            b = 4
            expected = 5

            # ==========
            # Act
            # ==========
            actual = my_module.pythagoras(a = a, b = b)

            # ==========
            # Assert
            # ==========
            self.assertEqual(expected, actual)
    """


if __name__ == "__main__":
    unittest.main()
