"""
First line is a short overall description of the module

After one empty line, you should go more into details about what the purpose of the module is - in free text.
This could take up a couple of lines.
This could take up a couple of lines.

Detailed information about specific functions should be done in the function headers.

The description could include an business example:
The module aims to handle everything that has something to do with formatting calendar dates

Warning:
    <This section is optional. Please remove this comment line when you use the template>
    Please be aware that this modules DOES SOME IRREVERSIBLE STUFF or that is 

Notes:
    Author: gxxxxx

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       ddmonyyyy   G12345      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""


def my_function_name(var_a, var_b, info=0):
    """
    Use the function_header.py for this part...
    """
