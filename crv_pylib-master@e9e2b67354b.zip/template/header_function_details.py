def my_function_name(info, var_a, var_b):
    """
    First line is a short overall description of the function

    After one empty line, you should go more into details about what the function does - in free text.
    This could take up many lines.
    This could take up many lines.
    This could take up many lines.

    It could also include an business example:
    A trade that has the characteristics A and B, will be treated this way,
    and interesting stuff will be calculated. All ending up with C being returned.

    Args:
        arg_name        (type):   Description

    Returns:
        (type):   Description

    Raises:
        <Example - Please remove this comment line when you use the template>
        <IOError: An error occurred accessing the bigtable.Table object.>

    Example:
        <This section is optional. Please remove these comment lines when you use the template.>
        <NOTE! Please keep the "::" followed by a blank line to indicate start of the code section>
        The module is called (from python) like this::

            something_returned = my_function_name(info      = 0,
                                                  var_a     = 9,
                                                  var_b     = {'some_dict_variable': 9, 'some_other_dict_variable': 'Ok - Got the point'}
                                                  )

    Test:

        >>> # Line of code (e.g. import)
        >>> # Another line of code
        >>> # Code producing output to the console
        <Expected output...>

        >>> # Example
        >>> from mr.utils import dict_helper
        >>> d = dict_helper.merge_dicts({'dict_one': 1}, {'dict_two': 2})
        >>> d.pop('dict_one')
        1

    Warning:
        <This section is optional. Please remove this comment line when you use the template>
        Please be aware that this function DOES SOME IRREVERSIBLE STUFF or something else that user needs to be aware of...

    Notes:
        Author: gxxxxx
    """
