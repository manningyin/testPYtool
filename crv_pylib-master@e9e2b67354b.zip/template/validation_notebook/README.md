# `MDP Validation Notebook template` 
**Template owners:** *Lee.MacKenzie.Fischer@nordea.com* (G01679), *Reinout.Kool@consult.nordea.com* (G85538)

Validation Jupyter Notebook template intended for Python validation activities of IRB models developed as part of the Model Development Programme 2018-2020.

### Use of template
- Copy-paste this template (.ipynb) to your folder. 
- Change name of the template Working_paper_Jira_issue_title_Jira_ID, where `Jira_issue_title` is the title of the related Jira issue and `Jira_ID` is the related Jira ID.
- **Note**: This template provides guidance on how to perform the Python validation activities in a uniform and readable manner. The user is free to make adjustments to **locally-stored** version of the template if it does not suffice for the validation activity.

### Template revision history
- **Version** 1.0
- **Date:** 22-09-2020
- **Author(s):** Reinout Kool (G85538)
- **Description:** New validation Notebook template intended for Python validation activities of IRB models developed as part of the Model Development Programme 2018-2020.
