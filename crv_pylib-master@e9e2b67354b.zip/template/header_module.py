"""
One line description. Followed by empty line and then multi-line detailed description.

Notes:
    Author: gxxxxx
"""


def my_function_name(var_a, var_b, info=0):
    """
    Use the function_header for this part...
    """
