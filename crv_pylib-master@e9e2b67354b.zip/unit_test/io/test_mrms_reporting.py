"""
Unit testing file for CRV.IO.MRMS_REPORTING.PY

This module is intended to contain and execute the test cases for
functions in the 'crv.io.mrms_reporting_helper' module.

Warning:
    No warnings as of latest version.

Notes:
    Author: Reinout Kool <G85338>

"""
import unittest
import numpy as np
import pandas as pd
import os
from datetime import datetime
from crv.io.mrms_reporting import (
    mrms_recommendation_status,
    merge_df,
    single_rec_per_recommendation,
    rec_id_in_action_id_check,
    mrms_data_consolidator,
)


class TestMRMSRecommendationStatus(unittest.TestCase):
    @staticmethod
    def get_test_data():
        df_recs = pd.DataFrame.from_dict(
            {
                "ID": ["rec1", "rec2", "rec3", "rec4"],
                "Initiation date": [
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                    np.nan,
                ],
                "Recommendation": [
                    "Recommendation rec1",
                    "Recommendation rec2",
                    "Recommendation rec3",
                    "Recommendation rec4",
                ],
                "Severity": ["High", "Medium", "Low", np.nan],
                "Issue": ["Issue rec1", "Issue rec2", "Issue rec3", "Issue rec4"],
                "Closed": ["Open", "Closed", "Open", "Closed"],
                "Name": ["Name1_1", "Name2_1", "Name3_1", "Name4_1"],
            }
        )

        df_actions = pd.DataFrame.from_dict(
            {
                "ID": [
                    "action1",
                    "action2",
                    "action3",
                    "action4",
                    "action5",
                    "action6",
                    "action7",
                    "action8",
                    "action9",
                    "action10",
                ],
                "Name": [
                    "Resolve 0: Name1_1",
                    "Resolve 1: Name1_2",
                    "Resolve 0: Name2_1",
                    "Resolve 0: Name3_1",
                    "Resolve 1: Name3_2",
                    "Resolve 2: Name3_3",
                    "Resolve 0: Name4_1",
                    "Resolve 1: Name4_2",
                    "Resolve 3: Name4_3",
                    "Resolve 4: Name4_4",
                ],
                "Model owner response": [
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                    "Model owner response",
                ],
                "Most Specific Model family": [
                    "PD",
                    "PD",
                    "CCF",
                    "EAD",
                    "EAD",
                    "EAD",
                    "LGD",
                    "LGD",
                    "LGD",
                    "LGD",
                ],
                "Most Specific Geography": [
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                    "Geographies",
                ],
                "Most Specific Business Unit": [
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                    "Risk Models",
                ],
                "Description": [
                    "Description action 1",
                    "Description action 2",
                    "Description action 3",
                    "Description action 4",
                    "Description action 5",
                    "Description action 6",
                    "Description action 7",
                    "Description action 8",
                    "Description action 9",
                    "Description action 10",
                ],
                "Initiation date": [
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                ],
                "Date of last follow-up": [
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                ],
                "Due date for closure": [
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                ],
                "Material submitted for assessment": [
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                    datetime(2021, 1, 1),
                ],
                "Material submission date": [
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                    datetime(2021, 1, 1),
                ],
                "Validator assessment": [
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                ],
                "Validator assessment date": [
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2017, 1, 1),
                    datetime(2018, 1, 1),
                    datetime(2019, 1, 1),
                    datetime(2020, 1, 1),
                ],
                "Creator": [
                    "Creator1",
                    "Creator1",
                    "Creator2",
                    "Creator3",
                    "Creator3",
                    "Creator3",
                    "Creator4",
                    "Creator4",
                    "Creator4",
                    "Creator4",
                ],
                "Updater": [
                    "Updater1",
                    "Updater1",
                    "Updater2",
                    "Updater3",
                    "Updater3",
                    "Updater3",
                    "Updater4",
                    "Updater4",
                    "Updater4",
                    "Updater4",
                ],
                "Full Classification": [
                    "Full Classification 1",
                    "Full Classification 1",
                    "Full Classification 2",
                    "Full Classification 3",
                    "Full Classification 3",
                    "Full Classification 3",
                    "Full Classification 4",
                    "Full Classification 4",
                    "Full Classification 4",
                    "Full Classification 4",
                ],
            }
        )

        df_recs_actions_keys = pd.DataFrame.from_dict(
            {
                "Recommendation": [
                    "rec1_error",
                    "rec1_error",
                    "rec2",
                    "rec3",
                    "rec3",
                    "rec3",
                    "rec4",
                    "rec4",
                    "rec4",
                    "rec4",
                ],
                "Action Plan": [
                    "action1",
                    "action2",
                    "action3",
                    "action4",
                    "action5",
                    "action6",
                    "action7",
                    "action8",
                    "action9",
                    "action10",
                ],
            }
        )

        df_actions_owner_keys = pd.DataFrame.from_dict(
            {
                "Action Plan": [
                    "action1",
                    "action2",
                    "action3",
                    "action4",
                    "action5",
                    "action6",
                    "action7",
                    "action8",
                    "action9",
                    "action10",
                ],
                "Owner": [
                    "Name1",
                    "Name1",
                    "Name2",
                    "Name3",
                    "Name3",
                    "Name3",
                    "Name4",
                    "Name4",
                    "Name4",
                    "Name4",
                ],
            }
        )

        df_user_owner_keys = pd.DataFrame.from_dict(
            {
                "ID": ["g87654", "g76543", "g65432", "g54321"],
                "Name": ["Name1", "Name2", "Name3", "Name4"],
            }
        )

        return (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        )

    def test_merge_df_dataframe_merge(self):
        """
        Test that two DataFrames are correctly merged.
        """
        data1 = {
            "col1": [1, 4, 3, 2, 7, 5, 3, 1, 4, 1, 3],
            "col2": [7, 5, 3, 4, 6, 5, 2, 1, 3, 5, 4],
            "col3": [8, 4, 2, 4, 6, 4, 2, 1, 3, 5, 2],
        }
        df_left = pd.DataFrame(data=data1)

        data2 = {"col4": [1, 3, 2], "col5": [4, 2, 2], "col6": [7, 6, 5]}
        df_right = pd.DataFrame(data=data2)

        df_merge = merge_df(
            df_left=df_left,
            df_right=df_right,
            left_ID="col1",
            right_ID="col4",
            validate="many_to_one",
            drop_cols=["col4"],
        )
        df_merge = df_merge.sort_values(["col1", "col2"], ascending=[True, True])
        data_calc = df_merge.values.tolist()

        # Validated list
        data_val = [
            [1, 1, 1, 4, 7],
            [1, 5, 5, 4, 7],
            [1, 7, 8, 4, 7],
            [2, 4, 4, 2, 5],
            [3, 2, 2, 2, 6],
            [3, 3, 2, 2, 6],
            [3, 4, 2, 2, 6],
        ]

        # Compare calculated and validated filtered DataFrame on row level
        for i in range(len(data_calc)):
            calc_list = data_calc[i]
            val_list = data_val[i]
            self.assertListEqual(
                calc_list,
                val_list,
                msg=f"Row '{i}' is not equal in the comparison "
                "of a calculated and validated merged dataframe.",
            )

    def test_single_rec_per_recommendation_validation(self):
        """
        Test that the most recent actions per recommendation are obtained.
        The most recent actions are identified by filtering the most recent
        resolve status from the column 'Action name'
        """
        data = {
            "ID Recommendation": [
                "ABC1",
                "ABC1",
                "BCD2",
                "BCD2",
                "CDE3",
                "CDE3",
                "CDE3",
            ],
            "initiation_date_action": [
                "01/01/2017",
                "01/01/2018",
                "01/01/2019",
                "01/01/2018",
                "01/01/2019",
                "01/01/2018",
                "01/01/2020",
            ],
            "Extended_deadline": [
                "01/01/2018",
                "01/01/2019",
                "01/01/2020",
                "01/01/2019",
                "01/01/2020",
                "01/01/2019",
                "01/01/2020",
            ],
            "Action name": [
                "Resolve 0",
                "Resolve 1",
                "Resolve 1",
                "Resolve 0",
                "Resolve 1",
                "Resolve 0",
                "Resolve 2",
            ],
            "initiation_information": [
                "init_ABC1-old",
                "init_ABC1-new",
                "init_BCD2-new",
                "init_BCD2-old",
                "init_CDE3-middle",
                "init_CDE3-old",
                "init_CDE3-new",
            ],
            "recent_information": [
                "rec_ABC1-old",
                "rec_ABC1-new",
                "rec_BCD2-new",
                "rec_BCD2-old",
                "rec_CDE3-middle",
                "rec_CDE3-old",
                "rec_CDE3-new",
            ],
        }
        df = pd.DataFrame(data=data)

        df_report = single_rec_per_recommendation(
            df,
            ["rec_ID", "initiation_date_action"],
            "ID Recommendation",
            ["recent_information"],
        )
        df_report = df_report.drop(
            columns=["Action name", "index", "Extended_deadline"]
        )
        data_calc = df_report.values.tolist()

        # Validated list
        data_val = [
            ["ABC1", "01/01/2017", "init_ABC1-old", "rec_ABC1-new"],
            ["BCD2", "01/01/2018", "init_BCD2-old", "rec_BCD2-new"],
            ["CDE3", "01/01/2018", "init_CDE3-old", "rec_CDE3-new"],
        ]

        # Compare calculated and validated filtered DataFrame on row level
        for i in range(len(data_calc)):
            calc_list = data_calc[i]
            val_list = data_val[i]
            self.assertListEqual(
                calc_list,
                val_list,
                msg=f"Row '{i}' is not equal in the comparison "
                "of a calculated and validated filtered dataframe.",
            )

    def test_multiple_actions_rec_per_recommendation_validation(self):
        """
        Test that the most recent actions per recommendation are obtained.
        The most recent actions are identified by filtering the most recent
        resolve status from the column 'Action name'.

        Recommendation ID CDE3 has a break-down of 2 actions, into 'Resolve 1a'
        and 'Resolve 1b'. The function should filter out both these actions.
        """
        data = {
            "ID Recommendation": [
                "ABC1",
                "ABC1",
                "BCD2",
                "BCD2",
                "CDE3",
                "CDE3",
                "CDE3",
            ],
            "initiation_date_action": [
                "01/01/2017",
                "01/01/2018",
                "01/01/2019",
                "01/01/2018",
                "01/01/2019",
                "01/01/2018",
                "01/01/2019",
            ],
            "Extended_deadline": [
                "01/01/2018",
                "01/01/2019",
                "01/01/2020",
                "01/01/2019",
                "01/01/2020",
                "01/01/2019",
                "01/01/2020",
            ],
            "Action name": [
                "Resolve 0",
                "Resolve 1",
                "Resolve 1",
                "Resolve 0",
                "Resolve 1a",
                "Resolve 0",
                "Resolve 1b",
            ],
            "initiation_information": [
                "init_ABC1-old",
                "init_ABC1-new",
                "init_BCD2-new",
                "init_BCD2-old",
                "init_CDE3-middle",
                "init_CDE3-old",
                "init_CDE3-new",
            ],
            "recent_information": [
                "rec_ABC1-old",
                "rec_ABC1-new",
                "rec_BCD2-new",
                "rec_BCD2-old",
                "rec_CDE3-new-a",
                "rec_CDE3-old",
                "rec_CDE3-new-b",
            ],
        }
        df = pd.DataFrame(data=data)

        df_report = single_rec_per_recommendation(
            df,
            ["rec_ID", "initiation_date_action"],
            "ID Recommendation",
            ["recent_information"],
        )
        df_report = df_report.drop(
            columns=["Action name", "index", "Extended_deadline"]
        )
        data_calc = df_report.values.tolist()

        # Validated list
        data_val = [
            ["ABC1", "01/01/2017", "init_ABC1-old", "rec_ABC1-new"],
            ["BCD2", "01/01/2018", "init_BCD2-old", "rec_BCD2-new"],
            ["CDE3", "01/01/2018", "init_CDE3-old", "rec_CDE3-new-a"],
            ["CDE3", "01/01/2018", "init_CDE3-old", "rec_CDE3-new-b"],
        ]

        # Compare calculated and validated filtered DataFrame on row level
        for i in range(len(data_calc)):
            calc_list = data_calc[i]
            val_list = data_val[i]
            self.assertListEqual(
                calc_list,
                val_list,
                msg=f"Row '{i}' is not equal in the comparison "
                "of a calculated and validated filtered dataframe.",
            )

    def test_mrms_data_consolidator_1(self):
        """
        Recommendation (rec2) with one action ID
        """
        recs_id = ["rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        output_df, df_ex_deadline = mrms_data_consolidator(
            recs_id,
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        )

        output_df = output_df[
            [
                "ID Recommendation",
                "Severity",
                "Most Specific Model family",
                "Issue",
                "Recommendation creation date",
                "Model owner response",
                "Issue Owner",
                "Description",
                "ID Action",
                "Date of last follow-up",
                "Material submission date",
                "Original deadline",
            ]
        ]

        data_calc = [element for element in output_df.values.tolist()[0]]

        # Validated list
        data_val = [
            "rec2",
            "Medium",
            "CCF",
            "Issue rec2",
            pd.Timestamp("2019-01-01 00:00:00"),
            "Model owner response",
            "Unregistered",
            "Description action 3",
            "action3",
            pd.Timestamp("2018-01-01 00:00:00"),
            pd.Timestamp("2018-01-01 00:00:00"),
            pd.Timestamp("2018-01-01 00:00:00"),
        ]

        # Compare calculated and validated filtered DataFrame on row level
        self.assertListEqual(
            data_calc,
            data_val,
            msg=f"Elements are not equal in the comparison "
            "of a calculated and validated filtered dataframe.",
        )

    def test_mrms_data_consolidator_2(self):
        """
        Recommendation with three action IDs and missing value for owner
        """
        recs_id = ["rec3"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        output_df, df_ex_deadline = mrms_data_consolidator(
            recs_id,
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        )

        output_df = output_df[
            [
                "ID Recommendation",
                "Severity",
                "Most Specific Model family",
                "Issue",
                "Recommendation creation date",
                "Model owner response",
                "Issue Owner",
                "Description",
                "ID Action",
                "Date of last follow-up",
                "Material submission date",
                "Original deadline",
            ]
        ]

        data_calc = [element for element in output_df.values.tolist()[0]]

        # Validated list
        data_val = [
            "rec3",
            "Low",
            "EAD",
            "Issue rec3",
            pd.Timestamp("2020-01-01 00:00:00"),
            "Model owner response",
            "Unregistered",
            "Description action 6",
            "action6",
            pd.Timestamp("2017-01-01 00:00:00"),
            pd.Timestamp("2020-01-01 00:00:00"),
            pd.Timestamp("2018-01-01 00:00:00"),
        ]

        # Compare calculated and validated filtered DataFrame on row level
        self.assertListEqual(
            data_calc,
            data_val,
            msg=f"Elements are not equal in the comparison "
            "of a calculated and validated filtered dataframe.",
        )

    def test_mrms_data_consolidator_3(self):
        """
        Recommendation with four action IDs and missing value for original
        deadline (Due date for closure)
        """
        recs_id = ["rec4"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        output_df, df_ex_deadline = mrms_data_consolidator(
            recs_id,
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        )

        output_df = output_df[
            [
                "ID Recommendation",
                "Severity",
                "Most Specific Model family",
                "Issue",
                "Recommendation creation date",
                "Model owner response",
                "Issue Owner",
                "Description",
                "ID Action",
                "Date of last follow-up",
                "Material submission date",
                "Original deadline",
            ]
        ]

        data_calc = [element for element in output_df.values.tolist()[0]]

        # Validated list
        data_val = [
            "rec4",
            "Unregistered",
            "LGD",
            "Issue rec4",
            "Unregistered",
            "Model owner response",
            "Unregistered",
            "Description action 10",
            "action10",
            pd.Timestamp("2017-01-01 00:00:00"),
            pd.Timestamp("2021-01-01 00:00:00"),
            "No deadline registered",
        ]

        # Compare calculated and validated filtered DataFrame on row level
        self.assertListEqual(
            data_calc,
            data_val,
            msg=f"Elements are not equal in the comparison "
            "of a calculated and validated filtered dataframe.",
        )

    def test_mrms_data_consolidator_4(self):
        """
        Two Recommendation IDs, where :
            - rec3 has three action IDs and missing value for owner
            - rec 4 has four action IDs with missing value for
                original deadline (Due date for closure)
        """
        recs_id = ["rec3", "rec4"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        output_df, df_ex_deadline = mrms_data_consolidator(
            recs_id,
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        )

        output_df = output_df[
            [
                "ID Recommendation",
                "Severity",
                "Most Specific Model family",
                "Issue",
                "Recommendation creation date",
                "Model owner response",
                "Issue Owner",
                "Description",
                "ID Action",
                "Date of last follow-up",
                "Material submission date",
                "Original deadline",
            ]
        ]

        data_calc = [element for element in output_df.values.tolist()]

        # Validated list
        data_val = [
            [
                "rec3",
                "Low",
                "EAD",
                "Issue rec3",
                pd.Timestamp("2020-01-01 00:00:00"),
                "Model owner response",
                "Unregistered",
                "Description action 6",
                "action6",
                pd.Timestamp("2017-01-01 00:00:00"),
                pd.Timestamp("2020-01-01 00:00:00"),
                pd.Timestamp("2018-01-01 00:00:00"),
            ],
            [
                "rec4",
                "Unregistered",
                "LGD",
                "Issue rec4",
                "Unregistered",
                "Model owner response",
                "Unregistered",
                "Description action 10",
                "action10",
                pd.Timestamp("2017-01-01 00:00:00"),
                pd.Timestamp("2021-01-01 00:00:00"),
                "No deadline registered",
            ],
        ]

        # Compare calculated and validated filtered DataFrame
        for i in range(len(data_val)):
            data_calc_list = data_calc[i]
            data_val_list = data_val[i]
            self.assertListEqual(
                data_calc_list,
                data_val_list,
                msg=f"Elements are not equal in the comparison "
                "of a calculated and validated filtered dataframe.",
            )

    def test_mrms_data_consolidator_ValueError_1(self):
        """
        Test that a ValueError is raised when df_recs is not a pd.DataFrame
        """

        recs_id = ["rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        df_recs = "Not a pd.DataFrame but string"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_data_consolidator,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_actions": df_actions,
                "df_recs_actions_keys": df_recs_actions_keys,
                "df_actions_owner_keys": df_actions_owner_keys,
                "df_user_owner_keys": df_user_owner_keys,
            },
        )

    def test_mrms_data_consolidator_ValueError_2(self):
        """
        Test that a ValueError is raised when df_actions is not a pd.DataFrame
        """

        recs_id = ["rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        df_actions = "Not a pd.DataFrame but string"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_data_consolidator,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_actions": df_actions,
                "df_recs_actions_keys": df_recs_actions_keys,
                "df_actions_owner_keys": df_actions_owner_keys,
                "df_user_owner_keys": df_user_owner_keys,
            },
        )

    def test_mrms_data_consolidator_ValueError_3(self):
        """
        Test that a ValueError is raised when df_recs_actions_keys is not
        a pd.DataFrame
        """

        recs_id = ["rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        df_recs_actions_keys = "Not a pd.DataFrame but string"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_data_consolidator,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_actions": df_actions,
                "df_recs_actions_keys": df_recs_actions_keys,
                "df_actions_owner_keys": df_actions_owner_keys,
                "df_user_owner_keys": df_user_owner_keys,
            },
        )

    def test_mrms_data_consolidator_ValueError_4(self):
        """
        Test that a ValueError is raised when df_actions_owner_keys is not
        a pd.DataFrame
        """

        recs_id = ["rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        df_actions_owner_keys = "Not a pd.DataFrame but string"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_data_consolidator,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_actions": df_actions,
                "df_recs_actions_keys": df_recs_actions_keys,
                "df_actions_owner_keys": df_actions_owner_keys,
                "df_user_owner_keys": df_user_owner_keys,
            },
        )

    def test_mrms_data_consolidator_ValueError_5(self):
        """
        Test that a ValueError is raised when df_user_owner_keys is not
        a pd.DataFrame
        """

        recs_id = ["rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        df_user_owner_keys = "Not a pd.DataFrame but string"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_data_consolidator,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_actions": df_actions,
                "df_recs_actions_keys": df_recs_actions_keys,
                "df_actions_owner_keys": df_actions_owner_keys,
                "df_user_owner_keys": df_user_owner_keys,
            },
        )

    def test_mrms_recommendation_status_FileNotFoundError_1(self):
        """
        Test that a FileNotFoundError is raised if incorrect path to input
        file has been specified.
        """
        recommendation_ids = ["F_CRMV-val-819533888-1", "F_CRMV-val-1718360099-2"]
        file_path_MRMS = "C:/Users/false_file_path.xls"
        output_folder = os.getcwd()
        recommendation_ids = ["F_CRMV-val-819533888-1", "F_CRMV-val-1718360099-2"]
        output_file_name = "output.xlsx"

        # ValueError check
        self.assertRaises(
            FileNotFoundError,
            mrms_recommendation_status,
            **{
                "recs_id": recommendation_ids,
                "mrms_input_data": file_path_MRMS,
                "output_file_path": output_folder,
                "output_file_name": output_file_name,
            },
        )

    def test_mrms_recommendation_status_FileNotFoundError_2(self):
        """
        Test that a FileNotFoundError is raised if incorrect path to output
        file has been specified.
        """
        file_path_MRMS = os.getcwd()
        output_folder = "C:/Users/false_output_folder"
        recommendation_ids = ["F_CRMV-val-819533888-1", "F_CRMV-val-1718360099-2"]
        output_file_name = "output.xlsx"

        # ValueError check
        self.assertRaises(
            FileNotFoundError,
            mrms_recommendation_status,
            **{
                "recs_id": recommendation_ids,
                "mrms_input_data": file_path_MRMS,
                "output_file_path": output_folder,
                "output_file_name": output_file_name,
            },
        )

    def test_mrms_recommendation_status_ValueError_1(self):
        """
        Test that a ValueError is raised if incorrect file extension
        (not .xlsx) is given for the output_file_name.
        """
        file_path_MRMS = os.getcwd()
        output_folder = os.getcwd()
        recommendation_ids = ["F_CRMV-val-819533888-1", "F_CRMV-val-1718360099-2"]
        output_file_name = "output.xlsxx"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_recommendation_status,
            **{
                "recs_id": recommendation_ids,
                "mrms_input_data": file_path_MRMS,
                "output_file_path": output_folder,
                "output_file_name": output_file_name,
            },
        )

    def test_mrms_recommendation_status_ValueError_2(self):
        """
        Test that a ValueError is raised when recs_id is not a list
        """
        file_path_MRMS = os.getcwd()
        output_folder = os.getcwd()
        recommendation_ids = "String instead of list"
        output_file_name = "output.xlsx"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_recommendation_status,
            **{
                "recs_id": recommendation_ids,
                "mrms_input_data": file_path_MRMS,
                "output_file_path": output_folder,
                "output_file_name": output_file_name,
            },
        )

    def test_mrms_recommendation_status_ValueError_3(self):
        """
        Test that a ValueError is raised when recs_id is an empty list
        """
        file_path_MRMS = os.getcwd()
        output_folder = os.getcwd()
        recommendation_ids = []
        output_file_name = "output.xlsx"

        # ValueError check
        self.assertRaises(
            ValueError,
            mrms_recommendation_status,
            **{
                "recs_id": recommendation_ids,
                "mrms_input_data": file_path_MRMS,
                "output_file_path": output_folder,
                "output_file_name": output_file_name,
            },
        )

    def test_rec_id_in_action_id_check_KeyError_1(self):
        """
        Test that a KeyError is raised when none of the Recommendation IDs
        can linked to Action ID.
        """
        recs_id = ["rec1_missing_action"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        # KeyError check
        self.assertRaises(
            KeyError,
            rec_id_in_action_id_check,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_recs_actions_keys": df_recs_actions_keys,
            },
        )

    def test_rec_id_in_action_id_check_KeyError_2(self):
        """
        Test that a KeyError is raised when none of the Recommendation IDs
        can be linked to Recommendation ID in MRMS
        """
        recs_id = ["rec1_missing_recommendation"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        # KeyError check
        self.assertRaises(
            KeyError,
            rec_id_in_action_id_check,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_recs_actions_keys": df_recs_actions_keys,
            },
        )

    def test_rec_id_in_action_id_check_warning_1(self):
        """
        Test that a warning is raised when a selection of the Recommendation IDs
        cannot be linked to Recommendation ID in MRMS.

        * 'rec_not_linked' cannot be linked to a recommendation ID
        * 'rec2' cann be linked to a recommendation ID
        """
        recs_id = ["rec_not_linked", "rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        # KeyError check
        self.assertWarns(
            Warning,
            rec_id_in_action_id_check,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_recs_actions_keys": df_recs_actions_keys,
            },
        )

    def test_rec_id_in_action_id_check_warning_2(self):
        """
        Test that a warning is raised when a selection of the Recommendation IDs
        cannot be linked to Action ID in MRMS.

        * 'rec1' cannot be linked to an Action ID
        * 'rec2' cann be linked to an Action ID
        """
        recs_id = ["rec1", "rec2"]
        (
            df_recs,
            df_actions,
            df_recs_actions_keys,
            df_actions_owner_keys,
            df_user_owner_keys,
        ) = self.get_test_data()

        # KeyError check
        self.assertWarns(
            Warning,
            rec_id_in_action_id_check,
            **{
                "recs_id": recs_id,
                "df_recs": df_recs,
                "df_recs_actions_keys": df_recs_actions_keys,
            },
        )


if __name__ == "__main__":
    unittest.main()
