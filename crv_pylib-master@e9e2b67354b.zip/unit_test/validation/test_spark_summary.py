"""
# ============================================================================
# TEST_PYSPARK_SUMMARY.PY
# ----------------------------------------------------------------------------
# Description:
#   Unit testing for the functions in 'crv.validation.summary.py' that
#   use the pypsark module.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# ============================================================================
"""

# Imports.
import re
import random
import unittest
import numpy as np
import pandas as pd
import pyspark.sql.functions as f

from unit_test.pyspark_test_class import PySparkTestCase
from crv.utils.dataframe_helper import rating_cats
from crv.validation.summary import spark_adf_summary, adf_summary
from crv.validation.summary import spark_migration_matrix, migration_matrix
from crv.validation.summary import (
    spark_pd_portfolio_information,
    pd_portfolio_information,
)
from crv.validation.summary import (
    lgd_contingency_table,
    spark_lgd_contingency_table,
    pandas_lgd_contingency_table,
)
from crv.validation.calibration import t_test


class TestSparkAdfSummary(PySparkTestCase):
    """
    Tests the 'crv.validation.summary.spark_adf_summary' function.
    """

    @staticmethod
    def dname(col):
        # Column name strings.
        d_colname = {"N": "N", "PD": "PD", "D": "D", "ADF": "ADF"}
        return d_colname[col]

    def get_test_df(self, duplicate=False):
        """
        Get data in Spark DataFrame for testing. Also returns pandas DataFrame
        for calculating the expected answer.
        Args:
            duplicate (bool): Set True to append a duplicate of the
             test dataframe to itself. Default is False.
        """
        d_sample_data = {
            "rating_col": ["1", "2", "2", "3", "3", "9"],
            "customer_id": [f"A00{i}" for i in range(6)],
            "group": ["1", "1", "2", "3", "4", "4"],
            "def_flag": [1, 1, 0, 1, 0, 1],
            "PD": [0.01, 0.02, 0.02, 0.03, 0.03, 0.09],
            "PDG": [0.01, 0.01, 0.02, 0.03, 0.03, 0.03],
            "ratG": ["1", "1", "2", "3", "3", "3"],
            "country": ["DK", "DK", "DK", "SE", "SE", "DK"],
            "ORGEXP": [100, 200, 300, 400, 500, 100],
        }
        pandas_sample_data = pd.DataFrame.from_dict(d_sample_data)
        if duplicate:
            df_dup = pandas_sample_data.copy()
            df_dup["def_flag"] = pd.Series([0, 0, 0, 0, 0, 0])
            pandas_sample_data = pd.concat([pandas_sample_data, df_dup], axis=0)
        pyspark_sample_data = self.spark.createDataFrame(pandas_sample_data)
        col_dict = {
            "rating": "rating_col",
            "ratG": "ratG",
            "cid": "customer_id",
            "group": "group",
            "default": "def_flag",
            "pd": "PD",
            "pdg": "PDG",
            "country": "country",
            "orgexp": "ORGEXP",
            "adf": "ADF",
        }
        return pyspark_sample_data, pandas_sample_data, col_dict

    def test_spark_adf_summary_no_group_no_sum(self):
        """
        Tests function with no grouping or summing columns.
        """
        # Get testing data.
        pyspark_test_df, pandas_test_df, col_dict = self.get_test_df()
        # Independent calculation of results, as a dictionary for hendling reasons.
        d_results = {
            self.dname("N"): pandas_test_df[col_dict["cid"]].count(),
            self.dname("D"): pandas_test_df[col_dict["default"]].sum(),
            self.dname("ADF"): (
                pandas_test_df[col_dict["default"]].sum()
                / pandas_test_df[col_dict["cid"]].count()
            ),
        }
        # Calculate using function. Convert to pandas for comparison.
        df_test = spark_adf_summary(
            pyspark_test_df, col_dict["cid"], col_dict["default"]
        )
        # Evaluate results.
        for col in d_results.keys():
            self.assertEqual(
                df_test[col][0], d_results[col], f"Incorrect result for {col} column."
            )

    def test_spark_adf_summary_no_group_no_sum_with_duplicates(self):
        """
        Tests function with no grouping or summing columns, with
        duplicated values.
        """
        # Get testing data, with doubles.
        pyspark_test_df, pandas_test_df, col_dict = self.get_test_df(True)
        # Independent calculation of results, as a dictionary for hendling reasons.
        pandas_test_df = (
            pandas_test_df.groupby(col_dict["cid"])
            .agg({col_dict["default"]: "max"})
            .reset_index()
        )
        d_results = {
            self.dname("N"): pandas_test_df[col_dict["cid"]].count(),
            self.dname("D"): pandas_test_df[col_dict["default"]].sum(),
            self.dname("ADF"): (
                pandas_test_df[col_dict["default"]].sum()
                / pandas_test_df[col_dict["cid"]].count()
            ),
        }
        # Calculate using function. Convert to pandas for comparison.
        df_test = spark_adf_summary(
            pyspark_test_df, col_dict["cid"], col_dict["default"]
        )
        # Evaluate results.
        for col in d_results.keys():
            self.assertEqual(
                df_test[col][0], d_results[col], f"Incorrect result for {col} column."
            )

    def test_spark_adf_summary_group_country(self):
        """
        Tests function with country grouping and no summing.
        """
        # Get testing data.
        pyspark_test_df, _, col_dict = self.get_test_df()
        # Independent calculation of results, as a dictionary for hendling reasons.
        d_results = {
            "country": ["DK", "SE"],
            "N": [4, 2],
            "D": [3, 1],
            "ADF": [0.75, 0.5],
        }
        # Calculate using function. Convert to pandas for comparison.
        df_test = spark_adf_summary(
            pyspark_test_df, col_dict["cid"], col_dict["default"], col_dict["country"]
        )
        for col in d_results.keys():
            self.assertEqual(
                list(df_test[col]),
                d_results[col],
                f"Incorrect result for '{col}' column.",
            )

    def test_spark_adf_summary_sum_exposure(self):
        """
        Tests the function with summing of original exposure, no grouping.
        """
        # Get testing data.
        pyspark_test_df, _, col_dict = self.get_test_df(True)
        # Independent calculation of results, as a dictionary for hendling reasons.
        d_results = {"N": [6], "D": [4], "ADF": [2 / 3], "ORGEXP": [3200.0]}
        # Calculate using function. Convert to pandas for comparison.
        df_test = spark_adf_summary(
            pyspark_test_df,
            col_dict["cid"],
            col_dict["default"],
            sum_list=col_dict["orgexp"],
        )
        for col in d_results.keys():
            self.assertEqual(
                list(df_test[col]),
                d_results[col],
                f"Incorrect result for '{col}' column.",
            )

    def test_spark_adf_summary_group_ratg_sum_exposure(self):
        """
        Tests the function with summing of original exposure, no grouping.
        """
        # Get testing data.
        pyspark_test_df, _, col_dict = self.get_test_df(True)
        # Independent calculation of results, as a dictionary for hendling reasons.
        d_results = {
            "ratG": ["1", "2", "3"],
            "N": [2, 1, 3],
            "D": [2, 0, 2],
            "ADF": [1.0, 0.0, 2 / 3],
            "ORGEXP": [600.0, 600.0, 2000.0],
        }
        # Calculate using function. Convert to pandas for comparison.
        df_test = spark_adf_summary(
            pyspark_test_df,
            col_dict["cid"],
            col_dict["default"],
            group_list=col_dict["ratG"],
            sum_list=col_dict["orgexp"],
        )
        for col in d_results.keys():
            self.assertEqual(
                list(df_test[col]),
                d_results[col],
                f"Incorrect result for '{col}' column.",
            )

    def test_spark_adf_summary_error_customer_in_group(self):
        """
        Tests for correct throwing of the error if the customer_col
        is found in the group_list.
        """
        # Get testing data.
        pyspark_test_df, _, _ = self.get_test_df(True)
        self.assertRaises(
            ValueError,
            spark_adf_summary,
            pyspark_test_df,
            "col1",
            "col2",
            ["col1", "col3"],
            "col4",
        )

    def test_spark_adf_summary_error_default_in_sum(self):
        """
        Tests for correct throwing of the error if the default_col
        is found in the sum_list.
        """
        # Get testing data.
        pyspark_test_df, _, _ = self.get_test_df(True)
        self.assertRaises(
            ValueError,
            spark_adf_summary,
            pyspark_test_df,
            "col1",
            "col2",
            ["col3"],
            ["col2", "col4"],
        )

    def test_spark_adf_summary_mean_PD(self):
        """
        Tests that the mean PD is calculated when the column name is provided.
        """
        # Get testing data.
        pyspark_test_df, _, col_dict = self.get_test_df(True)
        # Independent calculation of results, as a dictionary for hendling reasons.
        d_results = {
            "ratG": ["1", "2", "3"],
            "N": [2, 1, 3],
            "D": [2, 0, 2],
            "ADF": [1.0, 0.0, 2 / 3],
            "PD": [0.015, 0.02, 0.05],
        }
        # Calculate using function. Convert to pandas for comparison.
        df_test = spark_adf_summary(
            pyspark_test_df,
            col_dict["cid"],
            col_dict["default"],
            group_list=col_dict["ratG"],
            pd_col="PD",
        )
        df_test["PD"] = df_test["PD"].round(3)
        for col in d_results.keys():
            self.assertEqual(
                list(df_test[col]),
                d_results[col],
                f"Incorrect result for '{col}' column.",
            )


class TestSparkMigrationMatrix(PySparkTestCase):
    """
    Unit test case for the spark_migration_matrix function.
    """

    def get_test_data(self):
        """
        Creates 2 tables of synthetic data for testing calculations.
        """
        d_migration = {
            "6": {"6": 0.8, "3": 0.2, "1": 0.0},
            "3": {"6": 0.2, "3": 0.7, "1": 0.1},
            "1": {"6": 0.1, "3": 0.3, "1": 0.6},
        }

        mm_true = (
            pd.DataFrame.from_dict(d_migration, orient="index")
            .loc[["6", "3", "1"]]
            .to_numpy()
        )
        num_grades = len(d_migration)
        num_act_per_grade = 10_000
        total_act = num_grades * num_act_per_grade
        dfr = pd.DataFrame.from_dict(
            {
                "group": [
                    "XT" + str(i).zfill(int(np.log10(total_act) + 2))
                    for i in range(total_act)
                ],
                "rating_x": [
                    np.random.choice(["6", "3", "1"]) for i in range(total_act)
                ],
            }
        )
        dfr["FGRAD_MET"] = "03"
        dfr["dflag"] = 0
        dfr["rating_y"] = dfr["rating_x"].apply(
            lambda x: np.random.choice(
                a=list(d_migration[x].keys()), p=list(d_migration[x].values())
            )
        )
        df_1 = (
            dfr[["group", "rating_x", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_x": "Rating"})
        )
        df_2 = (
            dfr[["group", "rating_y", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_y": "Rating"})
        )
        df_1.loc[0:19, "dflag"] = 1
        df_2.loc[20:39, "dflag"] = 1
        df_2.loc[40:59, "FGRAD_MET"] = "02"
        df_1.loc[60:79, "FGRAD_MET"] = np.nan
        df_2.loc[75:94, "FGRAD_MET"] = np.nan
        df_1.loc[95:109, "Rating"] = np.nan
        df_2.loc[110:124, "Rating"] = np.nan
        df_2 = df_2.drop([i for i in range(100, 119)])

        ## Convert pd.DataFrame to pyspark.sql.DataFrame
        dic = {"group": "str", "Rating": "str", "FGRAD_MET": "str", "dflag": "int64"}

        df_1 = df_1.astype(dic)
        df_2 = df_2.astype(dic)

        data_0 = self.spark.createDataFrame(df_1)
        data_1 = self.spark.createDataFrame(df_2)

        ## Replace np.nan to pyspak native Null values
        data_0 = data_0.withColumn(
            "Rating",
            f.when(data_0["Rating"] == "nan", None).otherwise(data_0["Rating"]),
        )
        data_0 = data_0.withColumn(
            "FGRAD_MET",
            f.when(data_0["FGRAD_MET"] == "nan", None).otherwise(data_0["FGRAD_MET"]),
        )
        data_1 = data_1.withColumn(
            "Rating",
            f.when(data_1["Rating"] == "nan", None).otherwise(data_1["Rating"]),
        )
        data_1 = data_1.withColumn(
            "FGRAD_MET",
            f.when(data_1["FGRAD_MET"] == "nan", None).otherwise(data_1["FGRAD_MET"]),
        )

        return data_0, data_1, mm_true.copy()

    def test_spark_migration_matrix_calculation(self):
        """
        Test if the migration_matrix function calculates the correct
        values for each cell.
        """
        # Get synthetic data.
        df_1, df_2, mm_true = self.get_test_data()

        mm_pandas = spark_migration_matrix(
            data_0=df_1,
            data_1=df_2,
            id_col="group",
            rating_col="Rating",
            model_col="FGRAD_MET",
            default_col="dflag",
        )

        dfmm = mm_pandas.multiply(mm_pandas.N, axis=0)
        mm_pandas = mm_pandas.drop(labels="N", axis=1)
        arr_pandas = mm_pandas.loc[["6", "3", "1"], ["6", "3", "1"]].to_numpy()
        dfmm = dfmm.drop(labels="N", axis=1)
        arr_pandas2 = (
            dfmm[
                [
                    "Defaults",
                    "Other model",
                    "Relationship terminated",
                    "Missing rating",
                    "Missing model",
                ]
            ]
            .sum(axis=0)
            .to_numpy()
        )
        self.assertEqual(
            np.allclose(arr_pandas, mm_true, atol=0.1),
            True,
            msg="'test_migration_matrix_pandas_result' - "
            + "pandas result probabilities not within tolerance."
            + f"\n{arr_pandas} != {mm_true}",
        )
        self.assertEqual(
            np.allclose(
                mm_pandas.sum(axis=1).to_numpy(), np.array([1, 1, 1, 1, 1]), atol=1e-10
            ),
            True,
            msg="'test_migration_matrix_pandas_result' - "
            + "pandas result row sums are not within tolerance."
            + f"\n{mm_pandas.sum(axis=1).to_numpy()} != {np.array([1, 1, 1, 1, 1])}",
        )
        self.assertEqual(
            np.allclose(arr_pandas2, np.array([20, 35, 19, 6, 20]), atol=1e-1),
            True,
            msg="'test_migration_matrix_pandas_result' - "
            + "pandas result K+3 column sums are not within tolerance."
            + f"\n{arr_pandas2} != {np.array([20, 35, 19,  6, 20])}",
        )

    def test_spark_migration_matrix_value_error_id_col_not_found(self):
        """
        Check that an error gets raised if 'id_col' is
        not present within both DataFrames.
        """
        # Get synthetic data.
        df_1, df_2, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            spark_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "id_col_not_found",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )

    def test_spark_migration_matrix_value_error_rating_col_not_found(self):
        """
        Check that an error gets raised if 'rating_col' is
        not present within both DataFrames.
        """
        # Get synthetic data.
        df_1, df_2, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            spark_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "rating_col_not_found",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )

    def test_spark_migration_matrix_value_error_model_col_not_found(self):
        """
        Check that an error gets raised if 'model_col' is
        not present within both DataFrames.
        """
        # Get synthetic data.
        df_1, df_2, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            spark_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "col_not_found",
                "default_col": "dflag",
            },
        )

    def test_spark_migration_matrix_value_error_default_col_not_found(self):
        """
        Check that an error gets raised if 'default_col' is
        not present within both DataFrames.
        """
        # Get synthetic data.
        df_1, df_2, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            spark_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "default_col_not_found",
            },
        )

    def test_spark_migration_matrix_value_error_default_values(self):
        """
        Check that an error gets raised if there are values in the
        default column that are not '1', or '0'.
        """
        df_1, df_2, _ = self.get_test_data()
        pandas_df1 = df_1.toPandas()
        pandas_df1.loc[pandas_df1["dflag"] == 1, "dflag"] = np.nan
        spark_df1 = self.spark.createDataFrame(pandas_df1)
        spark_df1 = spark_df1.withColumn(
            "dflag",
            f.when(spark_df1["dflag"] == "nan", None).otherwise(spark_df1["dflag"]),
        )
        spark_df1 = spark_df1.withColumn(
            "Rating",
            f.when(spark_df1["Rating"] == "nan", None).otherwise(spark_df1["Rating"]),
        )
        spark_df1 = spark_df1.withColumn(
            "FGRAD_MET",
            f.when(spark_df1["FGRAD_MET"] == "nan", None).otherwise(
                spark_df1["FGRAD_MET"]
            ),
        )
        self.assertRaises(
            ValueError,
            spark_migration_matrix,
            **{
                "data_0": spark_df1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )

    def test_spark_migration_matrix_value_error_duplicate_id(self):
        """
        Check that an error gets raised if the values in the
        customer id column are not distinct.
        """
        d_schema = {
            "group": "str",
            "Rating": "str",
            "FGRAD_MET": "str",
            "dflag": "int64",
        }
        df_1, df_2, _ = self.get_test_data()
        pandas_df1 = df_1.toPandas()
        pandas_df1.loc[pandas_df1["dflag"] == 1, "group"] = "ABC123"
        spark_df1 = self.spark.createDataFrame(pandas_df1.astype(d_schema))
        spark_df1 = spark_df1.withColumn(
            "dflag",
            f.when(spark_df1["dflag"] == "nan", None).otherwise(spark_df1["dflag"]),
        )
        spark_df1 = spark_df1.withColumn(
            "Rating",
            f.when(spark_df1["Rating"] == "nan", None).otherwise(spark_df1["Rating"]),
        )
        spark_df1 = spark_df1.withColumn(
            "FGRAD_MET",
            f.when(spark_df1["FGRAD_MET"] == "nan", None).otherwise(
                spark_df1["FGRAD_MET"]
            ),
        )
        self.assertRaises(
            ValueError,
            spark_migration_matrix,
            **{
                "data_0": spark_df1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )


class TestSparkPdPortfolioInformation(PySparkTestCase):
    """
    Unit test case for the 'spark_pd_portfolio_information' function.
    """

    def get_test_data(self):
        """
        Sets up the sample data for the unit tests.
        """
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "c"],
                "rating": ["3+", "4+", "0-"],
                "default": [0, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        ## Convert pandas to pyspark.sql DataFrames
        df1 = self.spark.createDataFrame(df1)
        df2 = self.spark.createDataFrame(df2)

        df1_sum_list = [111, 222, 3, 3, 200, 1]
        df2_sum_list = [444, 333, 3, 2, 303, 2]
        df_change = [
            (df2_sum_list[i] - df1_sum_list[i]) / df1_sum_list[i]
            for i in range(len(df2_sum_list))
        ]
        d_col = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        return df1, df2, df1_sum_list, df2_sum_list, d_col, df_change

    def test_pd_portfolio_information_result(self):
        df1_test, df2_test, sum1, sum2, d_col, dc = self.get_test_data()
        df_res = spark_pd_portfolio_information(df1_test, df2_test, d_col)
        self.assertEqual(
            list(df_res["Beginning of the observation period"]),
            sum1,
            "'Beginning' summary does not match.",
        )
        self.assertEqual(
            list(df_res["End of the observation period"]),
            sum2,
            "'End' summary does not match.",
        )
        self.assertEqual(list(df_res["Change"]), dc, "'Change' summary does not match.")

    def test_pd_portfolio_information_ValueError_incomplete_input_arg(self):
        d = {"RWEA": "rwea", "cust_id": "cid", "rating": "rating", "default": "default"}
        df1_test, df2_test, _, _, _, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            spark_pd_portfolio_information,
            **{"df1": df1_test, "df2": df2_test, "d_colnames": d},
        )

    def test_pd_portfolio_information_ValueError_column_not_found(self):
        df1_test, df2_test, _, _, d_col, _ = self.get_test_data()
        df1_test = df1_test.drop("ead")
        self.assertRaises(
            ValueError,
            spark_pd_portfolio_information,
            **{"df1": df1_test, "df2": df2_test, "d_colnames": d_col},
        )

    def test_pd_portfolio_information_ValueError_column_name_repeated(self):
        d = {
            "RWEA": "rwea",
            "EAD": "rwea",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        df1_test, df2_test, _, _, _, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            spark_pd_portfolio_information,
            **{"df1": df1_test, "df2": df2_test, "d_colnames": d},
        )

    def test_spark_pd_portfolio_information_ValueError_non_unique_id(self):
        """
        Checks that a ValueError is raised if one of the DataFrames contains
        non-unique IDs.
        """
        d_col = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "b"],
                "rating": ["3+", "4+", "0-"],
                "default": [0, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        ## Convert pandas to pyspark.sql DataFrames
        df1 = self.spark.createDataFrame(df1)
        df2 = self.spark.createDataFrame(df2)
        self.assertRaises(ValueError, spark_pd_portfolio_information, df1, df2, d_col)

    def test_spark_pd_portfolio_information_ValueError_invalid_default_flag(self):
        """
        Checks that a ValueError is raised if values other than '1' or '0' are
        present in the default flag column.
        """
        d_col = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "c"],
                "rating": ["3+", "4+", "0-"],
                "default": [2, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        ## Convert pandas to pyspark.sql DataFrames
        df1 = self.spark.createDataFrame(df1)
        df2 = self.spark.createDataFrame(df2)
        self.assertRaises(ValueError, spark_pd_portfolio_information, df1, df2, d_col)


class TestPdPortfolioInformation(PySparkTestCase):
    """
    Test cases for the 'pd_portfolio_information' function.
    """

    @staticmethod
    def get_test_data():
        """
        Sets up the sample data for the unit tests.
        """
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "c"],
                "rating": ["3+", "4+", "0-"],
                "default": [0, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        return df1, df2

    def test_pd_portfolio_information_type_error_1(self):
        """
        Tests that a TypeError gets raised if neither a pandas nor
        pyspark DataFrame are passed as arguments.
        """
        self.assertRaises(TypeError, pd_portfolio_information, 1, 2, 3)

    def test_pd_portfolio_information_type_error_2(self):
        """
        Tests that a TypeError gets raised if both function arguments
        'df1' and 'df2' are not the same type.
        """
        test_df1 = pd.DataFrame.from_dict({"a": [1, 2, 3], "b": [4, 5, 6]})
        test_df2 = self.spark.createDataFrame(test_df1)
        self.assertRaises(TypeError, pd_portfolio_information, test_df1, test_df2, 1)

    def test_pd_portfolio_inofrmation_same_result(self):
        """
        Executes 'pd_portfolio_information' with both pandas and
        Spark DataFrames, then compares the results to ensure
        they are identical.
        """
        pandas_df1, pandas_df2 = self.get_test_data()
        spark_df1, spark_df2 = (
            self.spark.createDataFrame(pandas_df1),
            self.spark.createDataFrame(pandas_df2),
        )
        d_cols = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        pandas_result = pd_portfolio_information(pandas_df1, pandas_df2, d_cols)
        spark_result = pd_portfolio_information(spark_df1, spark_df2, d_cols)
        self.assertTrue(pandas_result.equals(spark_result))


class TestAdfSummary(PySparkTestCase):
    """
    Test class for the 'adf_summary' super function. Tests both
    pandas and pyspark functionality.
    """

    @staticmethod
    def get_test_df():
        """
        Sample data for ADF summary functions.
        """
        d_sample_data = {
            "rating_col": ["1", "2", "2", "3", "3", "9"],
            "customer_id": [f"A00{i}" for i in range(6)],
            "group": ["1", "1", "2", "3", "4", "4"],
            "def_flag": [1, 1, 0, 1, 0, 1],
            "PD": [0.01, 0.02, 0.02, 0.03, 0.03, 0.09],
            "PDG": [0.01, 0.01, 0.02, 0.03, 0.03, 0.03],
            "ratG": ["1", "1", "2", "3", "3", "3"],
            "country": ["DK", "DK", "DK", "SE", "SE", "DK"],
            "ORGEXP": [100, 200, 300, 400, 500, 100],
        }
        df_sample_data = pd.DataFrame.from_dict(d_sample_data)
        df_sample_data = rating_cats(
            df_sample_data, "ratG", category_list=["1", "2", "3", "9"]
        )
        return df_sample_data

    def test_adf_summary_type_error(self):
        """
        Tests that a TypeError gets raised if the input DataFrame is
        neither a pandas nor pyspark DataFrame.
        """
        self.assertRaises(TypeError, adf_summary, 1, 2, 3)

    def test_adf_summary_same_result(self):
        """
        Tests that passing a pandas or spark DataFrame to
        the function returns exactly the same result.
        """
        pandas_df = self.get_test_df()
        spark_df = self.spark.createDataFrame(pandas_df)
        pandas_result = adf_summary(
            pandas_df, "customer_id", "def_flag", "ratG", "ORGEXP"
        )
        spark_result = adf_summary(
            spark_df, "customer_id", "def_flag", "ratG", "ORGEXP"
        )
        spark_result = rating_cats(spark_result, "ratG", ["1", "2", "3", "9"])
        pd.testing.assert_frame_equal(pandas_result, spark_result, check_dtype=False)


class TestMigrationMatrix(PySparkTestCase):
    """
    Test class for the 'migration_matrix' super function.
    """

    @staticmethod
    def get_test_data():
        """
        Creates 2 tables of synthetic data for testing calculations.
        """
        d_migration = {
            "6": {"6": 0.8, "3": 0.2, "1": 0.0},
            "3": {"6": 0.2, "3": 0.7, "1": 0.1},
            "1": {"6": 0.1, "3": 0.3, "1": 0.6},
        }
        num_grades = len(d_migration)
        num_act_per_grade = 1_000
        total_act = num_grades * num_act_per_grade
        dfr = pd.DataFrame.from_dict(
            {
                "group": [
                    "XT" + str(i).zfill(int(np.log10(total_act) + 2))
                    for i in range(total_act)
                ],
                "rating_x": [
                    np.random.choice(["6", "3", "1"]) for i in range(total_act)
                ],
            }
        )
        dfr["FGRAD_MET"] = "03"
        dfr["dflag"] = 0
        dfr["rating_y"] = dfr["rating_x"].apply(
            lambda x: np.random.choice(
                a=list(d_migration[x].keys()), p=list(d_migration[x].values())
            )
        )
        df_1 = (
            dfr[["group", "rating_x", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_x": "Rating"})
        )
        df_2 = (
            dfr[["group", "rating_y", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_y": "Rating"})
        )
        df_1.loc[0:19, "dflag"] = 1
        df_2.loc[20:39, "dflag"] = 1
        df_2.loc[40:59, "FGRAD_MET"] = "02"
        df_1.loc[60:79, "FGRAD_MET"] = np.nan
        df_2.loc[75:94, "FGRAD_MET"] = np.nan
        df_1.loc[95:109, "Rating"] = np.nan
        df_2.loc[110:124, "Rating"] = np.nan
        df_2 = df_2.drop([i for i in range(100, 119)])

        return df_1.copy(), df_2.copy()

    def get_test_data_no_missing(self):
        """
        Returns some sample data where models and ratings are not
        changed or missing (a clean data set). Both pandas
        and spark DataFrames.
        """
        d_migration = {
            "6": {"6": 0.8, "3": 0.2, "1": 0.0},
            "3": {"6": 0.2, "3": 0.7, "1": 0.1},
            "1": {"6": 0.1, "3": 0.3, "1": 0.6},
        }

        mm_true = (
            pd.DataFrame.from_dict(d_migration, orient="index")
            .loc[["6", "3", "1"]]
            .to_numpy()
        )
        num_grades = len(d_migration)
        num_act_per_grade = 10_000
        total_act = num_grades * num_act_per_grade
        dfr = pd.DataFrame.from_dict(
            {
                "group": [
                    "XT" + str(i).zfill(int(np.log10(total_act) + 2))
                    for i in range(total_act)
                ],
                "rating_x": [
                    np.random.choice(["6", "3", "1"]) for i in range(total_act)
                ],
            }
        )
        dfr["FGRAD_MET"] = "03"
        dfr["dflag"] = 0
        dfr["rating_y"] = dfr["rating_x"].apply(
            lambda x: np.random.choice(
                a=list(d_migration[x].keys()), p=list(d_migration[x].values())
            )
        )
        df_1 = (
            dfr[["group", "rating_x", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_x": "Rating"})
        )
        df_2 = (
            dfr[["group", "rating_y", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_y": "Rating"})
        )
        df_1.loc[0:19, "dflag"] = 1
        df_2.loc[20:39, "dflag"] = 1

        ## Convert pd.DataFrame to pyspark.sql.DataFrame
        dic = {"group": "str", "Rating": "str", "FGRAD_MET": "str", "dflag": "int64"}

        df_1 = df_1.astype(dic)
        df_2 = df_2.astype(dic)

        data_0 = self.spark.createDataFrame(df_1)
        data_1 = self.spark.createDataFrame(df_2)

        ## Replace np.nan to pyspak native Null values
        data_0 = data_0.withColumn(
            "Rating",
            f.when(data_0["Rating"] == "nan", None).otherwise(data_0["Rating"]),
        )
        data_0 = data_0.withColumn(
            "FGRAD_MET",
            f.when(data_0["FGRAD_MET"] == "nan", None).otherwise(data_0["FGRAD_MET"]),
        )
        data_1 = data_1.withColumn(
            "Rating",
            f.when(data_1["Rating"] == "nan", None).otherwise(data_1["Rating"]),
        )
        data_1 = data_1.withColumn(
            "FGRAD_MET",
            f.when(data_1["FGRAD_MET"] == "nan", None).otherwise(data_1["FGRAD_MET"]),
        )

        return df_1, df_2, data_0, data_1

    def test_migration_matrix_type_error_1(self):
        """
        Tests that a TypeError is raised when the input DataFrames
        are not of the same type.
        """
        df1, df2 = self.get_test_data()
        # Schema for conversion to pyspark.sql.DataFrame.
        d_schema = {
            "group": "str",
            "Rating": "str",
            "FGRAD_MET": "str",
            "dflag": "int64",
        }
        spark_df2 = self.spark.createDataFrame(df2.astype(d_schema))
        self.assertRaises(
            TypeError,
            migration_matrix,
            df1,
            spark_df2,
            "group",
            "Rating",
            "FGRAD_MET",
            "dflag",
        )

    def test_migration_matrix_type_error_2(self):
        """
        Tests that a TypeError is raised when the input DataFrames
        are not pandas or pyspark DataFrames.
        """
        self.assertRaises(
            TypeError, migration_matrix, 1, 2, "group", "Rating", "FGRAD_MET", "dflag"
        )

    def test_migration_matrix_same_result(self):
        """
        Tests that the 'migration_matrix' function returns the same
        results whether pandas or pyspark DataFrames are passed.
        """
        pandas_df1, pandas_df2 = self.get_test_data()
        # Schema for conversion to pyspark.sql.DataFrame.
        d_schema = {
            "group": "str",
            "Rating": "str",
            "FGRAD_MET": "str",
            "dflag": "int64",
        }
        spark_df1 = self.spark.createDataFrame(pandas_df1.astype(d_schema))
        spark_df2 = self.spark.createDataFrame(pandas_df2.astype(d_schema))

        ## Replace np.nan to pyspak native Null values
        spark_df1 = spark_df1.withColumn(
            "Rating",
            f.when(spark_df1["Rating"] == "nan", None).otherwise(spark_df1["Rating"]),
        )
        spark_df1 = spark_df1.withColumn(
            "FGRAD_MET",
            f.when(spark_df1["FGRAD_MET"] == "nan", None).otherwise(
                spark_df1["FGRAD_MET"]
            ),
        )
        spark_df2 = spark_df2.withColumn(
            "Rating",
            f.when(spark_df2["Rating"] == "nan", None).otherwise(spark_df2["Rating"]),
        )
        spark_df2 = spark_df2.withColumn(
            "FGRAD_MET",
            f.when(spark_df2["FGRAD_MET"] == "nan", None).otherwise(
                spark_df2["FGRAD_MET"]
            ),
        )
        # Calculate result.
        pandas_result = migration_matrix(
            pandas_df1, pandas_df2, "group", "Rating", "FGRAD_MET", "dflag"
        )
        spark_result = migration_matrix(
            spark_df1, spark_df2, "group", "Rating", "FGRAD_MET", "dflag"
        )
        pandas_result.index = pandas_result.index.astype("str")
        spark_result.index = spark_result.index.astype("str")
        pd.testing.assert_frame_equal(
            pandas_result, spark_result, check_dtype=False, check_index_type=False
        )

    def test_migration_matrix_same_result_no_missing(self):
        """
        Tests that the 'migration_matrix' function returns the same
        results whether pandas or pyspark DataFrames are passed,
        when there are no missing or changed ratings or models
        in the data.
        """
        pandas_df1, pandas_df2, spark_df1, spark_df2 = self.get_test_data_no_missing()

        # Calculate result.
        pandas_result = migration_matrix(
            pandas_df1, pandas_df2, "group", "Rating", "FGRAD_MET", "dflag"
        )
        spark_result = migration_matrix(
            spark_df1, spark_df2, "group", "Rating", "FGRAD_MET", "dflag"
        )
        pandas_result.index = pandas_result.index.astype("str")
        spark_result.index = spark_result.index.astype("str")
        pd.testing.assert_frame_equal(
            pandas_result, spark_result, check_dtype=False, check_index_type=False
        )

    def test_migration_matrix_correct_rows_columns_pandas(self):
        """
        Checks that the correct rows and columns are returned when passing
        pandas.DataFrames. Required since column manipulation is performed
        in the super function.
        """
        pandas_df1, pandas_df2 = self.get_test_data()
        mm = migration_matrix(
            pandas_df1, pandas_df2, "group", "Rating", "FGRAD_MET", "dflag"
        )
        # Check that columns are as expected.
        self.assertListEqual(
            list(mm.columns),
            [
                "6",
                "3",
                "1",
                "Missing model",
                "Missing rating",
                "Defaults",
                "Other model",
                "Relationship terminated",
                "N",
            ],
        )
        # Check that row indices are as expected.
        self.assertListEqual(
            list(mm.index), ["6", "3", "1", "Missing model", "Missing rating"]
        )

    def test_migration_matrix_correct_rows_columns_spark(self):
        """
        Checks that the correct rows and columns are returned when passing
        pyspark.sql.DataFrames. Required since column manipulation is performed
        in the super function.
        """
        pandas_df1, pandas_df2 = self.get_test_data()
        # Schema for conversion to pyspark.sql.DataFrame.
        d_schema = {
            "group": "str",
            "Rating": "str",
            "FGRAD_MET": "str",
            "dflag": "int64",
        }
        spark_df1 = self.spark.createDataFrame(pandas_df1.astype(d_schema))
        spark_df2 = self.spark.createDataFrame(pandas_df2.astype(d_schema))
        ## Replace np.nan to pyspak native Null values
        spark_df1 = spark_df1.withColumn(
            "Rating",
            f.when(spark_df1["Rating"] == "nan", None).otherwise(spark_df1["Rating"]),
        )
        spark_df1 = spark_df1.withColumn(
            "FGRAD_MET",
            f.when(spark_df1["FGRAD_MET"] == "nan", None).otherwise(
                spark_df1["FGRAD_MET"]
            ),
        )
        spark_df2 = spark_df2.withColumn(
            "Rating",
            f.when(spark_df2["Rating"] == "nan", None).otherwise(spark_df2["Rating"]),
        )
        spark_df2 = spark_df2.withColumn(
            "FGRAD_MET",
            f.when(spark_df2["FGRAD_MET"] == "nan", None).otherwise(
                spark_df2["FGRAD_MET"]
            ),
        )
        mm = migration_matrix(
            spark_df1, spark_df2, "group", "Rating", "FGRAD_MET", "dflag"
        )
        # Check that columns are as expected.
        self.assertListEqual(
            list(mm.columns),
            [
                "6",
                "3",
                "1",
                "Missing model",
                "Missing rating",
                "Defaults",
                "Other model",
                "Relationship terminated",
                "N",
            ],
        )
        # Check that row indices are as expected.
        self.assertListEqual(
            list(mm.index), ["6", "3", "1", "Missing model", "Missing rating"]
        )


class TestSparkLgdContingencyTable(PySparkTestCase):
    """
    Unit test case for the spark_lgd_contingency_table function.

    Approach summary.spark_lgd_contingency_table:
        Estimated and realised LGDs are discretionised on facility
        level using pyspark Bucketize.

        The contingency frequency matrix is created using the pyspark
        crosstab function.

    Approach test_summary.lgd_contingency_table:
        Contingency table is calculated using the lgd_contingency_table
        function.
    """

    @staticmethod
    def create_dummy_lgd_data(self, bins):

        # Randomly create data
        dummy_pred_lgd = [random.choice(bins) for i in range(10000)]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(10000)]

        df = pd.DataFrame(
            list(zip(dummy_pred_lgd, dummy_act_lgd)), columns=["pred_lgd", "act_lgd"]
        )

        return df

    def test_lgd_contingency_table_ecb_result(self):
        """
        Test for the correct calculation of the lgd contingency table using
        ECB bins using randomly created actual LGD dummy data.

        The ECB bins were extracted from
        "LEICode_LGD_ModelID_EndOfObservationPeriod_versionNumber.xlsx"
        """
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "ecb")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "ecb"
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of LGD contingency tables with ECB binning.",
            )

    def test_lgd_contingency_table_lgd_result(self):
        """
        Test for the correct calculation of the lgd contingency table using
        LGD created bins (discretisation on the basis of the estimated LGD)
        using randomly created actual LGD dummy data.

        The LGD bins were extracted from "lgd.sas7bdat" with the function
        df['lgd_estimate'].unique()
        """
        # LGD bins
        bins = [
            0.054,
            0.173,
            0.205,
            0.224,
            0.227,
            0.243,
            0.265,
            0.27,
            0.272,
            0.279,
            0.293,
            0.302,
            0.318,
            0.319,
            0.331,
            0.332,
            0.341,
        ]
        df = self.create_dummy_lgd_data(self, bins)

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "lgd")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "lgd"
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of LGD contingency tables with LGD binning.",
            )

    def test_lgd_contingency_table_manual_result(self):
        """
        Test for the correct calculation of the lgd contingency table using
        manually created bins based on randomly created actual LGD dummy data.
        """
        # manual bins
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of LGD contingency tables with manual binning.",
            )

    def test_lgd_contingency_table_negative_actual_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an actual LGD < 0
        """
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "act_lgd"] = -1

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "ecb")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "ecb"
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a negative actual LGD",
            )

    def test_lgd_contingency_table_boundary_actual_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an actual LGD equal to the right boundary (0.25).
        """
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "act_lgd"] = 0.25

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "ecb")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "ecb"
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a boundary actual LGD",
            )

    def test_lgd_contingency_table_large_pred_lgd_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an predicted LGD equal to 2.
        """
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "pred_lgd"] = 2

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "lgd")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "lgd"
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a boundary actual LGD",
            )

    def test_lgd_contingency_table_large_pred_lgd_ecb(self):
        """
        Test for the correct calculation of the ecb lgd contingency table when
        there is an predicted LGD equal to 2.
        """
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "pred_lgd"] = 2

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "ecb")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "ecb"
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a boundary actual LGD",
            )

    def test_lgd_contingency_table_large_pred_lgd_manual(self):
        """
        Test for the correct calculation of the manual lgd contingency table
        when there is an predicted LGD equal to 2.
        """
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "pred_lgd"] = 2

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=[0.25, 0.5, 0.75, 1]
        )
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", "manual", bins=[0.25, 0.5, 0.75, 1]
        )
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a boundary actual LGD",
            )

    def test_lgd_contingency_table_binning_type_auto_lgd_1(self):
        """
        Test for the correct calculation of the lgd contingency table when
        default option for binning_type = 'auto' is selected.

        This test should activate the binning_type = "lgd"
        """
        # Test when number of pools < 20:
        bins = [0.2, 0.4, 0.6, 0.8, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(df_spark, "pred_lgd", "act_lgd")
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using binning_type='auto' "
                "where the lgd option should be activated.",
            )

    def test_lgd_contingency_table_binning_type_auto_lgd_2(self):
        """
        Test for the correct calculation of the lgd contingency table when
        default option for binning_type = 'auto' is selected.

        This test should activate the binning_type = "ecb"
        """
        # Test when number of pools > 20:
        lgd_estimates = [
            0.05,
            0.1,
            0.15,
            0.2,
            0.25,
            0.3,
            0.35,
            0.4,
            0.45,
            0.5,
            0.55,
            0.6,
            0.65,
            0.7,
            0.75,
            0.8,
            0.85,
            0.9,
            0.95,
            0.975,
            1,
        ]
        df = self.create_dummy_lgd_data(self, lgd_estimates)

        # Pandas contingency matrix
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd")
        freq_mat_1 = freq_mat.values.tolist()

        # Pyspark contingency matrix
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(df_spark, "pred_lgd", "act_lgd")
        freq_mat_2 = freq_mat_spark.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using binning_type='auto' "
                "where the lgd option should be activated.",
            )

    def test_lgd_contingency_table_intervals(self):
        """
        Test for the correct calculation of the lgd contingency table when
        default option for binning_type = 'auto' is selected.

        This test should activate the binning_type = "ecb"
        """
        # Bins
        bins = [0, 0.25, 0.5, 0.75, 1.0]
        df = self.create_dummy_lgd_data(self, bins)

        # Intervals from lgd_contingency_table
        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", binning_type="ecb"
        )
        intervals_1 = [item for item in freq_mat.columns]

        # Recreate intervals
        df_spark = self.spark.createDataFrame(df)
        freq_mat_spark = spark_lgd_contingency_table(
            df_spark, "pred_lgd", "act_lgd", binning_type="ecb"
        )
        intervals_2 = freq_mat_spark.columns

        # Compare contingency matrices on row level
        for i in range(len(intervals_2)):
            list_1 = intervals_1[i]
            list_2 = intervals_2[i]
            self.assertEqual(list_1, list_2, msg=f"Intervals do not match up")

    def test_lgd_contingency_table_ValueError_1(self):
        """
        Test that a ValueError is raised if incorrect value for bins is passed
        when option "manual" is selected for binning_type

        ValueError: if binning_type = "manual" and not isinstance(bins, list)
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])
        df_spark = self.spark.createDataFrame(df)

        # ValueError for binning_type = "manual" and not isinstance(bins, list)
        binning_type = "manual"
        bins = ""
        self.assertRaises(
            ValueError,
            spark_lgd_contingency_table,
            **{
                "data": df_spark,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_ValueError_2(self):
        """
        Test that a ValueError is raised if incorrect value for bins is passed
        when option "manual" is selected for binning_type

        ValueError: if binning_type = "manual" and bins = []
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])
        df_spark = self.spark.createDataFrame(df)

        # ValueError for binning_type = "manual" and bins = []
        binning_type = "manual"
        bins = []
        self.assertRaises(
            ValueError,
            spark_lgd_contingency_table,
            **{
                "data": df_spark,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_ValueError_3(self):
        """
        Test that a ValueError is raised if incorrect value for bins is passed
        when option "manual" is selected for binning_type

        ValueError: if binning_type = "manual" and bins = [-1] i.e. smaller than 0
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])
        df_spark = self.spark.createDataFrame(df)

        # ValueError for binning_type = "manual" and bins = [-1] (<0)
        binning_type = "manual"
        bins = [-1, 0.25, 0.5, 0.75, 1]
        self.assertRaises(
            ValueError,
            spark_lgd_contingency_table,
            **{
                "data": df_spark,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_ValueError_4(self):
        """
        Test that a ValueError is raised if incorrect value when incorrect
        value for binning_type is specified
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])
        df_spark = self.spark.createDataFrame(df)

        # ValueError for binning_type is incorrect value
        binning_type = "incorrect_value"
        bins = [-1, 0.25, 0.5, 0.75, 1]
        self.assertRaises(
            ValueError,
            spark_lgd_contingency_table,
            **{
                "data": df_spark,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_lgd_t_test_comparison(self):
        """
        Test that contingency table created by spark and pandas functions are
        in line with results from t-test with binning_type = lgd
        """
        sample_df = pd.DataFrame.from_dict(
            {
                "customer_id": [str(i) for i in range(25)],
                "lgd_estimate": [0.1, 0.2, 0.3, 0.4, 0.5] * 5,
                "lgd_actual": np.random.uniform(0.001, 2.0, 25),
            }
        )
        spark_df = self.spark.createDataFrame(sample_df)

        type_of_binning = "lgd"
        use_bins = [0.2, 0.25, 0.3]

        # pandas contingency table
        pandas_result = pandas_lgd_contingency_table(
            sample_df, "lgd_estimate", "lgd_actual", type_of_binning
        )
        list_pd_result = pandas_result.sum(1).tolist()

        # spark contingency table
        spark_result = spark_lgd_contingency_table(
            spark_df, "lgd_estimate", "lgd_actual", type_of_binning
        )
        list_spark_result = spark_result.sum(1).tolist()

        # t-test
        t_test_result = t_test(
            group_1_data=sample_df,
            test_type="paired",
            col_names={
                "id_col": "customer_id",
                "est_col": "lgd_estimate",
                "act_col": "lgd_actual",
            },
            binning_type=type_of_binning,
            bins=use_bins,
        )
        list_t_test = t_test_result.loc[
            t_test_result.index != "portfolio", "N_group1"
        ].tolist()

        list_t_test = [0 if np.isnan(x) else x for x in list_t_test]

        # Comparison between pandas contingency table results and t-test results
        self.assertListEqual(
            list_pd_result,
            list_t_test,
            msg=f"Pandas contingency table and t-test results " "do not match up",
        )

        # Comparison between spark contingency table results and t-test results
        self.assertListEqual(
            list_spark_result,
            list_t_test,
            msg=f"Spark contingency table and t-test results " "do not match up",
        )

    def test_lgd_contingency_table_ecb_t_test_comparison(self):
        """
        Test that contingency table created by spark and pandas functions are
        in line with results from t-test with binning_type = ecb
        """
        sample_df = pd.DataFrame.from_dict(
            {
                "customer_id": [str(i) for i in range(25)],
                "lgd_estimate": [0.1, 0.2, 0.3, 0.4, 0.5] * 5,
                "lgd_actual": np.random.uniform(0.001, 2.0, 25),
            }
        )
        print(sample_df)
        print(type(sample_df))
        spark_df = self.spark.createDataFrame(sample_df)

        type_of_binning = "ecb"
        use_bins = [0.2, 0.25, 0.3]

        # pandas contingency table
        pandas_result = pandas_lgd_contingency_table(
            sample_df, "lgd_estimate", "lgd_actual", type_of_binning
        )
        list_pd_result = pandas_result.sum(1).tolist()

        # spark contingency table
        spark_result = spark_lgd_contingency_table(
            spark_df, "lgd_estimate", "lgd_actual", type_of_binning
        )
        list_spark_result = spark_result.sum(1).tolist()

        # t-test
        t_test_result = t_test(
            group_1_data=sample_df,
            test_type="paired",
            col_names={
                "id_col": "customer_id",
                "est_col": "lgd_estimate",
                "act_col": "lgd_actual",
            },
            binning_type=type_of_binning,
            bins=use_bins,
        )
        list_t_test = t_test_result.loc[
            t_test_result.index != "portfolio", "N_group1"
        ].tolist()

        list_t_test = [0 if np.isnan(x) else x for x in list_t_test]

        # Comparison between pandas contingency table results and t-test results
        self.assertListEqual(
            list_pd_result,
            list_t_test,
            msg=f"Pandas contingency table and t-test results " "do not match up",
        )

        # Comparison between spark contingency table results and t-test results
        self.assertListEqual(
            list_spark_result,
            list_t_test,
            msg=f"Spark contingency table and t-test results " "do not match up",
        )

    def test_lgd_contingency_table_manual_t_test_comparison(self):
        """
        Test that contingency table created by spark and pandas functions are
        in line with results from t-test with binning_type = manual
        """
        sample_df = pd.DataFrame.from_dict(
            {
                "customer_id": [str(i) for i in range(25)],
                "lgd_estimate": [0.1, 0.2, 0.3, 0.4, 0.5] * 5,
                "lgd_actual": np.random.uniform(0.001, 2.0, 25),
            }
        )
        spark_df = self.spark.createDataFrame(sample_df)

        type_of_binning = "manual"
        use_bins = [0.2, 0.25, 0.3]

        # pandas contingency table
        pandas_result = pandas_lgd_contingency_table(
            sample_df, "lgd_estimate", "lgd_actual", type_of_binning, bins=use_bins
        )
        list_pd_result = pandas_result.sum(1).tolist()

        # spark contingency table
        spark_result = spark_lgd_contingency_table(
            spark_df, "lgd_estimate", "lgd_actual", type_of_binning, bins=use_bins
        )
        list_spark_result = spark_result.sum(1).tolist()

        # t-test
        t_test_result = t_test(
            group_1_data=sample_df,
            test_type="paired",
            col_names={
                "id_col": "customer_id",
                "est_col": "lgd_estimate",
                "act_col": "lgd_actual",
            },
            binning_type=type_of_binning,
            bins=use_bins,
        )
        list_t_test = t_test_result.loc[
            t_test_result.index != "portfolio", "N_group1"
        ].tolist()

        list_t_test = [0 if np.isnan(x) else x for x in list_t_test]

        # Comparison between pandas contingency table results and t-test results
        self.assertListEqual(
            list_pd_result,
            list_t_test,
            msg=f"Pandas contingency table and t-test results " "do not match up",
        )

        # Comparison between spark contingency table results and t-test results
        self.assertListEqual(
            list_spark_result,
            list_t_test,
            msg=f"Spark contingency table and t-test results " "do not match up",
        )


class TestLgdContingencyTable(PySparkTestCase):
    """
    Unit test case for the super function lgd_contigency_table function.
    """

    @staticmethod
    def create_dummy_lgd_data(self, bins):

        # Randomly create data
        dummy_pred_lgd = [random.choice(bins) for i in range(10000)]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(10000)]

        df = pd.DataFrame(
            list(zip(dummy_pred_lgd, dummy_act_lgd)), columns=["pred_lgd", "act_lgd"]
        )

        return df

    def test_lgd_contingency_table_TypeError(self):
        """
        Test that a TypeError is raised if not a Pandas or Spark dataframe is
        given as data input
        """
        df = "String_instead_of_data_frame"

        # ValueError for binning_type = "manual" and bins = [-1] (<0)
        binning_type = "auto"
        bins = [-1, 0.25, 0.5, 0.75, 1]
        self.assertRaises(
            TypeError,
            lgd_contingency_table,
            **{
                "data": df,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_same_result(self):
        """
        Tests that passing a pandas or spark DataFrame to
        the function returns exactly the same result.
        """
        bins = [0.25, 0.5, 0.75, 1]
        pandas_df = self.create_dummy_lgd_data(self, bins)
        spark_df = self.spark.createDataFrame(pandas_df)
        pandas_result = lgd_contingency_table(pandas_df, "pred_lgd", "act_lgd", "ecb")
        spark_result = lgd_contingency_table(spark_df, "pred_lgd", "act_lgd", "ecb")
        pandas_result_list = pandas_result.values.tolist()
        spark_result_list = spark_result.values.tolist()

        # Compare contingency matrices on row level
        for i in range(len(pandas_result_list)):
            freq_list_1 = pandas_result_list[i]
            freq_list_2 = spark_result_list[i]
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of pandas and spark dataframes",
            )


if __name__ == "__main__":
    unittest.main()
