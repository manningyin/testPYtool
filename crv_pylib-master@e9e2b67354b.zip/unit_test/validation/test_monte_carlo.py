"""
TEST_MONTE_CARLO.PY

Description:
    Unit testing for the functions in 'crv.validation.monte_carlo.py'.

"""

# Imports.
import unittest
import numpy as np
import pandas as pd

from crv.validation.monte_carlo import MonteCarloPD
from crv.validation.differentiation import auc


class TestMonteCarloPd(unittest.TestCase):
    """
    A test class containing unit tests for the
    'crv.validation.monte_carlo.MontoCarloPD' class.
    """

    @staticmethod
    def sample_function(df, default_count_col, customer_count_col, pd_col):
        """
        A sample function as input for the 'crv.validation.monte_carlo.MontoCarloPD'
        class constructor. This function accepts the same arguments as the
        crv.validation.quant_tests.auc' function and return the same value of 1.0.

        This is a mock function intended to return a deterministic result for unit
        testing purposed.

        Args:
            df (pandas.DataFrame): A sample DataFrame containing 'rating',
             'D', 'N', and 'PD' colummns.

            default_count_col (str): Name of column containing the default count.

            customer_count_col (str): Name of column containing the customer count.

            pd_col (str): Name of the column containing the corresponding PD.

        Returns:
            (float): 1.0, a sample score value.
        """
        return 1.0, 5.0

    @staticmethod
    def get_sample_data():
        """
        Returns a small sample pandas.DataFrame for unit testing.
        """
        return pd.DataFrame.from_dict(
            {
                "rating": ["A", "B", "C"],
                "D": [2, 3, 4],
                "N": [20, 40, 60],
                "PD": [0.11, 0.06, 0.02],
            }
        )

    def test_monte_carlo_pd_run_single_round(self):
        """
        Constructs an object and calls the '_run_single_round' method.
        """
        mc_obj = MonteCarloPD(self.get_sample_data(), test_func=self.sample_function)
        single_round_result = mc_obj._run_single_round(1)
        self.assertEqual(single_round_result, (1.0, 5.0))

    def test_monte_carlo_pd_run(self):
        """
        Constructs an object and calls the 'run' method, then inspects
        the 'results' attribute to confirm that it has produced the
        correct number of rounds.
        """
        mc_obj = MonteCarloPD(self.get_sample_data(), test_func=self.sample_function)
        test_num_rounds = 27
        mc_obj.run(test_num_rounds)
        len_results = len(mc_obj.results[0])
        self.assertEqual(test_num_rounds, len_results)

    def test_monte_carlo_pd_get_test_results(self):
        """
        Constructs an object and calls the 'get_test_reuslts' method,
        and checks for the correct output using the 'sample_function'.
        """
        mc_obj = MonteCarloPD(self.get_sample_data(), test_func=self.sample_function)
        test_result = mc_obj.get_test_results()
        self.assertEqual(test_result, self.sample_function(1, 2, 3, 4))

    def test_monte_carlo_pd_get_ci(self):
        """
        Constructs an object and calls the 'get_ci' method, and checks
        for the correct output using the 'sample_function'.
        """
        mc_obj = MonteCarloPD(self.get_sample_data(), test_func=self.sample_function)
        mc_obj.run(10)
        quantile_result = [list(ci) for ci in mc_obj.get_ci(alpha=0.9)]
        self.assertListEqual(quantile_result, [[1.0, 1.0], [5.0, 5.0]])

    def test_monte_carlo_pd_get_test_results_auc(self):
        """
        Constructs an object and calls the 'get_test_reuslts' method,
        and checks for the correct output using the 'auc' function.
        """
        mc_obj = MonteCarloPD(self.get_sample_data(), test_func=auc)
        test_result = mc_obj.get_test_results()
        correct_result = auc(self.get_sample_data(), "D", "N", "PD")
        self.assertEqual(test_result, correct_result)

    def test_monte_carlo_pd_get_ci_auc(self):
        """
        Constructs an object and calls the 'get_ci' method, and checks
        for the correct output using the 'auc' function.
        """
        mc_obj = MonteCarloPD(self.get_sample_data(), test_func=auc)
        mc_obj.run(10)
        test_alpha = 0.9
        quantile_result = [list(r) for r in mc_obj.get_ci(alpha=test_alpha)]
        res_list = mc_obj.results
        test_quantiles = [(1 - test_alpha) / 2, 1 - (1 - test_alpha) / 2]
        correct_ci = [
            list(np.quantile(res_list_i, test_quantiles)) for res_list_i in res_list
        ]
        self.assertListEqual(quantile_result, correct_ci)


if __name__ == "__main__":
    unittest.main()
