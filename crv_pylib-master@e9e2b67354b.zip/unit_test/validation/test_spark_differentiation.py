"""
# ============================================================================
# TEST_SPARK_DIFFERENTIATION.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.VALIDATION.DIFFERENTIATION.PY
#
# This module is intended to contain and execute the test cases for
# only those functions in the 'crv.validation.differentiation' module,
# which make use of the 'pyspark' package.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Lee MacKenzie Fischer <G01679>
# ============================================================================
"""

# Imports.
import unittest
import numpy as np
import pandas as pd
import pyspark.sql.functions as f
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.window import Window
from unit_test.pyspark_test_class import PySparkTestCase
from crv.validation.differentiation import (
    _add_deciles_spark,
    _calculate_cumulative_percentage_spark,
    _spark_lcr,
    _trapz_spark,
    loss_capture_ratio,
    kolmogorov_smirnov_2_sample,
)


class TestSparkKolgomorovSmirnov2Sample(PySparkTestCase):
    """
    Test class for function
    'crv.validation.differentiation._spark_kolmogorov_smirnov_2_sample'.
    """

    def test_spark_KS_2Sample_spark_DataFrame(self):
        """
        Tests that the function works with a pyspark.sql.DataFrame and no
        exception is raised
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.1, 0.2
        data1 = pd.Series(np.random.normal(mu1, sigma1, 100))
        data2 = pd.Series(np.random.normal(mu2, sigma2, 100))

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        raised = False
        try:
            kolmogorov_smirnov_2_sample(
                data1=data1,
                data2=data2,
                spark_session=self.spark,
                alternative="two-sided",
                mode="auto",
            )
        except:
            raised = True

        self.assertFalse(raised, "Function does not accept pyspark.sql.DataFrame")

    def test_spark_KS_2Sample_exact_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing mode="exact"
        R code: >>> ks.test(data1, data2)
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.5, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1,
            data2=data2,
            spark_session=self.spark,
            alternative="two-sided",
            mode="auto",
        )
        R_stat, R_pvalue = 1, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 8)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 8)

    def test_spark_KS_2Sample_asymp_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing mode="exact"
        R code: >>> ks.test(data1, data2)
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.5, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1,
            data2=data2,
            spark_session=self.spark,
            alternative="two-sided",
            mode="auto",
        )
        R_stat, R_pvalue = 1, 1.11e-15

        self.assertAlmostEqual(P_stat, R_stat, 8)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 8)

    def test_spark_KS_2Sample_greater_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing alternative="greater"
        R code: >>> ks.test(data1, data2, alternative="gr")
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.2, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1,
            data2=data2,
            spark_session=self.spark,
            alternative="two-sided",
            mode="auto",
        )

        R_stat, R_pvalue = 0.75, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 8)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 8)

    def test_spark_KS_2Sample_less_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing alternative="less"
        R code: >>> ks.test(data1, data2, alternative="less")
        """
        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1,
            data2=data2,
            spark_session=self.spark,
            alternative="less",
            mode="auto",
        )
        R_stat, R_pvalue = 0.61, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 2)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 2)

    def test_spark_KS_2Sample_different_sample_size_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when data1 and data2 have different sample sizes
        R code: >>> ks.test(data1, data2)
        """
        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 50)
        data2 = np.random.normal(mu2, sigma2, 100)

        df_pandas_1 = pd.DataFrame(data=data1, columns=["data1"])
        df_pandas_2 = pd.DataFrame(data=data2, columns=["data2"])
        df_spark_1 = self.spark.createDataFrame(df_pandas_1)
        df_spark_2 = self.spark.createDataFrame(df_pandas_2)
        data1 = df_spark_1.select("data1")
        data2 = df_spark_2.select("data2")

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1,
            data2=data2,
            spark_session=self.spark,
            alternative="two-sided",
            mode="auto",
        )
        R_stat, R_pvalue = 0.53, 5.4e-09

        self.assertAlmostEqual(P_stat, R_stat, 8)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 8)


class TestSparkLCR(PySparkTestCase):
    """
    Unit test case for the spark implementation of lcr functions.
    """

    @staticmethod
    def get_data_for_lcr_spark_versus_pandas(self):
        records = [
            (1.1464, 0.3332),
            (1.1157, 0.626),
            (1.0023, 0.5803),
            (0.9361, 0.2095),
        ]
        df_pandas = pd.DataFrame.from_records(records, columns=["obs_col", "pred_col"])
        return df_pandas, self.spark.createDataFrame(df_pandas)

    @staticmethod
    def get_data_for_lcr_spark(self):
        records = [
            (0.0000, 0.2172),
            (0.0054, 0.2494),
            (0.0000, 0.2136),
            (0.0019, 0.1956),
            (0.0000, 0.2100),
            (0.0000, 0.2172),
            (0.0000, 0.2111),
            (0.0000, 0.0650),
            (1.1464, 0.3332),
            (0.0000, 0.2125),
            (0.0000, 0.2112),
            (0.0000, 0.2285),
            (0.4279, 0.1158),
            (0.0000, 0.3325),
            (0.0000, 0.1713),
            (0.0000, 0.2114),
            (0.0000, 0.2863),
            (0.2494, 0.1342),
            (0.0000, 0.7039),
            (0.0000, 0.7034),
            (0.0000, 0.1713),
            (1.1157, 0.6260),
            (0.0268, 0.2080),
            (0.0475, 0.4561),
            (0.0000, 0.2044),
            (0.0000, 0.3272),
            (0.0000, 0.3523),
            (0.0871, 0.1953),
            (0.0000, 0.2201),
            (0.0231, 0.0388),
            (0.0000, 0.0165),
            (0.0000, 0.2200),
            (0.0006, 0.0792),
            (0.0000, 0.2119),
            (0.0000, 0.2172),
            (0.0931, 0.1825),
            (0.0000, 0.2110),
            (0.0000, 0.1721),
            (0.0000, 0.5080),
            (0.0305, 0.0679),
            (0.0000, 0.2069),
            (0.0098, 0.2007),
            (0.0000, 0.2940),
            (0.0000, 0.2120),
            (0.1498, 0.1856),
            (0.0000, 0.1681),
            (0.0104, 0.1966),
            (0.0000, 0.1713),
            (0.0000, 0.3816),
            (0.0008, 0.1613),
            (0.0000, 0.5157),
            (0.0005, 0.0635),
            (0.0771, 0.0871),
            (0.0000, 0.2172),
            (0.0000, 0.3392),
            (0.0000, 0.2114),
            (0.0001, 0.1702),
            (0.0393, 0.2050),
            (0.4710, 0.1934),
            (0.0000, 0.3183),
            (0.0000, 0.5517),
            (0.0000, 0.0508),
            (0.0016, 0.1668),
            (0.0135, 0.0756),
            (0.0000, 0.3337),
            (0.0000, 0.2153),
            (0.0000, 0.1918),
            (1.0023, 0.5803),
            (0.0042, 0.3533),
            (0.0282, 0.1929),
            (0.0001, 0.1565),
            (0.9361, 0.2095),
            (0.0019, 0.2803),
            (0.0083, 0.2764),
            (0.0014, 0.2478),
            (0.0000, 0.1675),
            (0.0039, 0.3273),
            (0.0128, 0.1919),
            (0.0000, 0.2468),
            (0.0954, 0.1610),
            (0.0000, 0.0550),
            (0.0000, 0.0826),
            (0.3095, 0.3884),
            (0.0000, 0.2003),
            (0.0016, 0.1956),
            (0.0000, 0.2047),
            (0.0149, 0.2015),
            (0.0000, 0.1947),
            (0.0000, 0.0960),
            (0.0159, 0.1788),
            (0.0000, 0.1692),
            (0.3758, 0.2181),
            (0.0000, 0.0795),
            (0.0276, 0.2079),
            (0.0056, 0.0824),
            (0.0045, 0.2056),
            (0.0050, 0.0738),
            (0.0000, 0.2019),
            (0.1070, 0.0996),
            (0.0287, 0.0709),
        ]
        df_pandas = pd.DataFrame.from_records(records, columns=["obs_col", "pred_col"])
        return self.spark.createDataFrame(df_pandas)

    def test_input_data_value_error(self):
        """
        Test whether strings delivered as obs_col or
        pred_col exists in dataframes column names: Value Error.
        """
        df_spark = self.get_data_for_lcr_spark(self)
        self.assertRaises(
            ValueError,
            loss_capture_ratio,
            df=df_spark,
            obs_col="obs_col",
            pred_col="X",
        )

    def test_input_order_by_name_value_error(self):
        """
        Test whether string delivered as order_by belongs to
        possible values
        """
        df_spark = self.get_data_for_lcr_spark(self)
        self.assertRaises(
            ValueError,
            loss_capture_ratio,
            df=df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="X",
            calc_method="all_observations",
        )

    def test_input_calc_method_name_value_error(self):
        """
        Test whether string delivered as calc_method belongs to
        possible values
        """
        df_spark = self.get_data_for_lcr_spark(self)
        self.assertRaises(
            ValueError,
            loss_capture_ratio,
            df=df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="predicted",
            calc_method="X",
        )

    def test_lcr_value_for_observed_all_observations(self):
        """
        Test for the correct result of LCR for order by observed
        -> all_observations
        """
        df_spark = self.get_data_for_lcr_spark(self)
        results = loss_capture_ratio(
            df=df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="observed",
            calc_method="all_observations",
        )
        self.assertAlmostEqual(results["LCR"], -0.003894304179662819, places=5)

    def test_lcr_value_predicted_all_observations(self):
        """
        Test for the correct result of LCR for for ordr by predicted
        -> all_observations
        """
        df_spark = self.get_data_for_lcr_spark(self)
        results = loss_capture_ratio(
            df=df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="predicted",
            calc_method="all_observations",
        )
        self.assertAlmostEqual(results["LCR"], 0.38118832109852063, places=5)

    def test_lcr_value_observed_deciles(self):
        """
        Test for the correct result of LCR for order by observed
        -> deciles
        """
        df_spark = self.get_data_for_lcr_spark(self)
        results = loss_capture_ratio(
            df=df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="observed",
            calc_method="deciles",
        )
        self.assertAlmostEqual(results["LCR"], -0.05413523580459598, places=5)

    def test_lcr_value_predicted_deciles(self):
        """
        Test for the correct result of LCR for order by predicted
        -> deciles
        """
        df_spark = self.get_data_for_lcr_spark(self)
        results = loss_capture_ratio(
            df=df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="predicted",
            calc_method="deciles",
        )
        self.assertAlmostEqual(results["LCR"], 0.35581213668237816, places=5)

    def test_deciles_assert_rank_column_0_assigned_decile_1(self):
        df = self.get_data_for_lcr_spark(self)
        df = _add_deciles_spark(df=df, rank_column="obs_col")
        df_iterate = (
            df[df.obs_col == 0]
            .select("decile_rank_obs_col")
            .toPandas()["decile_rank_obs_col"]
        )
        for i in df_iterate:
            self.assertEqual(i, 1)

    def test_deciles_assert_rank_column_max_assigned_decile_6(self):
        df = self.get_data_for_lcr_spark(self)
        df = _add_deciles_spark(df=df, rank_column="obs_col")
        df_iterate = (
            df[df.obs_col > 1.14]
            .select("decile_rank_obs_col")
            .toPandas()["decile_rank_obs_col"]
        )
        for i in df_iterate:
            self.assertEqual(i, 6)

    def test_cumulative_percentage_sum_to_one(self):
        df = self.get_data_for_lcr_spark(self)
        obs_col = "obs_col"
        df_obs = df.orderBy(df[obs_col].desc())
        df_obs = df_obs.withColumn("idx", f.monotonically_increasing_id())
        window_ = Window.orderBy(f.col("idx"))
        df = _calculate_cumulative_percentage_spark(
            df=df_obs, obs_col="obs_col", pred_col="pred_col", window_=window_
        ).toPandas()
        self.assertTrue(
            (df.iloc[-1]["perc_accum_obs_loss"] == 1)
            & (df.iloc[-1]["perc_accum_pred_loss"] == 1)
        )

    def test_trapz_spark_area_calculation(self):
        df_spark = self.get_data_for_lcr_spark(self)
        obs_col = "obs_col"
        df_obs = df_spark.orderBy(df_spark[obs_col].desc())
        df_obs = df_obs.withColumn("idx", f.monotonically_increasing_id())
        window_ = Window.orderBy(f.col("idx"))
        df_obs = df_obs.withColumn("accum_pop", f.row_number().over(window_))
        df_obs = _calculate_cumulative_percentage_spark(
            df_obs, obs_col="obs_col", pred_col="pred_col", window_=window_
        )
        df_obs = df_obs.withColumn(
            "inc_obs_trap_area",
            _trapz_spark("accum_pop", "perc_accum_obs_loss", window_),
        )
        area = df_obs.select(f.sum("inc_obs_trap_area")).collect()[0][0]
        self.assertAlmostEqual(area, 94.97115384615385, 4)

    def test_spark_versus_pandas_lcr(self):
        df_pandas, df_spark = self.get_data_for_lcr_spark_versus_pandas(self)
        # spark results
        results_spark_obs_all = loss_capture_ratio(
            df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="all_observations",
            order_by="observed",
        )
        results_spark_pred_all = loss_capture_ratio(
            df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="all_observations",
            order_by="predicted",
        )
        results_spark_obs_dec = loss_capture_ratio(
            df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="deciles",
            order_by="observed",
        )
        results_spark_pred_dec = loss_capture_ratio(
            df_spark,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="deciles",
            order_by="predicted",
        )
        # pandas results
        results_pandas_obs_all = loss_capture_ratio(
            df_pandas,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="all_observations",
            order_by="observed",
        )
        results_pandas_pred_all = loss_capture_ratio(
            df_pandas,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="all_observations",
            order_by="predicted",
        )
        results_pandas_obs_dec = loss_capture_ratio(
            df_pandas,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="deciles",
            order_by="observed",
        )
        results_pandas_pred_dec = loss_capture_ratio(
            df_pandas,
            obs_col="obs_col",
            pred_col="pred_col",
            calc_method="deciles",
            order_by="predicted",
        )

        self.assertAlmostEqual(
            0, abs(results_spark_obs_all["LCR"] - results_pandas_obs_all["LCR"])
        )
        self.assertAlmostEqual(
            0, abs(results_spark_pred_all["LCR"] - results_pandas_pred_all["LCR"])
        )
        self.assertAlmostEqual(
            0, abs(results_spark_obs_dec["LCR"] - results_pandas_obs_dec["LCR"])
        )
        self.assertAlmostEqual(
            0, abs(results_spark_pred_dec["LCR"] - results_pandas_pred_dec["LCR"])
        )


class TestKolgomorovSmirnov2Sample(PySparkTestCase):
    """
    Test class for the function
    'crv.validation.differentiation.kolmogorov_smirnov_2_sample'.
    """

    def test_kolmogorov_smirnov_2_sample_ValueError_1(self):
        """
        Checks whether a value error is raised when all parameter values
        are None
        """
        self.assertRaises(
            ValueError,
            kolmogorov_smirnov_2_sample,
            data1=None,
            data2=None,
            spark_session=None,
        )

    def test_kolmogorov_smirnov_2_sample_exact(self):
        """
        Test that '_pandas_kolmogorov_smirnov_2_sample' and
        '_spark_kolmogorov_smirnov_2_sample' yield similar output when
        mode='exact'
        """
        # Mode is exact
        mode = "exact"

        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode=mode
        )

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        S_stat, S_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, spark_session=self.spark
        )

        self.assertAlmostEqual(P_stat, S_stat, 8)
        self.assertAlmostEqual(P_pvalue, S_pvalue, 8)

    def test_kolmogorov_smirnov_2_sample_asymp(self):
        """
        Test that '_pandas_kolmogorov_smirnov_2_sample' and
        '_spark_kolmogorov_smirnov_2_sample' yield similar output when
        mode='asymp'
        """
        # Mode is exact
        mode = "asymp"

        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode=mode
        )

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        S_stat, S_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, spark_session=self.spark
        )

        self.assertAlmostEqual(P_stat, S_stat, 8)
        self.assertAlmostEqual(P_pvalue, S_pvalue, 8)

    def test_kolmogorov_smirnov_2_sample_greater(self):
        """
        Test that '_pandas_kolmogorov_smirnov_2_sample' and
        '_spark_kolmogorov_smirnov_2_sample' yield similar output when
        alternative='greater'
        """
        # Mode is exact
        alternative = "greater"

        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, alternative=alternative
        )

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        S_stat, S_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, spark_session=self.spark, alternative=alternative
        )

        self.assertAlmostEqual(P_stat, S_stat, 8)
        self.assertAlmostEqual(P_pvalue, S_pvalue, 8)

    def test_kolmogorov_smirnov_2_sample_less(self):
        """
        Test that '_pandas_kolmogorov_smirnov_2_sample' and
        '_spark_kolmogorov_smirnov_2_sample' yield similar output when
        alternative='less'
        """
        # Mode is exact
        alternative = "less"

        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 100)
        data2 = np.random.normal(mu2, sigma2, 100)

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, alternative=alternative
        )

        numpy_data = np.array([data1, data2]).transpose()
        df_pandas = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])
        df_spark = self.spark.createDataFrame(df_pandas)
        data1 = df_spark.select("data1")
        data2 = df_spark.select("data2")

        S_stat, S_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, spark_session=self.spark
        )
        self.assertAlmostEqual(P_stat, S_stat, 8)
        self.assertAlmostEqual(P_pvalue, S_pvalue, 8)

    def test_kolmogorov_smirnov_2_sample_different_sample_size(self):
        """
        Test that '_pandas_kolmogorov_smirnov_2_sample' and
        '_spark_kolmogorov_smirnov_2_sample' yield similar output when
        the two sample sizes are unequal
        """
        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 50)
        data2 = np.random.normal(mu2, sigma2, 100)

        P_stat, P_pvalue = kolmogorov_smirnov_2_sample(data1=data1, data2=data2)

        df_pandas_1 = pd.DataFrame(data=data1, columns=["data1"])
        df_pandas_2 = pd.DataFrame(data=data2, columns=["data2"])
        df_spark_1 = self.spark.createDataFrame(df_pandas_1)
        df_spark_2 = self.spark.createDataFrame(df_pandas_2)
        data1 = df_spark_1.select("data1")
        data2 = df_spark_2.select("data2")

        S_stat, S_pvalue = kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, spark_session=self.spark
        )

        self.assertAlmostEqual(P_stat, S_stat, 8)
        self.assertAlmostEqual(P_pvalue, S_pvalue, 8)


if __name__ == "__main__":
    unittest.main()
