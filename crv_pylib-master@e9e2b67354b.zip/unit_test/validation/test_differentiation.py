"""
# ============================================================================
# TEST_DIFFERENTIATION.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.VALIDATION.DIFFERENTIATION.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.validation.differentiation' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Lee MacKenzie Fischer <G01679>
# ============================================================================
"""

import sys

sys.path.append("../crv_pylib")
import unittest
import numpy as np
import pandas as pd
from unit_test.pyspark_test_class import PySparkTestCase
from scipy.stats import norm, chi2
from sklearn.metrics import roc_auc_score
from crv.validation.summary import adf_summary
from crv.validation.differentiation import (
    _add_deciles_pandas,
    _calculate_cumulative_percentage,
    auc,
    somers_d,
    loss_capture_ratio,
    herfindahl_index,
    g_auc,
    g_auc_test_stats,
    _pandas_kolmogorov_smirnov_2_sample,
)
from crv.utils.dataframe_helper import rating_cats


class QuantTestClass(unittest.TestCase):
    """
    A class extending the 'unittest.TestCase' class with
    functionality for creating test data.
    """

    @staticmethod
    def get_ecb_adf_table():
        d_adf = {
            "rat_rank": list(range(17)),
            "Rating": [str(i + 1) for i in range(17)],
            "N": [
                105_000,
                110_000,
                100_000,
                80_000,
                60_000,
                120_000,
                135_000,
                40_000,
                30_000,
                75_000,
                55_000,
                40_000,
                30_000,
                20_000,
                10_000,
                5_000,
                2_000,
            ],
            "D": [
                10,
                20,
                20,
                30,
                50,
                100,
                150,
                90,
                50,
                350,
                550,
                750,
                900,
                1000,
                900,
                700,
                1500,
            ],
            "PD": [
                0.0001,
                0.00015,
                0.0002,
                0.0004,
                0.0008,
                0.0009,
                0.001,
                0.0015,
                0.002,
                0.005,
                0.01,
                0.02,
                0.03,
                0.05,
                0.1,
                0.15,
                0.5,
            ],
            "ORGEXP": [
                400_000_000,
                440_000_000,
                390_000_000,
                315_000_000,
                235_000_000,
                470_000_000,
                530_000_000,
                150_000_000,
                120_000_000,
                300_000_000,
                210_000_000,
                160_000_000,
                120_000_000,
                80_000_000,
                40_000_000,
                20_000_000,
                8_000_000,
            ],
        }
        df = pd.DataFrame.from_dict(d_adf)
        df = df.sort_values("rat_rank")
        return df

    @staticmethod
    def get_test_df():
        d_sample_data = {
            "Rating": ["1", "2", "2", "3", "3", "9"],
            "customer_id": [f"A00{i}" for i in range(6)],
            "group": ["1", "1", "2", "3", "4", "4"],
            "def_flag": [1, 1, 0, 1, 0, 1],
            "PD": [0.01, 0.02, 0.02, 0.03, 0.03, 0.09],
            "PDG": [0.01, 0.01, 0.02, 0.03, 0.03, 0.03],
            "ratG": ["1", "1", "2", "3", "3", "3"],
            "country": ["DK", "DK", "DK", "SE", "SE", "DK"],
            "ORGEXP": [100, 200, 300, 400, 500, 100],
        }
        df_sample_data = pd.DataFrame.from_dict(d_sample_data)
        return df_sample_data

    @staticmethod
    def get_test_df_large():
        """
        Get a larger raw DataFrame to use as sample data for test calculation.
        Args:
            duplicate (bool): Set True to append a duplicate of the
            test dataframe to itself. Default is False.
        """
        d_sample_data = {
            "rating_col": [
                "1",
                "1",
                "1",
                "1",
                "1",
                "1",
                "1",
                "1",
                "1",
                "1",
                "2",
                "2",
                "2",
                "2",
                "2",
                "2",
                "2",
                "2",
                "2",
                "2",
                "3",
                "3",
                "3",
                "3",
                "3",
                "3",
                "3",
                "3",
                "3",
                "3",
            ],
            "customer_id": [f"A00{i}" for i in range(30)],
            "def_flag": [
                1,
                1,
                0,
                1,
                1,
                0,
                1,
                1,
                0,
                1,
                1,
                0,
                0,
                1,
                0,
                0,
                1,
                0,
                0,
                1,
                1,
                0,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
            ],
            "PD": [
                0.6,
                0.6,
                0.6,
                0.6,
                0.6,
                0.6,
                0.6,
                0.6,
                0.6,
                0.6,
                0.4,
                0.4,
                0.4,
                0.4,
                0.4,
                0.4,
                0.4,
                0.4,
                0.4,
                0.4,
                0.2,
                0.2,
                0.2,
                0.2,
                0.2,
                0.2,
                0.2,
                0.2,
                0.2,
                0.2,
            ],
            "country": [
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
                "DK",
                "SE",
                "NO",
            ],
        }
        pandas_sample_data = pd.DataFrame.from_dict(d_sample_data)
        return pandas_sample_data

    @staticmethod
    def get_test_df_ecb():
        """
        Returns ADF table from the ECB template 'LEICode_PD_ModelID_EndOfObservationPeriod_versionNumber.xlsx'
        from February 2019. Spreadsheet 3.0.
        """
        adf_ecb = {
            "PD": [
                0.00010,
                0.00015,
                0.00020,
                0.00040,
                0.00080,
                0.00090,
                0.00100,
                0.00150,
                0.00200,
                0.00500,
                0.01000,
                0.02000,
                0.03000,
                0.05000,
                0.10000,
                0.15000,
                0.50000,
            ],
            "D": [
                10,
                20,
                20,
                30,
                50,
                100,
                150,
                90,
                50,
                350,
                550,
                750,
                900,
                1000,
                900,
                700,
                1500,
            ],
            "N": [
                105_000,
                110_000,
                100_000,
                80_000,
                60_000,
                120_000,
                135_000,
                40_000,
                30_000,
                75_000,
                55_000,
                40_000,
                30_000,
                20_000,
                10_000,
                5_000,
                2_000,
            ],
        }

        pandas_adf_ecb = pd.DataFrame.from_dict(adf_ecb)

        return pandas_adf_ecb

    @staticmethod
    def get_ecb_lgd_matrix():
        """
        Returns the LGD matrix plus expected test results as per the
        ECB template 'LEICode_LGD_ModelID_EndOfObservationPeriod_versionNumber.xlsx'
        from February 2019.

        Expected values are given to 8 decimal places.
        """
        # ECB test data from template.
        lgd_matrix = np.array(
            [
                [1406, 584, 448, 1530, 200, 584, 25, 200, 54, 30, 39, 400],
                [130, 300, 500, 50, 100, 120, 30, 0, 32, 0, 0, 338],
                [14, 320, 10, 140, 10, 104, 20, 30, 0, 2, 18, 2],
                [2, 43, 6, 70, 10, 50, 19, 8, 42, 0, 0, 0],
                [20, 8, 65, 45, 80, 40, 55, 37, 10, 0, 0, 0],
                [1, 0, 0, 0, 7, 1, 7, 3, 1, 0, 0, 0],
                [1, 0, 1, 5, 3, 7, 15, 7, 1, 3, 2, 0],
                [0, 0, 0, 9, 15, 2, 20, 5, 15, 0, 9, 0],
                [3, 0, 1, 20, 34, 87, 35, 80, 600, 100, 284, 36],
                [57, 0, 56, 0, 5, 67, 15, 77, 548, 854, 798, 1223],
                [0, 240, 354, 9, 604, 364, 699, 1250, 2008, 2564, 1286, 122],
                [0, 0, 0, 0, 0, 0, 8, 32, 564, 566, 56, 774],
            ]
        )

        expected_g_auc = 0.70278690
        # Note: The formula for the expected standard deviation appears to be
        # correct in the Annex 2 reference, but the accompanying ECB template
        # data uses the formula for the STDEV from Somers D, which is 2x larger,
        # hence we must divide the expected value by 2 here.
        expected_std_dev = round(0.00492159 / 2, 7)
        significant_decimal_places = 8
        return lgd_matrix, expected_g_auc, expected_std_dev, significant_decimal_places

    @staticmethod
    def get_small_somers_d_data():
        """
        Returns a small matrix from a Wikipedia example
        (https://en.wikipedia.org/wiki/Somers%27_D) plus expected results.

        Expected values are given to 8 decimal places.
        """
        df = pd.DataFrame.from_dict({0: [3, 1], 1: [5, 7], 2: [2, 6]})
        exp_g_auc = 0.67142857
        exp_s = 0.10133223
        significant_decimal_places = 8
        return df, exp_g_auc, exp_s, significant_decimal_places


class TestPandasLCR(QuantTestClass):
    """
    Unit test case for the pandas implementation of lcr functions.
    """

    @staticmethod
    def get_data_for_lcr():
        return pd.DataFrame(
            [
                [0.000000, 50.922045],
                [154.833891, 7192.859088],
                [0.000000, 13031.110116],
                [98.477891, 10308.211324],
                [0.000000, 21.138367],
                [0.000000, 28.323184],
                [0.000000, 497.694498],
                [0.000000, 15126.853090],
                [48839.549037, 14197.308552],
                [0.000000, 23.812374],
            ],
            columns=["obs_col", "pred_col"],
        )

    def test_input_data_value_error(self):
        """
        Test whether strings delivered as obs_col or
        pred_col exists in dataframes column names: Value Error.
        """
        self.assertRaises(
            ValueError,
            loss_capture_ratio,
            df=self.get_data_for_lcr(),
            obs_col="obs_col",
            pred_col="X",
        )

    def test_input_order_by_name_value_error(self):
        """
        Test whether string delivered as order_by belongs to
        possible values
        """
        self.assertRaises(
            ValueError,
            loss_capture_ratio,
            df=self.get_data_for_lcr(),
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="X",
            calc_method="all_observations",
        )

    def test_input_calc_method_name_value_error(self):
        """
        Test whether string delivered as calc_method belongs to
        possible values
        """
        self.assertRaises(
            ValueError,
            loss_capture_ratio,
            df=self.get_data_for_lcr(),
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="predicted",
            calc_method="X",
        )

    def test_lcr_value_for_observed_all_observations(self):
        """
        Test for the correct result of LCR for rimo -> all_observations
        """
        df = self.get_data_for_lcr()
        results = loss_capture_ratio(
            df=df,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="observed",
            calc_method="all_observations",
        )
        self.assertAlmostEqual(results["LCR"], 0.24821789300061226, places=5)

    def test_lcr_value_predicted_all_observations(self):
        """
        Test for the correct result of LCR for crmv -> all_observations
        """
        df = self.get_data_for_lcr()
        results = loss_capture_ratio(
            df=df,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="predicted",
            calc_method="all_observations",
        )
        self.assertAlmostEqual(results["LCR"], 0.8726320462161731, places=5)

    def test_lcr_value_observed_deciles(self):
        """
        Test for the correct result of LCR for rimo -> deciles
        """
        df = self.get_data_for_lcr()
        results = loss_capture_ratio(
            df=df,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="observed",
            calc_method="deciles",
        )
        self.assertAlmostEqual(results["LCR"], 0.2671998366931145, places=5)

    def test_lcr_value_predicted_deciles(self):
        """
        Test for the correct result of LCR for rimo -> deciles
        """
        df = self.get_data_for_lcr()
        results = loss_capture_ratio(
            df=df,
            obs_col="obs_col",
            pred_col="pred_col",
            order_by="predicted",
            calc_method="deciles",
        )
        self.assertAlmostEqual(results["LCR"], 0.8726320462161731, places=5)

    def test_deciles_assert_rank_column_0_assigned_decile_1(self):
        df = self.get_data_for_lcr()
        df = _add_deciles_pandas(df=df, rank_column="obs_col")
        for i in df[df.obs_col == 0].decile_rank_obs_col:
            self.assertEqual(i, 1)

    def test_deciles_assert_rank_column_max_assigned_decile_5(self):
        df = self.get_data_for_lcr()
        df = _add_deciles_pandas(df=df, rank_column="obs_col")
        for i in df[df.obs_col >= 48839].decile_rank_obs_col:
            self.assertEqual(i, 5)

    def test_cumulative_percentage_sum_to_one(self):
        df = self.get_data_for_lcr()
        df = _calculate_cumulative_percentage(
            df=df, obs_col="obs_col", pred_col="pred_col"
        )
        self.assertTrue(
            (df.iloc[-1]["perc_accum_obs_loss"] == 1)
            & (df.iloc[-1]["perc_accum_pred_loss"] == 1)
        )


class TestAuc(QuantTestClass):
    """
    Unit test case for the auc function.
    """

    def test_input_data_value_error(self):
        """
        Test for correct type of input data Value Error.
        """
        self.assertRaises(
            ValueError,
            auc,
            adf_table="3",
            default_count_col="D",
            customer_count_col="N",
            pd_col="PD",
        )

    def test_auc_group_rating(self):
        """
        Test for correct results in the auc function when used in the
        intended way, grouped by rating.
        """
        df_test = self.get_test_df_large()
        adf_test = adf_summary(
            df_test, "customer_id", "def_flag", group_list="rating_col"
        )
        # Add PD to ADF table.
        pd_table = pd.DataFrame.from_dict(
            {"rating_col": ["1", "2", "3"], "PD": [0.6, 0.4, 0.2]}
        )
        adf_test = adf_test.merge(pd_table, on="rating_col")
        self.assertEqual(
            auc(adf_test, "D", "N", "PD")[0],
            roc_auc_score(df_test["def_flag"], df_test["PD"]),
        )

    def test_auc_no_group(self):
        """
        Test the auc function when no grouping has been applied to
        the ADF table (one row is returned). The result should be 0.5.
        """
        df_test = self.get_test_df_large()
        adf_test = adf_summary(df_test, "customer_id", "def_flag")
        # Add PD to ADF table.
        adf_test["PD"] = df_test["PD"].mean()
        self.assertEqual(auc(adf_test, "D", "N", "PD")[0], 0.5)

    def test_auc_group_country(self):
        """
        Test the result when grouping by country. The PD will have to
        be averaged by country for the results to make sense.
        """
        df_test = self.get_test_df_large()
        adf_test = adf_summary(df_test, "customer_id", "def_flag", group_list="country")
        # Add PD to ADF table.
        pd_table = df_test.groupby("country").PD.mean().reset_index()
        adf_test = adf_test.merge(pd_table, on="country")

        # PD in the test DataFrame has to be replaced with the country
        # averaged PD for each observation.
        df_test = df_test.join(
            df_test.groupby(by="country").PD.mean(), on="country", rsuffix="_c"
        )

        self.assertEqual(
            auc(adf_test, "D", "N", "PD")[0],
            roc_auc_score(df_test["def_flag"], df_test["PD_c"]),
        )

    def test_auc_ecb_data(self):
        """
        Test the auc & SD with ECB data from 'LEICode_PD_ModelID_EndOfObservationPeriod_versionNumber.xlsx'
        February 2019.
        """
        df_test = self.get_test_df_ecb()

        self.assertEqual(round(auc(df_test, "D", "N", "PD")[0], 6), 0.929744)

        self.assertEqual(
            round((auc(df_test, "D", "N", "PD")[1]) ** 2, 10), 0.0000021748
        )


class TestsSomersD(QuantTestClass):
    """
    Unit test case for the somers_d function.
    """

    def test_somers_d_ecb_data(self):
        """
        Test the somers' D & SD based on ECB data from 'LEICode_PD_ModelID_EndOfObservationPeriod_versionNumber.xlsx'
        February 2019.
        """
        df_test = self.get_test_df_ecb()

        self.assertEqual(round(somers_d(df_test, "D", "N", "PD")[0], 6), 0.859488)

        self.assertEqual(
            round((somers_d(df_test, "D", "N", "PD")[1]), 10), 0.0029494682
        )


class TestHerfindahlIndex(QuantTestClass):
    """
    Test class for the herfindahl_index function.
    """

    def test_herfindahl_index_group_rating(self):
        """
        Test for correct results grouped on rating.
        """
        df_test = self.get_ecb_adf_table()

        # Check for ECB HI observation weighted
        HI, _, _ = herfindahl_index(df_test, "PD")
        self.assertAlmostEqual(HI, 0.137923, places=6)

    def test_herfindahl_index_cv_is_init(self):
        """
        Passed the recieved CV from a calcuation into CV_init
        for the next calculation should return p=0.5.
        """
        df_test = self.get_ecb_adf_table()
        _, CV, p = herfindahl_index(df_test, "PD")

        # Check that p = 0.5 is CV_init = CV
        _, _, p = herfindahl_index(df_test, "PD", CV_init=CV)
        self.assertEqual(p, 0.5)

    def test_herfindahl_index_p_value_ecb(self):
        """
        Check for the correct p-value calculated from ECB test data.
        """
        df_test = self.get_ecb_adf_table()
        K = 17
        HI_init = 0.085
        CV_init = np.sqrt(K * np.exp((HI_init - 1) * np.log(K)) - 1)
        _, _, p = herfindahl_index(df_test, "PD", CV_init=CV_init)
        self.assertAlmostEqual(p, 0.160539, places=6)

    def test_herfindahl_index_incorrect_cv(self):
        """
        Check that function returns p=None for the incorrect
        input of CV_init and that HI is still returned correctly.
        """
        df_test = self.get_ecb_adf_table()
        HI, _, p = herfindahl_index(df_test, "PD", CV_init="string")
        self.assertEqual(p, None)
        self.assertAlmostEqual(HI, 0.137923, places=6)

    def test_herfindahl_index_exposure_weighted(self):
        """
        Check the HI returned when it is exposure weighted.
        """
        df_test = self.get_ecb_adf_table()
        HI, CV, p = herfindahl_index(df_test, "PD", weight="ORGEXP")
        self.assertAlmostEqual(HI, 0.137562, places=6)
        HI, CV, p = herfindahl_index(df_test, "PD", weight="ORGEXP", CV_init=CV)
        self.assertEqual(p, 0.5)

    def test_herfindahl_index_only_one_row(self):
        """
        Check output when the input table only has one row.
        """
        df_test = pd.DataFrame.from_dict({"N": [1], "PD": [0.1]})
        HI, CV, p = herfindahl_index(df_test, "PD")
        self.assertEqual(HI, 1)
        self.assertEqual(CV, 0)
        self.assertEqual(p, None)

    def test_herfindahl_index_user_warning(self):
        """
        Check that function raises a UserWarning if CV_init is not
        between 0 and 1.
        """
        df_test = self.get_ecb_adf_table()
        self.assertWarns(
            UserWarning,
            herfindahl_index,
            **{"adf_table": df_test, "pd_col": "PD", "CV_init": "string"},
        )


class TestGAuc(QuantTestClass):
    """
    Test class for the "g_auc' function.
    """

    def test_g_auc_results_numpy(self):
        """
        Tests for the correct results when a numpy.array is used as input.
        """
        np_lgd, exp_auc, exp_s, sig_dig = self.get_ecb_lgd_matrix()
        result_auc, result_s = g_auc(np_lgd)
        self.assertEqual(exp_auc, round(result_auc, sig_dig))
        self.assertEqual(exp_s, round(result_s, sig_dig))

    def test_g_auc_results_pandas(self):
        """
        Tests for the correct results when a pandas.DataFrame is used as input.
        """
        np_lgd, exp_auc, exp_s, sig_dig = self.get_ecb_lgd_matrix()
        pd_lgd = pd.DataFrame(np_lgd)
        result_auc, result_s = g_auc(pd_lgd)
        self.assertEqual(exp_auc, round(result_auc, sig_dig))
        self.assertEqual(exp_s, round(result_s, sig_dig))

    def test_g_auc_results_small_matrix(self):
        """
        Tests for correct results from a small Wikipedia example.
        """
        df, exp_g_auc, exp_s, sig_dig = self.get_small_somers_d_data()
        result_g_auc, result_s = g_auc(df)
        self.assertEqual(exp_g_auc, round(result_g_auc, sig_dig))
        self.assertEqual(exp_s, round(result_s, sig_dig))


class TestGAucTestStats(unittest.TestCase):
    """
    Test class for the 'g_auc_test_stats' function which performs
    a simple division and CDF operation.
    """

    def test_g_auc_test_stats_results(self):
        """
        Tests for correct results.
        """
        # Expected values.
        exp_test_stat = 2.0
        exp_var = 0.0625
        exp_p = 0.0227501319
        result_test_stat, result_var, result_p = g_auc_test_stats(2.5, 2, 0.25)
        self.assertEqual(exp_test_stat, result_test_stat)
        self.assertEqual(exp_var, result_var)
        self.assertEqual(exp_p, round(result_p, 10))


class TestPandasKolgomorovSmirnov2Sample(unittest.TestCase):
    """
    Test class for function
    'crv.validation.differentiation._pandas_kolmogorov_smirnov_2_sample'.
    """

    def test_pandas_KS_2Sample_auto_10000_plus(self):
        """
        Tests that the function chooses 'asymp' when mode='auto' and
        number of observations > 10.000
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.1, 0.2
        data1 = np.random.normal(mu1, sigma1, 100000)
        data2 = np.random.normal(mu2, sigma2, 100000)

        # mode = 'auto'
        stat_cac, p_calc = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode="auto"
        )

        # mode = 'asymp'
        stat_val, p_val = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode="asymp"
        )

        self.assertEqual(stat_cac, stat_val)
        self.assertEqual(p_calc, p_val)

    def test_pandas_KS_2Sample_auto_10000_min(self):
        """
        Tests that the function chooses 'exact' when mode='auto' and
        number of observations < 10.000
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.1, 0.2
        data1 = np.random.normal(mu1, sigma1, 9000)
        data2 = np.random.normal(mu2, sigma2, 9000)

        # mode = 'auto'
        stat_cac, p_calc = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode="auto"
        )

        # mode = 'asymp'
        stat_val, p_val = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode="exact"
        )

        self.assertEqual(stat_cac, stat_val)
        self.assertEqual(p_calc, p_val)

    def test_pandas_KS_2Sample_pd_Series(self):
        """
        Tests that the function works with a pandas.Series and no
        exception is raised
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.1, 0.2
        data1 = pd.Series(np.random.normal(mu1, sigma1, 9000))
        data2 = pd.Series(np.random.normal(mu2, sigma2, 9000))

        raised = False
        try:
            _pandas_kolmogorov_smirnov_2_sample(data1=data1, data2=data2, mode="auto")
        except:
            raised = True

        self.assertFalse(raised, "Function does not accept pd.Series")

    def test_pandas_KS_2Sample_pd_DataFrame(self):
        """
        Tests that the function works with a pandas.DataFrame and no
        exception is raised
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.1, 0.2
        data1 = np.random.normal(mu1, sigma1, 9000)
        data2 = np.random.normal(mu2, sigma2, 9000)
        numpy_data = np.array([data1, data2]).transpose()

        df = pd.DataFrame(data=numpy_data, columns=["data1", "data2"])

        raised = False
        try:
            _pandas_kolmogorov_smirnov_2_sample(
                data1=df["data1"], data2=df["data2"], mode="exact"
            )
        except:
            raised = True

        self.assertFalse(raised, "Function does not accept pd.DataFrame")

    def test_pandas_KS_2Sample_exact_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing mode="exact"
        R code: >>> ks.test(data1, data2)
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.5, 0.1
        data1 = np.random.normal(mu1, sigma1, 1000)
        data2 = np.random.normal(mu2, sigma2, 1000)

        P_stat, P_pvalue = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode="exact"
        )
        R_stat, R_pvalue = 0.986, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 12)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 12)

    def test_pandas_KS_2Sample_asymp_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing mode="asymp"
        R code: >>> ks.test(data1, data2, exact=False)
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.1, 0.2
        data1 = np.random.normal(mu1, sigma1, 1000)
        data2 = np.random.normal(mu2, sigma2, 1000)

        P_stat, P_pvalue = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, mode="asymp"
        )
        R_stat, R_pvalue = 0.376, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 12)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 12)

    def test_pandas_KS_2Sample_greater_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing alternative="greater"
        R code: >>> ks.test(data1, data2, alternative="gr")
        """
        np.random.seed(42)

        mu1, sigma1 = 0, 0.1
        mu2, sigma2 = 0.2, 0.1
        data1 = np.random.normal(mu1, sigma1, 800)
        data2 = np.random.normal(mu2, sigma2, 800)

        P_stat, P_pvalue = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, alternative="greater"
        )
        R_stat, R_pvalue = 0.725, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 12)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 12)

    def test_pandas_KS_2Sample_less_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when choosing alternative="less"
        R code: >>> ks.test(data1, data2, alternative="less")
        """
        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 800)
        data2 = np.random.normal(mu2, sigma2, 800)

        P_stat, P_pvalue = _pandas_kolmogorov_smirnov_2_sample(
            data1=data1, data2=data2, alternative="less"
        )
        R_stat, R_pvalue = 0.515, 2.2e-16
        print(P_pvalue, P_stat)
        self.assertAlmostEqual(P_stat, R_stat, 12)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 12)

    def test_pandas_KS_2Sample_different_sample_size_comparison_R(self):
        """
        Tests that the function output is in line with output from R
        when data1 and data2 have different sample sizes
        R code: >>> ks.test(data1, data2)
        """
        np.random.seed(42)

        mu1, sigma1 = 0.2, 0.2
        mu2, sigma2 = 0.0, 0.1
        data1 = np.random.normal(mu1, sigma1, 1000)
        data2 = np.random.normal(mu2, sigma2, 800)

        P_stat, P_pvalue = _pandas_kolmogorov_smirnov_2_sample(data1=data1, data2=data2)
        R_stat, R_pvalue = 0.52775, 2.2e-16

        self.assertAlmostEqual(P_stat, R_stat, 12)
        self.assertAlmostEqual(P_pvalue, R_pvalue, 12)


if __name__ == "__main__":
    unittest.main()
