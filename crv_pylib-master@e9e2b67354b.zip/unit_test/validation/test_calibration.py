"""
# ============================================================================
# TEST_CALIBRATION.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.VALIDATION.CALIBRATION.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.validation.calibration' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Lee MacKenzie Fischer <G01679>
# ============================================================================
"""

import sys

sys.path.append("../crv_pylib")
import unittest
import numpy as np
import pandas as pd
import random
from scipy.stats import norm, chi2, ttest_rel, ttest_ind
from sklearn.metrics import roc_auc_score
from crv.validation.summary import adf_summary
from crv.validation.calibration import (
    jeffreys_test,
    binomial_test_norm_approx,
    binomial_test,
    confidence_intervals,
    hosmer_lemeshow_test,
    _paired_t,
    _unpaired_equal_var_t,
    _unpaired_unequal_var_t,
    t_test,
    homogeneity_heterogeneity_test,
)
from crv.utils.dataframe_helper import rating_cats


class QuantTestClass(unittest.TestCase):
    """
    A class extending the 'unittest.TestCase' class with
    functionality for creating test data.
    """

    @staticmethod
    def get_ecb_adf_table():
        d_adf = {
            "rat_rank": list(range(17)),
            "Rating": [str(i + 1) for i in range(17)],
            "N": [
                105_000,
                110_000,
                100_000,
                80_000,
                60_000,
                120_000,
                135_000,
                40_000,
                30_000,
                75_000,
                55_000,
                40_000,
                30_000,
                20_000,
                10_000,
                5_000,
                2_000,
            ],
            "D": [
                10,
                20,
                20,
                30,
                50,
                100,
                150,
                90,
                50,
                350,
                550,
                750,
                900,
                1000,
                900,
                700,
                1500,
            ],
            "PD": [
                0.0001,
                0.00015,
                0.0002,
                0.0004,
                0.0008,
                0.0009,
                0.001,
                0.0015,
                0.002,
                0.005,
                0.01,
                0.02,
                0.03,
                0.05,
                0.1,
                0.15,
                0.5,
            ],
            "ORGEXP": [
                400_000_000,
                440_000_000,
                390_000_000,
                315_000_000,
                235_000_000,
                470_000_000,
                530_000_000,
                150_000_000,
                120_000_000,
                300_000_000,
                210_000_000,
                160_000_000,
                120_000_000,
                80_000_000,
                40_000_000,
                20_000_000,
                8_000_000,
            ],
        }
        df = pd.DataFrame.from_dict(d_adf)
        df = df.sort_values("rat_rank")
        return df


class TestJeffreysTest(QuantTestClass):
    """
    Unit test case for the jeffreys_test function.
    """

    def test_jeffreys_test_with_summary(self):
        df_test = self.get_ecb_adf_table()
        # Add a summary column, with weight-averaged PD.
        d_agg = {
            **{
                "PD": [df_test["PD"].multiply(df_test["N"]).sum() / df_test["N"].sum()],
                "N": [df_test["N"].sum()],
                "D": [df_test["D"].sum()],
            },
            **{c: "All" for c in ["rat_rank", "Rating"]},
            **{c: [df_test[c].sum()] for c in ["ORGEXP"]},
        }
        df_agg = pd.DataFrame.from_dict(d_agg)
        df_test = pd.concat([df_agg, df_test], sort=True)

        # results confirmed against ECB demo data
        result = {
            "p-value": [
                0.00012179442710942491,
                0.541061898631614,
                0.19117381870306804,
                0.48505284970110707,
                0.6283653724430048,
                0.3779990431204852,
                0.7774806426400536,
                0.0997691080522309,
                0.0001436858588534677,
                0.9046831036635619,
                0.9032529225260211,
                0.49720696288633254,
                0.9639630275672649,
                0.49788438757591263,
                0.49805825830115125,
                0.9996381470330791,
                0.9769393364367647,
                4.253397251205382e-116,
            ]
        }
        j_test = jeffreys_test(df_test, "D", "N", "PD")
        for k in result.keys():
            self.assertEqual(
                list(j_test[k]), result[k], f"'{k}' columns are not equal."
            )


class TestBinomialTest(QuantTestClass):
    """
    Unit test case for binomial functions
    """

    def test_binomial_test_result(self):

        """
        Test that cross-validates results from python package
        proportion_confint with R-package - prevalence::propCI()

        Note: Test fails for first the first row of the lowerbound
        and the first two rows for the upperbound.
        Expectedly due to different rounding.
        """

        # R-data for lower and upperbound
        r_k_L = [
            4.79548,
            9.14563,
            12.21693,
            21.88922,
            35.39484,
            88.60129,
            113.1974,
            45.79389,
            45.79641,
            338.0825,
            505.1917,
            746.0182,
            842.9584,
            940.4018,
            941.8721,
            701.0457,
            955.7011,
        ]
        r_k_H = [
            18.38962,
            25.98182,
            30.88670,
            45.17073,
            63.63274,
            130.3805,
            159.7742,
            77.21525,
            77.20971,
            414.8326,
            597.6855,
            856.7937,
            959.7931,
            1062.231,
            1060.469,
            801.0068,
            1044.299,
        ]
        r_k_L = list(np.ceil(r_k_L).astype(int))
        r_k_H = list(np.floor(r_k_H).astype(int))

        # Python data for lower and upperbound
        df = self.get_ecb_adf_table()
        df = binomial_test(df, "D", "N", "PD", alpha=0.95)

        k_L = df["k_L"].tolist()
        k_H = df["k_H"].tolist()

        # Compare lower and upperbound
        self.assertListEqual(k_L, r_k_L, msg="Error: Lowerbounds are not equal.")
        self.assertListEqual(k_H, r_k_H, msg="Error: Upperbounds are not equal.")

    def test_binomial_test_large_n_result(self):

        """
        Test that cross-validates results from python package
        proportion_confint with R-package - prevalence::propCI() with large N
        """

        # R-data for lower and upperbound
        r_k_L = [
            0.02532,
            4.79549,
            12.21673,
            20.24117,
            28.57696,
            37.11140,
            45.78683,
            54.56900,
            63.43564,
            72.37130,
            81.36471,
        ]
        r_k_H = [
            5.57037,
            18.38958,
            30.88754,
            42.82595,
            54.46766,
            65.91772,
            77.23078,
            88.43962,
            99.56571,
            110.6240,
            121.6255,
        ]
        r_k_L = list(np.ceil(r_k_L).astype(int))
        r_k_H = list(np.floor(r_k_H).astype(int))

        # Python data with large increasing n for lower and upperbound
        d_adf = {
            "rat_rank": list(range(11)),
            "Rating": [str(i + 1) for i in range(11)],
            "N": [
                10_000,
                100_000,
                200_000,
                300_000,
                400_000,
                500_000,
                600_000,
                700_000,
                800_000,
                900_000,
                1_000_000,
            ],
            "D": [10, 20, 20, 30, 50, 100, 150, 90, 90, 90, 90],
            "PD": [
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
                0.0001,
            ],
        }
        df = pd.DataFrame.from_dict(d_adf)
        df = df.sort_values("rat_rank")
        df = binomial_test(df, "D", "N", "PD", alpha=0.95)

        k_L = df["k_L"].tolist()
        k_H = df["k_H"].tolist()

        # Compare lower and upperbound
        self.assertListEqual(k_L, r_k_L, msg="Error: Lowerbounds are not equal.")
        self.assertListEqual(k_H, r_k_H, msg="Error: Upperbounds are not equal.")

    def test_binomial_test_alpha_errors(self):

        """
        Test that a ValueError is raised if an incorrect value of alpha
        is passed.

        ValueError: if alpha<=0 or alpha>=1.
        """

        df_test = self.get_ecb_adf_table()
        self.assertRaises(
            ValueError,
            binomial_test,
            **{
                "adf_table": df_test,
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "alpha": 0,
            },
        )
        self.assertRaises(
            ValueError,
            binomial_test,
            **{
                "adf_table": df_test,
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "alpha": 1,
            },
        )

    def test_binomial_test_df_values_error(self):

        """
        Test that a ValueError is raised if an incorrect values in dataframes
        are passed:

        ValueError: if column PD_ <=0 or column PD_>=1.
        ValueError: if column _D < 0.
        ValueError: if column _N <= 0.
        """

        # check for column PD_ < 0.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "PD"] = -1
        self.assertRaises(
            ValueError,
            binomial_test,
            **{
                "adf_table": df_test,
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "alpha": 0.95,
            },
        )

        # check for column PD_> 1.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "PD"] = 2
        self.assertRaises(
            ValueError,
            binomial_test,
            **{
                "adf_table": df_test,
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "alpha": 0.95,
            },
        )

        # check for column D_ < 0.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "D"] = -1
        self.assertRaises(
            ValueError,
            binomial_test,
            **{
                "adf_table": df_test,
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "alpha": 0.95,
            },
        )

        # check for column N_ < 0.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "N"] = -1
        self.assertRaises(
            ValueError,
            binomial_test,
            **{
                "adf_table": df_test,
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "alpha": 0.95,
            },
        )


class TestBinomialTestNormApprox(QuantTestClass):
    """
    Unit test case for the binomial_test_norm_approx function.
    """

    def test_binomial_test_norm_approx_results(self):
        """
        Unit test checking for the correct results from the test.
        """
        df_test = self.get_ecb_adf_table()  # Get sample data.
        # Execute function to test.
        b_test = binomial_test_norm_approx(df_test, "D", "N", "PD")
        st = df_test.copy()

        st["nPD"] = st["N"] * st["PD"]
        st["PHI_inv"] = norm.ppf((1 + 0.95) / 2) * np.sqrt(st["nPD"] * (1 - st["PD"]))
        st["klow"] = st["nPD"] - st["PHI_inv"]
        st["khigh"] = st["nPD"] + st["PHI_inv"]
        st["low_conf"] = st["klow"] / st["N"]
        st["high_conf"] = st["khigh"] / st["N"]
        result = {
            "k_L": list(st["klow"]),
            "k_H": list(st["khigh"]),
            "LCL": list(st["low_conf"]),
            "UCL": list(st["high_conf"]),
        }
        for k in result.keys():
            self.assertEqual(
                list(b_test[k]), result[k], f"'{k}' columns are not equal."
            )

    def test_binomial_test_norm_approx_drop_nan(self):
        """
        Unit test checking for removal of null values from the input table.
        """
        df_test = self.get_ecb_adf_table()  # Get sample data.
        # Populate with null values.
        null_rating = ["4", "9", "16"]
        df_test.loc[df_test["Rating"].isin(null_rating), "PD"] = np.nan
        # Execute function to test.
        b_test = binomial_test_norm_approx(df_test, "D", "N", "PD")
        st = df_test.copy()

        st = st.loc[~st["Rating"].isin(null_rating)]
        st["nPD"] = st["N"] * st["PD"]
        st["PHI_inv"] = norm.ppf((1 + 0.95) / 2) * np.sqrt(st["nPD"] * (1 - st["PD"]))
        st["klow"] = st["nPD"] - st["PHI_inv"]
        st["khigh"] = st["nPD"] + st["PHI_inv"]
        st["low_conf"] = st["klow"] / st["N"]
        st["high_conf"] = st["khigh"] / st["N"]
        result = {
            "k_L": list(st["klow"]),
            "k_H": list(st["khigh"]),
            "LCL": list(st["low_conf"]),
            "UCL": list(st["high_conf"]),
        }
        for k in result.keys():
            self.assertEqual(
                list(b_test[k]), result[k], f"'{k}' columns are not equal."
            )


class TestConfidenceIntervals(QuantTestClass):
    """
    Test class for the confidence_interval function.
    """

    def test_confidence_intervals_results(self):
        """
        Test for the correct calculation of confidence intervals based
        on the ECB sample data.
        """
        df_test = self.get_ecb_adf_table()
        df_test["ADF"] = df_test["D"] / df_test["N"]

        conf_test = confidence_intervals(df_test, "PD")
        results = conf_test[["UCL", "LCL"]].to_numpy()
        # compare to excel calculations
        test_compare = np.array(
            [
                [0.000214318, 3.27933e-05],
                [0.000316547, 5.07488e-05],
                [0.000417318, 6.92018e-05],
                [0.000811184, 0.000146273],
                [0.001573672, 0.000309754],
                [0.001760856, 0.000351947],
                [0.001946978, 0.000394557],
                [0.002864613, 0.000612816],
                [0.003765504, 0.000837955],
                [0.008966432, 0.002277269],
                [0.017215522, 0.004869722],
                [0.032911979, 0.010455743],
                [0.04796542, 0.016385916],
                [0.076851363, 0.028944855],
                [0.144667065, 0.063065109],
                [0.20840249, 0.099932739],
                [0.592887519, 0.407112481],
            ]
        )
        self.assertEqual(np.allclose(results, test_compare, atol=1e-7), True)

    def test_confidence_intervals_rho_errors(self):
        """
        Test that a ValueError is raised if an incorrect value of rho is passed.
        """
        df_test = self.get_ecb_adf_table()
        self.assertRaises(
            ValueError,
            confidence_intervals,
            **{"adf_table": df_test, "pd_col": "PD", "rho": -0.1},
        )
        self.assertRaises(
            ValueError,
            confidence_intervals,
            **{"adf_table": df_test, "pd_col": "PD", "rho": 1.1},
        )

    def test_confidence_intervals_alpha_errors(self):
        """
        Test that a ValueError is raised if an incorrect value of alpha is passed.
        """
        df_test = self.get_ecb_adf_table()
        self.assertRaises(
            ValueError,
            confidence_intervals,
            **{"adf_table": df_test, "pd_col": "PD", "alpha": 0},
        )
        self.assertRaises(
            ValueError,
            confidence_intervals,
            **{"adf_table": df_test, "pd_col": "PD", "alpha": 1},
        )


class TestHosmerLemeshowTest(QuantTestClass):
    """
    Unit test case for Hosmer Lemeshow function
    """

    def test_hosmer_lemeshow_result(self, dof=None):

        """
        This function calculates the Hosmer-Lemeshow test using a different
        approach then used in quant_tests.py.

        Approach quant_tests:
            --------------------------
            X-squared =
            sum((obsevent - expevent)**2 / expevent(1 - pd))

            source:
            https://arxiv.org/pdf/1006.4968.pdf | page 6
            https://essay.utwente.nl/60800/1/BSc_Harm_Hoeksema.pdf | page 18

            --------------------------
            p-value = chi2.sf(x_squared, degrees_freedom)
            Survival function. Also defined as 1 - cdf,
            but sf is sometimes more accurate.

            source:
            https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2.html
            --------------------------

        Approach test_quant_tests:
            --------------------------
            X-squared =
            (((obsevents_pos - expevents_pos)**2/expevents_pos) +
            ((obsevents_neg - expevents_neg)**2/expevents_neg)).sum()

            source:
            https://www.data-essential.com/hosman-lemeshow-in-python/

            --------------------------
            p-value = 1-chi2.cdf(x_squared, degrees_freedom)
            1 - chi2 cumulative distribution function

            source:
            https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2.html
            --------------------------
        """

        df = self.get_ecb_adf_table()
        df["obsevents_pos"] = df["D"]
        df["expevents_pos"] = df["N"] * df["PD"]
        df["obsevents_neg"] = df["N"] - df["obsevents_pos"]
        df["expevents_neg"] = df["N"] - df["expevents_pos"]

        # Calculation of chi2 test statistic
        df["X_sq"] = (
            (df["obsevents_pos"] - df["expevents_pos"]) ** 2 / df["expevents_pos"]
        ) + ((df["obsevents_neg"] - df["expevents_neg"]) ** 2 / df["expevents_neg"])
        df["relative_X_sq"] = df["X_sq"] / df["X_sq"].sum()

        # Calculate the p-value
        x_sq_sum_HL2 = df["X_sq"].sum()
        d_freedom_HL2 = max(len(df) - 2, 1) if dof is None else dof

        pvalue_HL2 = 1 - chi2.cdf(x_sq_sum_HL2, d_freedom_HL2)

        return df, x_sq_sum_HL2, d_freedom_HL2, pvalue_HL2

    def test_hosmer_lemeshow_degrees_freedom_default_value(self):

        """
        Unit test case for Hosmer Lemeshow degrees of freedom parameter (dof)
        is equal to the default value None; implying a dof
        equal to the number of rating grades minus 2.
        """

        df = self.get_ecb_adf_table()

        df_HL1, x_sq_sum_HL1, d_freedom_HL1, pvalue_HL1 = hosmer_lemeshow_test(
            df, "Rating", "D", "N", "PD"
        )

        (
            df_HL2,
            x_sq_sum_HL2,
            d_freedom_HL2,
            pvalue_HL2,
        ) = self.test_hosmer_lemeshow_result()

        # Compare degrees of freedom
        self.assertEqual(
            d_freedom_HL1,
            d_freedom_HL2,
            msg="Error: Degrees " "of freedom are unequal.",
        )

    def test_hosmer_lemeshow_d_freedom_manual_value(self):

        """
        Unit test case for Hosmer Lemeshow degrees of freedom parameter (dof)
        equal to an acceptable manual input value; i.e. dof > 1 and integer.
        """
        # Obtain results with dof = 3
        df = self.get_ecb_adf_table()

        df_HL1, x_sq_sum_HL1, dof_HL1, pvalue_HL1 = hosmer_lemeshow_test(
            df, "Rating", "D", "N", "PD", dof=3
        )
        df_HL2, x_sq_sum_HL2, dof_HL2, pvalue_HL2 = self.test_hosmer_lemeshow_result(
            dof=3
        )

        # Compare p-values following from manual inputted degrees of freedom
        self.assertAlmostEqual(
            pvalue_HL1,
            pvalue_HL2,
            places=6,
            msg="Error: Different degrees of freedom " "result in different p-values.",
        )

    def test_hosmer_lemeshow_xsquared_values(self):

        """
        Unit test case for Hosmer Lemeshow X-squared values per rating grade.
        """

        df = self.get_ecb_adf_table()

        df_HL1, x_sq_sum_HL1, d_freedom_HL1, pvalue_HL1 = hosmer_lemeshow_test(
            df, "Rating", "D", "N", "PD"
        )

        (
            df_HL2,
            x_sq_sum_HL2,
            d_freedom_HL2,
            pvalue_HL2,
        ) = self.test_hosmer_lemeshow_result()

        # Compare X-squared values
        X_sq_HL1 = [round(elem, 5) for elem in df_HL1["X_sq"].tolist()]
        X_sq_HL2 = [round(elem, 5) for elem in df_HL2["X_sq"].tolist()]

        self.assertListEqual(
            X_sq_HL1, X_sq_HL2, msg="Error: X-squared values " "are unequal."
        )

    def test_hosmer_lemeshow_xsquared_sum_values(self):

        """
        Unit test case for Hosmer Lemeshow summed X-squared values (chi2 test
        statistic) per rating grade.
        """

        df = self.get_ecb_adf_table()

        df_HL1, x_sq_sum_HL1, d_freedom_HL1, pvalue_HL1 = hosmer_lemeshow_test(
            df, "Rating", "D", "N", "PD"
        )

        (
            df_HL2,
            x_sq_sum_HL2,
            d_freedom_HL2,
            pvalue_HL2,
        ) = self.test_hosmer_lemeshow_result()

        # Compare summed X-squared values (chi2 test statistic)
        self.assertEqual(
            x_sq_sum_HL1,
            x_sq_sum_HL2,
            msg="Error: Summed " "X-squared values are unequal.",
        )

    def test_hosmer_lemeshow_pvalues(self):

        """
        Unit test case for Hosmer Lemeshow p-value
        """

        df = self.get_ecb_adf_table()

        df_HL1, x_sq_sum_HL1, d_freedom_HL1, pvalue_HL1 = hosmer_lemeshow_test(
            df, "Rating", "D", "N", "PD"
        )

        (
            df_HL2,
            x_sq_sum_HL2,
            d_freedom_HL2,
            pvalue_HL2,
        ) = self.test_hosmer_lemeshow_result()

        # Compare p-values
        self.assertAlmostEqual(
            pvalue_HL1, pvalue_HL2, places=6, msg="P-values are not equal"
        )

    def test_hosmer_lemeshow_pd_values_error_1(self):

        """
        Test that a ValueError is raised if incorrect values in dataframes
        are passed:

        ValueError: if column PD_ <=0 or column PD_>=1.
        """

        # check for column PD_ < 0.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "PD"] = -1
        self.assertRaises(
            ValueError,
            hosmer_lemeshow_test,
            **{
                "adf_table": df_test,
                "rating_class_col": "Rating",
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
            },
        )

    def test_hosmer_lemeshow_pd_values_error_2(self):

        """
        Test that a ValueError is raised if incorrect values in dataframes
        are passed:

        ValueError: if column PD_>=1.
        """

        # check for column PD_> 1.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "PD"] = 2
        self.assertRaises(
            ValueError,
            hosmer_lemeshow_test,
            **{
                "adf_table": df_test,
                "rating_class_col": "Rating",
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
            },
        )

    def test_hosmer_lemeshow_default_values_error(self):

        """
        Test that a ValueError is raised if incorrect values in dataframes
        are passed:

        ValueError: if column _D < 0.
        """

        # check for column D_ < 0.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "D"] = -1
        self.assertRaises(
            ValueError,
            hosmer_lemeshow_test,
            **{
                "adf_table": df_test,
                "rating_class_col": "Rating",
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
            },
        )

    def test_hosmer_lemeshow_n_values_error(self):

        """
        Test that a ValueError is raised if incorrect values in dataframes
        are passed:

        ValueError: if column _N <= 0.
        """
        # check for column N_ < 0.
        df_test = self.get_ecb_adf_table()
        df_test.at[0, "N"] = -1
        self.assertRaises(
            ValueError,
            hosmer_lemeshow_test,
            **{
                "adf_table": df_test,
                "rating_class_col": "Rating",
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
            },
        )

    def test_hosmer_lemeshow_d_freedom_values_error_1(self):

        """
        Test that a ValueError is raised if incorrect value for d_freedom
        is passed:

        ValueError: if d_freedom is not integer
        """
        # check for d_freedom must be integer
        df_test = self.get_ecb_adf_table()
        d_freedom = "string input"
        self.assertRaises(
            ValueError,
            hosmer_lemeshow_test,
            **{
                "adf_table": df_test,
                "rating_class_col": "Rating",
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "dof": d_freedom,
            },
        )

    def test_hosmer_lemeshow_d_freedom_values_error_2(self):

        """
        Test that a ValueError is raised if incorrect value for d_freedom
        is passed:

        ValueError: if d_freedom < 1.
        """
        # check for d_freedom must be integer
        df_test = self.get_ecb_adf_table()
        d_freedom = -1
        self.assertRaises(
            ValueError,
            hosmer_lemeshow_test,
            **{
                "adf_table": df_test,
                "rating_class_col": "Rating",
                "default_count_col": "D",
                "customer_count_col": "N",
                "pd_col": "PD",
                "dof": d_freedom,
            },
        )


class TestHomogeneityHeterogeneityTest(unittest.TestCase):
    """
    Unit test case for the 'pearson_chi_squared_contingency' function.

    """

    @staticmethod
    def get_test_df_contingencytabel():

        df = pd.DataFrame(
            {
                "Default": [12, 23, 35],
                "Non-default": [345, 456, 801],
                "Total": [357, 479, 836],
            },
            index=["Rating grade 1", "Rating grade 2", "Total"],
        )
        return df

    def test_homogeneity_heterogeneity_test_input_value_error(self):
        """
        Test that a ValueError is raised if incorrect type of input.
        """
        s = "testString"

        self.assertRaises(ValueError, homogeneity_heterogeneity_test, s)

    def test_homogeneity_heterogeneity_test_arg_value_error(self):
        """
        Test that a ValueError is raised if incorrect shape of input.
        """
        A = np.array([[1, 2, 3, 4], [3, 4, 5, 6]])

        self.assertRaises(ValueError, homogeneity_heterogeneity_test, A)
        self.assertRaises(ValueError, homogeneity_heterogeneity_test, A[:2, :1])
        self.assertRaises(ValueError, homogeneity_heterogeneity_test, A[:2, :3])
        self.assertRaises(
            ValueError, homogeneity_heterogeneity_test, np.transpose(A[:2, :3])
        )

    def test_homogeneity_heterogeneity_test_dataframe(self):
        """
        Test the implementation of Pearson Chi squared test for contingency tables with dataframe.
        Values in dataframe as defined in specifications.
        """
        # generate test case
        df_test = self.get_test_df_contingencytabel()

        # run test
        self.assertAlmostEqual(
            homogeneity_heterogeneity_test(df_test), 1.057866370493214, places=8
        )

    def test_homogeneity_heterogeneity_nparray(self):
        """
        Test the implementation of Pearson Chi squared test for contingency tables with numpy array as input.
        Values in numpy array as defined in specifications.
        """
        # generate test case (2 x2 numpy array)
        df_test = self.get_test_df_contingencytabel()
        A = df_test.to_numpy()

        # run test
        self.assertAlmostEqual(
            homogeneity_heterogeneity_test(A), 1.057866370493214, places=8
        )


class TestInternalTTests(QuantTestClass):
    """
    Unit test case for 'crv.validation.calibration._paired_t',
    'crv.validation.calibration._unpaired_equal_var_t' &
    'crv.validation.calibration._unpaired_unequal_var_t'
    functions.

    Approach: Compare to results from 'scipy.stats.ttest_rel' &
    'scipy.stats.ttest_ind'
    """

    @staticmethod
    def create_dummy_lgd_data(self, bins):

        # Randomly create data
        dummy_pred_lgd = [random.choice(bins) for i in range(10000)]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(10000)]

        df = pd.DataFrame(
            list(zip(dummy_pred_lgd, dummy_act_lgd)), columns=["pred_lgd", "act_lgd"]
        )

        return df

    def test_internal_paired_t_test_result_two_tailed(self):
        """
        Test the crv.validation.calibration._paired_t function
        with default two sided argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_rel'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_rel(df[act_col], df[pred_col]))

        # crv.validation.calibration._paired_t result
        t_test_pylib = _paired_t(
            df,
            dof=None,
            side="two_sided",
            col_names={"est_col": pred_col, "act_col": act_col},
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        self.assertAlmostEqual(
            t_test_scipy[1], t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_paired_t_test_result_right_tailed(self):
        """
        Test the crv.validation.calibration._paired_t function
        with right-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_rel'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_rel(df[act_col], df[pred_col]))

        # crv.validation.calibration._paired_t result
        t_test_pylib = _paired_t(
            df,
            dof=None,
            side="right_tailed",
            col_names={"est_col": pred_col, "act_col": act_col},
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] < 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])

        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_equal_var_t_test_result_two_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with default two sided argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2]))
        print(t_test_scipy)

        # crv.validation.calibration._unpaired_equal_var_t result
        t_test_pylib = _unpaired_equal_var_t(
            df[group_1], df[group_2], dof=None, side="two_sided"
        )
        print(t_test_pylib)
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        self.assertAlmostEqual(
            t_test_scipy[1], t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_equal_var_t_test_result_right_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with right-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2]))

        # crv.validation.calibration._unpaired_equal_var_t result
        t_test_pylib = _unpaired_equal_var_t(
            df[group_1], df[group_2], dof=None, side="right_tailed"
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] < 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])

        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_equal_var_t_test_result_left_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with left-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2]))

        # crv.validation.calibration._unpaired_equal_var_t result
        t_test_pylib = _unpaired_equal_var_t(
            df[group_1], df[group_2], dof=None, side="left_tailed"
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] > 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])

        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_unequal_var_t_test_result_two_tailed(self):
        """
        Test the crv.validation.calibration._unpaired_unequal_var_t function
        with default two sided argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2], equal_var=False))
        print(t_test_scipy)

        # crv.validation.calibration._unpaired_unequal_var_t result
        t_test_pylib = _unpaired_unequal_var_t(
            df[group_1], df[group_2], dof=None, side="two_sided"
        )
        print(t_test_pylib)
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        self.assertAlmostEqual(
            t_test_scipy[1], t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_unequal_var_t_result_right_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_unequal_var_t function
        with right-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2], equal_var=False))

        # crv.validation.calibration._unpaired_unequal_var_t result
        t_test_pylib = _unpaired_unequal_var_t(
            df[group_1], df[group_2], dof=None, side="right_tailed"
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] < 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])

        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_unequal_var_t_result_left_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with left-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"

        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2], equal_var=False))

        # crv.validation.calibration._unpaired_unequal_var_t result
        t_test_pylib = _unpaired_unequal_var_t(
            df[group_1], df[group_2], dof=None, side="left_tailed"
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] > 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])

        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )


class TestTTest(QuantTestClass):
    """
    Unit test case for 'crv.validation.calibration.t_test'
    function. Approach: Test the index of the result_df to test the
    function 'crv.validation.calibration._create_bins_labels'

    Compare to results from 'scipy.stats.ttest_rel' for each
    of the segments.
    """

    @staticmethod
    def lgd_data_binned(self):

        # Create data
        id_facility = [str(i + 1) for i in range(7)]
        dummy_pred_lgd = [0.1, 0.3, 0.4, 0.25, 0.7, -0.9, 1.2]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(7)]

        df = pd.DataFrame(
            list(zip(id_facility, dummy_pred_lgd, dummy_act_lgd)),
            columns=["fac_id", "pred_lgd", "act_lgd"],
        )

        return df

    @staticmethod
    def create_dummy_lgd_data_continuous(self):
        # Create data
        dummy_pred_lgd = [
            0.06919768849729835,
            0.4238483414518164,
            0.06819555665084798,
            0.24091113367447714,
            0.15768544018320974,
            0.4574048430327885,
            0.18662731806792554,
            0.49908465921774336,
            0.1563663488786975,
            0.00036161047635829835,
        ]

        dummy_act_lgd = [
            0.19136165109161873,
            0.7262035421234629,
            0.8926142485832232,
            0.783813021645464,
            0.023006965228376308,
            0.13272011958336605,
            0.2887934329711561,
            0.1286566134022451,
            0.013555236567417084,
            0.5842637320454735,
        ]

        id_facility = [str(i + 1) for i in range(10)]
        df = pd.DataFrame(
            list(zip(id_facility, dummy_pred_lgd, dummy_act_lgd)),
            columns=["facility_id", "pred_lgd", "act_lgd"],
        )

        return df

    @staticmethod
    def create_dummy_wiki_data(self):
        "Data taken from https://en.wikipedia.org/wiki/Welch%27s_t-test"
        # Create data
        group_1 = [19.8, 20.4, 19.6, 17.8, 18.5, 18.9, 18.3, 18.9, 19.5, 22.0]

        group_2 = [
            28.2,
            26.6,
            20.1,
            23.3,
            25.2,
            22.1,
            17.7,
            27.6,
            20.6,
            13.7,
            23.2,
            17.5,
            20.6,
            18.0,
            23.9,
            21.6,
            24.3,
            20.4,
            24.0,
            13.2,
        ]

        df1 = pd.Series(group_1)
        df2 = pd.Series(group_2)

        return df1, df2

    def test_result_df_auto_less_twenty_bins_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        id_col = "fac_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df = self.lgd_data_binned(self)
        t_test0 = t_test(df[pred_col], df[act_col])
        result_df_index = t_test0.index
        expected_index = [-0.9, 0.1, 0.25, 0.3, 0.4, 0.7, 1.2]
        expected_N = [7, 1, 1, 1, 1, 1, 1, 1]

        for row in range(len(expected_index)):
            self.assertEqual(
                expected_index[row],
                list(result_df_index)[row + 1],
                f"Index value in bin number '{row}' not equal",
            )
        for row in range(result_df_index.shape[0]):
            self.assertEqual(
                expected_N[row],
                list(t_test0["N_group1"])[row],
                f"N value in bin number '{row}' not equal",
            )

    def test_index_result_df_lgd_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        id_col = "fac_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df = self.lgd_data_binned(self)
        result_df_index = t_test(df[pred_col], df[act_col], binning_type="lgd").index

        expected_index = [-0.9, 0.1, 0.25, 0.3, 0.4, 0.7, 1.2]

        for row in range(len(expected_index)):
            self.assertEqual(
                expected_index[row],
                list(result_df_index)[row + 1],
                f"Index value in bin number '{row}' not equal",
            )

    def test_result_lgd_binning_type_zero_not_in_unique_and_min_unique_above_zero(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        id_col = "fac_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df = self.lgd_data_binned(self)
        df.iloc[[5], [1]] = 0.70
        t_test0 = t_test(df[pred_col], df[act_col])
        result_df_index = t_test0.index
        expected_index = [0.1, 0.25, 0.3, 0.4, 0.7, 1.2]
        expected_N = [7, 1, 1, 1, 1, 2, 1]

        for row in range(len(expected_index)):
            self.assertEqual(
                expected_index[row],
                list(result_df_index)[row + 1],
                f"Index value in bin number '{row}' not equal",
            )

        for row in range(result_df_index.shape[0]):
            self.assertEqual(
                expected_N[row],
                list(t_test0["N_group1"])[row],
                f"N value in bin number '{row}' not equal",
            )

    def test_index_result_df_ecb_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        id_col = "fac_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df = self.lgd_data_binned(self)
        result_df_index = t_test(
            group_1_data=df[pred_col], group_2_data=df[act_col], binning_type="ecb"
        ).index

        expected_index = np.array(
            [
                [0, 0.05],
                [0.05, 0.1],
                [0.1, 0.2],
                [0.2, 0.3],
                [0.3, 0.4],
                [0.4, 0.5],
                [0.5, 0.6],
                [0.6, 0.7],
                [0.7, 0.8],
                [0.8, 0.9],
                [0.9, 1.0],
            ]
        )

        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][0],
                list(result_df_index)[row + 1].left,
                f"Left value in bin number '{row}' not equal",
            )
        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][1],
                list(result_df_index)[row + 1].right,
                f"Left value in bin number '{row}' not equal",
            )

        ## Test last index
        self.assertEqual(">= 1", list(result_df_index)[-1])

    def test_index_result_df_manual_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        id_col = "fac_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df = self.lgd_data_binned(self)
        result_df_index = t_test(
            df[pred_col],
            df[act_col],
            binning_type="manual",
            bins=[0.05, 0.1, 0.2, 0.3, 0.4],
        ).index
        expected_index = np.array([[0, 0.05], [0.05, 0.1], [0.1, 0.2], [0.2, 0.3]])

        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][0],
                list(result_df_index)[row + 1].left,
                f"Left value in bin number '{row}' not equal",
            )
        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][1],
                list(result_df_index)[row + 1].right,
                f"Left value in bin number '{row}' not equal",
            )

        ## Test last index
        self.assertEqual(">= 0.4", list(result_df_index)[-1])

    def test_value_error_duplicate_id(self):
        """
        Test value error raising when duplicate values
        are found on id_col.
        """
        df = self.lgd_data_binned(self)
        df.iloc[[1], [0]] = "1"
        self.assertRaises(
            ValueError,
            t_test,
            group_1_data=df,
            test_type="paired",
            col_names={"id_col": "fac_id", "est_col": "pred_lgd", "act_col": "act_lgd"},
        )

    def test_value_error_paired_test_id_not_specified(self):
        """
        Test value error raising when test_type = "paired" &
        id_data not specified.
        """
        df = self.lgd_data_binned(self)
        self.assertRaises(ValueError, t_test, group_1_data=df, test_type="paired")

    def test_value_error_incorrect_binning_type(self):
        """
        Test value error raising when binning type value
        is not one of the values allowed.
        """
        df = self.lgd_data_binned(self)
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df["pred_lgd"],
                "group_2_data": df["act_lgd"],
                "binning_type": "foo",
            },
        )

    def test_value_error_incorrect_bins_input(self):
        """
        Test value error raising when values in bins argument
        is not a list.
        """
        df = self.lgd_data_binned(self)
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df["pred_lgd"],
                "group_2_data": df["act_lgd"],
                "binning_type": "manual",
                "bins": 3,
            },
        )

    def test_value_error_incorrect_ttest_type(self):
        """
        Test value error raising when values in test_type argument
        is not on the values allowed.
        """
        df = self.lgd_data_binned(self)
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df["pred_lgd"],
                "group_2_data": df["act_lgd"],
                "test_type": "foo",
            },
        )

    def test_value_error_incorrect_side_type(self):
        """
        Test value error raising when values in side argument
        is not on the values allowed.
        """
        df = self.lgd_data_binned(self)
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df["pred_lgd"],
                "group_2_data": df["act_lgd"],
                "side": "foo",
            },
        )

    def test_value_error_incorrect_dof_type(self):
        """
        Test value error raising when type of dof argument
        is not a list.
        """
        df = self.lgd_data_binned(self)
        self.assertRaises(
            ValueError,
            t_test,
            **{"group_1_data": df["pred_lgd"], "group_2_data": df["act_lgd"], "dof": 3},
        )

    def test_segment_level_t_test(self):
        """
        Compare t_test statistic value & p-value to results
        obtained from 'scipy.stats.ttest_rel' for each
        of the segments.

        Note: It only compares values that are not NaN's.
        """
        df = self.create_dummy_lgd_data_continuous(self)
        id_col = "facility_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"
        binning_type = "ecb"
        t_test_result = t_test(
            df,
            col_names={"id_col": id_col, "est_col": pred_col, "act_col": act_col},
            test_type="paired",
            side="right_tailed",
            binning_type=binning_type,
        )

        t_test_result = (
            t_test_result.reset_index(drop=True)
            .loc[[0, 2, 3, 6]]
            .reset_index(drop=True)[["t_stat", "p_value"]]
            .values.tolist()
        )

        ## T-test values & p-values (two-sided test) below, are the result of the
        ## scipy.stats.ttest_rel implementation i.e. ttest_rel(dummy_act_lgd,dummy_pred_lgd).
        ## p-values are modified accordingly
        ## to extract the right tailed (one-sided) p-value, as per "ECB Instructions
        ## for reporting the validation results of internal models, February 2019."
        ## Section 2.6.2.1 & 2.9.3.1.
        expected_result = [
            [1.1712059416098368, 0.2715894839724747 / 2],
            [1.347919230702717, 0.40634595933247775 / 2],
            [-0.7274415151088657, (1 - 0.5425865061003926 / 2)],
            [-0.6032050733458877, (1 - 0.6076673569611182 / 2)],
        ]

        for row in range(len(t_test_result)):
            self.assertAlmostEqual(
                expected_result[row][0],
                t_test_result[row][0],
                10,
                f"t_test value in row '{row}' not equal",
            )

        for row in range(len(t_test_result)):
            self.assertAlmostEqual(
                expected_result[row][1],
                t_test_result[row][1],
                10,
                f"p-value in row '{row}' not equal",
            )

    def test_portfolio_level_t_equal_var_test(self):
        """
        Compare t_test statistic value & p-value to results
        obtained from https://en.wikipedia.org/wiki/Welch%27s_t-test.
        Third example.
        """
        df1, df2 = self.create_dummy_wiki_data(self)
        t_test_result = t_test(df1, df2)

        expected_result = [-1.65, 0.110]

        self.assertEqual(
            expected_result[0],
            round(t_test_result["t_stat"][0], 2),
            f"t_test value not equal",
        )

        self.assertEqual(
            expected_result[1],
            round(t_test_result["p_value"][0], 3),
            f"p-value not equal",
        )

    def test_portfolio_level_t_unequal_var_test(self):
        """
        Compare t_test statistic value & p-value to results
        obtained from https://en.wikipedia.org/wiki/Welch%27s_t-test.
        Third example.
        """
        df1, df2 = self.create_dummy_wiki_data(self)
        t_test_result = t_test(df1, df2, test_type="unpaired_unequal_variances")

        expected_result = [-2.22, 0.036]

        self.assertEqual(
            expected_result[0],
            round(t_test_result["t_stat"][0], 2),
            f"t_test value not equal",
        )

        self.assertEqual(
            expected_result[1],
            round(t_test_result["p_value"][0], 3),
            f"p-value not equal",
        )

    def test_value_warning_empty_input_data(self):
        """
        Testwarning raising when either input data
        group_1_data or group_2_data are empty.
        """
        df = self.lgd_data_binned(self)
        df1 = df["pred_lgd"]
        df2 = pd.Series([])
        self.assertWarns(Warning, t_test, group_1_data=df1, group_2_data=df2)


if __name__ == "__main__":
    unittest.main()
