"""
# ============================================================================
# TEST_SUMMARY.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.VALIDATION.SUMMARY.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.validation.summary' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Lee MacKenzie Fischer <G01679>
# ============================================================================
"""

import random
import unittest
import numpy as np
import pandas as pd
import sklearn
from sklearn import metrics
from crv.validation.summary import (
    pandas_pd_portfolio_information,
    pandas_adf_summary,
    pandas_migration_matrix,
    pandas_lgd_contingency_table,
    lgd_contingency_table,
    mm_summary,
)
from crv.utils.dataframe_helper import rating_cats


class TestPandasPdPortfolioInformation(unittest.TestCase):
    """
    Unit test case for the 'pandas_pd_portfolio_information' function.
    """

    @staticmethod
    def get_test_data():
        """
        Sets up the sample data for the unit tests.
        """
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "c"],
                "rating": ["3+", "4+", "0-"],
                "default": [0, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        df1_sum_list = [111, 222, 3, 3, 200, 1]
        df2_sum_list = [444, 333, 3, 2, 303, 2]
        df_change = [
            (df2_sum_list[i] - df1_sum_list[i]) / df1_sum_list[i]
            for i in range(len(df2_sum_list))
        ]
        d_col = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        return df1, df2, df1_sum_list, df2_sum_list, d_col, df_change

    def test_pandas_pd_portfolio_information_result(self):
        df1_test, df2_test, sum1, sum2, d_col, dc = self.get_test_data()
        df_res = pandas_pd_portfolio_information(df1_test, df2_test, d_col)
        self.assertEqual(
            list(df_res["Beginning of the observation period"]),
            sum1,
            "'Beginning' summary does not match.",
        )
        self.assertEqual(
            list(df_res["End of the observation period"]),
            sum2,
            "'End' summary does not match.",
        )
        self.assertEqual(list(df_res["Change"]), dc, "'Change' summary does not match.")

    def test_pandas_pd_portfolio_information_ValueError_pandas_dataframe_type(self):
        _, _, _, _, d_col, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            pandas_pd_portfolio_information,
            **{"df1": 1, "df2": 2, "d_colnames": d_col},
        )

    def test_pandas_pd_portfolio_information_ValueError_incomplete_input_arg(self):
        d = {"RWEA": "rwea", "cust_id": "cid", "rating": "rating", "default": "default"}
        df1_test, df2_test, _, _, _, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            pandas_pd_portfolio_information,
            **{"df1": df1_test, "df2": df2_test, "d_colnames": d},
        )

    def test_pandas_pd_portfolio_information_ValueError_column_not_found(self):
        df1_test, df2_test, _, _, d_col, _ = self.get_test_data()
        df1_test = df1_test.drop(columns=["ead"])
        self.assertRaises(
            ValueError,
            pandas_pd_portfolio_information,
            **{"df1": df1_test, "df2": df2_test, "d_colnames": d_col},
        )

    def test_pandas_pd_portfolio_information_ValueError_column_name_repeated(self):
        d = {
            "RWEA": "rwea",
            "EAD": "rwea",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        df1_test, df2_test, _, _, _, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            pandas_pd_portfolio_information,
            **{"df1": df1_test, "df2": df2_test, "d_colnames": d},
        )

    def test_pandas_pd_portfolio_information_ValueError_non_unique_id(self):
        """
        Checks that a ValueError is raised if one of the DataFrames contains
        non-unique IDs.
        """
        d_col = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "b"],
                "rating": ["3+", "4+", "0-"],
                "default": [0, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        self.assertRaises(ValueError, pandas_pd_portfolio_information, df1, df2, d_col)

    def test_pandas_pd_portfolio_information_ValueError_invalid_default_flag(self):
        """
        Checks that a ValueError is raised if values other than '1' or '0' are
        present in the default flag column.
        """
        d_col = {
            "RWEA": "rwea",
            "EAD": "ead",
            "cust_id": "cid",
            "rating": "rating",
            "default": "default",
        }
        df1 = pd.DataFrame.from_dict(
            {
                "rwea": [1, 10, 100],
                "ead": [2, 20, 200],
                "cid": ["a", "b", "c"],
                "rating": ["3+", "4+", "0-"],
                "default": [2, 0, 1],
            }
        )
        df2 = pd.DataFrame.from_dict(
            {
                "rwea": [400, 40, 4],
                "ead": [3, 30, 300],
                "cid": ["a", "d", "e"],
                "rating": ["0+", "6+", "0+"],
                "default": [1, 0, 1],
            }
        )
        self.assertRaises(ValueError, pandas_pd_portfolio_information, df1, df2, d_col)


class TestPandasMigrationMatrix(unittest.TestCase):
    """
    Unit test case for the pandas_migration_matrix function.
    """

    @staticmethod
    def get_test_data():
        """
        Creates 2 tables of synthetic data for testing calculations.
        """
        d_migration = {
            "6": {"6": 0.8, "3": 0.2, "1": 0.0},
            "3": {"6": 0.2, "3": 0.7, "1": 0.1},
            "1": {"6": 0.1, "3": 0.3, "1": 0.6},
        }

        mm_true = (
            pd.DataFrame.from_dict(d_migration, orient="index")
            .loc[["6", "3", "1"]]
            .to_numpy()
        )
        num_grades = len(d_migration)
        num_act_per_grade = 10_000
        total_act = num_grades * num_act_per_grade
        dfr = pd.DataFrame.from_dict(
            {
                "group": [
                    "XT" + str(i).zfill(int(np.log10(total_act) + 2))
                    for i in range(total_act)
                ],
                "rating_x": [
                    np.random.choice(["6", "3", "1"]) for i in range(total_act)
                ],
            }
        )
        dfr["FGRAD_MET"] = "03"
        dfr["dflag"] = 0
        dfr["rating_y"] = dfr["rating_x"].apply(
            lambda x: np.random.choice(
                a=list(d_migration[x].keys()), p=list(d_migration[x].values())
            )
        )
        df_1 = (
            dfr[["group", "rating_x", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_x": "Rating"})
        )
        df_2 = (
            dfr[["group", "rating_y", "FGRAD_MET", "dflag"]]
            .copy()
            .rename(columns={"rating_y": "Rating"})
        )
        df_1.loc[0:19, "dflag"] = 1
        df_2.loc[20:39, "dflag"] = 1
        df_2.loc[40:59, "FGRAD_MET"] = "02"
        df_1.loc[60:79, "FGRAD_MET"] = np.nan
        df_2.loc[75:94, "FGRAD_MET"] = np.nan
        df_1.loc[95:109, "Rating"] = np.nan
        df_2.loc[110:124, "Rating"] = np.nan
        df_2 = df_2.drop([i for i in range(100, 119)])

        return df_1.copy(), df_2.copy(), mm_true.copy()

    def test_pandas_migration_matrix_calculation(self):
        """
        Test if the pandas_migration_matrix function calculates the correct
        values for each cell.
        """
        # Get synthetic data.
        df_1, df_2, mm_true = self.get_test_data()

        mm_pandas = pandas_migration_matrix(
            data_0=df_1,
            data_1=df_2,
            id_col="group",
            rating_col="Rating",
            model_col="FGRAD_MET",
            default_col="dflag",
        )

        dfmm = mm_pandas.multiply(mm_pandas.N, axis=0)
        mm_pandas = mm_pandas.drop(labels="N", axis=1)
        arr_pandas = mm_pandas.loc[["6", "3", "1"], ["6", "3", "1"]].to_numpy()
        dfmm = dfmm.drop(labels="N", axis=1)
        arr_pandas2 = (
            dfmm[
                [
                    "Defaults",
                    "Other model",
                    "Relationship terminated",
                    "Missing rating",
                    "Missing model",
                ]
            ]
            .sum(axis=0)
            .to_numpy()
        )
        self.assertEqual(
            np.allclose(arr_pandas, mm_true, atol=0.1),
            True,
            msg="'test_pandas_migration_matrix_pandas_result' - "
            + "pandas result probabilities not within tolerance."
            + f"\n{arr_pandas} != {mm_true}",
        )
        self.assertEqual(
            np.allclose(
                mm_pandas.sum(axis=1).to_numpy(), np.array([1, 1, 1, 1, 1]), atol=1e-10
            ),
            True,
            msg="'test_pandas_migration_matrix_pandas_result' - "
            + "pandas result row sums are not within tolerance."
            + f"\n{mm_pandas.sum(axis=1).to_numpy()} != {np.array([1, 1, 1, 1, 1])}",
        )
        self.assertEqual(
            np.allclose(arr_pandas2, np.array([20, 35, 19, 6, 20]), atol=1e-1),
            True,
            msg="'test_pandas_migration_matrix_pandas_result' - "
            + "pandas result K+3 column sums are not within tolerance."
            + f"\n{arr_pandas2} != {np.array([20, 35, 19,  6, 20])}",
        )

    def test_pandas_migration_matrix_categorical_input(self):
        """
        Testing the pandas_migration_matrix function using a column of
        Categorical type input.
        """
        # Get synthetic data.
        df_1, df_2, mm_true = self.get_test_data()
        df_1_cat = df_1.copy()
        df_2_cat = df_2.copy()
        df_1_cat.Rating = df_1_cat.Rating.fillna("M")
        df_2_cat.Rating = df_2_cat.Rating.fillna("M")
        df_1_cat = rating_cats(df_1_cat, "Rating")
        df_2_cat = rating_cats(df_2_cat, "Rating")

        # Checking that inputting one model column as categorical works
        # even if it has more categories than the other model column.
        df_1_cat["FGRAD_MET"] = df_1_cat["FGRAD_MET"].astype("category")
        df_1_cat["FGRAD_MET"] = df_1_cat["FGRAD_MET"].cat.add_categories("Extra cat")
        df_1_cat_test = df_1_cat.copy()
        df_2_cat_test = df_2_cat.copy()
        mm_pandas = pandas_migration_matrix(
            data_0=df_1,
            data_1=df_2,
            id_col="group",
            rating_col="Rating",
            model_col="FGRAD_MET",
            default_col="dflag",
        )

        dfmm = mm_pandas.multiply(mm_pandas.N, axis=0)
        mm_pandas = mm_pandas.drop(labels="N", axis=1)
        arr_pandas = mm_pandas.loc[["6", "3", "1"], ["6", "3", "1"]].to_numpy()
        dfmm = dfmm.drop(labels="N", axis=1)
        arr_pandas2 = (
            dfmm[
                [
                    "Defaults",
                    "Other model",
                    "Relationship terminated",
                    "Missing rating",
                    "Missing model",
                ]
            ]
            .sum(axis=0)
            .to_numpy()
        )
        self.assertEqual(
            np.allclose(arr_pandas, mm_true, atol=0.1),
            True,
            msg="'test_pandas_migration_matrix_pandas_result' - "
            + "pandas result probabilities not within tolerance."
            + f"\n{arr_pandas} != {mm_true}",
        )
        self.assertEqual(
            np.allclose(
                mm_pandas.sum(axis=1).to_numpy(), np.array([1, 1, 1, 1, 1]), atol=1e-10
            ),
            True,
            msg="'test_pandas_migration_matrix_pandas_result' - "
            + "pandas result row sums are not within tolerance."
            + f"\n{mm_pandas.sum(axis=1).to_numpy()} != {np.array([1, 1, 1, 1, 1])}",
        )
        self.assertEqual(
            np.allclose(arr_pandas2, np.array([20, 35, 19, 6, 20]), atol=1e-1),
            True,
            msg="'test_pandas_migration_matrix_pandas_result' - "
            + "pandas result K+3 column sums are not within tolerance."
            + f"\n{arr_pandas2} != {np.array([20, 35, 19,  6, 20])}",
        )

        # Ensure that the DataFrames are not modified during the
        # calculation of the migration matrix.
        pd.testing.assert_frame_equal(df_1_cat, df_1_cat_test)
        pd.testing.assert_frame_equal(df_2_cat, df_2_cat_test)

    def test_pandas_migration_matrix_value_error_df_type(self):
        """
        Check that an error gets raised if the input DataFrame is
        not a pandas.DataFrame.
        """
        # Get synthetic data.
        _, df_2, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            pandas_migration_matrix,
            **{
                "data_0": 1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )

    def test_pandas_migration_matrix_value_error_df_same_type(self):
        """
        Check that an error gets raised if the two input DataFrames
        are not of the same data type.
        """
        # Get synthetic data.
        df_1, _, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            pandas_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": 2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )

    def test_pandas_migration_matrix_value_error_column_not_found(self):
        """
        Check that an error gets raised if all required columns are
        not present within both DataFrames.
        """
        # Get synthetic data.
        df_1, df_2, _ = self.get_test_data()
        self.assertRaises(
            ValueError,
            pandas_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "col_not_found",
                "default_col": "dflag",
            },
        )

    def test_pandas_migration_matrix_value_error_default_values(self):
        """
        Check that an error gets raised if there are values in the
        default column that are not '1', or '0'.
        """
        df_1, df_2, _ = self.get_test_data()
        df_1.loc[df_1["dflag"] == 1, "dflag"] = np.nan
        self.assertRaises(
            ValueError,
            pandas_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )

    def test_pandas_migration_matrix_value_error_duplicate_id(self):
        """
        Check that an error gets raised if the values in the
        customer id column are not distinct.
        """
        df_1, df_2, _ = self.get_test_data()
        df_1.loc[df_1["dflag"] == 1, "group"] = "ABC123"
        self.assertRaises(
            ValueError,
            pandas_migration_matrix,
            **{
                "data_0": df_1,
                "data_1": df_2,
                "id_col": "group",
                "rating_col": "Rating",
                "model_col": "FGRAD_MET",
                "default_col": "dflag",
            },
        )


class TestMmSummary(unittest.TestCase):
    """
    Test class for the function
    'crv.validation.stability
    """

    def test_mm_summary_correct_result(self):
        """
        Tests for the correct execution of the mm_summary function
        using sample data and hand calculation.
        """
        row_sums = [119, 182, 241, 186, 122, 61]
        # Setup example migration matrix.
        mm_example = pd.DataFrame.from_dict(
            {
                "A": [100, 10, 5, 1, 1, 0],
                "B": [15, 150, 20, 4, 0, 0],
                "C": [4, 15, 200, 15, 6, 1],
                "D": [0, 5, 10, 150, 10, 5],
                "E": [0, 1, 6, 10, 100, 5],
                "F": [0, 1, 0, 6, 5, 50],
                "N": row_sums,
            }
        )
        mm_example.index = ["A", "B", "C", "D", "E", "F"]
        mm_example = mm_example[mm_example.index].divide(mm_example["N"], axis=0)
        mm_example["N"] = row_sums
        # Setup correct result.
        obs_counts = [3, 20, 60, 750, 55, 21, 2]
        summary_correct = pd.DataFrame.from_dict(
            {"N_Obs": obs_counts, "Perc": [i / sum(row_sums) for i in obs_counts]}
        )
        summary_result = mm_summary(mm_example)
        self.assertTrue(
            np.allclose(
                summary_correct.to_numpy(), summary_result.to_numpy(), equal_nan=True
            )
        )


class TestPandasAdfSummary(unittest.TestCase):
    """
    Unit test case for the pandas_adf_summary function.
    """

    @staticmethod
    def dname(col):
        d_colname = {"N": "N", "PD": "PD", "D": "D", "ADF": "ADF"}
        return d_colname[col]

    @staticmethod
    def get_ecb_adf_table():
        d_adf = {
            "rat_rank": list(range(17)),
            "Rating": [str(i + 1) for i in range(17)],
            "N": [
                105_000,
                110_000,
                100_000,
                80_000,
                60_000,
                120_000,
                135_000,
                40_000,
                30_000,
                75_000,
                55_000,
                40_000,
                30_000,
                20_000,
                10_000,
                5_000,
                2_000,
            ],
            "D": [
                10,
                20,
                20,
                30,
                50,
                100,
                150,
                90,
                50,
                350,
                550,
                750,
                900,
                1000,
                900,
                700,
                1500,
            ],
            "PD": [
                0.0001,
                0.00015,
                0.0002,
                0.0004,
                0.0008,
                0.0009,
                0.001,
                0.0015,
                0.002,
                0.005,
                0.01,
                0.02,
                0.03,
                0.05,
                0.1,
                0.15,
                0.5,
            ],
            "ORGEXP": [
                400_000_000,
                440_000_000,
                390_000_000,
                315_000_000,
                235_000_000,
                470_000_000,
                530_000_000,
                150_000_000,
                120_000_000,
                300_000_000,
                210_000_000,
                160_000_000,
                120_000_000,
                80_000_000,
                40_000_000,
                20_000_000,
                8_000_000,
            ],
        }
        df = pd.DataFrame.from_dict(d_adf)
        df = df.sort_values("rat_rank")
        return df

    @staticmethod
    def get_test_df():
        d_sample_data = {
            "rating_col": ["1", "2", "2", "3", "3", "9"],
            "customer_id": [f"A00{i}" for i in range(6)],
            "group": ["1", "1", "2", "3", "4", "4"],
            "def_flag": [1, 1, 0, 1, 0, 1],
            "PD": [0.01, 0.02, 0.02, 0.03, 0.03, 0.09],
            "PDG": [0.01, 0.01, 0.02, 0.03, 0.03, 0.03],
            "ratG": ["1", "1", "2", "3", "3", "3"],
            "country": ["DK", "DK", "DK", "SE", "SE", "DK"],
            "ORGEXP": [100, 200, 300, 400, 500, 100],
        }
        df_sample_data = pd.DataFrame.from_dict(d_sample_data)
        col_dict = {
            "rating": "rating_col",
            "ratG": "ratG",
            "cid": "customer_id",
            "group": "group",
            "default": "def_flag",
            "pd": "PD",
            "pdg": "PDG",
            "country": "country",
            "orgexp": "ORGEXP",
            "adf": "ADF",
        }
        df_sample_data = rating_cats(
            df_sample_data, "rating_col", category_list=["1", "2", "3", "9"]
        )
        return df_sample_data, col_dict

    def test_pandas_adf_summary_no_group_no_sum(self):
        df_test, col_dict = self.get_test_df()
        adf_table = pandas_adf_summary(
            data=df_test, customer_col=col_dict["cid"], default_col=col_dict["default"]
        )
        results = {
            self.dname("N"): df_test[col_dict["cid"]].count(),
            self.dname("D"): df_test[col_dict["default"]].sum(),
            self.dname("ADF"): (
                df_test[col_dict["default"]].sum() / df_test[col_dict["cid"]].count()
            ),
        }
        for col in results.keys():
            self.assertEqual(
                adf_table[col][0], results[col], f"Incorrect result for '{col}' column."
            )

    def test_pandas_adf_summary_group_level_no_group_no_sum(self):
        df_test, col_dict = self.get_test_df()
        adf_table = pandas_adf_summary(
            data=df_test,
            customer_col=col_dict["group"],
            default_col=col_dict["default"],
        )
        df_test = (
            df_test.groupby("group")
            .agg({"def_flag": "max", "ORGEXP": "sum"})
            .reset_index()
        )
        results = {
            self.dname("N"): df_test[col_dict["group"]].count(),
            self.dname("D"): df_test[col_dict["default"]].sum(),
            self.dname("ADF"): (
                df_test[col_dict["default"]].sum() / df_test["group"].count()
            ),
        }
        for col in results.keys():
            self.assertEqual(
                adf_table[col][0], results[col], f"Incorrect result for '{col}' column."
            )

    def test_pandas_adf_summary_group_level_country_group_sum(self):
        df_test, col_dict = self.get_test_df()
        adf_table = pandas_adf_summary(
            data=df_test,
            customer_col=col_dict["group"],
            default_col=col_dict["default"],
            group_list=["country"],
            sum_list=["ORGEXP"],
        )
        results = {
            "country": ["DK", "SE"],
            self.dname("N"): [3, 2],
            self.dname("D"): [2, 1],
            self.dname("ADF"): [2 / 3, 1 / 2],
        }
        for col in results.keys():
            self.assertEqual(
                list(adf_table[col]),
                results[col],
                f"Incorrect result for '{col}' column.",
            )

    def test_pandas_adf_summary_no_group(self):
        df_test, col_dict = self.get_test_df()
        adf_table = pandas_adf_summary(
            data=df_test,
            customer_col=col_dict["cid"],
            default_col=col_dict["default"],
            sum_list=["ORGEXP"],
        )
        results = {
            self.dname("N"): df_test[col_dict["cid"]].count(),
            self.dname("D"): df_test[col_dict["default"]].sum(),
            "ORGEXP": df_test[col_dict["orgexp"]].sum(),
        }
        for col in results.keys():
            self.assertEqual(
                adf_table[col][0], results[col], f"Incorrect result for '{col}' column."
            )

    def test_pandas_adf_summary_no_sum(self):
        df_test, col_dict = self.get_test_df()
        adf_table = pandas_adf_summary(
            data=df_test,
            customer_col=col_dict["cid"],
            default_col=col_dict["default"],
            group_list=["rating_col"],
        )
        results = {
            "rating_col": ["1", "2", "3", "9"],
            self.dname("N"): [1, 2, 2, 1],
            self.dname("D"): [1, 1, 1, 1],
            self.dname("ADF"): [1, 1 / 2, 1 / 2, 1],
        }
        for col in results.keys():
            self.assertEqual(
                list(adf_table[col]),
                results[col],
                f"Incorrect result for '{col}' column.",
            )

    def test_pandas_adf_summary_UserWarning(self):
        df_test, col_dict = self.get_test_df()
        self.assertWarns(
            UserWarning,
            pandas_adf_summary,
            **{
                "data": df_test,
                "customer_col": col_dict["cid"],
                "default_col": col_dict["default"],
                "sum_list": ["country"],
                "group_list": ["rating_col"],
            },
        )

    def test_pandas_adf_summary_ValueError(self):
        df_test, col_dict = self.get_test_df()
        self.assertRaises(
            ValueError,
            pandas_adf_summary,
            **{
                "data": df_test,
                "customer_col": col_dict["cid"],
                "default_col": col_dict["default"],
                "sum_list": [col_dict["cid"]],
                "group_list": ["rating_col"],
            },
        )

    def test_pandas_adf_summary_mean_PD(self):
        """
        Tests that the mean of the PD is calculated when the 'pd_col'
        argument is supplied.
        """
        df_test, col_dict = self.get_test_df()
        adf_table = pandas_adf_summary(
            data=df_test,
            customer_col=col_dict["cid"],
            default_col=col_dict["default"],
            group_list=["rating_col"],
            pd_col="PDG",
        )
        results = {
            "rating_col": ["1", "2", "3", "9"],
            self.dname("N"): [1, 2, 2, 1],
            self.dname("D"): [1, 1, 1, 1],
            self.dname("ADF"): [1, 1 / 2, 1 / 2, 1],
            "PDG": [0.01, 0.015, 0.03, 0.03],
        }
        for col in results.keys():
            self.assertEqual(
                list(adf_table[col]),
                results[col],
                f"Incorrect result for '{col}' column.",
            )

    def test_pandas_adf_summary_allow_empty(self):
        """
        Test that groupings with zero customers are shown in the ADF table.
        """
        df_test, col_dict = self.get_test_df()
        df_test = rating_cats(
            df_test.copy(), "rating_col", category_list=["1", "2", "3", "4", "9"]
        )
        adf_table = pandas_adf_summary(
            data=df_test,
            customer_col=col_dict["cid"],
            default_col=col_dict["default"],
            group_list=["rating_col"],
            supress_empty=False,
        )
        adf_table["ADF"] = adf_table["ADF"].fillna(0)
        results = {
            "rating_col": ["1", "2", "3", "4", "9"],
            self.dname("N"): [1, 2, 2, 0, 1],
            self.dname("D"): [1, 1, 1, 0, 1],
            self.dname("ADF"): [1.0, 1 / 2, 1 / 2, 0, 1.0],
        }
        for col in results.keys():
            self.assertEqual(
                list(adf_table[col]),
                results[col],
                f"Incorrect result for '{col}' column.",
            )


class TestPandasLgdContingencyTable(unittest.TestCase):
    """
    Unit test case for the pandas lgd_contigency_table function.

    Approach summary.pandas_lgd_contingency_table:
        Estimated and realised LGDs are discretionised on facility
        level using pandas.cut.

        The contingency frequency matrix is created using the pandas
        groupby.count() function.

    Approach test_summary.create_contigency_table:
        Estimated and realised LGDs are discretionised on facility
        level using np.digitize.

        The contingency frequency matrix is created using the sklearn
        metrics.cluster.contingency_matrix() function.

    """

    @staticmethod
    def create_dummy_lgd_data(self, bins):
        """ Randomly create data """
        dummy_pred_lgd = [random.choice(bins) for i in range(10000)]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(10000)]

        df = pd.DataFrame(
            list(zip(dummy_pred_lgd, dummy_act_lgd)), columns=["pred_lgd", "act_lgd"]
        )

        return df

    @staticmethod
    def create_contingency_table(self, df, bins, binning_type=None):
        """ Add max to bin """
        act_lgd_max = df["act_lgd"].max()
        pred_lgd_max = df["pred_lgd"].max()
        cond_pred_lgd = True if bins[-1] < pred_lgd_max else False
        cond_act_lgd = True if bins[-1] < act_lgd_max else False
        lgd_max = max(act_lgd_max, pred_lgd_max)
        if bins[-1] < lgd_max:
            bins = bins + [lgd_max + 1]
        else:
            bins = bins + [bins[-1] + 1]

        # Obtain arrays in Numpy
        pred_lgd = df[["pred_lgd"]].values
        act_lgd = df[["act_lgd"]].values

        # Cap negative actual LGDs at zero
        act_lgd = act_lgd.clip(min=0)

        if binning_type == "ecb" or binning_type == "manual":
            act_lgd_binned = np.digitize(act_lgd, bins, right=False)
            pred_lgd = np.digitize(pred_lgd, bins, right=False)
        else:
            act_lgd_binned = np.digitize(act_lgd, bins, right=True)

        df = pd.DataFrame(
            list(zip(pred_lgd, act_lgd, act_lgd_binned)),
            columns=["pred_lgd", "act_lgd", "act_lgd_binned"],
        )

        # Create contingency matrix using Sklearn
        freq_mat_1 = sklearn.metrics.cluster.contingency_matrix(
            pred_lgd, act_lgd_binned, eps=None, sparse=False
        )

        # sklearn.contingency_matrix does not include bins when there are no
        # observations in that bin. Therefore, in case there are no
        # actual LGDs greater than bin[-1], we need to include the
        # top bin (>[bins[-1]] manually to align with the function in
        # summary.py, which always include a top bin.
        if np.size(freq_mat_1, 1) < len(bins):
            if binning_type == "lgd":
                if cond_pred_lgd:
                    freq_mat_2 = np.zeros((len(bins), len(bins) + 1))
                    freq_mat_2[: len(bins), : len(bins) - 1] = freq_mat_1
                else:
                    freq_mat_2 = np.zeros((len(bins) - 1, len(bins)))
                    freq_mat_2[: len(bins) - 1, : len(bins) - 1] = freq_mat_1
            elif binning_type == "ecb" or binning_type == "manual":
                if cond_pred_lgd:
                    freq_mat_2 = np.zeros((len(bins) - 1, len(bins) - 1))
                    freq_mat_2[: len(bins) - 1, : len(bins) - 2] = freq_mat_1[
                        : len(bins) - 1, : len(bins) - 2
                    ]
                elif cond_act_lgd:
                    freq_mat_2 = freq_mat_1
                else:
                    freq_mat_2 = np.zeros((len(bins) - 1, len(bins) - 1))
                    freq_mat_2[: len(bins) - 1, : len(bins) - 2] = freq_mat_1
        else:
            freq_mat_2 = freq_mat_1

        return freq_mat_2

    def test_lgd_contingency_table_ecb_result(self):
        """
        Test for the correct calculation of the lgd contingency table using
        ECB bins using randomly created actual LGD dummy data.

        The ECB bins were extracted from
        "LEICode_LGD_ModelID_EndOfObservationPeriod_versionNumber.xlsx"
        """

        # ECB bins
        bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)

        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "ecb")
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "ecb")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of LGD contingency tables with ECB binning.",
            )

    def test_lgd_contingency_table_lgd_result(self):
        """
        Test for the correct calculation of the lgd contingency table using
        LGD created bins (discretisation on the basis of the estimated LGD)
        using randomly created actual LGD dummy data.

        The LGD bins were extracted from "lgd.sas7bdat" with the function
        df['lgd_estimate'].unique()
        """

        # LGD bins
        bins = [
            0.054,
            0.173,
            0.205,
            0.224,
            0.227,
            0.243,
            0.265,
            0.27,
            0.272,
            0.279,
            0.293,
            0.302,
            0.318,
            0.319,
            0.331,
            0.332,
            0.341,
        ]
        df = self.create_dummy_lgd_data(self, bins)

        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd", "lgd")
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins)

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of LGD contingency tables with LGD binning.",
            )

    def test_lgd_contingency_table_manual_result(self):
        """
        Test for the correct calculation of the lgd contingency table using
        manually created bins based on randomly created actual LGD dummy data.
        """

        # manual bins
        bins = [0, 0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "manual")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of LGD contingency tables with manual binning.",
            )

    def test_lgd_contingency_table_negative_actual_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an actual LGD < 0
        """
        bins = [0, 0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "act_lgd"] = -1

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "manual")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a negative actual LGD",
            )

    def test_lgd_contingency_table_zero_actual_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an actual LGD = 0
        """
        bins = [0, 0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "act_lgd"] = 0

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "manual")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a zero actual LGD",
            )

    def test_lgd_contingency_table_NA_actual_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an NA actual LGD
        """
        bins = [0, 0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "act_lgd"] = np.nan

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        df = df.dropna(subset=["act_lgd"])
        freq_mat_2 = self.create_contingency_table(self, df, bins, "manual")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using a zero actual LGD",
            )

    def test_lgd_contingency_table_large_actual_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an actual LGD >1
        """
        bins = [0, 0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "act_lgd"] = 3

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "manual")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using an actual LGD > 1",
            )

    def test_lgd_contingency_table_large_pred_lgd_lgd(self):
        """
        Test for the correct calculation of the lgd contingency table when
        there is an predicted LGD equal to 2.
        """
        bins = [0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "pred_lgd"] = 2

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "lgd", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "lgd")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using an actual LGD > 1",
            )

    def test_lgd_contingency_table_large_pred_lgd_ecb(self):
        """
        Test for the correct calculation of the ecb lgd contingency table when
        there is an predicted LGD equal to 2.
        """
        bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "pred_lgd"] = 2

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "ecb", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "ecb")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using an actual LGD > 1",
            )

    def test_lgd_contingency_table_large_pred_lgd_manual(self):
        """
        Test for the correct calculation of the manual lgd contingency table
        when there is an predicted LGD equal to 2.
        """
        bins = [0, 0.25, 0.5, 0.75, 1]
        df = self.create_dummy_lgd_data(self, bins)
        df.at[0, "pred_lgd"] = 2

        freq_mat = pandas_lgd_contingency_table(
            df, "pred_lgd", "act_lgd", "manual", bins=bins
        )
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "manual")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using an actual LGD > 1",
            )

    def test_lgd_contingency_table_binning_type_auto_lgd_1(self):
        """
        Test for the correct calculation of the lgd contingency table when
        default option for binning_type = 'auto' is selected.

        This test should activate the binning_type = "lgd"
        """
        # Test when number of pools < 20:
        bins = [0.2, 0.4, 0.6, 0.8, 1]
        df = self.create_dummy_lgd_data(self, bins)

        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd")
        freq_mat_1 = freq_mat.values.tolist()

        freq_mat_2 = self.create_contingency_table(self, df, bins, "lgd")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using binning_type='auto' "
                "where the lgd option should be activated.",
            )

    def test_lgd_contingency_table_binning_type_auto_lgd_2(self):
        """
        Test for the correct calculation of the lgd contingency table when
        default option for binning_type = 'auto' is selected.

        This test should activate the binning_type = "ecb"
        """
        # Test when number of pools > 20:
        lgd_estimates = [
            0,
            0.05,
            0.1,
            0.15,
            0.2,
            0.25,
            0.3,
            0.35,
            0.4,
            0.45,
            0.5,
            0.55,
            0.6,
            0.65,
            0.7,
            0.75,
            0.8,
            0.85,
            0.9,
            0.95,
            0.975,
            1,
        ]

        # ECB bins
        bins = [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]

        # Create dataframe
        df = self.create_dummy_lgd_data(self, lgd_estimates)

        # Create freq_mat from summary.py
        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd")
        freq_mat_1 = freq_mat.values.tolist()

        # Sort lgd_estimates in ECB bins and create freq_mat_2
        ecb_lgd_vals = df["pred_lgd"].values
        for i in range(len(ecb_lgd_vals)):
            value = ecb_lgd_vals[i]
            if value not in bins:
                ecb_lgd_vals[i] = min(
                    [i for i in bins if i < value], key=lambda x: abs(x - value)
                )
        df["pred_lgd"] = ecb_lgd_vals

        freq_mat_2 = self.create_contingency_table(self, df, bins, "ecb")

        # Compare contingency matrices on row level
        for i in range(len(freq_mat_2)):
            freq_list_1 = freq_mat_1[i]
            freq_list_2 = freq_mat_2[i].tolist()
            self.assertListEqual(
                freq_list_1,
                freq_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of the test case using binning_type='auto' "
                "where the lgd option should be activated.",
            )

    def test_lgd_contingency_table_intervals(self):
        """
        Test for the correct calculation of the lgd contingency table when
        default option for binning_type = 'auto' is selected.

        This test should activate the binning_type = "ecb"
        """
        # Bins
        bins = [0, 0.25, 0.5, 0.75, 1.0]

        # Create dataframe
        df = self.create_dummy_lgd_data(self, bins)

        freq_mat = pandas_lgd_contingency_table(df, "pred_lgd", "act_lgd")

        intervals_1 = [item for item in freq_mat.columns]

        # Recreate intervals
        intervals_2 = [
            pd.Interval(bins[i], bins[i + 1], closed="right")
            for i in range(len(bins) - 1)
        ]
        intervals_2.append(">=" + str(bins[-1]))

        # Compare contingency matrices on row level
        self.assertListEqual(intervals_1, intervals_2, msg=f"Intervals do not match up")

    def test_lgd_contingency_table_ValueError_1(self):

        """
        Test that a ValueError is raised if incorrect value for bins is passed
        when option "manual" is selected for binning_type

        ValueError: if binning_type = "manual" and not isinstance(bins, list)
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])

        # ValueError for binning_type = "manual" and not isinstance(bins, list)
        binning_type = "manual"
        bins = ""
        self.assertRaises(
            ValueError,
            pandas_lgd_contingency_table,
            **{
                "data": df,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_ValueError_2(self):
        """
        Test that a ValueError is raised if incorrect value for bins is passed
        when option "manual" is selected for binning_type

        ValueError: if binning_type = "manual" and bins = []
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])

        # ValueError for binning_type = "manual" and bins = []
        binning_type = "manual"
        bins = []
        self.assertRaises(
            ValueError,
            pandas_lgd_contingency_table,
            **{
                "data": df,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_ValueError_3(self):
        """
        Test that a ValueError is raised if incorrect value for bins is passed
        when option "manual" is selected for binning_type

        ValueError: if binning_type = "manual" and bins = [-1] i.e. smaller than 0
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])

        # ValueError for binning_type = "manual" and bins = [-1] (<0)
        binning_type = "manual"
        bins = [-1, 0.25, 0.5, 0.75, 1]
        self.assertRaises(
            ValueError,
            pandas_lgd_contingency_table,
            **{
                "data": df,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )

    def test_lgd_contingency_table_ValueError_4(self):
        """
        Test that a ValueError is raised if incorrect value when incorrect
        value for binning_type is specified
        """
        df = self.create_dummy_lgd_data(self, [0, 0.25, 0.5, 0.75, 1])

        # ValueError for binning_type = "manual" and bins = [-1] (<0)
        binning_type = "incorrect_value"
        bins = [-1, 0.25, 0.5, 0.75, 1]
        self.assertRaises(
            ValueError,
            pandas_lgd_contingency_table,
            **{
                "data": df,
                "pred_lgd_col": "pred_lgd",
                "act_lgd_col": "act_lgd",
                "binning_type": binning_type,
                "bins": bins,
            },
        )


if __name__ == "__main__":
    unittest.main()
