"""
# ============================================================================
# TEST_PYSPARK_CALIBRATION.PY
# ----------------------------------------------------------------------------
# Description:
#   Unit testing for the functions in 'crv.validation.calibration.py' that
#   use the pypsark module.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# ============================================================================
"""

# Imports.
import random
import unittest
import numpy as np
import pandas as pd
import pyspark.sql.functions as f
from pyspark.sql import SQLContext
from pyspark.sql.types import *

import random
from scipy.stats import ttest_rel, ttest_ind
from unit_test.pyspark_test_class import PySparkTestCase
from crv.validation.calibration import (
    _paired_t,
    _unpaired_equal_var_t,
    _unpaired_unequal_var_t,
    t_test,
)


class TestInternalTTests(PySparkTestCase):
    """
    Unit test case for 'crv.validation.calibration._paired_t',
    'crv.validation.calibration._unpaired_equal_var_t' &
    'crv.validation.calibration._unpaired_unequal_var_t'
    functions.
    Approach: Compare to results from 'scipy.stats.ttest_rel' &
    'scipy.stats.ttest_ind'
    """

    def create_dummy_lgd_data(self, bins):

        # Randomly create data
        dummy_pred_lgd = [random.choice(bins) for i in range(10000)]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(10000)]

        df = pd.DataFrame(
            list(zip(dummy_pred_lgd, dummy_act_lgd)), columns=["pred_lgd", "act_lgd"]
        )
        df_spark = self.spark.createDataFrame(df)

        return df, df_spark

    def test_internal_paired_t_test_result_two_tailed(self):
        """
        Test the crv.validation.calibration._paired_t function
        with default two sided argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_rel'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_rel(df[act_col], df[pred_col]))
        # crv.validation.calibration._paired_t result
        t_test_pylib = _paired_t(
            df_spark,
            dof=None,
            side="two_sided",
            col_names={"est_col": pred_col, "act_col": act_col},
        )

        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )
        self.assertAlmostEqual(
            t_test_scipy[1], t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_paired_t_test_result_right_tailed(self):
        """
        Test the crv.validation.calibration._paired_t function
        with right-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_rel'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_rel(df[act_col], df[pred_col]))
        # crv.validation.calibration._paired_t result
        t_test_pylib = _paired_t(
            df_spark,
            dof=None,
            side="right_tailed",
            col_names={"est_col": pred_col, "act_col": act_col},
        )
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] < 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])
        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_equal_var_t_test_result_two_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with default two sided argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2]))
        print(t_test_scipy)
        # crv.validation.calibration._unpaired_equal_var_t result
        t_test_pylib = _unpaired_equal_var_t(
            df_spark.select(group_1),
            df_spark.select(group_2),
            dof=None,
            side="two_sided",
        )
        print(t_test_pylib)
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )
        self.assertAlmostEqual(
            t_test_scipy[1], t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_equal_var_t_test_result_right_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with right-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2]))
        # crv.validation.calibration._unpaired_equal_var_t result
        t_test_pylib = _unpaired_equal_var_t(
            df_spark.select(group_1),
            df_spark.select(group_2),
            dof=None,
            side="right_tailed",
        )
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] < 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])
        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_equal_var_t_test_result_left_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with left-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2]))
        # crv.validation.calibration._unpaired_equal_var_t result
        t_test_pylib = _unpaired_equal_var_t(
            df_spark.select(group_1),
            df_spark.select(group_2),
            dof=None,
            side="left_tailed",
        )
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] > 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])
        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_unequal_var_t_test_result_two_tailed(self):
        """
        Test the crv.validation.calibration._unpaired_unequal_var_t function
        with default two sided argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2], equal_var=False))
        print(t_test_scipy)
        # crv.validation.calibration._unpaired_unequal_var_t result
        t_test_pylib = _unpaired_unequal_var_t(
            df_spark.select(group_1),
            df_spark.select(group_2),
            dof=None,
            side="two_sided",
        )
        print(t_test_pylib)
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )
        self.assertAlmostEqual(
            t_test_scipy[1], t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_unequal_var_t_result_right_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_unequal_var_t function
        with right-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2], equal_var=False))
        # crv.validation.calibration._unpaired_unequal_var_t result
        t_test_pylib = _unpaired_unequal_var_t(
            df_spark.select(group_1),
            df_spark.select(group_2),
            dof=None,
            side="right_tailed",
        )
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] < 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])
        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )

    def test_internal_unpaired_unequal_var_t_result_left_tailed(self):
        """
        Test the crv.validation.calibration.unpaired_equal_var_t function
        with left-tailed argument. Compare t_test & p_value
        to resulting values from 'scipy.stats.ttest_ind'
        """
        group_1 = "pred_lgd"
        group_2 = "act_lgd"
        # ECB bins
        bins = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        df, df_spark = self.create_dummy_lgd_data(bins)
        # scipy result
        t_test_scipy = list(ttest_ind(df[group_1], df[group_2], equal_var=False))
        # crv.validation.calibration._unpaired_unequal_var_t result
        t_test_pylib = _unpaired_unequal_var_t(
            df_spark.select(group_1),
            df_spark.select(group_2),
            dof=None,
            side="left_tailed",
        )
        self.assertAlmostEqual(
            t_test_scipy[0], t_test_pylib[5], 10, "t test values do not match"
        )

        if t_test_scipy[0] > 0:
            print(t_test_scipy[0])
            p_value_stats = 1 - t_test_scipy[1] / 2
        else:
            p_value_stats = t_test_scipy[1] / 2
            print(t_test_scipy[0])
        self.assertAlmostEqual(
            p_value_stats, t_test_pylib[6], 10, "p-values values do not match"
        )


class TestTTest(PySparkTestCase):
    """
    Unit test case for 'crv.validation.calibration.t_test'
    function. Approach: Test the index of the result_df to test the
    function 'crv.validation.calibration._create_bins_labels'

    Compare to results from 'scipy.stats.ttest_rel' for each
    of the segments.
    """

    def lgd_data_binned(self):

        # Create data
        id_facility = [str(i + 1) for i in range(7)]
        dummy_pred_lgd = [0.1, 0.3, 0.4, 0.25, 0.7, -0.9, 1.2]
        dummy_act_lgd = [random.uniform(0, 1) for i in range(7)]

        df = pd.DataFrame(
            list(zip(id_facility, dummy_pred_lgd, dummy_act_lgd)),
            columns=["fac_id", "pred_lgd", "act_lgd"],
        )

        df_spark = self.spark.createDataFrame(df)

        return df, df_spark

    def create_dummy_lgd_data_continuous(self):
        # Create data
        dummy_pred_lgd = [
            0.06919768849729835,
            0.4238483414518164,
            0.06819555665084798,
            0.24091113367447714,
            0.15768544018320974,
            0.4574048430327885,
            0.18662731806792554,
            0.49908465921774336,
            0.1563663488786975,
            0.00036161047635829835,
        ]

        dummy_act_lgd = [
            0.19136165109161873,
            0.7262035421234629,
            0.8926142485832232,
            0.783813021645464,
            0.023006965228376308,
            0.13272011958336605,
            0.2887934329711561,
            0.1286566134022451,
            0.013555236567417084,
            0.5842637320454735,
        ]

        id_facility = [str(i + 1) for i in range(10)]
        df = pd.DataFrame(
            list(zip(id_facility, dummy_pred_lgd, dummy_act_lgd)),
            columns=["facility_id", "pred_lgd", "act_lgd"],
        )

        df_spark = self.spark.createDataFrame(df)

        return df, df_spark

    def create_dummy_wiki_data(self):
        "Data taken from https://en.wikipedia.org/wiki/Welch%27s_t-test"
        # Create data
        group_1 = [19.8, 20.4, 19.6, 17.8, 18.5, 18.9, 18.3, 18.9, 19.5, 22.0]

        group_2 = [
            28.2,
            26.6,
            20.1,
            23.3,
            25.2,
            22.1,
            17.7,
            27.6,
            20.6,
            13.7,
            23.2,
            17.5,
            20.6,
            18.0,
            23.9,
            21.6,
            24.3,
            20.4,
            24.0,
            13.2,
        ]

        df1 = pd.DataFrame(group_1, columns=["group_1"])
        df2 = pd.DataFrame(group_2, columns=["group_1"])

        df_spark1 = self.spark.createDataFrame(df1)
        df_spark2 = self.spark.createDataFrame(df2)

        return df1, df2, df_spark1, df_spark2

    def test_result_df_auto_less_twenty_bins_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df, df_spark = self.lgd_data_binned()
        t_test0 = t_test(df_spark.select(pred_col), df_spark.select(act_col))
        result_df_index = t_test0.index
        expected_index = [-0.9, 0.1, 0.25, 0.3, 0.4, 0.7, 1.2]
        expected_N = [7, 1, 1, 1, 1, 1, 1, 1]

        for row in range(len(expected_index)):
            self.assertEqual(
                expected_index[row],
                list(result_df_index)[row + 1],
                f"Index value in bin number '{row}' not equal",
            )
        for row in range(result_df_index.shape[0]):
            self.assertEqual(
                expected_N[row],
                list(t_test0["N_group1"])[row],
                f"N value in bin number '{row}' not equal",
            )

    def test_index_result_df_lgd_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df, df_spark = self.lgd_data_binned()
        result_df_index = t_test(
            df_spark.select(pred_col), df_spark.select(act_col), binning_type="lgd"
        ).index

        expected_index = [-0.9, 0.1, 0.25, 0.3, 0.4, 0.7, 1.2]

        for row in range(len(expected_index)):
            self.assertEqual(
                expected_index[row],
                list(result_df_index)[row + 1],
                f"Index value in bin number '{row}' not equal",
            )

    def test_result_lgd_binning_type_zero_not_in_unique_and_min_unique_above_zero(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df, _ = self.lgd_data_binned()
        df.iloc[[5], [1]] = 0.70
        df_spark = self.spark.createDataFrame(df)
        t_test0 = t_test(df_spark.select(pred_col), df_spark.select(act_col))
        result_df_index = t_test0.index
        expected_index = [0.1, 0.25, 0.3, 0.4, 0.7, 1.2]
        expected_N = [7, 1, 1, 1, 1, 2, 1]

        for row in range(len(expected_index)):
            self.assertEqual(
                expected_index[row],
                list(result_df_index)[row + 1],
                f"Index value in bin number '{row}' not equal",
            )

        for row in range(result_df_index.shape[0]):
            self.assertEqual(
                expected_N[row],
                list(t_test0["N_group1"])[row],
                f"N value in bin number '{row}' not equal",
            )

    def test_index_result_df_ecb_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df, df_spark = self.lgd_data_binned()
        result_df_index = t_test(
            df_spark.select(pred_col), df_spark.select(act_col), binning_type="ecb"
        ).index

        expected_index = np.array(
            [
                [0, 0.05],
                [0.05, 0.1],
                [0.1, 0.2],
                [0.2, 0.3],
                [0.3, 0.4],
                [0.4, 0.5],
                [0.5, 0.6],
                [0.6, 0.7],
                [0.7, 0.8],
                [0.8, 0.9],
                [0.9, 1.0],
            ]
        )

        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][0],
                list(result_df_index)[row + 1].left,
                f"Left value in bin number '{row}' not equal",
            )
        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][1],
                list(result_df_index)[row + 1].right,
                f"Left value in bin number '{row}' not equal",
            )

        ## Test last index
        self.assertEqual(">= 1", list(result_df_index)[-1])

    def test_index_result_df_manual_binning_type(self):
        """
        Test the index of the result_df to test the
        function 'crv.validation.calibration._create_bins_labels'
        """
        pred_col = "pred_lgd"
        act_col = "act_lgd"

        # ECB bins
        df, df_spark = self.lgd_data_binned()
        result_df_index = t_test(
            df_spark.select(pred_col),
            df_spark.select(act_col),
            binning_type="manual",
            bins=[0.05, 0.1, 0.2, 0.3, 0.4],
        ).index
        expected_index = np.array([[0, 0.05], [0.05, 0.1], [0.1, 0.2], [0.2, 0.3]])

        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][0],
                list(result_df_index)[row + 1].left,
                f"Left value in bin number '{row}' not equal",
            )
        for row in range(expected_index.shape[0]):
            self.assertEqual(
                expected_index[row][1],
                list(result_df_index)[row + 1].right,
                f"Left value in bin number '{row}' not equal",
            )

        ## Test last index
        self.assertEqual(">= 0.4", list(result_df_index)[-1])

    def test_value_error_duplicate_id(self):
        """
        Test value error raising when duplicate values
        are found on id_col.
        """
        df, _ = self.lgd_data_binned()
        df.iloc[[1], [0]] = "1"
        df_spark = self.spark.createDataFrame(df)
        self.assertRaises(
            ValueError,
            t_test,
            group_1_data=df_spark,
            test_type="paired",
            col_names={"id_col": "fac_id", "est_col": "pred_lgd", "act_col": "act_lgd"},
        )

    def test_value_error_paired_test_col_names_not_specified(self):
        """
        Test value error raising when test_type = "paired" &
        col names not specified.
        """
        df, df_spark = self.lgd_data_binned()
        self.assertRaises(ValueError, t_test, group_1_data=df_spark, test_type="paired")

    def test_value_error_incorrect_binning_type(self):
        """
        Test value error raising when binning type value
        is not one of the values allowed.
        """
        df, df_spark = self.lgd_data_binned()
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df_spark.select("pred_lgd"),
                "group_2_data": df_spark.select("act_lgd"),
                "binning_type": "foo",
            },
        )

    def test_value_error_incorrect_bins_input(self):
        """
        Test value error raising when values in bins argument
        is not a list.
        """
        df, df_spark = self.lgd_data_binned()
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df_spark.select("pred_lgd"),
                "group_2_data": df_spark.select("act_lgd"),
                "binning_type": "manual",
                "bins": 3,
            },
        )

    def test_value_error_incorrect_ttest_type(self):
        """
        Test value error raising when values in test_type argument
        is not on the values allowed.
        """
        df, df_spark = self.lgd_data_binned()
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df_spark.select("pred_lgd"),
                "group_2_data": df_spark.select("act_lgd"),
                "test_type": "foo",
            },
        )

    def test_value_error_incorrect_side_type(self):
        """
        Test value error raising when values in side argument
        is not on the values allowed.
        """
        df, df_spark = self.lgd_data_binned()
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df_spark.select("pred_lgd"),
                "group_2_data": df_spark.select("act_lgd"),
                "side": "foo",
            },
        )

    def test_value_error_incorrect_dof_type(self):
        """
        Test value error raising when type of dof argument
        is not a list.
        """
        df, df_spark = self.lgd_data_binned()
        self.assertRaises(
            ValueError,
            t_test,
            **{
                "group_1_data": df_spark.select("pred_lgd"),
                "group_2_data": df_spark.select("act_lgd"),
                "dof": 3,
            },
        )

    def test_segment_level_t_test(self):
        """
        Compare t_test statistic value & p-value to results
        obtained from 'scipy.stats.ttest_rel' for each
        of the segments.

        Note: It only compares values that are not NaN's.
        """
        df, df_spark = self.create_dummy_lgd_data_continuous()
        id_col = "facility_id"
        pred_col = "pred_lgd"
        act_col = "act_lgd"
        binning_type = "ecb"
        t_test_result = t_test(
            df_spark,
            col_names={"id_col": id_col, "est_col": pred_col, "act_col": act_col},
            test_type="paired",
            side="right_tailed",
            binning_type=binning_type,
        )

        t_test_result = (
            t_test_result.reset_index(drop=True)
            .loc[[0, 2, 3, 6]]
            .reset_index(drop=True)[["t_stat", "p_value"]]
            .values.tolist()
        )

        ## T-test values & p-values (two-sided test) below, are the result of the
        ## scipy.stats.ttest_rel implementation i.e. ttest_rel(dummy_act_lgd,dummy_pred_lgd).
        ## p-values are modified accordingly
        ## to extract the right tailed (one-sided) p-value, as per "ECB Instructions
        ## for reporting the validation results of internal models, February 2019."
        ## Section 2.6.2.1 & 2.9.3.1.
        expected_result = [
            [1.1712059416098368, 0.2715894839724747 / 2],
            [1.347919230702717, 0.40634595933247775 / 2],
            [-0.7274415151088657, (1 - 0.5425865061003926 / 2)],
            [-0.6032050733458877, (1 - 0.6076673569611182 / 2)],
        ]

        for row in range(len(t_test_result)):
            self.assertAlmostEqual(
                expected_result[row][0],
                t_test_result[row][0],
                10,
                f"t_test value in row '{row}' not equal",
            )

        for row in range(len(t_test_result)):
            self.assertAlmostEqual(
                expected_result[row][1],
                t_test_result[row][1],
                10,
                f"p-value in row '{row}' not equal",
            )

    def test_segment_level_t_test_spark_pandas_unq_var(self):
        """
        Compare t_test dataframes resulting from the pandas
        & spark implementations.

        test_type = 'unpaired_unequal_variances'
        binning_type = 'ecb'
        side = "left_tailed"
        """
        df, df_spark = self.create_dummy_lgd_data_continuous()
        pred_col = "pred_lgd"
        act_col = "act_lgd"
        binning_type = "ecb"
        t_test_result_pandas = t_test(
            df[pred_col],
            df[act_col],
            test_type="unpaired_unequal_variances",
            side="left_tailed",
            binning_type=binning_type,
        )

        t_test_result_spark = t_test(
            df_spark.select(pred_col),
            df_spark.select(act_col),
            test_type="unpaired_unequal_variances",
            side="left_tailed",
            binning_type=binning_type,
        )

        pd.testing.assert_frame_equal(t_test_result_pandas, t_test_result_spark)

    def test_segment_level_t_test_spark_pandas_eq_var(self):
        """
        Compare t_test dataframes resulting from the pandas
        & spark implementations.

        test_type = 'unpaired_equal_variances'
        binning_type = 'lgd'
        side = "two_sided"
        """
        df, df_spark = self.create_dummy_lgd_data_continuous()
        pred_col = "pred_lgd"
        act_col = "act_lgd"
        binning_type = "lgd"
        t_test_result_pandas = t_test(
            df[pred_col],
            df[act_col],
            test_type="unpaired_equal_variances",
            side="two_sided",
            binning_type=binning_type,
        )

        t_test_result_spark = t_test(
            df_spark.select(pred_col),
            df_spark.select(act_col),
            test_type="unpaired_equal_variances",
            side="two_sided",
            binning_type=binning_type,
        )

        pd.testing.assert_frame_equal(t_test_result_pandas, t_test_result_spark)

    def test_portfolio_level_t_equal_var_test(self):
        """
        Compare t_test statistic value & p-value to results
        obtained from https://en.wikipedia.org/wiki/Welch%27s_t-test.
        Third example.
        """
        df1, df2, df1_spark, df2_spark = self.create_dummy_wiki_data()
        t_test_result = t_test(df1_spark, df2_spark)

        expected_result = [-1.65, 0.110]

        self.assertEqual(
            expected_result[0],
            round(t_test_result["t_stat"][0], 2),
            f"t_test value not equal",
        )

        self.assertEqual(
            expected_result[1],
            round(t_test_result["p_value"][0], 3),
            f"p-value not equal",
        )

    def test_portfolio_level_t_unequal_var_test(self):
        """
        Compare t_test statistic value & p-value to results
        obtained from https://en.wikipedia.org/wiki/Welch%27s_t-test.
        Third example.
        """
        df1, df2, df1_spark, df2_spark = self.create_dummy_wiki_data()
        t_test_result = t_test(
            df1_spark, df2_spark, test_type="unpaired_unequal_variances"
        )

        expected_result = [-2.22, 0.036]

        self.assertEqual(
            expected_result[0],
            round(t_test_result["t_stat"][0], 2),
            f"t_test value not equal",
        )

        self.assertEqual(
            expected_result[1],
            round(t_test_result["p_value"][0], 3),
            f"p-value not equal",
        )

    def test_value_warning_empty_input_data(self):
        """
        Testwarning raising when either input data
        group_1_data or group_2_data are empty.
        """
        df, df_spark = self.lgd_data_binned()
        df1 = df_spark.select("pred_lgd")
        sc = self.spark.sparkContext
        sqlContext = SQLContext(sc)
        field = [StructField("FIELDNAME_1", StringType(), True)]
        schema = StructType(field)
        df2 = sqlContext.createDataFrame(sc.emptyRDD(), schema)

        self.assertWarns(Warning, t_test, group_1_data=df1, group_2_data=df2)


if __name__ == "__main__":
    unittest.main()
