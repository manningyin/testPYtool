"""
# ============================================================================
# TEST_MODEL_DIAGNOSTICS.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.VALIDATION.MODEL_DIAGNOSTICS.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.validation.model_diagnostics' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Adam Szpilewicz <M016673>
# ============================================================================
"""
# external modules import
import unittest
import numbers
import pandas as pd
import numpy as np
import statsmodels.api as sm
import warnings

# inner modules import
from crv.validation.model_diagnostics import (
    vif,
    cooks_distance,
    glejser_test,
    _glejser_test_pandas,
    _single_glejser_pandas,
)


class TestPandasVIF(unittest.TestCase):
    """
    Unit test case for the pandas implementation of vif function.
    """

    @staticmethod
    def get_vif_table():
        return pd.DataFrame(
            {
                "points": [25, 20, 14, 16, 27, 20, 12, 15, 14, 19],
                "assists": [5, 7, 7, 8, 5, 7, 6, 9, 9, 5],
                "rebounds": [11, 8, 10, 6, 6, 9, 6, 10, 10, 7],
            }
        )

    @staticmethod
    def get_vif_table_nans():
        return pd.DataFrame(
            {
                "points": [
                    np.nan,
                    np.nan,
                    np.nan,
                    100,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                ],
                "assists": [5, 7, 7, 8, 5, 7, 6, 9, 9, 5],
                "rebounds": [11, 8, 10, 6, 6, 9, 6, 10, 10, 7],
            }
        )

    @staticmethod
    def get_vif_table_nones():
        return pd.DataFrame(
            {
                "points": [25, 20, 14, None, 27, 20, 12, 15, 14, 19],
                "assists": [5, 7, 7, 8, 5, 7, 6, 9, 9, 5],
                "rebounds": [11, 8, 10, 6, 6, 9, 6, 10, 10, 7],
            }
        )

    @staticmethod
    def get_vif_table_infs():
        return pd.DataFrame(
            {
                "points": [25, 20, 14, np.inf, 27, 20, 12, 15, 14, 19],
                "assists": [5, 7, 7, 8, 5, 7, 6, 9, 9, 5],
                "rebounds": [11, 8, 10, 6, 6, 9, 6, 10, 10, 7],
            }
        )

    def to_check_vif(self):
        df = self.get_vif_table()
        lm_reb = sm.OLS(
            df["rebounds"], sm.add_constant(df[["points", "assists"]])
        ).fit()
        lm_poi = sm.OLS(
            df["points"], sm.add_constant(df[["rebounds", "assists"]])
        ).fit()
        lm_ass = sm.OLS(
            df["assists"], sm.add_constant(df[["points", "rebounds"]])
        ).fit()
        vif_reb = 1 / (1 - lm_reb.rsquared)
        vif_poi = 1 / (1 - lm_poi.rsquared)
        vif_ass = 1 / (1 - lm_ass.rsquared)
        return vif_reb, vif_poi, vif_ass

    def test_df_delivered_as_pandas_df(self):
        """
        Test whether argument `df` delivered as pandas.DataFrame
        """
        self.assertRaises(
            TypeError, vif, df=[1, 2, 3], vif_columns=["points", "assists", "rebounds"]
        )

    def test_vif_columns_delivered_as_list(self):
        """
        Test whether argument `vif_columns` delivered as list
        """
        self.assertRaises(
            TypeError,
            vif,
            df=self.get_vif_table(),
            vif_columns=("points", "assists", "rebounds"),
        )

    def test_all_list_elements_in_df_columns(self):
        """
        Test whether all names from vif_columns present in df.columns
        """
        self.assertRaises(
            ValueError,
            vif,
            df=self.get_vif_table(),
            vif_columns=["a", "assists", "rebounds"],
        )

    def test_proper_results(self):
        """
        Test whether the results of VIF calculation are proper
        """
        res = vif(
            df=self.get_vif_table(), vif_columns=["points", "assists", "rebounds"]
        )
        print(res)
        res_to_check = self.to_check_vif()
        self.assertAlmostEqual(
            res[res.feature == "points"].iloc[0]["VIF"], res_to_check[1], 6
        )
        self.assertAlmostEqual(
            res[res.feature == "rebounds"].iloc[0]["VIF"], res_to_check[0], 6
        )
        self.assertAlmostEqual(
            res[res.feature == "assists"].iloc[0]["VIF"], res_to_check[2], 6
        )

    def test_nones_in_input(self):
        self.assertRaises(
            ValueError,
            vif,
            df=self.get_vif_table_nones(),
            vif_columns=["points", "assists", "rebounds"],
        )

    def test_nans_in_input(self):
        self.assertRaises(
            ValueError,
            vif,
            df=self.get_vif_table_nans(),
            vif_columns=["points", "assists", "rebounds"],
        )

    def test_infs_in_input(self):
        self.assertRaises(
            ValueError,
            vif,
            df=self.get_vif_table_infs(),
            vif_columns=["points", "assists", "rebounds"],
        )


class TestPandasCooksDistance(unittest.TestCase):
    """
    Unit test case for the pandas implementation of vif function.
    """

    @staticmethod
    def get_cooks_table():
        X = pd.DataFrame(
            ([1, -1], [2, 8], [3, 4], [4, 5], [5, 6], [15, 16]), columns=["x1", "x2"]
        )
        X = X.astype({"x1": float, "x2": float})
        # convert to pandas.DataSeries to test that type of input as well
        y = pd.DataFrame((3.1, 5.9, 9.3, 11.8, 15.1, 1), columns=["y"]).y
        return y, X

    @staticmethod
    def get_r_results():
        """
        Below the r script that was used to obtain cooks distance to
         compare with python results
            x1 <- c(1,2,3,4,5,15)
            x2 <- c(-1,8,4,5,6,16)
            data_ = data.frame(x1, x2)
            y <- c(3.1,5.9,9.3,11.8,15.1,1)
            res <- lm(y ~  x1+x2, data=data_)
            res
            cooks.distance(res)
        """
        return [
            1.360994555,
            5.126667716,
            0.001917883,
            0.030070254,
            0.110588774,
            14.662101794,
        ]

    def test_y_is_not_data_frame(self):
        _, X = self.get_cooks_table()
        self.assertRaises(TypeError, cooks_distance, y=["a"], X=X)

    def test_X_is_not_data_frame(self):
        y, _ = self.get_cooks_table()
        self.assertRaises(TypeError, cooks_distance, y=y, X=["1"])

    def test_X_contains_inf(self):
        y, X = self.get_cooks_table()
        X["x1"][0] = np.inf
        self.assertRaises(ValueError, cooks_distance, y=y, X=X)

    def test_y_contains_inf(self):
        y, X = self.get_cooks_table()
        y = pd.DataFrame(y, columns=["y"])
        y["y"][0] = np.inf
        self.assertRaises(ValueError, cooks_distance, y=y, X=X)

    def test_X_all_columns_numeric(self):
        y, X = self.get_cooks_table()
        X["x1"][0] = "a"
        self.assertRaises(TypeError, cooks_distance, y=y, X=X)

    def test_y_all_columns_numeric(self):
        y, X = self.get_cooks_table()
        y = pd.DataFrame(y, columns=["y"])
        y["y"][0] = "a"
        self.assertRaises(TypeError, cooks_distance, y=y, X=X)

    def test_assert_the_same_results_as_in_r(self):
        y, X = self.get_cooks_table()
        python_results = cooks_distance(y=y, X=X)["cooks_distance"].tolist()
        r_results = self.get_r_results()
        is_lower_than_threshold = [
            (i - j) < 0.0000001 for i, j in zip(r_results, python_results)
        ]
        self.assertTrue(all(is_lower_than_threshold))


class TestGlejserTest(unittest.TestCase):
    """
    Test class for the 'crv.validation.model_diagnostics.glejser_test'
    function. Mainly focused on testing error raising.
    """

    def test_glejser_test_not_pandas(self):
        """
        Confirms that the 'TypeError' is raised when
        something other than a pandas or pyspark DataFrame is passed.
        """
        with self.assertRaises(TypeError):
            glejser_test(data=1, y_col="y", x_cols="x")

    def test_glejser_test_x_not_str_or_list(self):
        """
        Confirms that the 'TypeError' is raised when a value is
        passed to 'x_cols' that is not a string or list.
        """
        with self.assertRaises(TypeError):
            glejser_test(data=pd.DataFrame(), y_col="y", x_cols=True)

    def test_glejser_test_y_not_str(self):
        """
        Confirms that the 'TypeError' is raised when a value is
        passed to 'y_col' that is not a string.
        """
        with self.assertRaises(TypeError):
            glejser_test(data=pd.DataFrame(), y_col=1, x_cols="xcol")

    def test_glejser_test_alpha_value_error(self):
        """
        Confirms that a 'ValueError' is raised when the value
        passed to 'alpha' is not between 0 and 1.
        """
        with self.assertRaises(ValueError):
            glejser_test(data=pd.DataFrame(), y_col="y", x_cols="x", alpha=1.1)


class TestSingleGlejserPandas(unittest.TestCase):
    """
    Test class for the
    'crv.validation.model_diagnostics._single_glejser_pandas'
    function.
    """

    @staticmethod
    def create_test_array():
        X = np.array(
            [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4]
        )
        Y = np.array(
            [
                0.2699846644019307,
                5.188843727442551,
                1.1957286680977168,
                1.616212899669112,
                1.2069814687581766,
                2.2502585102252977,
                -4.63685249001615,
                6.524160400363965,
                0.32129176420146566,
                4.301835833422125,
                1.4445531066255424,
                1.844110297850798,
                6.353856616595811,
                6.322966681052259,
            ]
        )
        return X, Y

    def test_single_glejser_pandas_user_warning(self):
        """
        Tests that a user warning is raised when one of the
        transform functions encounters an 'inf' value.
        """
        x, y = self.create_test_array()
        with warnings.catch_warnings():
            _single_glejser_pandas(x=x, y=y, alpha=0.05)


class TestGlejserTestPandas(unittest.TestCase):
    """
    Test class for the function
    'crv.validation.model_diagnostics._glejser_test_pandas'.
    Implicitly tests the correct function of *_signle_glejser_pandas'.
    """

    @staticmethod
    def create_test_data():
        d_custom = {
            "B": [
                0.2699846644019307,
                5.188843727442551,
                1.1957286680977168,
                1.616212899669112,
                1.2069814687581766,
                2.2502585102252977,
                -4.63685249001615,
                6.524160400363965,
                0.32129176420146566,
                4.301835833422125,
                1.4445531066255424,
                1.844110297850798,
                6.353856616595811,
                6.322966681052259,
            ],
            "C": [
                20.916787810323783,
                -38.3737916786569,
                -77.76998354252675,
                -41.38560815887493,
                -40.5374194254564,
                19.662552173104615,
                -18.946424912704977,
                -6.1952266028961365,
                -11.313370813927609,
                0.09328476634984595,
                -25.037780897086304,
                -21.40528133767217,
                2.515870797993458,
                6.2519662711896276,
            ],
            "A": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4],
        }
        return pd.DataFrame.from_dict(d_custom)

    def test_glejser_test_pandas_correct_result_heterosced(self):
        """
        Correct identification of heteroscedasticity.
        """
        df_test = self.create_test_data()
        test_result = _glejser_test_pandas(
            data=df_test, y_col="C", x_cols="A", alpha=0.05
        )
        test_eval = test_result.loc[0, "Evaluation"]
        correct_eval = "Strongly heteroscedastic"
        self.assertEqual(test_eval, correct_eval)

    def test_glejser_test_pandas_correct_result_homosced(self):
        """
        Correct identification of homoscedasticity.
        """
        df_test = self.create_test_data()
        test_result = _glejser_test_pandas(
            data=df_test, y_col="B", x_cols="A", alpha=0.05
        )
        test_eval = test_result.loc[0, "Evaluation"]
        correct_eval = "Not heteroscedastic"
        self.assertEqual(test_eval, correct_eval)


if __name__ == "__main__":
    unittest.main()