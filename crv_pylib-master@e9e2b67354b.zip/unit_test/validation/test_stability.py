"""
# ============================================================================
# TEST_STABILITY.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.VALIDATION.STABILITY.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.validation.stability' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Lee MacKenzie Fischer <G01679>
# ============================================================================
"""

import unittest
import numpy as np
import pandas as pd
from crv.validation.stability import (
    concentration_test,
    _exec_adj_conc_test,
    psi_test,
    _pandas_group_population,
    population_stability_index,
    z_test,
    mm_stability_test,
    matrix_weighted_bandwidth,
    likelihood_ratio_test,
)
from crv.utils.dataframe_helper import rating_cats
from scipy.stats import norm, chi2


class TestExecAdjConcTest(unittest.TestCase):
    """
    Test class for the 'crv.validation.stability.exec_adj_conc_test' funciton.
    """

    @staticmethod
    def get_adj_test_table():
        """
        Test data.
        """
        adf = pd.DataFrame.from_dict(
            {
                "rating": ["1", "2", "3", "4", "5", "6"],
                "N": [150, 300, 500, 600, 450, 300],
                "EAD": [200, 400, 650, 800, 450, 350],
                "group_totals": [2300] * 6,
            }
        )
        adf["rating"] = pd.Categorical(
            adf["rating"], categories=["0", "1", "2", "3", "4", "5", "6", "7"]
        )
        adf = adf.sort_values("rating")
        adf["Concentration"] = adf["N"] / adf["group_totals"]
        adf["adj_conc"] = np.nan
        adf["Adjacent Concentration Limit Passed"] = np.nan
        return adf

    def test_exec_adj_conc_test_results(self):
        """
        Test for correct calculation of results.
        """
        df = self.get_adj_test_table()
        tot = 2300.0
        expected_adj_conc = [
            np.nan,
            450.0 / tot,
            800.0 / tot,
            1100.0 / tot,
            1050.0 / tot,
            750.0 / tot,
        ]
        expected_passed = [np.nan, True, True, False, False, True]
        test_result = _exec_adj_conc_test(df, 0.35)
        for i in range(1, 6, 1):
            self.assertAlmostEqual(
                list(test_result["adj_conc"])[i], expected_adj_conc[i], places=15
            )
        self.assertListEqual(
            list(test_result["Adjacent Concentration Limit Passed"])[1:],
            expected_passed[1:],
        )


class TestConcentrationTest(unittest.TestCase):
    """
    Test case for the 'crv.validatoin.stability.concentration_test' function.
    """

    @staticmethod
    def get_adf_grouped_table():
        """
        Test data for grouping.
        """
        adf = pd.DataFrame.from_dict(
            {
                "rating": ["1", "2", "3", "4", "1", "2", "3"],
                "country": ["DK", "DK", "DK", "DK", "SE", "SE", "SE"],
                "year": [2017, 2018, 2018, 2018, 2017, 2017, 2018],
                "N": [200, 300, 400, 200, 100, 200, 300],
                "EAD": [100, 100, 130, 100, 200, 220, 350],
            }
        )
        adf["rating"] = pd.Categorical(adf["rating"], categories=["1", "2", "3", "4"])
        adf["country"] = pd.Categorical(
            adf["country"], categories=["DK", "SE", "NO", "FI"]
        )
        adf = adf.sort_values(["country", "rating"])
        return adf

    @staticmethod
    def get_adj_test_table():
        """
        Test data.
        """
        adf = pd.DataFrame.from_dict(
            {
                "rating": ["1", "2", "3", "4", "5", "6"],
                "N": [150, 300, 500, 600, 450, 300],
                "EAD": [200, 400, 650, 800, 450, 350],
                "group_totals": [2300] * 6,  # using N as value column.
            }
        )
        adf["rating"] = pd.Categorical(
            adf["rating"], categories=["0", "1", "2", "3", "4", "5", "6", "7"]
        )
        adf = adf.sort_values("rating")
        adf["Concentration"] = adf["N"] / adf["group_totals"]
        adf["adj_conc"] = np.nan
        adf["Adjacent Concentration Limit Passed"] = np.nan
        return adf

    def test_concentration_test_nogroup_results(self):
        """
        Test for correct calculation of results without grouping.
        """
        df = self.get_adj_test_table()[["rating", "N", "EAD"]]
        test_results = concentration_test(df, "rating", "EAD", single_conc_limit=0.25)
        tot = 2850.0
        expected_single_conc = [
            200 / tot,
            400 / tot,
            650 / tot,
            800 / tot,
            450 / tot,
            350 / tot,
        ]
        # Test group total.
        self.assertListEqual(
            list(test_results["group_totals"]),
            [tot] * 6,
            msg="Mismatch in column 'group_totals'.",
        )
        # Test single concentration value.
        for exp, res in zip(expected_single_conc, list(test_results["Concentration"])):
            self.assertAlmostEqual(exp, res, places=12, msg="")
        # Test single concentration passed.
        self.assertListEqual(
            list(test_results["Single Concentration Limit Passed"]),
            [True, True, True, False, True, True],
        )

    def test_concentration_test_group_country_results(self):
        """
        Test for correct results when grouping by country.
        """
        df = self.get_adf_grouped_table()[["rating", "country", "N", "EAD"]]
        dk_tot, se_tot = 430.0, 770.0
        expected_totals = [dk_tot] * 4 + [se_tot] * 3
        expected_conc = [
            100 / dk_tot,
            100 / dk_tot,
            130 / dk_tot,
            100 / dk_tot,
            200 / se_tot,
            220 / se_tot,
            350 / se_tot,
        ]
        expected_single_passed = [True, True, False, True, True, True, False]
        expected_adj_conc = [
            round((100 + 100) / dk_tot, 14),
            round((100 + 130) / dk_tot, 14),
            round((130 + 100) / dk_tot, 14),
            round((200 + 220) / se_tot, 14),
            round((220 + 350) / se_tot, 14),
        ]
        expected_adj_passed = [True, False, False, False, False]
        test_results = concentration_test(df, "rating", "EAD", "country")
        print(test_results)
        # Test expected totals.
        self.assertListEqual(
            list(test_results["group_totals"]),
            expected_totals,
            msg="Mismatch in column 'group_totals'.",
        )
        # Test expected concentrations.
        self.assertListEqual(
            list(test_results["Concentration"]),
            expected_conc,
            msg="Mismatch in column 'Concentration'.",
        )
        # Test single concetration passed result.
        self.assertListEqual(
            list(test_results["Single Concentration Limit Passed"]),
            expected_single_passed,
            msg="Mismatch in column 'Single Concentration Limit Passed'.",
        )
        # Test expected adjacent concentrations.
        idx = [1, 2, 3, 5, 6]
        self.assertListEqual(
            [round(test_results["adj_conc"][i], 14) for i in idx],
            expected_adj_conc,
            msg="Mismatch in column 'adj_conc'.",
        )
        # Test expected adjacent test passed results.
        self.assertListEqual(
            [test_results["Adjacent Concentration Limit Passed"][i] for i in idx],
            expected_adj_passed,
            msg="Mismatch in column 'adj_conc'.",
        )

    def test_concentration_test_group_country_year_results(self):
        """
        Test for correct results when grouping by country & year.
        """
        df = self.get_adf_grouped_table()
        dk_tot_17, dk_tot_18, se_tot_17, se_tot_18 = 100.0, 330.0, 420.0, 350.0
        expected_totals = [dk_tot_17] + [dk_tot_18] * 3 + [se_tot_17] * 2 + [se_tot_18]
        expected_conc = [
            100 / dk_tot_17,
            100 / dk_tot_18,
            130 / dk_tot_18,
            100 / dk_tot_18,
            200 / se_tot_17,
            220 / se_tot_17,
            350 / se_tot_18,
        ]
        expected_single_passed = [False, False, False, False, False, False, False]
        expected_adj_conc = [
            round((100 + 130) / dk_tot_18, 14),
            round((130 + 100) / dk_tot_18, 14),
            round((200 + 220) / se_tot_17, 14),
        ]
        expected_adj_passed = [False, False, False]
        test_results = concentration_test(df, "rating", "EAD", ["country", "year"])
        print(test_results)
        # Test expected totals.
        self.assertListEqual(
            list(test_results["group_totals"]),
            expected_totals,
            msg="Mismatch in column 'group_totals'.",
        )
        # Test expected concentrations.
        self.assertListEqual(
            list(test_results["Concentration"]),
            expected_conc,
            msg="Mismatch in column 'Concentration'.",
        )
        # Test single concetration passed result.
        self.assertListEqual(
            list(test_results["Single Concentration Limit Passed"]),
            expected_single_passed,
            msg="Mismatch in column 'Single Concentration Limit Passed'.",
        )
        # Test expected adjacent concentrations.
        idx = [2, 3, 5]
        self.assertListEqual(
            [round(test_results["adj_conc"][i], 14) for i in idx],
            expected_adj_conc,
            msg="Mismatch in column 'adj_conc'.",
        )
        # Test expected adjacent test passed results.
        self.assertListEqual(
            [test_results["Adjacent Concentration Limit Passed"][i] for i in idx],
            expected_adj_passed,
            msg="Mismatch in column 'adj_conc'.",
        )

    def test_concentration_test_single_error(self):
        """
        Tests that a ValueError gets raised if the single concentration limit
        is not between 0 and 1.
        """
        df = self.get_adf_grouped_table()
        self.assertRaises(
            ValueError, concentration_test, df, "rating", "EAD", "country", -0.4
        )
        self.assertRaises(
            ValueError, concentration_test, df, "rating", "EAD", "country", 1.4
        )

    def test_concentration_test_adjacent_error(self):
        """
        Tests that a ValueError gets raised if the adjacent concentration limit
        is not between 0 and 1.
        """
        df = self.get_adf_grouped_table()
        self.assertRaises(
            ValueError, concentration_test, df, "rating", "EAD", "country", 0.3, -0.4
        )
        self.assertRaises(
            ValueError, concentration_test, df, "rating", "EAD", "country", 0.3, 1.4
        )

    def test_concentration_test_value_error_not_numeric(self):
        """
        Tests that a ValueError gets raised if the value_column is
        does not contain numeric values.
        """
        df = self.get_adf_grouped_table()
        self.assertRaises(ValueError, concentration_test, df, "rating", "country")


class TestPsiTest(unittest.TestCase):
    """
    Test class for the 'crv.validation.stability.psi_test' calculation function.
    """

    def test_psi_test_correct_result(self):
        """
        Tests for the correct calculation of the test result.
        """
        # Sample data.
        sample_data = pd.DataFrame(
            {
                "Dec 2018": [0.03, 0.08, 0.20, 0.4, 0.1, 0.09, 0.1],
                "Aug 2020": [0.04, 0.07, 0.25, 0.39, 0.05, 0.11, 0.09],
            },
            index=[
                "LGD pool 1",
                "LGD pool 2",
                "LGD pool 3",
                "LGD pool 4",
                "LGD pool 5",
                "LGD pool 6",
                "LGD pool 7",
            ],
        )
        correct_result = 0.05534686839013497
        test_result = psi_test(sample_data, "Dec 2018", "Aug 2020")
        self.assertAlmostEqual(
            correct_result, test_result, places=12, msg="PSI test result is incorrect."
        )

    def test_psi_test_value_error_zero_found(self):
        """
        Tests for the raising of a ValueError if a zero is found
        in one of the columns, but the columns still sum to 1.
        """
        # Sample data.
        sample_data = pd.DataFrame(
            {
                "Dec 2018": [0.03, 0.08, 0.20, 0.4, 0.1, 0.09, 0.05, 0.05],
                "Aug 2020": [0.04, 0.07, 0.25, 0.39, 0.05, 0.11, 0.09, 0],
            },
            index=[
                "LGD pool 1",
                "LGD pool 2",
                "LGD pool 3",
                "LGD pool 4",
                "LGD pool 5",
                "LGD pool 6",
                "LGD pool 7",
                "LGD pool 8",
            ],
        )
        self.assertRaises(ValueError, psi_test, sample_data, "Dec 2018", "Aug 2020")

    def test_psi_test_value_error_wrong_column_sum(self):
        """
        Tests that a ValueError is raised if one of the columns
        do not sum to 1.
        """
        # Sample data.
        sample_data = pd.DataFrame(
            {
                "Dec 2018": [0.03, 0.08, 0.20, 0.4, 0.1, 0.09, 0.05],
                "Aug 2020": [0.04, 0.07, 0.25, 0.39, 0.05, 0.11, 0.09],
            },
            index=[
                "LGD pool 1",
                "LGD pool 2",
                "LGD pool 3",
                "LGD pool 4",
                "LGD pool 5",
                "LGD pool 6",
                "LGD pool 7",
            ],
        )
        self.assertRaises(ValueError, psi_test, sample_data, "Dec 2018", "Aug 2020")


class TestPandasGroupPopulation(unittest.TestCase):
    """
    Test class for the crv.validation.stability._pandas_group_population'
    function.
    """

    @staticmethod
    def get_sample_data():
        """
        Generate small sample data for test.
        """
        d_sample = {
            "year": ["2010"] * 10 + ["2011"] * 10 + ["2012"] * 10,
            "lgd_est": [0.15, 0.4, 0.6] * 10,
            "lgd_actual": list(np.random.uniform(low=0.01, high=0.8, size=30)),
            "country": ["DK", "SE", "NO", "FI", "DK"] * 6,
        }
        df_sample = pd.DataFrame.from_dict(d_sample)
        return df_sample

    def test_pandas_group_population_auto_binning(self):
        """
        Test case for scenario:
            date_col = 'year'
            binning_type = 'auto'
            binning_col = 'lgd_est'
            minimum_value = 1
        """
        correct_result = pd.DataFrame.from_dict(
            {"2010": [0.4, 0.3, 0.3], "2011": [0.3, 0.4, 0.3], "2012": [0.3, 0.3, 0.4]}
        )
        correct_result.index = [0.15, 0.4, 0.6]

        test_result = _pandas_group_population(
            data=self.get_sample_data(),
            population_col="year",
            binning_type="auto",
            binning_col="lgd_est",
            minimum_value=1,
        )
        pd.testing.assert_frame_equal(correct_result, test_result)

    def test_pandas_group_population_ecb_binning(self):
        """
        Test case for scenario:
            date_col = 'year'
            binning_type = 'ecb'
            binning_col = 'lgd_est'
            minimum_value = 1
        """
        correct_result = pd.DataFrame.from_dict(
            {
                "2010": [1, 1, 4, 1, 1, 3, 1, 3, 1, 1, 1, 1],
                "2011": [1, 1, 3, 1, 1, 4, 1, 3, 1, 1, 1, 1],
                "2012": [1, 1, 3, 1, 1, 3, 1, 4, 1, 1, 1, 1],
            }
        )
        correct_result.index = [
            "[0.0, 0.05)",
            "[0.05, 0.1)",
            "[0.1, 0.2)",
            "[0.2, 0.3)",
            "[0.3, 0.4)",
            "[0.4, 0.5)",
            "[0.5, 0.6)",
            "[0.6, 0.7)",
            "[0.7, 0.8)",
            "[0.8, 0.9)",
            "[0.9, 1.0)",
            ">= 1",
        ]

        correct_result = correct_result / correct_result.sum()

        test_result = _pandas_group_population(
            data=self.get_sample_data(),
            population_col="year",
            binning_type="ecb",
            binning_col="lgd_est",
            minimum_value=1,
        )
        test_result.index = test_result.index.astype(str)

        pd.testing.assert_frame_equal(correct_result, test_result)

    def test_pandas_group_population_lgd_binning(self):
        """
        Test case for scenario:
            date_col = 'year'
            binning_type = 'lgd'
            binning_col = 'lgd_est'
            minimum_value = 1
        """
        correct_result = pd.DataFrame.from_dict(
            {"2010": [0.4, 0.3, 0.3], "2011": [0.3, 0.4, 0.3], "2012": [0.3, 0.3, 0.4]}
        )
        correct_result.index = [0.15, 0.4, 0.6]

        test_result = _pandas_group_population(
            data=self.get_sample_data(),
            population_col="year",
            binning_type="lgd",
            binning_col="lgd_est",
            minimum_value=1,
        )
        pd.testing.assert_frame_equal(correct_result, test_result)

    def test_pandas_group_population_manual_binning(self):
        """
        Test case for scenario:
            date_col = 'year'
            binning_type = 'manual'
            binning_col = 'lgd_est'
            minimum_value = 1,
            bins = [0.5]
        """
        correct_result = pd.DataFrame.from_dict(
            {"2010": [0.7, 0.3], "2011": [0.7, 0.3], "2012": [0.6, 0.4]}
        )
        correct_result.index = ["[0.0, 0.5)", ">= 0.5"]

        test_result = _pandas_group_population(
            data=self.get_sample_data(),
            population_col="year",
            binning_type="manual",
            binning_col="lgd_est",
            minimum_value=1,
            bins=[0.5],
        )
        test_result.index = test_result.index.astype(str)

        pd.testing.assert_frame_equal(correct_result, test_result)

    def test_pandas_group_population_column_grouping(self):
        """
        Test case for scenario:
            date_col = 'year'
            binning_type = 'column'
            binning_col = 'country'
            minimum_value = 1
        """
        correct_result = pd.DataFrame.from_dict(
            {
                "2010": [0.4, 0.2, 0.2, 0.2],
                "2011": [0.4, 0.2, 0.2, 0.2],
                "2012": [0.4, 0.2, 0.2, 0.2],
            }
        )
        correct_result.index = ["DK", "SE", "NO", "FI"]

        test_result = _pandas_group_population(
            data=self.get_sample_data(),
            population_col="year",
            binning_type="column",
            binning_col="country",
            minimum_value=1,
        )
        pd.testing.assert_frame_equal(correct_result, test_result)

    def test_pandas_group_population_check_cols_row_removed(self):
        """
        Tests that the row containing zeros in both of the
        'check_cols' is removed.
        """
        sample_df = self.get_sample_data()
        sample_df = sample_df.drop(
            sample_df[
                (sample_df["year"].isin(["2010", "2011"]))
                & (sample_df["country"] == "SE")
            ].index
        )
        correct_result = pd.DataFrame(
            {
                "2010": [0.5, 0.25, 0.25],
                "2011": [0.5, 0.25, 0.25],
                "2012": [0.5, 0.25, 0.25],
            },
            index=["DK", "NO", "FI"],
        )
        test_result = _pandas_group_population(
            data=sample_df,
            population_col="year",
            binning_type="column",
            binning_col="country",
            minimum_value=1,
            bins=None,
            check_cols=["2010", "2011"],
        )
        pd.testing.assert_frame_equal(correct_result, test_result)

    def test_pandas_group_population_value_error_min_value(self):
        """
        Tests that the function raises a ValueError if a
        'minimum_value' of zero is chosen.
        """
        self.assertRaises(
            ValueError,
            _pandas_group_population,
            self.get_sample_data(),
            "year",
            "lgd",
            "lgd_est",
            0,
        )

    def test_pandas_group_population_value_error_binning_type(self):
        """
        Tests that the function raises a ValueError if an invalid
        value is passed to the 'binning_type' argument.
        """
        self.assertRaises(
            ValueError,
            _pandas_group_population,
            self.get_sample_data(),
            "year",
            "unkn",
            "lgd_est",
            1,
        )

    def test_pandas_group_population_value_error_check_cols_length(self):
        """
        Tests that a ValueError is raised when not exactly 2 values are
        provided in the list for the argument 'check_cols'.
        """
        self.assertRaises(
            ValueError,
            _pandas_group_population,
            self.get_sample_data(),
            "year",
            "ecb",
            "lgd_est",
            1,
            None,
            ["2010", "2011", "2012"],
        )

    def test_pandas_group_population_warning_row_removed(self):
        """
        Tests that a warning is raised when coinciding values of
        zero or less are found in the 'check_cols', causing that
        row to be dropped.
        """
        sample_df = self.get_sample_data()
        sample_df = sample_df.drop(
            sample_df[
                (sample_df["year"].isin(["2010", "2011"]))
                & (sample_df["country"] == "SE")
            ].index
        )
        self.assertWarns(
            UserWarning,
            _pandas_group_population,
            sample_df,
            "year",
            "column",
            "country",
            1,
            None,
            ["2010", "2011"],
        )

    def test_pandas_group_population_warning_zero_found(self):
        """
        Tests that a warning is raised when at least one zero (or less)
        value is found and replaced in the grouped data.
        """
        sample_df = self.get_sample_data()
        sample_df = sample_df.drop(
            sample_df[
                (sample_df["year"].isin(["2010"])) & (sample_df["country"] == "SE")
            ].index
        )
        self.assertWarns(
            UserWarning,
            _pandas_group_population,
            sample_df,
            "year",
            "column",
            "country",
        )


class TestPopulationStabilityIndex(unittest.TestCase):
    """
    Test class for the top-level function
    'crv.validation.stability.population_stability_index'.

    Errors and further functionality is checked in unit tests
    for the subfunctions. This test class tests the assembly of
    those subfunctions within this top-level function.
    """

    @staticmethod
    def get_sample_data():
        """
        Generate small sample data for test.
        """
        d_sample = {
            "year": ["2010"] * 10 + ["2011"] * 10 + ["2012"] * 10,
            "lgd_est": [0.15, 0.4, 0.6] * 10,
            "lgd_actual": list(np.random.uniform(low=0.01, high=0.8, size=30)),
            "country": ["DK", "SE", "NO", "FI", "DK"] * 6,
        }
        df_sample = pd.DataFrame.from_dict(d_sample)
        return df_sample

    def test_pandas_group_population_auto_binning(self):
        """
        Test case for scenario:
            population_col = 'year'
            population_1 = '2011'
            population_2 = '2012'
            binning_type = 'auto'
            binning_col = 'lgd_est'
            minimum_value = 1
        """
        df_grouped = pd.DataFrame.from_dict(
            {"2010": [0.4, 0.3, 0.3], "2011": [0.3, 0.4, 0.3], "2012": [0.3, 0.3, 0.4]}
        )
        df_grouped.index = [0.15, 0.4, 0.6]
        psi_correct = psi_test(df_grouped, "2011", "2012")

        psi_result = population_stability_index(
            data=self.get_sample_data(),
            population_col="year",
            population_1="2011",
            population_2="2012",
            binning_type="auto",
            binning_col="lgd_est",
            minimum_value=1,
        )
        self.assertEqual(psi_correct, psi_result)

    def test_pandas_group_population_ecb_binning(self):
        """
        Test case for scenario:
            population_col = 'year'
            population_1 = '2011'
            population_2 = '2012'
            binning_type = 'ecb'
            binning_col = 'lgd_est'
            minimum_value = 1
        """
        df_grouped = pd.DataFrame.from_dict(
            {"2010": [4, 3, 3], "2011": [3, 4, 3], "2012": [3, 3, 4]}
        )
        df_grouped.index = ["[0.1, 0.2)", "[0.4, 0.5)", "[0.6, 0.7)"]
        df_grouped = df_grouped / df_grouped.sum()
        psi_correct = psi_test(df_grouped, "2011", "2012")

        psi_result = population_stability_index(
            data=self.get_sample_data(),
            population_col="year",
            population_1="2011",
            population_2="2012",
            binning_type="ecb",
            binning_col="lgd_est",
            minimum_value=1,
        )
        self.assertEqual(psi_correct, psi_result)

    def test_pandas_group_population_lgd_binning(self):
        """
        Test case for scenario:
            population_col = 'year'
            population_1 = '2011'
            population_2 = '2012'
            binning_type = 'lgd'
            binning_col = 'lgd_est'
            minimum_value = 1
        """
        df_grouped = pd.DataFrame.from_dict(
            {"2010": [0.4, 0.3, 0.3], "2011": [0.3, 0.4, 0.3], "2012": [0.3, 0.3, 0.4]}
        )
        df_grouped.index = [0.15, 0.4, 0.6]
        psi_correct = psi_test(df_grouped, "2011", "2012")

        psi_result = population_stability_index(
            data=self.get_sample_data(),
            population_col="year",
            population_1="2011",
            population_2="2012",
            binning_type="lgd",
            binning_col="lgd_est",
            minimum_value=1,
        )
        self.assertEqual(psi_correct, psi_result)

    def test_pandas_group_population_manual_binning(self):
        """
        Test case for scenario:
            population_col = 'year'
            population_1 = '2011'
            population_2 = '2012'
            binning_type = 'manual'
            binning_col = 'lgd_est'
            minimum_value = 1,
            bins = [0.5]
        """
        df_grouped = pd.DataFrame.from_dict(
            {"2010": [0.7, 0.3], "2011": [0.7, 0.3], "2012": [0.6, 0.4]}
        )
        df_grouped.index = ["[0.0, 0.5)", ">= 0.5"]
        psi_correct = psi_test(df_grouped, "2011", "2012")

        psi_result = population_stability_index(
            data=self.get_sample_data(),
            population_col="year",
            population_1="2011",
            population_2="2012",
            binning_type="manual",
            binning_col="lgd_est",
            minimum_value=1,
            bins=[0.5],
        )
        self.assertEqual(psi_correct, psi_result)

    def test_pandas_group_population_column_grouping(self):
        """
        Test case for scenario:
            population_col = 'year'
            population_1 = '2011'
            population_2 = '2012'
            binning_type = 'column'
            binning_col = 'country'
            minimum_value = 1
        """
        df_grouped = pd.DataFrame.from_dict(
            {
                "2010": [0.4, 0.2, 0.2, 0.2],
                "2011": [0.4, 0.2, 0.2, 0.2],
                "2012": [0.4, 0.2, 0.2, 0.2],
            }
        )
        df_grouped.index = ["DK", "SE", "NO", "FI"]
        psi_correct = psi_test(df_grouped, "2011", "2012")

        psi_result = population_stability_index(
            data=self.get_sample_data(),
            population_col="year",
            population_1="2011",
            population_2="2012",
            binning_type="column",
            binning_col="country",
            minimum_value=1,
        )
        self.assertEqual(psi_correct, psi_result)


class TestZTest(unittest.TestCase):
    """
    Test class for the z-test function in
    'crv.validation.stability.z_test'.
    """

    def test_z_test_lower(self):
        """
        Tests that the correct values are calculated
        the the lower variant of the z-test function.
        """
        z_value_test, p_value_test = z_test(0.04, 0.05, 1234, "lower")
        self.assertAlmostEqual(z_value_test, 1.1715956053664185, places=12)
        self.assertAlmostEqual(p_value_test, 0.8793202733535856, places=12)

    def test_z_test_upper(self):
        """
        Tests that the correct values are calculated
        the the upper variant of the z-test function.
        """
        z_value_test, p_value_test = z_test(0.04, 0.05, 1234, "upper")
        self.assertAlmostEqual(z_value_test, -1.1715956053664185, places=12)
        self.assertAlmostEqual(p_value_test, 0.12067972664641441, places=12)


class TestMmStabilityTest(unittest.TestCase):
    """
    Test class for the function
    'crv.validation.stability.mm_stability_test'.
    """

    @staticmethod
    def get_ecb_mm_and_results():
        """
        Returns the migration matrix, as well as the
        z-matrix and p-value matrix, as described in the
        sample data of the ECB sample template;
        'LEICode_PD_ModelID_EndOfObservationPeriod_versionNumber.xlsx'.
        """
        row_labels = [f"Rating {i+1}" for i in range(17)]
        mm_sample = pd.DataFrame.from_dict(
            {
                "Rating 1": [
                    0.674689228151439,
                    0.197892589438617,
                    0.02738397918501,
                    0.0271303872754138,
                    0.0132468143764919,
                    0.00882527626042512,
                    0.00101883733555445,
                    0.000545773812348726,
                    0.00101918247006151,
                    0.000440164328015793,
                    0.00017741506253881,
                    4.74754907778859e-05,
                    0.000104387765753854,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                ],
                "Rating 2": [
                    0.0668620314789431,
                    0.488793853697794,
                    0.220565684945737,
                    0.0547326073730087,
                    0.0382274820966278,
                    0.0157851149795471,
                    0.00277391478950226,
                    0.00156613354847895,
                    0.00156517307902304,
                    0.00112041828949474,
                    0.00054998669387031,
                    0.00040354167161203,
                    0.000208775531507707,
                    5.67214974475326e-05,
                    0.000110643947776057,
                    0.0,
                    0.0,
                ],
                "Rating 3": [
                    0.0229522143971262,
                    0.0737874435013709,
                    0.421127610530169,
                    0.206402026397805,
                    0.0752782167232626,
                    0.0480914817262408,
                    0.0106940736388854,
                    0.00443737838735703,
                    0.00469551923706912,
                    0.00253427946433335,
                    0.00182737514414974,
                    0.00106819854250243,
                    0.000765510282194927,
                    0.000623936471922859,
                    0.000110643947776057,
                    0.0,
                    0.0,
                ],
                "Rating 4": [
                    0.0176490050574278,
                    0.0392191725699741,
                    0.0774824150928463,
                    0.358704694736581,
                    0.212302054264869,
                    0.0783985678793405,
                    0.0231134776562279,
                    0.0102747852498695,
                    0.00924544097841517,
                    0.00461505628768073,
                    0.00420473698216979,
                    0.00249246326583901,
                    0.00139183687671805,
                    0.000510493477027794,
                    0.000110643947776057,
                    0.000541858574911948,
                    0.0,
                ],
                "Rating 5": [
                    0.0240487781821619,
                    0.0166665107008169,
                    0.0373462866414064,
                    0.0718924221165427,
                    0.288185455401271,
                    0.130630819035828,
                    0.0372135914387917,
                    0.0133358644582602,
                    0.0118297965274997,
                    0.007522808515179,
                    0.00486117271356338,
                    0.00327580886367413,
                    0.00180938793973346,
                    0.000737379466817924,
                    0.000221287895552113,
                    0.0,
                    0.0,
                ],
                "Rating 6": [
                    0.0482393534054923,
                    0.0352701172551258,
                    0.0485847983300521,
                    0.0752573351378869,
                    0.133224624281344,
                    0.400993784663259,
                    0.202860181308425,
                    0.109724265578283,
                    0.0743275215666291,
                    0.041868964413381,
                    0.0225494544486827,
                    0.0160467158829254,
                    0.00786387835345697,
                    0.00476460578559274,
                    0.00188094711219296,
                    0.000541858574911948,
                    0.0,
                ],
                "Rating 7": [
                    0.00570024105496999,
                    0.0062979010115945,
                    0.0177580356347879,
                    0.0420427877869799,
                    0.0498940927277006,
                    0.0911805793731126,
                    0.419820476399414,
                    0.262256181481657,
                    0.186291995777673,
                    0.13071546710772,
                    0.0637984564889559,
                    0.038288983312365,
                    0.0189289815233655,
                    0.00935904707884288,
                    0.00365125027660987,
                    0.00162557572473584,
                    0.000288850375505488,
                ],
                "Rating 8": [
                    0.000954766743867278,
                    0.00131011313762739,
                    0.00274037652971379,
                    0.00581099370475682,
                    0.0105571058736509,
                    0.0155090636841973,
                    0.0571590055552663,
                    0.190119121066869,
                    0.135442070396389,
                    0.075681587792776,
                    0.0442827996096869,
                    0.0201770835806015,
                    0.0134312258603292,
                    0.00606920022688599,
                    0.00309803053772959,
                    0.0010837171498239,
                    0.000288850375505488,
                ],
                "Rating 9": [
                    0.0006144538450631,
                    0.000692488372745904,
                    0.00137513479288887,
                    0.00317866322311484,
                    0.00479104327068554,
                    0.00913478831884761,
                    0.0215666297307146,
                    0.0802762090076408,
                    0.134641284169912,
                    0.0704663074214373,
                    0.0411957775215116,
                    0.0208417404514919,
                    0.0108563276384008,
                    0.00589903573454339,
                    0.00354060632883381,
                    0.00135464643727987,
                    0.000288850375505488,
                ],
                "Rating 10": [
                    0.000519922484284161,
                    0.00110423821600022,
                    0.00241390567960349,
                    0.00598482684977091,
                    0.0088424167030898,
                    0.016496156194842,
                    0.0388348070530316,
                    0.102510559536804,
                    0.171295453718196,
                    0.289588112895481,
                    0.178319879357757,
                    0.0921499275998766,
                    0.0510804133755524,
                    0.0247305728871242,
                    0.0115069705687099,
                    0.00894066648604714,
                    0.00202195262853842,
                ],
                "Rating 11": [
                    0.00024578153802524,
                    0.000505329353084849,
                    0.00151363757778415,
                    0.00230949749804438,
                    0.00363110647883536,
                    0.00774616665133048,
                    0.0178556820632572,
                    0.0396041953395662,
                    0.0636625050049139,
                    0.121765459104732,
                    0.251716490730063,
                    0.164217722600707,
                    0.0887991927346115,
                    0.0523539421440726,
                    0.0261119716751494,
                    0.0167976158222704,
                    0.00404390525707683,
                ],
                "Rating 12": [
                    0.000141797041168408,
                    0.000243306725559372,
                    0.000662834756284564,
                    0.00145274842618921,
                    0.00240392697441415,
                    0.00425788210100131,
                    0.00924390370871664,
                    0.0171562811447012,
                    0.0273359298220071,
                    0.0497785840046951,
                    0.120358378426328,
                    0.245258385358559,
                    0.174431956574689,
                    0.0980147475893364,
                    0.056649701261341,
                    0.0357626659441886,
                    0.0106874638937031,
                ],
                "Rating 13": [
                    6.61719525452569e-05,
                    0.000177801068678002,
                    0.000336363906174256,
                    0.000620832660764617,
                    0.00122717950442121,
                    0.0022502363166392,
                    0.00421664795079834,
                    0.00797304351952921,
                    0.012412186510392,
                    0.0202475590887265,
                    0.0481149649605251,
                    0.117929119092269,
                    0.239013187654407,
                    0.171979580260919,
                    0.100796636423988,
                    0.0544567867786508,
                    0.0190641247833622,
                ],
                "Rating 14": [
                    2.83594082336815e-05,
                    4.67897549152638e-05,
                    0.000296791681918461,
                    0.000409749556104648,
                    0.000672427125710251,
                    0.000987092510644705,
                    0.0014947905434047,
                    0.0035119358359831,
                    0.00567830233319987,
                    0.00869658005655445,
                    0.0227623525237293,
                    0.049920478552947,
                    0.111938480810049,
                    0.222575155984118,
                    0.167846868776278,
                    0.0921159577350312,
                    0.0384170999422299,
                ],
                "Rating 15": [
                    0.0,
                    2.80738529491583e-05,
                    6.9251392447641e-05,
                    0.000223499757875262,
                    0.000252160172141344,
                    0.000476815873786002,
                    0.000847791651483264,
                    0.00156613354847895,
                    0.00196556619226149,
                    0.00360134450194739,
                    0.00832076643307017,
                    0.0201533458352126,
                    0.0430077594905877,
                    0.0953488372093023,
                    0.199933613631334,
                    0.133839068003251,
                    0.0629693818601964,
                ],
                "Rating 16": [
                    0.0,
                    9.35795098305275e-06,
                    3.95722242557949e-05,
                    9.93332257223388e-05,
                    0.000201728137713075,
                    0.000175669006131685,
                    0.000334654599269709,
                    0.000854254662806701,
                    0.000764386852546136,
                    0.00148055273968948,
                    0.00305153907566752,
                    0.00709758587129394,
                    0.0125961237342983,
                    0.028757799205899,
                    0.0568709891568931,
                    0.132213492278515,
                    0.0756787983824379,
                ],
                "Rating 17": [
                    0.0,
                    1.87159019661055e-05,
                    3.95722242557949e-05,
                    8.69165725070465e-05,
                    0.000168106781427563,
                    0.000217494959972562,
                    0.000290033986033748,
                    0.000901713255184851,
                    0.000691588104684599,
                    0.00189404044176493,
                    0.00365475028829948,
                    0.00776224274218435,
                    0.0137443891575907,
                    0.0211003970504821,
                    0.0400531090949325,
                    0.0701706854510973,
                    0.122183708838821,
                ],
                "Default": [
                    9.523809523809524e-05,
                    0.0001818181818181818,
                    0.0002,
                    0.000375,
                    0.0008333333333333334,
                    0.0008333333333333334,
                    0.0011111111111111111,
                    0.00225,
                    0.0016666666666666668,
                    0.004666666666666667,
                    0.01,
                    0.01875,
                    0.03,
                    0.05,
                    0.09,
                    0.14,
                    0.6,
                ],
                "Other model": [
                    0.045730885721338155,
                    0.04591812643612636,
                    0.046687916291554804,
                    0.04776189256697731,
                    0.05202024192433686,
                    0.05600322571050695,
                    0.04985012982670402,
                    0.050378723522060506,
                    0.05182314353082019,
                    0.05443868229324149,
                    0.05675123451314371,
                    0.05803972709505373,
                    0.06000939489891803,
                    0.06903951597655508,
                    0.07916869513904251,
                    0.10351846834642837,
                    0.021355671095705943,
                ],
                "Relationship terminated": [
                    0.09146177144267631,
                    0.09183625287225272,
                    0.09337583258310961,
                    0.09552378513395464,
                    0.10404048384867373,
                    0.1120064514210139,
                    0.09970025965340805,
                    0.10075744704412103,
                    0.10364628706164039,
                    0.10887736458648299,
                    0.11350246902628744,
                    0.11607945419010746,
                    0.12001878979783608,
                    0.1380790319531102,
                    0.15833739027808505,
                    0.20703693669285678,
                    0.04271134219141189,
                ],
                "N": [
                    105000,
                    110000,
                    100000,
                    80000,
                    60000,
                    120000,
                    135000,
                    40000,
                    30000,
                    75000,
                    55000,
                    40000,
                    30000,
                    20000,
                    10000,
                    5000,
                    2000,
                ],
            }
        )
        mm_sample.index = row_labels
        z_sample = pd.DataFrame.from_dict(
            {
                "Rating 1": [
                    np.nan,
                    124.342907740523,
                    133.108372891983,
                    27.4142016720247,
                    27.1352025273276,
                    15.3836135204675,
                    10.4752011158586,
                    4.44173815421583,
                    1.86035025606211,
                    4.71653136578088,
                    3.24000288919421,
                    3.3537079287164,
                    1.02172108791387,
                    1.06512642402963,
                    1.05193246557894,
                    np.nan,
                    np.nan,
                ],
                "Rating 2": [
                    322.883969870644,
                    np.nan,
                    81.7790670529629,
                    87.9093420392434,
                    27.1022807914272,
                    44.6462724953416,
                    25.1340898532733,
                    7.4164474939035,
                    6.85775477713391,
                    6.40664223476488,
                    6.14618712096936,
                    3.46558939728733,
                    3.08983196043733,
                    3.07539485799515,
                    0.0,
                    np.nan,
                    np.nan,
                ],
                "Rating 3": [
                    47.9950002887309,
                    220.304573062132,
                    np.nan,
                    58.517892304908,
                    64.7371075288203,
                    29.6271047778304,
                    24.8744649915062,
                    9.63640871538428,
                    6.67945310690474,
                    6.74147348896127,
                    7.18200135343098,
                    4.77506288606488,
                    2.33582848599978,
                    -0.476328210042138,
                    0.0,
                    1.64643910426242,
                    np.nan,
                ],
                "Rating 4": [
                    8.53128301120109,
                    34.2870775823467,
                    176.166234130996,
                    np.nan,
                    26.4264382356391,
                    39.8362557681477,
                    21.1276015677828,
                    3.98507765925407,
                    3.08386584885753,
                    7.23049773717719,
                    1.61688147204469,
                    2.06292592535702,
                    1.27827401442975,
                    0.90833584032794,
                    0.607311091673659,
                    -1.64643910426242,
                    np.nan,
                ],
                "Rating 5": [
                    -10.1605247705657,
                    31.785511225744,
                    37.7205603511243,
                    137.449652290727,
                    np.nan,
                    138.310347126279,
                    131.987264650491,
                    57.153394090294,
                    37.7444683486099,
                    42.8381472069514,
                    25.1999895696333,
                    18.4527229516471,
                    10.6825785355675,
                    7.68957553330665,
                    3.62212134362236,
                    1.64643910426242,
                    np.nan,
                ],
                "Rating 6": [
                    -29.2733442658215,
                    -27.1649229792529,
                    -12.1325770608853,
                    -2.48116571028133,
                    60.2122906863738,
                    np.nan,
                    105.071129639551,
                    51.6601593796839,
                    38.9351592211042,
                    59.9565163214363,
                    33.2499093434711,
                    19.1713445638061,
                    11.7354876318838,
                    5.47140638768869,
                    2.3807942233241,
                    1.64643910426242,
                    0.760176077171571,
                ],
                "Rating 7": [
                    60.3724963453753,
                    47.6132871200337,
                    38.1209574931503,
                    27.5597979651456,
                    48.6304130468279,
                    170.505626734785,
                    np.nan,
                    -21.5750273744256,
                    -15.5903061905369,
                    -33.4209738669916,
                    -13.9461993893399,
                    -15.0232488147988,
                    -5.29594334037597,
                    -3.74700927374904,
                    -0.673408765744769,
                    -0.736150326644961,
                    0.0,
                ],
                "Rating 8": [
                    18.881479914025,
                    18.9967755587535,
                    33.3537365946475,
                    47.50253620577,
                    39.7013302940037,
                    82.4975275596669,
                    226.710609804159,
                    np.nan,
                    -0.266887865329866,
                    -3.73639193856229,
                    -2.47637636207721,
                    0.65635414198735,
                    -2.86212169261075,
                    -0.219973008279334,
                    0.54319355034927,
                    0.387970104485936,
                    0.0,
                ],
                "Rating 9": [
                    2.78385805700004,
                    4.57788776663903,
                    6.73125468444521,
                    7.85563483602593,
                    11.4129488835085,
                    14.0774976459033,
                    46.9881590199166,
                    43.2229819377253,
                    np.nan,
                    107.426408534191,
                    71.7807152807201,
                    43.4155156300709,
                    28.36746922559,
                    15.305898311204,
                    6.5079562703606,
                    5.30147118657124,
                    1.61339297022014,
                ],
                "Rating 10": [
                    0.90948112835303,
                    -3.22187938887586,
                    -5.33724323366528,
                    -8.29495837870135,
                    -8.50425831237933,
                    -15.9450698056318,
                    -25.8800086460178,
                    -10.4152610532099,
                    -11.5033385903246,
                    np.nan,
                    26.4144847856864,
                    28.7596760797263,
                    17.5574304067563,
                    14.140615032945,
                    7.55149729995739,
                    3.46713390051161,
                    1.16141187405198,
                ],
                "Rating 11": [
                    3.2104019216276,
                    4.95166063882117,
                    4.54314071963556,
                    11.4236445425167,
                    11.4419824778631,
                    19.4983527600956,
                    32.5006151105917,
                    33.8483324716918,
                    39.4448603777974,
                    74.2462675859414,
                    np.nan,
                    25.5346409040235,
                    29.3202042203712,
                    16.7691766947447,
                    10.6753667653602,
                    5.86950144145289,
                    2.45157841338581,
                ],
                "Rating 12": [
                    1.71154932383642,
                    3.17628657118004,
                    5.76799105507651,
                    3.95109448860659,
                    3.86988510185596,
                    11.0346580435908,
                    19.2474622898165,
                    18.9286383516513,
                    21.010682140743,
                    48.3344715134224,
                    51.7171101576771,
                    np.nan,
                    17.4847590528454,
                    20.3379942862008,
                    11.195384469685,
                    4.40943270521068,
                    2.17442079785057,
                ],
                "Rating 13": [
                    1.69928890787085,
                    1.05871903490617,
                    3.26619155936115,
                    5.16816444900857,
                    4.78434216552436,
                    8.62351885765086,
                    15.9358241988703,
                    11.6055402529868,
                    13.0017038891641,
                    30.7539076081486,
                    41.9321738631746,
                    43.2323943274931,
                    np.nan,
                    11.4284510813873,
                    13.0459831000153,
                    6.98940905433026,
                    3.62175654713263,
                ],
                "Rating 14": [
                    1.26021858496707,
                    2.8995175125525,
                    0.497319829992453,
                    1.85980124005171,
                    3.11801458429213,
                    7.69231501192034,
                    13.2416271137672,
                    8.33267028719224,
                    8.68252610652046,
                    18.6368459902872,
                    22.4351316005639,
                    33.6667751869886,
                    38.0386090346166,
                    np.nan,
                    5.29834279427957,
                    6.23060347887778,
                    3.45869114033326,
                ],
                "Rating 15": [
                    1.7256367850203,
                    0.717418784454693,
                    3.76116967112842,
                    2.09346322369893,
                    3.3858552807772,
                    4.62038308644156,
                    4.91203902686481,
                    5.463127706165,
                    7.36190230818163,
                    12.5961515484389,
                    19.2750650739717,
                    22.6335366162189,
                    30.8067587713872,
                    32.7549805730413,
                    np.nan,
                    -0.222848976001154,
                    1.52734326564242,
                ],
                "Rating 16": [
                    np.nan,
                    1.01458574850186,
                    0.899687952364601,
                    1.95465883056979,
                    0.579840880637395,
                    4.08426516973833,
                    5.48350085025177,
                    2.89427013524724,
                    3.98295765514598,
                    8.15094555496963,
                    11.6020524096845,
                    15.8673347039014,
                    22.5263103837984,
                    27.2228768054182,
                    29.4279287790985,
                    np.nan,
                    4.70130707424011,
                ],
                "Rating 17": [
                    np.nan,
                    -0.585769527798413,
                    0.0,
                    0.257336754659666,
                    0.428240325788273,
                    -0.730719318723468,
                    0.655950890247783,
                    -0.226509717592836,
                    0.330451992380254,
                    -1.94936659071367,
                    -1.72751325480813,
                    -1.09050346466474,
                    -1.22546714208262,
                    4.8527028577393,
                    5.40990906996164,
                    9.8459594709709,
                    np.nan,
                ],
            }
        )
        z_sample.index = row_labels
        p_sample = pd.DataFrame.from_dict(
            {
                "Rating 1": [
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.999995538244527,
                    0.968582006201242,
                    0.999998800503011,
                    0.999402357557703,
                    0.999601317601056,
                    0.846543536338556,
                    0.856590638455278,
                    0.853584732276265,
                    np.nan,
                    np.nan,
                ],
                "Rating 2": [
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.99999999999994,
                    0.999999999996502,
                    0.99999999992562,
                    0.999999999603162,
                    0.999735464698737,
                    0.998998651165709,
                    0.998948879825495,
                    0.5,
                    np.nan,
                    np.nan,
                ],
                "Rating 3": [
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.999999999988008,
                    0.999999999992161,
                    0.999999999999656,
                    0.99999910174447,
                    0.990249908828796,
                    0.316920285416046,
                    0.5,
                    0.950163306115527,
                    np.nan,
                ],
                "Rating 4": [
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    0.999966270970051,
                    0.998978351453622,
                    0.999999999999759,
                    0.947048065732946,
                    0.980440166735272,
                    0.899423586555585,
                    0.818149593866971,
                    0.728177760579566,
                    0.0498366938844727,
                    np.nan,
                ],
                "Rating 5": [
                    1.48735497530332e-24,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.999999999999993,
                    0.999853901504192,
                    0.950163306115527,
                    np.nan,
                ],
                "Rating 6": [
                    1.13300769517893e-188,
                    8.43706306386198e-163,
                    3.54899899386803e-34,
                    0.00654767391136479,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.999999977676092,
                    0.991362320438813,
                    0.950163306115527,
                    0.776425328649078,
                ],
                "Rating 7": [
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.5414900935012e-103,
                    4.23632409220615e-55,
                    3.39935323089449e-245,
                    1.65911249426246e-44,
                    2.58549544203318e-51,
                    5.92017750544105e-08,
                    8.94777362700797e-05,
                    0.250343636726918,
                    0.230819609099643,
                    0.5,
                ],
                "Rating 8": [
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    0.394777749970413,
                    9.33398095341594e-05,
                    0.00663617926695895,
                    0.744201855471543,
                    0.00210407648886503,
                    0.412946088060476,
                    0.706501726595747,
                    0.65098092133236,
                    0.5,
                ],
                "Rating 9": [
                    0.997314173187584,
                    0.999997651527162,
                    0.99999999999159,
                    0.999999999999998,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.99999999996191,
                    0.99999994256341,
                    0.946670420277333,
                ],
                "Rating 10": [
                    0.818451892559135,
                    0.000636763663257086,
                    4.71852025362589e-08,
                    5.43116154479229e-17,
                    9.1380101807752e-18,
                    1.5414773442328e-57,
                    5.59164299318187e-148,
                    1.0560865463002e-25,
                    6.34548383674108e-31,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.999999999999978,
                    0.999736980112664,
                    0.877262778780413,
                ],
                "Rating 11": [
                    0.999337252532852,
                    0.999999632085788,
                    0.999997228888639,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    0.999999997814462,
                    0.992888440332803,
                ],
                "Rating 12": [
                    0.956510122967399,
                    0.999254132444909,
                    0.999999995988897,
                    0.99996110269996,
                    0.999945556671018,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    1.0,
                    0.999994817912126,
                    0.985163226217919,
                ],
                "Rating 13": [
                    0.955367619249438,
                    0.855136121845527,
                    0.999454977578403,
                    0.99999988179787,
                    0.999999142258818,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    1.0,
                    1.0,
                    0.99999999999862,
                    0.999853695285836,
                ],
                "Rating 14": [
                    0.896204739874304,
                    0.99813131266733,
                    0.690518234944122,
                    0.968543174063063,
                    0.999089631032331,
                    0.999999999999993,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    0.999999941570787,
                    0.999999999767679,
                    0.999728596515154,
                ],
                "Rating 15": [
                    0.957793611390156,
                    0.763442133787062,
                    0.999915439670941,
                    0.981846088153024,
                    0.999645216034961,
                    0.999998084839305,
                    0.999999549329469,
                    0.99999997660911,
                    0.999999999999909,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    0.411826524488102,
                    0.93666216189894,
                ],
                "Rating 16": [
                    np.nan,
                    0.844848332194054,
                    0.815856831721081,
                    0.974688323781442,
                    0.718989036768097,
                    0.999977891742067,
                    0.999999979150486,
                    0.998099794733748,
                    0.999965968556792,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    np.nan,
                    0.999998707492857,
                ],
                "Rating 17": [
                    np.nan,
                    0.27901520189725,
                    0.5,
                    0.601540589270164,
                    0.665761920093141,
                    0.232475306511516,
                    0.744072138565308,
                    0.410402501039265,
                    0.629470769227228,
                    0.0256258306810397,
                    0.0420377633887118,
                    0.137745713979241,
                    0.110199631417658,
                    0.999999391049492,
                    0.999999968471621,
                    1.0,
                    np.nan,
                ],
            }
        )
        p_sample.index = row_labels
        return mm_sample, z_sample, p_sample

    def test_mm_stability_test_ecb_example(self):
        """
        Tests for correct calculation of the z- and p-matrices
        according to examples in the ECB example data.
        """
        mm_sample, z_sample, p_sample = self.get_ecb_mm_and_results()
        z_result, p_result = mm_stability_test(mm_sample, mm_sample["N"])
        self.assertTrue(
            np.allclose(z_sample.to_numpy(), z_result.to_numpy(), equal_nan=True),
            msg="z-test matrices are not equal.",
        )
        self.assertTrue(
            np.allclose(p_sample.to_numpy(), p_result.to_numpy(), equal_nan=True),
            msg="p-value matrices are not equal.",
        )


class TestMatrixWeightedBandwith(unittest.TestCase):
    """
    Test class for the function
    'crv.validation.stability.matrix_weighted_bandwidth'.
    """

    @staticmethod
    def get_mm_n_series_for_mwb():
        """
        Returns the migration matrix, as well as the
        N_data.
        """
        n_series = pd.Series(
            [
                105000,
                110000,
                100000,
                80000,
                60000,
                120000,
                135000,
                40000,
                30000,
                75000,
                55000,
                40000,
                30000,
                20000,
                10000,
                5000,
                2000,
            ]
        )
        mm_sample = pd.DataFrame.from_dict(
            {
                "Rating 1": [
                    0.674689228151439,
                    0.197892589438617,
                    0.02738397918501,
                    0.0271303872754138,
                    0.0132468143764919,
                    0.00882527626042512,
                    0.00101883733555445,
                    0.000545773812348726,
                    0.00101918247006151,
                    0.000440164328015793,
                    0.00017741506253881,
                    4.74754907778859e-05,
                    0.000104387765753854,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                ],
                "Rating 2": [
                    0.0668620314789431,
                    0.488793853697794,
                    0.220565684945737,
                    0.0547326073730087,
                    0.0382274820966278,
                    0.0157851149795471,
                    0.00277391478950226,
                    0.00156613354847895,
                    0.00156517307902304,
                    0.00112041828949474,
                    0.00054998669387031,
                    0.00040354167161203,
                    0.000208775531507707,
                    5.67214974475326e-05,
                    0.000110643947776057,
                    0.0,
                    0.0,
                ],
                "Rating 3": [
                    0.0229522143971262,
                    0.0737874435013709,
                    0.421127610530169,
                    0.206402026397805,
                    0.0752782167232626,
                    0.0480914817262408,
                    0.0106940736388854,
                    0.00443737838735703,
                    0.00469551923706912,
                    0.00253427946433335,
                    0.00182737514414974,
                    0.00106819854250243,
                    0.000765510282194927,
                    0.000623936471922859,
                    0.000110643947776057,
                    0.0,
                    0.0,
                ],
                "Rating 4": [
                    0.0176490050574278,
                    0.0392191725699741,
                    0.0774824150928463,
                    0.358704694736581,
                    0.212302054264869,
                    0.0783985678793405,
                    0.0231134776562279,
                    0.0102747852498695,
                    0.00924544097841517,
                    0.00461505628768073,
                    0.00420473698216979,
                    0.00249246326583901,
                    0.00139183687671805,
                    0.000510493477027794,
                    0.000110643947776057,
                    0.000541858574911948,
                    0.0,
                ],
                "Rating 5": [
                    0.0240487781821619,
                    0.0166665107008169,
                    0.0373462866414064,
                    0.0718924221165427,
                    0.288185455401271,
                    0.130630819035828,
                    0.0372135914387917,
                    0.0133358644582602,
                    0.0118297965274997,
                    0.007522808515179,
                    0.00486117271356338,
                    0.00327580886367413,
                    0.00180938793973346,
                    0.000737379466817924,
                    0.000221287895552113,
                    0.0,
                    0.0,
                ],
                "Rating 6": [
                    0.0482393534054923,
                    0.0352701172551258,
                    0.0485847983300521,
                    0.0752573351378869,
                    0.133224624281344,
                    0.400993784663259,
                    0.202860181308425,
                    0.109724265578283,
                    0.0743275215666291,
                    0.041868964413381,
                    0.0225494544486827,
                    0.0160467158829254,
                    0.00786387835345697,
                    0.00476460578559274,
                    0.00188094711219296,
                    0.000541858574911948,
                    0.0,
                ],
                "Rating 7": [
                    0.00570024105496999,
                    0.0062979010115945,
                    0.0177580356347879,
                    0.0420427877869799,
                    0.0498940927277006,
                    0.0911805793731126,
                    0.419820476399414,
                    0.262256181481657,
                    0.186291995777673,
                    0.13071546710772,
                    0.0637984564889559,
                    0.038288983312365,
                    0.0189289815233655,
                    0.00935904707884288,
                    0.00365125027660987,
                    0.00162557572473584,
                    0.000288850375505488,
                ],
                "Rating 8": [
                    0.000954766743867278,
                    0.00131011313762739,
                    0.00274037652971379,
                    0.00581099370475682,
                    0.0105571058736509,
                    0.0155090636841973,
                    0.0571590055552663,
                    0.190119121066869,
                    0.135442070396389,
                    0.075681587792776,
                    0.0442827996096869,
                    0.0201770835806015,
                    0.0134312258603292,
                    0.00606920022688599,
                    0.00309803053772959,
                    0.0010837171498239,
                    0.000288850375505488,
                ],
                "Rating 9": [
                    0.0006144538450631,
                    0.000692488372745904,
                    0.00137513479288887,
                    0.00317866322311484,
                    0.00479104327068554,
                    0.00913478831884761,
                    0.0215666297307146,
                    0.0802762090076408,
                    0.134641284169912,
                    0.0704663074214373,
                    0.0411957775215116,
                    0.0208417404514919,
                    0.0108563276384008,
                    0.00589903573454339,
                    0.00354060632883381,
                    0.00135464643727987,
                    0.000288850375505488,
                ],
                "Rating 10": [
                    0.000519922484284161,
                    0.00110423821600022,
                    0.00241390567960349,
                    0.00598482684977091,
                    0.0088424167030898,
                    0.016496156194842,
                    0.0388348070530316,
                    0.102510559536804,
                    0.171295453718196,
                    0.289588112895481,
                    0.178319879357757,
                    0.0921499275998766,
                    0.0510804133755524,
                    0.0247305728871242,
                    0.0115069705687099,
                    0.00894066648604714,
                    0.00202195262853842,
                ],
                "Rating 11": [
                    0.00024578153802524,
                    0.000505329353084849,
                    0.00151363757778415,
                    0.00230949749804438,
                    0.00363110647883536,
                    0.00774616665133048,
                    0.0178556820632572,
                    0.0396041953395662,
                    0.0636625050049139,
                    0.121765459104732,
                    0.251716490730063,
                    0.164217722600707,
                    0.0887991927346115,
                    0.0523539421440726,
                    0.0261119716751494,
                    0.0167976158222704,
                    0.00404390525707683,
                ],
                "Rating 12": [
                    0.000141797041168408,
                    0.000243306725559372,
                    0.000662834756284564,
                    0.00145274842618921,
                    0.00240392697441415,
                    0.00425788210100131,
                    0.00924390370871664,
                    0.0171562811447012,
                    0.0273359298220071,
                    0.0497785840046951,
                    0.120358378426328,
                    0.245258385358559,
                    0.174431956574689,
                    0.0980147475893364,
                    0.056649701261341,
                    0.0357626659441886,
                    0.0106874638937031,
                ],
                "Rating 13": [
                    6.61719525452569e-05,
                    0.000177801068678002,
                    0.000336363906174256,
                    0.000620832660764617,
                    0.00122717950442121,
                    0.0022502363166392,
                    0.00421664795079834,
                    0.00797304351952921,
                    0.012412186510392,
                    0.0202475590887265,
                    0.0481149649605251,
                    0.117929119092269,
                    0.239013187654407,
                    0.171979580260919,
                    0.100796636423988,
                    0.0544567867786508,
                    0.0190641247833622,
                ],
                "Rating 14": [
                    2.83594082336815e-05,
                    4.67897549152638e-05,
                    0.000296791681918461,
                    0.000409749556104648,
                    0.000672427125710251,
                    0.000987092510644705,
                    0.0014947905434047,
                    0.0035119358359831,
                    0.00567830233319987,
                    0.00869658005655445,
                    0.0227623525237293,
                    0.049920478552947,
                    0.111938480810049,
                    0.222575155984118,
                    0.167846868776278,
                    0.0921159577350312,
                    0.0384170999422299,
                ],
                "Rating 15": [
                    0.0,
                    2.80738529491583e-05,
                    6.9251392447641e-05,
                    0.000223499757875262,
                    0.000252160172141344,
                    0.000476815873786002,
                    0.000847791651483264,
                    0.00156613354847895,
                    0.00196556619226149,
                    0.00360134450194739,
                    0.00832076643307017,
                    0.0201533458352126,
                    0.0430077594905877,
                    0.0953488372093023,
                    0.199933613631334,
                    0.133839068003251,
                    0.0629693818601964,
                ],
                "Rating 16": [
                    0.0,
                    9.35795098305275e-06,
                    3.95722242557949e-05,
                    9.93332257223388e-05,
                    0.000201728137713075,
                    0.000175669006131685,
                    0.000334654599269709,
                    0.000854254662806701,
                    0.000764386852546136,
                    0.00148055273968948,
                    0.00305153907566752,
                    0.00709758587129394,
                    0.0125961237342983,
                    0.028757799205899,
                    0.0568709891568931,
                    0.132213492278515,
                    0.0756787983824379,
                ],
                "Rating 17": [
                    0.0,
                    1.87159019661055e-05,
                    3.95722242557949e-05,
                    8.69165725070465e-05,
                    0.000168106781427563,
                    0.000217494959972562,
                    0.000290033986033748,
                    0.000901713255184851,
                    0.000691588104684599,
                    0.00189404044176493,
                    0.00365475028829948,
                    0.00776224274218435,
                    0.0137443891575907,
                    0.0211003970504821,
                    0.0400531090949325,
                    0.0701706854510973,
                    0.122183708838821,
                ],
            }
        )
        return mm_sample, n_series

    def test_matrix_weighted_bandwidth_proper_results(self):
        """Test to check the proper calculation of the lower and upper bandwidth of the
        migration matrix
        """
        mm_sample, n_series = self.get_mm_n_series_for_mwb()
        mm_sample = mm_sample.iloc[:17, :17]
        mwb_lower, mwb_upper = matrix_weighted_bandwidth(mm_sample, n_series)
        self.assertAlmostEquals(mwb_lower, 0.15511366)
        self.assertAlmostEquals(mwb_upper, 0.17983226)

    def test_matrix_weighted_bandwidth_not_square_dataframe(self):
        """Test to check whether ValueError is raised when not squared matrix delivered"""
        mm_sample, n_series = self.get_mm_n_series_for_mwb()
        mm_sample = mm_sample.iloc[:17, :13]
        with self.assertRaises(ValueError):
            matrix_weighted_bandwidth(mm_sample, n_series)

    def test_matrix_weighted_bandwidth_not_equal_lengths(self):
        """Test to check whether length of N_data is the same as the number of rows in
        mig_matrix
        """
        mm_sample, n_series = self.get_mm_n_series_for_mwb()
        mm_sample = mm_sample.iloc[:17, :17]
        n_series = n_series.iloc[
            :2,
        ]
        with self.assertRaises(ValueError):
            matrix_weighted_bandwidth(mm_sample, n_series)

    def test_matrix_weighted_bandwidth_negative_values(self):
        """Test whether no negative probability of transitions are delivered in mig_matrix"""
        mm_sample = pd.DataFrame({"a": [-1, 0, 10], "b": [0, 0.5, 0.5], "c": [1, 1, 1]})
        n_series = pd.Series([10, 23, 23])
        with self.assertRaises(ValueError):
            matrix_weighted_bandwidth(mm_sample, n_series)

    def test_matrix_weighted_bandwidth_gt_1_values(self):
        """Test to check whether there are no greater than 1 probability of transisitions in
        mig_matrix
        """
        mm_sample = pd.DataFrame({"a": [0.8, 0], "b": [1.5, 0.5]})
        n_series = pd.Series([10, 23])
        with self.assertRaises(ValueError):
            matrix_weighted_bandwidth(mm_sample, n_series)

    def test_matrix_weighted_bandwidth_type_error_rasied_when_not_pd_DataFrame(self):
        """Test to check whether mig_matrix is delivered as type of pd.DataFrame"""
        mm_sample = [1, 2]
        n_series = pd.Series([10, 23])
        with self.assertRaisesRegex(
            TypeError, "mig_matrix argument has to be a type of pd.DataFrame"
        ):
            matrix_weighted_bandwidth(mm_sample, n_series)

    def test_matrix_weighted_bandwidth_type_error_rasied_when_not_pd_Series(self):
        """Test to check whether N_data is delivered as type of pd.Series"""
        mm_sample = pd.DataFrame({"a": [0.8, 0], "b": [1.5, 0.5]})
        n_series = [1, 2]
        with self.assertRaisesRegex(
            TypeError, "N_data argument has to be type a of pd.Series"
        ):
            matrix_weighted_bandwidth(mm_sample, n_series)


class TestLikelihoodRatio(unittest.TestCase):
    """
    Test class for the 'crv.validation.stability.likelihood_ratio_test'
    function.
    """

    def test_lr_and_pvalues(self):
        """
        Test output values on an example from
        https://online.stat.psu.edu/stat504/node/220/

        p-value is example is reported as <0.0001.
        This condition is also tested.
        """

        result = likelihood_ratio_test(
            log_likelihood_unrestricted=5147.390 / -2,
            log_likelihood_restricted=5176.510 / -2,
            num_parameters_unrestricted=2,
            num_parameters_restricted=1,
        )

        expected_result = [29.1207, 1 - chi2.cdf(29.1207, 1)]

        p_value_threshold = 0.0001

        self.assertAlmostEqual(
            expected_result[0], round(result[0], 4), 2, f"lr value not equal"
        )

        self.assertAlmostEqual(expected_result[1], result[1], 2, f"p value not equal")

        self.assertTrue(result[1] < p_value_threshold)

    def test_lr_and_pvalues_r_example(self):
        """
        Test output values on the output of the example from
        https://www.rdocumentation.org/packages/lmtest/versions/0.9-37/topics/lrtest

        """

        result = likelihood_ratio_test(
            log_likelihood_unrestricted=-56.069,
            log_likelihood_restricted=-65.871,
            num_parameters_unrestricted=3,
            num_parameters_restricted=2,
        )

        expected_result = [19.605, 0.000009524]

        self.assertAlmostEqual(
            expected_result[0], round(result[0], 4), 2, f"lr value not equal"
        )

        self.assertAlmostEqual(expected_result[1], result[1], 8, f"p value not equal")

    def test_lr_incorrect_log_likelihood_magnitudes(self):
        """
        Test value error raising the logL value of the
        unrestricted model is lower than the logL of the
        restricted model.
        """
        self.assertRaises(
            ValueError,
            likelihood_ratio_test,
            **{
                "log_likelihood_unrestricted": 5176.510 / -2,
                "log_likelihood_restricted": 5147.390 / -2,
                "num_parameters_unrestricted": 2,
                "num_parameters_restricted": 1,
            },
        )

    def test_lr_incorrect_number_of_parameters_magnitudes(self):
        """
        Test value error raising when the number of parameters of the
        unrestricted model is lower than the number of parameters of the
        restricted model.
        """
        self.assertRaises(
            ValueError,
            likelihood_ratio_test,
            **{
                "log_likelihood_unrestricted": 5147.390 / -2,
                "log_likelihood_restricted": 5176.510 / -2,
                "num_parameters_unrestricted": 1,
                "num_parameters_restricted": 2,
            },
        )

    def test_lr_incorrect_number_of_parameters_type(self):
        """
        Test value error raising when the number of parameters is
        not of integer type.
        """
        self.assertRaises(
            ValueError,
            likelihood_ratio_test,
            **{
                "log_likelihood_unrestricted": 5147.390 / -2,
                "log_likelihood_restricted": 5176.510 / -2,
                "num_parameters_unrestricted": 5.6,
                "num_parameters_restricted": 2,
            },
        )


if __name__ == "__main__":
    unittest.main()
