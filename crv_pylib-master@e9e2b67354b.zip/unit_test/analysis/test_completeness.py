"""
# ============================================================================
# TEST_COMPLETENESS.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.DATA_ANALYSIS.COMPLETENESS.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.data_analysis.completeness' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Reinout Kool <G85538>
# ============================================================================
"""

import unittest
import numpy as np
import pandas as pd
from crv.analysis.completeness import pandas_missing_values


class TestPandasMissingValues(unittest.TestCase):
    """
    Unit test case for the 'pandas_missing_values' function.
    """

    @staticmethod
    def get_test_data():
        """
        Sets up the sample data for the unit tests.
        """

        data = {
            "g1": ["a", "a", "a", "a", "a", "b", "b", "c", "d", "e"],
            "g2": [
                "red",
                "red",
                "red",
                "blue",
                "blue",
                "blue",
                "blue",
                "blue",
                "red",
                "red",
            ],
            "x1": [1, 2, 1, 4, 5, 6, 7, 8, 9, 10],
            "x2": [np.nan, 2, np.nan, 4, 5, 6, 7, np.nan, 9, 10],
            "x3": [1, 2, 3, 4, 5, "Zero", 7, 8, "Zero", "Zero"],
            "x4": [1, np.nan, 3, 4, 5, "Zero", 7, 8, 9, 10],
            "x5": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        }

        df = pd.DataFrame(data, columns=["g1", "g2", "x1", "x2", "x3", "x4", "x5"])

        return df

    def test_pandas_missing_values_ValueError_1_no_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is not a
        pandas.DataFrame
        """
        # df is not a pandas.DataFrame
        df = "Not a pandas.DataFrame but string"

        # Input parameters
        missing_vals_def = ["NaN", "Zero"]
        col_names = None
        groupby_cols = []

        # assertRaises
        self.assertRaises(
            ValueError,
            pandas_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_pandas_missing_values_ValueError_2_empty_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is an empty
        pandas.DataFrame
        """
        # df is an empty pandas.DataFrame
        df = pd.DataFrame(columns=["x1", "x2", "x3", "x4", "x5", "g1", "g2"])

        # Input parameters
        missing_vals_def = ["NaN", "Zero"]
        col_names = None
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            pandas_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_pandas_missing_values_ValueError_3_no_list(self):
        """
        Test that a ValueError is raised if input parameter 'missing_vals_def'
        is not a list
        """
        # missing_vals_def is not a list
        missing_vals_def = "Not a list but string"

        # Input parameters
        df = self.get_test_data()
        col_names = None
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            pandas_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_pandas_missing_values_ValueError_5_no_str(self):
        """
        Test that a ValueError is raised if input parameter 'groupby_cols'
        is not a list
        """
        # first_groupby_col is a string instead of a list
        groupby_cols = "g1"

        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = ["NaN", "Zero"]

        # assertRaises
        self.assertRaises(
            ValueError,
            pandas_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_pandas_missing_values_ValueError_8__no_list(self):
        """
        Test that a ValueError is raised if input parameter 'col_names'
        is not a list
        """
        # missing_vals_def is not a list
        col_names = "Not a list but string"

        # Input parameters
        df = self.get_test_data()
        missing_vals_def = ["NaN", "Zero"]
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            pandas_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_pandas_missing_values_ValueError_9_empty_list(self):
        """
        Test that a ValueError is raised if input parameter 'col_names'
        is a empty list
        """
        # missing_vals_def is not a list
        col_names = []

        # Input parameters
        df = self.get_test_data()
        missing_vals_def = ["NaN", "Zero"]
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            pandas_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_pandas_missing_values_aggr_level_one_one_def(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with missing values definition is solely numpy.nan
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = []
        groupby_cols = None

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [0.0, 0.0],
            [0.0, 0.0],
            [0.0, 0.0],
            [3.0, 0.3],
            [0.0, 0.0],
            [1.0, 0.1],
            [0.0, 0.0],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "one definition. ",
            )

    def test_pandas_missing_values_aggr_level_one_one_def_cols(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with missing values definition is solely numpy.nan with a specific
        column selection
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = []
        groupby_cols = None

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [[3.0, 0.3], [0.0, 0.0], [1.0, 0.1]]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "one definition with specific columns",
            )

    def test_pandas_missing_values_aggr_level_one_multiple_def(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with multiple missing values definitions (numpy.nan and "Zero")
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [3.0, 0.3, 0.0, 0.0],
            [0.0, 0.0, 3.0, 0.3],
            [1.0, 0.1, 1.0, 0.1],
            [0.0, 0.0, 0.0, 0.0],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "multiple definitions.",
            )

    def test_pandas_missing_values_aggr_level_one_multiple_def_cols(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with multiple missing values definitions (numpy.nan and "Zero") and a
        specific column selection
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [3.0, 0.3, 0.0, 0.0],
            [0.0, 0.0, 3.0, 0.3],
            [1.0, 0.1, 1.0, 0.1],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "multiple definitions with specific column "
                "selection. ",
            )

    def test_pandas_missing_values_aggr_level_two_one_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the absolute values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "one definition, absolute values",
            )

    def test_pandas_missing_values_aggr_level_two_one_def_absolute_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the absolute values dataframe with a specific column
        selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.4, 0.0, 0.2],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "one definition, absolute values",
            )

    def test_pandas_missing_values_aggr_level_two_one_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the relative values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_relative"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_relative"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_relative"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "one definition, relative values",
            )

    def test_pandas_missing_values_aggr_level_two_one_def_relative_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the relative values dataframe with specific column
        selection
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.4, 0.0, 0.2],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_relative"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_relative"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_relative"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "one definition, relative values",
            )

    def test_pandas_missing_values_aggr_level_two_multiple_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the absolute values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 2.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 3.0, 1.0, 0.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.5, 0.5, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_absolute", "df_Zero_absolute"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', absolute values",
                )

    def test_pandas_missing_values_aggr_level_two_multiple_def_abs_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the absolute values dataframe with a specific
        column selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.4, 0.0, 0.2],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 1.0, 2.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 3.0, 1.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0],
                [0.0, 0.5, 0.5],
                [0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_absolute", "df_Zero_absolute"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', absolute "
                    f"values with a specific column "
                    f"selection.",
                )

    def test_pandas_missing_values_aggr_level_two_multiple_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the relative values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nanabsolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 2.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 3.0, 1.0, 0.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.5, 0.5, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_relative", "df_Zero_relative"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', relative values",
                )

    def test_pandas_missing_values_aggr_level_two_multiple_def_rel_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero")for the relative values dataframe with a specific
        column selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.4, 0.0, 0.2],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 1.0, 2.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 3.0, 1.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0],
                [0.0, 0.5, 0.5],
                [0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_relative", "df_Zero_relative"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', relative values",
                )

    def test_pandas_missing_values_aggr_level_three_one_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the absolute values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_NaN_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 3, "
                "one definition, absolute values",
            )

    def test_pandas_missing_values_aggr_level_three_one_def_abs_cols(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the absolute values dataframe with a specific
        column selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = []
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0],
                [0.6666666666666666, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 3, "
                "one definition, absolute values",
            )

    def test_pandas_missing_values_aggr_level_three_one_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the relative values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_relative"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_relative"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_relative"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 3, "
                "one definition, relative values",
            )

    def test_pandas_missing_values_aggr_level_three_one_def_rel_cols(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with missing values definition
        is numpy.nan for the relative values dataframe with a specific column
        selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = []
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0],
                [0.6666666666666666, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_relative"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_relative"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_relative"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 3, "
                "one definition, relative values",
            )

    def test_pandas_missing_values_aggr_level_three_multiple_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the absolute values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 1.0, 0.0, 2.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 3.0, 1.0, 0.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.5, 0.5, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_absolute", "df_Zero_absolute"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 3, "
                    f"definition '{definition}', absolute values",
                )

    def test_pandas_missing_values_aggr_level_three_multiple_def_abs_cols(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the absolute values dataframe with a
        specific column selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0],
                [0.6666666666666666, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 1.0, 2.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 3.0, 1.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.5, 0.5],
                [0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_absolute", "df_Zero_absolute"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 3, "
                    f"definition '{definition}', absolute values"
                    f" with a specific column selection.",
                )

    def test_pandas_missing_values_aggr_level_three_multiple_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the relative values dataframe
        """
        # Input parameters
        df = self.get_test_data()
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 1.0, 0.0, 2.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 3.0, 1.0, 0.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.5, 0.5, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_relative", "df_Zero_relative"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 3, "
                    f"definition '{definition}', relative values",
                )

    def test_pandas_missing_values_aggr_level_three_multiple_def_rel_cols(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan and "Zero") for the relative values dataframe with a specific
        column selection.
        """
        # Input parameters
        df = self.get_test_data()
        col_names = ["x2", "x3", "x4"]
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = pandas_missing_values(
            df=df,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [2.0, 0.0, 1.0, 3.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 1.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0],
                [0.6666666666666666, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 1.0, 2.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 1.0, 0.0, 1.0],
                [0.0, 3.0, 1.0, 4.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.5, 0.5],
                [0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_relative", "df_Zero_relative"]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 3, "
                    f"definition '{definition}', relative "
                    f"values with specific column selection.",
                )


if __name__ == "__main__":
    unittest.main()
