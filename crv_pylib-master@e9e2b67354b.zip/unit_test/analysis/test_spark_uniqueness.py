"""
# ============================================================================
# TEST_PYSPARK_UNIQUENESS.PY
# ----------------------------------------------------------------------------
# Description:
#   Unit testing for the functions in 'crv.validation.uniqueness.py' that
#   use the pypsark module.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# Notes:
#   Author: Reinout Kool <G85538>
# ============================================================================
"""

from typing import Tuple
import unittest
import numpy as np
import pandas as pd
import pyspark.sql.dataframe as psd
from crv.analysis.uniqueness import duplicates, _pandas_duplicates, _spark_duplicates
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, StringType

from unit_test.pyspark_test_class import PySparkTestCase


class TestSparkDuplicates(PySparkTestCase):
    """
    Unit test case for the '_spark_duplicates' function.
    """

    @staticmethod
    def get_test_data(self) -> Tuple[pd.DataFrame, psd.DataFrame]:
        """
        Sets up the sample data for the unit tests.
        """

        data = {
            "x1": [1, 2, 1, 2, 5, 6, 7, 8, 9, 10],
            "x2": [1, 2, 2, 2, 5, 6, 7, 8, 9, 10],
            "x3": [5, 2, 6, 2, 4, 8, 9, 4, 2, 10],
            "g1": ["a", "b", "b", "c", "b", "b", "b", "c", "c", "e"],
            "g2": [
                "red",
                "red",
                "blue",
                "blue",
                "blue",
                "red",
                "blue",
                "red",
                "blue",
                "red",
            ],
        }

        # Pandas and Spark dataframe
        df_pandas = pd.DataFrame(data, columns=["g1", "g2", "x1", "x2", "x3"])
        df_spark = self.spark.createDataFrame(df_pandas)

        return df_pandas, df_spark

    def test_spark_duplicates_ValueError_1_no_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is not a
        spark.DataFrame
        """
        # df is not a pandas.DataFrame
        df = "Not a spark.DataFrame but string"

        # Input parameters
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_sparkduplicates_ValueError_2_empty_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is an empty
        spark.DataFrame
        """
        # df is an empty spark.DataFrame
        columns = ["x1", "x2", "x3", "x4", "x5", "g1", "g2"]
        schema = StructType([StructField(c, StringType()) for c in columns])
        df = self.spark.createDataFrame(data=[], schema=schema)

        # Input parameters
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_ValueError_3_no_list(self):
        """
        Test that a ValueError is raised if input parameter 'groupby_cols'
        is not a list
        """
        # first_groupby_col is a string instead of a list
        groupby_cols = "g1"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_ValueError_4_no_list(self):
        """
        Test that a ValueError is raised if input parameter 'col_names'
        is not a list
        """
        # first_groupby_col is a string instead of a list
        col_names = "Str instead of list"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_ValueError_5_empty_list(self):
        """
        Test that a ValueError is raised if input parameter 'groupby'
        is a empty list
        """
        # missing_vals_def is not a list
        groupby_cols = []

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_ValueError_6_empty_list(self):
        """
        Test that a ValueError is raised if input parameter 'col_names'
        is a empty list
        """
        # missing_vals_def is not a list
        col_names = []

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_ValueError_7_wrong_value(self):
        """
        Test that a ValueError is raised if input parameter
        'single_or_combination' is an invalid value; i.e. not either of the
        options: 'single' or 'combination'.
        """
        # missing_vals_def is not a list
        single_or_combination = "Invalid"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_ValueError_8_wrong_value(self):
        """
        Test that a ValueError is raised if input parameter
        'mark_duplicates' is an invalid value; i.e. not either of the options:
        None, 'all', 'first', 'last'.
        """
        # missing_vals_def is not a list
        mark_duplicates = "Invalid"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "single"

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_duplicates,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_spark_duplicates_single_no_groupby_all(self):
        """
        Test that correct output is generated when identifying
        duplicates per column (single_or_combination = "single"
        without groupby and for all columns)
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal = dict_vals["df_duplicates_statistics"].values.tolist()

        # Validated values
        vals_validated = [
            ["g1", 8, 0.8],
            ["g2", 10, 1.0],
            ["x1", 4, 0.4],
            ["x2", 3, 0.3],
            ["x3", 5, 0.5],
        ]

        # Compare on row level
        for i in range(len(vals_cal)):
            vals_list_1 = vals_cal[i]
            vals_list_2 = vals_validated[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = None, "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = None",
            )

    def test_spark_duplicates_single_no_groupby_cols(self):
        """
        Test that correct output is generated when identifying
        duplicates per column (single_or_combination = "single"
        without groupby and for a selection of columns)
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal = dict_vals["df_duplicates_statistics"].values.tolist()

        # Validated values
        vals_validated = [["x1", 4, 0.4], ["x2", 3, 0.3]]

        # Compare on row level
        for i in range(len(vals_cal)):
            vals_list_1 = vals_cal[i]
            vals_list_2 = vals_validated[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = None, "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = None",
            )

    def test_spark_duplicates_single_groupby_all(self):
        """
        Test that correct output is generated when identifying
        duplicates per column (single_or_combination = "single"
        with groupby and for all columns)
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = ["g1"]
        single_or_combination = "single"
        mark_duplicates = None

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_abs = dict_vals["df_duplicates_absolute_statistics"].values.tolist()
        vals_cal_rel = dict_vals["df_duplicates_relative_statistics"].values.tolist()
        vals_calc = [vals_cal_abs, vals_cal_rel]

        # Validated values
        vals_validated_abs = [
            [1, 1, 0, 0],
            [5, 2, 2, 2],
            [3, 1, 1, 3],
            [1, 0, 0, 0],
            [10, 4, 3, 5],
        ]
        vals_validated_rel = [
            [0.1, 0.1, 0.0, 0.0],
            [0.5, 0.2, 0.2, 0.2],
            [0.3, 0.1, 0.1, 0.3],
            [0.1, 0.0, 0.0, 0.0],
            [1.0, 0.4, 0.3, 0.5],
        ]
        vals_validated = [vals_validated_abs, vals_validated_rel]

        # Compare on row level absolute
        for i in range(len(vals_calc)):
            for ii in range(len(vals_calc[i])):
                vals_list_1 = vals_calc[i][ii]
                vals_list_2 = vals_validated[i][ii]
                self.assertListEqual(
                    vals_list_1,
                    vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    "of duplicate values, "
                    "col_names = None, "
                    "groupby_cols = None "
                    "single_or_combination = 'single', "
                    "mark_duplicates = None",
                )

    def test_spark_duplicates_single_groupby_cols(self):
        """
        Test that correct output is generated when identifying
        duplicates per column (single_or_combination = "single"
        with groupby and for a selection of columns)
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = ["g1"]
        single_or_combination = "single"
        mark_duplicates = None

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_abs = dict_vals["df_duplicates_absolute_statistics"].values.tolist()
        vals_cal_rel = dict_vals["df_duplicates_relative_statistics"].values.tolist()
        vals_calc = [vals_cal_abs, vals_cal_rel]

        # Validated values
        vals_validated_abs = [[1, 0], [2, 2], [1, 1], [0, 0], [4, 3]]
        vals_validated_rel = [
            [0.1, 0.0],
            [0.2, 0.2],
            [0.1, 0.1],
            [0.0, 0.0],
            [0.4, 0.3],
        ]
        vals_validated = [vals_validated_abs, vals_validated_rel]

        # Compare on row level absolute
        for i in range(len(vals_calc)):
            for ii in range(len(vals_calc[i])):
                vals_list_1 = vals_calc[i][ii]
                vals_list_2 = vals_validated[i][ii]
                self.assertListEqual(
                    vals_list_1,
                    vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    "of duplicate values, "
                    "col_names = None, "
                    "groupby_cols = ['x1', 'x2'], "
                    "single_or_combination = 'single', "
                    "mark_duplicates = None",
                )

    def test_spark_duplicates_single_groupby_dup_marks_all(self):
        """
        Test that correct duplicates marks output is generated
        when identifying duplicates per column
        (single_or_combination = "single",
        mark_duplicates = "all")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = "all"

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicate_marks"].toPandas().values.tolist()

        # Validated values
        vals_validated_marks = [
            [False, True, True, False, False],
            [True, True, True, True, True],
            [True, True, True, True, False],
            [True, True, True, True, True],
            [True, True, False, False, True],
            [True, True, False, False, False],
            [True, True, False, False, False],
            [True, True, False, False, True],
            [True, True, False, False, True],
            [False, True, False, False, False],
        ]

        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = None, "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = 'first'",
            )

    def test_spark_duplicates_single_groupby_dup_marks_first(self):
        """
        Test that correct duplicates marks output is generated
        when identifying duplicates per column
        (single_or_combination = "single",
        mark_duplicates = "first")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = "first"

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicate_marks"].toPandas().values.tolist()

        # Validated values
        vals_validated_marks = [
            [False, True, True, False, False],
            [True, True, True, True, True],
            [True, True, False, True, False],
            [True, True, False, False, True],
            [True, True, False, False, True],
            [True, True, False, False, False],
            [False, True, False, False, False],
            [True, True, False, False, False],
            [False, False, False, False, False],
            [False, False, False, False, False],
        ]

        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = None, "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = 'first'",
            )

    def test_spark_duplicates_single_groupby_dup_marks_last(self):
        """
        Test that correct duplicates marks output is generated
        when identifying duplicates per column
        (single_or_combination = "single",
        mark_duplicates = "last")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = "last"

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicate_marks"].toPandas().values.tolist()

        # Validated values
        vals_validated_marks = [
            [False, False, False, False, False],
            [False, True, False, False, False],
            [True, False, True, True, False],
            [False, True, True, True, True],
            [True, True, False, False, False],
            [True, True, False, False, False],
            [True, True, False, False, False],
            [True, True, False, False, True],
            [True, True, False, False, True],
            [False, True, False, False, False],
        ]
        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = None, "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = 'last'",
            )

    def test_spark_duplicates_combination_no_groupby_cols(self):
        """
        Test that correct output is generated when identifying
        duplicates per column (single_or_combination = "combination"
        with groupby and for a selection of columns)
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = None
        single_or_combination = "combination"
        mark_duplicates = None

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicates_statistics"].values.tolist()

        # Validated values
        vals_validated_marks = [["x1 & x2", 2, 0.2]]
        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = ['x1', 'x2'], "
                "groupby_cols = None, "
                "single_or_combination = 'combination', "
                "mark_duplicates = 'last'",
            )

    def test_spark_duplicates_combination_groupby_cols(self):
        """
        Test that correct output is generated when identifying
        duplicates per column (single_or_combination = "combination"
        with groupby and for a selection of columns)
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = ["g1"]
        single_or_combination = "combination"
        mark_duplicates = None

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicates_statistics"].values.tolist()

        # Validated values
        vals_validated_marks = [
            [0.0, 0.0],
            [1.0, 0.1],
            [1.0, 0.1],
            [0.0, 0.0],
            [2.0, 0.2],
        ]
        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = ['x1', 'x2'], "
                "groupby_cols = ['g1'], "
                "single_or_combination = 'combination', "
                "mark_duplicates = 'last'",
            )

    def test_spark_duplicates_combination_groupby_dup_marks_all(self):
        """
        Test that correct duplicates marks output is generated
        when identifying duplicates per column
        (single_or_combination = "single",
        mark_duplicates = "all")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = None
        single_or_combination = "combination"
        mark_duplicates = "all"

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicate_marks"].toPandas().values.tolist()

        # Validated values
        vals_validated_marks = [
            [False],
            [True],
            [False],
            [True],
            [False],
            [False],
            [False],
            [False],
            [False],
            [False],
        ]
        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = ['x1', 'x2'], "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = 'all'",
            )

    def test_spark_duplicates_combination_groupby_dup_marks_first(self):
        """
        Test that correct duplicates marks output is generated
        when identifying duplicates per column
        (single_or_combination = "single",
        mark_duplicates = "first")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = None
        single_or_combination = "combination"
        mark_duplicates = "first"

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicate_marks"].toPandas().values.tolist()

        # Validated values
        vals_validated_marks = [
            [False],
            [True],
            [False],
            [False],
            [False],
            [False],
            [False],
            [False],
            [False],
            [False],
        ]
        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = ['x1', 'x2'], "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = 'first'",
            )

    def test_pandas_duplicates_combination_groupby_dup_marks_last(self):
        """
        Test that correct duplicates marks output is generated
        when identifying duplicates per column
        (single_or_combination = "single",
        mark_duplicates = "last")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x1", "x2"]
        groupby_cols = None
        single_or_combination = "combination"
        mark_duplicates = "last"

        # Calculated values
        dict_vals = _spark_duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_cal_marks = dict_vals["df_duplicate_marks"].toPandas().values.tolist()

        # Validated values
        vals_validated_marks = [
            [False],
            [False],
            [False],
            [True],
            [False],
            [False],
            [False],
            [False],
            [False],
            [False],
        ]
        # Compare on row level absolute
        for i in range(len(vals_cal_marks)):
            vals_list_1 = vals_cal_marks[i]
            vals_list_2 = vals_validated_marks[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of duplicate values, "
                "col_names = ['x1', 'x2'], "
                "groupby_cols = None, "
                "single_or_combination = 'single', "
                "mark_duplicates = 'last'",
            )


class TestDuplicates(PySparkTestCase):
    """
    Unit test case for the '_spark_duplicates' function.
    """

    @staticmethod
    def get_test_data(self):
        """
        Sets up the sample data for the unit tests.
        """

        data = {
            "x1": [1, 2, 1, 2, 5, 6, 7, 8, 9, 10],
            "x2": [1, 2, 2, 2, 5, 6, 7, 8, 9, 10],
            "x3": [5, 2, 6, 2, 4, 8, 9, 4, 2, 10],
            "x4": [1, 2, 3, 2, 4, 6, 7, 7, 9, 10],
            "g1": ["a", "b", "b", "c", "b", "b", "b", "c", "c", "e"],
            "g2": [
                "red",
                "red",
                "blue",
                "blue",
                "blue",
                "red",
                "blue",
                "red",
                "blue",
                "red",
            ],
        }

        # Pandas and Spark dataframe
        df_pandas = pd.DataFrame(data, columns=["g1", "g2", "x1", "x2", "x3", "x4"])
        df_spark = self.spark.createDataFrame(df_pandas)

        return df_pandas, df_spark

    def test_duplicates_TypeError(self):
        """
        Test that a TypeError is raised if not a Pandas or Spark dataframe is
        given as data input
        """
        # df is not a pandas.DataFrame
        df = "Not a DataFrame but string"

        # Input parameters
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # assertRaises
        self.assertRaises(
            TypeError,
            duplicates,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "single_or_combination": single_or_combination,
                "mark_duplicates": mark_duplicates,
            },
        )

    def test_duplicates_aggr_level_one_single_pandas_spark_comparison(self):
        """
        Test that a duplicates are consistently identified at level one
        aggregation between pandas and spark function
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "single"
        mark_duplicates = None

        # Calculated values
        dict_spark = duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        dict_pandas = duplicates(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_spark = dict_spark["df_duplicates_statistics"].values.tolist()
        vals_pandas = dict_pandas["df_duplicates_statistics"].values.tolist()

        # Compare on row level
        for i in range(len(vals_spark)):
            vals_list_1 = vals_spark[i]
            vals_list_2 = vals_pandas[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of spark and pandas function for "
                "missing values aggregation level 1.",
            )

    def test_duplicates_aggr_level_two_single_spark_pandas_comparison(self):
        """ "
        Test that a duplicates are consistently identified at level two
        aggregation (groupby variable 'g1') between spark and pandas functions
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = ["g1"]
        single_or_combination = "single"
        mark_duplicates = None

        # Calculated values
        dict_spark = duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        dict_pandas = duplicates(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_spark = {
            "abs_stats": dict_spark[
                "df_duplicates_absolute_statistics"
            ].values.tolist(),
            "rel_stats": dict_spark[
                "df_duplicates_relative_statistics"
            ].values.tolist(),
        }
        vals_pandas = {
            "abs_stats": dict_pandas[
                "df_duplicates_absolute_statistics"
            ].values.tolist(),
            "rel_stats": dict_pandas[
                "df_duplicates_relative_statistics"
            ].values.tolist(),
        }

        # Compare on row level
        for item in ["abs_stats", "rel_stats"]:
            for i in range(len(vals_spark[item])):
                vals_list_1 = vals_spark[item][i]
                vals_list_2 = vals_pandas[item][i]
                self.assertListEqual(
                    vals_list_1,
                    vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{item}', between "
                    f"spark and pandas function",
                )

    def test_duplicates_aggr_level_one_combination_pandas_spark_comparison(self):
        """
        Test that a duplicates are consistently identified at level one
        aggregation between pandas and spark function
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None
        single_or_combination = "combination"
        mark_duplicates = None

        # Calculated values
        dict_spark = duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        dict_pandas = duplicates(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_spark = dict_spark["df_duplicates_statistics"].values.tolist()
        vals_pandas = dict_pandas["df_duplicates_statistics"].values.tolist()

        # Compare on row level
        for i in range(len(vals_spark)):
            vals_list_1 = vals_spark[i]
            vals_list_2 = vals_pandas[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of spark and pandas function for "
                "missing values aggregation level 1.",
            )

    def test_duplicates_aggr_level_two_combination_spark_pandas_comparison(self):
        """ "
        Test that a duplicates are consistently identified at level two
        aggregation (groupby variable 'g1') between spark and pandas functions
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = ["g1"]
        single_or_combination = "combination"
        mark_duplicates = None

        # Calculated values
        dict_spark = duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        dict_pandas = duplicates(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_spark = dict_spark["df_duplicates_statistics"].values.tolist()
        vals_pandas = dict_pandas["df_duplicates_statistics"].values.tolist()

        # Compare on row level
        for i in range(len(vals_spark)):
            vals_list_1 = vals_spark[i]
            vals_list_2 = vals_pandas[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of spark and pandas function for "
                "missing values aggregation level 1.",
            )

    def test_duplicates_aggr_level_two_combination_pandas_spark_comparison_colnames(
        self,
    ):
        """
        Test that a duplicates are consistently identified at level two
        aggregation (groupby variable 'g1') between spark and pandas functions
        with col_names specified
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x4"]
        groupby_cols = ["g1"]
        single_or_combination = "combination"
        mark_duplicates = None

        # Calculated values
        dict_spark = duplicates(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        dict_pandas = duplicates(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            single_or_combination=single_or_combination,
            mark_duplicates=mark_duplicates,
        )

        vals_spark = dict_spark["df_duplicates_statistics"].values.tolist()
        vals_pandas = dict_pandas["df_duplicates_statistics"].values.tolist()

        # Compare on row level
        for i in range(len(vals_spark)):
            vals_list_1 = vals_spark[i]
            vals_list_2 = vals_pandas[i]
            self.assertListEqual(
                vals_list_1,
                vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of spark and pandas function for "
                "missing values aggregation level 1.",
            )


if __name__ == "__main__":
    unittest.main()
