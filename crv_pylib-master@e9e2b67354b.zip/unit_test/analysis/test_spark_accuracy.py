"""
# ============================================================================
# TEST_SPARK_ACCURACY.PY
# ----------------------------------------------------------------------------
# Description:
#   Unit testing for the functions in 'crv.analysis.accuracy.py' that
#   use the pyspark module.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# Notes:
#   Author: Camilla Trinderup <G80944>
# ============================================================================
"""

import sys

sys.path.append("../crv_pylib")
import unittest
import numpy as np
import pandas as pd
from crv.analysis.accuracy import (
    descriptive_statistics,
    _spark_descriptive_statistics,
    _blank_as_null,
    _quantile_func,
    _compute_quantiles,
    _stat_values_numeric_groupby,
    _compute_numeric_stats,
    _stat_values_categorical,
    _compute_categorical_stats,
    _compute_bool_stats,
    _stat_values_boolean,
    _stat_values_dates_groupby,
    _compute_date_stats,
)

import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField
from pyspark.sql.types import (
    IntegerType,
    StringType,
    DoubleType,
    DateType,
    BooleanType,
    FloatType,
    LongType,
)
import datetime

from unit_test.pyspark_test_class import PySparkTestCase


class TestSparkAccuracy(PySparkTestCase):
    """
    Unit test case for the '_spark_descriptive_statistics' function.
    """

    def get_table_for_descr_stat(self):
        df_pandas = pd.DataFrame(
            {
                "Brand": [
                    "Honda Civic",
                    "Ford Focus",
                    "",
                    "Toyota Corolla",
                    "Tesla S",
                    "Tesla S",
                ],
                "Country": pd.Series(
                    ["US", "Japan", "Japan", "Japan", "", "US"], dtype="category"
                ),
                "Price": pd.array(
                    [22000, 27000, 25000, np.nan, 35000, 40000], dtype="float64"
                ),
                "Year": ["2014", "2014", "2015", "2014", "2015", "2015"],
                "YearMonth": [
                    "",
                    pd.Period("2020-01"),
                    pd.Period("2020-01"),
                    pd.Period("2014-08"),
                    pd.Period("2017-02"),
                    pd.Period("2018-11"),
                ],
                "Crashed": pd.array([0, 0, 4, 1, 0, 0], dtype="int64"),
                "Electric": pd.array(
                    [False, True, False, False, False, True], dtype="bool"
                ),
                "Tax benefit": pd.array(
                    [False, True, False, False, True, True], dtype="bool"
                ),
                "First registration": [
                    np.datetime64("2000-01-01"),
                    np.datetime64("2010-11-02"),
                    np.datetime64("2019-05-14"),
                    np.datetime64("2009-08-21"),
                    np.datetime64("2018-05-21"),
                    np.datetime64("2018-05-21"),
                ],
                "Last EU control": [
                    np.nan,
                    np.datetime64("2019-11"),
                    np.datetime64("2018-08"),
                    np.datetime64("2018-08"),
                    np.datetime64("2019-02"),
                    np.datetime64("2018-05"),
                ],
                "Another day": [
                    pd.Timestamp(year=2016, month=2, day=2),
                    np.nan,
                    pd.Timestamp(year=2020, month=1, day=3),
                    pd.Timestamp(year=2014, month=12, day=11),
                    pd.Timestamp(year=2007, month=10, day=1),
                    pd.Timestamp(year=2018, month=2, day=3),
                ],
                "Last license number": pd.array([8, 5, 8, 3, 5, 7], dtype="int64"),
                "License plate": pd.array([10804, 84610, 74920, 48271, 42685, 47392]),
            }
        )

        dic = {
            "Brand": "str",
            "Country": "str",
            "Price": "float",
            "Year": "str",
            "YearMonth": "str",
            "Crashed": "float",
            "Electric": "bool",
            "Tax benefit": "bool",
            "First registration": "datetime64",
            "Last EU control": "datetime64",
            "Another day": "datetime64",
            "Last license number": "int64",
            "License plate": "float",
        }

        df_pandas = df_pandas.astype(dic)

        df_spark = self.spark.createDataFrame(df_pandas)
        df_spark = df_spark.withColumn(
            "First registration", df_spark["First registration"].cast(DateType())
        )
        df_spark = df_spark.withColumn(
            "Last EU control", df_spark["Last EU control"].cast(DateType())
        )
        df_spark = df_spark.withColumn(
            "Another day", df_spark["Another day"].cast(DateType())
        )
        df_spark = df_spark.withColumn(
            "Last license number", df_spark["Last license number"].cast(IntegerType())
        )
        df_spark = df_spark.withColumn(
            "License plate", df_spark["License plate"].cast(FloatType())
        )

        return df_pandas, df_spark

    def test_spark_descriptive_stats_empty_df_Value_Error(self):
        """
        Test that a ValueError is raised if input parameter 'df' is an empty df.
        """
        # df is not a pandas.DataFrame
        schema = StructType(
            [
                StructField("firstname", StringType(), True),
                StructField("middlename", StringType(), True),
                StructField("lastname", StringType(), True),
            ]
        )

        df_spark = self.spark.createDataFrame(
            self.spark.sparkContext.emptyRDD(), schema
        )

        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_descriptive_statistics,
            **{
                "df_spark": df_spark,
                "spark_session": self.spark,
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": None,
            }
        )

    def test_spark_descriptive_stats_not_spark_session_Type_Error(self):
        """
        Test that a TypeError is raised if input parameter 'spark_session'
        is not of type SparkSession.
        """
        # df is not a pandas.DataFrame
        schema = StructType(
            [
                StructField("firstname", StringType(), True),
                StructField("middlename", StringType(), True),
                StructField("lastname", StringType(), True),
            ]
        )

        df_spark = self.spark.createDataFrame(
            self.spark.sparkContext.emptyRDD(), schema
        )

        # assertRaises
        self.assertRaises(
            TypeError,
            _spark_descriptive_statistics,
            **{
                "df_spark": df_spark,
                "spark_session": [3, 5, 6],
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": None,
            }
        )

    def test_spark_descriptive_statistics_selected_columns_missing(self):
        """
        Test that a ValueError is raised if any of the requested column names for descriptive
        statistics is missing from the column names in the input table.

        ValueError: if any element of 'selected_columns' is not among the
                    column names of the input table.
        """

        df_pandas, df_spark = self.get_table_for_descr_stat()
        self.assertRaises(
            ValueError,
            _spark_descriptive_statistics,
            **{
                "df_spark": df_spark,
                "selected_columns": ["Country", "Another_Country"],
                "quantiles": None,
                "groupby_vars": None,
                "spark_session": self.spark,
            }
        )

    def test_spark_descriptive_statistics_groupby_vars_missing(self):
        """
        Test that a ValueError is raised if any of the requested groupby column names for descriptive
        statistics is missing from the column names in the input table.

        ValueError: if any element of 'selected_columns' is not among the
                    column names of the input table.
        """

        df_pandas, df_spark = self.get_table_for_descr_stat()
        self.assertRaises(
            ValueError,
            _spark_descriptive_statistics,
            **{
                "df_spark": df_spark,
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": ["Another Country"],
                "spark_session": self.spark,
            }
        )

    def test_spark_descriptive_statistics_warning_msg_columns_of_nulls(self):
        """
        Test if a Warning message is given when 'float16' data type is present in the input table.

        """
        df_pandas, df_spark = self.get_table_for_descr_stat()
        df_spark = df_spark.withColumn("new_column", f.lit(None).cast(StringType()))

        self.assertWarns(
            Warning,
            _spark_descriptive_statistics,
            **{
                "df_spark": df_spark,
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": None,
                "spark_session": self.spark,
            }
        )

    def test_spark_descriptive_statistics_compare_to_manual_calculations(self):

        """
        Test that '_spark_descriptive_statistics' results match those computed manually.

        """

        # One variable for each data type (except 'timedelta'):
        df_pandas, df_spark = self.get_table_for_descr_stat()

        calculated = _spark_descriptive_statistics(
            df_spark=df_spark,
            selected_columns=[
                "Brand",
                "Country",
                "Price",
                "YearMonth",
                "Crashed",
                "Electric",
                "First registration",
            ],
            quantiles=[0.20, 0.25, 0.5],
            groupby_vars=None,
            spark_session=self.spark,
        )

        manual = pd.DataFrame(
            {
                "Price": pd.array(
                    [
                        5,
                        29800,
                        7463.243263,
                        22000,
                        40000,
                        149000,
                        24400,
                        25000,
                        27000,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Crashed": pd.array(
                    [
                        6,
                        0.833333333,
                        1.602082,
                        0,
                        4,
                        5,
                        0,
                        0,
                        0,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Electric": pd.array(
                    [
                        6,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        2,
                        False,
                        4,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Brand": pd.array(
                    [
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "Tesla S",
                        2.0,
                        4.0,
                    ],
                    dtype="object",
                ),
                "Country": pd.array(
                    [
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "Japan",
                        3,
                        2,
                    ],
                    dtype="object",
                ),
                "YearMonth": pd.array(
                    [
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "2020-01",
                        2.0,
                        4.0,
                    ],
                    dtype="object",
                ),
                "First registration": pd.array(
                    [
                        6,
                        np.nan,
                        np.nan,
                        datetime.date(2000, 1, 1),
                        datetime.date(2019, 5, 14),
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        datetime.date(2018, 5, 21),
                        2,
                        5.0,
                    ],
                    dtype="object",
                ),
            },
            index=[
                "count",
                "mean",
                "std",
                "min",
                "max",
                "sum",
                "20%",
                "25%",
                "50%",
                "count of trues",
                "top",
                "freq",
                "unique",
            ],
        )

        pd.testing.assert_frame_equal(calculated, manual)

    def test_spark_descriptive_statistics_compare_to_manual_calculations_with_groupby(
        self,
    ):
        """
        Test that '_spark_descriptive_statistics' results match those computed manually when
        groupby_vars are specified.

        """
        # One variable for each data type (except 'timedelta'):
        df_pandas, df_spark = self.get_table_for_descr_stat()

        calculated = _spark_descriptive_statistics(
            df_spark=df_spark,
            selected_columns=["Price", "Electric", "Brand", "First registration"],
            groupby_vars=["Year"],
            quantiles=[0.25, 0.5, 0.75],
            spark_session=self.spark,
        )

        # Define parameters for manually computed results
        stat_order = [
            "count",
            "mean",
            "std",
            "min",
            "25%",
            "50%",
            "75%",
            "max",
            "sum",
            "count of trues",
            "top",
            "freq",
            "unique",
        ]
        n = len(stat_order)
        stat_order2 = stat_order + stat_order
        year = ["2014"] * n + ["2015"] * n
        price = [
            2,
            24500,
            3535.533906,
            22000,
            23250,
            24500,
            25750,
            27000,
            49000,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            3,
            33333.333333,
            7637.626158,
            25000,
            30000,
            35000,
            37500,
            40000,
            100000,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
        ]
        electric = [
            3,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            1,
            False,
            2,
            np.nan,
            3,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            1,
            False,
            2,
            np.nan,
        ]
        brand = [
            3,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            "Honda Civic",
            1,
            3,
            2,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            np.nan,
            "Tesla S",
            2,
            1,
        ]
        first_reg = [
            3,
            np.nan,
            np.nan,
            datetime.date(2000, 1, 1),
            np.nan,
            np.nan,
            np.nan,
            datetime.date(2010, 11, 2),
            np.nan,
            np.nan,
            datetime.date(2009, 8, 21),
            1,
            3,
            3,
            np.nan,
            np.nan,
            datetime.date(2018, 5, 21),
            np.nan,
            np.nan,
            np.nan,
            datetime.date(2019, 5, 14),
            np.nan,
            np.nan,
            datetime.date(2018, 5, 21),
            2,
            2,
        ]

        manual_groupby = pd.DataFrame(
            {
                "Year": pd.array(year, dtype="object"),
                "stat": pd.array(stat_order2, dtype="category"),
                "Price": pd.array(price, dtype="object"),
                "Electric": pd.array(electric, dtype="object"),
                "Brand": pd.array(brand, dtype="object"),
                "First registration": pd.array(first_reg, dtype="object"),
            }
        )
        manual_groupby["stat"] = pd.Categorical(manual_groupby["stat"], stat_order)

        pd.testing.assert_frame_equal(calculated, manual_groupby)


class TestInternalSparkAccuracy(PySparkTestCase):
    """
    Unit test case for the internal functions of the '_spark_descriptive_statistics' function.
    """

    def get_table_for_descr_stat(self):
        df_pandas = pd.DataFrame(
            {
                "Brand": [
                    "Honda Civic",
                    "Ford Focus",
                    "",
                    "Toyota Corolla",
                    "Tesla S",
                    "Tesla S",
                ],
                "Country": pd.Series(
                    ["US", "Japan", "Japan", "Japan", "", "US"], dtype="category"
                ),
                "Price": pd.array(
                    [22000, 27000, 25000, np.nan, 35000, 40000], dtype="float64"
                ),
                "Year": ["2014", "2014", "2015", "2014", "2015", "2015"],
                "YearMonth": [
                    "",
                    pd.Period("2020-01"),
                    pd.Period("2020-01"),
                    pd.Period("2014-08"),
                    pd.Period("2017-02"),
                    pd.Period("2018-11"),
                ],
                "Crashed": pd.array([0, 0, 4, 1, 0, 0], dtype="int64"),
                "Electric": pd.array(
                    [False, True, False, False, False, True], dtype="bool"
                ),
                "Tax benefit": pd.array(
                    [False, True, False, False, True, True], dtype="bool"
                ),
                "First registration": [
                    np.datetime64("2000-01-01"),
                    np.datetime64("2010-11-02"),
                    np.datetime64("2019-05-14"),
                    np.datetime64("2009-08-21"),
                    np.datetime64("2018-05-21"),
                    np.datetime64("2018-05-21"),
                ],
                "Last EU control": [
                    np.nan,
                    np.datetime64("2019-11"),
                    np.datetime64("2018-08"),
                    np.datetime64("2018-08"),
                    np.datetime64("2019-02"),
                    np.datetime64("2018-05"),
                ],
                "Another day": [
                    pd.Timestamp(year=2016, month=2, day=2),
                    np.nan,
                    pd.Timestamp(year=2020, month=1, day=3),
                    pd.Timestamp(year=2014, month=12, day=11),
                    pd.Timestamp(year=2007, month=10, day=1),
                    pd.Timestamp(year=2018, month=2, day=3),
                ],
                "Last license number": pd.array([8, 5, 8, 3, 5, 7], dtype="int64"),
                "License plate": pd.array([10804, 84610, 74920, 48271, 42685, 47392]),
            }
        )

        dic = {
            "Brand": "str",
            "Country": "str",
            "Price": "float",
            "Year": "str",
            "YearMonth": "str",
            "Crashed": "float",
            "Electric": "bool",
            "Tax benefit": "bool",
            "First registration": "datetime64",
            "Last EU control": "datetime64",
            "Another day": "datetime64",
            "Last license number": "int64",
            "License plate": "float",
        }

        df_pandas = df_pandas.astype(dic)

        df_spark = self.spark.createDataFrame(df_pandas)
        df_spark = df_spark.withColumn(
            "First registration", df_spark["First registration"].cast(DateType())
        )
        df_spark = df_spark.withColumn(
            "Last EU control", df_spark["Last EU control"].cast(DateType())
        )
        df_spark = df_spark.withColumn(
            "Another day", df_spark["Another day"].cast(DateType())
        )
        df_spark = df_spark.withColumn(
            "Last license number", df_spark["Last license number"].cast(IntegerType())
        )
        df_spark = df_spark.withColumn(
            "License plate", df_spark["License plate"].cast(FloatType())
        )

        return df_pandas, df_spark

    def test_spark_descriptive_statistics_blank_as_null(self):
        """
        Test if subfunction _blank_as_null returns nulls where it should.
        """
        df_pandas, df_spark = self.get_table_for_descr_stat()

        test_column = (
            df_spark.withColumn("test_column", _blank_as_null("Country"))
            .select("test_column")
            .toPandas()
        )

        test_manual = pd.DataFrame(
            {
                "test_column": pd.array(
                    ["US", "Japan", "Japan", "Japan", None, "US"], dtype="object"
                )
            }
        )

        pd.testing.assert_frame_equal(test_column, test_manual)

    def test_spark_descriptive_statistics_quantile_func(self):
        """
        Test if computation of quantile, in this case median is computed correctly
        by _quantile_func.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Set parameters for test.
        name = "Price"
        quantiles = [0.5]

        # Compute median.
        df_quant = df_spark.agg(
            _quantile_func(name, quantiles, self.spark).alias("median")
        ).toPandas()
        median_calculated = df_quant.iloc[0, 0][0]
        median_manual = 27000
        self.assertEqual(median_calculated, median_manual)

    def test_spark_descriptive_statistics_compute_quantiles(self):
        """
        Test if _compute_quantiles returns correct results.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Set parameters for test.
        groupby_vars = None
        float_cols = ["Price", "License plate"]
        quantiles = [0.2, 0.5, 0.9]
        column_names = ["20%", "50%", "90%"]

        df_quantiles = _compute_quantiles(
            df_spark, groupby_vars, float_cols, column_names, quantiles, self.spark
        )

        df_manual = pd.DataFrame(
            {
                "Price": pd.array([24400, 27000, 38000], dtype="object"),
                "License plate": pd.array([42685, 47831.5, 79765.0], dtype="object"),
            },
            index=column_names,
        )

        pd.testing.assert_frame_equal(df_quantiles, df_manual)

    def test_spark_descriptive_statistics_stat_values_numeric_groupby(self):
        """
        Test if _stat_values_numeric_groupby returns correct result.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Define parameters for test case.
        name = "Price"
        groupby_vars = ["Year"]
        df_stats_column = _stat_values_numeric_groupby(df_spark, groupby_vars, name)
        df_stats_column.reset_index(drop=True, inplace=True)

        # Define manual comparison.
        stat_order = ["count", "mean", "std", "min", "max", "sum"]
        df_manual = pd.DataFrame(
            {
                "Year": pd.array(["2014"] * 6 + ["2015"] * 6, dtype="object"),
                "stat": pd.array(stat_order + stat_order, dtype="object"),
                name: pd.array(
                    [
                        2,
                        24500,
                        3535.533906,
                        22000,
                        27000,
                        49000,
                        3,
                        33333.3333333,
                        7637.626158,
                        25000,
                        40000,
                        100000,
                    ],
                    dtype="float64",
                ),
            }
        )

        pd.testing.assert_frame_equal(df_stats_column, df_manual)

    def test_spark_descriptive_statistics_compute_numeric_stats(self):
        """
        Test that _compute_numeric_stats returns correct results.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Define parameters for test case.
        cols = ["Price", "License plate"]
        groupby_vars = ["Year"]
        quantiles = None

        # Compute test case.
        df_numeric_stats, column_names = _compute_numeric_stats(
            df_spark, self.spark, quantiles, groupby_vars, cols
        )
        df_numeric_stats.reset_index(inplace=True)

        # Define manual data frame for comparison.
        df_manual = pd.DataFrame(
            {
                "Year": pd.array(
                    ["2014"] * 6 + ["2015"] * 6 + ["2014"] * 3 + ["2015"] * 3,
                    dtype="object",
                ),
                "stat": pd.array(
                    [
                        "count",
                        "mean",
                        "std",
                        "min",
                        "max",
                        "sum",
                        "count",
                        "mean",
                        "std",
                        "min",
                        "max",
                        "sum",
                        "25%",
                        "50%",
                        "75%",
                        "25%",
                        "50%",
                        "75%",
                    ],
                    dtype="object",
                ),
                "Price": pd.array(
                    [
                        2,
                        24500,
                        3535.533906,
                        22000,
                        27000,
                        49000,
                        3,
                        33333.3333333,
                        7637.626158,
                        25000,
                        40000,
                        100000,
                        23250.0,
                        24500.0,
                        25750.0,
                        30000.0,
                        35000.0,
                        37500.0,
                    ],
                    dtype="object",
                ),
                "License plate": pd.array(
                    [
                        3.0,
                        47895.0,
                        36904.436603,
                        10804.0,
                        84610.0,
                        143685.0,
                        3.0,
                        54999.0,
                        17411.882236,
                        42685.0,
                        74920.0,
                        164997.0,
                        29537.5,
                        48271.0,
                        66440.5,
                        45038.5,
                        47392.0,
                        61156.0,
                    ],
                    dtype="object",
                ),
            }
        )

        pd.testing.assert_frame_equal(df_numeric_stats, df_manual)

    def test_spark_descriptive_statistics_stat_values_categorical(self):
        """
        Test if _stat_values_categorical returns expected results.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Compute the result of _stat_values_categorical
        df_stats_column = _stat_values_categorical(
            df_spark, groupby_vars=None, name="Brand"
        )

        # Define manual comparison.
        df_manual = pd.DataFrame(
            {
                "top": pd.array(["Tesla S"], dtype="object"),
                "freq": pd.array([2], dtype="int64"),
                "count": pd.array([5], dtype="int64"),
                "unique": pd.array([4], dtype="int64"),
            },
            index=["Brand"],
        )

        pd.testing.assert_frame_equal(df_stats_column, df_manual)

    def test_spark_descriptive_statistics_compute_categorical_stats(self):
        """
        Test if _compute_categorical_stats returns expected results.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Define columns
        cols = ["Brand", "Country"]

        # Compute statistics of categorical variables.
        df_cat_stats = _compute_categorical_stats(
            df_spark, groupby_vars=None, cat_cols=cols
        )

        # Define manual test case.
        df_manual = pd.DataFrame(
            {
                "top": pd.array(["Tesla S", "Japan"], dtype="object"),
                "freq": pd.array([2, 3], dtype="int64"),
                "count": pd.array([5, 5], dtype="int64"),
                "unique": pd.array([4, 2], dtype="int64"),
            },
            index=cols,
        )

        pd.testing.assert_frame_equal(df_cat_stats, df_manual)

    def test_spark_descriptive_statistics_stat_values_boolean(self):
        """
        Test if _stat_values_boolean returns expected results.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Compute the result of _stat_values_categorical
        df_stats_column = _stat_values_boolean(
            df_spark, groupby_vars=None, name="Electric"
        )

        # Define manual comparison.
        df_manual = pd.DataFrame(
            {
                "count of trues": pd.array([2], dtype="int64"),
                "count": pd.array([6], dtype="int64"),
                "top": pd.array([False], dtype="bool"),
                "freq": pd.array([4], dtype="int64"),
            },
            index=["Electric"],
        )

        pd.testing.assert_frame_equal(df_stats_column, df_manual)

    def test_compute_bool_stats(self):
        """
        Test if _compute_bool_stats returns expected results.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        # Compute boolean statistics
        cols = ["Electric", "Tax Benefit"]
        df_bool_stats = _compute_bool_stats(df_spark, groupby_vars=None, bool_cols=cols)

        # Define manual results
        df_manual = pd.DataFrame(
            {
                "count of trues": pd.array([2, 3], dtype="int64"),
                "count": pd.array([6, 6], dtype="int64"),
                "top": pd.array([False, True], dtype="bool"),
                "freq": pd.array([4, 3], dtype="int64"),
            },
            index=cols,
        )

        pd.testing.assert_frame_equal(df_bool_stats, df_manual)

    def test_stat_values_dates_groupby(self):
        """
        Test if _stat_values_dates_groupby returns correct result.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        groupby_vars = ["Year"]
        name = "First registration"

        # Compute date statistics.
        df_calculated = _stat_values_dates_groupby(df_spark, groupby_vars, name)

        # Define dataframe for testing.
        df_manual = pd.DataFrame(
            {
                "Year": pd.array(["2014", "2015"] * 3, dtype="object"),
                "stat": pd.array(
                    ["top", "top", "freq", "freq", "unique", "unique"], dtype="object"
                ),
                name: pd.array(
                    [
                        datetime.date(2009, 8, 21),
                        datetime.date(2018, 5, 21),
                        1,
                        2,
                        3,
                        2,
                    ],
                    dtype="object",
                ),
            }
        )

        pd.testing.assert_frame_equal(df_calculated, df_manual)

    def test_compute_date_stats(self):
        """
        Test if function returns correct results when compared to manual computations.
        """
        # Define test data frames.
        df_pandas, df_spark = self.get_table_for_descr_stat()

        groupby_vars = None
        cols = ["First registration", "Another day"]

        # Compute date statistics.
        df_calculated = _compute_date_stats(df_spark, groupby_vars, cols)

        # Define dataframe for testing.
        df_manual = pd.DataFrame(
            {
                "min": pd.array(
                    [datetime.date(2000, 1, 1), datetime.date(2007, 10, 1)],
                    dtype="object",
                ),
                "max": pd.array(
                    [datetime.date(2019, 5, 14), datetime.date(2020, 1, 3)],
                    dtype="object",
                ),
                "unique": pd.array([5, 5], dtype="int64"),
                "count": pd.array([6, 5], dtype="int64"),
                "top": pd.array(
                    [datetime.date(2018, 5, 21), datetime.date(2020, 1, 3)],
                    dtype="object",
                ),
                "freq": pd.array([2, 1], dtype="object"),
            },
            index=cols,
        )

        pd.testing.assert_frame_equal(df_calculated, df_manual)


if __name__ == "__main__":
    unittest.main()
