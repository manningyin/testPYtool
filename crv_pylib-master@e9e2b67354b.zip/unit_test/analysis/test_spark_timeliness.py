"""
# ============================================================================
# TEST_SPARK_TIMELINESS.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.DATA_ANALYSIS.TIMELINESS.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.data_analysis.timeliness' module that uses pyspark.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# Notes:
#     Author: Diana Lucatero <G85544>
# ============================================================================
"""

import unittest
import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal
from datetime import date, datetime
from crv.analysis.timeliness import (
    _pandas_outdated_values,
    _spark_outdated_values,
    outdated_values,
)

from unit_test.pyspark_test_class import PySparkTestCase
import pyspark.sql.functions as f
from pyspark.sql.types import StringType


class TestSparkOutdatedValues(PySparkTestCase):
    """
    Unit test case for the 'pandas_outdated_values' function.
    """

    def get_test_data(self):
        """
        Sets up the sample data for the unit tests.
        """
        data = {
            "statement_ID": [f"A00{i}" for i in range(6)],
            "date": [
                "2000-01-01",
                "2010-11-02",
                "2019-05-14",
                "2009-08-21",
                "2011-02-06",
                "2018-05-21",
            ],
        }
        df = pd.DataFrame(data, columns=["statement_ID", "date"])
        dic = {"statement_ID": "str", "date": "str"}
        df = df.astype(dic)
        df_spark = self.spark.createDataFrame(df)

        return df_spark

    def test_spark_outdated_ValueError_no_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is not a
        pyspark.sql.DataFrame
        """
        df0 = "3"
        # assertRaises
        self.assertRaises(
            TypeError, outdated_values, **{"df": df0, "date_col_name": "date0"}
        )

    def test_spark_outdated_ValueError_wrong_date_format(self):
        """
        Test that a ValueError is raised if input parameter 'date_to_compare' is not a
        string with format YYYY-MM-DD.
        """
        df = self.get_test_data()
        df = df.withColumn("date0", f.to_date(df.date))
        # assertRaises
        self.assertRaises(
            ValueError,
            outdated_values,
            **{"df": df, "date_col_name": "date0", "date_to_compare": "2010-29-24"},
        )

    def test_spark_outdated_ValueError_wrong_date_type(self):
        """
        Test that a ValueError is raised if input parameter 'date_to_compare' is not a
        string, np.datetime64 or datetime.
        """
        df = self.get_test_data()
        df = df.withColumn("date0", f.to_date(df.date))
        # assertRaises
        self.assertRaises(
            ValueError,
            outdated_values,
            **{"df": df, "date_col_name": "date0", "date_to_compare": 34},
        )

    def test_spark_outdated_ValueError_datecol_not_in_df(self):
        """
        Test that a ValueError is raised if input parameter 'date_to_compare' is not a
        string, np.datetime64 or datetime.
        """
        df = self.get_test_data()
        df = df.withColumn("date0", f.to_date(df.date))
        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_outdated_values,
            **{
                "df": df,
                "date_col_name": "not_date",
                "date_to_compare": "2012-04-12",
                "max_age_allowed": 24,
            },
        )

    def test_spark_outdated_ValueError_wrong_date_type(self):
        """
        Test that a ValueError is raised if date column 'date_col_name' is not of
        type date.
        """
        df = self.get_test_data()
        # assertRaises
        self.assertRaises(
            ValueError,
            _spark_outdated_values,
            **{
                "df": df,
                "date_col_name": "date0",
                "date_to_compare": "2012-04-12",
                "max_age_allowed": 24,
            },
        )

    def test_spark_outdated_result_manual_example(self):
        """
        Test that the resulting dataframe and absolute/relative number of
        outdated values match that of a manual example.
        """
        df = self.get_test_data()
        df = df.withColumn("date0", f.to_date(df.date))

        # Run _pandas_outdated_values
        (
            df_with_age,
            outdated_num_records,
            per_outdated_records,
        ) = _spark_outdated_values(df, "date0", "2018-09-30", max_age_allowed=30)
        df_with_age = df_with_age.toPandas()
        df_with_age["date_diff"] = df_with_age["date_diff"].astype(np.int32)
        df_with_age["outdated_flag"] = df_with_age["outdated_flag"].astype(np.int32)

        # Manual result
        result_df = pd.concat(
            [
                df.toPandas(),
                pd.DataFrame(
                    {
                        "date_diff": pd.array(
                            [225.0, 95.0, -7.0, 109.0, 92.0, 4.0], dtype=np.int32
                        ),
                        "outdated_flag": pd.array([1, 1, 0, 1, 1, 0], dtype=np.int32),
                    }
                ),
            ],
            axis=1,
        )
        outdated_num_records_result = 4
        per_outdated_records_result = (4 / 6) * 100

        # Perform comparison
        assert_frame_equal(df_with_age, result_df)
        self.assertEqual(outdated_num_records, outdated_num_records_result)
        self.assertEqual(per_outdated_records_result, per_outdated_records)


if __name__ == "__main__":
    unittest.main()
