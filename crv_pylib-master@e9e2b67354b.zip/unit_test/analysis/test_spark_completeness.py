"""
# ============================================================================
# TEST_PYSPARK_COMPLETENESS.PY
# ----------------------------------------------------------------------------
# Description:
#   Unit testing for the functions in 'crv.validation.completeness.py' that
#   use the pypsark module.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# Notes:
#   Author: Reinout Kool <G85538>
# ============================================================================
"""

import unittest
import numpy as np
import pandas as pd
from crv.analysis.completeness import (
    pandas_missing_values,
    spark_missing_values,
    missing_values,
)
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, StringType

from unit_test.pyspark_test_class import PySparkTestCase


class TestSparkMissingValues(PySparkTestCase):
    """
    Unit test case for the 'spark_missing_values' function.
    """

    @staticmethod
    def get_test_data(self):
        """
        Sets up the sample data for the unit tests.
        """

        data = {
            "x1": [1, 2, 1, 4, 5, 6, 7, 8, 9, 10],
            "x2": [np.nan, 2, np.nan, 4, 5, 6, 7, np.nan, 9, 10],
            "x3": ["Na", "Na", "Na", "Na", "Na", "Zero", "Na", "Na", "Zero", "Zero"],
            "x4": [1, np.nan, 3, 4, 5, 6, 7, 8, 9, 10],
            "x5": [1, 2, 3, 4, 5, 3, 7, 3, 9, 3],
            "g1": ["a", "a", "a", "a", "a", "b", "b", "c", "d", "e"],
            "g2": [
                "red",
                "red",
                "red",
                "blue",
                "blue",
                "blue",
                "blue",
                "red",
                "blue",
                "red",
            ],
        }

        # Pandas dataframe
        df_pandas = pd.DataFrame(
            data, columns=["g1", "g2", "x1", "x2", "x3", "x4", "x5"]
        )

        # Spark dataframe
        df_spark = self.spark.createDataFrame(df_pandas)

        # Create null empty values in spark dataframe
        df_spark = df_spark.withColumn(
            "x5", f.when(f.col("x5") != 3, f.col("x5")).otherwise(f.lit(None))
        )

        return df_pandas, df_spark

    def test_spark_missing_values_ValueError_1_no_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is not a
        spark.DataFrame
        """
        # df is not a pandas.DataFrame
        df = "Not a spark.DataFrame but string"

        # Input parameters
        missing_vals_def = ["Zero"]
        col_names = None
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_ValueError_2_empty_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is an empty
        spark.DataFrame
        """
        # df is an empty spark.DataFrame
        columns = ["x1", "x2", "x3", "x4", "x5", "g1", "g2"]
        schema = StructType([StructField(c, StringType()) for c in columns])
        df_spark = self.spark.createDataFrame(data=[], schema=schema)

        # Input parameters
        missing_vals_def = ["Zero"]
        col_names = None
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_missing_values,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_ValueError_3_no_list(self):
        """
        Test that a ValueError is raised if input parameter 'missing_vals_def'
        is not a list
        """
        # missing_vals_def is not a list
        missing_vals_def = "Not a list but string"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_missing_values,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_ValueError_5_no_list(self):
        """
        Test that a ValueError is raised if input parameter 'groupby_cols'
        is not a list
        """
        # first_groupby_col is a string instead of a list
        groupby_cols = "g1"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_missing_values,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_ValueError_8_no_list(self):
        """
        Test that a ValueError is raised if input parameter 'col_names'
        is not a list
        """
        # missing_vals_def is not a list
        col_names = "Not a list but string"

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_missing_values,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_ValueError_9_empty_list(self):
        """
        Test that a ValueError is raised if input parameter 'col_names'
        is a empty list
        """
        # missing_vals_def is not a list
        col_names = []

        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_missing_values,
            **{
                "df": df_spark,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_aggr_level_one_null_na_def(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with missing values definition is [], implying the
        function searches for np.nan and null values
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = []
        groupby_cols = None

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [3.0, 0.3, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [1.0, 0.1, 0.0, 0.0],
            [0.0, 0.0, 4.0, 0.4],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "np.nan and null definition. ",
            )

    def test_spark_missing_values_aggr_level_one_one_def_cols(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with missing values definition is [] (np.nan and null)
        with a specific column selection
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x3", "x5"]
        missing_vals_def = []
        groupby_cols = None

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [3.0, 0.3, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 4.0, 0.4],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "one definition with specific columns",
            )

    def test_spark_missing_values_aggr_level_one_multiple_def(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with multiple missing values definitions (np.nan, null
        and "Zero")
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [3.0, 0.3, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 3.0, 0.3],
            [1.0, 0.1, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 4.0, 0.4, 0.0, 0.0],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "multiple definitions.",
            )

    def test_spark_missing_values_aggr_level_one_multiple_def_cols(self):
        """
        Test that a missing values are correctly identified at level one
        aggregation with multiple missing values definitions and a
        specific column selection
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x3", "x5"]
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        miss_vals_cal = dict_miss_vals["df_missing_values"].values.tolist()

        # Validated values
        miss_vals_val = [
            [3.0, 0.3, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 3.0, 0.3],
            [0.0, 0.0, 4.0, 0.4, 0.0, 0.0],
        ]

        # Compare on row level
        for i in range(len(miss_vals_cal)):
            miss_vals_list_1 = miss_vals_cal[i]
            miss_vals_list_2 = miss_vals_val[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 1, "
                "multiple definitions with specific column "
                "selection. ",
            )

    def test_spark_missing_values_aggr_level_two_null_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is [] (null) for the absolute values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.2],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_null_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_null_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_null_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "null definition, absolute values",
            )

    def test_spark_missing_values_aggr_level_two_nan_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is np.nan for the absolute values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "np.nan definition, absolute values",
            )

    def test_spark_missing_values_aggr_level_two_nan_def_absolute_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is np.nan for the absolute values dataframe with a specific
        column selection.
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x3", "x5"]
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_NaN_relative": dict_miss_vals["df_numpy_nan_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [2.0, 0.0, 0.0, 2.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 0.0, 3.0],
            ],
            "df_numpy_nan_relative": [
                [0.4, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "nan definition, absolute values",
            )

    def test_spark_missing_values_aggr_level_two_null_def_absolute_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is null for the absolute values dataframe with a specific
        column selection.
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x3", "x5"]
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_null_absolute": [
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.2],
                [0.0, 0.0, 0.5],
                [0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_null_absolute"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_null_absolute"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_null_absolute"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "null definition, absolute values",
            )

    def test_spark_missing_values_aggr_level_two_nan_def_relative_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is np.nan for the relative values dataframe with a specific
        column selection.
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x3", "x5"]
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [2.0, 0.0, 0.0, 2.0],
                [0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [3.0, 0.0, 0.0, 3.0],
            ],
            "df_numpy_nan_relative": [
                [0.4, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_numpy_nan_relative"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_numpy_nan_relative"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_numpy_nan_relative"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "nan definition, relative values",
            )

    def test_spark_missing_values_aggr_level_two_null_def_relative_cols(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with missing values definition
        is null for the relative values dataframe with a specific
        column selection.
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = ["x2", "x3", "x5"]
        missing_vals_def = []
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_null_absolute": [
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.2],
                [0.0, 0.0, 0.5],
                [0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0],
            ],
        }

        # Compare on row level
        for i in range(len(dict_miss_vals_calc["df_null_relative"])):
            miss_vals_list_1 = dict_miss_vals_calc["df_null_relative"][i]
            miss_vals_list_2 = dict_miss_vals_val["df_null_relative"][i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of missing values aggregation level 2, "
                "null definition, absolute values",
            )

    def test_spark_missing_values_aggr_level_two_multiple_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with multiple missing values
        definitions (numpy.nan, null and "Zero") for the absolute values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.2],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 3.0, 0.0, 0.0, 3.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.5, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in [
            "df_numpy_nan_absolute",
            "df_null_absolute",
            "df_Zero_absolute",
        ]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', absolute values",
                )

    def test_pandas_missing_values_aggr_level_two_multiple_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level two
        aggregation (groupby variable 'g1' with multiple missing values
        definitions for the relative values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.4, 0.0, 0.2, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.2],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 3.0, 0.0, 0.0, 3.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.5, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in [
            "df_numpy_nan_relative",
            "df_null_relative",
            "df_Zero_relative",
        ]:
            for ii in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][ii]
                miss_vals_list_2 = dict_miss_vals_val[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', relative values",
                )

    def test_spark_missing_values_aggr_level_three_one_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation groupby variable 'g1' with missing values definition
        is np.nan and null for the absolute values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0],
            ],
        }

        # Compare on row level
        # Compare on row level
        for definition in ["df_numpy_nan_absolute", "df_null_absolute"]:
            for i in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][i]
                miss_vals_list_2 = dict_miss_vals_val[definition][i]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    "of missing values aggregation level 3, "
                    "one definition, absolute values",
                )

    def test_spark_missing_values_aggr_level_three_one_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation (groupby variable 'g1' with missing values definition
        is NaN for the absolute values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = []
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0],
            ],
        }

        # Compare on row level
        for definition in ["df_numpy_nan_relative", "df_null_relative"]:
            for i in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][i]
                miss_vals_list_2 = dict_miss_vals_val[definition][i]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    "of missing values aggregation level 3, "
                    "one definition, absolute values",
                )

    def test_spark_missing_values_aggr_level_three_multiple_def_absolute(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation groupby variable 'g1' with missing values definition
        is np.nan and null for the multiple values dataframe
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 3.0, 0.0, 0.0, 3.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.5, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in [
            "df_numpy_nan_absolute",
            "df_null_absolute",
            "df_Zero_absolute",
        ]:
            for i in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][i]
                miss_vals_list_2 = dict_miss_vals_val[definition][i]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    "of missing values aggregation level 3, "
                    "one definition, absolute values",
                )

    def test_spark_missing_values_aggr_level_three_multiple_def_relative(self):
        """ "
        Test that a missing values are correctly identified at level three
        aggregation groupby variable 'g1' with missing values definition
        is np.nan and null for the multiple values dataframe - relative
        values.
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_vals = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_vals_calc = {
            "df_numpy_nan_absolute": dict_miss_vals[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_vals[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_null_absolute": dict_miss_vals["df_null_absolute"].values.tolist(),
            "df_null_relative": dict_miss_vals["df_null_relative"].values.tolist(),
            "df_Zero_absolute": dict_miss_vals["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_vals["df_Zero_relative"].values.tolist(),
        }

        # Validated values
        dict_miss_vals_val = {
            "df_numpy_nan_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 2.0, 0.0, 1.0, 0.0, 3.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 3.0, 0.0, 1.0, 0.0, 4.0],
            ],
            "df_numpy_nan_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.6666666666666666, 0.0, 0.3333333333333333, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            "df_null_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 4.0, 4.0],
            ],
            "df_null_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.3333333333333333],
                [0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 1.0],
            ],
            "df_Zero_absolute": [
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 3.0, 0.0, 0.0, 3.0],
            ],
            "df_Zero_relative": [
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.5, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0, 0.0],
            ],
        }

        # Compare on row level
        for definition in [
            "df_numpy_nan_relative",
            "df_null_relative",
            "df_Zero_relative",
        ]:
            for i in range(len(dict_miss_vals_calc[definition])):
                miss_vals_list_1 = dict_miss_vals_calc[definition][i]
                miss_vals_list_2 = dict_miss_vals_val[definition][i]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{i}' is not equal in the comparison "
                    "of missing values aggregation level 3, "
                    "one definition, absolute values",
                )


class TestMissingValues(PySparkTestCase):
    """
    Unit test case for the super function missing_values function.
    """

    @staticmethod
    def get_test_data(self):
        """
        Sets up the sample data for the unit tests.
        """

        data = {
            "x1": [1, 2, 1, 4, 5, 6, 7, 8, 9, 10],
            "x2": [np.nan, 2, np.nan, 4, 5, 6, 7, np.nan, 9, 10],
            "x3": ["Na", "Na", "Na", "Na", "Na", "Zero", "Na", "Na", "Zero", "Zero"],
            "x4": [1, np.nan, 3, 4, 5, 6, 7, 8, 9, 10],
            "x5": [1, 2, 3, 4, 5, 3, 7, 3, 9, 3],
            "g1": ["a", "a", "a", "a", "a", "b", "b", "c", "d", "e"],
            "g2": [
                "red",
                "red",
                "red",
                "blue",
                "blue",
                "blue",
                "blue",
                "red",
                "blue",
                "red",
            ],
        }

        # Pandas dataframe
        df_pandas = pd.DataFrame(
            data, columns=["g1", "g2", "x1", "x2", "x3", "x4", "x5"]
        )

        # Spark dataframe
        df_spark = self.spark.createDataFrame(df_pandas)

        # Create null empty values in spark dataframe
        df_spark = df_spark.withColumn(
            "x5", f.when(f.col("x5") != 3, f.col("x5")).otherwise(f.lit(None))
        )

        return df_pandas, df_spark

    def test_missing_values_TypeError(self):
        """
        Test that a TypeError is raised if not a Pandas or Spark dataframe is
        given as data input
        """
        df = "String_instead_of_data_frame"
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # ValueError
        self.assertRaises(
            TypeError,
            missing_values,
            **{
                "df": df,
                "col_names": col_names,
                "groupby_cols": groupby_cols,
                "missing_vals_def": missing_vals_def,
            },
        )

    def test_spark_missing_values_aggr_level_one_pandas_spark_comparison(self):
        """
        Test that a missing values are consistently identified at level one
        aggregation with multiple missing values definitions (np.nan, null
        and "Zero") between pandas and spark function
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = None

        # Calculated values
        dict_miss_spark = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_pandas = pandas_missing_values(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        dict_miss_spark["df_missing_values"].drop(
            columns=["null_absolute", "null_relative"], inplace=True
        )

        miss_vals_spark = dict_miss_spark["df_missing_values"].values.tolist()
        miss_vals_pandas = dict_miss_pandas["df_missing_values"].values.tolist()

        # Compare on row level
        for i in range(len(miss_vals_spark)):
            miss_vals_list_1 = miss_vals_spark[i]
            miss_vals_list_2 = miss_vals_pandas[i]
            self.assertListEqual(
                miss_vals_list_1,
                miss_vals_list_2,
                msg=f"Row '{i}' is not equal in the comparison "
                "of spark and pandas function for "
                "missing values aggregation level 1.",
            )

    def test_missing_values_aggr_level_two_multiple_def_spark_pandas_comparison(self):
        """ "
        Test that a missing values are consistently identified at level two
        aggregation (groupby variable 'g1') with multiple missing values
        definitions between spark and pandas functions
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1"]

        # Calculated values
        dict_miss_spark = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )
        dict_miss_pandas = pandas_missing_values(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        val_miss_spark = {
            "df_numpy_nan_absolute": dict_miss_spark[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_spark[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_spark["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_spark["df_Zero_relative"].values.tolist(),
        }

        val_miss_pandas = {
            "df_numpy_nan_absolute": dict_miss_pandas[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_pandas[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_pandas["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_pandas["df_Zero_relative"].values.tolist(),
        }

        # Compare on row level
        for definition in [
            "df_numpy_nan_absolute",
            "df_numpy_nan_relative",
            "df_Zero_absolute",
            "df_Zero_relative",
        ]:
            for ii in range(len(val_miss_spark[definition])):
                miss_vals_list_1 = val_miss_spark[definition][ii]
                miss_vals_list_2 = val_miss_pandas[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 2, "
                    f"definition '{definition}', between "
                    f"spark and pandas function",
                )

    def test_missing_values_aggr_level_three_multiple_def_spark_pandas_comparison(self):
        """ "
        Test that a missing values are consistently identified at level three
        aggregation (groupby variable 'g1' and 'g2') with multiple missing
        values definitions between spark and pandas functions
        """
        # Input parameters
        df_pandas, df_spark = self.get_test_data(self)
        col_names = None
        missing_vals_def = ["Zero"]
        groupby_cols = ["g1", "g2"]

        # Calculated values
        dict_miss_spark = spark_missing_values(
            df=df_spark,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )
        dict_miss_pandas = pandas_missing_values(
            df=df_pandas,
            col_names=col_names,
            groupby_cols=groupby_cols,
            missing_vals_def=missing_vals_def,
        )

        val_miss_spark = {
            "df_numpy_nan_absolute": dict_miss_spark[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_spark[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_spark["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_spark["df_Zero_relative"].values.tolist(),
        }

        val_miss_pandas = {
            "df_numpy_nan_absolute": dict_miss_pandas[
                "df_numpy_nan_absolute"
            ].values.tolist(),
            "df_numpy_nan_relative": dict_miss_pandas[
                "df_numpy_nan_relative"
            ].values.tolist(),
            "df_Zero_absolute": dict_miss_pandas["df_Zero_absolute"].values.tolist(),
            "df_Zero_relative": dict_miss_pandas["df_Zero_relative"].values.tolist(),
        }

        # Compare on row level
        for definition in [
            "df_numpy_nan_absolute",
            "df_numpy_nan_relative",
            "df_Zero_absolute",
            "df_Zero_relative",
        ]:
            for ii in range(len(val_miss_spark[definition])):
                miss_vals_list_1 = val_miss_spark[definition][ii]
                miss_vals_list_2 = val_miss_pandas[definition][ii]
                self.assertListEqual(
                    miss_vals_list_1,
                    miss_vals_list_2,
                    msg=f"Row '{ii}' is not equal in the comparison "
                    f"of missing values aggregation level 3, "
                    f"definition '{definition}', between "
                    f"spark and pandas function",
                )


if __name__ == "__main__":
    unittest.main()
