"""
# ============================================================================
# TEST_ACCURACY.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.ANALYSIS.ACCURACY.PY
#
# This module is intended to contain and execute test cases for
# function '_pandas_descriptive_statistics' in file 
# 'crv.analysis.accuracy'.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Mark Rubtsov <AC30171>
# ============================================================================
"""

import sys

sys.path.append("../crv_pylib")
import unittest
import numpy as np
import pandas as pd
import random
import warnings
from scipy.stats import norm, chi2, ttest_rel, ttest_ind
from sklearn.metrics import roc_auc_score
from crv.validation.summary import adf_summary
from crv.analysis.accuracy import descriptive_statistics, _pandas_descriptive_statistics
from crv.utils.dataframe_helper import rating_cats


class TestPandasDescriptiveStatistics(unittest.TestCase):
    """
    Unit test cases for the _pandas_descriptive_statistics function.
    """

    @staticmethod
    def get_table_for_descr_stat():
        df = pd.DataFrame(
            {
                "Brand": [
                    "Tesla S",
                    "Ford Focus",
                    "Toyota Corolla",
                    "Toyota Corolla",
                    "Tesla S",
                    "Tesla S",
                ],
                "Country": pd.Series(
                    ["US", "Japan", "Japan", "Japan", np.nan, "US"], dtype="category"
                ),
                "Price": pd.array(
                    [22000, 27000, 25000, np.nan, 35000, 40000], dtype="float64"
                ),
                "Mileage": pd.array(
                    [12700, 7000, 25000, 29000, 3500, 4870], dtype="float16"
                ),
                "Year": [
                    pd.Period("2014"),
                    pd.Period("2014"),
                    pd.Period("2015"),
                    pd.Period("2014"),
                    pd.Period("2017"),
                    pd.Period("2018"),
                ],
                "YearMonth": [
                    np.nan,
                    pd.Period("2014-08"),
                    pd.Period("2020-01"),
                    pd.Period("2014-08"),
                    pd.Period("2017-02"),
                    pd.Period("2018-11"),
                ],
                "Crashed": pd.array([0, 0, 4, 1, 0, 0], dtype="int64"),
                "Electric": pd.array(
                    [True, False, False, False, False, True], dtype="bool"
                ),
                "Tax benefit": pd.array(
                    [False, True, False, False, np.nan, True], dtype="boolean"
                ),
                "First registration": [
                    np.datetime64("2000-01-01"),
                    np.datetime64("2019-05-14"),
                    np.datetime64("2019-05-14"),
                    np.datetime64("2019-05-14"),
                    np.datetime64("2018-05-21"),
                    np.datetime64("2000-01-01"),
                ],
                "Last EU control": [
                    np.nan,
                    np.datetime64("2019-11"),
                    np.datetime64("2018-08"),
                    np.datetime64("2018-08"),
                    np.datetime64("2019-02"),
                    np.datetime64("2018-05"),
                ],
                "Another day": [
                    pd.Timestamp(year=2016, month=2, day=2),
                    np.nan,
                    pd.Timestamp(year=2020, month=1, day=3),
                    pd.Timestamp(year=2014, month=12, day=11),
                    pd.Timestamp(year=2007, month=10, day=1),
                    pd.Timestamp(year=2018, month=2, day=3),
                ],
            }
        )

        df["Time delta"] = df["Last EU control"] - df["First registration"]

        return df

    def test_descriptive_stats_not_pd_psd_df_Type_Error(self):
        """
        Test that a TypeError is raised input df
        is not pandas.DataFrame or pyspark.sql.DataFrame.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()
        df_pandas = df.to_dict()

        # assertRaises
        self.assertRaises(
            TypeError,
            descriptive_statistics,
            **{
                "df_original": df_pandas,
                "selected_columns": ["Country", "Year"],
                "quantiles": [0.3, 0.4],
            }
        )

    def test_descriptive_stats_selected_column_not_list(self):
        """
        Test that a ValueError is raised of input paramter selected_columns
        is not a list.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{"df_original": df, "selected_columns": df}
        )

    def test_descriptive_stats_not_string_colname_Value_Error(self):
        """
        Test that a ValueError is raised if input parameter 'selected_columns'
        contains a name that is not a string.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{"df_original": df, "selected_columns": ["Country", "Year", 3]}
        )

    def test_descriptive_stats_selected_column_not_in_df_Value_Error(self):
        """
        Test that a ValueError is raised if input parameter 'selected_columns'
        contains a name that is not on the df.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{"df_original": df, "selected_columns": ["Country", "Year", "my_col"]}
        )

    def test_descriptive_stats_quantiles_not_list_Value_Error(self):
        """
        Test that a ValueError is raised of input parameter 'quantiles'
        is not of type list.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError, descriptive_statistics, **{"df_original": df, "quantiles": df}
        )

    def test_descriptive_stats_quantiles_not_numeric_Value_Error(self):
        """
        Test that a ValueError is raised if input parameter 'quantiles'
        contains value that is not numeric.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{
                "df_original": df,
                "selected_columns": ["Country", "Year"],
                "quantiles": [0.3, "3"],
            }
        )

    def test_descriptive_stats_quantiles_not_in_range_Value_Error(self):
        """
        Test that a ValueError is raised if input parameter 'quantiles'
        is not in range (0,1).
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{
                "df_original": df,
                "selected_columns": ["Country", "Year"],
                "quantiles": [0.3, 1.7],
            }
        )

    def test_descriptive_stats_groupbyvars_not_list(self):
        """
        Test that a ValueError is raised of input parameter groupby_vars
        is not a list.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{
                "df_original": df,
                "selected_columns": ["Year", "Country"],
                "groupby_vars": df,
            }
        )

    def test_descriptive_stats_not_string_groupbyname_Value_Error(self):
        """
        Test that a ValueError is raised if input parameter 'groupby_var'
        contains a name that is not a string.
        """
        # df is not a pandas
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{"df_original": df, "groupby_vars": ["Country", "Year", 3]}
        )

    def test_descriptive_stats_selectedcol_groupby_commoncol_Value_error(self):
        """
        Test that a ValueError is raised of input parameters 'selected_columns'
        and 'groupby_vars' contain common variable names.
        """
        # df is not a pandas.DataFrame
        df = self.get_table_for_descr_stat()

        # assertRaises
        self.assertRaises(
            ValueError,
            descriptive_statistics,
            **{
                "df_original": df,
                "groupby_vars": ["Country", "Year"],
                "selected_columns": ["Country", "Brand", "Electric"],
            }
        )

    def test_pandas_descriptive_statistics_input_df_empty(self):

        """
        Test that a ValueError is raised if the input table is empty.

        ValueError: if 'df_original' is empty.
        """
        self.assertRaises(
            ValueError,
            _pandas_descriptive_statistics,
            **{
                "df_original": pd.DataFrame(),
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": None,
            }
        )

    def test_pandas_descriptive_statistics_selected_columns_missing(self):

        """
        Test that a ValueError is raised if any of the requested column names for descriptive
        statistics is missing from the column names in the input table.

        ValueError: if any element of 'selected_columns' is not among the
                    column names of the input table.
        """

        df_test = self.get_table_for_descr_stat()
        self.assertRaises(
            ValueError,
            _pandas_descriptive_statistics,
            **{
                "df_original": df_test,
                "selected_columns": ["Country", "Another_Country"],
                "quantiles": None,
                "groupby_vars": None,
            }
        )

    def test_pandas_descriptive_statistics_groupby_vars_missing(self):

        """
        Test that a ValueError is raised if any of the requested column names for groupby
        variables is missing from the column names in the input table.

        ValueError: if any element of 'groupby_vars' is not among the
                    column names of the input table.
        """
        df_test = self.get_table_for_descr_stat()
        self.assertRaises(
            ValueError,
            _pandas_descriptive_statistics,
            **{
                "df_original": df_test,
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": ["Country", "Another_Country"],
            }
        )

    def test_pandas_descriptive_statistics_compare_to_manual_calculations(self):

        """
        Test that '_pandas_descriptive_statistics' results match those computed manually.

        """
        df_test = self.get_table_for_descr_stat()

        # One variable for each data type (except 'timedelta'):
        calculated = _pandas_descriptive_statistics(
            df_original=df_test,
            selected_columns=[
                "Brand",
                "Country",
                "Price",
                "YearMonth",
                "Crashed",
                "Electric",
                "First registration",
            ],
            quantiles=[0.20, 0.25, 0.5],
            groupby_vars=None,
        )

        manual = pd.DataFrame(
            {
                "Statistics": pd.array(
                    [
                        "count",
                        "mean",
                        "std",
                        "min",
                        "20%",
                        "25%",
                        "50%",
                        "max",
                        "sum",
                        "top",
                        "freq",
                        "count of trues",
                        "unique",
                    ],
                    dtype="object",
                ),
                "Price": pd.array(
                    [
                        5,
                        29800,
                        7463.243263,
                        22000,
                        24400,
                        25000,
                        27000,
                        40000,
                        149000,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Crashed": pd.array(
                    [
                        6,
                        0.833333333,
                        1.602082,
                        0,
                        0,
                        0,
                        0,
                        4,
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Electric": pd.array(
                    [
                        6,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        False,
                        4,
                        2,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Brand": pd.array(
                    [
                        6,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "Tesla S",
                        3,
                        np.nan,
                        3,
                    ],
                    dtype="object",
                ),
                "Country": pd.array(
                    [
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "Japan",
                        3,
                        np.nan,
                        2,
                    ],
                    dtype="object",
                ),
                "YearMonth": pd.array(
                    [
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        pd.Period("2014-08", freq="M"),
                        2,
                        np.nan,
                        4,
                    ],
                    dtype="object",
                ),
                "First registration": pd.array(
                    [
                        6,
                        np.nan,
                        np.nan,
                        "2000-01-01",
                        np.nan,
                        np.nan,
                        np.nan,
                        "2019-05-14",
                        np.nan,
                        "2019-05-14",
                        3,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
            }
        )

        pd.testing.assert_frame_equal(calculated, manual)

    def test_pandas_descriptive_statistics_compare_to_manual_calculations_with_groupby(
        self,
    ):

        """
        Test that '_pandas_descriptive_statistics' results match those computed manually, this time with 'groupby'.

        """
        df_test = self.get_table_for_descr_stat()

        # One variable for each data type (except 'timedelta'):
        calculated = _pandas_descriptive_statistics(
            df_original=df_test,
            selected_columns=[
                "Brand",
                "Price",
                "YearMonth",
                "Crashed",
                "Electric",
                "First registration",
            ],
            quantiles=[0.20, 0.25, 0.5],
            groupby_vars=["Country"],
        )

        manual = pd.DataFrame(
            {
                "Country": pd.array(
                    [
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "Japan",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                        "US",
                    ],
                    dtype="object",
                ),
                "Statistics": pd.array(
                    [
                        "count",
                        "mean",
                        "std",
                        "min",
                        "20%",
                        "25%",
                        "50%",
                        "max",
                        "sum",
                        "top",
                        "freq",
                        "count of trues",
                        "unique",
                        "count",
                        "mean",
                        "std",
                        "min",
                        "20%",
                        "25%",
                        "50%",
                        "max",
                        "sum",
                        "top",
                        "freq",
                        "count of trues",
                        "unique",
                    ],
                    dtype="object",
                ),
                "Price": pd.array(
                    [
                        2,
                        26000,
                        1414.213562,
                        25000,
                        25400,
                        25500,
                        26000,
                        27000,
                        52000,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        2,
                        31000,
                        12727.922061,
                        22000,
                        25600,
                        26500,
                        31000,
                        40000,
                        62000,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Crashed": pd.array(
                    [
                        3,
                        1.666666667,
                        2.081666,
                        0,
                        0.4,
                        0.5,
                        1,
                        4,
                        5,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        2,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Electric": pd.array(
                    [
                        3,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        False,
                        3,
                        0,
                        np.nan,
                        2,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        True,
                        2,
                        2,
                        np.nan,
                    ],
                    dtype="object",
                ),
                "Brand": pd.array(
                    [
                        3,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "Toyota Corolla",
                        2,
                        np.nan,
                        2,
                        2,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        "Tesla S",
                        2,
                        np.nan,
                        1,
                    ],
                    dtype="object",
                ),
                "YearMonth": pd.array(
                    [
                        3,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        pd.Period("2014-08", freq="M"),
                        2,
                        np.nan,
                        2,
                        1,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        np.nan,
                        pd.Period("2018-11", freq="M"),
                        1,
                        np.nan,
                        1,
                    ],
                    dtype="object",
                ),
                "First registration": pd.array(
                    [
                        3,
                        np.nan,
                        np.nan,
                        "2019-05-14",
                        np.nan,
                        np.nan,
                        np.nan,
                        "2019-05-14",
                        np.nan,
                        "2019-05-14",
                        3,
                        np.nan,
                        np.nan,
                        2,
                        np.nan,
                        np.nan,
                        "2000-01-01",
                        np.nan,
                        np.nan,
                        np.nan,
                        "2000-01-01",
                        np.nan,
                        "2000-01-01",
                        2,
                        np.nan,
                        np.nan,
                    ],
                    dtype="object",
                ),
            }
        )

        pd.testing.assert_frame_equal(calculated.astype("object"), manual)

    def test_pandas_descriptive_statistics_warning_msg_float_16(self):

        """
        Test if a Warning message is given when 'float16' data type is present in the input table.

        """
        df_test = self.get_table_for_descr_stat()

        self.assertWarns(
            Warning,
            _pandas_descriptive_statistics,
            **{
                "df_original": df_test,
                "selected_columns": None,
                "quantiles": None,
                "groupby_vars": None,
            }
        )

    def test_pandas_descriptive_statistics_warning_msg_groupby_NaNs(self):

        """
        Test if a Warning message is given when any 'groupby_vars' contain
        missing values (NaN).

        """
        df_test = self.get_table_for_descr_stat()

        self.assertWarns(
            Warning,
            _pandas_descriptive_statistics,
            **{
                "df_original": df_test,
                "selected_columns": ["Price"],
                "quantiles": None,
                "groupby_vars": ["Country"],
            }
        )


if __name__ == "__main__":
    unittest.main()
