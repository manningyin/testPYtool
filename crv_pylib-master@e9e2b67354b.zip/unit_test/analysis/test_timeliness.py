"""
# ============================================================================
# TEST_TIMELINESS.PY
# ----------------------------------------------------------------------------
# Unit testing file for CRV.DATA_ANALYSIS.TIMELINESS.PY
#
# This module is intended to contain and execute the test cases for
# functions in the 'crv.data_analysis.timeliness' module.
#
# Warning:
#     No warnings as of latest version.
#
# Notes:
#     Author: Diana Lucatero <G85544>
# ============================================================================
"""

import unittest
import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal
from crv.analysis.timeliness import _pandas_outdated_values, outdated_values


class TestPandasOutdatedValues(unittest.TestCase):
    """
    Unit test case for the 'pandas_outdated_values' function.
    """

    @staticmethod
    def get_test_data():
        """
        Sets up the sample data for the unit tests.
        """
        data = {
            "statement_ID": [f"A00{i}" for i in range(6)],
            "date": pd.array(
                [
                    "2000-01-01",
                    "2010-11-02",
                    "2019-05-14",
                    "2009-08-21",
                    "2011-02-06",
                    "2018-05-21",
                ],
                dtype=np.datetime64,
            ),
        }
        df = pd.DataFrame(data, columns=["statement_ID", "date"])

        return df

    def test_pandas_outdated_ValueError_datecol_not_in_df(self):
        """
        Test that a ValueError is raised if input parameter 'date_to_compare' is not a
        string, np.datetime64 or datetime.
        """
        df = self.get_test_data()
        # assertRaises
        self.assertRaises(
            ValueError,
            _pandas_outdated_values,
            **{
                "df": df,
                "date_col_name": "not_date",
                "date_to_compare": "2012-04-12",
                "max_age_allowed": 24,
            },
        )

    def test_pandas_outdated_ValueError_wrong_date_type(self):
        """
        Test that a ValueError is raised if date column 'date_col_name' is not of
        type np.datetime64
        """
        df = self.get_test_data()
        df["date"] = df["date"].astype(str)
        # assertRaises
        self.assertRaises(
            ValueError,
            _pandas_outdated_values,
            **{
                "df": df,
                "date_col_name": "date",
                "date_to_compare": "2012-04-12",
                "max_age_allowed": 24,
            },
        )

    def test_pandas_outdated_result_manual_example(self):
        """
        Test that the resulting dataframe and absolute/relative number of
        outdated values match that of a manual example.
        """
        df = self.get_test_data()
        date_to_compare = pd.to_datetime("2018-09-30")
        # Run _pandas_outdated_values
        (
            df_with_age,
            outdated_num_records,
            per_outdated_records,
        ) = _pandas_outdated_values(df, "date", date_to_compare, max_age_allowed=30)
        df_with_age["date_diff"] = df_with_age["date_diff"].astype(np.int32)
        df_with_age["outdated_flag"] = df_with_age["outdated_flag"].astype(np.int32)

        # Manual result
        result_df = pd.concat(
            [
                df,
                pd.DataFrame(
                    {
                        "date_diff": pd.array(
                            [225.0, 95.0, -7.0, 109.0, 92.0, 4.0], dtype=np.int32
                        ),
                        "outdated_flag": pd.array([1, 1, 0, 1, 1, 0], dtype=np.int32),
                    }
                ),
            ],
            axis=1,
        )
        outdated_num_records_result = 4
        per_outdated_records_result = (4 / 6) * 100

        # Perform comparison
        assert_frame_equal(df_with_age, result_df)
        self.assertEqual(outdated_num_records, outdated_num_records_result)
        self.assertEqual(per_outdated_records_result, per_outdated_records)


if __name__ == "__main__":
    unittest.main()
