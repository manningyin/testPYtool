"""
Unit testing file for CRV.UTILS.VISUAL_HELPER.PY

This module is intended to contain and execute the test cases for
functions in the 'crv.utils.visual_helper' module.

Warning:
    No warnings as of latest version.

Notes:
    Author: Lee MacKenzie Fischer <G01679>

"""

import pandas as pd
import matplotlib.pyplot as plt
import unittest
from crv.utils.visual_helper import (
    get_nordea_colour,
    get_xy_tick_format,
    nordea_axis_formatter,
    get_subplot_dims,
    build_plotting_dict,
)


class TestFile(unittest.TestCase):
    """
    Unit test case for CRV.UTILS.VISUAL_HELPER.PY
    """

    def test_get_nordea_colour_KeyError(self):
        print("test_get_nordea_colour_KeyError")
        self.assertRaises(KeyError, get_nordea_colour, "Terrible Mauve")

    def test_get_xy_tick_format_ValueError(self):
        print("test_get_xy_tick_format_ValueError")
        # test error in x_format
        self.assertRaises(ValueError, get_xy_tick_format, [1, 1, 1], [2, 2], 2)
        self.assertRaises(ValueError, get_xy_tick_format, {}, [2, 2], 2)
        # test error in y_format
        self.assertRaises(ValueError, get_xy_tick_format, [1, 1], [2, 2, 2], 2)
        self.assertRaises(ValueError, get_xy_tick_format, [1, 1], {}, 2)

    def test_nordea_axis_formatter_ValueError(self):
        print("text_nordea_axis_formatter_ValueError")
        figsize = (8, 4)
        fig, ax = plt.subplots(3, 1, figsize=figsize)
        # test gridlines_on value
        self.assertRaises(
            ValueError,
            nordea_axis_formatter,
            ax=ax[1],
            figsize=figsize,
            text_scale=1.0,
            x_label="",
            y_label="",
            axis_title="",
            x_format="default",
            y_format="default",
            y_scale="linear",
            gridlines_on=5,
            force_axis_zero=None,
        )
        # test gridlines_on value
        self.assertRaises(
            ValueError,
            nordea_axis_formatter,
            ax=ax[1],
            figsize=figsize,
            text_scale=1.0,
            x_label="",
            y_label="",
            axis_title="",
            x_format="default",
            y_format="default",
            y_scale="linear",
            gridlines_on=None,
            force_axis_zero=5,
        )

    def test_get_subplot_dims_ValueError(self):
        print("test_get_subplot_dims_ValueError")
        self.assertRaises(ValueError, get_subplot_dims, 5, "shape")

    def test_build_plotting_dict_ValueError(self):
        print("test_build_plotting_dict_ValueError")
        df = pd.DataFrame.from_dict(
            {
                "X": [1, 2, 3, 1, 2, 3, 1, 2, 3],
                "Y": [100, 200, 300, 200, 400, 600, 300, 600, 900],
                "GROUP": ["A", "A", "A", "B", "B", "B", "C", "C", "C"],
            }
        )
        # test subplot_by ValueError when y_cols and split_col
        # are provided
        self.assertRaises(
            ValueError,
            build_plotting_dict,
            data=df,
            x_col="X",
            y_cols="Y",
            split_col="GROUP",
            subplot_by=None,
        )
        # test subplot_by ValueError when split_col is not provided
        self.assertRaises(
            ValueError,
            build_plotting_dict,
            data=df,
            x_col="X",
            y_cols="Y",
            split_col=None,
            subplot_by="split_col",
        )
