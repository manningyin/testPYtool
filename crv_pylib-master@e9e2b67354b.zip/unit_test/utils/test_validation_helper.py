"""
Unit testing file for CRV.UTILS.VALDIATION_HELPER.PY

This module is intended to contain and execute the test cases for
functions in the 'crv.utils.validation_helper' module.

Warning:
    No warnings as of latest version.

Notes:
    Author: Lee MacKenzie Fischer <G01679>

    Function 'crv.utils.validation_helper.set_defs' is tested
    implicitly as part of testing 'treat_PD_FIRB_data'.

"""

import unittest
import pandas as pd
from crv.utils.validation_helper import treat_PD_FIRB_data, _create_bins_labels


class TestTreatPdFirbData(unittest.TestCase):
    """
    Unit test case for 'treat_PD_FIRB_data' function.
    """

    @staticmethod
    def get_obs_perf_df():
        d_obs = {
            "rating": ["2", "1-", "2", "3+", "2", "1-", "3+", "1-", "3+", "3+"],
            "rating_group": ["2", "1-", "2", "3+", "2", "1-", "3+", "1-", "3+", "3+"],
            "group": [f"A00{i}" for i in range(10)],
            "bankkod": [
                "Denmark",
                "Denmark",
                "Denmark",
                "Denmark",
                "Denmark",
                "Sweden",
                "Sweden",
                "Sweden",
                "Sweden",
                "Sweden",
            ],
            "BA_1EXPCLO": [
                "I03",
                "I03",
                "I03",
                "I03",
                "I03",
                "I02",
                "I02",
                "I02",
                "I02",
                "I02",
            ],
            "CALMONTH": ["202212" for i in range(10)],
        }
        df_obs = pd.DataFrame.from_dict(d_obs)
        d_perf = {
            "group": [f"A00{i}" for i in range(10)],
            "bankkod": [
                "Denmark",
                "Denmark",
                "Denmark",
                "Denmark",
                "Denmark",
                "Sweden",
                "Sweden",
                "Sweden",
                "Sweden",
                "Sweden",
            ],
            "BA_1EXPCLO": [
                "I03",
                "I03",
                "I03",
                "I03",
                "I03",
                "I04",
                "I02",
                "I02",
                "I02",
                "I02",
            ],
            "rating": ["0-", "0+", "2", "3+", "2", "0", "3+", "0", "3+", "3+"],
            "CALMONTH": ["202312" for i in range(10)],
        }
        df_perf = pd.DataFrame.from_dict(d_perf)
        df_firb = pd.concat([df_obs, df_perf], sort=True)
        ls_defaults = [1, 1, 0, 0, 0, 1, 0, 1, 0, 0]
        return df_firb, ls_defaults

    def test_treat_PD_FIRB_data_PandasDF(self):
        df_firb, ls_defaults = self.get_obs_perf_df()
        df_obs = df_firb[df_firb.CALMONTH == "202212"].copy()
        df_perf = df_firb[df_firb.CALMONTH == "202312"].copy()
        df_test = treat_PD_FIRB_data(df_obs, df_perf)
        test_defaults_ls = list(df_test.default)
        self.assertEqual(test_defaults_ls, ls_defaults, "Default count is not equal.")


class TestCreateBinsLabels(unittest.TestCase):
    """
    Test class for 'crv.utils.validation_helper._create_bins_labels'.
    """

    def test_create_bins_labels_value_error_1(self):
        """
        Tests for ValueError is raised when data is not a pd.DataFrame,
        pd.Series, psd.DataFrame
        """
        # Input parameters
        sample_series = "string instead of correct output"
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        self.assertRaises(
            ValueError,
            _create_bins_labels,
            **{
                "data": sample_series,
                "bins": sample_bins,
                "right": right,
                "pred_min": pred_min,
                "pred_max": pred_max,
            },
        )

    def test_create_bins_labels_value_error_2(self):
        """
        Tests for ValueError is raised when data if contains multiple columns
        """
        # Input parameters
        sample_series = pd.DataFrame.from_dict(
            {
                "col1": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35],
                "col2": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35],
            }
        )
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        self.assertRaises(
            ValueError,
            _create_bins_labels,
            **{
                "data": sample_series,
                "bins": sample_bins,
                "right": right,
                "pred_min": pred_min,
                "pred_max": pred_max,
            },
        )

    def test_create_bins_labels_add_bottom_bin(self):
        """
        Tests for correct binning when the data minimum is
        greater than 0.
        """
        # Input parameters
        sample_series = pd.Series([0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35])
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [0, 0.1, 0.2, 0.3, 1.4])

    def test_create_bins_labels_add_one_plus_top(self):
        """
        Tests for correct binning when the data maximum
        is less than the highest bin.
        """
        # Input parameters
        sample_series = pd.Series([0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35])
        sample_bins = [0.1, 0.2, 0.3, 0.4, 0.5]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.5])

    def test_create_bins_labels_negative_bin(self):
        """
        Tests for correct binning when a negative value
        is supplied in the bins.
        """
        # Input parameters
        sample_series = pd.Series([0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35])
        sample_bins = [-0.5, 0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [-0.5, 0.1, 0.2, 0.3, 1.4])

    def test_create_bins_labels_data_min_below_bin(self):
        """
        Tests for correct binning when the minimum data value is
        less than zero and less than the minimum bin.
        """
        # Input parameters
        sample_series = pd.Series([0.1, 0.2, 0.3, 0.4, 0.4, -0.1, 0.25, 0.35])
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [-0.1, 0.1, 0.2, 0.3, 1.4])

    def test_create_bins_labels_right_false(self):
        """
        Tests for correct labels are produced when the right = False
        """
        # Input parameters
        sample_series = pd.Series([0.1, 0.2, 0.3, 0.4, 0.4, -0.1, 0.25, 0.35])
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, labels = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )

        # Recreate intervals
        validation_labels = []
        validation_bins = [0, 0.1, 0.2, 0.3, 1.4]
        for i in range(len(validation_bins) - 1):
            validation_labels.append(
                pd.Interval(validation_bins[i], validation_bins[i + 1], closed="left")
            )

        # Compare contingency matrices on row level
        self.assertListEqual(
            labels, validation_labels, msg=f"Intervals do not match up"
        )

    def test_create_bins_labels_right_true(self):
        """
        Tests for correct labels are produced when the right = True
        """
        # Input parameters
        sample_series = pd.Series([0.1, 0.2, 0.3, 0.4, 0.4, -0.1, 0.25, 0.35])
        sample_bins = [0.1, 0.2, 0.3]
        right = True
        pred_min = None
        pred_max = None

        result_bins, labels = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )

        # Recreate intervals
        validation_labels = []
        validation_bins = [0, 0.1, 0.2, 0.3, 0.4]
        for i in range(len(validation_bins) - 1):
            validation_labels.append(
                pd.Interval(validation_bins[i], validation_bins[i + 1], closed="right")
            )

        # Compare contingency matrices on row level
        self.assertListEqual(
            labels, validation_labels, msg=f"Intervals do not match up"
        )


if __name__ == "__main__":
    unittest.main()
