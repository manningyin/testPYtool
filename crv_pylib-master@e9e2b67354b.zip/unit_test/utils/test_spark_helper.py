"""
Unit testing file for CRV.UTILS.SPARK_HELPER.PY

This module is intended to contain and execute the test cases for
functions in the 'crv.utils.spark_helper' module.

Warning:
    No warnings as of latest version.

Notes:
    Author: Lee MacKenzie Fischer <G01679>

"""

# Imports.
import unittest
from unittest.mock import patch
from crv.utils.spark_helper import spark_csv2parquet, spark_create_index_col
import pyspark.sql.functions as f
from unit_test.pyspark_test_class import PySparkTestCase
from pyspark.sql.types import StructType, StructField, StringType
import pandas as pd


class TestCsv2Parquet(unittest.TestCase):
    """
    Unit test case for the 'spark_csv2parquet' function.
    """

    @patch("crv.utils.spark_helper.os.path.isfile")
    @patch("crv.utils.spark_helper.os.path.isdir")
    def test_spark_csv2parquet_value_errors(self, mock_isdir, mock_isfile):
        test_infile = "not\\a\\real\\folder"
        test_outfile = "also\\not\\real"
        # Test for correct type of 'partition_by.
        self.assertRaises(
            ValueError, spark_csv2parquet, test_infile, test_outfile, 24.6
        )
        # Test for all strings in 'partition_by' list.
        self.assertRaises(
            ValueError, spark_csv2parquet, test_infile, test_outfile, ["string", 1]
        )
        # Test for for ccrrect type of 'sort_by'.
        self.assertRaises(
            ValueError, spark_csv2parquet, test_infile, test_outfile, "part_by", 6
        )
        # Test for all strings in 'sort_by' list.
        self.assertRaises(
            ValueError,
            spark_csv2parquet,
            test_infile,
            test_outfile,
            "part_by",
            ["string", 7],
        )
        # Test for proper existing file check.
        mock_isdir.return_value = True
        mock_isfile.return_value = True
        self.assertRaises(ValueError, spark_csv2parquet, test_infile, test_outfile)


class TestSparkCreateIndexCol(PySparkTestCase):
    """
    Unit test case for the 'spark_create_index_col' function.
    """

    @staticmethod
    def get_test_data(self):
        """
        Sets up the sample data for the unit tests.
        """

        data = {
            "asc": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "desc": [10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        }

        # Pandas and Spark dataframe
        df_pandas = pd.DataFrame(data)
        df_spark = self.spark.createDataFrame(df_pandas)

        return df_spark

    def test_spark_create_index_col_ValueError_1_no_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is not a
        spark.DataFrame
        """
        # df is not a pandas.DataFrame
        df = "Not a spark.DataFrame but string"

        # Input parameters
        order = "asc"
        index_name = "idx"

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_create_index_col,
            **{"df": df, "order": order, "index_name": index_name}
        )

    def test_spark_create_index_col_ValueError_2_empty_df(self):
        """
        Test that a ValueError is raised if input parameter 'df' is an empty
        spark.DataFrame
        """
        # df is an empty spark.DataFrame
        columns = ["x1", "x2", "x3", "x4", "x5", "g1", "g2"]
        schema = StructType([StructField(c, StringType()) for c in columns])
        df = self.spark.createDataFrame(data=[], schema=schema)

        # Input parameters
        order = "asc"
        index_name = "idx"

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_create_index_col,
            **{"df": df, "order": order, "index_name": index_name}
        )

    def test_spark_create_index_col_ValueError_3_no_str(self):
        """
        Test that a ValueError is raised if input parameter 'order'
        is not a list
        """
        # first_groupby_col is a string instead of a list
        order = ["list instead of list"]

        # Input parameters
        df = self.get_test_data(self)
        index_name = "idx"

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_create_index_col,
            **{"df": df, "order": order, "index_name": index_name}
        )

    def test_spark_create_index_col_ValueError_4_no_str(self):
        """
        Test that a ValueError is raised if input parameter 'index_name'
        is not a list
        """
        # first_groupby_col is a string instead of a list
        index_name = ["list instead of list"]

        # Input parameters
        df = self.get_test_data(self)
        order = "asc"

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_create_index_col,
            **{"df": df, "order": order, "index_name": index_name}
        )

    def test_spark_create_index_col_ValueError_8_wrong_value(self):
        """
        Test that a ValueError is raised if input parameter
        'order' is an invalid value; i.e. not either of the options:
        'asc', 'desc'.
        """
        # first_groupby_col is a string instead of a list
        order = "Invalid value"

        # Input parameters
        df = self.get_test_data(self)
        index_name = "idx"

        # assertRaises
        self.assertRaises(
            ValueError,
            spark_create_index_col,
            **{"df": df, "order": order, "index_name": index_name}
        )

    def test_spark_create_index_col_Ascending_order(self):
        """
        Test whether an ascending order is created
        """
        # Input parameters
        df = self.get_test_data(self)
        order = "asc"
        index_name = "idx"

        df = spark_create_index_col(df=df, order=order, index_name=index_name)
        df_pd = df.select(
            f.col(index_name).alias(index_name), f.col("asc").alias("asc")
        ).toPandas()
        calc_list = df_pd["idx"].values.tolist()
        val_list = df_pd["asc"].values.tolist()

        self.assertListEqual(
            calc_list, val_list, msg="Ascending column does not add up."
        )

    def test_spark_create_index_col_Descending_order(self):
        """
        Test whether an descending order is created
        """
        # Input parameters
        df = self.get_test_data(self)
        order = "desc"
        index_name = "idx"

        df = spark_create_index_col(df=df, order=order, index_name=index_name)
        df_pd = df.select(
            f.col(index_name).alias(index_name), f.col("desc").alias("desc")
        ).toPandas()
        calc_list = df_pd["idx"].values.tolist()
        val_list = df_pd["desc"].values.tolist()

        self.assertListEqual(
            calc_list, val_list, msg="Descending column does not add up."
        )


if __name__ == "__main__":
    unittest.main()
