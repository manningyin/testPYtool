"""
# ============================================================================
# TEST_VALIDATION_HELPER.PY
# ----------------------------------------------------------------------------
# Description:
#   Unit testing for the functions in 'crv.validation.validation_helper.py' 
#   that use the pypsark module.
#
# Note:
#   This file uses the updated (202-03-18) method of unit testing, i.e. 
#   each function in the file gets its own test class, with the test cases
#   for the function being contained in separate methods.
#   This is not much different functionally from the previous implementations
#   but is definitely cleaner to read and debug.
#
# Warning:
#   Tests for functions that make use of Spark will take signigicantly
#   longer than their 'pandas' counterparts. The SparkSession creates a lot
#   of computational overhead, such as starting session, splitting data,
#   sending to workers.
#
# ============================================================================
"""
from crv.utils.validation_helper import _create_bins_labels
import pandas as pd
import unittest
from unit_test.pyspark_test_class import PySparkTestCase


class TestCreateBinsLabels(PySparkTestCase):
    """
    Test class for 'crv.utils.validation_helper._create_bins_labels'.
    """

    def test_create_bins_labels_value_error_1(self):
        """
        Tests for ValueError is raised when data contains multiple columns
        """
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict(
                {
                    "col1": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35],
                    "col2": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35],
                }
            )
        )
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        self.assertRaises(
            ValueError,
            _create_bins_labels,
            **{
                "data": sample_series,
                "bins": sample_bins,
                "right": right,
                "pred_min": pred_min,
                "pred_max": pred_max,
            },
        )

    def test_create_bins_labels_add_bottom_bin(self):
        """
        Tests for correct binning when the data minimum is
        greater than 0.
        """
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict({"col1": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35]})
        )
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [0, 0.1, 0.2, 0.3, 1.4])

    def test_create_bins_labels_add_one_plus_top(self):
        """
        Tests for correct binning when the data maximum
        is less than the highest bin.
        """
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict({"col1": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35]})
        )
        sample_bins = [0.1, 0.2, 0.3, 0.4, 0.5]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.5])

    def test_create_bins_labels_negative_bin(self):
        """
        Tests for correct binning when a negative value
        is supplied in the bins.
        """
        # Input parameters
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict({"col1": [0.1, 0.2, 0.3, 0.4, 0.4, 0.2, 0.25, 0.35]})
        )
        sample_bins = [-0.5, 0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [-0.5, 0.1, 0.2, 0.3, 1.4])

    def test_create_bins_labels_data_min_below_bin(self):
        """
        Tests for correct binning when the minimum data value is
        less than zero and less than the minimum bin.
        """
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict(
                {"col1": [0.1, 0.2, 0.3, 0.4, 0.4, -0.1, 0.25, 0.35]}
            )
        )
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, _ = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )
        self.assertEqual(result_bins, [-0.1, 0.1, 0.2, 0.3, 1.4])

    def test_create_bins_labels_right_false(self):
        """
        Tests for correct labels are produced when the right = False
        """
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict(
                {"col1": [0.1, 0.2, 0.3, 0.4, 0.4, -0.1, 0.25, 0.35]}
            )
        )
        sample_bins = [0.1, 0.2, 0.3]
        right = False
        pred_min = None
        pred_max = None

        result_bins, labels = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )

        # Recreate intervals
        validation_labels = []
        validation_bins = [0, 0.1, 0.2, 0.3, 1.4]
        for i in range(len(validation_bins) - 1):
            validation_labels.append(
                pd.Interval(validation_bins[i], validation_bins[i + 1], closed="left")
            )

        # Compare contingency matrices on row level
        self.assertListEqual(
            labels, validation_labels, msg=f"Intervals do not match up"
        )

    def test_create_bins_labels_right_true(self):
        """
        Tests for correct labels are produced when the right = True
        """
        # Input parameters
        sample_series = self.spark.createDataFrame(
            pd.DataFrame.from_dict(
                {"col1": [0.1, 0.2, 0.3, 0.4, 0.4, -0.1, 0.25, 0.35]}
            )
        )
        sample_bins = [0.1, 0.2, 0.3]
        right = True
        pred_min = None
        pred_max = None

        result_bins, labels = _create_bins_labels(
            data=sample_series,
            bins=sample_bins,
            right=right,
            pred_min=pred_min,
            pred_max=pred_max,
        )

        # Recreate intervals
        validation_labels = []
        validation_bins = [0, 0.1, 0.2, 0.3, 1.4]
        for i in range(len(validation_bins) - 1):
            validation_labels.append(
                pd.Interval(validation_bins[i], validation_bins[i + 1], closed="right")
            )

        # Compare contingency matrices on row level
        self.assertListEqual(
            labels, validation_labels, msg=f"Intervals do not match up"
        )


if __name__ == "__main__":
    unittest.main()
