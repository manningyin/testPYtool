# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 17:27:25 2019

@author: N440730
"""

import unittest
import pandas as pd
from pandas.testing import assert_frame_equal
from pandas.api.types import CategoricalDtype
from crv.utils import dataframe_helper


class TestPandasRatingCats(unittest.TestCase):
    """
    Unit test case for 'pandas_rating_cats' function.
    """

    def test_pandas_rating_cats_results(self):
        rat_cats = CategoricalDtype(
            categories=[
                "6+",
                "6",
                "6-",
                "5+",
                "5",
                "5-",
                "4+",
                "4",
                "4-",
                "3+",
                "3",
                "3-",
                "2+",
                "2",
                "2-",
                "1+",
                "1",
                "1-",
                "0+",
                "0",
                "0-",
                "U",
            ],
            ordered=True,
        )
        df = pd.DataFrame(
            data={
                "col1": [
                    "6+",
                    "6",
                    "6-",
                    "5+",
                    "5",
                    "5-",
                    "4+",
                    "4",
                    "4-",
                    "3+",
                    "3",
                    "3-",
                    "2+",
                    "2",
                    "2-",
                    "1+",
                    "1",
                    "1-",
                    "0+",
                    "0",
                    "0-",
                    "U",
                ]
            }
        )
        df["col1"] = df["col1"].astype(rat_cats)
        df_test = pd.DataFrame(
            data={
                "col1": [
                    "0-",
                    "0+",
                    "0",
                    "1-",
                    "1+",
                    "1",
                    "6-",
                    "6+",
                    "6",
                    "2-",
                    "2+",
                    "2",
                    "4-",
                    "4+",
                    "4",
                    "3-",
                    "3+",
                    "3",
                    "5-",
                    "5+",
                    "5",
                    "U",
                ]
            }
        )
        df_test = dataframe_helper.pandas_rating_cats(df_test, "col1")

        df_test.sort_values(by=["col1"], inplace=True)
        df_test.reset_index(inplace=True, drop=True)
        assert_frame_equal(df, df_test, check_names=False)

    def test_pandas_rating_cats_scoring(self):
        scoring_cats_list = [
            "A+",
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-",
            "E+",
            "E",
            "E-",
            "F+",
            "F",
            "F-",
            "0+",
            "0",
            "0-",
            "U",
        ]
        rat_cats = CategoricalDtype(categories=scoring_cats_list, ordered=True)
        df = pd.DataFrame(data={"col1": scoring_cats_list})
        df["col1"] = df["col1"].astype(rat_cats)
        df_test = pd.DataFrame(data={"col1": scoring_cats_list})
        df_test = dataframe_helper.rating_cats(
            df_test, "col1", dataframe_helper.scoring_cats_list()
        )
        assert_frame_equal(df, df_test, check_names=False)

    def test_pandas_rating_cats_TypeError(self):
        self.assertRaises(TypeError, dataframe_helper.pandas_rating_cats, 1, "string")
        self.assertRaises(
            TypeError, dataframe_helper.pandas_rating_cats, "string", "string"
        )

    def test_pandas_rating_cats_KeyError(self):
        df = pd.DataFrame(data={"col1": list("abc")})
        self.assertRaises(KeyError, dataframe_helper.pandas_rating_cats, df, "col2")
        self.assertRaises(KeyError, dataframe_helper.pandas_rating_cats, df, 1)


class TestRatingCats(unittest.TestCase):
    """
    Test case for the 'rating_cats' function.
    """

    def test_rating_cats_return_type_pandas(self):
        df = pd.DataFrame(
            data={
                "col1": [
                    "0-",
                    "0+",
                    "0",
                    "1-",
                    "1+",
                    "1",
                    "6-",
                    "6+",
                    "6",
                    "2-",
                    "2+",
                    "2",
                    "4-",
                    "4+",
                    "4",
                    "3-",
                    "3+",
                    "3",
                    "5-",
                    "5+",
                    "5",
                    "U",
                ]
            }
        )
        assert isinstance(dataframe_helper.rating_cats(df, "col1"), pd.DataFrame)


class TestPandasDowncastFloats(unittest.TestCase):
    """
    Test case for 'pandas_downcast_floats' function.
    """

    def test_pandas_downcast_floats(self):
        df = pd.DataFrame(data={"col1": [1.1, 2.2, 3.3]})
        df_test = df.copy()
        df_test = dataframe_helper.pandas_downcast_floats(df_test)
        df["col1"] = pd.to_numeric(df["col1"], downcast="float")
        assert_frame_equal(df, df_test, check_names=False)

    def test_pandas_downcast_floats_AttributeError(self):
        self.assertRaises(AttributeError, dataframe_helper.pandas_downcast_floats, 1)
        self.assertRaises(
            AttributeError, dataframe_helper.pandas_downcast_floats, "string"
        )


class TestDowncastFloats(unittest.TestCase):
    """
    Test case for 'downcast_floats' function.
    """

    def test_downcast_floats_return_type(self):
        df = pd.DataFrame(data={"col1": [1.1, 2.2, 3.3]})
        df_out = dataframe_helper.downcast_floats(df)
        assert isinstance(df_out, pd.DataFrame)


class TestPandasCategorize(unittest.TestCase):
    """
    Test case for 'pandas_categorize' function.
    """

    def test_pandas_categorize(self):
        df = pd.DataFrame(
            data={
                "col1": list("abcdef"),
                "col2": list("aabbcc"),
                "col3": list("aaaabb"),
                "col4": [1, 2, 3, 4, 5, 6],
            }
        )
        df_test = df.copy()
        df_test = dataframe_helper.pandas_categorize(df_test)
        df["col3"] = df["col3"].astype("category")
        assert_frame_equal(df, df_test, check_names=False)

        df_test = dataframe_helper.pandas_categorize(df_test, force=True)
        df["col1"] = df["col1"].astype("category")
        df["col2"] = df["col2"].astype("category")
        assert_frame_equal(df, df_test, check_names=False)

    def test_pandas_categorize_AttributeError(self):
        self.assertRaises(AttributeError, dataframe_helper.pandas_categorize, 1)
        self.assertRaises(AttributeError, dataframe_helper.pandas_categorize, "string")


class TestCategorize(unittest.TestCase):
    """
    Test case for 'categorize' function.
    """

    def test_categorize_TypeError(self):
        self.assertRaises(TypeError, dataframe_helper.categorize, 1)
        self.assertRaises(TypeError, dataframe_helper.categorize, "string")

    def test_categorize_return_type(self):
        df = pd.DataFrame(
            data={
                "col1": list("abcdef"),
                "col2": list("aabbcc"),
                "col3": list("aaaabb"),
                "col4": [1, 2, 3, 4, 5, 6],
            }
        )
        assert isinstance(dataframe_helper.categorize(df), pd.DataFrame)


if __name__ == "__main__":
    unittest.main()
