# Unit tests for `CRV_PyLib`
This folder contains all the unit tests for all relevant modules of this library. Functions that will not be unit tested include, but are not limited to, plotting functions and table formatting and export functions, though these should be thoroughly reviewed before merging.

## Testing methodology
Each function should have a `unittest.TestCase` class written, with each test case (correct output, edge cases, error handling) getting a separate method in the class.

Each `.py` file shall have one test file written, with each function within that file recieving its own test case class in the test file.

All test methods shall conclude with a `self.assert` method indicating the comparison between the actual and expected output.

## Spark tests
Unit tests for functions that make use of Spark can be handled in a similar way to regular unit tests, but require the use of a customized `TestCase` class. Additionally, test for functions that use Spark shall be contained in a separate test file with the word `spark` immediately following the prefix `test`.

### Writing Spark tests
The motivation and structure of the tests should be the same, and they should not rely on outside data. That is, either all the data should be contained within the test function itself, or the data should be stored as a dictionary in a separate `.py` file within this folder. Accessing specific external data sources, e.g. the tables on the UDM, is not allowed. All tests must be able to run using only the code contained in this folder.

A class called `PySparkTestCase` is contained in the `pyspark_test_class.py` file, which handles the creation and closing of the necessary Spark session for each test. This should be used to create the test case class, e.g.:

`class TestMyFile(unittest.TestCase):` should be replaced with `class TestMyFile(PySparkTestCase):`, and the extra import `from unit_test.pyspark_test_class import PySparkTestCase` must be added to your import section of code.

### Running Spark tests
Unit tests that make use of a Spark connection must be run on a system that has Spark installed, either via a notebook with a `spark` object created or via command line using `spark-submit`. Running these unit tests on a system without Spark installed will cause the tests to not be executed, though other non-Spark tests will not be affected.
