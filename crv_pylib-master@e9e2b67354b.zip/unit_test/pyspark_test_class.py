"""
# ============================================================================
# PYSPARK_TEST_CLASS.PY
# ----------------------------------------------------------------------------
# Description:
#   This file contains the 'PySparkTestCase' class that extends the
#   'unittest.TestCase' class for the purposes of writing unit tests for
#   functions that make use of the 'pyspark' module.
#
# References:
# [1] https://blog.cambridgespark.com/unit-testing-with-pyspark-fb31671b1ad8
#
# ============================================================================
"""

# Imports.
import unittest
import logging
from pyspark.sql import SparkSession


class PySparkTestCase(unittest.TestCase):
    """
    A class extending the 'unittest.TestCase' class with functionality
    for creating unit tests for functions using pyspark.

    The below functions are called automatically on 'TestCase' startup
    and completion, to handle setup and cleanup, respectively.
    """

    @classmethod
    def suppress_py4j_logging(cls):
        """
        Supresses py4j console logging.
        """
        logger = logging.getLogger("py4j")
        logger.setLevel(logging.WARN)

    @classmethod
    def create_testing_pyspark_session(cls):
        """
        Creates the Spark session object for the test.
        """
        return (
            SparkSession.builder.master("local[2]")
            .appName("local-pyspark-testing-context")
            .getOrCreate()
        )

    @classmethod
    def setUpClass(cls):
        """
        Method automatically called by the TestCase object
        on test start. Handles setup.
        """
        cls.suppress_py4j_logging()
        cls.spark = cls.create_testing_pyspark_session()

    @classmethod
    def tearDownClass(cls):
        """
        Method automatically called by the TestCase object
        on test completion. Handles cleanup.
        """
        cls.spark.stop()
