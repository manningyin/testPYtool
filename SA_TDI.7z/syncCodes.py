from dirsync import sync
#C:\Users\z006554\OneDrive - Nordea\pythonProject\_ValidationCodes\SA_TDI
#C:\Users\z006554\OneDrive - Nordea\Documents\ValidationProjects\2024\_Validating\2024_05_IV_Standardized_Method_Traded_Dept_Instruments\4.code

source_path = 'C:\\Users\\z006554\\OneDrive - Nordea\\pythonProject\\_ValidationCodes\\SA_TDI'
target_path = 'C:\\Users\\z006554\\OneDrive - Nordea\\Documents\\ValidationProjects\\2024\\_Validating\\2024_05_IV_Standardized_Method_Traded_Dept_Instruments\\4.code'

sync(source_path, target_path, 'sync') #for syncing one way
#sync(target_path, source_path, 'sync') #for syncing the opposite way