    with list_ORCA_leftovers_isin as
    (
                                                                    select /*+parallel(6)*/ isin 
                                                                      from se.legacy_isin_cat_result 
                                                                     where eod_date = DATE '%(date_sql)s'  
                                                                       and error is not null
                                                                    union
                                                                    select /*+parallel(6)*/ isin 
                                                                      from se.legacy_isin_cat_result 
                                                                     where eod_date = DATE '%(date_sql)s'   
                                                                       and supported = 0
    )
    ,list_ORCA_leftovers_trans as
    (
                                                            --orca_leftovers_trans            ORCA leftovers specified at trans level. due to pricing or reconciliation error
                                                            select distinct trade_id, trans_id
                                                            from
                                                            (
                                                                     select trade_id,
                                                                            trans_id,
                                                                   --The same trans may fail in both HS and Stressed VaR and/or register multiple ripl_load_error_code_ids, which is 
                                                                   --why we need a group function in order to get a single record per trans. Should a trans occur with more than 
                                                                   --one ripl_load_error_code_id, we arbitrarily choose the greatest. 
                                                                            max(ripl_load_error_code_id) ripl_load_error_code_id 
                                                                       from marsp.ripl_load_error x1,
                                                                            marsp.th_recon_trade  x2         
                                                                      where x1.eod_date         = DATE '%(date_sql)s'
                                                                        and x1.scenario_name like ('%%TRIM Bond CS%%') 
                                                                        and x2.eod_date         = x1.eod_date
                                                                        and x2.th_message_id    = x1.th_message_id
                                                                        and nvl(x2.mismatch_properties,'X') <> 'MISSING_IN_MARS' --if a trans is missing in MARS, of course we don't
                                                                      group by trade_id,                                         --have a position in it anyway, according to MARS 
                                                                               trans_id
                                                            )
    )
    ,list_ORCA_leftovers_hold as
    (
                                                            --orca_leftovers_holding           ORCA leftovers specified at holding level. due to pricing or reconciliation error
                                                            select distinct org_id, product_id, effect_id
                                                            from
                                                            (
                                                                    select org_id, 
                                                                            product_id, 
                                                                            effect_id,
                                                                            max(ripl_load_error_code_id) ripl_load_error_code_id
                                                                       from marsp.ripl_load_error  y1,
                                                                            marsp.th_recon_holding y2       
                                                                      where y1.eod_date         = DATE '%(date_sql)s'
                                                                        and y1.scenario_name LIKE ('%%TRIM Bond CS%%') 
                                                                        and y2.th_message_id    = y1.th_message_id
                                                                        and y2.eod_date         = y1.eod_date
                                                                        and nvl(y2.mismatch_properties,'X') <> 'MISSING_IN_MARS' 
                                                                      group by org_id,                                       
                                                                               product_id, 
                                                                               effect_id
                                                            )
    )
    select x.report_date,
          'MKR_SA_TDI',
          '201409',
           x.eod_date_month,
           x.eod_date,
           x.org_id,
           x.isin,
           x.name as product_type,
           x.issue_date,
           x.MATURITY_DATE,
           x.sp_rating,
           x.internal_rating,
           x.issue_type,
           x.COLLATERAL_TYPE,
           x.ISSUE_CCY,
           x.SOURCE_ISSUER_DESC,
           x.instrument_name as instrument_name,
           'O' AS cortype,
           'S' AS rsktype,
           sum (x.quantity) quantity,
           round(sum(x.mv_base),2) as mv_base,
           'DK' AS national_market,
           null as INTERNAL_ISSUER, 
           case when nvl(x.domicile,x.issue_country) is null then 'DK' else nvl(x.domicile,x.issue_country) end domicilie,
          'EUR' as currency,
           0 as row_index,
           0 as adj_notional,
           null as risk_bucket,
           x.position_grp_id
    from 
    (
                            select a.eod_date                                                       AS report_date
                                 , to_char(a.eod_date,'YYYYMM')                                     AS eod_date_month
                                 , to_char(a.eod_date,'YYYYMMDD')                                   AS eod_date
                                 , a.org_id
                                 , g.isin
                                 , a.name --product_name
                                 , to_char(a.issue_date,'YYYYMMDD')                                 as issue_date
                                 , to_char(a.MATURITY_DATE,'YYYYMMDD')                              as maturity_date
                                 , nvl(a.sp_rating, nvl(moo.moodys_rating_converted, m.rating))     as sp_rating
                                 , nvl(ACR_int_rat.code, nvl(k.internal_rating, '3-'))              as internal_rating
                                 , case when a.issuer_type_id='MORTG' then 'INST' else a.issuer_type_id end issue_type
                                 , h.collateral_type
                                 , h.issue_ccy
                                 , h.source_issuer_desc
                                 , a.instrument_name
                                 , h.issue_country
                                 , h.issuer_su_key
                                 , i.domicile
                                 , a.position_grp_id
                                 , sum(a.quantity)                                                  as quantity
                                 , sum(a.mv_base)                                                   as mv_base 
                            from
                            (  
                                    select a.eod_date
                                         , a.effect_id
                                         , a.org_id
                                         , a.product_id
                                         , b.issuer_type_id
                                         , b.issue_date
                                         , b.maturity_date
                                         , case when x.sp_rating in ('NA','NR') then null else x.sp_rating end          sp_rating      
                                         , case when x.moodys_rating in ('NA','NR') then null else x.moodys_rating end  moodys_rating 
                                         , b.spread_id
                                         , a.position_grp_id
                                         , c.name -- product_name
                                         , d.name as instrument_name
                                         , a.mv_base
                                         , a.quantity
                                    from 
                                    (
                                                                select a.eod_date
                                                                      , a.bond_effect_id       as effect_id
                                                                      , a.org_id
                                                                      , a.bond_product_id      as product_id
                                                                      , marsp.Util_Position_Grp.get_cs_position_grp (a.org_id, a.bond_product_id,b.spread_id) as position_grp_id
                                                                      , a.mv_base_adj          as mv_base
                                                                      , a.quantity_base_adj    as quantity 
                                                                from
                                                                (
                                                                        select a.eod_date
                                                                             , a.effect_id
                                                                             , a.org_id
                                                                             , a.quantity_base
                                                                             , a.quantity_base * c.wgt                             as quantity_base_adj
                                                                             , a.quantity_base * c.wgt * f.price / 100             as mv_base_adj
                                                                             , a.effect_price       as future_price
                                                                             , f.price              as bond_price
                                                                             , c.wgt
                                                                             , c.conversion_factor
                                                                             , b.undl_effect_id
                                                                             , c.bond_effect_id
                                                                             , e.product_id         as   bond_product_id
                                                                             , d.name
                                                                        from
                                                                        (
                                                                                select *
                                                                                from marsp.position_mv_h
                                                                                where eod_date = DATE '%(date_sql)s'
                                                                                and org_id in (select org_id from MARSP.CONS_ORG_STRUCTURE_STD where cons_org_id in (50004))
                                                                                and product_id in (526)  --futures on callable mortgage bonds
                                                                        ) a
                                                                        left join marsp.future_effect         b on a.effect_id = b.effect_id
                                                                        left join marsp.ctd_bond              c on b.undl_effect_id = c.effect_id
                                                                        left join marsp.effect               d on c.bond_effect_id = d.effect_id
                                                                        left join marsp.product_mapping      e on d.effect_grp_id = e.effect_grp_id
                                                                        left join marsp.price                f on c.bond_effect_id=f.effect_id and a.eod_date=f.eod_date and f.price_type_id='INT'
                                                                        where c.eod_date = DATE '%(date_sql)s'
                                                                        and e.trade_type_id = 'HOLD'
                                                                ) a
                                                                join marsp.bond_effect    b on a.bond_effect_id=b.effect_id
                                                                join marsp.product        c on a.bond_product_id=c.product_id
                                                                where a.mv_base_adj is not null
                                                                and a.mv_base_adj <> 0
                                                                
                                                                union
                                                            
                                                                select *
                                                                from
                                                                (
                                                                        select a.eod_date
                                                                             , a.effect_id
                                                                             , a.org_id
                                                                             , a.product_id
                                                                             , marsp.Util_Position_Grp.get_cs_position_grp (a.org_id,a.product_id,b.spread_id) as position_grp_id
                                                                             , a.mv_base
                                                                             , a.quantity
                                                                        from
                                                                        (
                                                                                select * from marsp.position_mv_h
                                                                                where eod_date = DATE '%(date_sql)s'
                                                                                and org_id in (select org_id from MARSP.CONS_ORG_STRUCTURE_STD where cons_org_id in (50004))
                                                                        ) a
                                                                        inner join marsp.bond_effect b on a.effect_id=b.effect_id
                                                                        where a.product_id not in (select product_id from marsp.product_grp_product where product_grp_id = 100141) --ORCA handled
                                                                )
                                                                where position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp where position_supergrp_id = 'SA')
                                                                
                                                                union
                                                                
                                                                select a.eod_date
                                                                     , a.effect_id
                                                                     , a.org_id
                                                                     , a.product_id
                                                                     , marsp.Util_Position_Grp.get_cs_position_grp (a.org_id,a.product_id,b.spread_id) as position_grp_id
                                                                     , a.mv_base
                                                                     , a.quantity
                                                                from
                                                                (
                                                                        select * from marsp.position_mv_h
                                                                        where eod_date = DATE '%(date_sql)s'
                                                                        and org_id in (select org_id from MARSP.CONS_ORG_STRUCTURE_STD where cons_org_id in (50004))
                                                                ) a
                                                                inner join marsp.bond_effect b on a.effect_id=b.effect_id
                                                                inner join 
                                                                (
                                                                        select distinct effect_id
                                                                        from marsp.isin_effect
                                                                        where isin in (select * from list_ORCA_leftovers_isin)
                                                                ) x on a.effect_id=x.effect_id
                                                                where a.product_id in (select product_id from marsp.product_grp_product where product_grp_id = 100141) --ORCA handled
                                                                
                                                                union 
                                                                
                                                                select a.eod_date
                                                                     , a.effect_id
                                                                     , a.org_id
                                                                     , a.product_id
                                                                     , marsp.Util_Position_Grp.get_cs_position_grp (a.org_id,a.product_id,b.spread_id) as position_grp_id
                                                                     , a.mv_base
                                                                     , a.quantity
                                                                from
                                                                (
                                                                        select * from marsp.position_mv_h
                                                                        where eod_date = DATE '%(date_sql)s'
                                                                        and org_id in (select org_id from MARSP.CONS_ORG_STRUCTURE_STD where cons_org_id in (50004))
                                                                ) a
                                                                inner join marsp.bond_effect b on a.effect_id=b.effect_id
                                                                inner join (select * from list_ORCA_leftovers_trans) x on a.trade_id=x.trade_id and a.trans_id=x.trans_id
                                                                where a.product_id in (select product_id from marsp.product_grp_product where product_grp_id = 100141) --ORCA handled
                                                        
                                                                union
                                                                
                                                                select a.eod_date
                                                                     , a.effect_id
                                                                     , a.org_id
                                                                     , a.product_id
                                                                     , marsp.Util_Position_Grp.get_cs_position_grp (a.org_id,a.product_id,b.spread_id) as position_grp_id
                                                                     , a.mv_base
                                                                     , a.quantity
                                                                from
                                                                (
                                                                        select * from marsp.position_mv_h
                                                                        where eod_date = DATE '%(date_sql)s'
                                                                        and org_id in (select org_id from MARSP.CONS_ORG_STRUCTURE_STD where cons_org_id in (50004))
                                                                ) a
                                                                inner join marsp.bond_effect b on a.effect_id=b.effect_id
                                                                inner join (select * from list_ORCA_leftovers_hold) x on a.org_id=x.org_id and a.product_id=x.product_id and a.effect_id=x.effect_id 
                                                                where a.product_id in (select product_id from marsp.product_grp_product where product_grp_id = 100141) --ORCA handled
                                    ) a
                                    inner join marsp.bond_effect b on a.effect_id=b.effect_id
                                    left join marsp.product c on a.product_id=c.product_id
                                    left join marsp.effect d on a.effect_id=d.effect_id
                                    left join marsp.org_rating x on d.issuer_org_id=x.org_id and x.eod_date=DATE '%(date_sql)s' and x.seniority_grp_id=50
                                    where a.position_grp_id not in (130) -- CoCo bonds (130) are excluded, since they are in SA equity
                                    and a.position_grp_id not in (57,1057) -- 57 and 1057 are excluded due to static data quality issues
                            ) a
                            inner join marsp.isin_effect g on a.effect_id=g.effect_id
                            inner join 
                            (
                                    select ISIN
                                         , collateral_type
                                         , issue_ccy
                                         , source_issuer_desc
                                         , issue_country
                                         , issuer_su_key
                                    from tw_mcdm_net.in_instrument 
                                    where SOURCE_ISSUER_DESC NOT LIKE ('%%NORDEA%%')
                            ) h on g.isin=h.isin
                            left join
                            (
                                    select su_key, 
                                    CASE WHEN max(DOMICILE_COUNTRY) is null then max(COUNTRY) else max(DOMICILE_COUNTRY) end AS DOMICILE
                                    from  TW_GLOSTATIC_NET.GS_COUNTERPART
                                    group by su_key
                            ) i on h.issuer_su_key=i.su_key
                            left join 
                            (
                                    select counterpart_su_key as issuer_su_key 
                                          , code             
                                    from TW_CREDIT_NET.rsd_internal_rating 
                                    where report_date in 
                                    (
                                            select max(report_date)
                                            from TW_CREDIT_NET.rsd_internal_rating 
                                            where report_date<=DATE '%(date_sql)s'
                                    )
                                    and code <> 'NR'
                            ) ACR_int_rat on h.issuer_su_key=ACR_int_rat.issuer_su_key
                            left join MARSP.SA_TDI_INTERNAL_RATINGS k on h.issuer_su_key=k.issuer_su_key 
                            left join
                            (
                                    select b.moodys_rating
                                          , a.uniform_rating        AS moodys_rating_converted
                                    from marsp.rating_mapping#1 a,
                                         marsp.rating_mapping#2 b
                                    where a.rating_id=b.rating_id
                            ) moo on a.moodys_rating=moo.moodys_rating
                            left join MARSP.SA_TDI_EXTERNAL_RATINGS m on g.isin=m.isin
                            group by
                                  a.eod_date
                                 , a.org_id
                                 , g.isin
                                 , a.name --product_name
                                 , a.issue_date
                                 , a.MATURITY_DATE
                                 , a.sp_rating
                                 , moo.moodys_rating_converted
                                 , m.rating
                                 , ACR_int_rat.code
                                 , k.internal_rating
                                 , a.issuer_type_id
                                 , h.collateral_type
                                 , h.issue_ccy
                                 , h.source_issuer_desc
                                 , a.instrument_name
                                 , h.issue_country
                                 , h.issuer_su_key
                                 , i.domicile
                                 , a.position_grp_id
    )  x
    where x.quantity<>0
    group by x.report_date, x.eod_date_month, x.eod_date,
             x.org_id, x.isin, x.name, 
             x.issue_date, x.MATURITY_DATE, x.sp_rating,
             x.internal_rating, x.issue_type, x.COLLATERAL_TYPE,
             x.ISSUE_CCY, x.SOURCE_ISSUER_DESC, x.instrument_name,
             x.issue_country, x.domicile, x.position_grp_id