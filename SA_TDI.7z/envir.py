"""
Modules that provides environment information for current invocation of the library.

The module will provide environment specific information, such as:
- name of current environment
- location of data area for a specific environment
- location of data area for current environment.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ====================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ====================================================================================
    1       01FEB2017   G50444      Initial creation
    2       23jun2017   g50444      Added sub_data_path() function
    ======= =========   =========   ====================================================================================

Review:
    ======= =========   ========    =========   ========================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ========================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ========================================================================
"""
import inspect
import os


def detect(info=0):
    """
    Returns the (conceptual) name of the environment where this function is called from.

    Args:

    Returns:
        (str):   Name of the environment - PROD, PREPROD, TEST or DEV

    Raises:

    Example:
        The module is called (from python) like this::
        
            current_environment = detect()
            
    Warning:

    Notes:
        Author: g50444
    """

    # Getting information about current object
    calling_object = inspect.stack()[0]

    # ===================================================================================
    # Extracting the information about the calling object
    # Abspath is used due to Python 2 issues, where Spyder defaults to relative path
    # ===================================================================================
    module_file_path = os.path.abspath(calling_object[1])

    # ===================================================================================
    # Determining if it is possible that the given module_file_path is based on a
    # mapped network drive (e.g. z:\something instead of \\server\share\something).
    # If it is a mapped drive, we translate it to get the name of the share - which
    # tells us which environment we are on...
    # ===================================================================================
    if module_file_path.lower().startswith('c'):
        mapped_network_drive = False
    elif module_file_path.lower().startswith('\\\\'):
        mapped_network_drive = False
    elif module_file_path.lower().startswith('//'):
        mapped_network_drive = False
    else:
        mapped_network_drive = True

    if mapped_network_drive:
        # Translating mapped network drive letter into a full network path. (z:\ -> \\server\share\...)
        try:
            from core.system import network
            full_module_file_path = network.get_UNC_path(mapped_drive_letter=module_file_path[:1])
        except ImportError:
            # Issues when importing some (sub)modules in the network module for some PyCharm installations
            full_module_file_path = 'NA'
    else:
        full_module_file_path = module_file_path

    if full_module_file_path.lower().startswith("c:"):
        envir = 'DEV'
    elif not full_module_file_path.lower().find("marketrisklibtest") == -1:
        envir = 'TEST'
    elif not full_module_file_path.lower().find("marketrisklibprod") == -1:
        envir = 'PROD'
    else:
        envir = 'NA'
        print('Not able to determine environment for path:', full_module_file_path)

    return envir


def envir_data_path(envir):
    """
    Returns the location (as path) of the data folder for the current environment

    Args:
        envir (str): Short name of the environment (DEV, TEST, PREP, PROD)

    Returns:
        (str):   Full path of the data-folder for the given environment

    Raises:

    Example:
        The module is called (from python) like this::
        
            data_location = envir_data_path('TEST')

    Notes:
        Author: g50444
    """
    if envir.upper() == 'DEV':
        envir_data_path = r'C:\working\data'
    elif envir.upper() == 'TEST':
        envir_data_path = r'\\DCD00CB-EVS01\MarketRiskLibTestData'
    elif envir.upper() == 'PROD':
        envir_data_path = r'\\DCD00HH-EVS01\MarketRiskLibProdData'
    elif envir.upper() == 'NA':
        # Envir was net determined. Library not used as intented? Data is saved to blackbook.
        envir_data_path = r'\\DCD00CB-EVS01\MarketRiskLibTestData\blackbook'
    else:
        raise KeyError('The chosen environment: ' + envir + ' is not known. Not able to return data-path.')

    return envir_data_path


def logging_path():
    """
    Returns logging path for the environment

    Author:
        g48606
    """
    envir = detect()

    if envir.upper() == 'DEV':
        envir_data_path = 'C:/working/logging/'
    elif envir.upper() == 'TEST':
        envir_data_path = '//DCD00CB-EVS01/MarketRiskLibTestData/logging/'
    elif envir.upper() == 'PROD':
        envir_data_path = '//DCD00HH-EVS01/MarketRiskLibProdData/logging/'
    elif envir.upper() == 'NA':
        # Envir was not determined. Library not used as intented? Data is saved to blackbook.
        envir_data_path = '//DCD00CB-EVS01/MarketRiskLibTestData/blackbook/logging/'
    else:
        raise KeyError('The chosen environment: ' + envir + ' is not known. Not able to return data-path.')

    return envir_data_path

def data_onedrive_path():
    """

    :return:
    (str):  Location (path) on personal onedrive folder. Intended to be used to save data

    Example:
    The module is called (from python) like this:
        data_destination = data_onedrive_path() + '\some_sub_folder'

    """
    return os.environ['USERPROFILE'] + "\OneDrive - Nordea\data_code_lib"


def logging_onedrive_path():
    """

    :return:
    (str):  Location (path) on personal onedrive folder. Intended to be used to save log

    Example:
    The module is called (from python) like this:
        data_destination = logging_onedrive_path() + '\some_sub_folder'

    """
    return os.environ['USERPROFILE'] + "\OneDrive - Nordea\logging_code_lib"



def data_path():
    """
    Returns the data path for the current environment

    Returns:
        (str):  Location (path) of the data-area for the current environment.

    Example:
        The module is called (from python) like this::
    
            data_destination = data_path() + '/some_sub_folder'

    Notes:
        Author: g50444
    """
    current_envir = detect()
    return envir_data_path(current_envir)


def guestbook_file_path():
    """
    Returns the data path for guest book files in the the current environment

    Returns:
        (str):  Location (path) of the guest book data-area for the current environment.

    Raises:

    Example:
        The module is called (from python) like this::
    
            logging_data_destination = logging_path()

    Warning:

    Notes:
        Author: g50444
    """
    import core.utils.date_helper as dateutils
    yyyymm = dateutils.date_format(dateutils.today_as_date(), 'YYYYMM')

    return data_path() + '/guestbook/' + yyyymm + '_mr_application_log.log'


def sub_cache_path(sub_path=None):
    """
    Returns the full path for a specific sub-folder in the environment specific data folder.
    The function also makes sure that the folder is created, if it does not already exist.

    Args:
        sub_path    (str):      Sub folders below the environment specific path
                                        (e.g. 'main_sub_folder/specific_sub_folder' or ['main_sub_folder','specific_sub_folder'])

    Returns:
        (str):  Location (path) of the specific sub data-area on the current environment.

    Example:
        The module is called (from python) like this::

            from core.system import envir
            application_folder = envir.sub_data_path('main_sub_folder/specific_sub_folder')

    Notes:
        Author: g50444
    """
    if sub_path is None:
        # If no sub-folder is chosen, no sub-folder is returned.
        sub_data_path = data_path() + '\\caching'
    elif isinstance(sub_path, list):
        # Input is a list, and we construct sub-folder string from the list
        sub_data_path = data_path() + '\\' + '\\'.join(sub_path)
    elif isinstance(sub_path, str):
        # Input is assumed to be a real data path, as string
        if sub_path.startswith('/') or sub_path.startswith('\\'):
            sub_data_path = data_path() + '\\caching' + sub_path
        else:
            sub_data_path = data_path() + '\\caching\\' + sub_path
    else:
        raise NotImplemented('Input is in a non-supported format. Only lists and strings are supported!')

    from core.utils import directory
    directory.create(sub_data_path)

    return sub_data_path + '\\'

def logging_onedrive_path():
    path = os.environ['USERPROFILE'] + "\OneDrive - Nordea\code_lib_logging"
    if not os.path.exists(path):
        os.makedirs(path)
    return path

def data_onedrive_path():
    path = os.environ['USERPROFILE'] + "\OneDrive - Nordea\code_lib_data"
    if not os.path.exists(path):
        os.makedirs(path)
    return path



def codelib_path():
    """
    Return the code-lib path on your computer :)

    Notes:
        Author: g48454
    """
    curr_path = os.path.realpath(__file__)
    curr_path = curr_path[0: curr_path.find("code-lib") + 8]
    return curr_path


def doclib_path():
    curr_path = os.path.realpath(__file__)
    path = str(curr_path.split("code-lib")[0]) + "doc-lib\\"
    return path


def excellib_path():
    curr_path = os.path.realpath(__file__)
    path = str(curr_path.split("code-lib")[0]) + "excel-lib\\"
    return path


if __name__ == '__main__':
    print(os.path.realpath(__file__))
    print(excellib_path())
    # path = sub_data_path(sub_path = ['caching', 'loader_name'])
    # print(path)
