select a.EOD_DATE,a.instrument_id,a.issue_type,a. risk_bucket, a.adj_notional,
                                                case when a.risk_bucket='3.1' then abs(a.adj_notional)*0
                                                     when a.risk_bucket='3.2a' then abs(a.adj_notional)*0.0025
                                                     when a.risk_bucket='3.2b' then abs(a.adj_notional)*0.01
                                                     when a.risk_bucket='3.2c' then abs(a.adj_notional)*0.016
                                                     when a.risk_bucket='3.3' then abs(a.adj_notional)*0.08
                                                     when a.risk_bucket='3.4' then abs(a.adj_notional)*0.12 end capital,50004 org_id
                                                from (
                                                select EOD_DATE,instrument_id,issue_type,risk_bucket,
                                                case when risk_bucket='3.1' then 0
                                                     when risk_bucket='3.2a' then 0.0025
                                                     when risk_bucket='3.2b' then 0.01
                                                     when risk_bucket='3.2c' then 0.016
                                                     when risk_bucket='3.3' then 0.08
                                                     when risk_bucket='3.4' then 0.12 end risk_weight,
                                                sum( adj_notional) as adj_notional from MARSP.sa_tdi_rawdata
                                                where EOD_DATE= DATE '%(date_sql)s'
                                                group by EOD_DATE,instrument_id,issue_type,risk_bucket) a