# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd
import oracledb
from sqlalchemy import create_engine
from sqlalchemy import text
import copy

os.chdir('C:\\Users\\z006554\\OneDrive - Nordea\\pythonProject\\_ValidationCodes\\SA_TDI')

# # USERPROFILE is set by default to 'C:\users\gXXXXX'
wallet_path = os.path.join(os.getenv('USERPROFILE'), 'oracle')
os.environ["TNS_ADMIN"] = wallet_path
# print(os.getenv('TNS_ADMIN'))

# Check that TNS_ADMIN is set and points towards both sqlnet.ora and tnsnames.ora
print(os.getenv('TNS_ADMIN'))

# Initialize oracledb so that your custom files are loaded
oracledb.init_oracle_client()

# Create an infop connection. Note that no credentials are inserted.
infop_connection = oracledb.connect(user='', password='', dsn='infop')
#######################################################################################################################
# GENERIC_QUERY = "SELECT *  FROM MARSP.SA_TDI_CAPITAL WHERE EOD_DATE = '31-MAY-24' AND ISSUE_TYPE = 'GOVM'"
SQL_QUERY_SA_TDI_CAPITAL = "SELECT *  FROM MARSP.SA_TDI_CAPITAL WHERE EOD_DATE = '31-MAY-24'"
SQL_QUERY_SA_TDI_RAW = "SELECT *  FROM MARSP.SA_TDI_RAWDATA WHERE EOD_DATE = '31-MAY-24'"

SQL_QUERY_POSITION_MV_H = "SELECT *  FROM MARSP.POSITION_MV_H WHERE EOD_DATE = '31-MAY-24'"
SQL_QUERY_RC_RISK_CORR = "SELECT *  FROM MARSP.RC_RISK_CORR WHERE EOD_DATE = '31-MAY-24'"
SQLtmp = "SELECT table_name   FROM all_tables"
#######################################################################################################################
connection = create_engine('oracle+oracledb://' + 'infop')

df_SA_TDI_RAW = pd.read_sql(SQL_QUERY_SA_TDI_RAW, connection)
# df_SA_TDI_RAW = df_SA_TDI_RAW.reset_index(drop=True)
df_SA_TDI_RAW.to_csv('df_SA_TDI_RAW_EOD_MAY31.csv')

df_SA_TDI_CAPITAL = pd.read_sql(SQL_QUERY_SA_TDI_CAPITAL, connection)
df_SA_TDI_CAPITAL.to_csv('df_SA_TDI_CAPITAL_EOD_MAY31.csv')

df_POS = pd.read_sql(SQL_QUERY_POSITION_MV_H, connection)
df_POS = df_POS.to_csv('df_POS_EOD_MAY31.csv')

df_RC_RISK_CORR = pd.read_sql(SQL_QUERY_RC_RISK_CORR, connection)

#######################################################################################################################


# According to Model documentation, Application SA and Application IMA  will start being used for regulatory capital
# reporting purposes, and therefore replace Regulatory SA and Regulatory IMA.
# Filter out 'SA_CALC'.
df_SA_TDI_RAW = df_SA_TDI_RAW[df_SA_TDI_RAW['update_pgm_id']=='SA_CALC_APPL']
df_SA_TDI_CAPITAL = df_SA_TDI_CAPITAL[df_SA_TDI_CAPITAL['update_pgm_id']=='SA_CALC_APPL']


df_SA_TDI_RAW = df_SA_TDI_RAW[df_SA_TDI_RAW['update_pgm_id']=='SA_CALC']
df_SA_TDI_CAPITAL = df_SA_TDI_CAPITAL[df_SA_TDI_CAPITAL['update_pgm_id']=='SA_CALC']
df_SA_TDI_RAW = df_SA_TDI_RAW.reset_index(drop=True)
df_SA_TDI_CAPITAL = df_SA_TDI_CAPITAL.reset_index(drop=True)

# ['eod_date', 'org_id', 'instrument_id', 'deal_type', 'issue_date',
#        'maturity_date', 'sp_rating', 'internal_rating', 'issue_type',
#        'collateral_type', 'issue_ccy', 'source_issuer_desc', 'instrument_name',
#        'quantity', 'mkr_val', 'national_market', 'internal_issuer',
#        'domicilie', 'currency', 'adj_notional', 'risk_bucket', 'update_pgm_id',
#        'update_datetime', 'position_grp_id']

org_id_Raw = list(df_SA_TDI_RAW['org_id'].unique())
org_id_Capital = list(df_SA_TDI_CAPITAL['org_id'].unique())





if bool([True for x in org_id_Raw if x in org_id_Capital]):
# if bool([True for x in org_id_Capital if x in org_id_Raw]):
    print("OK! org_id in SA_TDI_RAWDATA matches with SA_TDI_CAPITAL!")
else:
    print("ERROR! org_id in SA_TDI_RAWDATA does not match with SA_TDI_CAPITAL!")


instr_id_Raw = list(df_SA_TDI_RAW['instrument_id'].unique())
instr_id_Capital = list(df_SA_TDI_CAPITAL['instrument_id'].unique())
if bool([True for x in instr_id_Capital if x in instr_id_Raw]):
    print("OK! instr_id in SA_TDI_RAWDATA matches with SA_TDI_CAPITAL!")
else:
    print("ERROR! instr_id in SA_TDI_RAWDATA does not match with SA_TDI_CAPITAL!")

def checkItem(df1, df2,columnName):
   itemList1 = list(df1[columnName]).unique()
   itemList2 = list(df2[columnName]).unique()
   if bool([True for x in itemList1 if x in itemList2]):
       print("OK! instr_id in SA_TDI_RAWDATA matches with SA_TDI_CAPITAL!")
   else:
       print("ERROR! instr_id in SA_TDI_RAWDATA does not match with SA_TDI_CAPITAL!")


# Define risk weight based on 'risk_bucket'
def get_risk_weight(risk_bucket):
    if risk_bucket=='3.1':
        rw = 0
    elif risk_bucket=='3.2a':
        rw = 0.0025
    elif risk_bucket=='3.2b':
        rw = 0.01
    elif risk_bucket=='3.2c':
        rw = 0.016
    elif risk_bucket=='3.3':
        rw = 0.08
    else:
        rw = 0.12
    return rw



df_SA_TDI_RAW_FILTERED = copy.deepcopy(df_SA_TDI_RAW)

df_SA_TDI_RAW_FILTERED['risk_weight'] = df_SA_TDI_RAW_FILTERED['risk_bucket'].apply(get_risk_weight)
df_SA_TDI_RAW_FILTERED['capital'] = abs(df_SA_TDI_RAW_FILTERED['adj_notional'])*df_SA_TDI_RAW_FILTERED['risk_weight']

# df_SA_TDI_RAW_FILTERED.to_csv('df_SA_TDI_RAW_FILTERED.csv')
# df_SA_TDI_CAPITAL.to_csv('df_SA_TDI_CAPITAL.csv')

org_id_Raw = list(df_SA_TDI_RAW_FILTERED['org_id'].unique())
org_id_Capital = list(df_SA_TDI_CAPITAL['org_id'].unique())

result = []

for i in org_id_Raw:
    tmp1 = df_SA_TDI_RAW_FILTERED[df_SA_TDI_RAW_FILTERED['org_id']==i].reset_index(drop=True)
    tmp1.reset_index(drop=True)
    tmp1 = tmp1.sort_values(by=['capital'],ascending=True)
    tmp2 = df_SA_TDI_CAPITAL[df_SA_TDI_CAPITAL['org_id']==i]
    tmp2.reset_index(drop=True)
    tmp2 = tmp2.sort_values(by=['capital'],ascending=True)
    tmp = tmp1['capital'].values-tmp2['capital'].values
    result = result.append(tmp)




for i in org_id_Raw:


#######################################################################################################################
dfTmp = pd.read_csv('df_SA_TDI_CAPITAL_EOD_MAY31.csv')

dfTmp.describe()

# print(df)
#######################################################################################################################
SQL_FILE = 'fetchMARSrawData.sql'


def parse_sql(txt: str,**kwargs):
    sql_raw = ''
    if txt.__contains__('.sql'):
        with open(txt, 'r') as con:
            sql_raw = con.read()
    else:
        sql_raw = txt
    for kstr in kwargs.keys():
        sql_raw = sql_raw.replace(kstr, kwargs[kstr])
    return text(sql_raw)

kwargs = {
    '%(date_sql)s': '2024-06-03'
}

sql_query = parse_sql(SQL_FILE,**kwargs)
raw_data_final = pd.read_sql_query(sql_query, connection)

sql_netPosPerISIN_query = parse_sql('fetch_MARS_nettedPosPerISIN.sql',**kwargs)
raw_netPosPerISIN_data = pd.read_sql_query(sql_netPosPerISIN_query, connection)

#######################################################################################################################

columns = ("REPORT_DATE	MKR_SA_TDI	201409	EOD_DATE_MONTH	EOD_DATE	ORG_ID	ISIN	PRODUCT_TYPE	ISSUE_DATE	"
           "MATURITY_DATE	SP_RATING	INTERNAL_RATING	ISSUE_TYPE	COLLATERAL_TYPE	ISSUE_CCY	SOURCE_ISSUER_DESC	"
           "INSTRUMENT_NAME	CORTYPE	RSKTYPE	QUANTITY	MKR_VAL	NATIONAL_MARKET	INTERNAL_ISSUER	DOMICILIE	"
           "CURRENCY	ROW_INDEX	ADJ_NOTIONAL	RISK_BUCKET  POSITION_GRP_ID").split()

data = list(map(list, raw_data_final))
df = pd.DataFrame(data, columns=columns)
######################################################################################################################
uni_org_id = df_SA_TDI_CAPITAL['org_id'].unique()

######################################################################################################################
import datetime
from datetime import date, timedelta
import six

def to_datetime(date):
    """
    Convert date to a datetime object.

    This attempts to automatically convert input to a datetime object.
    It supports various string representations of a date and as well

    Args:
        date: date can be a string, datetime.date , datetime.datetime or panda.timestamp
    Returns:
        datetime.datetime: date converted to datetime object
    """
    if isinstance(date, six.string_types):
        if date == LAST_BUSINESS_DAY:
            return to_datetime(last_business_day())
        for f in ["%Y-%m-%d",
                  "%Y-%m-%d %H:%M:%S",
                  "%Y-%m-%d %H:%M:%S,%f",
                  "%y-%m-%d",
                  "%y-%m-%d %H:%M:%S",
                  "%y-%m-%d %H:%M:%S,%f",
                  "%Y%m%d",
                  "%Y/%m/%d",
                  "%d/%m/%Y"
                  ]:
            try:
                return datetime.datetime.strptime(date, f)
            except ValueError:
                pass
        if "," in date:  # Fallback - Oracle is using nanoseconds and time zoned sometimes...
            assert (len(date.split(",")) == 2)
            return to_datetime(date.split(",")[0])
        raise Exception("Date format not supported: %s" % str(date))
    elif type(date) is datetime.datetime:
        return date
    elif type(date) is datetime.date:
        return datetime.datetime(date.year, date.month, date.day)
    elif type(date) is pd.Timestamp:
        return date.to_pydatetime()
    else:
        print("error!")
        # logging.error("Unsupported date type %s; data: %s" % (type(date), date))
        # raise Exception("Unsupported date type: %s" % type(date))

######################################################################################################################
