# -*- coding: utf-8 -*-
"""
Calculates implied foreign exchange crosses, using quotes towards same quote currency.

Variable names and comments in this module uses the the following denomination for currency pairs:
    [Base Currency][Quote Currency] (in Mars quote currency is EUR).
Known aliases are:
    Base Currency   = Main Currency     = Foreign Currency
    Quote Currency  = Counter Counter   = Domestic Currency
        
Warning:
    The currency pairs are sometimes written with a "/" separater - as [Base Currency]/[Quote Currency].
    The meaning is however still: For 1 unit of Base Currency, how many units of Quote Currency can you buy.
    
    The logical way of writing this would however be: amount of [Quote Currency] per 1 [Base Currency], which
    in unit terms should be written as [Quote Currency]/[Base Currency] - which is REVERSE to the commonly
    used currency pair denotation. Don't let this fool you!
    
Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       27JAN2017   G50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import numpy as np

def calc(base_currency_quotes,
         currency_name_key     = 'currency_id',
         currency_quote_key    = 'price',
         precision_decimals    = 12,
         info                  = 0
         ):
    """
    Calculate (all) implied fx crosses based on quotes with EUR as quote currency

    Given a number of input currency quotes, all with EUR as quote (or counter or domestic) currency,
    all implied currency cross quotes are calculated.

    As an example, based on quotes for USDEUR and DKKEUR, DKKUSD - as well as all 3 inverse currency pairs are
    returned.
    In matrix form, where "in" is input and "calc" is calculated by the module::
    
                              Quote Currency
                            EUR     USD     DKK
                        EUR calc    calc    calc
         Base Currency  USD in      calc    calc
                        DKK in      calc    calc

    Args:
        base_currency_quotes    (list of dicts):    Containing currency names and quotes, stored in dict elements with names
                                                    matching what is stated in the following two "key" parameters
        currency_name_key       (str):              Name of the element in the dict that holds the short name of the currency
        currency_quote_key      (str):              Name of the element in the dict that holds the quotes
                                                    (how many EUR can be bought for 1 unit of the base currency)
        precision_decimals      (int):              Number of decimals in the output
        info                    (int):              Level of information printed. The higher, the more information is printed
    Returns:
        (list of dicts):  Implied FX cross pairs in a list of dicts

    Raises:

    Example:
        The module is called (from python) like this::

            from core.market_data import fx_cross
            fx_pairs = fx_cross.calc(base_currency_quotes    = [{'currency_name': 'USD', 'price': 0.941358097},{'currency_name': 'DKK', 'price': 0.134405245}],
                                     currency_name_key       = 'currency_name',
                                     currency_quote_key      = 'price',
                                     precision_decimals      = 12,
                                     info                    = 0
                                     )

    Warning:
        Please note that this function is designed only to calculate fx cross for ONE DAY. If it should be used
        calculated fx crosses for a time series, please either change the function, or loop over for each date

        Input should be XXXEUR, which is the common denotation for amounts of EUR paied to get 1 XXX. 
        This choice has been made to make it easy to use data from Mars, which uses this convention.
        If something else is needed, please change the hard coded "input_quote_currency = 'EUR'" into an input parameter,
        defaulting to EUR, and/or change it.

    Notes:
        Author: g50444
    """

    ############################################################################
    # Section 1: Initial Validations
    ############################################################################
    
    dict_keys = base_currency_quotes[0].keys()

    if info > 0:
        print('Dictionary keys:', dict_keys)

    if currency_name_key not in dict_keys:
        raise KeyError('The key',currency_name_key, 'which is expected to hold currency names is not in input dictionary')

    if currency_quote_key not in dict_keys:
        raise KeyError('The key',currency_quote_key, 'which is expected to hold currency quotes is not in input dictionary')

    input_quote_currency = 'EUR'

    ############################################################################
    # Section 2: Splitting currency denotation and quotes
    ############################################################################

    base_currency   = []
    quote           = []

    # Adding counter currency with quote = 1 to data
    base_currency.append(input_quote_currency)
    quote.append(1)

    # ===================================================================================
    # Creating two lists.
    #   - quote         : Contains currency quotes  (e.g. 0.1344)
    #   - base_currency : Contains the names of the names of the base (foreign) currency
    #                     (e.g. DKK)
    # If the "quote currency" is among the input quotes, it is discarded (it should be
    # equal to 1, and is hard-coded as such by the function - making it optional to
    # provide it as part of the input).
    # ===================================================================================

    for currency_quote in base_currency_quotes:
        currency_name   = currency_quote[currency_name_key]
        currency_quote  = currency_quote[currency_quote_key]
        if not currency_name == input_quote_currency:
            base_currency.append(currency_name)
            if currency_quote == 0:

                raise ZeroDivisionError('Currency quote for',currency_name,' is zero - which is not expected')
            else:
                quote.append(currency_quote)

    if info > 0:
        print('base_currency:',base_currency)

    ############################################################################
    # Section 3: Calculating FX Crosses using Numpy
    ############################################################################

    # Transforming quotes into vector, so the crosses can be calculated using matrix operations
    P = np.mat(np.array(quote)).T
    if info > 0:
        print(80*'=')
        print(P)
        print(80*'=')

    # FX Quotes are transposed and inverted, to span out the inverse quotes (Base/Counter -> Counter/Base)
    PT = (1/P.T)

    CROSS = P * PT

    if info > 0:
        print('FX Cross Matrix:',CROSS)

    ############################################################################
    # Section 4: Creating list of dicts with implied currency crosses
    ############################################################################

    fx_quotes       = []
    fx_pairs_dict   = {}

    for i in range(0,len(CROSS)):
        for j in range(0,len(CROSS)):
            fx_pairs_dict["base_currency"]          = base_currency[j]
            fx_pairs_dict["quote_currency"]         = base_currency[i]
            fx_pairs_dict["currency_pair_label"]    = base_currency[j] + base_currency[i]

            if base_currency[j] == base_currency[i]:
                # Making sure, that no numerical imprecision causes conversion factor from A to A being different than 1
                fx_pairs_dict["quote"] = 1.0
            else:
                fx_pairs_dict["quote"] = round(CROSS.item(j,i),precision_decimals)

            # Appending dict to list
            fx_quotes.append(fx_pairs_dict)

            # Clearing dict at end of loop. This MUST be done to avoid all rows in fx_quotes list to be identical
            fx_pairs_dict = {}

    if info > 0:
        print('FX Cross List:',fx_quotes)

    return fx_quotes