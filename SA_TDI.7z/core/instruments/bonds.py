"""
The module collect a few loaders that used to download static information for bonds product

Notes:
    Author: gxxxxx

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       ddmonyyyy   G12345      Initial creation
    ======= =========   =========   ========================================================================================
"""

import json

import requests

from core.connection import credentials
from core.market_data import market_data_loader


class BondCoreInfoLoader(market_data_loader.StaticDataLoader):
    def __init__(self, ISINs,load_from_source=False, cache_path=None):
        market_data_loader.StaticDataLoader.__init__(self, names=ISINs,
                                                     load_from_source=load_from_source,
                                                     cache_path=cache_path)


    def return_unique_name(self):
        identifier_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for identifier in identifier_list:
            out[self.startd, identifier] = '_'.join([self.__class__.__name__,
                                                     str(identifier)])
        return out

    def source_loading_function(self,isins,eod_date):
        auth = credentials.get_HttpNtlmAuth()
        webservice = 'http://mds.oneadr.net/v1/instrument/coreinformation/bonds'
        service_arg = webservice + '?isins=' + ",".join(isins) + '&format=json'
        response = requests.get(url=service_arg
                                        , auth=auth
                                        )
        data = json.loads(response.content)
        out = {}
        for item in data['Result']:
            out[eod_date,item['ISIN']] = item
        return out


class IssuerLoader(market_data_loader.StaticDataLoader):
    def __init__(self, ISINs,load_from_source=False, cache_path=None):
        market_data_loader.StaticDataLoader.__init__(self, names=ISINs,
                                                     load_from_source=load_from_source,
                                                     cache_path=cache_path)


    def return_unique_name(self):
        identifier_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for identifier in identifier_list:
            out[self.startd, identifier] = '_'.join([self.__class__.__name__,
                                                     str(identifier)])
        return out

    def source_loading_function(self,isins,eod_date):
        auth = credentials.get_HttpNtlmAuth()

        webservice = 'http://mds.oneadr.net/v1/instrument/coreinformation/issuers'
        service_arg = webservice + '?isins=' + ",".join(isins) + '&format=json'
        response = requests.get(url=service_arg
                                        , auth=auth
                                        )
        data = json.loads(response.content)
        out = {}
        for item in data['Result']:
            out[eod_date,item['Isin']] = item
        return out

if __name__ == '__main__':
    import pandas as pd
    obj1 = BondCoreInfoLoader(
        ISINs=["XS1218217377", "US91911TAK97", "NO0010459910", "FR0012870061", "XS1327531486", "GR0133011248",
               "DK0002032382", "DK0004914462"])
    df = pd.DataFrame.from_dict(obj1.data,orient='index')
    print(df)