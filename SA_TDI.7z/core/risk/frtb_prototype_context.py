import sys

import core.risk.frtb_credit.dependency_tests as dependency_tests

from core.types import PricingEngine
from core.utils.singleton import Singleton


class ContextManager(Singleton):
    def __init__(self):
        self.global_tenor_buckets = ['1D', '7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y',
                                     '12Y', '15Y', '20Y', '25Y', '30Y', '50Y']

    def check_dependency(self, *args, **kwargs):
        if self.dependency_fulfilled is None:
            print("Check Dependency...")
            df = dependency_tests.run_test(*args, **kwargs)
            print("Dependency check result:")
            print(df)
            l = df.Result.tolist()
            if l.count(False) > 0:
                self.dependency_fulfilled = False
                print("There is a dependency problem, prototype aborted!")
                sys.exit()
            else:
                self.dependency_fulfilled = True


class BondContextManager(ContextManager):
    def __init__(self):
        from core.risk.frtb_credit import scenario_convert
        ContextManager.__init__(self)
        self.bond_curve_source = 'marsp'
        self.bond_price_source = 'MDS'
        self.resultFilePath = 'default'
        self.rate_scenario = 'DAMDS'
        self.credit_curve_scenario = 'ORCA'
        self.bond_future_price_source = 'MDS'
        self.dependency_fulfilled = None
        self.scenario_convert_method = scenario_convert.convert_scenario_via_zero_harzard_rate_sub
        self.check_dependency(['INFOP', 'DAMDS', 'TWP', 'TWP_RO', "DAMDP_RO", "TRMP",'MDS', 'PYTHON_VERSION'])  # TODO: Obtain this automatically using the dir() function to find attributes



class BondFutureContextManager(ContextManager):
    def __init__(self):
        from core.risk.frtb_credit import scenario_convert
        ContextManager.__init__(self)
        self.bond_curve_source = 'marsp'
        self.bond_price_source = 'MDS'
        self.resultFilePath = 'default'
        self.rate_scenario = 'DAMDS'
        self.credit_curve_scenario = 'ORCA'
        self.bond_future_price_source = 'MDS'
        self.dependency_fulfilled = None
        self.scenario_convert_method = scenario_convert.convert_scenario_via_zero_harzard_rate_sub
        self.check_dependency(['INFOP', 'DAMDS', 'TWP', 'TWP_RO', "DAMDP_RO", "TRMP",'MDS', 'PYTHON_VERSION'])  # TODO: Obtain this automatically using the dir() function to find attributes




class CDSContextManager(ContextManager):
    def __init__(self):
        from core.risk.frtb_credit import scenario_convert
        ContextManager.__init__(self)
        self.resultFilePath = 'default'
        self.rate_scenario = 'DAMDS'
        self.credit_curve_scenario = 'ORCA'
        self.cds_buckets = ["2Y","5Y","10Y"]
        self.dependency_fulfilled = None
        self.pricing_engine = PricingEngine.ORCA
        self.scenario_convert_method = scenario_convert.convert_scenario_via_zero_harzard_rate_sub
        self.check_dependency(['ORCA',"DAMDS"])
        self.scenarios_in_scope = self.decide_scenario_in_scope

    @staticmethod
    def decide_scenario_in_scope(x):
        names = ['CREDIT.HAZARD.', 'OIS.CURVE', 'CREDIT.RECOVERY','FX.SPOT']
        return any([name in x for name in names])
# ===================================================================================
# context manager for fx
# ===================================================================================
class FXContextManager(ContextManager):
    def __init__(self):
        ContextManager.__init__(self)
        self.rate_scenario = 'DAMDS'
        self.fx_scenario = 'DAMDS'
        self.pricing_engine = PricingEngine.ORCA
        self.scenarios_in_scope = self.decide_scenario_in_scope

    @staticmethod
    def decide_scenario_in_scope(x):
        names = ['CREDIT.HAZARD.', 'OIS.CURVE', 'CREDIT.RECOVERY', 'FX.SPOT']
        return any([name in x for name in names])