
"""
Module for calculation of various risk measures based on a PL vector. Supports VaR and ES - read functions for details

Two implementations are currently available in the module, and they are split in two different classes.
Class RiskMeasures calculates VaR/ES but approximating to the nearest integer as index
Class InterpolatedRiskMeasures handles cases where (VaR/ES) percentiles fall between integer index values. Compliant
with TRIM (Feb 2017).

Notes:
    Author: G46474 -- Joerg Wegener

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       ddmonyyyy   G46474      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    1       18jun2019   G54713      OK          Added comments and extended InterpolatedRiskMeasures.expected_shortfall
                                                to handle both profit and loss case.
    ======= =========   ========    =========   ============================================================================
"""

from collections import namedtuple
import numpy as np
import pandas as pd
from enum import Enum


class PercentileOrientation(Enum):
    LOWER = 0
    UPPER = 1


class ProfitLosses(Enum):
    LOSSES = 0
    PROFIT = 1


class RiskMeasures:
    """
    This class holds calculated results for all defined risk measures. It takes as input a PL vector (distribution of
    profits and losses), and uses it to measure risk
    """
    def __init__(self, pl_vector, percentile, percentile_orientation):
        self.series = pl_vector if isinstance(pl_vector, pd.Series) else pd.Series(pl_vector)
      #  self.values = pl_vector.values.tolist()
        self.percentile = percentile
        self.percentile_orientation = percentile_orientation
        self.no_of_scenarios = len(pl_vector)

        self.p_value, self.tail = self._get_tail()
        self.value_at_risk = self._value_at_risk()
        self.expected_shortfall = self._expected_shortfall()

    def __str__(self):
        sb = []
        for key in self.__dict__:
            if key not in ('series', 'values', 'percentile', 'percentile_orientation', 'p_value', 'tail', 'no_of_scenarios'):
                sb.append(str(key) + "='{:,.2f}'".format(self.__dict__[key].value))
        return '%s(%s)' % (self.__class__.__name__, ', '.join(sb))

    def __repr__(self):
        return self.__str__()

    def _get_tail(self):
        if self.series.empty:
            print("Vector is empty, returning: p_value=None, tail = {}.")
            out = None, {}
        else:
            pl_sorted = self.series.sort_values(ascending=True)
            idx = int(np.ceil(self.no_of_scenarios * self.percentile))   # TODO: ceil() should be replaced with round()

            if self.percentile_orientation is PercentileOrientation.LOWER:
                idx = max(0, idx-1)
                tail = pl_sorted[:idx].to_dict()
            elif self.percentile_orientation is PercentileOrientation.UPPER:
                tail = pl_sorted[idx:].to_dict()
                idx = max(0, idx-1)
            else:
                raise TypeError("Wrong input: 'percentile_orientation' must be of type PercentileOrientation.")

            p_value = namedtuple('p_value', 'value scenario')(pl_sorted[idx], pl_sorted.index[idx])
            out = p_value, tail
        return out

    def _value_at_risk(self):
        var_val = min(0, self.p_value.value)
        var = namedtuple('Value_at_Risk', 'value scenario')(var_val, self.p_value.scenario)
        return var

    def _expected_shortfall(self):
        padded_tail = self.tail.copy()
        padded_tail.update({self.value_at_risk.scenario: self.value_at_risk.value})
        es_val = min(0., float(np.mean(list(padded_tail.values()))))
        es = namedtuple('Expected_Shortfall', 'value scenarios')(es_val, padded_tail)
        return es


def get_tail(vector, percentile, percentile_orientation):
    # " 0 < percentile <= 1"
    # " percentile_orientation (PercentileOrientation)
    # "better name: rank_something"


    series = vector if isinstance(vector, pd.Series) else pd.Series(vector) # If vector is just an array (as oposed to pd.Series), this operation will index the array with integers, starting at zero
                                                                            #  (which, in this way, is equal to "ordinary" array indexing).
    vn = len(series)

    try:
        assert (vn > 0)  # False -> vector empty

        p = percentile
        v = series.sort_values()
        # vector.sort_values(...'ascending') keeps it a Pandas.Series to extract dates from.
        idx = int(np.round(vn * p))  # TODO: implement interpolation, see numpy.percentile(). Verified by matching ´perc_historic = [98.8, 98.99, 99.19, 99.39, 99.59, 99.79]´ with MARS indices: ´array([6., 5., 4., 3., 2., 1.])´.
        # print("Percentile: {perc}   |  MARS index: {idx}".format(perc = (1-p)*100, idx=idx))
        #idx = int(np.ceil(vn * p))  # matches VAR (i.e. ES) calculation in MARS.
        if percentile_orientation is PercentileOrientation.LOWER:
            idx = max(0, idx - 1)  # "idx-1": index starts at zero, "len()" at one. [i:e], i = inclusive, e = exclusive.
            tail = v[:idx]
        elif percentile_orientation is PercentileOrientation.UPPER:
            tail = v[idx:]
            idx = max(0, idx - 1)
        else:
            raise TypeError("Wrong input: 'percentile_orientation' must be of type PercentileOrientation.")

        p_value = v[idx:idx+1]

    except AssertionError:
        p_value = None
        tail = []
        print("Vector is empty, returning: p_value = None & tail = [].")
    finally:
        # return p_value, tail, ts_index # make it Pandas.Series compatible
        return {'p_value': p_value, 'tail': tail}


def value_at_risk(vector, percentile):
    """
    Calculation of value at risk for a given percentile. Calculates the percentile of the return vector

    Args:
        vector     (list type): A list type of returns
        percentile     (float): The cutoff percentile to calculate value-at-risk for

    Notes:
        Author: Joerg Wegener
    """
    tail = get_tail(vector, percentile, PercentileOrientation.LOWER)
    var = tail['p_value'].to_dict()
    #TODO: we need discuss whether the floor below makes sense.
    var = {key: min(0, value) for key, value in var.items()}
    return var


def expected_shortfall(vector, percentile):
    """
    Calculation of expected shortfall. Includes the quantile point, i.e. it calculates
    ES = E[X*1_{X<=percentile}] where X is the return distribution and 1_{...} the indicator function.

    Args:
        vector     (list type): A list type of returns
        percentile     (float): The cutoff percentile to calculate expected shortfall for

    Returns:
        (float): The expected shortfall

    Notes:
        Author: Joerg Wegener
    """
    # TODO: define ES properly, see "TODOs" below.
    # TODO: clarify negative sign (probably sgn() needed)
    # TODO: min(0, loss) needed?

    tail_calc = get_tail(vector, percentile, PercentileOrientation.LOWER)
    tail = tail_calc['tail']
    var = tail_calc['p_value']
    padded_tail = tail.append(var)
    es = np.mean(padded_tail)
    # TODO: we need discuss whether the floor below makes sense.
    es = min(0, es)
    return dict(es=es, tail=padded_tail.to_dict(), var=var.to_dict(), no_of_scenarios=len(vector))


def calculate_twosided_ES(vector, percentile):
    # TODO: Probably better to switch 1-percentile -> 'lower' and percentile -> 'upper'.
    # TODO (cont.): In order to be more consistent with the definition of the "ordinary" ES, where 0.99 means top 99% percentile of LOSSES.
    low  = get_tail(vector, percentile, PercentileOrientation.LOWER)
    high = get_tail(vector, 1 - percentile, PercentileOrientation.UPPER)
    es_l = np.mean(low.get('tail') + [low.get('p_value')])
    es_h = np.mean(high.get('tail') + [high.get('p_value')])
    return {'ES_low': es_l, 'ES_high': es_h}


def remove_outliers(vector):
    # removes (date, value)-pairs from pandas.Series if
    #            value > mean + 2 * sigma
    #     or
    #            value < mean + 2 * sigma
    # of timeseries. Note, this is a symmetric criteria, which can be simplified into one criterion.

    mn = np.mean(vector)
    sd = np.sqrt(np.var(vector))

    c = 2 * sd
    bol = (abs(vector.values - mn) < c)  # keep those
    # vector[np.logical_not(bol)]) # throw away
    return vector[bol]


class InterpolatedRiskMeasures(object):
    """Handling cases where (VaR-) percentiles fall between integer index values -- compliant with TRIM.
    """

    def __init__(self, plvector):
        self.plvector = pd.Series(plvector).sort_values(ascending=True)  # guarantee ascending order.
        self.samplesize = len(self.plvector)

    def value_at_risk(self, percentile):
        """
        Linearly interpolated Value-at-Risk.

        Symmetric when flipping tails, i.e. VaR(99%) -> VaR(1%) when order of return vectors changes from ascending
        (enforced) -> descending.
        Implementation of equation in TRIM (Feb 2017), paragraph 116 of section 5.2 ("Data inputs"). In pseudo-code:

        var = w_hi * self.plvector[i_lo] + w_lo * self.plvector[i_hi]
        where i_lo, i_hi, w_lo and w_hi are obtained from function interpolate_percentile
        Even though it may see confusing to combine the lower index to the high weight and viceversa, this is exactly
        what done in the Regulatory text. Also, this will make sense on the expected_shortfall measure, see next fct.

        Args:
            percentile        (float):   99% VaR -> percentile = 0.99.
                                         Requirement: 0 + 1 / self.samplesize < percentile < 1 - 1 / self.samplesize

        Returns:
            (float):   Value-at-Risk (VaR)

        Example:
            The module is called (from python) like this::

                pl_vec = [-4, -3, -2, -1, 0, 1, 2]
                irm = InterpolatedRiskMeasures(plvector=pl_vec)
                var = irm.value_at_risk(percentile=0.75)

        Notes:
            Author: G46474 -- Joerg Wegener
            Review & Comments: g54713 -- Elena Bossolini (18/06-2019)
        """
        # TODO: additionally return scenario (ids/dates) of worst scenarios -- pd.Series supports that natively.
        d = interpolate_percentile(self.samplesize, percentile)
        idx_hi, idx_lo = d['i_hi']-1, d['i_lo']-1  # Subtracting 1 because of Python index starting with 0.
        wgt_hi, wgt_lo = d['w_hi'], d['w_lo']
        var = wgt_hi * self.plvector.iloc[idx_lo] + wgt_lo * self.plvector.iloc[idx_hi]
        return var

    def expected_shortfall(self, quantile, profitlosses):
        """
        Linearly interpolated Expected Shortfall. Calculates both ES of losses and of gains.

        ES for losses (profits) is defined as the weighted average of the worse losses (best profits) up the the
        quantile considered.
        **ES 99% Losses (Profits) calculates ES(1%) (ES(99%), respectively) when ordering the pl_vector in ascending
        order.**

        It could also include an business example:
        A trade that has the characteristics A and B, will be treated this way,
        and interesting stuff will be calculated. All ending up with C being returned.

        Args:
            quantile        (float):   99% ES -> quantile = 0.99.
                                        Requirement: 0 + 1 / self.samplesize < quantile < 1 - 1 / self.samplesize
            profiltlosses    (enum):   instance of the class ProfitLosses.

        Returns:
            (float):   Expected Shortfall (ES)

        Raises:
            <TypeError: Wrong input: 'profitlosses' must be of type ProfitLosses.>

        Example:
            The module is called (from python) like this::

                    pl_vec = [-4, -3, -2, -1, 0, 1, 2]
                    irm = InterpolatedRiskMeasures(plvector=pl_vec)
                    es = irm.expected_shortfall(quantile=0.75, profitlosses=ProfitLosses.LOSSES)
                    # returns es = -3.5
                    es_profit = irm.expected_shortfall(quantile=0.75, profitlosses=ProfitLosses.PROFIT)
                    # returns es_profit = 1.5

        Notes:
            Author: G46474 -- Joerg Wegener
            Review & Comments: g54713 -- Elena Bossolini (18/06-2019)
        """
        var_interpolated = self.value_at_risk(quantile)  # VaR at the (interpolated) percentile
        d = interpolate_percentile(self.samplesize, quantile)  # get index and corresponding weight
        if profitlosses == ProfitLosses.LOSSES:
            idx_lo = d['i_lo']-1  # Subtracting 1 because of Python index starting with 0.
            w_lo = d['w_lo']
            # remainder VaRs in lower tail
            vars = self.plvector.iloc[0:idx_lo+1]  # slicing [:stop] takes up to stop-1
            result = 1. / (len(vars) + w_lo) * (np.sum(vars) + w_lo * var_interpolated)  # weigthed sum, vars have weight 1
        elif profitlosses == ProfitLosses.PROFIT:
            idx_hi = d['i_hi'] - 1  # Subtracting 1 because of Python index starting with 0.
            w_hi = d['w_hi']
            # remainder VaRs in upper tail
            vars = self.plvector.iloc[idx_hi:]
            result = 1. / (len(vars) + w_hi) * (np.sum(vars) + w_hi * var_interpolated)  # weigthed sum, vars have weight 1
        else:
            raise TypeError("Wrong input: 'profitlosses' must be of type ProfitLosses.")
        return result


def interpolate_percentile(samplesize, quantile):
    """
        Interpolates (VaR) percentiles that fall between integer index values -- compliant with TRIM.

    Implementation of equation in TRIM (Feb 2017), paragraph 116 of section 5.2 ("Data inputs"). In pseudo-code:

            var = w_hi * self.plvector[i_lo] + w_lo * self.plvector[i_hi]

    **Note:** Indices (e.g. 'i_hi') are assumed to start with 1, not with 0 -- the latter is the Python way, the former
    the MARS way. That means, if used for indexing in Python arrays, one must substract 1, see method value_at_risk(),
    above.

    Assumes ordered (ascending) return vector.

    This approach ensures symmetry when flipping tails, i.e. VaR(99%) -> VaR(1%) when order of return vectors changes
    from ascending -> descending.

    The procedure is very close to linear interpolation with "samplesize += 1".

        Args:
            samplesize      (int):      Samplesize of P&L vector, e.g. 499, 249 etc.
            quantile        (float):   99% ES -> quantile = 0.99.
                                        Requirement: 0 + 1 / self.samplesize < quantile < 1 - 1 / self.samplesize

        Returns:
            (dict):   dictionary containing indices (e.g. `i_hi`) and corresponding weights (e.g. `w_hi`)

    Author:
        G46474 -- Joerg Wegener


    **Examples:**

       >>> interpolate_percentile(samplesize=499, quantile=0.988)
       >>> # {'i_hi': 7, 'i_lo': 6, 'w_hi': 5.329070518200751e-15, 'w_lo': 0.9999999999999947}

       >>> odd_pl_vec = [-4, -3, -2, -1, 0, 1 ,2]
       >>> samplesize = len(odd_pl_vec) # samplesize = 7 in this case
       >>> quantile = 0.75  # 75% of the observations should be above and the remaining 25 below,
       >>> # since odd_pl_vec is in ascending order. This means that we should take the 6th starting from right or the
       >>> # 2nd starting from left, i.e. 8*0.75 = (samplesize+1)*quantile = 6  from the right
       >>> # or i = 8*(1-0.75) = (samplesize+1)*(1-quantile) = 2 from the left.
       >>> interpolate_percentile(samplesize, quantile)
       >>> # {'i_hi': 3, 'i_lo': 2, 'w_hi': 1.0, 'w_lo': 0.0}
       >>> # as expected i_lo = 2, that is the second element of the pl vector
    """

    import math

    # avoiding indices to fall out of bounds:
    assert(quantile >= 0+(1/samplesize))
    assert(quantile <= 1-(1/samplesize))

    # Given a pl vector in ascending order [-4, -3, -2, -1, 0, 1 ,2],
    i = (samplesize+1.) * (1 - quantile)   # index in return vector

    mod = math.modf(i)
    intgr = mod[1]  # integer part
    frac = mod[0]  # floating point part
    i_lo = int(intgr)
    i_hi = i_lo + 1

    w_lo = frac
    w_hi = 1 - w_lo

    return {'i_lo': i_lo, 'i_hi': i_hi, 'w_lo': w_lo, 'w_hi': w_hi}


def interpolate_percentile_strict(samplesize, percentile):
    '''
        JUST FOR TESTING PURPOSES. DELETE.

    Implementation of equation in TRIM (Feb 2017), paragraph 116 of section 5.2 ("Data inputs"). In pseudo-code:

    v = return_vector # ascending order, first index = 1, not 0.
    VAR = w_hi * v[i_hi] + w_lo * v[i_lo]

    *Note:* Indices (e.g. 'i_hi') above are assumed to start with 1, not with 0 -- the latter is the Python way. That means,
    if used for indexing in Python arrays, one must substract 1, see method value_at_risk(), above.

    The procedure is very close to linear interpolation with "samplesize += 1".

    This approach ensures symmetry when flipping tails, i.e. VaR(99%) -> VaR(1%) when order of return vectors changes from ascending -> descending.

    Assumes ordered (ascending) return vector.

    0 < percentile < 1

    :return:
    '''

    import math

    n = samplesize
    p = percentile

    assert (p >= 0 + (1 / n))
    assert (p <= 1 - (1 / n))

    q = 1 - p  # flipping tails
    i = (n+1.)* q   # index in return vector
                    # q now in percent (100/100 cancel)

    mod = math.modf(i)
    intgr = mod[1] # integer part
    frac  = mod[0] # floating point part

    if frac <= 1e-18:
        intgr -= 1

    i_lo = int(intgr)
    i_hi = i_lo + 1

    # weights corresponding to i_hi & i_lo, see preamble.
    w_hi = frac
    w_lo = 1 - w_hi

    return {'i_lo':i_lo, 'i_hi':i_hi,
            'w_lo':w_lo, 'w_hi':w_hi}


def linear_interpolate_percentiles(samplesize, percentile):
    """
    Linear interpolation of (VaR) percentiles that fall between integer index values.

    Very close to interpolate_percentile(samplesize-1, percentile), but less convoluted.

    :param samplesize: Samplesize of return vector, e.g. 499, 249 etc.
    :param percentile: 0 < percentile < 1, such that 99% VaR -> percentile = 0.99
    :return: weights and indices


    Author:
     G46474 -- Joerg Wegener
    """

    samplesize += 1
    p = np.ones(shape=samplesize) * 1./samplesize  # probability of receiving any one of the elements from the sample in one draw.
    cp = np.cumsum(p) # cumulative probability
    result = np.interp(percentile, cp, range(1,samplesize+1))  # interpolate map of: probabilities to index (starting with 1)

    return result

    ## Below code works, but only used to break results into weights.
    # m = np.modf(result)
    # frac = m[0]
    # integr = m[1]
    #
    # w_hi = frac
    # w_lo = 1 - frac
    #
    # i_lo = integr
    # i_hi = i_lo + 1
    #
    # return {'i_lo':i_lo, 'i_hi':i_hi,
    #         'w_lo':w_lo, 'w_hi':w_hi}


if __name__ == '__main__':

#    Example TRIM, para 166
    samplesizes = (250, 260)
    percentiles = 0.99,

    for s in samplesizes:
        for p in percentiles:
            res = interpolate_percentile(s, p)
            print(f'{s}, {p}, {res}')
            w = res.get('w_lo') + res.get('w_hi')

## TABLE:

    samplesizes = (497, 498, 499, 500, 501, 502, 503)  # (250, 260, 249, 499, 100, 101)
    percentiles =  0.988, # 0.012, 0.988 #(0.01, 0.99) #, 0.975, 0.988)

    print("samplesize    VAR%    IDX_LO,         W_HI,              IDX_HI,           W_LO")
    print("----------------------------------------------------------------------------------------------")
    for s in samplesizes:
        for p in percentiles:
            res = interpolate_percentile(s, p)
            print('     ', s, '   ', p*100, '   ', int(res.get('i_lo')),  '     ', res.get('w_hi'), '       ',
                  int(res.get('i_hi')), '        ', res.get('w_lo'), '    ')


# PLOTTING:
#---------------------------------------------------------------------------

    result = []
    for s in samplesizes:
        for p in percentiles:
            res = interpolate_percentile(s,p)
            result.append(res['w_lo']*res['i_hi'] + res['w_hi']*res['i_lo'])


    import matplotlib.pyplot as plt
    plt.plot(samplesizes, result, '--', label='interpolate_percentile(...)')

#---------------------------------------------------------------------------

    result = []
    for s in samplesizes:
        for p in percentiles, :
            q = 1-p[0]
            res = linear_interpolate_percentiles(s,q)
            result.append(res)

    plt.plot(samplesizes, result,'*',label='linear_interpolate_percentiles(...)')
    plt.legend()
    plt.show()


#    print(linear_interpolate_percentiles(100, 0.99))
#    print(linear_interpolate_percentiles(100, 0.01))
#    print(linear_interpolate_percentiles(250, 0.01))
#    print(linear_interpolate_percentiles(100, 0.01)) #0.012)) # 98.8% VaR
#    print(linear_interpolate_percentiles(100, 0.99))