from numpy import NaN
from pandas import DataFrame, DatetimeIndex


class Backtesting(object):

    """Identification and investigation of regulatory backtest exceptions.

      Common use-case:
             fact = P&L
             fiction = VaR

      Author: G46474 -- Joerg Wegener.
    """


    def __init__(self, fact, fiction):
        self.fact = fact
        self.fiction = fiction
        self.exceptions = fiction.gt(fact)

    def is_exception(self):
        # Truncated Series of boolean True's -> exceptions.
        ex = self.exceptions
        return ex[ex]

    def has_exceptions(self):
        # True -> at least one exception, False otherwise.
        return any(self.is_exception())

    def get_exceptions(self):
        # Truncated Series of dates and corresponding overshootings.
        ex = self.exceptions
        return (self.fiction[ex] - self.fact[ex])

    def count_exceptions(self):
        # Number of (element-wise) 'fiction' > 'fact'.
        return self.is_exception().size

    def exception_dates(self):
        # List of datetime.date corresponding to overshootings.
        return self.is_exception().index.date

    def exception_values(self):
        # List of overshootings.
        return self.get_exceptions().values

    def difference(self):
        # 'fiction - fact', filling missing values with NAN.
        return self.fiction.sub(self.fact, fill_value=None)

    def has_same_dates(self):
        # True if dates in 'fact' and 'fiction' coincide.
        return  not self.difference().hasnans

    def days_since_exception(self, dates, calendar):
        """ Days (according to calendar ''calendar'') passed since exception.

        Parameters
        ----------
        dates: collection of datetime.date or sortable strings, e.g. "2018-10-25": Dates must be present in ''calendar''.

        calendar: collection of datetime.date or sortable strings

        Returns:
        -------
        pandas.DataFrame with exception dates as columns names.

        Each item in the calendar is assumed to have 1 (business)-day "distance" to previous item.
        That means, if e.g. weekends are to be counted, they need to be included in the calendar.
        """
        xdates = self.exception_dates()
        calendar = sorted(calendar)  # ensure ascending order
        calendar = dict(zip(calendar, range(len(calendar))))  # map calendar days to integers
        data = {}
        for xdate in xdates:
            days_since = []
            for date in dates:
                dummy = calendar[date] - calendar[xdate]  # assumes all dates & xdates to be valid keys.
                dummy = dummy if dummy >= 0 else NaN
                days_since.append(dummy)
            data[xdate] = days_since

        return DataFrame(data, index=DatetimeIndex(dates))

    @staticmethod
    def count_active_exceptions(df, func):
        """
        Number of simultaneously active (as controlled by ''func'') exceptions as time series.

        Parameters:
        -----------

        df : output from ''Backtesting.days_since_exception()''

        func : callable that results in boolean, e.g. ''lambda x: (x>5) & (x<7)''. True -> indicates exception on given day and is counted.


        Returns:
        --------

        pandas.Series of simultaneous exceptions.


        Example:  # needs defined: fact, fiction, calendar
        --------

        >>> bt = Backtesting(fact, fiction)
        >>> df = bt.days_since_exception(calendar, calendar)
        >>> bt.count_active_exceptions(df, lambda x: (x<=250))  # Simultaneous exceptions in running 250-day window.

        """

        df1 = func(df)
        return df1.sum(axis=1) # sum over rows. Treats True as 1 and False as 0. Done.



if __name__ == '__main__':
    import pandas as pd

    # create dummy data.
    index = pd.date_range(start='20180101', periods=10)
    fiction = pd.Series(range(10), index=index)

    # manipulate s.th. fact != fiction.
    indices = index[[2, 5, 9]]
    fact = fiction.copy(deep=True)
    fact[indices] -= 3.3 , 2, 4

    # same, but with missing values
    #fact[indices] = np.nan

    bt = Backtesting(fact, fiction)

    # print(bt.is_exception())
    # print(bt.has_exceptions())
    print(bt.get_exceptions())
    print(bt.exception_dates())
    print(bt.exception_values())
    # print(bt.count_exceptions())
    # print(bt.difference())
    # print(bt.has_same_dates())

    calendar = index.date
    day = calendar[9]
    df = bt.days_since_exception(calendar, calendar)
    print(df)
    print(100*'-')
    cs = bt.count_active_exceptions(df, lambda x: (x<=4))
    print(cs)