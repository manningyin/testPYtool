# ===================================================================================
# Assumption:
# 1 now we get the cds curve from gotc , it is inconsistent with the treatment of single credit bond, future all these curves should move to DAMDS...
# ===================================================================================

import datetime

import core.risk.frtb_prototype_context as context_manager
import pandas as pd
import quantum as qt
from core.risk.frtb_credit import cds_utili
try:
    from core.risk.frtb_fx import fx_util
except:
    pass
from core.risk.frtb_prototype import frtb_prototype
from orca.trades.trade_handler import TradeHandler
from pandas.tseries.offsets import BDay

import core.pricing.model_factory
from core.caching.cache_driver import easy_cache
from core.market_data import market_data_loader
from core.system import ext_envir
from core.utils import RawTimeSeries
from core.utils import market_data_cache
from core.connection import orca_connect


class cds_prototype(frtb_prototype):
    def __init__(self, trade_id_lists, name, analysisStartDate, analysisEndDate, resultFilePath='default',
                 context_instance=None):
        # call the frtb prototype
        frtb_prototype.__init__(self, Pos_Lists=trade_id_lists,
                                name=name,
                                analysisStartDate=analysisStartDate,
                                analysisEndDate=analysisEndDate,
                                resultFilePath=resultFilePath)
        # get context
        if context_instance is None:
            context_instance = context_manager.CDSContextManager.get_instance()

        # assign all attributes
        self.cds_source = context_instance.credit_curve_scenario
        self.rate_source = context_instance.rate_scenario

        self.rate_buckets =context_instance.global_tenor_buckets
        self.cds_buckets = context_instance.cds_buckets
        self.record_cds_buckets = self.cds_buckets if len(self.cds_buckets) < 360 else [str(i) + 'M' for i in range(1,360,1)]
        self.scenario_convert_method = context_instance.scenario_convert_method
        self.scenarios_in_scope = context_instance.scenarios_in_scope
        self.trade_identifier = cds_utili.generate_orca_identifier(self.Position_Lists)
        self.pricing_engine = context_instance.pricing_engine

        # added by Oskar
        self.models = {}
        self.credit_names = {}
        self.leg_fixings = {}
        self.model_factories = {}
        self.scenario_names = []
        self.scenario_mapping = {}

        self.req = orca_connect.get_orca_request()

        # self.get_info_for_cds()
        # self.get_cds_curve_id()
        #self.attach_trade_handler()

    def attach_trade_handler(self):
        self.cfg = ext_envir.ORCA().config
        self.req = orca_connect.get_orca_request()
        self.hf = self.req.get_holiday_factory_for_all_centers().result()
        self.trade_handler = TradeHandler(self.cfg, self.req, self.hf)

    def loadALLMarketDATAintoCache(self,loadStressedInformation=False):
        tempCacheSet = market_data_cache.marketDataCacheSet(name='cacheList')
        print("--- Start loading market data ---")
        datacaches = self.load_market_data_in_range(
            dateRange=self.analysisRange)

        #if loadStressedInformation:
        #    risk_free_cache_stress, cds_rate_cache_stress= self.load_market_data_in_range(
        #       dateRange=self.stressedRange)
        #    risk_free_cache= risk_free_cache.append_another_cache(risk_free_cache_stress)
        #   cds_rate_cache = cds_rate_cache.append_another_cache(cds_rate_cache_stress)

        for datacache in datacaches:
            tempCacheSet.append(datacache)

        self.attachMarketDataCacheSet(tempCacheSet)

    @staticmethod
    def get_credit_curve_from_qt_linear_credit_model(model):
        credit_curve = model.getMarketData().creditCurves[0]
        return credit_curve

    def get_credit_curves_from_qt_model(self,scenario):
        out = RawTimeSeries.RawTimeSeries(name="temp")
        already_loaded_scenario_and_dates = []
        for position in self.Position_Lists:
            for d in self.analysisRange:
                try:
                    qt_model = self.models[d,position,1]
                except Exception as e:
                    self.trackError(errorMessage=e, date=d,
                                    comments='Do not find qt model for trade : ' + position)
                    continue
                scenario_for_this_pos = self.scenario_mapping[d,position,1]
                if  (scenario in scenario_for_this_pos) and ((d,scenario) not in already_loaded_scenario_and_dates):
                    credit_curve = self.get_credit_curve_from_qt_linear_credit_model(qt_model)
                    out.addItem(credit_curve,d)
                    already_loaded_scenario_and_dates.append((d,scenario))
        return out

    def load_market_data_in_range(self, dateRange):
        out = []
        for scenario in self.return_all_scenario_name_in_scope():
            if scenario.find('CREDIT.HAZARD.') > -1:
                cdsCurveCache = self.get_credit_curves_from_qt_model(scenario)
                cdsCurveCache.name = scenario
                if len(cdsCurveCache.cacheDate)>0:
                    out.append(cdsCurveCache)
            elif ".RATE." in scenario or ".DISC." in scenario:
                riskFreeRateCache = market_data_loader.IrCurveLoader(name=scenario,
                                                                     startd=dateRange[0],
                                                                     endd=dateRange[-1],
                                                                     source=self.rate_source).data
                riskFreeRateCache.name = scenario
                if len(riskFreeRateCache.cacheDate) > 0:
                    out.append(riskFreeRateCache)
            elif '.SPOT' in scenario:
                fxSpotCache = fx_util.orca_fx_scenario_data_loader(orca_fx_id=scenario,
                                                                   startd=dateRange[0],
                                                                   endd=dateRange[-1])

                fxSpotCache_rawts = RawTimeSeries.RawTimeSeries(name = scenario)
                for (d,value) in fxSpotCache.items():
                    fxSpotCache_rawts.addItem(value,d)
                out.append(fxSpotCache_rawts)

        return out

    def fetch_models_and_scenarios(self):
        print("--- fetching models and scenario from ORCA ---")
        trade_identifiers = cds_utili.generate_orca_identifier_for_imcc_prototype(self.Position_Lists)

        models = core.pricing.model_factory.ModelFactoryLoader(trade_ids=trade_identifiers,
                                                               startd=self.analysisStartDate,
                                                               endd=self.analysisEndDate).data

        for (eod_date,trades) in models:
            model_list = models[eod_date,trades]
            models_for_this_date = {}
            legs_for_this_date = {}
            for (model,leg) in model_list:
                trade_id = leg.trade_info.__getattribute__('trade_id').encode()
                trade_leg_id = leg.trade_info.__getattribute__('trade_leg_id')
                models_for_this_date[eod_date, trade_id, trade_leg_id] = model
                legs_for_this_date[eod_date, trade_id, trade_leg_id] = (leg.get_leg(), leg.fixings)

            self.models.update(models_for_this_date)
            self.leg_fixings.update(legs_for_this_date)

        for key, model in self.models.items():
            scenario_item = [name.label for name in qt.getMarketDataScenarioNames(model)]
            self.scenario_mapping[key] = [x for x in scenario_item if self.scenarios_in_scope(x)]
            self.scenario_names += scenario_item
        self.scenario_names = list(set(self.scenario_names))
        # self.scenario_names = [x for x in self.scenario_names if x in self.return_all_scenario_name_in_scope()]

    @staticmethod
    def parse_orca_pricing_result(orca_result, trade_id):
        # this is a strange implementation but don't touch it until there is a better way of doing this...
        out = None
        for item in orca_result:
            if "result" in item.keys():
                if item['result'] is not None:
                    if item['result']['trade_id'] == trade_id.decode():
                        out = item['result']['value_in_base_currency_leg_1'] + item['result']['value_in_base_currency_leg_2']
                        break

        if out == None:
            raise Exception
        else:
            return out

    @staticmethod
    def parse_orca_pricing_result_local_ccy(orca_result, trade_id):
        # this is a strange implementation but don't touch it until there is a better way of doing this...
        out = None
        for item in orca_result:
            if "result" in item.keys():
                if item['result'] is not None:
                    if item['result']['trade_id'] == trade_id.decode():
                        out = item['result']['value_leg_1'] + item['result'][
                            'value_leg_2']
                        break

        if out == None:
            raise Exception
        else:
            return out

    @staticmethod
    def make_rate_curve_scenario(curve1, curve2):
        d_l = []
        r_l = []
        for d in list(set(curve1._get_dates() + curve2._get_dates())):
            rate = curve2.getVal(d) - curve1.getVal(d)
            d_l.append(d)
            r_l.append(rate)

        curve_type = curve1._get_typename()
        if curve_type is u'CurveCatrom':
            return qt.CurveCatrom.make(d_l, r_l)
        elif curve_type is u'CurveFlat':
            return qt.CurveFlat.make(d_l, r_l)
        elif curve_type is u'CurveLinear':
            return qt.CurveLinear.make(d_l, r_l)
        else:
            return qt.CurveLinear.make(d_l, r_l)

    def fetch_orca_scenario_request(self,scenario,scenario_qt):
        if self.is_forward_rate_scenario(scenario):
            return {'name': scenario,
                         'type': "ADDITION_IN_FORWARD_RATES",
                         'data': scenario_qt[scenario]}
        if self.is_cds_scenario(scenario):
            return {'name': scenario,
                    'type': self.get_cds_bump_type_orca(),
                    'data': scenario_qt[scenario]}
        else:
            return {'name': scenario,
                    'type': "ADDITION",
                    'data': scenario_qt[scenario]}

    @staticmethod
    def is_forward_rate_scenario(scenario):
        return ".RATE.FWD." in scenario

    @staticmethod
    def is_cds_scenario(scenario):
        return "CREDIT.HAZARD." in scenario

    @staticmethod
    def is_ois_scenario(scenario):
        return "OIS.CURVE" in scenario

    @staticmethod
    def is_recovery_scenario(scenario):
        return "CREDIT.RECOVERY" in scenario

    @staticmethod
    def is_fx_spot_scenario(scenario):
        return "FX.SPOT" in scenario

    def keep_cds_scenario_to_dataframe(self, qt_scenario, d1, d2, scenario):
        if "cds scenario" not in self.resultDataFrameName:
            self.resultDataFrameName.append("cds scenario")
            self.resultDataFrameList.append(pd.DataFrame())
        temp_data = [d1,d2,scenario] + [qt_scenario.getVal(qt.addTenor(d2,bucket)) for bucket in self.record_cds_buckets]
        temp_cols = ['d1', 'd2', 'scenario'] + self.record_cds_buckets
        temp_df = pd.DataFrame(data=[temp_data] , columns=temp_cols)
        idx = self.resultDataFrameName.index("cds scenario")
        self.resultDataFrameList[idx] = self.resultDataFrameList[idx].append(temp_df)



    def make_scenario_in_qt_format(self,d1,d2,scenario):

        if self.is_recovery_scenario(scenario):
            corresponding_hazard_name = scenario.replace("CREDIT.RECOVERY", "CREDIT.HAZARD")
            datacache = self.marketDataCache.getObjectFromCacheSet(corresponding_hazard_name)
            curve_d1 = datacache.getvalue(d1)
            curve_d2 = datacache.getvalue(d2)
            out = curve_d2.recoveryRate - curve_d1.recoveryRate
        elif  self.is_fx_spot_scenario(scenario):
            datacache = self.marketDataCache.getObjectFromCacheSet(scenario)
            r1 = datacache.getvalue(d1)
            r2 = datacache.getvalue(d2)
            out = r2 - r1
        else:
            datacache = self.marketDataCache.getObjectFromCacheSet(scenario)
            curve_d1 = datacache.getvalue(d1)
            curve_d2 = datacache.getvalue(d2)
            if self.is_cds_scenario(scenario):
                out = self.scenario_convert_method(buckets=self.cds_buckets,
                                                   credit_curve1=curve_d1,
                                                   credit_curve2=curve_d2,
                                                   anchorDate=d2)
                self.keep_cds_scenario_to_dataframe(qt_scenario=out,
                                                    d1=d1,
                                                    d2=d2,
                                                    scenario=scenario)
            else:
                out = self.make_rate_curve_scenario(curve_d1, curve_d2)
        return out

    def calculate_HPL(self,d1,d2):
        valuation_d1 = self.call_orca_for_price(d=d1,trade_list=self.Position_Lists)
        valuation_d2 = self.call_orca_for_price(d=d2,trade_list=self.Position_Lists)
        return valuation_d1,valuation_d2

    def make_qt_scenarios(self,d1,d2):
        scenario_qt = dict()
        for scenario in self.return_all_scenario_name_in_scope():
            try:
                scenario_qt[scenario] = self.make_scenario_in_qt_format(d1, d2, scenario)
            except Exception as e:
                self.trackError(errorMessage=e, date=d1,
                                comments='Can not make scenario for name: ' + scenario)
                continue
        return scenario_qt

    @staticmethod
    def merge_two_dicts(x, y):
        z = x.copy()  # start with x's keys and values
        z.update(y)  # modifies z with y's keys and values & returns None
        return z


    def RTPLcalculation(self):
        df = pd.DataFrame()
        from core.imcc_prototype import rtpl_service

        trade_identifiers = cds_utili.generate_orca_identifier_for_imcc_prototype(self.Position_Lists)
        for d1 in self.analysisRange[:-1]:
            d2 = d1 + BDay(1)
            print('---start RTPL calculation for:' + d1.strftime('%Y%m%d'))
            # ===================================================================================
            # Generate the scenario
            # ===================================================================================
            scenario_qt = self.make_qt_scenarios(d1,d2)
            all_orca_scenario = []
            for scenario in self.return_all_scenario_name_in_scope():
                try:
                    scenario_orca = self.fetch_orca_scenario_request(scenario, scenario_qt)
                    all_orca_scenario.append(scenario_orca)
                except Exception as e:
                    self.trackError(errorMessage=e, date=d1,
                                    comments='Can not call orce to perform scenario valuation for scenario ' + scenario)
                    continue

            pl_service = rtpl_service.RTPL_Service(positions=trade_identifiers,
                                                   eod_date=d1,
                                                   pricing_engine=self.pricing_engine,
                                                   scenario_list= all_orca_scenario)
            temp_df = pl_service.aggregated_pl_results()

            df = df.append(temp_df)

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('RTPL_All')

    def decomp_scenario_into_buckets(self,scenario, cds_scenario_curve,d1):
        out_result = {}
        for bucket in self.cds_buckets:
            unit_bump = cds_scenario_curve.getVal(qt.addTenor(d1,bucket))
            unit_bump_curve = qt.CurveLinear.make([qt.addTenor(d1,bucket)],[unit_bump])
            scenario_orca = {'name': scenario,
                    'type': self.get_cds_bump_type_orca(),
                    'data': unit_bump_curve}
            new_scenario_name = scenario + "." + bucket
            out_result[new_scenario_name] = self.call_orca_for_price_use_ci(d=d1,  # HAVE CHANGED TO d1 from d2
                                                                   trade_list=self.Position_Lists,
                                                                   scenario_orca=[scenario_orca])

        return out_result


    def get_bump_type_qt(self, scenario):
        if self.is_cds_scenario(scenario):
            bump = self.get_cds_bump_type_qt()
        else:
            bump = "A"
        return bump

    def get_cds_bump_type_qt(self):
        if self.scenario_convert_method.func_name in ["convert_scenario_via_zero_harzard_rate_multiply", "convert_scenario_via_zero_harzard_rate_multiply_with_one"]:
            return "M"
        elif self.scenario_convert_method.func_name is "convert_scenario_via_zero_harzard_rate_sub":
            return "S"
        else:
            return "A"

    def get_cds_bump_type_orca(self):
        if self.scenario_convert_method.func_name is "convert_scenario_via_zero_harzard_rate_multiply":
            return "MULTIPLICATION"
        elif self.scenario_convert_method.func_name is "convert_scenario_via_zero_harzard_rate_sub":
            return "SUBSTITUTION"
        else:
            return "ADDITION"

    def return_all_scenario_name_in_scope(self):
        out = []
        for scenario in self.scenario_names:
            if self.scenarios_in_scope(scenario):
                out.append(scenario)
        return out

        # out = []
        # for scenario in self.scenario_names:
        # # filter out all foward scenario since it does not create any differences..
        #     if self.is_cds_scenario(scenario) or self.is_ois_scenario(scenario) or self.is_recovery_scenario(scenario):
        #         out.append(scenario)
        # return out

    @staticmethod
    @easy_cache()
    def call_orca_for_price(d, trade_list, scenario_orca=None):
        trade_identifiers = cds_utili.generate_orca_identifier(trade_list)
        if scenario_orca is None:
            scenario_orca =[]

        if type(scenario_orca) is not list:
            scenario_orca = [scenario_orca]

        req = orca_connect.get_orca_request()
        print('--- call orca ---')
        temp = req.request_price(
                time_stamp=orca_connect.get_orca_timestamp(d),
                model_configuration_name='ORCA_REVAL_CDS',
                trade_identifiers=trade_identifiers,
                scenarios=scenario_orca).result()
        print('--- orca has come back the result')
        print(temp)
        return(temp)


    def call_orca_for_price_use_ci(self, d, trade_list, scenario_orca=None):
        trade_identifiers = cds_utili.generate_orca_identifier(trade_list)
        if scenario_orca is None:
            scenario_orca = []

        if type(scenario_orca) is not list:
            scenario_orca = [scenario_orca]


        print('--- call orca ---')
        temp = self.req.request_price(
            time_stamp=orca_connect.get_orca_timestamp(d),
            model_configuration_name='ORCA_REVAL_CDS',
            trade_identifiers=trade_identifiers,
            scenarios=scenario_orca, use_grid=True).result()
        print('--- orca has come back the result')
        print(temp)
        return (temp)

    def analysis_curves(self, trade_id):
        from core.graphics.curve import compare_two_curves
        for curr_idx in range(0, len(self.analysisRange) - 1):
            currt = self.analysisRange[curr_idx]
            d1 = currt
            d2 = d1 + BDay(1)
            qt_model_d2 = self.models[d1, trade_id, 1]
            rtpl_model_d1 = self.rtpl_models[d1,trade_id,1]
            credit_curve_fo = self.get_credit_curve_from_qt_linear_credit_model(qt_model_d2)
            credit_curve_risk = self.get_credit_curve_from_qt_linear_credit_model(rtpl_model_d1)
            target_date_list = [qt.addTenor(d2,x) for x in self.cds_buckets]
            risk_prob_list = []
            fo_prob_list = []
            for d in target_date_list:
                risk_prob_list.append(1 - credit_curve_risk.survivalProb(d))
                fo_prob_list.append(1 - credit_curve_fo.survivalProb(d))
            risk_prob_curve = qt.CurveLinear.make(target_date_list, risk_prob_list)
            fo_prob_curve = qt.CurveLinear.make(target_date_list, fo_prob_list)
            compare_two_curves(risk_prob_curve,fo_prob_curve,d2.date(),['rtpl_prob','fo_prob'])




if __name__ == '__main__':
    from time import time
    from core.risk import frtb_prototype_context
    from core.types import PricingEngine

    context = frtb_prototype_context.CDSContextManager.get_instance()

    context.pricing_engine = PricingEngine.ORCA

    startDate = datetime.datetime(2017, 7, 1)
    endDate = datetime.datetime(2017, 7, 4)

    tempOBJ = cds_prototype(name='analysis',
                            trade_id_lists=["2571361","test"],#['2304262','2032527','2711269','2711267','2671405','2670028','2616535','2570782','2328795','2238438','2210153','2710900','2710899','2692816','2692798','2350017','2275363','2270181','2214569','2710363','2678207','2500569','2500547','2356206','2310004'],
                            analysisStartDate=startDate,
                            analysisEndDate=endDate,
                            context_instance= context
                                      )

    ts = time()
    tempOBJ.fetch_models_and_scenarios()
    te = time()
    print('took: %2.4f sec') % (te - ts)
    tempOBJ.loadALLMarketDATAintoCache()

    ts = time()
    tempOBJ.RTPLcalculation()
    te = time()
    print('took: %2.4f sec') % (te - ts)

    tempOBJ.plAttribution()
    tempOBJ.writeResultToExcel()