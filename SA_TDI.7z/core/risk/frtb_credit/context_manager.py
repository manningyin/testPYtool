import core.risk.frtb_credit.dependency_tests as dependency

from core.utils.singleton import Singleton


class context_manager(Singleton):
    def __init__(self):
        self.bond_curve_source = 'marsp'
        self.bond_price_source = 'MDS'
        self.resultFilePath = 'default'
        self.rate_scenario = 'DAMDS'
        self.credit_curve_scenario = 'ORCA'
        self.global_tenor_buckets = ['1D','7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '12Y','15Y', '20Y', '25Y', '30Y', '50Y']
        self.cds_buckets = ['28M','52M','76M','112M']
        self.dependency_fulfilled = None
        self.check_dependency()



    def check_dependency(self):
        if self.dependency_fulfilled == None:
            print("Check Dependency...")
            df = dependency.run_test()
            print("Depencency check result:")
            print(df)
            l = df.Result.tolist()
            if l.count(False) > 0:
                self.dependency_fulfilled = False
            else:
                self.dependency_fulfilled = True

