'''
bond utili module, the functions here can be used outside credit prototype application.

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       30jan2017   g48454      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''

import json
import os
import pyodbc
from datetime import datetime

import pandas as pd
import quantum as qt
import requests

import core.connection.credentials as credential
import core.connection.database_extract as database_extract
import core.risk_factor.factory.rates.domain
from core.caching.cache_driver import easy_cache
from core.connection import database_connect
from core.connection.database_connect import return_sql_engine
from core.utils.date_helper import oracle_to_date
from core.utils.version_independent import return_main_qt_version


def get_global_buckets():
    return list(core.risk_factor.factory.rates.domain.PRICING_FACTOR_IR_BUCKETS)

webservice = 'http://mds.oneadr.net/v1/instrument/coreinformation/bonds'

def get_core_information(ISIN_Lists):
    '''
    The function try to get the core information from the ISIN, by using the following webservice
    http://mds.oneadr.net/v1/instrument/coreinformation/bonds

    Args:
        ISIN_Lists                   (int):              List of ISINs

    Returns:
        df    (DataFrame):   Core information for the isins


    Notes:
        Author: g48454
    '''

    auth = credential.get_HttpNtlmAuth()
    df=pd.DataFrame()
    for isin in ISIN_Lists:
        try:
            service_arg = webservice + '?isins=' + isin + '&format=json'
            print(service_arg)
            response = requests.get(url=service_arg
                                    , auth=auth
                                    )
            data = json.loads(response.content)
            df = pd.DataFrame(data['Result'])
        except:
            continue
    return df


def get_static_information(ISIN_Lists):
    '''
        The function try to get the issuer information from the webservice
        http://mds.oneadr.net/v1/instrument/coreinformation/issuers

        Args:
            ISIN_Lists                   (int):              List of ISINs

        Returns:
            df    (DataFrame):   Issure information for the isins


        Notes:
            Author: g48454
    '''
    auth = credential.get_HttpNtlmAuth()
    df = pd.DataFrame()
    column_list = ['Isin',
                   'Name',
                   'Prefix',
                   'IssuerTypeDescription',
                   'Country']
    for isin in ISIN_Lists:
        try:
            service_arg = webservice + '?isins=' + isin + '&format=json'
            response = requests.get(url=service_arg
                                    , auth=auth
                                    )
            data = json.loads(response.content)
            colData = [data['Result'][0][x] for x in column_list]
            df = df.append(pd.DataFrame(data=[colData], columns=column_list))
        except:
            continue
    return df


def get_issuer_information(ISIN_Lists):
    '''
        The function try to get the issuer information from the webservice
        http://mds.oneadr.net/v1/instrument/coreinformation/issuers

        Args:
            ISIN_Lists                   (int):              List of ISINs

        Returns:
            df    (DataFrame):   Issure information for the isins


        Notes:
            Author: g48454
    '''
    auth = credential.get_HttpNtlmAuth()
    df = pd.DataFrame()
    column_list = ['Isin',
                   'Name',
                   'Prefix',
                   'IssuerTypeDescription',
                   'Country']
    for isin in ISIN_Lists:
        try:
            service_arg = webservice + '?isins=' + isin + '&format=json'
            response = requests.get(url=service_arg
                                    , auth=auth
                                    )
            data = json.loads(response.content)
            colData = [data['Result'][0][x] for x in column_list]
            df = df.append(pd.DataFrame(data=[colData], columns=column_list))
        except:
            continue
    return df

def get_ratings(ISIN_Lists,source='INFOP'):
    rating_list=[]
    for ISIN in ISIN_Lists:
        if source=='DAMDP':
            rating=database_extract.select_from_query(info=0,
                                           database='DAMDP',
                                           query=return_rating_query_DAMDP(ISIN)
                                           )
        elif source=='INFOP':
            rating = database_extract.select_from_query(info=0,
                                                        database='INFOP',
                                                        query=return_rating_query_mars(ISIN)
                                                        )

        if not rating:
            rating_list.append('na')
        else:
            rating_list.append(rating[0])
    return rating_list


def return_rating_query_DAMDP(ISIN):
    return '''select cr.valid_from_date,spr.description
             FROM ANASYS.ISSUERS I
             JOIN ANASYS.CREDIT_RATINGS cr
            ON I.ISSUER_ID     =cr.ISSUER_ID
            join anasys.sp_ratings spr on cr.SP_RATING_ID=spr.RATING_ID
            WHERE I.ISSUER_ID IN
            (SELECT bi.ISSUER_ID
            FROM ANASYS.BOND_INFO bi
            WHERE bi.EFFECT_ID IN
            (SELECT sn.EFFECT_ID
            FROM ANASYS.SECURITY_NAMES sn
            WHERE sn.DESCRIPTION IN (\'''' + ISIN + '''\' )))
            order by cr.valid_from_date desc
            '''

def return_rating_query_mars(ISIN):
    return ''' select ora.SP_Rating as rating from marsp.effect e
           join marsp.org o on e.ISSUER_ORG_ID=o.ORG_ID
           join marsp.org_rating ora on e.issuer_org_id=ora.ORG_ID
          where 1=1
         and e.DATA_SOURCE_IDENTITY in
         (\'''' + ISIN + '''\' )
         AND ora.EOD_DATE>sysdate -5
         order by ora.EOD_Date desc
         '''

def get_static_information_for_bond_future(sukeys):
    '''
        The function try to get the bond futures information from the webservice
        http://mds.oneadr.net/V1/instrument/coreinformation/bonds/futures?sukeys=154609570

        Args:
            sukeys                   (str):              List of sukeys

        Returns:
            df    (DataFrame):   all static info on Bond Futures


        Notes:
            Author: g50091
    '''
    bond_future_service = "http://mds.oneadr.net:80/v1/instrument/coreinformation/bonds/futures"
    auth = credential.get_HttpNtlmAuth()
    df = pd.DataFrame()
    underlying_df = pd.DataFrame()
    column_list = ['SUKey',
                   'Currency',
                   'DayCountConvention',
                   'LotSize',
                   'ExpiryDate',
                   'ProductType',
                   'FirstTrade',
                   'LastTrade',
                   'FirstDelivery',
                   'LastDelivery',
                   'BbTicker',
                   'Exchange',
                   'MIC',
                   'NordeaShortName',
                   'SettlementType',
                   'CtdISIN']
    for sukey in sukeys:
        try:
            service_arg = bond_future_service + '?sukeys=' + sukey +'&format=json'
            response = requests.get(url=service_arg
                                    , auth=auth
                                    )
            data = json.loads(response.content)
            dicColData = data['Result'][0]
        except Exception as e:
            print(e)
            continue

        try:
            colData = [dicColData.get(x) for x in column_list]
            df = df.append(pd.DataFrame(data=[colData], columns=column_list))

            Underlyings = dicColData.get('Underlying')
            single_su_key_underlying_df = pd.DataFrame.from_dict(Underlyings)
            single_su_key_underlying_df["su_key"] = sukey
            underlying_df = underlying_df.append(single_su_key_underlying_df)
        except Exception as e:
            print(e)
            continue
    return df, underlying_df

def return_all_isins_in_prototype_scope(folder = None):
    # ===================================================================================
    # read all text file in the isin lists folder
    # ===================================================================================
    if folder is None:
        folder = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/20 Data/FRTB Credit/BatchLoader/ISIN Lists/'
    full_list = []

    for filename in os.listdir(folder):
        if filename.endswith('.txt'):
            tempfile = open(folder + filename, 'r')
            isin_list = tempfile.read().split('\n')
            tempfile.close()
            full_list = full_list + isin_list
    # =========================================================================F==========
    # remove duplicates if any
    # ===================================================================================

    full_list = list(set(full_list))

    # ===================================================================================
    # validate to see if the length of isin is 12
    # ===================================================================================

    full_list = [x for x in full_list if len(x) == 12]

    return full_list

def format_isin_list_to_sql_string(isin_list):
    list_isin_key = ""
    for i in range(0, len(isin_list)):
        list_isin_key = isin_list[i] + ", " + list_isin_key

    list_isin_key = list_isin_key[:-2]

    tmp = ""
    for i, m in enumerate(list_isin_key.replace(' ', '').split(',')):
        tmp = tmp + m + "','"

    list_isin_key = tmp[:-3]
    list_isin_key = "'" + list_isin_key + "'"

    return list_isin_key



# ===================================================================================
# A qt version independent implementation for curve construction
# ===================================================================================
def curve_make(datelist,ratelist):
    if return_main_qt_version() > 12:
        return qt.CurveCatrom.make(datelist, ratelist)
    else:
        raise Exception('qt version not supported')


# ===================================================================================
# get the ir curve from the FRTB_HS_INTEREST_RATE table
# ===================================================================================
def return_ir_curve_from_marsp(name,date):
    engine=return_sql_engine()
    df=pd.read_sql("select * from MARSP.FRTB_HS_INTEREST_RATE where eod_date = :eod_date and interest_id = :interest_id"
            , params = {'eod_date' : date, 'interest_id': int(name) }
            ,con=engine)
    return df


def return_bond_curve_from_marsp(curvename,date):
    '''
    The code below load the table from marsp database, now the table direct to the bond curve table created by Johan in market data management team

    Warning:
        before run this code, ask Johan to make sure you have access to his table...

    Example:
        A testing script can be found below
        import core.market_data.bond_curve_loader as bond_curve
        import datetime
        curvename='DKKMTGNYKSOFTBLT'
        d1=datetime.datetime(2016,1,1)
        d2=datetime.datetime(2016,3,1)
        data=bond_curve.extract_curve_from_marsp(curvename,d1,d2)

    Notes:
        Author: g48454
    '''


    sql = ''' select a.info_date as info_date, a.Tenor as time, a.data_point as rate, a.Time_Convention
    from G47193.ANALYTICS_CURVES a
    where
    a.curve = (select curve_id from G47193.BOND_CURVE_CONTEXT
    where
    ROWNUM <=1
    and
    short_name like :curve_name)
    and a.info_date = :eod_date
    order by info_date,time
    '''
    engine = return_sql_engine()
    return pd.read_sql(sql, con=engine, params = {'curve_name': curvename, 'eod_date': date})

# ===================================================================================
# function to get qToolkit curves for bond curve
# ===================================================================================
def make_qt_curve_from_db(bond_curve_df,currDateTime):
    tempRateList = bond_curve_df['rate'].tolist()
    tempTenorList = bond_curve_df['time'].tolist()
    qtTenorList = [qt.addTenor(currDateTime,yearfrac_to_qt_tenor(j)) for j in tempTenorList]
    try:
        qt_bond_curve = curve_make(qtTenorList , tempRateList)
        return qt_bond_curve
    except:
        raise Exception

def make_qt_curve_from_db_ir(ir_curve_df, currDateTime):
    tempRateList = ir_curve_df['interest_pct'].tolist()
    tempTenorList = ir_curve_df['term_id'].tolist()
    qtTenorList = [qt.addTenor(currDateTime, j) for j in tempTenorList]
    try:
        qt_bond_curve = curve_make(qtTenorList, tempRateList)
        return qt_bond_curve
    except:
        raise Exception

# ===================================================================================
# convert year fraction to qt tenor
# ===================================================================================
def yearfrac_to_qt_tenor(argument):
    # ===================================================================================
    # This code transfer the year fraction to something can be recognized by qToolkit
    # ===================================================================================
    try:
        if argument < 0.083:
            # if within 1m, return xD
            return str(int(round(argument * 365))) + 'D'
        elif argument < 1:
            # if within 1m, return xM
            return str(int(round(argument * 12))) + 'M'
        elif argument >= 1:
            i, d = divmod(argument, 1)
            if d > 0.0001:
                # if larger than 1Y but have decimal part, return xM
                # example 1.5 -> 18M
                return str(int(round(argument * 12))) + 'M'
            if d == 0:
                return str(int(round(argument))) + 'Y'
        else:
            return str(int(round(argument))) + 'Y'
    except:
        print('--error in convertion')


# ===================================================================================
# generate bond swap basis between ir curve and bond curve
# ===================================================================================
def convert_bond_swap_basis(bond_curve_df,IR_curve_df,asofdate):
    # geneerate the bond curve
    tempDateList = []
    tempRateList = []
    qtcurve = make_qt_curve_from_db(bond_curve_df, currDateTime=asofdate)
    for index, row in IR_curve_df.iterrows():
        currdate=qt.addTenor(asofdate,row['TERM_ID'])
        tempDateList.append(currdate)
        tempRateList.append(qtcurve.getVal(currdate) - row['INTEREST_PCT']/100)
    return curve_make(tempDateList, tempRateList)


# ===================================================================================
# generate the bond swap basis curve as of two qt curves
# ===================================================================================
def convert_bond_swap_basis_qt(bond_curve_qt,ir_curve_qt,tenors,asofdate):
    tempDateList = []
    tempRateList = []
    for tenor in tenors:
        currdate=qt.addTenor(asofdate,tenor)
        tempDateList.append(currdate)
        tempRateList.append(bond_curve_qt.getVal(currdate) - ir_curve_qt.getVal(currdate))
    return curve_make(tempDateList, tempRateList)


# ===================================================================================
# add zspread on top of the discount curve
# ===================================================================================
def add_zspread_on_disc_curve(disc_curve,zspread):
    return qt.DiscCurveWithZSpread.make(disc_curve, zspread)


# ===================================================================================
#
#                      Below is an example code
#
# ===================================================================================

# a simple pricing functions by using zero coupon cash flow
def pricing(currt, t, disc_curve):
    d = [qt.datetime.datetime(2016, 6, 20), t]
    h = [0, 0]  # input
    hc = qt.CurveFlat.make(d, h)
    cc = qt.CreditCurveInterpolated.make("empty", "EUR", currt, hc, 0.4)

    # test the hazard curve delta from a dummy bond based on this dummy hc
    dates = [t]
    amounts = [100]
    amorts = qt.CashFlow.make(dates, amounts)
    # define coupon cash flow
    amounts = [0]
    coupons = qt.CashFlow.make(dates, amounts)
    # define bond cash flow
    bond = qt.BondCashFlow.make(amorts, "0D", coupons, "1M")
    if qt.__version__ == u'0.13':
        return qt.bondCashFlowPvCc(disc_curve, cc, bond)
    elif qt.__version__ == u'0.11':
        return qt.bondCashFlowPV_CC(disc_curve, cc, bond)
    else:
        return qt.bondCashFlowPV(disc_curve, cc, bond)


def parse_qt_curve_to_json(qtcurve):
    return json.dumps(dict(zip([datetime.strptime(x, '%d%b%Y').date().isoformat() for x in qtcurve.riskLabels()], qtcurve.values())))

def parse_qt_curves_to_tenors(qtcurve, asofdate , buckets = None):
    if buckets is None:
        buckets = get_global_buckets()
    rates=[]
    for tenor in buckets:
        date= qt.addTenor(asofdate,tenor)
        rates.append(qtcurve.getVal(date))
    return dict(zip(buckets,rates))

def convert_bond_swap_basis_qt(bond_curve_qt,ir_curve_qt,asofdate, buckets = None):
    # geneerate the bond curve
    if buckets is None:
        buckets = get_global_buckets()
    tempDateList = []
    tempRateList = []
    for bucket in buckets:
        currdate=qt.addTenor(asofdate,bucket)
        tempDateList.append(currdate)
        tempRateList.append(bond_curve_qt.getVal(currdate) - ir_curve_qt.getVal(currdate))
    return curve_make(tempDateList, tempRateList)

@easy_cache()
def get_bond_future_pos_from_trmp(portfolio, eod_date):
    sql = """ SELECT REPORT_DATE, PORTFOLIO, to_char(INSTRUMENT_SU_KEY) as SU_KEY, BB_TICKER, CURRENCY, sum(LOTS) as lots
            FROM FCUSER.PLX_T_RNG_TOTAL_OUTPUT 
            WHERE  portfolio = '%s'
            AND REPORT_DATE = %s
            and POSITION_INDICATOR = 'TRUE'
            and INSTRUMENT_TYPE = 'FUTURE'
            group by REPORT_DATE, PORTFOLIO, INSTRUMENT_SU_KEY, BB_TICKER, CURRENCY""" \
          %(portfolio,oracle_to_date(eod_date))
    string = database_connect.return_trmp_string()
    df = pd.read_sql_query(sql, pyodbc.connect(string))
    return(df)



if __name__ == '__main__':
    currt=datetime(2016, 10, 6)
# ===================================================================================
# get the SEK Libor curve from INFOP table (9251)
# ===================================================================================

    print(get_bond_future_pos_from_trmp(portfolio="STKRED", eod_date = currt))
    ir_curve=return_ir_curve_from_marsp(name="9251",date=currt)
# ===================================================================================
# get the Bond Curve from INFOP table, this one is the swedish govt bond curve
# ===================================================================================
    bond_curve=return_bond_curve_from_marsp(curvename='SEKGOV',date=currt)

# ===================================================================================
# make the spread curve as a qtoolkit functions
# ===================================================================================
    spread_curve=convert_bond_swap_basis(bond_curve_df=bond_curve,
                                        IR_curve_df=ir_curve,
                                        asofdate=currt)
    std_tenors= ["1D", "2D", "7D" , "14D" ,  "21D" , "1M" , "2M" , "3M" , "6M", "9M" , "1Y" , "2Y", "3Y","4Y", "5Y" ,"7Y" , "10Y","12Y" ,"15Y","20Y" ,"25Y" ,"30Y" ,"50Y" ]
    print(parse_qt_curves_to_tenors(spread_curve , currt))

    print(len(std_tenors))
    parse_qt_curve_to_json(spread_curve)
    ircurveqt=make_qt_curve_from_db_ir(ir_curve,currt)
    discurve1=qt.DiscCurveZeroCouponSpread.make(date=currt,ccy='SEK',curve=ircurveqt,spreadCurve=spread_curve,keyString="OIS")
    discurve2=qt.DiscCurveZeroCoupon.make(date=currt,ccy="SEK",curve=make_qt_curve_from_db(bond_curve, currDateTime=currt))
    for index, row in ir_curve.iterrows():
        asofdate = qt.addTenor(currt, row['term_id'])
        print('------' + row['term_id'])
        discurve1.dict()
        print(pricing(currt,asofdate,discurve1) , pricing(currt,asofdate,discurve2))


# compare the price for key tenors
# for index, row in ir_curve.iterrows():
#     asofdate = qt.addTenor(currt, row['term_id'])
#     print('------' + row['term_id'])
#     discurve1.dict()
#     print(price(currt,asofdate,discurve1) , pricing(currt,asofdate,discurve2))
