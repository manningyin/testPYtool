from datetime import datetime

import core.risk.frtb_credit.future_chain as future_chain
import core.risk.frtb_credit.future_prototype as future
import pandas as pd

import core.graphics.scatter as scatter

__start_date = datetime(2014,1,1)
__end_date = datetime(2017,6,1)

def generate_bond_future_basis(su_key):
    future_obj = future_chain.Bond_Future_Timeseries([su_key])
    venuecode_obj = future_obj.getBondFuture_venuecode()
    chain_venue_code = future_obj.getBondFutureChain_venuecode(venue_code=[str(venuecode_obj[0]['instrument_name'])])
    chain_in_scope_df = work_out_su_keys_in_scope(chain_venue_code)
    print("following chains have been identified: ")
    print(chain_in_scope_df)
    df = pd.DataFrame()
    for index, single_chain in chain_in_scope_df.iterrows():
        try:
            tempOBJ = future.future_prototype(name='analysis',
                                              su_key_lists=[single_chain['su_key']],
                                              analysisStartDate=single_chain['start_date'],
                                              analysisEndDate=single_chain['end_date']
                                              )
            tempOBJ.loadALLMarketDATAintoCache()
            tempOBJ.calculate_model_basis()
            df =df.append(tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('basis')])
            print("have calculate basis for " + single_chain['su_key'])
        except:
            print("error: can not calculate basis for " + single_chain['su_key'])
    return df



def work_out_su_keys_in_scope(chain):
    # for safe, transfer the input to panda dataframe and sorted by expiry date
    chain_df = pd.DataFrame(chain)
    sort_df = chain_df.sort_values(by=['expiry_date'], ascending=[0])
    # loop through all panda dataframes...
    answer = pd.DataFrame()
    for index, row in sort_df.iterrows():
        curr_start_date = sort_df.iloc[index+1]['expiry_date']
        curr_end_date = sort_df.iloc[index]['expiry_date']
        if curr_end_date< __start_date:
            return answer
        else:
            if curr_start_date<__end_date:
                single_pd = pd.DataFrame(data =[[curr_start_date,curr_end_date,sort_df.iloc[index]['su_key']]],
                                         columns=['start_date', 'end_date', 'su_key'])
                answer = answer.append(single_pd)

if __name__ == '__main__':
    su_key = '131478729'
    df = generate_bond_future_basis(su_key)
    df_final = df.sort_values(by=['date'], ascending=[0])
    scatter.plot(dataframe      = df_final,
                 x_axis_var     = 'date',
                 y_axis_vars    = ['basis'],
                 y_axis_labels  = ['basis time series'],
                 dest_html_file = 'c:/Temp/basis.html',
                 plot_title     = 'This is some test plot',
                 plot_types     = 'lines+markers',
                 auto_open      = True,
                 )



