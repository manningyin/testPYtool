import core.connection.database_connect as database_connect
import core.connection.credentials as credential
import core.utils.version_independent as version_independent
import pandas as pd
import requests
import json
from distutils.version import StrictVersion
from core.system import version


def run_test(list_of_tests):
    list_of_tests = [x.upper() for x in list_of_tests]
    credentials = [x for x in ['INFOP', 'DAMDS', 'TWP', 'TWP_RO','DAMDP_RO'] if x in list_of_tests]
    result = pd.DataFrame()
    result = result.append(run_credential_tests(credentials))
    if 'MDS' in list_of_tests: result = result.append(run_mds_test())
    if 'MDS_test' in list_of_tests: result = result.append(run_mds_test(test_env=True))
    if 'TRMP' in list_of_tests: result = result.append(run_trmp_test())
    qt_synonyms = ['QT_VERSION', 'QT', 'QTOOLKIT', 'QTVERSION']
    if any(x in list_of_tests for x in qt_synonyms): result = result.append(run_qt_version_test())
    # run orca version test
    orca_synonyms = ['ORCA_VERSION', 'ORCA']
    if any(x in list_of_tests for x in orca_synonyms): result = result.append(run_orca_version_test())

    if any(x in list_of_tests for x in ['Python_Version', 'PYTHON_VERSION']): result = result.append(run_python_distribution_test())
    return result


def run_python_distribution_test():
    try:
        python_version_number = version.package_version_number()
    except:
        python_version_number = 0


    single_df = pd.DataFrame(data=[["MRIA Python version have to be 6:", python_version_number == 6]],
                             columns=['Test Name', 'Result'])
    return single_df

def run_credential_tests(credential_list):
    result_df = pd.DataFrame()
    for credential in credential_list:
        result = database_connect.credential_test(credential)
        single_df = pd.DataFrame(data=[["credential test " + credential, result]], columns=['Test Name', 'Result'])
        result_df = result_df.append(single_df)
    return result_df


def run_mds_test(test_env=False):
    single_df = pd.DataFrame(data=[["mds service access test", test_windows_credential()]],
                             columns=['Test Name', 'Result'])
    return single_df


def run_trmp_test():
    try:
        database_connect.return_trmp_string()
        out = True
    except:
        out = False

    single_df = pd.DataFrame(data=[["TRMP credential (either trusted or personal)", out]],
                             columns=['Test Name', 'Result'])
    return single_df


def test_windows_credential(test_env=False):
    service_arg = "http://mds.oneadr.net" if not test_env else "http://vda1cs1527"
    service_arg += "/v1/marketdata/prices/reval?Isins=DK0009792525&TradeDate=2017-04-28&format=json"
    auth = credential.get_HttpNtlmAuth()
    try:
        headers = {'accept': 'application/json;odata=verbose'}
        response = requests.post(url=service_arg
                                , auth=auth
                                 , headers=headers)
        #print(response.status_code)
        #print(response.content)
        data = json.loads(response.content)
        result = True
    except:
        result = False
    return result


def run_qt_version_test():
    single_df = pd.DataFrame(data=[["qt version has to be: 38", test_qt_versions()]],
                             columns=['Test Name', 'Result'])
    return single_df


def test_qt_versions():
    qt_main_version = version_independent.return_main_qt_version()
    if qt_main_version == 38:
        result = True
    else:
        result = False

    return result

def run_orca_version_test(test_version = '0.17.4'):
    import orca
    test_result = StrictVersion(orca.__version__) == StrictVersion(test_version)
    single_df = pd.DataFrame(data=[["orca version has to be :" + test_version, test_result]],
                             columns=['Test Name', 'Result'])
    return single_df





if __name__ == '__main__':
    run_python_distribution_test()