"""
This is a bond future prototype

The documentation can be found on:
https://confluence.itcm.oneadr.net/display/RPF/Bond+future+prototype+-+final

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       ddmonyyyy   G12345      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""




import core.risk.frtb_credit.bond_utili as bondUti
import core.risk.frtb_credit.credit_prototype as credit
import core.risk.frtb_prototype_context as context_manager
# ===================================================================================
# Assumption:
# 1: assume all isins in the CTD bucket has same risk factors (same curves for example..)
# 2: now use the future price from the CRD table directly, should direct to mds service. As talked with market data team, the release will be in 17 AUG 2017
# 3: now we only make qtookit bond future object once, and use the cash flow at the start date of the analysis, it assume the cashflow of the underlying ISINs keep unchanged( is that true?)
#
# ===================================================================================
import pandas as pd
import quantum as qt
from core.risk.frtb_prototype import frtb_prototype
from pandas.tseries.offsets import BDay

import core.market_data.market_data_loader as market_data_loader
from core.utils import date_helper
from core.utils import version_independent
from core.connection.orca_connect import get_orca_request


class future_prototype(frtb_prototype):
    def __init__(self, su_key_lists, name, analysisStartDate, analysisEndDate, portfolio = "STKRED", resultFilePath='default',
                 context_instance=None):

        # check the su_keys is not big enough!
        if len(su_key_lists) > 200:
            user_input = version_independent.get_input("Too many su_Key! Are u sure you want to continue? Press Y to continue :")
            if user_input != "Y":
                quit()

        # call the frtb prototype
        frtb_prototype.__init__(self, Pos_Lists=su_key_lists,
                                name=name,
                                analysisStartDate=analysisStartDate,
                                analysisEndDate=analysisEndDate,
                                resultFilePath=resultFilePath)
        # get context
        if context_instance is None:
            context_instance = context_manager.BondFutureContextManager.get_instance()




        # assign all attributes
        self.portfolio = portfolio
        self.bond_curve_source = context_instance.bond_curve_source
        self.bond_price_source = context_instance.bond_price_source
        self.rate_source = context_instance.rate_scenario
        self.bond_future_price_source = context_instance.bond_future_price_source

        self.credit_prototype = None
        self.qt_futures = None
        self.qt_bond_future_models = None


    def get_static_info(self):
        bondFuturesSD, underlying_df = bondUti.get_static_information_for_bond_future(self.Position_Lists)

        # attach the static information to result dataframe
        self.resultDataFrameList.append(bondFuturesSD)
        self.resultDataFrameName.append('Static Information')

        # attach the underlyings to the result dataframe
        self.resultDataFrameList.append(underlying_df)
        self.resultDataFrameName.append('underlying')


    def get_zspread_for_underlying(self):
        # ===================================================================================
        # this function will call credit prototype and calculate zspread for each underlyings
        # ===================================================================================
        if self.credit_prototype is None:
            self.attach_credit_prototype_for_underlying()

        self.credit_prototype.batchCalculateZSpread()
        zspread_df = self.credit_prototype.resultDataFrameList[self.credit_prototype.resultDataFrameName.index('Zspread')]
        # attach the underlyings to the result dataframe
        self.resultDataFrameList.append(zspread_df)
        self.resultDataFrameName.append('zspread')
        self.errorMessageDataFrame = self.errorMessageDataFrame.append(self.credit_prototype.errorMessageDataFrame)

    def attach_credit_prototype_for_underlying(self):
        # ===================================================================================
        # since many functionaries of future prototype is same with the credit prototype,
        # so here we just create a credit prototype for all underlying isins
        # ===================================================================================
        if 'underlying' not in self.resultDataFrameName:
            self.get_static_info()
        underlying_df = self.resultDataFrameList[self.resultDataFrameName.index('underlying')]

        try:
            isin_list = underlying_df["ISIN"].tolist()
        except Exception as e:
            print("----Serious error : no underlying ISIN has been loaded for sukey:  ---" )
            print(self.Position_Lists)
            raise Exception("No underlying ISIN! The future prototype will stop!")


        # remove duplicates
        isin_list = list(set(isin_list))

        # call credit prototype to calculate zspread.
        tempOBJ = credit.credit_prototype(name='analysis',
                                          ISIN_Lists=isin_list,
                                          analysisStartDate=self.analysisStartDate,
                                          analysisEndDate=self.analysisEndDate
                                          )
        tempOBJ.loadALLMarketDATAintoCache(loadISINLevelInformation=True)
        self.credit_prototype = tempOBJ


    def loadALLMarketDATAintoCache(self,loadStressedInformation=True):
        if 'zspread' not in self.resultDataFrameName:
            self.get_zspread_for_underlying()
        # since bond future should have the same curves(bond curve and risk free curve) with the underlying bond
        # so we just need load the curves from the credit prototype directly here.
        self.marketDataCache= self.credit_prototype.marketDataCache

        # we just need load the future price here
        df = pd.DataFrame()
        for su_key in self.Position_Lists:
            try:
                future_price_cache = market_data_loader.BondFuturePriceLoader(name = su_key,
                                                                              source = self.bond_future_price_source,
                                                                              startd=self.analysisStartDate,
                                                                              endd=self.analysisEndDate).data
                df = df.append(future_price_cache)
            except Exception as e:
                self.raise_serious_error(
                    message = "No future price in this period",
                    position= su_key)
                continue


            # if can not load any future prices, we remove the su_key from the position list
            if len(future_price_cache) == 0:
                self.raise_serious_error(
                    message="No future price in this period",
                    position=su_key)
                continue


        # attach the future prices
        df["date"] = df.index
        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('future_price')


    def get_deliverables(self , isins):
        out = []
        req = get_orca_request()
        specs = req.request_bond_specs(isins=isins).result()
        for isin in isins:
            try:
                spec = specs.results[isin]
            except:
                self.trackError(position=isin, comments="ORCA Bond Spec service can not get back specs for this ISIN")

            out.append(qt.FixedRateBullet.makeSimple(isin=isin,
                                                     issuedBefore=date_helper.to_datetime(spec.issue_date),
                                                     maturity=date_helper.to_datetime(spec.maturity_date),
                                                     couponRate=float(spec.coupon),
                                                     ccy=spec.currency,
                                                     frequency=spec.coupon_frequency,
                                                     exCoupon=str(spec.excoupon_days) + "B"))
        return out


    def make_qt_futures(self):
        futures = dict()
        static_info_df = self.resultDataFrameList[self.resultDataFrameName.index('Static Information')]
        underlying_df = self.resultDataFrameList[self.resultDataFrameName.index('underlying')]
        for su_key in self.Position_Lists:
            delivery_date = static_info_df.ix[static_info_df['SUKey'] == su_key].iloc[0]['FirstDelivery']
            delivery_date_datetime = date_helper.to_datetime(delivery_date)
            # ===================================================================================
            # get underlying isins and the corresponding convert factor
            # ===================================================================================
            this_isin_df = underlying_df.ix[underlying_df['su_key'] == su_key]
            isins =this_isin_df['ISIN'].tolist()
            convert_factor = this_isin_df['ConversionFactor'].tolist()
            if len(isins) != len(convert_factor):
                self.raise_serious_error(
                    message="number of conversion factor is not same with underlying isin",
                    position=su_key)
                continue
            # ===================================================================================
            # construct cash flow list
            # ===================================================================================
            cash_flows = []
            convert_factor_isins = []
            idx = 0
            for currISIN in isins:
                try:
                    cash_flow_cache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_cashflow')
                    cash_flow = cash_flow_cache.getvalue(min(cash_flow_cache.cacheDate))
                    cash_flows.append(cash_flow)
                    convert_factor_isins.append(convert_factor[idx])
                    idx = idx + 1
                except Exception as e:
                    self.raise_serious_error(
                        message="Can not load cash flow for this position",
                        position=su_key)
                    continue


            # ===================================================================================
            # call qtoolkit to construct bond future
            # ===================================================================================
            deliverables = self.get_deliverables(isins)
            fut = qt.BondFuture(isin = isins[0],
                                deliverables=deliverables,
                                     conversionFactors=convert_factor_isins,
                                     deliveryDate=delivery_date_datetime)

            futures[su_key] = fut
        self.qt_futures = futures

    def RTPLcalculation(self, marketdataCache = None):
        df = pd.DataFrame()
        df.name = 'RTPL_All'
        static_info_df = self.resultDataFrameList[self.resultDataFrameName.index('Static Information')]
        if self.qt_bond_future_models is None:
            self.make_models()


        position_df = pd.DataFrame()
        for currt in self.analysisRange:
            position_df = position_df.append(bondUti.get_bond_future_pos_from_trmp(self.portfolio,currt))
        position_df["EOD_DATE"] = [date_helper.to_datetime(x) for x in list(position_df["REPORT_DATE"])]

        for su_key in self.Position_Lists:
            isins = self.fetch_underlying_isins_from_result_df(su_key)
            try:
                lot_size = static_info_df[static_info_df["SUKey"] == su_key]["LotSize"]
                lot_size = float(lot_size)
            except Exception as e:
                self.trackError(errorMessage=e,
                                position=su_key,
                                comments='Can not get lot size for this su key')
                continue
            # get lots

            for currt in self.analysisRange:
                d1 = currt
                d2 = d1 + BDay(1)
                d1 = date_helper.to_datetime(d1)
                d2 = date_helper.to_datetime(d2)

                try:
                    lots = position_df[(position_df["SU_KEY"] == su_key) & (position_df["EOD_DATE"] == currt)]['LOTS']
                    lots = float(lots)
                except Exception as e:
                    self.trackError(errorMessage=e,
                                    position=su_key,
                                    date=d1,
                                    comments='Can not get lot for this su key and for this date')
                    continue

                try:
                    model_d1 = self.qt_bond_future_models[su_key,d1]
                    model_d2 = self.qt_bond_future_models[su_key,d2]
                    future_price_d1 = self.fetch_reval_price_from_result_df(su_key,d1)
                    future_price_d2 = self.fetch_reval_price_from_result_df(su_key,d2)
                    fx_rate_d1 = self.fetch_fx_rates('fxRate', d1)['price']
                    fx_rate_d2 = self.fetch_fx_rates('fxRate', d2)['price']

                    HPL = fx_rate_d2* future_price_d2 - fx_rate_d1*future_price_d1

                    disCurve_d1 = self.fetch_rates_and_make_discount_curve('riskfreecurve', d1 ,d1)
                    spreadCurve_d1 = self.fetch_rates_and_make_discount_curve('bondSwapBasis', d1,d1)
                    disCurve_d2 = self.fetch_rates_and_make_discount_curve('riskfreecurve', d2, d1)
                    spreadCurve_d2 = self.fetch_rates_and_make_discount_curve('bondSwapBasis', d2, d1)
                    zspreads_d1 = self.fetch_zspread_from_result_df(isins, d1)
                    zspreads_d2 = self.fetch_zspread_from_result_df(isins, d2)


                    RTPL_by_risk_free = fx_rate_d1 * (model_d1.scenarioPrice(disCurve_d2, spreadCurve_d1,
                                                               zspreads_d1) - future_price_d1)
                    RTPL_by_spread = fx_rate_d1 * (model_d1.scenarioPrice(disCurve_d1, spreadCurve_d2,
                                                               zspreads_d1) - future_price_d1)
                    RTPL_by_zspreads = fx_rate_d1 * (model_d1.scenarioPrice(disCurve_d1, spreadCurve_d1,
                                                            zspreads_d2) - future_price_d1)

                    RTPL_by_future_basis = fx_rate_d1*((model_d2.basis() / model_d1.basis()) * future_price_d1 - future_price_d1)

                    RTPL_wo_future_basis =fx_rate_d2 *  (model_d1.basis()/model_d2.basis() ) * future_price_d2 - fx_rate_d1 *future_price_d1

                    RTPL_with_future_basis = fx_rate_d2*future_price_d2 - fx_rate_d1 *future_price_d1


                    otherPL = RTPL_wo_future_basis - RTPL_by_risk_free - RTPL_by_spread - RTPL_by_zspreads - RTPL_by_future_basis


                    output_unit_pl = [HPL,RTPL_wo_future_basis ,RTPL_with_future_basis,RTPL_wo_future_basis - HPL,
                                                    RTPL_by_risk_free,
                                                    RTPL_by_spread , RTPL_by_zspreads,
                                                    RTPL_by_future_basis,
                                                    otherPL]

                    output_pl_with_lot_size = [x * lot_size * lots/100 for x in output_unit_pl]


                    single_df = pd.DataFrame(data=[[d1, d2,  su_key , lots,fx_rate_d1,fx_rate_d2] + output_pl_with_lot_size],
                                         columns=['Day1', 'Day2', 'Position','lots','fx d1', 'fx d2',
                                                  'HPL' , 'RTPL','RTPL with future basis', 'unExplained_PL',
                                                  'PL Explained by risk free',
                                                  'PL Explained by bond-swap basis',
                                                  'PL Explained by zspreads',
                                                  'PL Explained by basis',
                                                  'PL Explianed by others (non linear)'
                                                  ])

                    df = df.append(single_df)
                except Exception as e:
                    self.trackError(errorMessage=e,
                                    position= su_key,
                                    date = d1,
                                    comments='Can not finish RTPL calculation for this date')

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('RTPL_All')


    def calculate_model_basis(self):
        if self.qt_bond_future_models is None:
            self.make_models()
        df = pd.DataFrame()
        df.name = 'RTPL_All'
        for su_key in self.Position_Lists:
            for currt in self.analysisRange:
                try:
                    model = self.qt_bond_future_models[su_key,currt]
                    single_df = pd.DataFrame(data=[[currt, su_key, model.basis()]],
                                             columns=['date', 'su_key', 'basis'])
                    df = df.append(single_df)
                except Exception as e:
                    self.trackError(errorMessage=e,
                                    position= su_key,
                                    date = currt,
                                    comments='Can not calculate basis for this date')
                    continue

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('basis')

    def make_models(self):
        models = dict()
        marketdataCache = self.marketDataCache

        df = pd.DataFrame()
        df.name = 'RTPL_All'

        if self.qt_futures is None:
            self.make_qt_futures()

        for su_key in self.Position_Lists:
            future = self.qt_futures[su_key]
            isins = self.fetch_underlying_isins_from_result_df(su_key)
            for currt in self.analysisRange:
                try:
                    # ===================================================================================
                    # here we get reval price and zspread from the result dataframe.
                    # ===================================================================================
                    currt = date_helper.to_datetime(currt)
                    reval_price = self.fetch_reval_price_from_result_df(su_key, currt)
                    disCurve_d0 = self.fetch_rates_and_make_discount_curve('riskfreecurve',currt,currt)
                    spreadCurve_d0_disc = self.fetch_rates_and_make_discount_curve('bondSwapBasis',currt,currt)
                    zspreads = self.fetch_zspread_from_result_df(isins, currt)
                    #ints = self.fetch_accr_interest_from_result_df(su_key, currt)
                    model_d0 = qt.BondFutureModel.makeFromData(discCurve=disCurve_d0,
                                                       spreadCurve=spreadCurve_d0_disc,
                                                       zSpreads=zspreads,
                                                       future=future,
                                                       futuresPrice=reval_price)
                    models[su_key,currt] = model_d0
                except Exception as e:
                    self.trackError(errorMessage=e,
                                    position= su_key,
                                    date = currt,
                                    comments='Can not make qt future model for this date')
                    continue


        self.qt_bond_future_models = models

    def fetch_rates_and_make_discount_curve(self,cachename,curvedate,asofdate):
        tempcache = self.marketDataCache.getObjectFromCacheSet(cachename)
        curve = tempcache.getvalue(curvedate)
        return qt.DiscCurveZeroCoupon.make(asofdate, "EUR", curve)

    def fetch_fx_rates(self,cachename,asofdate):
        tempcache = self.marketDataCache.getObjectFromCacheSet(cachename)
        return tempcache.getvalue(asofdate)

    def fetch_accr_interest_from_result_df(self,su_key,currt):
        isins = self.fetch_underlying_isins_from_result_df(su_key)
        ints = []
        for currISIN in isins:
            marketPriceCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_marketPrice')
            priceObj = marketPriceCache.getvalue(currt)
            if priceObj['accrued_interest'] == None:
                self.trackError(position=su_key, date = currt, comments="no accured int, use zero instead")
                ints.append(0)
            else:
                ints.append(float(priceObj['accrued_interest']))
        return ints



    def fetach_future_basis_from_result_df(self,su_key,currt):
        basis_df = self.resultDataFrameList[self.resultDataFrameName.index('basis')]
        this_day_df = basis_df.ix[basis_df['date'] == currt]
        return this_day_df.ix[this_day_df['su_key'] == su_key].iloc[0]["basis"]

    def fetch_underlying_isins_from_result_df(self,su_key):
        underlying_df = self.resultDataFrameList[self.resultDataFrameName.index('underlying')]
        this_isin_df = underlying_df.ix[underlying_df['su_key'] == su_key]
        isins = this_isin_df['ISIN'].tolist()
        return isins

    def fetch_zspread_from_result_df(self,isins, currt):
        zspreads =[]
        zspread_df = self.resultDataFrameList[self.resultDataFrameName.index('zspread')]
        zspread_df_currt = zspread_df.ix[zspread_df['INFO_DATE'] == currt]
        for isin in isins:
            temp_isin = zspread_df_currt.ix[zspread_df_currt['ISIN'] == isin]
            zspread_for_isin = temp_isin.iloc[0]["ZSPREAD"]
            zspreads_qt = qt.ZSpread(isin=isin,spread=zspread_for_isin)
            zspreads.append(zspreads_qt)
        return zspreads

    def fetch_reval_price_from_result_df(self,su_key,currt):
        future_df = self.resultDataFrameList[self.resultDataFrameName.index('future_price')]
        reval_price_df_this_date = future_df[future_df['date'] == currt]
        price_df_for_this_su_key_and_this_date = reval_price_df_this_date.ix[reval_price_df_this_date['su_key'] == su_key]
        return price_df_for_this_su_key_and_this_date.iloc[0]["price"]

    def load_future_price(self):
        return


if __name__ == '__main__':
    import datetime
    startDate = datetime.datetime(2017,2,1)
    endDate = datetime.datetime(2017,2,12)

    tempOBJ = future_prototype(name='analysis',
                               su_key_lists=['154863286','131478729', '154527792'],
                            # ['2304262','2032527','2711269','2711267','2671405','2670028','2616535','2570782','2328795','2238438','2210153','2710900','2710899','2692816','2692798','2350017','2275363','2270181','2214569','2710363','2678207','2500569','2500547','2356206','2310004'],
                            analysisStartDate=startDate,
                            analysisEndDate=endDate,
                               portfolio="STKRED"
                            )

    tempOBJ.loadALLMarketDATAintoCache()
    tempOBJ.calculate_model_basis()
    print(tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('basis')])
    #tempOBJ.RTPLcalculation()
    #tempOBJ.plAttribution()
    tempOBJ.writeResultToExcel()

