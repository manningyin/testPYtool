import os
import sys
from datetime import datetime

import core.risk.frtb_credit.credit_prototype as credit
import core.risk.frtb_credit.future_prototype as future
import pandas as pd
from core.risk.frtb_credit import bond_utili
from core.risk.frtb_credit import isin_rf_mapping
from core.risk.frtb_credit.bond_utili import get_core_information

from core.system import guestbook


def do_calculations(transaction_list, startd, endd, calculation, product = "Bond" , config_func = None, mail_function = None, varbose = False):
    guestbook.checkin()
    # validate the input
    if product not in ["Bond Future", "Bond"]:
        print("Error : the product is not supported")

    def empty_config(tempobj):
        return tempOBJ

    def no_email(msg):
        return

    if config_func is None:
        config_func = empty_config

    if mail_function is None:
        mail_function = no_email

        # create result file name
    defaultResultFolder = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/20 Data/FRTB Credit/TestingWork/simpleBondProtoType/batch_result/'
    result_folder = defaultResultFolder + calculation + '_batch_runner' + datetime.now().strftime("%Y%m%d-%H%M%S") + '/'
    os.mkdir(result_folder)
    use_header = True
    totalNum = 0

    if product == "Bond":
        duplicate_mapping, risk_factor_mapping, transacation_mapped = return_duplicate_mapping_for_bonds(transaction_list,
                                                                                             result_folder)
    elif product == "Bond Future":
        duplicate_mapping, risk_factor_mapping, transacation_mapped = return_duplicate_mapping_for_bond_futures(
            transaction_list,
            result_folder)

    for rf_set in duplicate_mapping:
        result_df = pd.DataFrame()
        result_df_2 = pd.DataFrame()
        # Loop through risk factor set and find the relevent isins to do the calculation
        ids = [i for i, j in enumerate(risk_factor_mapping) if j == rf_set]
        transaction_selected = [transacation_mapped[x] for x in ids]
        print('Now we run the calculation for the following risk factor set: ')
        print(rf_set)
        print('In total ' + str(len(transaction_selected)) + ' pos have been mapped to this risk factor set')

        if not varbose:
            sys.stdout = open(os.devnull, "w")
        # call credit_prototype
        if product == "Bond":
            tempOBJ = credit.credit_prototype(name='analysis',
                                              ISIN_Lists=transaction_selected,
                                              analysisStartDate=startd,
                                              analysisEndDate=endd
                                              )

            tempOBJ = config_func(tempOBJ)
        elif product == "Bond Future":
            tempOBJ = future.future_prototype(name='analysis',
                                              su_key_lists=transaction_selected,
                                              analysisStartDate=startd,
                                              analysisEndDate=endd)
            tempOBJ = config_func(tempOBJ)



        # ===================================================================================
        # Load the market data used for the calculation.
        # ===================================================================================

        if calculation in ['IMCC']:
            tempCache = tempOBJ.loadALLMarketDATAintoCache(
                loadStressedInformation=True)
        else:
            tempCache = tempOBJ.loadALLMarketDATAintoCache(
                loadStressedInformation=False)

        if calculation == 'RTPL':
            tempOBJ.RTPLcalculation(marketdataCache=tempCache)
            result_df = tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('RTPL_All')]
            if not varbose:
                sys.stdout = sys.__stdout__


        if calculation == 'ZSPREAD':
            try:
                tempOBJ.batchCalculateZSpread()
                tempOBJ.scenario_generator(tempOBJ.analysisRange ,
                                           returnName='normal_cs_fs',
                                           bumpRiskFactors= ['zSpread'])
                tempOBJ.bump_size_calculation()
                result_df = tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('Zspread')]
                result_df_2 = tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('NMRF_bump_size')]
            except:
                continue
            if not varbose:
                sys.stdout = sys.__stdout__

            if result_df.empty:
                print('--- empty zspread results--------')


        elif calculation == 'IMCC':
            tempOBJ.Modelability_File = ''
            tempOBJ.batchCalculateZSpread()
            tempOBJ.calculateIMCC()
            if not varbose:
                sys.stdout = sys.__stdout__

            try:
                result_df = tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('IMCC')]
                result_df_2 = tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('Zspread')]
            except:
                print('--- result cannot return from the credit prototype--------')

            if result_df.empty:
                print('--- empty IMCC results--------')

        elif calculation =='Just Mapping':
            result_df = pd.DataFrame()
            result_df_2 = pd.DataFrame()

        elif calculation == 'ZSPREAD_only':
            try:
                tempOBJ.batchCalculateZSpread()
                tempOBJ.update_zspread_to_DAMDS()
                result_df = tempOBJ.resultDataFrameList[tempOBJ.resultDataFrameName.index('Zspread')]
            except:
                continue

        error_df = tempOBJ.errorMessageDataFrame

        # I/O
        def file_IO(df,filename,use_header):
            df.to_csv(path_or_buf = filename, mode='a', index = False, header=use_header)

        file_IO(result_df, result_folder+'result_1.csv',use_header)
        file_IO(result_df_2, result_folder + 'result_2.csv', use_header)
        file_IO(error_df, result_folder + 'error.csv', use_header)

        totalNum = totalNum + len(transaction_selected)

        mail_function('Batch Runner Info: In total ' + str(totalNum) + ' ISIN has finished')
    # print finish messgae
    print("Batch runner finished and you can find the results at : " + os.path.normpath(result_folder))


def return_duplicate_mapping_for_bonds(isin_Lists ,result_folder):
    risk_factor_mapping = []
    risk_factor_mapping_df = []
    isin_mapped = []
    for isin in isin_Lists:
        try:
            bond_curve, credit_curve, status = isin_rf_mapping.get_rf_for_isin(isin)
            ccy = get_core_information([isin]).loc[0]["Currency"].encode("ASCII","ignore")
            risk_factor_mapping.append((bond_curve, credit_curve, status, ccy))
            risk_factor_mapping_df.append([isin, bond_curve, credit_curve, status,ccy])
            isin_mapped.append(isin)
        except:
            print("we can not get risk factor for this ISIN : " + isin )
            continue
    duplicate_mapping = list(set(risk_factor_mapping))
    mapping_df = pd.DataFrame(risk_factor_mapping_df)
    mapping_df.to_csv(result_folder + 'mapping.csv', mode='a', header=True , index=False)
    return duplicate_mapping,risk_factor_mapping,isin_mapped
    # now we find the duplicate mapping

def return_duplicate_mapping_for_bond_futures(su_key_lists,result_folder):
    static_info, underlying_df = bond_utili.get_static_information_for_bond_future(su_key_lists)
    risk_factor_mapping = static_info["Currency"].tolist()
    sukey_mapped = static_info["SUKey"].tolist()
    duplicate_mapping = list(set(risk_factor_mapping))
    mapping_df  = static_info[["SUKey", "Currency"]]
    mapping_df.to_csv(result_folder + 'mapping.csv', mode='a', header=True, index=False)
    return duplicate_mapping,risk_factor_mapping,sukey_mapped


if __name__ == '__main__':
    #fullfilename = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/20 Data/FRTB Credit/BatchLoader/ISIN Lists/credit bonds.txt'
    #isin_list = return_all_isins_in_prototype_scope('//dcd00cb-evs02/ABD/Market Risk Models & Measures/20 Data/FRTB Credit/BatchLoader/test ISIN Lists/')
    su_key_list = ['154527792','130071509']

    do_calculations(transaction_list=su_key_list,
                    startd = datetime(2017,3,10),
                    endd = datetime(2017,5,30),
                    product = "Bond Future",
                    calculation = 'RTPL',
                    varbose= True)


