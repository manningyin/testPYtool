import core.connection.database_extract as db

def get_interest_id_from_marsp(isin):
    sql  = '''
        select isin, to_char(interest_id) as interest_id from (
         select /*+ materialize*/ A.ISIN,
                case
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'GR' then 9006
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'IE' then 9006
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'PT' then 9006
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'ES' then 9006
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'BE' then 9014
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'DE' then 9001
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'FI' then 9003
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'FR' then 9004
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID = 'IT' then 9006
                    when B.ORIGINAL_CURRENCY_ID = 'EUR' and B.ISSUER_COUNTRY_ID not in ('GR','IE','PT','ES','BE','DE','FI','FR','IT') then 9001
                    when B.ORIGINAL_CURRENCY_ID <> 'EUR' then (select interest_id from MARSP.INTEREST where interest_market_id = 'GOVM' and currency_id = b.original_currency_id and interest_issuer_id = 'BENCH')
                    else 99999999
                end INTEREST_ID
                from MARSP.ISIN_EFFECT a, MARSP.BOND_EFFECT b
                where A.ISIN in (''' + "'" + isin + "'" + ''')
                and A.EFFECT_ID = B.EFFECT_ID
                )
                '''
    return db.select_from_query(database = 'INFOP' , query = sql)[0]['INTEREST_ID']


if __name__ == '__main__':
    #myISIN = ['DK0009918138','DK0009763344','XS0237270995','NO0010296775','NO0010039878','NO0010297468']
    print( get_interest_id_from_marsp('DE0001104644'))