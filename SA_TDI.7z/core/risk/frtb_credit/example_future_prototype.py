import datetime

import core.risk.frtb_credit.future_prototype as future

if __name__ == '__main__':
    startDate = datetime.datetime(2017, 3, 1)
    endDate = datetime.datetime(2017, 6, 1)

    tempOBJ = future.future_prototype(name='analysis',
                                      su_key_lists=['154527792'],
                                      analysisStartDate=startDate,
                                      analysisEndDate=endDate
                                      )
    tempOBJ.loadALLMarketDATAintoCache()
    tempOBJ.calculate_model_basis()
    tempOBJ.RTPLcalculation()
    tempOBJ.plAttribution()
    tempOBJ.writeResultToExcel()