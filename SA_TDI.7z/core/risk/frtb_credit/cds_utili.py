import quantum as qt
from orca.models.factory import Factory
from orca.trades.trade_handler import TradeHandler
from orca.types import TradeIdentifier, SourceSystem
from pandas.tseries.offsets import BDay
from core.system import ext_envir
from core.caching.cache_driver import easy_cache
from core.connection import database_extract, orca_connect


@easy_cache()
def get_info_from_gotc(trade_id):

    sql =  """
    select  distinct(trade_id) as trade_id,
    r.datetime,
    h.credit_name,
    c.curve_name,
    c.currency_code,
    c.curve_id
    from gotc.gotc_ra_sec_val_data_item_exp r
    join GOTC.GOTC_VEM_MD_EXPORT v on (v.sec_val_data_id = r.sec_val_data_id)
    join gotc.gotc_curve c on c.curve_id = v.md_id
    join gotc.gotc_cd_credit_curve_header h on h.curve_id = v.md_id
    where r.model_association_name in ('REVAL_CDS_SUB','REVAL_CDS', 'REVAL_CDS_MIX', 'REVAL_CDS_MIX_SUB', 'REVAL_CDS_2003', 'REVAL_CDS_2003_SUB')
    and trade_id = %s
    """ %trade_id
    print(sql)
    return database_extract.select_from_query(database="TWP_RO", query= sql)

def get_credit_name_from_gotc(trade_id):
    trade_info = get_info_from_gotc(trade_id)
    try:
        credit_name = trade_info[0]['credit_name']
    except:
        credit_name = None
    return credit_name

def get_curve_name_from_gotc(trade_id):
    trade_info = get_info_from_gotc(trade_id)
    try:
        curve_name = trade_info[0]['curve_name']
    except:
        curve_name = None
    return curve_name

def generate_orca_identifier(trade_ids):
    return [TradeIdentifier(trade_id, SourceSystem.INFINITY) for trade_id in trade_ids]

def generate_orca_identifier_for_imcc_prototype(trade_ids):
    return {'INFINITY': trade_ids}

def theta_calc(d1, trade_id):
    d2 = d1 + BDay(1)

    cfg = ext_envir.ORCA().config
    req = orca_connect.get_orca_request()
    hf = req.get_holiday_factory_for_all_centers().result()
    trade_handler = TradeHandler(cfg, req, hf)
    trade_identifier = [TradeIdentifier(x, SourceSystem.INFINITY) for x in trade_id]
    trade_list = list(trade_handler.request_trades(d1, trade_identifier))

    model_factory_0 = Factory(orca_connect.to_eod(d1), hf, req)

    theta = 0
    d1_price = 0
    for leg in trade_list[0]:
        qt_model_d1 = model_factory_0.create("ORCA_REVAL_CDS", leg.model_specification)
        d1_price += qt_model_d1.value(leg.get_leg(), leg.fixings)
        fwd_model_d2 = qt.forwardModel(model=qt_model_d1, newAnchorDate=d2)
        theta += fwd_model_d2.value(leg.get_leg(), leg.fixings)

    theta -= d1_price
    print(d1_price)
    return theta


if __name__ == '__main__':
    print(get_info_from_gotc(1733309))
    print(get_credit_name_from_gotc(1733309))
    print(get_curve_name_from_gotc(1733309))
    import datetime as dt
    print(theta_calc(dt.datetime(2017, 3, 1), ['2711267']))