from __future__ import print_function
import cx_Oracle
import pyodbc
from collections import namedtuple

from contextlib import contextmanager
import sys

import pandas as pd



if __name__ == "__main__":
    print(curveName2interest_id('EUR-XO_CURVE'))
    print(type(curveName2interest_id('EUR-XO_CURVE')))