import datetime

import core.risk.frtb_credit.credit_prototype as credit

if __name__ == '__main__':
    ISIN_lists=['SE0006758561']
    startDate=datetime.datetime(2017,1,5)
    endDate=datetime.datetime(2017,7,15)

    tempOBJ=credit.credit_prototype(name='analysis',
                           ISIN_Lists=ISIN_lists,
                           analysisStartDate=startDate,
                           analysisEndDate=endDate
                           )


    tempCache=tempOBJ.loadALLMarketDATAintoCache(loadStressedInformation=False, loadISINLevelInformation=True)
    tempOBJ.RTPLcalculation(marketdataCache=tempCache)
    tempOBJ.batchCalculateZSpread()
    tempOBJ.writeResultToExcel()