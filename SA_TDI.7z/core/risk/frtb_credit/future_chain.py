import core.connection.database_extract as db
import pandas as pd
class Bond_Future_Timeseries(object):

    def __init__(self, su_key=None):
        self.su_key = su_key

        if su_key == None:
            su_key = ""

    def getBondFuturePrice(self):
        """
        The function provide a standard SQL to query @TWP.WORLD for Bond Future REVAL prices by su_key.

        Args:
            su_key                   (list):              List of su_key ['item1','item2']

        Returns:
            (dict):   REVAL price and some static data for single Bond Future

        Notes:
            Author: g47193
        """
        list_su_key = ""
        for i in range(0, len(self.su_key)):
            list_su_key = self.su_key[i] + ", " + list_su_key

        list_su_key = list_su_key[:-2]

        tmp = ""
        for i, m in enumerate(list_su_key.replace(' ', '').split(',')):
            tmp = tmp + m + "','"

        list_su_key = tmp[:-3]
        list_su_key = "'" + list_su_key + "'"

        tSQL = '''
        select
         rs.instrument_su_key,
         ii.instrument_name,
         ii.description,
         inf.EXPIRY_DATE,
         inf.CREATED_AT,
         ii.issue_ccy,
         ift.future_type,
         rod.DATA_VALUE as PRICE_REVAL_CRD,
         rod.REPORT_DATE
         from mcdm.in_instrument ii
         left join prices.rr_securities rs on ii.SU_KEY=rs.INSTRUMENT_SU_KEY
         left join prices.rr_output_data rod on rs.SECURITY_ID=rod.SECURITY_ID
         left join mcdm.in_future inf on rs.instrument_su_key=inf.instrument_su_key
         left join mcdm.in_future_type ift on inf.FUTURE_TYPE_SU_KEY=ift.su_key
         where 1=1
         and rod.PURPOSE='REVAL'
         and ift.FUTURE_TYPE in ('BOND_FUTURE')
         and rs.instrument_su_key in (''' + list_su_key + ''')
        '''
        tSQL = tSQL.replace('"', "")
        tSQL = tSQL.replace("\n", "")

        get_price = db.select_from_query(database="TWP", query=tSQL)

        return get_price

    def getBondFutureChain(self):
        """
        The function provide a standard SQL to query @TWP.WORLD for all Bond Future REVAL prices and static data
        on product by su_key.

        Args:
            self.su_key                   (list):              List of su_key ['item1','item2']

        Returns:
            (dict):     REVAL price and some static data for all su_key's related
                        to a Bond Futures Product.

        Notes:
            Author: g47193
        """
        list_su_key = ""
        for i in range(0, len(self.su_key)):
            list_su_key = self.su_key[i] + ", " + list_su_key

        list_su_key = list_su_key[:-2]

        tmp = ""
        for i, m in enumerate(list_su_key.replace(' ', '').split(',')):
            tmp = tmp + m + "','"

        list_su_key = tmp[:-3]
        list_su_key = "'" + list_su_key + "'"

        tSQL = '''
        select
         DISTINCT
         ii.SU_KEY,
         inf.FUTURE_TYPE_SU_KEY,
         rod.REPORT_DATE,
         ii.issue_ccy,
         ii.INSTRUMENT_TYPE,
         ii.INSTRUMENT_NAME,
         ii.DESCRIPTION,
         ii.DESCRIPTION_SHORT,
         rod.DATA_VALUE as PRICE_REVAL_CRD,
         rod.quote_type,
         inf.EXPIRY_DATE,
         inf.FIRST_TRADE_DATE,
         inf.LAST_TRADE_DATE,
         inf.FIRST_DELIVERY_DATE,
         inf.LAST_DELIVERY_DATE,
         ii.issuer_su_key,
         ii.source_issuer_desc,
         ii.issue_type
         from mcdm.in_future inf
         left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY
         left join mcdm.in_future_type ift on inf.FUTURE_TYPE_SU_KEY=ift.su_key
         left join prices.rr_securities rs on inf.instrument_su_key=rs.INSTRUMENT_SU_KEY
         left join prices.rr_output_data rod on rs.SECURITY_ID=rod.SECURITY_ID
         where 1=1
         and rod.PURPOSE='REVAL'
         and ii.INSTRUMENT_NAME in (select distinct ii.INSTRUMENT_NAME from mcdm.in_future
         inf left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY where
         inf.instrument_su_key in (''' + list_su_key + '''))
         order by ii.SU_KEY, rod.REPORT_DATE asc, inf.EXPIRY_DATE desc
        '''
        tSQL = tSQL.replace('"', "")
        tSQL = tSQL.replace("\n", "")

        get_chain = db.select_from_query(database="TWP", query=tSQL)

        return get_chain


    def getBondFutureChain_sukeys(self):
        """
        The function provide a standard SQL to query @TWP.WORLD for all su_key's per Bond Future product.

        Args:
            self.su_key                   (list):              List of su_key ['item1','item2']

        Returns:
            (dict):   All su_key's related to a Bond Futures Product.

        Notes:
            Author: g47193
        """
        list_su_key = ""
        for i in range(0, len(self.su_key)):
            list_su_key = self.su_key[i] + ", " + list_su_key

        list_su_key = list_su_key[:-2]

        tmp = ""
        for i, m in enumerate(list_su_key.replace(' ', '').split(',')):
            tmp = tmp + m + "','"

        list_su_key = tmp[:-3]
        list_su_key = "'" + list_su_key + "'"

        tSQL = '''
        select
         DISTINCT ii.SU_KEY,
         inf.EXPIRY_DATE
         from mcdm.in_future inf
         left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY
         where 1=1
         and ii.INSTRUMENT_NAME in (select distinct ii.INSTRUMENT_NAME from mcdm.in_future
         inf left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY where
         inf.instrument_su_key in (''' + list_su_key + '''))
        '''
        tSQL = tSQL.replace('"', "")
        tSQL = tSQL.replace("\n", "")

        get_chain = db.select_from_query(database="TWP", query=tSQL)

        dictChain = {}
        for i in range(0, len(get_chain)):
            dictChain[int(get_chain[i]['su_key'])] = get_chain[i]['expiry_date']

        return dictChain

    def getBondFuture_venuecode(self):
        """
        The function provide a standard SQL to query @TWP.WORLD for venue code for a Bond Future by su_key.

        Args:
            self.su_key                   (list):              List of su_key ['item1','item2']

        Returns:
            (dict):   Venue code for a su_key's related Bond Futures Product.

        Notes:
            Author: g47193
        """
        list_su_key = ""
        for i in range(0, len(self.su_key)):
            list_su_key = self.su_key[i] + ", " + list_su_key

        list_su_key = list_su_key[:-2]

        tmp = ""
        for i, m in enumerate(list_su_key.replace(' ', '').split(',')):
            tmp = tmp + m + "','"

        list_su_key = tmp[:-3]
        list_su_key = "'" + list_su_key + "'"

        tSQL = '''
        select
         DISTINCT
         ii.INSTRUMENT_NAME
         from mcdm.in_future inf
         left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY
         where 1=1
         and ii.INSTRUMENT_NAME in (select distinct ii.INSTRUMENT_NAME from mcdm.in_future
         inf left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY where
         inf.instrument_su_key in (''' + list_su_key + '''))
        '''
        tSQL = tSQL.replace('"', "")
        tSQL = tSQL.replace("\n", "")

        get_venuecode = db.select_from_query(database="TWP", query=tSQL)
        return get_venuecode

    def getBondFutureChain_venuecode(self, venue_code):
        """
        The function provide a standard SQL to query @TWP.WORLD for all Bond Future su_keys per Bond Future product.

        Args:
            venue code                   (list):              List of venue codes ['item1','item2']

        Returns:
            (dict):   su_key's for all su_key's related to a Bond Futures Product by venue code.

        Notes:
            Author: g47193
        """
        list_su_key = ""
        for i in range(0, len(venue_code)):
            list_su_key = venue_code[i] + ", " + list_su_key

        list_su_key = list_su_key[:-2]

        tmp = ""
        for i, m in enumerate(list_su_key.replace(' ', '').split(',')):
            tmp = tmp + m + "','"

        list_su_key = tmp[:-3]
        list_su_key = "'" + list_su_key + "'"

        tSQL = '''
        select
         DISTINCT
         to_char(ii.SU_KEY) as su_key,
         inf.EXPIRY_DATE
         from mcdm.in_future inf
         left join mcdm.in_instrument ii  on inf.instrument_su_key=ii.SU_KEY
         where 1=1
         and ii.INSTRUMENT_NAME in (''' + list_su_key + ''')
         order by inf.EXPIRY_DATE desc
        '''
        print(tSQL)
        tSQL = tSQL.replace('"', "")
        tSQL = tSQL.replace("\n", "")

        get_venuecode = db.select_from_query(database="TWP", query=tSQL)

        return get_venuecode

if __name__ == '__main__':
    sukeys = ['110075550']

    # iniate class object for sukeyys
    future_obj = Bond_Future_Timeseries(sukeys)

    # get Bond Future price by su_key
    price_obj = future_obj.getBondFuturePrice()
    #print (price_obj)

    # get Bond Future chain by su_key
    chain_obj = future_obj.getBondFutureChain()
    #print (chain_obj)

    # get Bond Future chain su_key by su_key
    chain_sukey_obj = future_obj.getBondFutureChain_sukeys()
    #print (chain_sukey_obj)

    # get Bond Future venue code by su_key
    venuecode_obj = future_obj.getBondFuture_venuecode()
    #print (venuecode_obj)

    # get Bond Future chain by venue code
    chain_venue_code = future_obj.getBondFutureChain_venuecode(venue_code=[str(venuecode_obj[0]['instrument_name'])])
    print (chain_venue_code)
