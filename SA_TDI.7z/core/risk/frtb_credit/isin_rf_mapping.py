'''
The module return the risk factors by return the ISIN

In FRTB IMA, we need answer a question, which risk factor(s) will be used for a specific ISIN,
this prototype make an initial proposal to the logic


'''
import core.risk.frtb_credit.credit_bond_mapping as credit_bond_mapping
import core.risk.frtb_credit.eu_gov_bond_mapping as eu_gov_mapping
import pandas as pd
from core.risk.frtb_credit.bond_utili import *

from core.caching.cache_driver import easy_cache
from core.system import envir

_global_cache_folder = envir.data_path()

@easy_cache(_global_cache_folder)
def get_rf_for_isin(isin):
    '''
    The function returns the risk factors for a given isin by using waterfall setup

    The function will follow the following waterfall to decide the risk factors:
    1) check whether the isin is govt bond
    2) check whether the isin is bullt mortgage bond
    3) check whether the isin can be mapped to a eu gov bond case by mars logic
    4) check whether the isin has simple credit bonds with signle name cds
    5) go to proxy setup

    Args:
        isin                    (str):              a string of

    Returns:
        (list of dicts):   [name of bond curve, name of credit curve, status code]


    Notes:
        Author: g48454
    '''

    # level 1: try to check whether it is a govt bond
    try:
        bond_curve,credit_curve , status = check_whether_isin_is_gov(isin)
        return bond_curve, credit_curve , status
    except Exception as e:
        pass

    # level 2: try to check whether it is a mortgage bond
    try:
        bond_curve,credit_curve = check_whether_isin_is_mortgage(isin)
        return bond_curve, credit_curve,'mortgage_bond'
    except:
        pass

    # level 4: try to check whether a single name cds is avalibale in markit
    try:
        bond_curve,credit_curve = check_whether_single_name_cds_exsisted(isin)
        return bond_curve, credit_curve,'single_name_cds'
    except:
        pass


    # level 4: back to proxy setup
    bond_curve, credit_curve = get_proxy(isin)
    return bond_curve, credit_curve, 'proxy'




def check_whether_eu_gov_bond(isin):
    interest_id = eu_gov_mapping.get_interest_id_from_marsp(isin)
    if interest_id !='99999999':
        return interest_id,"empty"






def check_whether_single_name_cds_exsisted(isin):
    df = parse_cds_mapping()
    credit_name  = df[df['ISIN'] == isin]['MARKIT_TICKER'].tolist()[0]
    credit_name = str(credit_name)
    if credit_name != 'nan':
        return "empty",credit_name


def parse_cds_mapping():
    filepath = _global_cache_folder
    xl = pd.ExcelFile(filepath)
    df = xl.parse("DATA")
    return df

def check_whether_isin_is_mortgage(isin):
    country , issuer_type , asset_type , currency = parse_info(isin)
    if issuer_type in ["Mortgage" ] and asset_type in ["NonCallableBond"]:
        # it is mortgage bond
        if country == "DK" and currency == "DKK":
            return "DKKMTGNYKSOFTBLT", "empty"
        if country == "SE" and currency == "SEK":
            return "SEKMTGBLEND", "empty"



def check_whether_isin_is_gov(isin):
    country , issuer_type , asset_type , currency = parse_info(isin)
    if issuer_type in ["Government" , "Guaranteed by Government"] and asset_type in ["NonCallableBond"]:
        # it is government bond
        if country == "DK" and currency == "DKK":
            return "DKKGOV", "empty","govt_bond"
        if country == "SE" and currency == "SEK":
            return "SEKGOV", "empty","govt_bond"
        if country == "FI" and currency == "EUR":
            return "FIMGOV", "empty","govt_bond"
        if country == "NO" and currency == "NOK":
            return "NOKGOV", "empty","govt_bond"
        else:
            try:
                bond_curve,credit_curve = check_whether_eu_gov_bond(isin)
                return bond_curve,credit_curve,"eu_gov_bond"
            except:
                return


def get_proxy(isin):
    class_obj = credit_bond_mapping.static_data_mapping([isin])
    rating = class_obj.getRating()[isin]
    sector = class_obj.getSector()[isin]
    region = class_obj.getRegion()[isin]
    if rating is 'null':
        rating = 'A'
        print('WARING from proxy service : no rating, has been directed to rating A')

    if sector is 'null':
        sector = 'FINANCE'
        print('WARING from proxy service : no sector, has been directed to industry finance')

    if region is 'null':
        region = 'WORLD'
        print('WARING from proxy service : no REGION, has been directed to region world')

    credit_curve = sector + '_' + region + '_' + rating
    return 'empty',credit_curve

@easy_cache(_global_cache_folder)
def curveName2interest_id(curveName):
    # get back the interest_id based on the excel sheet got from market data team.
    df = pd.read_csv('c:/working/git/code-lib/core/risk/frtb_credit/infoat_interest_newrf.csv')
    interest_id =  int(df[df['NAME']==curveName]['INTEREST_ID'])
    return interest_id



def parse_info(isin):
    issuer_information = get_issuer_information([isin])
    core_information = get_core_information([isin])
    country = issuer_information.iloc[0]['Country']
    issuer_type = issuer_information.iloc[0]['IssuerTypeDescription']
    asset_type = core_information.iloc[0]['AssetType']
    currency = core_information.iloc[0]['Currency']
    return country, issuer_type,asset_type,currency

if __name__ == '__main__':
    # govt bond
    #print(get_rf_for_isin('FI4000047089'))
    # mortgage bond
    #print(get_rf_for_isin('DK0009779340'))
    # credit bond
    #print(get_rf_for_isin('DK0009763344'))

    # eu gov bond
    print(get_rf_for_isin('NO0010635691'))

    print(get_rf_for_isin('NO0010297500'))
