import quantum as qt
# from core.utils.marketDataCache import *
from core.risk.frtb_credit.credit_prototype import credit_prototype

import core.utils.date_helper as dateutils


class credit_prototype_ng(credit_prototype):

    def __init__(self, ISIN_Lists,name,analysisStartDate,analysisEndDate,bond_curve_source='marsp',bond_price_source='MDS',resultFilePath='default'):

        # call the frtb prototype
        credit_prototype.__init__(self, ISIN_Lists=ISIN_Lists,
                              name=name,
                              analysisStartDate = analysisStartDate,
                              analysisEndDate=analysisEndDate)


    # Added by ngs 2016-01-19
    def LoadTRMPOtherQuantities(self, portfolio, date0, date1, ISIN_lists_calypso_other):
        print('... Loading TRMP other (calypso) profit and loss ...')
        # Fetch data from TRMP
        ######### Connection to TRMP #########
        import pyodbc
        # print(pyodbc.drivers()) #Get list of installed drivers

        conf = {"connection": "Driver={Oracle in OraClient11Home_x64_1}; Dbq=trmp;"}
        connection_string = conf["connection"] + "Trusted_Connection=yes;"
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        try:  # check if any items in ISIN list
            SQL = '''SELECT report_date, sum(mtm_recalc) mtm_recalc, sum(fx_mtm_recalc) fx_mtm_recalc
                  FROM FCUSER.PLX_T_CAL_BOND_OUTPUT
                  WHERE portfolio = '%(portfolio)s'
                  AND REPORT_DATE between (Date '%(date0)s') and (Date '%(date1)s')
                  --AND POSITION_INDICATOR = 'TRUE'
                  AND isin in (
                  ''' % locals()

            for isin in ISIN_lists_calypso_other:  # Used when only government bonds are needed #ngs 18 jan 2017
                SQL += "'" + isin + "',"
            SQL = SQL[:-1]  # remove the last ","
            SQL += ') '

            SQL += ''' GROUP BY report_date '''

            print(SQL)

            # TRMP_data = {}
            # Export TRMP data to dataframe
            Output = []
            Output_names = ['report_date', 'mtm_recalc', 'fx_mtm_recalc']
            for rownum, trmp_data in enumerate(cursor.execute(SQL)):
                # Get quantities and day-to-day PL for each ISIN
                Output.append([trmp_data[0], trmp_data[1], trmp_data[2]])
            # Export to dataframe
            df_Output = pd.DataFrame(data=Output, columns=Output_names)
            df_Output.name = 'TRMP_Other_agg_data'
            # Append to the self object
            self.resultDataFrameList.append(df_Output)
            self.resultDataFrameName.append('TRMP_Other_agg_data')

        except Exception as e:
            print('... Failed to load other TRMP (Calypso) data ...')

        print('... Next: Loading TRMP hedge (Listed products) profit and loss ...')
        connection_hedge = pyodbc.connect(connection_string)
        cursor_hedge = connection_hedge.cursor()

        SQL = '''SELECT report_date, sum(mtm_eur) mtm_eur, sum(mtm_fx_eur) mtm_fx_eur
                  FROM FCUSER.PLX_T_RNG_TOTAL_OUTPUT
                  WHERE portfolio = '%(portfolio)s'
                  AND REPORT_DATE between (Date '%(date0)s') and (Date '%(date1)s')
                  --AND REPORT_DATE <> (Date '%(date0)s')
                  group by report_date
                  ''' % locals()

        print(SQL)

        Output = []
        Output_names = ['report_date', 'mtm_eur', 'mtm_fx_eur']
        for rownum, trmp_data in enumerate(cursor_hedge.execute(SQL)):
            # Get quantities and day-to-day PL for each ISIN
            Output.append([trmp_data[0], trmp_data[1], trmp_data[2]])
        # Export to dataframe
        df_Output = pd.DataFrame(data=Output, columns=Output_names)
        df_Output.name = 'TRMP_Other_agg_data'
        # Append to the self object

        try:
            self.resultDataFrameList.append(df_Output)
            self.resultDataFrameName.append('TRMP_Hedges_agg_data')
        except:
            print('... could not fetch trmp hedges agg data ...')


    def LoadMARSQuantities(self, portfolio, date0, date1, ISIN_lists):
        print('... Loading MARS quantities ...')
        # Fetch data from MARS

        portfolio = str(portfolio) + ', CAL'  # Because naming in MARS tables is different from TRMP tables.

        def GetEffectID(isin):
            import cx_Oracle
            connection = cx_Oracle.connect("MARS_TEST", "AYD4YZPT00UZZ0XC",
                                           "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=ora_infop)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=infop)))")
            cursor = connection.cursor()

            SQL = '''select a.effect_id from marsp.isin_effect a where a.ISIN = '{isin}'  '''.format(**locals())
            print(SQL)
            cursor.execute(SQL)
            for row in cursor.execute(SQL):
                return row[0]

        def GetQuantities(date0, date1, effect_id, portfolio):
            import cx_Oracle
            connection = cx_Oracle.connect("MARS_TEST", "AYD4YZPT00UZZ0XC",
                                           "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=ora_infop)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=infop)))")
            cursor = connection.cursor()
            cursor2 = connection.cursor()

            # Find org_id based on portofolio name
            SQL = """select org_id from marsp.org where name = '"""
            SQL += portfolio
            SQL += """'"""

            # org_id = cursor.execute(SQL)[0]
            try:
                for org_ids in cursor.execute(SQL):
                    org_id = org_ids[0]
            except:
                print('Could not determine org_id based on portfolio name')

            SQL = """SELECT a.eod_date, nvl(b.ISIN,PRIMARY_DATA_SOURCE_IDENTITY) ISIN,
                    SUM(QUANTITY) quantity,
                    --SUM(QUANTITY_BASE) quantity_base,
                    --SUM(MV) mv,
                    --SUM(MV_BASE) mv_base,
                    --a.effect_price,
                    a.effect_id
                  --FROM marsp.position_mv_h a
                  FROM marsp.position_h a
                       join marsp.effect_woc_link b on b.effect_id = a.effect_id
                  WHERE a.org_id = '"""
            SQL += str(org_id)
            SQL += """'
                  AND eod_date between (Date '%(date0)s') AND (Date '%(date1)s')
                  and a.effect_id = '%(effect_id)s'
                  GROUP BY nvl(b.ISIN,PRIMARY_DATA_SOURCE_IDENTITY),a.effect_id, a.eod_date--, a.effect_price
                  order by isin, eod_date
                  """ % locals()

            print(SQL)

            cursor.execute(SQL)
            for row in cursor.execute(SQL):
                yield {'eod_date': row[0], 'ISIN': row[1], 'quantity': row[2], 'effect_id': row[3]}
                # yield {'eod_date':row[0],'ISIN':row[1],'quantity':row[2],'quantity_base':row[3],'mv':row[4],'mv_base':row[5],'effect_price':row[6],'effect_id':row[7]}

        effect_ids = []
        for myISIN in ISIN_lists:
            effect_ids.append(GetEffectID(myISIN))  # Save effect_id to ISIN

        effect_ids = filter(None, effect_ids)
        print(effect_ids)
        # Get quantities for each ISIN

        Output_a = []
        Output = []
        Output_names = []

        # org_id = portfolio
        # org_id = '70113'

        for row1, myeffect_id in enumerate(effect_ids):
            for row2, myquantities in enumerate(GetQuantities(date0, date1, myeffect_id, portfolio)):
                if row1 == 0 and row2 == 0:
                    Output_names = myquantities.keys()  # save output names
                Output_a = []
                for measure in myquantities:
                    Output_a.append(myquantities[measure])  # save output data
                Output.append(Output_a)

        df_Output = pd.DataFrame(data=Output, columns=Output_names)
        print(df_Output)

        # Export to excel
        try:
            self.resultDataFrameList.append(df_Output)
            self.resultDataFrameName.append('MARS_data')
        except:
            print('... could not fetch mars data ...')


    # Added by ngs 2016-01-10
    def AppendTRMPQuantities(self, HPL_type):
        print('... Appending the TRMP Quantities ...')
        # Load the RTPL

        try:
            RTPL_DataFrame = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_All')]
            # RTPL_DataFrame = RTPL_DataFrame.rename(index=str, columns={"Position": "ISIN"}) #Rename one of the columns from position to ISIN
            # print(RTPL_DataFrame.head())
            TRMP_DataFrame = self.resultDataFrameList[self.resultDataFrameName.index('TRMP_data')]
            # RTPL_DataFrame=self.resultDataFrameList[self.resultDataFrameName=='TRMP_All']
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='can not find RTPL or TRMP DataFrame, the appending trmp quantities can not be processed')
            return

        RTPL_DataFrame['Day2'] = pd.to_datetime(RTPL_DataFrame['Day2'])
        TRMP_DataFrame['report_date'] = pd.to_datetime(TRMP_DataFrame['report_date'])

        print(RTPL_DataFrame.head())
        print(TRMP_DataFrame.head())

        # Merge RTPL and TRMP dataframes
        # df_Output = RTPL_DataFrame.merge(TRMP_DataFrame,how='left',left_on=['Day2','ISIN'],right_on=['report_date','isin']) #Could either do a left or a right join dependent on most complete data.
        # df_Output = RTPL_DataFrame.merge(TRMP_DataFrame,how='inner',left_on=['Day2','ISIN'],right_on=['report_date','isin']) #Could either do a left or a right join dependent on most complete data.
        df_Output = RTPL_DataFrame.merge(TRMP_DataFrame, how='inner', left_on=['Day2', 'Position'],
                                         right_on=['report_date',
                                                   'Position'])  # Could either do a left or a right join dependent on most complete data.
        df_Output['Q_RTPL'] = df_Output['RTPL'] * df_Output[
            'pos_eod_0'] / 100  # Divide by 100 since prototype calculates rtpl/hpl wrt a nominal value of 100.
        df_Output['Q_HPL'] = df_Output['HPL'] * df_Output[
            'pos_eod_0'] / 100  # dtd_calc corresponds to pnl from (ultimo) t-1 to t. pos_eod corresponds to holdings ultimo t. pos_eod_0 corresponds to holdings ultimo t-1.

        # raw_input("Press the <ENTER> key to continue...")

        # In the following we refer to equations (1) - (4) which has been specified in the document "RTPL and HPL versions".

        # CHOOSE VERSION OF HPL TO USE IN ANALYSIS:
        if HPL_type == 1:  # HPL version (1)
            df_Output['mtm_recalc'] = (df_Output['FX Rate D2'] * (df_Output['bond_price_d1_hpl']) - df_Output[
                'FX Rate D2'] * (df_Output['bond_price_d1'])) * df_Output[
                                          'pos_eod_0'] / 100  # we subtract accrued interest to get clean prices
            df_Output['fx_mtm_recalc'] = (df_Output['FX Rate D2'] * (df_Output['bond_price_d1']) - df_Output[
                'FX Rate D1'] * (df_Output['bond_price_d1'])) * df_Output['pos_eod_0'] / 100

            # df_Output['Q_unExplained_PL'] = (df_Output['mtm_recalc'] + df_Output['fx_mtm_recalc']) - df_Output['Q_RTPL'] #Unexplained PL (currently not used... unclear what dtd_calc is)
            df_Output['HPL_calc'] = df_Output['mtm_recalc'] + df_Output['fx_mtm_recalc']  # simple HPL


        elif HPL_type == 2:  # HPL version (2)
            df_Output['mtm_recalc'] = (df_Output['FX Rate D2'] * (df_Output['bond_price_d2']) - df_Output[
                'FX Rate D2'] * (df_Output['bond_price_d2_forwarded'])) * df_Output[
                                          'pos_eod_0'] / 100  # we subtract accrued interest to get clean prices
            df_Output['fx_mtm_recalc'] = (df_Output['FX Rate D2'] * (df_Output['bond_price_d2_forwarded']) -
                                          df_Output['FX Rate D1'] * (df_Output['bond_price_d2_forwarded'])) * \
                                         df_Output['pos_eod_0'] / 100

            # df_Output['Q_unExplained_PL'] = (df_Output['mtm_recalc'] + df_Output['fx_mtm_recalc']) - df_Output['Q_RTPL'] #Unexplained PL (currently not used... unclear what dtd_calc is)
            df_Output['HPL_calc'] = df_Output['mtm_recalc'] + df_Output['fx_mtm_recalc']  # simple HPL

        elif HPL_type == 3:  # HPL version (3)
            # ngs 2016-02-03: Changing the FX rates and bond prices to align with the prototype (for the use when calculating hpl- effectively overwriting the original columns)
            df_Output['mtm_recalc'] = (df_Output['FX Rate D2'] * (df_Output['bond_price_d2']) - df_Output[
                'FX Rate D2'] * (df_Output['bond_price_d1'])) * df_Output[
                                          'pos_eod_0'] / 100  # we subtract accrued interest to get clean prices
            df_Output['fx_mtm_recalc'] = (df_Output['FX Rate D2'] * (df_Output['bond_price_d1']) - df_Output[
                'FX Rate D1'] * (df_Output['bond_price_d1'])) * df_Output['pos_eod_0'] / 100
            # df_Output['Q_unExplained_PL'] = (df_Output['mtm_recalc'] + df_Output['fx_mtm_recalc']) - df_Output['Q_RTPL'] #Unexplained PL (currently not used... unclear what dtd_calc is)
            df_Output['HPL_calc'] = df_Output['mtm_recalc'] + df_Output['fx_mtm_recalc']  # simple HPL_calc

        # df_Output['Q_unExplained_PL'] = df_Output['HPL'] - df_Output['Q_RTPL']

        # df_Output['PROT_Q_unExplained_PL'] = df_Output['Q_HPL'] - df_Output['Q_RTPL'] #Unexplained PL
        # print(df_Output.head())

        # Append to the self object
        print(df_Output)

        self.resultDataFrameList.append(df_Output)
        self.resultDataFrameName.append('RTPL_agg')


    # Added by ngs 2016-01-13
    def AggregatePlDay(self):
        print('... Aggregating the RTPL, HPL, (TRMP HPL) for each day ...')
        # Load the RTPL, HPL and dtd_calc (with quantities)

        try:
            df = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_agg')]
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='can not find RTPL Quantities, the aggregate pl attribution can not be processed')
            return

        print(df.head())

        # df_Output = df.groupby(['Day1'])['dtd_calc','Q_RTPL','Q_HPL','Q_unExplained_PL'].sum() #currently not used... unclear what dtd_calc is
        # df_Output = df.groupby(['Day1'])['HPL','Q_RTPL','Q_HPL','Q_unExplained_PL','mtm_recalc','fx_mtm_recalc'].sum()
        df_Output = df.groupby(['Day1'])['HPL_calc', 'Q_RTPL', 'Q_HPL', 'mtm_recalc', 'fx_mtm_recalc'].sum()
        df_Output.rename(columns={'mtm_recalc': 'mtm_recalc_gov_bond', 'fx_mtm_recalc': 'fx_mtm_recalc_govbond'},
                         inplace=True)  # can be removed again later
        df_Output2 = df.groupby(['Day2'])['HPL_calc'].sum()  # Ugly solution to get Day2 in same format

        df_Output['Day1'] = df_Output.index.values
        df_Output['Day2'] = df_Output2.index.values  # continuation of ugly index solution

        # df_Output['Day2'] = df_Output2.index.values #Continuation of ugly but useful way to go day2.

        print(df_Output)

        # Other data (pnl) should be added if available
        try:
            TRMP_Hedges_agg_data = self.resultDataFrameList[self.resultDataFrameName.index('TRMP_Hedges_agg_data')]
            # RTPL_DataFrame=self.resultDataFrameList[self.resultDataFrameName=='TRMP_All']
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='There is no data from calypso available that is not captured by the prototype')
            print('There is no data from calypso available that is not captured by the prototype')

        # Hedge data (from infinity) should be added if available
        try:
            TRMP_Other_agg_data = self.resultDataFrameList[self.resultDataFrameName.index('TRMP_Other_agg_data')]
            # RTPL_DataFrame=self.resultDataFrameList[self.resultDataFrameName=='TRMP_All']
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='There is no hedge data available in RNG')
            print('There is no hedge data available in RNG')

        # Join other calypso data if available
        try:
            # df_Output = df_Output.merge(TRMP_Hedges_agg_data,how='outer',left_on=['Day2'],right_on=['report_date']) #Outer join in case that either prototype data or other calypso data not available/0 at some days.
            df_Output = df_Output.merge(TRMP_Hedges_agg_data, how='left', left_on=['Day2'], right_on=[
                'report_date'])  # Outer join in case that either prototype data or other calypso data not available/0 at some days.
        except:
            print('Could not join with other calypso data')

        # Join hedge infinity data if available
        try:
            # df_Output = df_Output.merge(TRMP_Other_agg_data,how='outer',left_on=['Day2'],right_on=['report_date']) #Outer join in case that either prototype data or other infinity data not available/0 at some days.
            df_Output = df_Output.merge(TRMP_Other_agg_data, how='left', left_on=['Day2'], right_on=[
                'report_date'])  # Outer join in case that either prototype data or other infinity data not available/0 at some days.
        except:
            print('Could not join with hedge (infinity) data')

        # Export the dataframe to self object
        print(df_Output)
        self.resultDataFrameList.append(df_Output)
        self.resultDataFrameName.append('RTPL_agg_Pl')


    # Added by ngs 2016-01-12
    def Q_plAttribution(self):
        print('... Performing Quantity PnL attribution test for each ISIN ...')
        # pl attribution code
        # workout how many months need have pl attribution
        noofPLAttributionMonths = (self.analysisEndDate.year - self.analysisStartDate.year) * 12 + \
                                  self.analysisEndDate.month - self.analysisStartDate.month + 1
        df2 = pd.DataFrame()

        try:
            RTPL_DataFrame = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_Quantities')]
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='can not find RTPL with Quantities DataFrame, the pl attribution with quantities can not be processed')
            return

        for currISIN in self.Position_Lists:
            # return the dataframe for pl attribution on this isin
            currISIN_PTPL_DataFrame = RTPL_DataFrame[RTPL_DataFrame['Position'] == currISIN]
            # loop on all these months
            currd = datetime.datetime(self.analysisStartDate.year, self.analysisStartDate.month, 1)
            for x in range(0, noofPLAttributionMonths):
                try:
                    nextd = qt.addTenor(date=currd, tenor='1M')
                    date_scope = (currISIN_PTPL_DataFrame['Day1'] >= self.convert_to_date(currd)) \
                                 & (currISIN_PTPL_DataFrame['Day1'] < self.convert_to_date(nextd))
                    dateFrameWithInScope = currISIN_PTPL_DataFrame[date_scope]
                    # unExplainedPL=dateFrameWithInScope.Q_unExplained_PL
                    unExplainedPL = dateFrameWithInScope.Q_HPL - dateFrameWithInScope.Q_RTPL
                    # HPL=dateFrameWithInScope.dtd_calc #currently not used as unclear what dtd_calc is
                    HPL = dateFrameWithInScope.HPL
                    Q_ratio1 = numpy.mean(unExplainedPL) / numpy.std(HPL, ddof=1)
                    Q_ratio2 = numpy.var(unExplainedPL) / numpy.var(HPL)
                except Exception as e:
                    self.trackError(errorMessage=e, position=currISIN, date=currd,
                                    comments='pl attribution not working for this ISIN and this period')
                    Q_ratio1 = 'na'
                    Q_ratio2 = 'na'
                df_signleAnalysis = pd.DataFrame(
                    [[currISIN, self.convert_to_date(currd), dateutils.to_date_str(nextd),
                      Q_ratio1, Q_ratio2
                      ]],
                    columns=['ISIN', 'start date', 'end date', 'Q_ratio1', 'Q_ratio2'
                             ])
                df2 = df2.append(df_signleAnalysis)
                currd = nextd

        self.resultDataFrameList.append(df2)
        self.resultDataFrameName.append('Q_PnLAttributionSummary')


    # Added by ngs 2016-01-12
    def Q_Pf_plAttribution(self, analysistype, wZspread='false'):
        print('... Performing Quantity PnL attribution test on pf/desk level ...')
        # pl attribution code
        # workout how many months need have pl attribution
        noofPLAttributionMonths = (self.analysisEndDate.year - self.analysisStartDate.year) * 12 + \
                                  self.analysisEndDate.month - self.analysisStartDate.month + 1
        df2 = pd.DataFrame()

        try:
            RTPL_DataFrame = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_agg_Pl')]
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='can not find RTPL with Quantities DataFrame, the pl attribution with quantities can not be processed')
            return

        # return the dataframe for pl attribution on all isin
        allISIN_PTPL_DataFrame = RTPL_DataFrame
        # loop on all these months
        currd = datetime.datetime(self.analysisStartDate.year, self.analysisStartDate.month, 1)
        for x in range(0, noofPLAttributionMonths):
            try:
                nextd = qt.addTenor(date=currd, tenor='1M')
                date_scope = (allISIN_PTPL_DataFrame['Day1'] >= self.convert_to_date(currd)) \
                             & (allISIN_PTPL_DataFrame['Day1'] < self.convert_to_date(nextd))
                dateFrameWithInScope = allISIN_PTPL_DataFrame[date_scope]

                # In the following we refer to equations (1) - (4) which has been specified in the document "RTPL and HPL versions".


                # Choose RTPL (1) or (4) which corresponds to choose without z-spread (4) and with z-spread (1)

                if analysistype == "onlyGovBonds":

                    if wZspread == 'false':  # choosing RTPL (4)
                        unExplainedPL = dateFrameWithInScope.HPL_calc - dateFrameWithInScope.Q_RTPL  # use prototype rtpl without zp
                    elif wZspread == 'true':  # choosing RTPL (1)
                        unExplainedPL = dateFrameWithInScope.HPL_calc - dateFrameWithInScope.Q_HPL  # use prototype rtpl with zspread
                    HPL = dateFrameWithInScope.HPL_calc
                    print(
                        '... Analysis: Only Gov Bonds - RTPL is calculated for all Gov bonds (of chosen country) ...')
                elif analysistype == "onlyCalypso":
                    if wZspread == 'false':  # choosing RTPL (4)
                        unExplainedPL = dateFrameWithInScope.HPL_calc + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc - (
                            dateFrameWithInScope.Q_RTPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc)  # Total HPL - Total RTPL (i.e. bonds covered by prototype + other calypso instruments)
                    elif wZspread == 'true':  # choosing RTPL (1)
                        unExplainedPL = dateFrameWithInScope.HPL_calc + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc - (
                            dateFrameWithInScope.Q_HPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc)  # Total HPL - Total RTPL (i.e. bonds covered by prototype + other calypso instruments)
                    HPL = dateFrameWithInScope.HPL_calc + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc  # HPL from TRMP + HPL from non covered instruments from calypso in the chosen book.
                    print(
                        '... Analysis: Only Calypso products - assume all products not covered by prototype satisfies RTPL=HPL ...')
                elif analysistype == "All":
                    #                     unExplainedPL= dateFrameWithInScope.HPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur + dateFrameWithInScope.mtm_fx_eur - (dateFrameWithInScope.Q_RTPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur + dateFrameWithInScope.mtm_fx_eur) #Total HPL - Total RTPL (i.e. bonds covered by prototype + other calypso instruments + Infinity products)
                    #                     HPL = dateFrameWithInScope.HPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur + dateFrameWithInScope.mtm_fx_eur #HPL from TRMP + HPL from non covered instruments from calypso in the chosen book and instruments from Infinity #reasons why we can use this line (and the one above) is because the fx_mtm_eur has the cash part included which is not in the other part.

                    # With Andys altered version: (i.e. we assume that the fx hedges perfectly):
                    if wZspread == 'false':  # choosing RTPL (4)
                        unExplainedPL = dateFrameWithInScope.HPL_calc + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond - (
                            dateFrameWithInScope.Q_RTPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond)  # Total HPL - Total RTPL (i.e. bonds covered by prototype + other calypso instruments + Infinity products)
                    elif wZspread == 'true':  # choosing RTPL (1)
                        unExplainedPL = dateFrameWithInScope.HPL_calc + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond - (
                            dateFrameWithInScope.Q_HPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond)  # Total HPL - Total RTPL (i.e. bonds covered by prototype + other calypso instruments + Infinity products)

                    HPL = dateFrameWithInScope.HPL_calc + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond  # HPL from TRMP + HPL from non covered instruments from calypso in the chosen book and instruments from Infinity
                    print('... Analysis: All - assume all products not covered by prototype satisfies RTPL=HPL ...')

                elif analysistype == "onlyProt":  # perform same analysis and "all" but using the prototype hpl instead of own calculated hpl.
                    unExplainedPL = dateFrameWithInScope.Q_HPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond - (
                        dateFrameWithInScope.Q_RTPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond)  # Total HPL - Total RTPL (i.e. bonds covered by prototype + other calypso instruments + Infinity products)
                    HPL = dateFrameWithInScope.Q_HPL + dateFrameWithInScope.mtm_recalc + dateFrameWithInScope.fx_mtm_recalc + dateFrameWithInScope.mtm_eur - dateFrameWithInScope.fx_mtm_recalc - dateFrameWithInScope.fx_mtm_recalc_govbond  # HPL from TRMP + HPL from non covered instruments from calypso in the chosen book and instruments from Infinity

                avg_unexpl = numpy.mean(unExplainedPL)
                var_unexpl = numpy.var(unExplainedPL, ddof=1)
                var_hpl = numpy.var(HPL, ddof=1)
                Q_ratio1 = numpy.mean(unExplainedPL) / numpy.std(HPL, ddof=1)
                Q_ratio2 = numpy.var(unExplainedPL) / numpy.var(HPL)

                # Other measures
                min_var_hpl_1 = self.Measure('min_var_hpl_1', avg_unexpl, var_unexpl, var_hpl)
                min_var_hpl_2 = self.Measure('min_var_hpl_2', avg_unexpl, var_unexpl, var_hpl)
                max_absmean = self.Measure('max_absmean', avg_unexpl, var_unexpl, var_hpl)
                max_var_unexpl = self.Measure('max_var_unexpl', avg_unexpl, var_unexpl, var_hpl)
                max_daily_hedge_pct = self.Measure('max_daily_hedge_pct', avg_unexpl, var_unexpl, var_hpl)

                # Correlation measures

                HPL_RTPL_corr = numpy.corrcoef(HPL, HPL - unExplainedPL)[1][0]  # correlation between HPL and RTPL
                HPL_UNEXPL_corr = numpy.corrcoef(HPL, unExplainedPL)[1][0]
                HPL_RTPL_corr_daily_hedge_pct = \
                    numpy.corrcoef(HPL * (1 - max_daily_hedge_pct),
                                   HPL * (1 - max_daily_hedge_pct) - unExplainedPL)[1][
                        0]  # correlation given minimum hedge percentage, i.e. calculating corr(HPL^h,RTPL^h) = corr(HPL(1-x),HPL(1-x)-UNEXPL))

                # print(min_var_hpl_1)
                # print(min_var_hpl_2)
                # print(max_absmean)
                # print(max_var_unexpl)
                print('max hgd pct: ' + str(max_daily_hedge_pct))
                print('corr: ' + str(HPL_RTPL_corr))
                print('corr w hedge pct: ' + str(HPL_RTPL_corr_daily_hedge_pct))

            except Exception as e:
                self.trackError(errorMessage=e, position="All isin", date=currd,
                                comments='pl attribution not working for this pf/desk level and this period')
                Q_ratio1 = 'na'
                Q_ratio2 = 'na'
                min_var_hpl_1 = 'na'
                min_var_hpl_2 = 'na'
                max_absmean = 'na'
                max_var_unexpl = 'na'
                max_daily_hedge_pct = 'na'
            df_signleAnalysis = pd.DataFrame([["allISIN", self.convert_to_date(currd), dateutils.to_date_str(nextd),
                                               avg_unexpl, var_unexpl, var_hpl,
                                               Q_ratio1, Q_ratio2, min_var_hpl_1, min_var_hpl_2, max_absmean,
                                               max_var_unexpl, max_daily_hedge_pct, HPL_RTPL_corr, HPL_UNEXPL_corr,
                                               HPL_RTPL_corr_daily_hedge_pct, str(analysistype) + str('_Z_no')
                                               ]],
                                             columns=['ISIN', 'start date', 'end date', 'avg unexp', 'var unexp',
                                                      'var trmp hpl', 'Q_ratio1', 'Q_ratio2', 'min_var_hpl_1',
                                                      'min_var_hpl_2', 'max_absmean', 'max_var_unexpl',
                                                      'max_daily_hedge_pct', 'HPL_RTPL_corr', 'HPL_UNEXPL_corr',
                                                      'HPL_RTPL_corr_daily_hedge_pct', 'analysis'
                                                      ])
            df2 = df2.append(df_signleAnalysis)
            currd = nextd

        # Aggregate statistics
        try:
            print(df2['max_daily_hedge_pct'].sort_values(ascending=[False]))
            df2['max_period_hedge_pct'] = df2['max_daily_hedge_pct'].sort_values(ascending=[False]).iloc[
                3]  # Take the 3rd largest hedge percentage out
        except:
            print(
                '... could not determine aggregate statistics. Could it be because to small time-range is considered? ...')

        self.resultDataFrameList.append(df2)
        if wZspread == 'false':
            self.resultDataFrameName.append(
                'Q_Pf_PnLAtt_' + str(analysistype) + str('_Z_no'))  # excluding zspread in rtpl
        elif wZspread == 'true':
            self.resultDataFrameName.append(
                'Q_Pf_PnLAtt_' + str(analysistype) + str('_Z_yes'))  # including zspread in rtpl



            # Added by ngs 2016-01-12


    def Q_Pf_plAttribution_PROT(self):
        print('... Performing Quantity PnL attribution test on pf/desk level (HPL prot vs RTPL prot) ...')
        # pl attribution code
        # workout how many months need have pl attribution
        noofPLAttributionMonths = (self.analysisEndDate.year - self.analysisStartDate.year) * 12 + \
                                  self.analysisEndDate.month - self.analysisStartDate.month + 1
        df2 = pd.DataFrame()

        try:
            RTPL_DataFrame = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_agg_Pl')]
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='can not find RTPL with Quantities DataFrame, the pl attribution with quantities can not be processed')
            return

        # return the dataframe for pl attribution on this isin
        allISIN_PTPL_DataFrame = RTPL_DataFrame
        # loop on all these months
        currd = datetime.datetime(self.analysisStartDate.year, self.analysisStartDate.month, 1)
        for x in range(0, noofPLAttributionMonths):
            try:

                nextd = qt.addTenor(date=currd, tenor='1M')
                date_scope = (allISIN_PTPL_DataFrame['Day1'] >= self.convert_to_date(currd)) \
                             & (allISIN_PTPL_DataFrame['Day1'] < self.convert_to_date(nextd))
                dateFrameWithInScope = allISIN_PTPL_DataFrame[date_scope]
                unExplainedPL = dateFrameWithInScope.Q_HPL - dateFrameWithInScope.Q_RTPL
                # HPL=dateFrameWithInScope.dtd_calc #currently not used as unclear what dtd_calc is
                HPL = dateFrameWithInScope.Q_HPL
                avg_unexpl = numpy.mean(unExplainedPL)
                var_unexpl = numpy.var(unExplainedPL, ddof=1)
                var_hpl = numpy.var(HPL, ddof=1)
                Q_ratio1 = numpy.mean(unExplainedPL) / numpy.std(HPL, ddof=1)
                Q_ratio2 = numpy.var(unExplainedPL) / numpy.var(HPL)

                min_var_hpl_1 = self.Measure('min_var_hpl_1', avg_unexpl, var_unexpl, var_hpl)
                min_var_hpl_2 = self.Measure('min_var_hpl_2', avg_unexpl, var_unexpl, var_hpl)
                max_absmean = self.Measure('max_absmean', avg_unexpl, var_unexpl, var_hpl)
                max_var_unexpl = self.Measure('max_var_unexpl', avg_unexpl, var_unexpl, var_hpl)
                max_daily_hedge_pct = self.Measure('max_daily_hedge_pct', avg_unexpl, var_unexpl, var_hpl)


            except Exception as e:
                self.trackError(errorMessage=e, position="All isin", date=currd,
                                comments='pl attribution not working for this pf/desk level and this period')
                Q_ratio1 = 'na'
                Q_ratio2 = 'na'

            df_signleAnalysis = pd.DataFrame([["allISIN", self.convert_to_date(currd), dateutils.to_date_str(nextd),
                                               avg_unexpl, var_unexpl, var_hpl,
                                               Q_ratio1, Q_ratio2, min_var_hpl_1, min_var_hpl_2, max_absmean,
                                               max_var_unexpl, max_daily_hedge_pct, 'PROT'
                                               ]],
                                             columns=['ISIN', 'start date', 'end date', 'avg unexp', 'var unexp',
                                                      'var trmp hpl', 'Q_ratio1', 'Q_ratio2', 'min_var_hpl_1',
                                                      'min_var_hpl_2', 'max_absmean', 'max_var_unexpl',
                                                      'max_daily_hedge_pct', 'analysis'
                                                      ])
            df2 = df2.append(df_signleAnalysis)
            currd = nextd

        # Aggregate statistics
        try:
            print(df2['max_daily_hedge_pct'].sort_values(ascending=[False]))
            df2['max_period_hedge_pct'] = df2['max_daily_hedge_pct'].sort_values(ascending=[False]).iloc[
                2]  # Take the 3rd largest hedge percentage out
        except:
            print(
                '... could not determine aggregate statistics. Could it be because to small time-range is considered? ...')

        # Might have two breaches for some months -> could check by counting number of

        self.resultDataFrameList.append(df2)
        self.resultDataFrameName.append('Q_Pf_PnLAttSummary_PROT')


    def Measure(self, measure, avg_unexpl, var_unexpl, var_hpl):
        import math
        print('... Check other possible measures  ...')

        # Find minimum required hpl variance given unexplained mean
        if measure == 'min_var_hpl_1':
            return pow(abs(avg_unexpl) / 0.1, 2)  # variable = unexplained mean

        # Find minimum required hpl variance given unexplained var
        if measure == 'min_var_hpl_2':
            return avg_unexpl / 0.2  # variable = unexplained mean

        # Find minimum absolute mean required given hpl variance
        if measure == 'max_absmean':
            return 0.1 * math.sqrt(var_hpl)  # variable = hpl variance

        # Find maximum unexplained variance given hpl variance
        if measure == 'max_var_unexpl':
            return 0.2 * var_hpl  # hpl variance

        # Hedge in percentage

        # Tests how many percentage the daily HPL can decrease by assuming that the daily unexplained = HPL-RTPL remains unchanged
        if measure == 'max_daily_hedge_pct':
            # hedge ratio based on mean ratio
            x = 1 - abs(avg_unexpl) / (
                0.1 * math.sqrt(var_hpl))  # negative if currently failing r1 else positive
            # hedge ratio based on variance ratio
            y = 1 - math.sqrt(var_unexpl / (0.2 * var_hpl))  # negative if currently failing r2 else positive
            return min(x,
                       y)  # return the hedge ratio based on the ratio test that becomes binding first.


    def LoadTRMPQuantities(self, portfolio, date0, date1, ISIN_lists):
        print('... Loading TRMP quantitites ...')
        # Fetch data from TRMP
        ######### Connection to TRMP #########
        import pyodbc
        # print(pyodbc.drivers()) #Get list of installed drivers

        conf = {"connection": "Driver={Oracle in OraClient11Home_x64_1}; Dbq=trmp;"}
        #connection_string = getconstr.get_string(database_alias='TRMP_RO')
        connection_string = conf["connection"]+ "Trusted_Connection=yes;" #ngs01      
        
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        date0_str=date0.strftime('%Y%m%d')
        date1_str=date1.strftime('%Y%m%d')


        SQL = '''SELECT report_date, isin, mtm_recalc, fx_mtm_recalc , pos_eod, pos_eod_0, price_eod_0, price_eod, fx_rate, fx_rate_1
        FROM FCUSER.PLX_T_CAL_BOND_OUTPUT
        WHERE portfolio = '%(portfolio)s'
        AND REPORT_DATE between to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
        AND POSITION_INDICATOR = 'TRUE'
        AND isin in (
        ''' % locals()

        for isin in ISIN_lists:  # Used when only government bonds are needed #ngs 18 jan 2017
            SQL += "'" + isin + "',"
        SQL = SQL[:-1]  # remove the last ","
        SQL += ') '
        print(SQL)

        # Export TRMP data to dataframe
        Output = []
        Output_names = ['report_date', 'Position', 'mtm_recalc', 'fx_mtm_recalc', 'pos_eod', 'pos_eod_0', 'price_eod_0',
                        'price_eod', 'fx_rate', 'fx_rate_1']
        for rownum, trmp_data in enumerate(cursor.execute(SQL)):
            # Get quantities and day-to-day PL for each ISIN
            Output.append(
                [trmp_data[0], trmp_data[1], trmp_data[2], trmp_data[3], trmp_data[4], trmp_data[5], trmp_data[6],
                 trmp_data[7], trmp_data[8], trmp_data[9]])
        # Export to dataframe
        df_Output = pd.DataFrame(data=Output, columns=Output_names)
        df_Output.name = 'TRMP_data'
        print('... Loading TRMP quantitites finsihed ...')
        # Append to the self object
        self.resultDataFrameList.append(df_Output)
        self.resultDataFrameName.append('TRMP_data')