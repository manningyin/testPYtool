import orca
import quantum as qt
from orca.types import TradeIdentifier, SourceSystem , InfinityMarketDataName
import datetime
from orca import pretty_print
import numpy as np
import math

def flat_scenario_convertor(curve1,curve2):
    return

# a becnhamrk method for compare ....
def convert_scenario_interpolation(credit_curve1,credit_curve2,anchorDate,buckets):
    curve1 = credit_curve1.hazardCurve
    curve2 = credit_curve2.hazardCurve
    d_l = []
    r_l = []
    for bucket in buckets:
        d = qt.addTenor(anchorDate,bucket)
        d_l.append(qt.addTenor(anchorDate,bucket))
        r_l.append(curve2.getVal(d) - curve1.getVal(d))
    return qt.CurveFlat.make(d_l,r_l)

def return_date_lists_for_bumps(buckets,startd):
    d_l = []
    for bucket in buckets:
        d_l.append(qt.addTenor(startd, bucket))
    return d_l

def return_matrix_for_flat_interpolation(target_date_List, buckets, asofdate):
    m =len(target_date_List)
    n = len(buckets)
    out = np.zeros((m,n))
    bump_date_list = return_date_lists_for_bumps(buckets,asofdate)
    for i in range(0,m):
        idx = find_right_dates(d_l = bump_date_list, target_d= target_date_List[i])
        out[i,idx] = 1
    return out

def find_right_dates(d_l,target_d):
    out = 0
    while d_l[out]<target_d:
        out = out + 1
    return out

def remove_all_zero_cols(M):
    s = M.sum(axis=0)
    non_zero_entry = np.where(s != 0)[0]
    return M[:,non_zero_entry],non_zero_entry

def return_b_vector(curve1,curve2 ,date_list):
    d_l = date_list
    M = len(d_l)
    r_l = np.zeros((M,1))
    for i in range(0,M):
        r_l[i,0]= curve2.getVal(d_l[i]) - curve1.getVal(d_l[i])
    return r_l

def make_qt_curve(buckets,rates,anchorDate):
    d_l = [qt.addTenor(anchorDate,x) for x in buckets]
    return qt.CurveFlat.make(d_l,rates)


def convert_scenario_via_zero_harzard_rate(credit_curve1,credit_curve2,anchorDate,buckets):
    #orca_curve_d1_fwd = credit_curve1.forwardedCreditCurveInterpolated(anchorDate)

    zero_harzard_curve_risk_d1 = record_fo_curve_via_zero_harzard_rate(credit_curve1,buckets)
    zero_harzard_curve_risk_d2 = record_fo_curve_via_zero_harzard_rate(credit_curve2, buckets)
    d_l = []
    r_l = []
    for bucket in buckets:
        d = qt.addTenor(anchorDate, bucket)
        d_l.append(qt.addTenor(anchorDate, bucket))
        r_l.append(zero_harzard_curve_risk_d2.getVal(d) - zero_harzard_curve_risk_d1.getVal(d))
    return qt.CurveFlat.make(d_l, r_l)

def convert_scenario_via_zero_harzard_rate_multiply(credit_curve1,credit_curve2,anchorDate,buckets):
    #orca_curve_d1_fwd = credit_curve1.forwardedCreditCurveInterpolated(anchorDate)

    zero_harzard_curve_rate_d1 = record_fo_curve_via_zero_harzard_rate(credit_curve1,buckets)
    zero_harzard_curve_rate_d2 = record_fo_curve_via_zero_harzard_rate(credit_curve2, buckets)
    d_l, r_l = calculate_mutiple_bumps(zero_harzard_curve_rate_d1,zero_harzard_curve_rate_d2,anchorDate,buckets)
    return qt.CurveFlat.make(d_l, r_l)

def calculate_mutiple_bumps(zero_harzard_curve_rate_d1,zero_harzard_curve_rate_d2,anchorDate,buckets):
    d_l = []
    r_l = []
    for i in range(0,len(buckets)):
        bucket = buckets[i]
        d = qt.addTenor(anchorDate, bucket)
        d_l.append(qt.addTenor(anchorDate, bucket))
        r_l.append(zero_harzard_curve_rate_d2[i]/zero_harzard_curve_rate_d1[i])
    return d_l,r_l


def convert_scenario_via_zero_harzard_rate_sub(credit_curve1,credit_curve2,anchorDate,buckets):
    #orca_curve_d1_fwd = credit_curve1.forwardedCreditCurveInterpolated(anchorDate)
    zero_harzard_curve_rate_d1 = record_fo_curve_via_zero_harzard_rate(credit_curve1, buckets)
    zero_harzard_curve_rate_d2 = record_fo_curve_via_zero_harzard_rate(credit_curve2, buckets)
    d_l, r_l = calculate_mutiple_bumps(zero_harzard_curve_rate_d1, zero_harzard_curve_rate_d2, anchorDate, buckets)
    scenario_curve = qt.CurveFlat.make(d_l, r_l)
    common_date_list = list(set(scenario_curve._get_dates() + credit_curve2.hazardCurve._get_dates()))
    final_rate = []
    for d in common_date_list:
        final_rate.append(credit_curve1.hazardCurve.getVal(d) * scenario_curve.getVal(d))
    return qt.CurveFlat.make(common_date_list,final_rate)




def record_fo_curve_via_zero_harzard_rate(credit_curve , buckets):
    zero_harzard_curve_risk = get_zero_harzard_rate(credit_curve, buckets)
    (d_l, r_l) = transform_zero_harzard_rate_to_flat_harzard_rate(credit_curve.anchorDate,
                                                            zero_harzard_curve_risk._get_dates(),
                        [zero_harzard_curve_risk.getVal(d) for d in zero_harzard_curve_risk._get_dates()])
    return r_l


def convert_zero_harzard_rate_scenario_to_orca_scenario(zero_harzard_curve_d1, orca_curve_d1, orca_curve_d2, zero_harzard_shock,date_list):
    orca_curve_d1_fwd = orca_curve_d1.forwardedCreditCurveInterpolated(orca_curve_d2.anchorDate)
    zero_harzard_rate_d2_list = [zero_harzard_curve_d1.getVal(d) + zero_harzard_shock.getVal(d) for d in date_list]
    (d_l,flat_harzard_rate_d2) = transform_zero_harzard_rate_to_flat_harzard_rate(d = orca_curve_d2.anchorDate,
                                                                            d_l= date_list,
                                                                            r_l = zero_harzard_rate_d2_list)
    flat_harzard_rate_d2_qt= qt.CurveFlat.make(d_l,flat_harzard_rate_d2)
    bump_list = []
    std_bump_dates = d_l
    for d in std_bump_dates:
        bump_list.append(flat_harzard_rate_d2_qt.getVal(d) - orca_curve_d1_fwd.hazardCurve.getVal(d))
    return qt.CurveFlat.make(std_bump_dates,bump_list)


def convert_scenario_by_interpolation_on_FO_bumps(credit_curve1,credit_curve2,anchorDate,buckets):
    curve1 = credit_curve1.hazardCurve
    curve2 = credit_curve2.hazardCurve
    target_date_list = list(set(curve1._get_dates() + curve2._get_dates()))
    rate_list = return_b_vector(curve1, curve2,target_date_list)
    curve_type = curve1._get_typename()
    if curve_type == u'CurveCatrom':
        interpolation_method = qt.CurveCatrom
    elif curve_type == u'CurveFlat':
        interpolation_method = qt.CurveFlat
    elif curve_type == u'CurveLinear':
        interpolation_method = qt.CurveLinear
    else:
        interpolation_method = None

    fo_bump_curve = interpolation_method.make(target_date_list,rate_list)
    risk_date_list = [qt.addTenor(anchorDate,x) for x in buckets]
    risk_bump_list = [fo_bump_curve.getVal(d) for d in risk_date_list]
    return interpolation_method.make(risk_date_list,risk_bump_list)



def convert_flat_scenario(credit_curve1,credit_curve2,anchorDate,buckets):
    # ===================================================================================
    # this is the code to convert the scenario by solving linear system
    # ===================================================================================
    curve1 = credit_curve1.hazardCurve
    curve2 = credit_curve2.hazardCurve
    target_date_List = curve2._get_dates()
    M = return_matrix_for_flat_interpolation(target_date_List=target_date_List,
                                             buckets=buckets,
                                             asofdate=anchorDate)
    new_M, non_zero_entry = remove_all_zero_cols(M)

    b_l = return_b_vector(curve1, curve2,target_date_List)

    x_vec = np.linalg.solve(new_M, b_l)

    curve = make_qt_curve(buckets = [buckets[x] for x in non_zero_entry.tolist()],
                           rates = [x[0] for x in x_vec.tolist()],
                           anchorDate=anchorDate)

    rate_list = [curve.getVal(qt.addTenor(anchorDate,x)) for x in buckets]

    return make_qt_curve(buckets = buckets,
                           rates = rate_list,
                           anchorDate=anchorDate)



def get_zero_harzard_rate(credit_curve,buckets):
    d = credit_curve.anchorDate
    d_list = [qt.addTenor(d,x) for x in buckets]
    prob_curve = [credit_curve.survivalProb(x) for x in d_list ]
    zero_harzard_rate= [-math.log(x) for x in prob_curve]
    return qt.CurveLinear.make(d_list,zero_harzard_rate)


def return_day_count_list(d, d_list):
    return [qt.yearfraction(d, x, qt.DayCount.ACT36525) for x in d_list]


def transform_zero_harzard_rate_to_flat_harzard_rate(d, d_l,r_l):
    out = [0] * len(r_l)
    dt = return_day_count_list(d,d_l)
    for i in range(0,len(r_l)):
        zero_harzard_rate = r_l[i]
        if i == 0:
            out[i] = zero_harzard_rate
        else:
            out[i] = ( r_l[i]  -  r_l[i-1]) / float(dt[i] - dt [i-1])
    return (d_l,out)


if __name__ == '__main__':
    from core.connection import orca_connect

    value_time_stamp_d1 = datetime.datetime(2017, 2, 23, 19)
    value_time_stamp_d2 = datetime.datetime(2017, 3, 23, 19)
    db_time_stamp = datetime.datetime(2017, 9, 13, 23, 59)

    credit_curve_names = InfinityMarketDataName("CDXHY_S26",
                                                qt.Currency.USD,
                                                qt.MarketDataInstanceCode.OPEN)

    ois_curve_names = InfinityMarketDataName("USDOISD_V",
                                                qt.Currency.USD,
                                                qt.MarketDataInstanceCode.OPEN)

    def get_context_time_stamp(d):
        return (d, db_time_stamp)

    req = orca_connect.get_orca_request()
    ois_curve = req.get_curve(curve_name=ois_curve_names, context_time_stamp=get_context_time_stamp(value_time_stamp_d1)).result()
    credit_curve_d1 = req.get_credit_curve(context_time_stamp= get_context_time_stamp(value_time_stamp_d1),
                                            curve_name=credit_curve_names).result()

    credit_curve_d2 = req.get_credit_curve(context_time_stamp=get_context_time_stamp(value_time_stamp_d2),
                                           curve_name=credit_curve_names).result()

    temp = convert_scenario_via_zero_harzard_rate_sub(credit_curve1 = credit_curve_d1,
                                          credit_curve2 = credit_curve_d2,
                                          anchorDate = value_time_stamp_d1,
                                          buckets = ['1D','7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '12Y','15Y', '20Y', '25Y', '30Y', '50Y'])
    print(temp)
    curve1 = credit_curve_d1.hazardCurve
    curve2 = credit_curve_d2.hazardCurve
    buckets = ['1D','7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '12Y','15Y', '20Y', '25Y', '30Y', '50Y']

    (d_l,r_l) = get_zero_harzard_rate(credit_curve=credit_curve_d1,buckets = buckets)

    flat_harzard_rate = transform_zero_harzard_rate_to_flat_harzard_rate(d = credit_curve_d1.anchorDate,
                                                          d_l = d_l,
                                                          r_l = r_l)
    print(flat_harzard_rate)


    print(convert_scenario_by_interpolation_on_FO_bumps(credit_curve1 = credit_curve_d1,
                                credit_curve2 = credit_curve_d2,
                                anchorDate=credit_curve_d2.anchorDate,
                                buckets = buckets) )



