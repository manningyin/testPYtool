

'''
The prototype of simple govt bond model

The simple credit bond prototype, one code include all following modules:
* RTPL calculation
* PnL Attribution
* Caculate expected shortfall
* Calculate NMRF
* Calculate final capital charge based on two secnario: whether include z spread in the risk factor

All module works on single ISIN level

The module aims to handle everything needed for simple credit bond in FRTB context

Warning:
    Some comment of the code has not been finished yet!

Notes:
    Author: g48454 (Shengyao Zhu)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       14122016     G48454     Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''


import copy
import decimal
import math as math
import time
try:
    import core.market_data.other_legacy_code.getCurvePriceFromDAMD as GETCURVE
    import core.risk.frtb_credit.isin_rf_mapping as isin_rf_mapping
    import core.risk.frtb_prototype_context as context_manager
except:
    pass

import numpy as np
import orca.utilities.soap as soap
import quantum as qt
from core.risk.frtb_prototype import frtb_prototype

import core.finance.bondpricing_central as BPC
import core.market_data.old_loaders.fx_rates as fx_rates
import core.utils.date_helper as dateutils
import core.utils.version_independent as version_indp
from core.utils.RawTimeSeries import RawTimeSeries
from core.utils.date_helper import *
from core.utils.market_data_cache import *


class credit_prototype(frtb_prototype):

    def __init__(self, ISIN_Lists,name,analysisStartDate,analysisEndDate,resultFilePath='default', context_instance = None):

        # call the frtb prototype
        frtb_prototype.__init__(self, Pos_Lists=ISIN_Lists,
                              name=name,
                              analysisStartDate = analysisStartDate,
                              analysisEndDate=analysisEndDate,
                              resultFilePath=resultFilePath)


        # decide the product type, currently based on the first bond on the top of the lists
        topISIN = self.Position_Lists[0]
        bondType = topISIN[0:2]

        # get context
        if context_instance is None:
            context_instance = context_manager.BondContextManager.get_instance()

        # assign all attributes
        self.bond_curve_source=context_instance.bond_curve_source
        self.bond_price_source=context_instance.bond_price_source
        self.rate_source = context_instance.rate_scenario

        self.get_static_data()
        self.ccy = self.getBackCurrencyForEachISIN(bondType)
        self.riskFreeCurve = self.ccy + '-XO_CURVE'
        self.mars_interest_id = str(isin_rf_mapping.curveName2interest_id(self.riskFreeCurve))
        self.riskFactorBuckets = ['7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '12Y',
                                '15Y', '20Y', '25Y', '30Y', '50Y']
        self.cdsBuckets = ['1Y','2Y','5Y','7Y','10Y']
        # TODO: someone need fix this:
        self.Modelability_File = 'isin_NMRF.xlsx'
        self.Modelability_File_backup='C:/Temp/NMRF/isin_NMRF.xlsx'
        self.riskFactorLists = ['bondSwapBasis',
                              'riskfreecurve',
                              'zSpread',
                              'fxRate',
                               'cdsspread']


        # ===================================================================================
        # Allow user use an IR curve as a proxy for bond curve,
        # The field can be changed to true by call method use_ir_curve_as_bond_curve
        # ===================================================================================
        self.proxy_bond_curve_by_ircurve = False
        self.DAMD_concet_string = ''
        self.express_pnl_in_org_ccy = False

        # ===================================================================================
        # this option will decide whether a outlier zspread cleanning need be performed
        # ===================================================================================

        self.clean_outlier_for_zspread = False
        self.outlier_clean_time_window = 120
        self.outlier_clean_no_of_stddev = 4

        # ===================================================================================
        # whether should use cds curve as risk factor
        # ===================================================================================
        self.use_cds_curve_in_pricing = False
        self.cds_curve_name = "empty"

        # ===================================================================================
        # Here we active the external curve mode, user can also choose to run this method again after initial the credit prototype object.
        # By default, the curve name is directed to the govt bond curve.
        # ===================================================================================
        self.activate_external_curve_mode()

    def getBackRiskFactorForEachISIN(self):
        ##################################################
        # get risk factor specification
        ##################################################
        df = pd.DataFrame()
        print('Following risk factors have been identified')
        for isin in self.Position_Lists:
            bond_curve, credit_curve, status = isin_rf_mapping.get_rf_for_isin(isin)
            print([isin, bond_curve, credit_curve, status])
            single_df = pd.DataFrame(data = [[isin, bond_curve, credit_curve, status]], columns=["ISIN","Bond Curve", "CDS Curve", "Mapping Type" ])
            df = df.append(single_df)
        print(
            "warning: we will use the risk factors for the last isin in the calculation , the code will continue within 2 seconds")
        time.sleep(2)


        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append("Risk Factor Mapping")
        # setup the model

        if status in ["govt_bond", "mortgage_bond"]:
            self.ext_bond_curve_name = bond_curve
            self.bond_curve_source = 'DAMDS'

        if status in ['eu_gov_bond']:
            self.ext_bond_curve_name = bond_curve
            self.bond_curve_source = 'marsp_eu_gov'

        if status in ['single_name_cds']:
            self.use_cds_curve( credit_curve, cds_source='MARKIT')

        if status in ['proxy']:
            self.use_cds_curve(credit_curve, cds_source='proxy_service_fast')


    def activate_external_curve_mode(self, curvename=None):
        # This method allow user to provide an external curve to the prototype
        # It can be used if user want to have something very quick to try various curves.
        if curvename==None:
            self.getBackRiskFactorForEachISIN()
        else:
            self.ext_bond_curve_name=curvename

        print('Bond curve name: ' + self.ext_bond_curve_name)

    def use_ir_curve_as_bond_curve(self):
        curveName = self.getDiscName(self.ccy, 'LIBOR')
        self.activate_external_curve_mode(curvename=curveName)
        self.proxy_bond_curve_by_ircurve=True

    def use_cds_curve(self,cds_curve_name,cds_source='proxy_service_fast'):
        self.use_cds_curve_in_pricing = True
        self.use_ir_curve_as_bond_curve()
        self.cds_curve_name=cds_curve_name
        self.cds_curve_source=cds_source

    def express_curve_in_org_ccy(self):
        self.express_pnl_in_org_ccy = True

    def get_mort_bond_curve_name(self,ISIN):
        # get the mortgage bond curve
        return {
            'DK': 'DKKMTGNYKSOFTBLT' ,  # Danish Mortgagae Bond curve.
            'LU': 'DKKMTGNYKREDIT' # Danish Mortgagae Bond in EUR
        }.get(ISIN, 'DKKMTGNYKREDIT')


    def checkModelbility(self):
      """
          Add an error message to the error message function

          Returns:
              add one error message to the errorMessageDataFrame object in the frtb_prototype class
      """
      modelLable_list = []
      max_interval = []
      try:
        df = pd.read_excel(io=self.Modelability_File)
      except Exception as e:
          self.trackError(errorMessage=e, comments='Can not read the NMRF file, use back up file instead')
          try:
            df = pd.read_excel(io=self.Modelability_File_backup)
          except Exception as e:
              self.trackError(errorMessage=e, comments='back up file also do not work')
              df=pd.DataFrame()

      for currISIN in self.Position_Lists:
          try:
              tempAnswer = df.loc[df['ISIN'] == currISIN]['Modellable?'].values[0].strip()
              tempMaxInterVal = df.loc[df['ISIN'] == currISIN]['Max. Interval (days)'].values[0]
          except Exception as e:
              tempAnswer = False
              tempMaxInterVal = 42
              self.trackError(errorMessage=e, position=currISIN, comments='Can not find this ISIN in NMRF file, ' +
                                                                          'we will assume this isin is not modellable, '
                                                                          ' and max interval is ' + str(tempMaxInterVal))

          modelLable_list.append(tempAnswer)
          max_interval.append(tempMaxInterVal)
      return modelLable_list, max_interval

    def getLiquidHorizon(self,riskFactorName):
        return {
            'bondSwapBasis': 20,
            'riskfreecurve': 10,
            'zSpread': 20,
            'fxRate': 10
        }.get(riskFactorName, 300)

    def RTPLcalculation(self, marketdataCache = None):
        # Calculate RTPL
        # get all market data cache except for risk free rate
        if marketdataCache is None:
           marketdataCache = self.marketDataCache
        fxRateCache = marketdataCache.getObjectFromCacheSet('fxRate')
        bondSwapBasisCache = marketdataCache.getObjectFromCacheSet('bondSwapBasis')
        riskFreeRateCache = marketdataCache.getObjectFromCacheSet('riskfreecurve')
        cdsRateCache=marketdataCache.getObjectFromCacheSet('cdsspread')

        df = pd.DataFrame()
        df.name = 'RTPL_All'
        # loop through ISINs and calculate all relevant measures
        for currISIN in self.Position_Lists:
            cashFlowCache = marketdataCache.getObjectFromCacheSet(currISIN + '_cashflow')
            marketPriceCache = marketdataCache.getObjectFromCacheSet(currISIN + '_marketPrice')
            for currt in self.analysisRange:
                d1 = currt
                d2 = d1 + BDay(1)
                print('---start calculation for:' + currt.strftime('%Y%m%d'))
                try:
                    valuation_d1 = self.simple_bond_Pricing(
                                                           ISIN=currISIN,
                                                           ccy=self.ccy,
                                                           rfCurve=self.riskFreeCurve,
                                                           currt=d1,
                                                           zspread=-1,
                                                           bondSwapBasisCache=bondSwapBasisCache,
                                                           cdsSpreadCache=cdsRateCache,
                                                           riskFreeRateCache=riskFreeRateCache,
                                                           cashFlowCache=cashFlowCache,
                                                           marketPriceCache=marketPriceCache)

                    valuation_d2 = self.simple_bond_Pricing(
                                                           ISIN=currISIN,
                                                           ccy=self.ccy,
                                                           rfCurve=self.riskFreeCurve,
                                                           currt=d2,
                                                           zspread=-1,
                                                           bondSwapBasisCache=bondSwapBasisCache,
                                                           cdsSpreadCache=cdsRateCache,
                                                           riskFreeRateCache=riskFreeRateCache,
                                                           cashFlowCache=cashFlowCache,
                                                           marketPriceCache=marketPriceCache)

                    valuation_d1_allmdchange = self.simple_bond_Pricing(
                                                                       ISIN=currISIN,
                                                                       ccy=self.ccy,
                                                                       rfCurve=self.riskFreeCurve,
                                                                       currt=d1,
                                                                       risk_free_rate_t=d2,
                                                                       bond_swap_basis_t=d2,
                                                                       zspread=valuation_d2.zspread,
                                                                       bondSwapBasisCache=bondSwapBasisCache,
                                                                       cdsSpreadCache=cdsRateCache,
                                                                       riskFreeRateCache=riskFreeRateCache,
                                                                       cashFlowCache=cashFlowCache,
                                                                       marketPriceCache=marketPriceCache)

                    valuation_d1_zspreadchange = self.simple_bond_Pricing(
                                                                         ISIN=currISIN,
                                                                         ccy=self.ccy,
                                                                         rfCurve=self.riskFreeCurve,
                                                                         currt=d1,
                                                                         risk_free_rate_t=d1,
                                                                         bond_swap_basis_t=d1,
                                                                         zspread=valuation_d2.zspread,
                                                                         bondSwapBasisCache=bondSwapBasisCache,
                                                                         cdsSpreadCache=cdsRateCache,
                                                                         riskFreeRateCache=riskFreeRateCache,
                                                                         cashFlowCache=cashFlowCache,
                                                                         marketPriceCache=marketPriceCache)

                    valuation_d1_riskfreeRateChange = self.simple_bond_Pricing(
                                                                              ISIN=currISIN,
                                                                              ccy=self.ccy,
                                                                              rfCurve=self.riskFreeCurve,
                                                                              currt=d1,
                                                                              risk_free_rate_t=d2,
                                                                              bond_swap_basis_t=d1,
                                                                              zspread=valuation_d1.zspread,
                                                                              bondSwapBasisCache=bondSwapBasisCache,
                                                                              cdsSpreadCache=cdsRateCache,
                                                                              riskFreeRateCache=riskFreeRateCache,
                                                                              cashFlowCache=cashFlowCache,
                                                                              marketPriceCache=marketPriceCache)

                    valuation_d1_bondSwapBasisChange = self.simple_bond_Pricing(
                                                                               ISIN=currISIN,
                                                                               ccy=self.ccy,
                                                                               rfCurve=self.riskFreeCurve,
                                                                               currt=d1,
                                                                               risk_free_rate_t=d1,
                                                                               bond_swap_basis_t=d2,
                                                                               zspread=valuation_d1.zspread,
                                                                               bondSwapBasisCache=bondSwapBasisCache,
                                                                               cdsSpreadCache=cdsRateCache,
                                                                               riskFreeRateCache=riskFreeRateCache,
                                                                               cashFlowCache=cashFlowCache,
                                                                               marketPriceCache=marketPriceCache)

                    valuation_d1_forRTPL = self.simple_bond_Pricing(
                                                                   ISIN=currISIN,
                                                                   ccy=self.ccy,
                                                                   rfCurve=self.riskFreeCurve,
                                                                   currt=d2, # theta now is part of the RTPL!
                                                                   risk_free_rate_t=d2,
                                                                   bond_swap_basis_t=d2,
                                                                   zspread=valuation_d2.zspread, # changed by Shengyao in 09/06/2017, beacuse zspread is in scope of risk factor
                                                                   bondSwapBasisCache=bondSwapBasisCache,
                                                                   cdsSpreadCache=cdsRateCache,
                                                                   riskFreeRateCache=riskFreeRateCache,
                                                                   cashFlowCache=cashFlowCache,
                                                                   marketPriceCache=marketPriceCache)

                    valuation_d1_forwarded = self.simple_bond_Pricing(
                                                                      ISIN=currISIN,
                                                                      ccy=self.ccy,
                                                                      rfCurve=self.riskFreeCurve,
                                                                      currt=d2,
                                                                      risk_free_rate_t=d1,
                                                                      bond_swap_basis_t=d1,
                                                                      zspread=valuation_d1.zspread,
                                                                      bondSwapBasisCache=bondSwapBasisCache,
                                                                      cdsSpreadCache=cdsRateCache,
                                                                      riskFreeRateCache=riskFreeRateCache,
                                                                      cashFlowCache=cashFlowCache,
                                                                      marketPriceCache=marketPriceCache)

                except Exception as e:
                    self.trackError(errorMessage=e, position=currISIN, date=d1,
                                    comments='Can not finish RTPL valuation')
                    continue
                try:
                    if self.express_pnl_in_org_ccy:
                        fxRate_d1 = 1
                        fxRate_d2 = 1
                    else:
                        fxRate_d1 = fxRateCache.getvalue(d1)['price']
                        fxRate_d2 = fxRateCache.getvalue(d2)['price']

                    totalPL = fxRate_d2 * valuation_d2.model_cleanprice - fxRate_d1 * valuation_d1.model_cleanprice
                    fxPL = (fxRate_d2 - fxRate_d1) * float(valuation_d1.market_cleanprice)
                    zspreadPL = fxRate_d1 * (valuation_d1_zspreadchange.model_fullprice - valuation_d1.model_fullprice)
                    riskfreeRatePL = fxRate_d1 * (
                        valuation_d1_riskfreeRateChange.model_fullprice - valuation_d1.model_fullprice)
                    bondSwapBasisPL = fxRate_d1 * (
                        valuation_d1_bondSwapBasisChange.model_fullprice - valuation_d1.model_fullprice)
                    otherPL = totalPL - fxPL - zspreadPL - riskfreeRatePL - bondSwapBasisPL
                    RTPL = fxRate_d2 * valuation_d1_forRTPL.model_cleanprice - fxRate_d1 * valuation_d1.model_cleanprice
                    # HPL = fxRate_d2 * valuation_d1_allmdchange.model_cleanprice - fxRate_d1 * valuation_d1.model_cleanprice
                    # HPL_withtimefwd =  fxRate_d2 * ( valuation_d1_forwarded.model_cleanprice) - \
                    #                       fxRate_d1 * (valuation_d1.model_cleanprice)
                    # unExplained_PL = HPL- RTPL

                    HPL = fxRate_d2 * valuation_d1_allmdchange.model_cleanprice - fxRate_d1 * valuation_d1.model_cleanprice  # Shengyao version
                    HPL_withtimefwd = fxRate_d2 * (valuation_d1_forwarded.model_cleanprice) - fxRate_d1 * (
                    valuation_d1.model_cleanprice)  # Shengyao version v2

                    # ngs01 2017-02-09: Defining HPL to be aligned with how Shingi/front office defines the time component.
                    HPL_Shingi = fxRate_d2 * (valuation_d2.market_cleanprice) - fxRate_d1 * (
                    valuation_d1_forwarded.model_cleanprice)

                    unExplained_PL = HPL - RTPL

                    bond_price_d1 = valuation_d1.model_cleanprice  # clean value time 1 - ngs01
                    bond_price_d1_rtpl = valuation_d1_forRTPL.model_cleanprice  # time 1 given time 2 rf wo/ zspread - ngs01
                    bond_price_d1_hpl = valuation_d1_allmdchange.model_cleanprice  # time 1 value given time 2 rf w/ zspread ngs01
                    bond_price_d2 = valuation_d2.model_cleanprice  # clean value time 2 - ngs01
                    bond_price_d2_alternative = valuation_d2.market_cleanprice  # should be same as above - ngs01
                    bond_price_d2_forwarded = valuation_d1_forwarded.model_cleanprice  # forwarded to time 2 given rf from time 1 (for Shingi/FO definition of HPL) - ngs01

                except Exception as e:
                    self.trackError(errorMessage=e, position=currISIN, date=d1,
                                    comments='Can not finish RTPL calculation even valuation is finished')
                    continue


                # ===================================================================================
                # Try to identify data issues
                #
                # ===================================================================================

                agrregateCashFlow_d1 = BPC.bond_pricing_with_empty_curve(t=d1, cashFlowCache=cashFlowCache)
                accured_int_d1=valuation_d1.market_fullprice-valuation_d1.market_cleanprice
                agrregateCashFlow_d2 = BPC.bond_pricing_with_empty_curve(t=d2, cashFlowCache=cashFlowCache)
                accured_int_d2 = valuation_d2.market_fullprice - valuation_d2.market_cleanprice

                data_issue=''
                if agrregateCashFlow_d2 != agrregateCashFlow_d1:
                    # ===================================================================================
                    # if aggregate cash flow has changed, that means d1 is a coupon date
                    # if d1 is coupon date, the accured int in d2 should be smaller than d1
                    # ===================================================================================
                    if accured_int_d2 > accured_int_d1:
                        data_issue='accured int can not agree with price in d1'
                if accured_int_d2 < accured_int_d1:
                    # ===================================================================================
                    # if coupon paid, accured interest becomes smaller ( or zero) than the previous day
                    # if aggregate cashflow doesnt change, then there is an issue
                    # ===================================================================================
                    if agrregateCashFlow_d2 == agrregateCashFlow_d1:
                        data_issue = 'aggregated cashflow seems to be static even after coupon payment'
                if accured_int_d2 == 0:
                    # ===================================================================================
                    # if coupon paid, accured interest becomes zero
                    # if aggregate cashflow doesnt change, then there is an issue
                    # ===================================================================================
                    if agrregateCashFlow_d2 == agrregateCashFlow_d1:
                        data_issue = 'aggregated cashflow seems to be static even after coupon payment'

                df_signleDay = pd.DataFrame([[self.convert_to_date(d1), self.convert_to_date(d2), currISIN, fxRate_d1,
                                              fxRate_d2, valuation_d1.market_cleanprice
                                                 , valuation_d2.market_cleanprice, valuation_d1.market_fullprice,
                                              valuation_d2.market_fullprice, valuation_d1.model_cleanprice,
                                              valuation_d2.model_cleanprice,
                                              10000 * valuation_d1.zspread,
                                              10000 * valuation_d2.zspread, totalPL, fxPL, zspreadPL, riskfreeRatePL,
                                              bondSwapBasisPL, otherPL, RTPL
                                                 , HPL, unExplained_PL,
                                              valuation_d1_forwarded.model_cleanprice,
                                              valuation_d1.model_cleanprice,
                                              HPL_withtimefwd,
                                              agrregateCashFlow_d1,
                                              accured_int_d1, data_issue
                                                 , valuation_d2.market_fullprice - valuation_d2.market_cleanprice
                                              # ngs01
                                                 , bond_price_d1, bond_price_d1_rtpl, bond_price_d1_hpl, bond_price_d2
                                              # ngs01
                                                 , bond_price_d2_alternative  # ngs01
                                                 , bond_price_d2_forwarded  # ngs01 09Feb17
                                              ]],
                                            columns=['Day1', 'Day2', 'Position', 'FX Rate D1',
                                                     'FX Rate D2',
                                                     'Clean Price d1 (org ccy)', 'Clean Price d2 (org ccy)',
                                                     'Dirty Price d1', 'Dirty Price d2', 'Clean Price d1',
                                                     'Clean Price d2',
                                                     'zspread(d1) in bps',
                                                     'zspread(d2) in bps', 'totalPL', 'PL explained by FX Change',
                                                     'PL explained by zspread',
                                                     'PL explained by risk free rate movement',
                                                     'PL explained by bond swap basis movement',
                                                     'otherPL ', 'RTPL', 'HPL', 'unExplained_PL',
                                                     'valuation_d1_forwarded.model_cleanprice',
                                                     'valuation_d1.model_cleanprice',
                                                     'HPL with theta',
                                                     'aggregateCashFlow(d1)',
                                                     'accured_interest(d1)', 'data issue identified'
                                                , 'accured_interest(d2)'  # ngs01
                                                , 'bond_price_d1', 'bond_price_d1_rtpl', 'bond_price_d1_hpl',
                                                     'bond_price_d2'  # ngs01
                                                , 'bond_price_d2_alternative'
                                                , 'bond_price_d2_forwarded'  # ngs01 09Feb17
                                                     ])
                df = df.append(df_signleDay)
        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('RTPL_All')

    def loadALLMarketDATAintoCache(self,loadISINLevelInformation = True,loadStressedInformation=False):

        ##################################################
        # load all market datas and store in the batch
        ##################################################
        tempCacheSet=marketDataCacheSet(name='cacheList')
        bondSwapBasisCache = RawTimeSeries('bondSwapBasis')
        fxRateCache = RawTimeSeries('fxRate')
        riskFreeRateCache=RawTimeSeries('riskfreecurve')

        # load the market data from the normal period
        fxRateCache, bondSwapBasisCache, riskFreeRateCache,cdsRateCache,bondCurveCache=self.load_market_data_in_range(
            dateRange=self.analysisRange,
            fxRateCache=fxRateCache,
            bondSwapBasisCache=bondSwapBasisCache
        )

        # load the market data from the normal period
        if loadStressedInformation:
            fxRateCache_stress, bondSwapBasisCache_stress, riskFreeRateCache_stress,cdsRateCache_stress,bondCurveCache_stress = self.load_market_data_in_range(
                dateRange=self.stressedRange,
                fxRateCache=fxRateCache,
                bondSwapBasisCache=bondSwapBasisCache)

            fxRateCache.append_another_cache(fxRateCache_stress)
            bondSwapBasisCache.append_another_cache(bondSwapBasisCache_stress)
            riskFreeRateCache.append_another_cache(riskFreeRateCache_stress)
            cdsRateCache.append_another_cache(cdsRateCache_stress)
            bondCurveCache.append_another_cache(bondCurveCache_stress)


        tempCacheSet.append(fxRateCache)
        tempCacheSet.append(bondSwapBasisCache)
        tempCacheSet.append(riskFreeRateCache)
        tempCacheSet.append(cdsRateCache)
        tempCacheSet.append(bondCurveCache)
        ##################################################
        # load all ISINs and cashflows in normal period
        ##################################################
        if loadISINLevelInformation:
            for x in range(0, len(self.Position_Lists)):
                currISIN = self.Position_Lists[x]
                if len(currISIN) >2:
                    try:
                        marketPriceCache,cashFlowCache=self.getAllISINInformation(currISIN)
                    except Exception as e:
                        self.trackError(errorMessage=e, position=currISIN,
                                        comments='Can not get cash flow and price for this ISIN')
                        continue
                    tempCacheSet.append(marketPriceCache)
                    tempCacheSet.append(cashFlowCache)



        cacheFile='marketDataCache'+datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+'.pickle'
        self.putCacheIntoFile(self.defaultCacheFolder+cacheFile,tempCacheSet)
        self.attachMarketDataCacheSet(tempCacheSet)

        print('--a cache has been placed: ' + cacheFile)
        return tempCacheSet

    def batchCalculateZSpread(self):
        # ===================================================================================
        # the code here will call the qToolkit to calculate z-spread dynamics
        # ===================================================================================
        df = pd.DataFrame()
        for x in range(0, len(self.Position_Lists)):
            currISIN = self.Position_Lists[x]
            df_currisin = pd.DataFrame()
            if len(currISIN) > 2:
                fxRateCache = self.marketDataCache.getObjectFromCacheSet('fxRate')
                bondSwapBasisCache = self.marketDataCache.getObjectFromCacheSet('bondSwapBasis')
                bondCurveCache = self.marketDataCache.getObjectFromCacheSet('bondcurve')
                riskFreeRateCache = self.marketDataCache.getObjectFromCacheSet('riskfreecurve')
                cashFlowCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_cashflow')
                marketPriceCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_marketPrice')
                for tempT in self.analysisRange:
                    try:
                        valuation_zspread = self.simple_bond_Pricing(
                                                                    ISIN=currISIN,
                                                                    ccy=self.ccy,
                                                                    rfCurve=self.riskFreeCurve,
                                                                    currt=tempT,
                                                                    zspread=-1,
                                                                    bondSwapBasisCache=bondSwapBasisCache,
                                                                    riskFreeRateCache=riskFreeRateCache,
                                                                    cashFlowCache=cashFlowCache,
                                                                    marketPriceCache=marketPriceCache,
                                                                    bondCurveCache=bondCurveCache)
                        df_currisin = df_currisin.append(
                            pd.DataFrame([[currISIN, tempT, self.ext_bond_curve_name, self.cds_curve_name,
                                           valuation_zspread.zspread]]
                                         , columns=['ISIN', 'INFO_DATE', 'CURVE_NAME', 'CDS_CURVE_NAME','ZSPREAD']))
                    except Exception as e:
                        self.trackError(errorMessage=e, position=currISIN, date=tempT,
                                        comments='Can not calculate Z-spread for this ISIN and for this date')
                        continue
            # append the data frame for current isin the final isin
            # remove outlier if being asked....
            try:
                if self.clean_outlier_for_zspread:
                    df = df.append(self.detact_and_clean_outlier(df_currisin))
                else:
                    df = df.append(df_currisin)
            except Exception as e:
                self.trackError(errorMessage=e, position=currISIN,
                                comments='The ISIN do not have any zspread populated')
                continue

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('Zspread')

    def detact_and_clean_outlier(self, df):
        df['return'] = df['ZSPREAD'].shift(1) - df['ZSPREAD']
        df['mov_vol'] = df['return'].rolling(window=self.outlier_clean_time_window).std()
        # in the first period, use the std dev instead of rolling std dev
        idx = df['mov_vol'].isnull()
        df.loc[idx, 'mov_vol'] = df['return'].loc[idx].std()
        # check whether there is any outlier
        df['outlier'] = np.abs(df['ZSPREAD'] - df['ZSPREAD'].rolling(window=self.outlier_clean_time_window).mean()) > \
                        self.outlier_clean_no_of_stddev * df['mov_vol']

        df['RAW_ZSPREAD'] = df['ZSPREAD']
        # clean outlier
        df['ZSPREAD'] = self.clean_outlier(df['ZSPREAD'].tolist(), df['outlier'].tolist())
        return df

    def clean_outlier(self, raw_data, outlier):
        clean_data = raw_data
        for i in range(1, len(raw_data)):
            if outlier[i]:
                # use previou day's result
                clean_data[i] = clean_data[i - 1]

        return clean_data

    def getAllISINInformation(self, currISIN):

        # ===================================================================================
        # load cash flow from the ISIN
        # ===================================================================================
        print('--- get cash flow for ISIN:' + currISIN)
        from core.market_data.market_data_loader import CashFlowLoader
        cashFlowCache=CashFlowLoader(name=currISIN,source='orca',
                                     startd=self.analysisStartDate,
                                         endd=self.analysisEndDate).data

        cashFlowCache.name=currISIN + '_cashflow'
        # ===================================================================================
        # load price for this ISIN
        # ===================================================================================
        print('--- get price for ISIN:' + currISIN)
        from core.market_data.market_data_loader import BondPriceLoader
        marketPriceCache=BondPriceLoader(name=currISIN, source=self.bond_price_source,
                                         startd=self.analysisStartDate,
                                         endd=self.analysisEndDate,
                                         ).data

        marketPriceCache.name=currISIN + '_marketPrice'
        return marketPriceCache, cashFlowCache

    def load_price_from_DAMDP_or_MARS(self,tempT,currISIN):
        try:
            tempd = tempT + BDay(0)
            priceObj = GETCURVE.get_price_at_from_DAMD(isin=currISIN, asofdate=tempd.to_datetime(),
                                                       constr=self.DAMD_concet_string)
        except Exception as e:
            self.trackError(errorMessage=e, position=currISIN, date=tempT,
                            comments='Can not load price for this ISIN from DAMDP')

        if priceObj == None:  # if DAMDP doesnt return a price, then we uses MARS
            try:
                mars_price = GETCURVE.isin_price(proddate=tempd + BDay(0), isin=currISIN)
                priceObj['clean_price'] = decimal.Decimal(mars_price[0].get('clean_price'))
            except Exception as e:
                self.trackError(errorMessage=e, position=currISIN, date=tempT,
                                comments='Can not load price for this ISIN from MARSP')

        return priceObj

    def load_market_data_in_range(self, dateRange, fxRateCache, bondSwapBasisCache):

        loadDateRangeList = [currt.date() for currt in dateRange]
        from core.market_data.market_data_loader import IrCurveLoader
        from core.market_data.market_data_loader import CDSSpreadLoader
        from core.market_data.market_data_loader import BondCurveLoader

        # ===================================================================================
        # load the risk free curve
        # ===================================================================================
        if self.rate_source == "INFOP_FRTB":
            riskFreeRateCache = IrCurveLoader(name=self.mars_interest_id,
                                              ccy=self.ccy,
                                              startd=dateRange[0],
                                              endd=dateRange[-1],
                                              source='INFOP_FRTB').data
        elif self.rate_source == "DAMDS":
            riskFreeRateCache = IrCurveLoader(name=self.ccy + ".DISC.LIBOR.CURVE",
                                              startd=dateRange[0],
                                              endd=dateRange[-1],
                                              source=self.rate_source).data

        if len(riskFreeRateCache.cacheDate) == 0:
            self.trackError(comments='no risk free rate has been loaded')

        riskFreeRateCache.name = 'riskfreecurve'  # name need be 'riskfreecurve' to be indexed afterwards...
        # ===================================================================================
        # load the bond curve
        # ===================================================================================

        # in mortgage bond curve mode, the curve is got from the market data service\
        if self.proxy_bond_curve_by_ircurve:
            bond_curve_cache = copy.deepcopy(riskFreeRateCache)
        else:
            bond_curve_cache=BondCurveLoader(name= self.ext_bond_curve_name,
                                         startd=dateRange[0],
                                         endd=dateRange[-1],
                                         source=self.bond_curve_source).data


        if len(bond_curve_cache.cacheDate) == 0:
            self.trackError(comments='no bond curve has been loaded')

        bond_curve_cache.name = 'bondcurve'


        # ===================================================================================
        # generate bond swap basis
        # ===================================================================================
        loadDateTimeRangeList = [datetime.datetime.combine(currt, datetime.datetime.min.time())
                                 for currt in loadDateRangeList]

        for currDateTime in loadDateTimeRangeList:
            try:
                bond_curve=bond_curve_cache.getvalue(currDateTime)
            except Exception as e:
                self.trackError(errorMessage=e, date=currDateTime,
                                comments='bond curve ' + self.ext_bond_curve_name + ' not exsisted')
                continue

            try:
                risk_free_curve_sd=riskFreeRateCache.getvalue(currDateTime)
            except Exception as e:
                self.trackError(errorMessage=e, date=currDateTime,
                                comments='risk free curve not exsisted')
                continue

            try:
                bond_swap_basis = GETCURVE.BondBasisCurveGenerator(bond_curve, risk_free_curve_sd, self.riskFactorBuckets,
                                                                   currDateTime)
                bondSwapBasisCache.addItem(bond_swap_basis, currDateTime)
                print('has loaded bond swap basis curve to cache :' + currDateTime.strftime('%Y%m%d'))
            except Exception as e:
                self.trackError(errorMessage=e, date=currDateTime,
                                comments='Can not load bond-swap basis for this date')


        # ===================================================================================
        # get fx rate part.
        # ===================================================================================
        tempFX = fx_rates.extract(info=0,
                                  currency=self.ccy,
                                  eod_date=loadDateRangeList
                                  )
        for item in tempFX:
            fxRateCache.addItem(item, item['eod_date'])

        # ===================================================================================
        # get cds spread
        # ===================================================================================

        # make the default one
        cdsCurveCache = RawTimeSeries(name='cdsspread')
        for currt in loadDateRangeList:
            d = [qt.datetime.datetime(2017, 11, 18), qt.datetime.datetime(2050, 11, 28)]
            h = [0, 0]  # input, empty hazard rate
            hc = qt.CurveFlat.make(d, h)
            credit_curve = qt.CreditCurveInterpolated.make('emptyCurve', 'USD', to_datetime(currt), hc, 0.4)
            cdsCurveCache.addItem(credit_curve, currt)

        # if really need cds curve, try to get it through loader
        if self.use_cds_curve_in_pricing:
            try:
                tempCDS=CDSSpreadLoader(name=self.cds_curve_name,
                     source=self.cds_curve_source,startd=dateRange[0],
                     endd=dateRange[-1])
                cdsCurveCache=tempCDS.transfer_curve_to_cdscurve()
                cdsCurveCache.name='cdsspread'
            except Exception as e:
                self.trackError(errorMessage=e,
                                comments='Something is wrong with the cds loader, use empty cds spread instead')

        if len(cdsCurveCache.cacheDate) == 0:
            self.trackError(comments='no cds curve has been loaded')

        return fxRateCache, bondSwapBasisCache, riskFreeRateCache,cdsCurveCache,bond_curve_cache

    def makeCurveInStdBucket(self, curve, asoft):
        tempDate = []
        tempRate = []
        for bucket in self.riskFactorBuckets:
            tempT = qt.addTenor(asoft, bucket)
            tempDate.append(tempT)
            tempRate.append(curve.getVal(tempT))

        return qt.CurveCatrom.make(tempDate, tempRate)

    def scenarioNPV(self,returnName,include_theta=False):
        # conttruct the market data scenario
        asofDate=self.analysisEndDate

        #fxRateCache = self.marketDataCache.getObjectFromCacheSet('fxRate')
        bondSwapBasisCache = self.marketDataCache.getObjectFromCacheSet('bondSwapBasis')
        riskFreeRateCache = self.marketDataCache.getObjectFromCacheSet('riskfreecurve')
        cdsCurveCache = self.marketDataCache.getObjectFromCacheSet('cdsspread')
        #fxRate=fxRateCache.getvalue(asofDate)
        riskFreeRateStart = riskFreeRateCache .getvalue(asofDate)
        bondSwapBasisStart = bondSwapBasisCache.getvalue(asofDate)
        creditCurveStart = cdsCurveCache.getvalue(asofDate).hazardCurve
        # parse the scenario file
        try:
            idx=self.resultDataFrameName.index('scenario_'+returnName)
            resultDF=self.resultDataFrameList[idx]
        except Exception as e:
            self.trackError(errorMessage=e ,
                            comments='Scenario are not generated correctly')
            return

        coulmnslist=list(resultDF.columns.values)
        bondSwapBasisIdx= [i for i,x in enumerate(coulmnslist) if 'bondSwapBasis' in x]
        riskfreeidx = [i for i, x in enumerate(coulmnslist) if 'riskfreecurve' in x]
        cdsspreadidx = [i for i, x in enumerate(coulmnslist) if 'cdsspread' in x]
        # prepare the DataFrame
        df=pd.DataFrame()

        for currISIN in self.Position_Lists:
            zSpreadidx=[i for i, x in enumerate(coulmnslist) if 'zspread_'+currISIN in x]
            ###########################################
            # perform the base valuation as of today
            ###########################################
            cashFlowCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_cashflow')
            marketPriceCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_marketPrice')
            if asofDate.date() not in cashFlowCache.cacheDate:
                self.trackError(comments='ES as of date not in cash flow',
                                position= currISIN
                                )
                continue

            if asofDate.date() not in marketPriceCache.cacheDate:
                self.trackError(comments='ES as of date not in market price',
                                position= currISIN
                                )
                continue

            try:
                valuation_asOfDate = self.simple_bond_Pricing(
                    ISIN=currISIN,
                    ccy=self.ccy,
                    rfCurve=self.riskFreeCurve,
                    currt=asofDate,
                    zspread=-1,
                    bondSwapBasisCache=bondSwapBasisCache,
                    riskFreeRateCache=riskFreeRateCache,
                    cashFlowCache=cashFlowCache,
                    marketPriceCache=marketPriceCache)
                df=df.append(pd.DataFrame([['Base Scenario',currISIN,valuation_asOfDate.model_cleanprice,0 ]],
                                      columns=['Scenario Number','Position','Scenario Valuation','scenario_pl']))
            except Exception as e:
                self.trackError(errorMessage=e, date=asofDate, position= currISIN,
                                comments='can not finish base valuation for this ISIN')
                continue

            ###########################################
            # decide whether include theta in the simulation
            ###########################################
            if include_theta:
                scenario_valuation_date=asofDate+BDay(10)
            else:
                scenario_valuation_date=asofDate
            ###########################################
            # perform scenario NPV calculation on each scenario
            ###########################################
            for x in range(0, len(resultDF) - 1):
                # prepare the scenario
                bondSwapBasisScenario = resultDF.values[x][bondSwapBasisIdx]
                riskFreeScenario = resultDF.values[x][riskfreeidx]
                zspreadScenario = resultDF.values[x][zSpreadidx]
                creditScenario  = resultDF.values[x][cdsspreadidx]

                # make external curves put into the price
                try:
                    riskFreeScenarioCurve=self.addScenarioToCurve(riskFreeRateStart,riskFreeScenario,asofDate)
                    bondSwapBasisScenarioCurve = self.addScenarioToCurve(bondSwapBasisStart, bondSwapBasisScenario, asofDate)
                    credit_curve_temp = self.addScenarioToCurve(creditCurveStart, creditScenario, asofDate ,
                                                                buckets = self.cdsBuckets,
                                                                floor_atzero= True)
                    credit_curve_scenario = qt.CreditCurveInterpolated.make('credit curve', self.ccy, asofDate, credit_curve_temp, 0.4)
                    # perform scenario valuation
                    valuation_scenario = self.simple_bond_Pricing(
                                                                 ISIN=currISIN,
                                                                 ccy=self.ccy,
                                                                 rfCurve=self.riskFreeCurve,
                                                                 currt=scenario_valuation_date,
                                                                 zspread=valuation_asOfDate.zspread + zspreadScenario, # bump the z spread scenario
                                                                 bondSwapBasisCache=bondSwapBasisCache,
                                                                 riskFreeRateCache=riskFreeRateCache,
                                                                 cashFlowCache=cashFlowCache,
                                                                 marketPriceCache=marketPriceCache,
                                                                 externalBondSwapBasisCurve=bondSwapBasisScenarioCurve,
                                                                 externalRiskFreeCurve=riskFreeScenarioCurve,
                                                                 externalCDSCurve = credit_curve_scenario
                                                                 )
                    # calculate the pl
                    if valuation_scenario.model_cleanprice >0:
                        scenario_pl=valuation_scenario.model_cleanprice-valuation_asOfDate.model_cleanprice

                        df = df.append(pd.DataFrame([[dateutils.to_date_str(resultDF.values[x][1]), currISIN,
                                                  valuation_scenario.model_cleanprice, scenario_pl]],
                                                columns=['Scenario Number', 'Position', 'Scenario Valuation', 'scenario_pl']))
                    else:
                        self.trackError(date=asofDate, position=currISIN,
                                        comments='can not finish scenario valuation for scenario : ' + str(x))
                except Exception as e:
                    self.trackError(errorMessage=e, date=asofDate, position=currISIN,
                                    comments='can not finish scenario valuation for scenario : ' + str(x))
                    continue

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('scenario NPV_'+returnName)



    def bump_size_calculation(self):
        df = pd.DataFrame()
        for currISIN in self.Position_Lists:
            bump_sizes_in_normal_period = self.calibrate_NMRF_bump_size(currISIN)
            df = df.append(pd.DataFrame([[currISIN, 10000*bump_sizes_in_normal_period[0], 10000*bump_sizes_in_normal_period[1]]]
                                        , columns=['Position',
                                                   'bumpsize Short in normal period (in bps)', 'bumpsize Long in normal period (in bps) ']))

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('NMRF_bump_size')

    def calculateIMCC(self,info=0):
        # TODO: move it to frtb prototype and has a general implementation across all products
        import math as math
        # calculate stressed ES for reducedk set
        self.calculateESNumbers(dateRange=self.stressedRange,
                                name='stressed_full',
                                riskFactors=['bondSwapBasis', 'riskfreecurve','cdsspread'],
                                info=info)

        self.calculateESNumbers(dateRange=self.stressedRange,
                                name='stressed_ir',
                                riskFactors=['riskfreecurve'],
                                info=info)

        self.calculateESNumbers(dateRange=self.stressedRange,
                                name='stressed_cs',
                                riskFactors=['bondSwapBasis','cdsspread'],
                                info=info)

        self.calculateESNumbers(dateRange=self.analysisRange,
                                name='normal_cs_fs',
                                riskFactors=['bondSwapBasis','zSpread','cdsspread'],
                                info=info)

        self.calculateESNumbers(dateRange=self.analysisRange,
                                name='normal_cs_rs',
                                riskFactors=['bondSwapBasis','cdsspread'],
                                info=info)

        # do the modelblity study

        modellableList,maxinterval_list=self.checkModelbility()

        # get the ES result
        try:
            esResultDF = self.resultDataFrameList[self.resultDataFrameName.index('ES result')]
        except Exception as e:
            self.trackError(errorMessage=e,
                                comments='ES result do not exsisted')
            return

        df = pd.DataFrame()
        idx=0

        def getESNumbers(df, name):
            tempdf = df.loc[df['ES Calculation Name'] == name]
            return tempdf['ES10d'].values[0]

        for currISIN in self.Position_Lists:
            date_scope = (esResultDF['Position'] == currISIN)
            dateFrameWithInScope = esResultDF[date_scope]
            try:
                fullES = getESNumbers(dateFrameWithInScope, 'ES_stressed_full')
                irES = getESNumbers(dateFrameWithInScope, 'ES_stressed_ir')
                crES_stress_rs = getESNumbers(dateFrameWithInScope, 'ES_stressed_cs')
                crES_normal_rs= getESNumbers(dateFrameWithInScope, 'ES_normal_cs_rs')
                crES_normal_fs=getESNumbers(dateFrameWithInScope, 'ES_normal_cs_fs')
            except Exception as e:
                self.trackError(errorMessage=e, position=currISIN,
                                comments='ES calculation is not finished correct')
            try:
                crIMCCwoZspread = crES_stress_rs * math.sqrt(2)
                fullIMCCwoZspread = math.sqrt(math.pow(fullES, 2) + math.pow(crES_stress_rs, 2))
                irIMCC = irES
                finalIMCCwoZspread = 0.5 * fullIMCCwoZspread + 0.5 * (crIMCCwoZspread + irIMCC)
            except Exception as e:
                crIMCCwoZspread = 'na'
                fullIMCCwoZspread = 'na'
                irIMCC = 'na'
                finalIMCCwoZspread = 'na'
                self.trackError(errorMessage=e, position=currISIN,
                                comments='Can not get the capital charge without z spread')
            try:
                crES= crES_stress_rs * max(crES_normal_fs/ crES_normal_rs ,1)
                fullIMCC = math.sqrt(math.pow(fullES, 2) + math.pow(crES, 2))
                crIMCC = crES * math.sqrt(2)
                finalIMCC = 0.5 * fullIMCC + 0.5 * (crIMCC + irIMCC)
            except:
                crES='na'
                fullIMCC = 'na'
                crIMCC = 'na'
                finalIMCC = 'na'
                self.trackError(errorMessage=e, position=currISIN,
                                comments='Can not get the capital charge without z spread')


            # calculate the NMRF if any
            if modellableList[idx]=='True':
                bump_sizes_in_normal_period = [0,0]
                NMRF_Long = 0
                NMRF_Short = 0
                scale_ratio = 0

            else:
                # ===================================================================================
                # Calibrate the NMRF bump size for zspread
                # The calibration is applied to normal period and according to regulation,
                # we nee calibrate the bump size by using stress period.
                #
                # so that we scale the bump size by using the ratio:
                # ES_stress / ES_normal
                #
                # ===================================================================================
                try:
                    bump_sizes_in_normal_period = self.calibrate_NMRF_bump_size(currISIN)
                    if crES == 'na':
                        scale_ratio = 1.33 # 1/0.75
                    else:
                        scale_ratio = max( crES_stress_rs / crES_normal_rs ,1)

                    NMRF_Long=self.calculate_NMRF(currISIN=currISIN,
                                                  max_interval=maxinterval_list[idx],
                                                  bumpsize=bump_sizes_in_normal_period[0] * scale_ratio )
                    NMRF_Short = self.calculate_NMRF(currISIN=currISIN,
                                                    max_interval=maxinterval_list[idx],
                                                    bumpsize=bump_sizes_in_normal_period[1] * scale_ratio)
                except Exception as e:
                    self.trackError(errorMessage=e, position=currISIN,
                                    comments='can not calibrate bump size for this isin''')
                    continue

            idx=idx+1

            df = df.append(pd.DataFrame([[currISIN, fullES, irES, crES_stress_rs,crES_normal_rs, crES_normal_fs,crES
                                             , fullIMCC, crIMCC, irIMCC, finalIMCC,finalIMCCwoZspread,
                                               bump_sizes_in_normal_period[0], bump_sizes_in_normal_period[1],scale_ratio,
                                              NMRF_Long, NMRF_Short]]
                                        , columns=['Position', 'stressed es all', 'stressed es ir',
                                                   'stressed es cr rs', 'normal es cr rs', 'normal es cr fs',
                                                   'stressed es cr',
                                                   'IMCC all', 'IMCC CR', 'IMCC IR', 'final IMCC', 'final IMCC wo zSpread',
                                                   'bumpsize Short in normal period' , 'bumpsize Long in normal period ' , 'scale ratio',
                                                   'NMRFCharge_Short','NMRFCharge_Long']))

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('IMCC')

    def calibrate_NMRF_bump_size(self,currISIN):
        scenario_df = self.resultDataFrameList[self.resultDataFrameName.index('scenario_normal_cs_fs')]
        zSpreadScenario = scenario_df['zspread_' + currISIN]
        return np.nanpercentile(a = zSpreadScenario , q =[1,99])


    def calculate_NMRF(self, currISIN, max_interval,bumpsize):
        ##################################################
        # NMRF calculation
        ##################################################


        asofDate = self.marketDataCache.lastAllAvaliableDate()
        bondSwapBasisCache = self.marketDataCache.getObjectFromCacheSet('bondSwapBasis')
        riskFreeRateCache = self.marketDataCache.getObjectFromCacheSet('riskfreecurve')
        cashFlowCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_cashflow')
        marketPriceCache = self.marketDataCache.getObjectFromCacheSet(currISIN + '_marketPrice')

        valuation_base = self.simple_bond_Pricing(
                                                 ISIN=currISIN,
                                                 ccy=self.ccy,
                                                 rfCurve=self.riskFreeCurve,
                                                 currt=asofDate,
                                                 zspread=-1,
                                                 bondSwapBasisCache=bondSwapBasisCache,
                                                 riskFreeRateCache=riskFreeRateCache,
                                                 cashFlowCache=cashFlowCache,
                                                 marketPriceCache=marketPriceCache)

        valuation_bump = self.simple_bond_Pricing(
                                                 ISIN=currISIN,
                                                 ccy=self.ccy,
                                                 rfCurve=self.riskFreeCurve,
                                                 currt=asofDate,
                                                 zspread=valuation_base.zspread + bumpsize,
                                                 bondSwapBasisCache=bondSwapBasisCache,
                                                 riskFreeRateCache=riskFreeRateCache,
                                                 cashFlowCache=cashFlowCache,
                                                 marketPriceCache=marketPriceCache)

        stressed_pl = valuation_bump.model_fullprice - valuation_base.model_fullprice
        stressed_pl = -stressed_pl * math.sqrt(max_interval / 10)
        return stressed_pl


    def getBackCurrencyForEachISIN(self, arg):
        static_df = self.resultDataFrameList[self.resultDataFrameName.index('bond_coreInformation')]
        ccy = static_df.iloc[0]["Currency"]
        return ccy.encode('ascii', 'ignore')

    def getDiscName(self, currency, id):
        if id == 'LIBOR':
            DiscName = {'USD': 'USLI_REV', 'CAD': 'CALI_REV', 'CZK': 'CZPR_REV', 'SAR': 'SALI_REV',
                        'LTL': 'LTLI_REV', 'DKK': 'DKCI_REV', 'HKD': 'HDHI_REV', 'THB': 'THLI_REV',
                        'KWD': 'KWLI_REV', 'EEK': 'EKTA_REV', 'COP': 'COLI_REV', 'MXN': 'MXME_REV',
                        'ZAR': 'ZAJI_REV', 'HUF': 'HULI_REV', 'MYR': 'MYLI_REV', 'INR': 'INLI_REV',
                        'PHP': 'PHLI_REV', 'TRY': 'TYLI_REV', 'JPY': 'JYLI_REV', 'RUB': 'RULI_REV',
                        'IDR': 'IDLI_REV', 'ISK': 'ISLI_REV', 'ARS': 'ARLI_REV', 'BRL': 'BRLI_REV',
                        'CNY': 'CNLI_REV', 'AUD': 'AULI_REV', 'CHF': 'CHLI_REV', 'GBP': 'GBLI_REV',
                        'NOK': 'NKNI_REV', 'PLN': 'PLWI_REV', 'NZD': 'NZLI_REV', 'LVL': 'LVLI_REV',
                        'SGD': 'SGLI_REV', 'SEK': 'SESTI_REV', 'EUR': 'EIEU_REV'}
            return DiscName[currency.upper()]
        if id == 'OIS':
            return soap.getDiscName(currency.upper(), 'OIS')
        if id == 'BASIS':
            return soap.getDiscName(currency.upper(), 'BASIS')

    def simple_bond_Pricing(self, ISIN, currt, ccy, rfCurve, MDC='', bond_swap_basis_t='',
                            risk_free_rate_t='',  zspread=-1,
                            bondSwapBasisCache='', riskFreeRateCache='', cashFlowCache='', marketPriceCache='',
                            externalRiskFreeCurve='', externalBondSwapBasisCurve='',cdsSpreadCache='',
                            bondCurveCache='', externalCDSCurve = ''):
        """
        TODO: the code is really heavy now, need rebuild . By Shengyao
        The simple_bond_pricing model return the scenario NPV based on given input

        We choose the risk factor for Nordic govt bond as two risk factors: OIS discount curve + bond swap basis,
        the function try to call orca and assign a price to given ISIN, the function will fetch the necessary market data
        if needed. And the dates of these risk factors can be different

        The reason why the risk factor dates is different, simply because for the sack of p&l attribution work

        Args:
            ISIN:                   str             ISIN number
            currt:                  date            Valuation Date
            MDC:                    object          applications.FRTB.getCurvePriceFromDAMD as getCurve Module in FRTB folder
            bond_swap_basis_t       datetime        the asof date of bond swap basis risk factor (default = currt)
            risk_free_rate_t        datetime        the asof date of OIS rate (default = currt)
            constr                  str             connection string for DAMDP database
            zspread                 double          zspread, if user input -1, automatically derive the z spread by calling orca

        Returns:
            model_fullprice        double           the full dirty price given by the model
            market_fullprice       double           the full dirty price given by the market (from DAMD)
            zspread                double           zspread used in this calculation
            market_cleanprice      double           the clean price given by the market (from DAMD)


        Example:
            The module is called (from python) like this::

                import import applications.FRTB.getCurvePriceFromDAMD as getCurve as GETCURVE
                import  mr_common.external_connection.get_string as getconstr
                currt = qt.datetime.datetime(2016,11,17)
                import quantum as qt

                DAMD_concet_string =getconstr.get_string(info=0, database='DAMD')
                temp1=self.simple_bond_Pricing(ISIN='SE0001811399',
                                  MDC=GETCURVE,
                                  currt=currt,
                                  constr=DAMD_concet_string ,
                                  zspread=-1)

        Author:
            g48454

        Version:
            1   29Nov2016   G48454  Initial creation
            1   05dec2016   G50091  change MDC to GETCURVE

        Review:
            x   ddmonyyyy   Gxxxxx  <OK (optional comment)>
        """
        qt_version = version_indp.return_main_qt_version()
        if bond_swap_basis_t == '':
            bond_swap_basis_t = currt

        if risk_free_rate_t == '':
            risk_free_rate_t = currt

        currISIN = ISIN

        class result():
            model_fullprice = 0
            market_fullprice = 0
            zspread = 0
            market_cleanprice = 0
            model_cleanprice=0
            accured_int=0

        tempResult = result()
        ###############################
        # load cashflow
        ###############################
        try:
            bond_cash_flow_obj = cashFlowCache.getvalue(currt)
        except Exception as e:
            self.trackError(position=ISIN, date=currt,
                            comments='no cash flow')
            return


        # ===================================================================================
        # Try to load discount curve from the external bond curves
        # If external bond curve can not be provided, load risk free rate and bond swap basis
        # ===================================================================================
        if bondCurveCache=='':
            need_make_disc_curve=True
        else:
            need_make_disc_curve = False
            try:
                bond_curve=bondCurveCache.getvalue(currt)
                disc_curve=qt.DiscCurveZeroCoupon.make(date=currt,
                                                  ccy=ccy,curve=bond_curve)
            except Exception as e:
                self.trackError(position=ISIN, date=currt,
                                comments='no bond curve')
                return


        ###############################
        # load risk free rate
        ###############################
        if externalRiskFreeCurve=='' and need_make_disc_curve:
            try:
                risk_free_curve = riskFreeRateCache.getvalue(risk_free_rate_t)
            except Exception as e:
                self.trackError(position=ISIN, date=currt,
                                comments='no risk free curve')
                return
        else:
            risk_free_curve=externalRiskFreeCurve

        ###############################
        # load bond swap basis curve
        ###############################
        if externalBondSwapBasisCurve == '' and need_make_disc_curve:
            try:
                bond_swap_basis = bondSwapBasisCache.getvalue(bond_swap_basis_t)
            except Exception as e:
                print(e)
                return
        else:
            bond_swap_basis = externalBondSwapBasisCurve

        ###############################
        # make discounting curve
        ###############################
        if need_make_disc_curve:
            disc_curve = qt.DiscCurveZeroCouponSpread.make(date=currt,
                                                       ccy=ccy,
                                                       curve=risk_free_curve,
                                                       spreadCurve=bond_swap_basis,
                                                       discountType='OIS')
        ###############################
        # take the credit curve
        ###############################
        if externalCDSCurve == '':
            if cdsSpreadCache == '':
                d = [qt.datetime.datetime(2017, 11, 18), qt.datetime.datetime(2050, 11, 28)]
                h = [0, 0]  # input, empty hazard rate
                hc = qt.CurveFlat.make(d, h)
                credit_curve = qt.CreditCurveInterpolated.make('emptyCurve', ccy, currt, hc, 0.4)
            else:
                try:
                    credit_curve= cdsSpreadCache.getvalue(currt)
                except Exception as e:
                    self.trackError(position=ISIN, date=currt,
                                    comments='no cds curve')
                    return
        else:
            credit_curve = externalCDSCurve

        ###############################
        # load market price
        ###############################
        try:
            priceObj = marketPriceCache.getvalue(currt)
        except Exception as e:
            self.trackError(position=ISIN, date=currt,
                            comments='no reval price')
            return

        if priceObj['accrued_interest'] == None:  # this is the case where accured Interest is NONE. Later on we should also introduce the option to get data from MARS
            market_dirty_price = float(priceObj['clean_price'])
            print (currISIN, 'doesnt have accured interest', "for date:", currt.strftime('%Y%m%d'))
        else:
            market_dirty_price = float(priceObj['clean_price']) + float(priceObj['accrued_interest'])
        tempResult.market_fullprice = market_dirty_price
        tempResult.market_cleanprice = float(priceObj['clean_price'])
        tempResult.accured_int=tempResult.market_fullprice - tempResult.market_cleanprice

        if market_dirty_price<10 and zspread==-1:
        # ===================================================================================
        # do some sanity check of the price....
        # ===================================================================================
            self.trackError(position=ISIN, date=currt,
                            comments='the market price is less than 10(normal level should around 100, zspread will not be calculated')
            return
        ###############################
        # Imply Z-spread
        ###############################
        if zspread == -1:
            if currt == bond_swap_basis_t and bond_swap_basis_t == risk_free_rate_t:

                if qt_version == 8:
                    zspread = qt.ImpliedZSpread_CC(disc_curve, credit_curve
                                                   , bond_cash_flow_obj, market_dirty_price)
                elif qt_version ==11:
                    zspread = qt.impliedZSpread_CC(disc_curve, credit_curve
                                                   , bond_cash_flow_obj, market_dirty_price)
                elif qt_version>12:
                    zspread = qt.impliedZSpreadCc(disc_curve, credit_curve
                                                   , bond_cash_flow_obj, market_dirty_price)
                else:
                    self.trackError(position=ISIN, date=currt,
                                    comments='please check your qt version!')
                    return


                if zspread == 0.005:
                    # ===================================================================================
                    # seems sometime the qt impliedzspread function will return 50bps as default value, then we just track an error
                    # ===================================================================================
                    self.trackError(position=ISIN, date=currt, comments='zspread return 50 bps, implied zspread calculation can not finished')
                    return
                else:
                    # ===================================================================================
                    # if not 50 bps, return as normal
                    # ===================================================================================
                    tempResult.zspread = zspread
            else:
                print('Error!, you can not calculate z spread when the three dates are not same! ')
                return

        ###############################
        # Calculation Price
        ###############################
        zSpread = qt.ZSpread(isin = ISIN, spread = zspread)
        disc_curve_w_z_spread = qt.DiscCurveWithZSpread.make(disc_curve, zSpread)

        if qt_version == 8:
            tempResult.model_fullprice = qt.bondCashFlowPvCc_CC(disc_curve_w_z_spread, credit_curve
                                                           , bond_cash_flow_obj)
        elif qt_version == 11:
            tempResult.model_fullprice = qt.bondCashFlowPV_CC(disc_curve_w_z_spread, credit_curve
                                                       , bond_cash_flow_obj)
        elif  qt_version > 12:
            tempResult.model_fullprice = qt.bondCashFlowPvCc(disc_curve_w_z_spread, credit_curve
                                                                , bond_cash_flow_obj)
        else:
            self.trackError(position=ISIN, date=currt,
                            comments='please check your qt version!')
            return


        tempResult.model_cleanprice= tempResult.model_fullprice - tempResult.accured_int

        return tempResult




    def get_static_data(self):
       '''
       This function return the static information, includding core information and issuer information from the web serivce.
       '''
       from core.risk.frtb_credit.bond_utili import get_core_information
       from core.risk.frtb_credit.bond_utili import get_issuer_information
       df=get_core_information(self.Position_Lists)
       self.resultDataFrameList.append(df)
       self.resultDataFrameName.append('bond_coreInformation')


       # ===================================================================================
       # get issuer information from web service
       # http://mds.oneadr.net/v1/instrument/coreinformation/issuers
       # ===================================================================================
       df = get_issuer_information(self.Position_Lists)
       self.resultDataFrameList.append(df)
       self.resultDataFrameName.append('issuer_information')


    def update_zspread_to_DAMDS(self):
        # ===================================================================================
        # Make sure all these isins have been deleted from the table
        # ===================================================================================
        from core.connection.database_connect import return_sql_engine
        engine = return_sql_engine("DAMDS")
        sql_string = self.return_delete_sql_string_for_isin()
        print("delete relevant records if there is any...")
        with engine.connect() as conn:
            conn.execute(sql_string)
        print("delete finished.")
        # ===================================================================================
        # Calculate zspread dyanmics
        # ===================================================================================
        zspreadPD = self.resultDataFrameList[self.resultDataFrameName.index('Zspread')]
        print("upload zspread to DAMDS table, in total :" + str(zspreadPD.count()) + ' records ....')
        zspreadPD.to_sql(name='zspread_frtb', con=engine,
                     schema='GMCCR_TIMESERIES',
                       # dtype={'info_date': DATE,
                       #       'isin': VARCHAR(50),
                       #       'curve_name': VARCHAR(50),
                       #        'cds_curve_name' : VARCHAR(50),
                       #       'zspread': NUMERIC(20, 10)},
                      flavor='oracle',
                    if_exists='append', index=False)

        print("upload zspread to DAMDS table, Done")

    def return_sql_string_for_already_exsisted_isin(self):
        '''
            Creates sql extract string used for retrieving FX spot prices from MARS

            Args:
                info                    (int)           Level of information printed. The higher, the more information is printed
                ISIN_Lists              (list of str)   List of ISINs
                startd                  (datetime)      start date
                endd                    (datetime)      end date

            Returns:
                (str):   Sql extract string
                Author: g48454
            '''
        import core.utils.string as string
        ISIN_Lists = self.Position_Lists
        min_sql_date = oracle_to_date(self.analysisStartDate)
        max_sql_date = oracle_to_date(self.analysisEndDate)
        date_where_clause = '(' + min_sql_date + ' < = INFO_DATE and INFO_DATE <= ' + max_sql_date + ')'
        ISIN_where_caluse = 'ISIN in (' + string.commasep_quoted(ISIN_Lists) + ')'
        combined_where_clause = date_where_clause + ' and ' + ISIN_where_caluse
        select_query = ('''
                                select *
                                from GMCCR_TIMESERIES.ZSPREAD_FRTB
                                where
                            '''
                        + combined_where_clause
                        )
        return select_query


    def return_delete_sql_string_for_isin(self):
        '''
            Creates sql extract string used for retrieving FX spot prices from MARS

            Args:
                info                    (int)           Level of information printed. The higher, the more information is printed
                ISIN_Lists              (list of str)   List of ISINs
                startd                  (datetime)      start date
                endd                    (datetime)      end date

            Returns:
                (str):   Sql extract string
                Author: g48454
            '''
        import core.utils.string as string
        ISIN_Lists = self.Position_Lists
        min_sql_date = oracle_to_date(self.analysisStartDate)
        max_sql_date = oracle_to_date(self.analysisEndDate)
        date_where_clause = '(' + min_sql_date + ' < = INFO_DATE and INFO_DATE <= ' + max_sql_date + ')'
        ISIN_where_caluse = 'ISIN in (' + string.commasep_quoted(ISIN_Lists) + ')'
        combined_where_clause = date_where_clause + ' and ' + ISIN_where_caluse
        select_query = ('''
                                delete
                                from GMCCR_TIMESERIES.ZSPREAD_FRTB
                                where
                            '''
                        + combined_where_clause
                        )
        return select_query
