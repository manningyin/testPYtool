import core.connection.database_extract as db
import pandas as pd

class static_data_mapping(object):

    def __init__(self, isin_list):
        self.isin_list_str = self.format_isin_list(isin_list)

        self.isin_list = isin_list

        self.df_parent_sector = db.select_from_query(database="DAMDP_RO", query=self.get_parent_child_query())

        self.df_damdp_rating = db.select_from_query(database="DAMDP_RO", query=self.get_rating_query())

        self.df_damdp_region = db.select_from_query(database="DAMDP_RO", query=self.get_region_query())

        self.df_damdp_sector = db.select_from_query(database="DAMDP_RO", query=self.get_sector_query())

    def format_isin_list(self,isin_list):
        list_isin_key = ""
        for i in range(0, len(isin_list)):
            list_isin_key = isin_list[i] + ", " + list_isin_key

        list_isin_key = list_isin_key[:-2]

        tmp = ""
        for i, m in enumerate(list_isin_key.replace(' ', '').split(',')):
            tmp = tmp + m + "','"

        list_isin_key = tmp[:-3]
        list_isin_key = "'" + list_isin_key + "'"

        return list_isin_key

    def get_rating_query(self):
        self.rating_query = '''
                select
                 sn.DESCRIPTION as ISIN,
                 spr.DESCRIPTION as SP_RATING,
                 mor.DESCRIPTION as MOODYS_RATING
                 from ANASYS.SECURITY_NAMES sn
                 left join anasys.bond_info bi on (sn.EFFECT_ID=bi.EFFECT_ID)
                 left join ANASYS.ISSUERS iss on (bi.ISSUER_ID=iss.ISSUER_ID)
                 left join ANASYS.CREDIT_RATINGS cra on (bi.RATING_CLASS=cra.RATING_CLASS and bi.ISSUER_ID=cra.ISSUER_ID)
                 left join ANASYS.SP_RATINGS spr on (cra.SP_RATING_ID=spr.RATING_ID)
                 left join ANASYS.MOODY_RATINGS mor on (cra.MOODY_RATING_ID=mor.RATING_ID)
                 where 1=1
                 and sn.NAME_ID=1
                 and (bi.VALID_UNTIL_DATE is null or bi.VALID_UNTIL_DATE >= trunc(sysdate))
                 and (cra.VALID_UNTIL_DATE is null or cra.VALID_UNTIL_DATE >= trunc(sysdate))
                 and sn.DESCRIPTION in (''' + self.isin_list_str + ''')
                '''
        self.rating_query = self.rating_query.replace('"', "")
        self.rating_query = self.rating_query.replace("\n", "")

        return  self.rating_query

    def get_region_query(self):
        self.region_query = '''
                    select
                     sn.DESCRIPTION AS ISIN,
                     reg.REGION_NAME
                     from ANASYS.SECURITY_NAMES sn
                     left join anasys.bond_info bi on (sn.EFFECT_ID=bi.EFFECT_ID)
                     left join ANASYS.ISSUERS iss on (bi.ISSUER_ID=iss.ISSUER_ID)
                     left join ANASYS.REGIONS_COUNTRIES rc on (iss.PRIMARY_COUNTRY_ID=rc.COUNTRY_ID)
                     left join ANASYS.REGIONS reg on (rc.REGION_ID=reg.REGION_ID)
                     where 1=1
                     and reg.GEOGRAPHICAL=1
                     and reg.GEOGRAPHICAL is not null
                     and sn.NAME_ID = 1
                     and (bi.VALID_UNTIL_DATE is null or bi.VALID_UNTIL_DATE >= trunc(sysdate))
                     and sn.DESCRIPTION in (''' + self.isin_list_str + ''')
                    '''
        self.region_query = self.region_query.replace('"', "")
        self.region_query = self.region_query.replace("\n", "")

        return self.region_query

    def get_sector_query(self):
        self.df_damdp_sector = '''
                    select
                     sn.DESCRIPTION as ISIN,
                     ind.ID,
                     ind.PARENT_ID,
                     ind.GICS_CODE,
                     ind.GICS_SECTOR_NAME
                     from ANASYS.SECURITY_NAMES sn
                     left join anasys.bond_info bi on (sn.EFFECT_ID=bi.EFFECT_ID)
                     left join ANASYS.ISSUERS iss on (bi.ISSUER_ID=iss.ISSUER_ID)
                     left join ANASYS.INDUSTRIES ind on (iss.SECTOR_ID=ind.ID)
                     where 1=1
                     and sn.NAME_ID=1
                     and (bi.VALID_UNTIL_DATE is null or bi.VALID_UNTIL_DATE >= trunc(sysdate))
                     and sn.DESCRIPTION in (''' + self.isin_list_str + ''')
                    '''
        self.df_damdp_sector = self.df_damdp_sector.replace('"', "")
        self.df_damdp_sector = self.df_damdp_sector.replace("\n", "")

        return self.df_damdp_sector

    def get_parent_child_query(self):
        self.parent_child_query = '''
                select
                 ind.id, ind.parent_id, ind.gics_code, ind.gics_sector_name, LEVEL
                 from anasys.industries ind
                 START WITH ind.id in (SELECT IND.ID FROM ANASYS.INDUSTRIES IND WHERE IND.PARENT_ID IS NULL connect by IND.id=IND.PARENT_ID CONNECT BY PRIOR IND.ID = IND.PARENT_ID)
                 connect by prior ind.ID=ind.PARENT_ID
                 '''
        self.parent_child_query = self.parent_child_query.replace('"', "")
        self.parent_child_query = self.parent_child_query.replace("\n", "")

        return  self.parent_child_query

    def getRating(self):
        '''
                    The function provide a mapping on Rating between Front Office Database DAMDP and external vendor Markit.
                    Markit convention by Shengyao #ratings=['AAA','AA','A','BBB','BB','B']
                    The Rating from DAMDP can be either SP and Moody, or SP or Moody only, or NULL.

                    Args:
                        rating                  (str):              A String variable containing Rating value

                    Returns:
                        dictionary    (dict):   Rating in Markit convention


                    Notes:
                        Author: g47193
        '''

        self.rating_dict = {'A':'A',
                       'A-':'AA',
                       'A+':'AA',
                       'AA':'AA',
                       'AA-':'AAA',
                       'AA+':'AAA',
                       'AAA':'AAA',
                       'B':'B',
                       'B-':'BB',
                       'B+':'BB',
                       'BB':'BB',
                       'BB-':'BBB',
                       'BB+':'BBB',
                       'BBB':'BBB',
                       'BBB-':'CCC',
                       'BBB+':'CCC',
                       #'C':[{'SP':'CCC','Moody':'D'}], #wait with this as C is not used in Shengyao's set of ratings and it forces me to something like try type(dict[]['']) == list
                       'CC':'CCC',
                       'CCC':'CCC',
                       'CCC-':'D',
                       'CCC+':'D',
                       'D':'D',
                       'Not rated':'null',
                       'NULL':'null',
                       'A2':'A',
                       'A3':'AA',
                       'A1':'AA',
                       'Aa2':'AA',
                       'Aa3':'AAA',
                       'Aa1':'AAA',
                       'Aaa':'AAA',
                       'B2':'B',
                       'B3':'BB',
                       'B1':'BB',
                       'Ba2':'BB',
                       'Ba3':'BBB',
                       'Ba1':'BBB',
                       'Baa2':'BBB',
                       'Baa3':'CCC',
                       'Baa1':'CCC',
                       'Ca':'CCC',
                       'Caa2':'CCC',
                       'Caa3':'D',
                       'Caa1':'D'}

        return_rating_dict = {}

        if len(self.df_damdp_rating) == 0:
            for isin in self.isin_list:
                return_rating_dict[isin] = 'null'

        for i in range(0,len(self.df_damdp_rating)):
            try:
                if not self.df_damdp_rating[i]['sp_rating'] and not self.df_damdp_rating[i]['moodys_rating']:
                    return_rating_dict[self.df_damdp_rating[i]['isin']] = 'null'
                    pass
                elif not self.df_damdp_rating[i]['sp_rating']:
                    return_rating_dict[self.df_damdp_rating[i]['isin']] = self.rating_dict[self.df_damdp_rating[i]['moodys_rating']]
                elif not self.df_damdp_rating[i]['moodys_rating']:
                    return_rating_dict[self.df_damdp_rating[i]['isin']] = self.rating_dict[self.df_damdp_rating[i]['sp_rating']]
                else:
                    return_rating_dict[self.df_damdp_rating[i]['isin']] = self.rating_dict[self.df_damdp_rating[i]['sp_rating']]
            except:
                return_rating_dict[self.df_damdp_rating[i]['isin']] = 'null'

        return return_rating_dict

    def getRegion(self):
        '''
                    The function provide a mapping on Regions between Front Office Database DAMDP and external vendor Markit.
                    Markit convention by Shengyao # regions=['NORDIC','World','Europe','Asia','N. America']
                    The Rating from DAMDP can be NULL.

                    Args:
                        regions                  (str):              A String variable containing Regions value

                    Returns:
                        dictionary    (dict):   Regions in Markit convention


                    Notes:
                        Author: g47193
        '''

        self.region_dict = {'Africa & Middle East':'World',
                       'Asia & Pacific':'Asia',
                       'Central & Eastern Europe':'Europe',
                       'Baltics':'Europe',
                       'South Eastern Europe':'Europe',
                       'Euro countries':'Europe',
                       'Europe':'Europe',
                       'Nordic countries':'NORDIC',
                       'Latin America':'World',
                       'North America':'NAmerica'
                       }

        return_region_dict = {}


        if len(self.df_damdp_region) == 0:
            for isin in self.isin_list:
                return_region_dict[isin] = 'null'

        for i in range(0,len(self.df_damdp_region)):
            try:
                # if no region found, use World instead
                if not self.df_damdp_region[i]['region_name']:
                    return_region_dict[self.df_damdp_region[i]['isin']] = 'null'
                    pass
                else:
                    return_region_dict[self.df_damdp_region[i]['isin']] = self.region_dict[self.df_damdp_region[i]['region_name']]
            except:
                # if no region found, use World instead
                return_region_dict[self.df_damdp_region[i]['isin']] = 'null'

        return return_region_dict

    def getSector(self):
        '''
                        The function provide a mapping on Sector between Front Office Database DAMDP and external vendor Markit.
                        Markit convention by Shengyao # sectors=['CONSDSC', 'CONSSTP', 'HEALTH', 'FINANCE', 'IT', 'TELECOM', 'UTILITY','ENERGY','MATERIAL', 'INDUST']
                        The Sector from DAMDP can be NULL.

                        Args:
                            sector                  (str):              A String variable containing Sector value

                        Returns:
                            dictionary    (dict):   Sector in Markit convention


                        Notes:
                            Author: g47193
            '''
        self.sector_dict = {'Materials':'MATERIAL',
                       'Consumer Discretionary':'CONSDSC',
                       'Energy':'ENERGY',
                       'Financials':'FINANCE',
                       'Health Care':'HEALTH',
                       'Industrials':'INDUST',
                       'Telecommunication Services':'TELECOM',
                       'Utilities':'UTILITY',
                       'Consumer Staples':'CONSSTP',
                       'Information Technology':'IT'
                       }

        return_sector_dict = {}

        if len(self.df_damdp_sector) == 0:
            for isin in self.isin_list:
                return_sector_dict[isin] = 'null'


        for i in range(0, len(self.df_damdp_sector)):
            try:
                if not self.df_damdp_sector[i]['gics_sector_name']:
                    # if no industry avaliable, use FINANCE as default
                    return_sector_dict[self.df_damdp_sector[i]['isin']] = 'null'
                    pass
                else:
                    return_sector_dict[self.df_damdp_sector[i]['isin']] = self.sector_dict[self.getSectorTopParent(
                     self.df_damdp_sector[i]  )]
            except:
                return_sector_dict[self.df_damdp_sector[i]['isin']] = 'null'

        return return_sector_dict

    def getSectorTopParent(self, temp_dict):
        '''
                    A recursive function to give top-parent of child-sector id.

                    Args:
                        temp_dict                   (dict):              DataFrame(ISIN, ID, PARENT_ID, GICS_SECTOR_NAME)

                    Returns:
                            (str):   string of industry name


                    Notes:
                        Author: g47193
                '''
        #df_pc = pds.read_sql(getParentChild(isin_list), DBCon(getpass.getuser(), my_password(damdp_param).getPW(), damdp_param).getConn())

        if not temp_dict['parent_id']:
            return temp_dict['gics_sector_name']
        else:
            # changed by Shengyao, indexing through the dict
            temp_index = next(index for (index, d) in enumerate(self.df_parent_sector) if d["id"] == temp_dict['parent_id'])
            df_internal = self.df_parent_sector[temp_index]
            return self.getSectorTopParent(df_internal)

        """

        if df[0]['parent_id'].isnull().any():
            return df[0]['gics_sector_name']
        else:
            df_internal = self.df_parent_sector[self.df_parent_sector['id'].isin(df[0]['parent_id'])]
            return self.getSectorTopParent(df_internal)
        """
if __name__ == '__main__':

    #myISIN = ['DK0009918138','DK0009763344','XS0237270995','NO0010296775','NO0010039878','NO0010297468']
    myISIN = ['NO0010039878','NO0010296775', 'NO0010297468']

    myISIN = ['FI4000053160']

    bond_rating = static_data_mapping(myISIN)
    bond_rating_dict = bond_rating.getRating()
    print (bond_rating_dict)

    bond_region = static_data_mapping(myISIN)
    bond_region_dict = bond_region.getRegion()
    print (bond_region_dict)

    bond_sector = static_data_mapping(myISIN)
    bond_sector_dict = bond_sector.getSector()
    print (bond_sector_dict) #fix recursive per ISIN

