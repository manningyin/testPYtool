import os
import sys

sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])

import core.connection.sqltool as sqltool
from core.caching.cache_driver import method_cache,memory_cache,json_cache
import numpy as np
from core.risk.irm.connection import get_cursor
import logging
import json
from scipy.stats import t as student_t
from scipy.stats import norm
from core.risk.irm.config import config
import pandas as pd

migrations_raw = sqltool.query_all_with_sql(query="""
WITH ord AS
   (
     SELECT
       a.from_rating_id rating_id,
       b.rating_grp_id,
       a.migration_id,
       row_number() over (order by a.from_rating_id desc,max(b.rating_id) desc) ord
     FROM
       marsp.ir_model d,
       marsp.irm_model_matrix e,
       marsp.rating_migration a,
       marsp.rating_grp_rating b,
       marsp.rating_supergrp_rating_grp c
     WHERE
           d.ir_model_id = %(ir_model_id)d
       AND e.ir_model_id = d.ir_model_id
       AND e.issuer_type_id = '%(issuer_type_id)s'
       AND a.to_rating_id = b.rating_id
       AND a.term_id = '1Y'
       AND a.migration_id = e.migration_id
       AND c.rating_supergrp_id = 'IR'
       AND c.rating_grp_id = b.rating_grp_id
     GROUP BY a.from_rating_id, b.rating_grp_id, a.migration_id
   ),
   probs AS
   (
     SELECT
       x.from_rating_id rating_id,
       rgr.rating_grp_id,
       sum(x.probability) migr_prob,
       y.ord,
       round(sum(sum(x.probability)) over (partition by x.from_rating_id order by y.ord rows unbounded preceding),10) sum_prob
     FROM
       marsp.rating_migration x,
       marsp.rating_supergrp_rating_grp rsrg,
       marsp.rating_grp_rating rgr,
       ord y
     WHERE
           x.from_rating_id = y.rating_id
       AND x.to_rating_id = rgr.rating_id
       AND x.migration_id = y.migration_id
       AND y.rating_grp_id = rgr.rating_grp_id
       AND rsrg.rating_supergrp_id = 'IR'
       AND rsrg.rating_grp_id = rgr.rating_grp_id
       AND x.term_id = '1Y'
     GROUP BY x.from_rating_id,rgr.rating_grp_id,y.ord
     ORDER BY y.ord
  )
SELECT
  rating_id,
  rating_grp_id,
  marsp.statfunk.inversenormcum(nvl(lag(sum_prob,1) over (partition by rating_id order by ord),0)) attach,
  marsp.statfunk.inversenormcum(sum_prob) detach,
  migr_prob
FROM probs
ORDER BY ord;
""",keys=["rating_id","rating_grp_id","attach","detach","migr_prob"])

@json_cache   
def migrations(issuer_type_id,ir_model_id=1, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    return migrations_raw(cursor=cursor,issuer_type_id=issuer_type_id, ir_model_id=ir_model_id)
    
@memory_cache
@json_cache
def migrations_for_rating(issuer_type_id, rating_id, ir_model_id=1, cursor=None):
    migr,sql = migrations(cursor=cursor, issuer_type_id=issuer_type_id,ir_model_id=ir_model_id)
    return [r for r in migr if r["rating_id"] == rating_id],sql

@memory_cache
@json_cache
def migrations_for_rating_stressed(issuer_type_id, rating_id, ir_model_id=1, shock=0, how='abs', cursor=None):
    migr,sql = migrations(cursor=cursor, issuer_type_id=issuer_type_id,ir_model_id=ir_model_id)
    m=[r for r in migr if r["rating_id"] == rating_id]
    migr_prob = {}
    PD = 0
    for i in m:
        if i["rating_grp_id"] == "D":
            PD = i["migr_prob"]
        else:
            migr_prob[i["rating_grp_id"]] = i["migr_prob"]

    if how == 'abs':
        PD_shock = max(min(PD + shock, 1), 0)
    elif how == 'rel':
        PD_shock = max(min(PD * (1 + shock), 1), 0)
    elif how == 'floor':
        PD_shock = max(PD, shock)
    else:
        logging.error(how + ' stress method not supported.')
        sys.exit()

    summed_row = sum(migr_prob.values())
    adj_migr = {}
    for i in migr_prob:
        adj_migr[i] = migr_prob[i] * (1 - PD_shock) / summed_row

    adj_migr["D"] = PD_shock

    migr_stressed = m.copy()
    for j in migr_stressed:
        migr_stressed[migr_stressed.index(j)]["migr_prob"] = adj_migr[j["rating_grp_id"]]


    return migr_stressed,sql


rating_to_group_raw = sqltool.query_all_with_sql(query="""
SELECT
  RATING_ID,
  RATING_GRP_ID
FROM marsp.rating_grp_rating
WHERE
  RATING_ID<=23 AND
  RATING_GRP_ID IN ('AAA','AA','A','BBB','BB','B','CCC','CNR','D')
  ORDER BY RATING_ID;
  """)

@memory_cache
def rating_to_group_dict(cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    data,sql=rating_to_group_raw(cursor=cursor)
    return dict((int(row["rating_id"]),str(row["rating_grp_id"]))for row in data)

def rating_to_group(rating_id,cursor=None):
    return rating_to_group_dict()[rating_id]
    
class Migrator:
    """Migrator object encapsulates migrations of a certain rating_id and issuer type."""
    sql=""
    def __init__(self,migrations,issuer_type_id,rating_id,ir_model_id):
        self.migrations     = migrations
        self.issuer_type_id = issuer_type_id
        self.rating_id      = rating_id
        self.ir_model_id    = ir_model_id

    @classmethod
    def for_rating(cls, issuer_type_id, rating_id, ir_model_id,cursor=None):
        rating_id=int(rating_id)
        ir_model_id=int(ir_model_id)
        migrations,sql = migrations_for_rating(cursor=cursor,issuer_type_id=issuer_type_id,rating_id=rating_id,ir_model_id=ir_model_id)
        m=Migrator(migrations=migrations,issuer_type_id=issuer_type_id,rating_id=rating_id,ir_model_id=ir_model_id)
        m.sql=sql
        return m
    
    @classmethod
    def from_dict(cls,d):
        m=Migrator(migrations=d["migrations"],issuer_type_id=d["issuer_type_id"],rating_id=d["rating_id"],ir_model_id=d["ir_model_id"])
        m.sql = d.get("sql","")
        return m

    @classmethod
    def for_rating_stressed(cls,issuer_type_id, rating_id, ir_model_id, shock, how, cursor=None):
        rating_id=int(rating_id)
        ir_model_id=int(ir_model_id)
        migrations,sql = migrations_for_rating_stressed(cursor=cursor,issuer_type_id=issuer_type_id,rating_id=rating_id,ir_model_id=ir_model_id,shock=shock,how=how)
        m=Migrator(migrations=migrations,issuer_type_id=issuer_type_id,rating_id=rating_id,ir_model_id=ir_model_id)
        m.sql=sql
        return m
#    def ordinal_boundaries(self):

        
    def to_dict(self):
        return dict(
            migrations     = self.migrations,
            issuer_type_id = self.issuer_type_id,
            rating_id      = self.rating_id,
            ir_model_id    = self.ir_model_id,
            sql            = self.sql
        )

    def rating_group(self):
        "Return the rating group corresponding to the Migrator rating_id."
        return rating_to_group(self.rating_id)
        
    def check_migrations(self,tiny=1e-6):
        """Checks the consistency of migrations.

           Returns:
               (bool, str):   Return a tuple of a boolean (True if migrations are consistent.) and a string describing the inconsistency (if any)        

           Example:
               See unit tests, e.g.
               risk\irm\test_migration_matrix.py, TestMigrationMatrix.test_migrations_boundaries
        """
        for i,m in enumerate(self.migrations):
            if m["rating_id"]!=self.rating_id:
                logging.warning("Discrepancy in migrator: migration rating_id (%s) differs from migrator rating_id (%s)."%(m["rating_id"],self.rating_id))
            if m["detach"]<m["attach"]:
                return False,"Detach is less than attach in migration %d"%i
        for i,(m1,m2) in enumerate(zip(self.migrations,self.migrations[1:])):
            if np.abs(m1["detach"]-m2["attach"])>tiny:
                return False,"Detach and attach of migrations %d amd %d not connected."%(i,i+1)
        return True,"OK"

    @method_cache
    def migrations_boundaries(self, distribution_type=None):
        if distribution_type is None:
            if config()["random_source"] == "student":
                return self.student_migrations_boundaries()            
        if distribution_type is None:
            return self.migrations_boundaries_from_database()
        if distribution_type == "student":
            return self.student_migrations_boundaries()
        if distribution_type == "normal":
            return self.normal_migrations_boundaries()

        raise Exception("Unsupported probability distribution: "+str(distribution_type))        
        
    @method_cache
    def migrations_boundaries_from_database(self):
        """Return array of boundaries on the normal random number distribution.
           This corresponds to attach-detach boundaries of each migration.
           
           Properties:
             - boundaries[i] corresponds to detach of migration i-1 and attach of migration i.
             - for all i, boundaries[i]<=boundaries[i+1]         
           
           Returns:
               (numpy array of real numbers):   The array size is len(migrations)+1

           Example:
               See unit tests, e.g.
               risk\irm\test_migration_matrix.py, TestMigrationMatrix.test_migrations_boundaries

           Warning:
               The function may fail to deliver correct results if migrations are not consistent,
               e.g. if there are gaps in attach/detach or if the migrations are incorrectly ordered.
               Run check_migrations to make sure if the migrations are consistent.

           Notes:
               See as well the check_migrations method.
               Author: g46987 (Orest Dubay)
        """
        boundaries = np.zeros(len(self.migrations)+1,np.double)
        boundaries[0]=self.migrations[0]["attach"]
        for i,m in enumerate(self.migrations):
            boundaries[i+1] = m["detach"]
        return boundaries

    @method_cache
    def student_migrations_boundaries(self):
        """Return array of boundaries on the Student random number distribution.
           This conceptually corresponds to attach-detach boundaries of each migration.
           
           Properties:
             - boundaries[i] corresponds to detach of migration i-1 and attach of migration i.
             - for all i, boundaries[i]<=boundaries[i+1]         
           
           Returns:
               (numpy array of real numbers):   The array size is len(migrations)+1

           Example:
               See unit tests, e.g.
               risk\irm\test_migration_matrix.py, TestMigrationMatrix.test_migrations_boundaries

           Warning:
               The function may fail to deliver correct results if migrations are not consistent,
               e.g. if there are gaps in attach/detach or if the migrations are incorrectly ordered.
               Run check_migrations to make sure if the migrations are consistent.

           Notes:
               See as well the check_migrations method.
               Author: g46987 (Orest Dubay)
        """
        boundaries = np.zeros(len(self.migrations)+1,np.double)
        migration_probabilities=[m["migr_prob"] for m in self.migrations]

        DOF = config()["degrees_of_freedom"]

        boundaries[0] = -1000
        pd_sum = 0
        for i in range(len(migration_probabilities)-1):
            pd_sum = pd_sum + migration_probabilities[i]
            if pd_sum == 0:
                boundaries[i + 1] = -1000
            elif pd_sum >0.9999999999999999:
                boundaries[i + 1] = 1000
            else:
                boundaries[i + 1] = student_t.ppf(pd_sum, DOF)
        boundaries[len(migration_probabilities)] = 1000

        return boundaries

    @method_cache
    def normal_migrations_boundaries(self):
        """Return array of boundaries on the Normal random number distribution. Used to adjust bounderies whe PDs are stressed.
        Ddded in by Berglind (g50087) March 2020
        """
        boundaries = np.zeros(len(self.migrations) + 1, np.double)
        migration_probabilities = [m["migr_prob"] for m in self.migrations]

        boundaries[0] = -1000
        pd_sum = 0
        for i in range(len(migration_probabilities) - 1):
            pd_sum = pd_sum + migration_probabilities[i]
            if pd_sum == 0:
                boundaries[i + 1] = -1000
            elif pd_sum > 0.9999999999999999:
                boundaries[i + 1] = 1000
            else:
                boundaries[i + 1] = norm.ppf(pd_sum)
        boundaries[len(migration_probabilities)] = 1000

        return boundaries

    def migrates_to_ordinal_(self,asset_value):        
        "Original (old) implementation of migrates_to_ordinal."
        for i in range(len(self.migrations)):
            if asset_value > self.migrations[i]["attach"] and (self.migrations[i]["detach"] is None or asset_value <= self.migrations[i]["detach"]):
                return len(self.migrations) - i - 1
        raise Exception("migration not found " + self.rating_id + " for value " + asset_value)

    def migrates_to_ordinal(self,asset_value, distribution_type=None):
        """Convert the 'asset value' to a migration ordinal.
        Asset value is a normally distributed random number with zero mean and variance=1.
        Ordinal is (typically) the number of the rating group."""        
        mb=self.migrations_boundaries(distribution_type)
        index=np.searchsorted(mb,asset_value)
        if index<1 or index>=len(mb):
            raise Exception("migration not found " + self.rating_id + " for value " + asset_value)
        return len(self.migrations)-index
    
    def migrates_to_ordinal_vector_(self,asset_value_vector):
        "Original (old) implementation of migrates_to_ordinal_vector."
        s=np.zeros(len(asset_value_vector),np.int8)
        for j,asset_value in enumerate(asset_value_vector):
            found=False
            for i in range(len(self.migrations)):
                if asset_value > self.migrations[i]["attach"] and (self.migrations[i]["detach"] is None or asset_value <= self.migrations[i]["detach"]):
                    s[j] = len(self.migrations) - i - 1
                    found=True
                    break
           # if not found:
           #     raise Exception("migration not found " + self.rating_id + " for value " + asset_value)
        return s

    def migrates_to_ordinal_vector(self,asset_value_vector, distribution_type=None):
        "An optimized vector version of the migrates_to_ordinal method"
        mb=self.migrations_boundaries(distribution_type=distribution_type)
        index=np.searchsorted(mb,asset_value_vector) 
        
     #  if np.any(index<1) or np.any(index>=len(mb)):
       #     bad_asset_value=asset_value_vector[np.logical_or(index<1, index>=len(mb))][0]            
          #  raise Exception("migration not found %s for value %s"%(self.rating_id, bad_asset_value))
        return len(self.migrations)-index

    @method_cache
    def default_probability(self):
        for m in self.migrations:
            if m["rating_grp_id"] == "D":
                return m["migr_prob"]
        logging.error("no default-migration for %s in migrator %s"%(self.rating_id,json.dumps(self.to_dict())))
        raise Exception("no default-migration for " + self.rating_id)


class MigratorMaturityMismatch(Migrator):
    """
    MigratorMaturityMismatch object considers the time-to-maturity as well. Not only rating_id and issuer_type.
    """
    sql = ""

    @classmethod
    def for_rating(cls, issuer_type_id, rating_id, ir_model_id, time_to_maturity, migration_tables, cursor=None):
        rating_id = int(rating_id)
        ir_model_id = int(ir_model_id)
        time_to_maturity = int(time_to_maturity)

        if time_to_maturity == 12:
            migrations, sql = migrations_for_rating(
                cursor=cursor,
                issuer_type_id=issuer_type_id,
                rating_id=rating_id,
                ir_model_id=ir_model_id
            )
            m = Migrator(
                migrations=migrations,
                issuer_type_id=issuer_type_id,
                rating_id=rating_id,
                ir_model_id=ir_model_id
        )
            m.sql = sql
        else:
            if issuer_type_id == 'CORP':
                m = MigratorMaturityMismatch(
                    migrations=migration_tables[f"CORP_migrations_{time_to_maturity}"].loc[
                        migration_tables[f"CORP_migrations_{time_to_maturity}"]["rating_id"] == rating_id
                        ].to_dict('records'),
                    issuer_type_id=issuer_type_id,
                    rating_id=rating_id,
                    ir_model_id=ir_model_id
                )
                m.sql = "Non-SQL fetch for the <1 year credit event thresholds."
            elif issuer_type_id == 'GOVM':
                m = MigratorMaturityMismatch(
                    migrations=migration_tables[f"GOVM_migrations_{time_to_maturity}"].loc[
                        migration_tables[f"GOVM_migrations_{time_to_maturity}"]["rating_id"] == rating_id
                        ].to_dict('records'),
                    issuer_type_id=issuer_type_id,
                    rating_id=rating_id,
                    ir_model_id=ir_model_id
                )
                m.sql = "Non-SQL fetch for the <1 year credit event thresholds."
            else:
                print("ISSUER_TYPE_ID is neither GOVM or CORP.")
                m = None
        return m
    
class MigratorCyclicality(Migrator):
    
    @classmethod
    def for_rating(cls, issuer_type_id, rating_id, ir_model_id, run_type, migration_tables, cursor=None):
        rating_id = int(rating_id)
        ir_model_id = int(ir_model_id)
        run_type = str(run_type)

        if issuer_type_id == 'CORP':
            m = MigratorCyclicality(
                migrations=migration_tables[f"corporate_migrations_{run_type}"].loc[
                    migration_tables[f"corporate_migrations_{run_type}"]["rating_id"] == rating_id
                    ].to_dict('records'),
                issuer_type_id=issuer_type_id,
                rating_id=rating_id,
                ir_model_id=ir_model_id
            )
            m.sql = "Non-SQL fetch for the <1 year credit event thresholds."
        elif issuer_type_id == 'GOVM':
            m = MigratorCyclicality(
                migrations=migration_tables[f"sovereign_migrations_{run_type}"].loc[
                    migration_tables[f"sovereign_migrations_{run_type}"]["rating_id"] == rating_id
                    ].to_dict('records'),
                issuer_type_id=issuer_type_id,
                rating_id=rating_id,
                ir_model_id=ir_model_id
            )
            m.sql = "Non-SQL fetch for the <1 year credit event thresholds."
        else:
            print("ISSUER_TYPE_ID is neither GOVM or CORP.")
            m = None
        return m