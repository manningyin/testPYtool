# -*- coding: utf-8 -*-
import logging
import pandas as pd
import numpy as np
from application.IRM_CRM.IRM_maturity_mismatch_analysis.adjusted_return_queries import get_returns_by_maturity
from core.caching.cache_driver import method_cache
from core.math.tail import tail_average,\
                            tail_indices,\
                            tail
from core.risk.irm.config import config
from core.risk.irm.connection import get_cursor,\
                                        sqlite_connection,\
                                        get_sqlite_cursor
from core.risk.irm.irm_data import get_issuers,\
                                    get_issuers_modified,\
                                    query_for_migration_effects,\
                                    query_for_migration_effects_custom_grid,\
                                    get_issuers_wMarkit,\
                                    issuer_query_capital_centres_as_corp
from core.risk.irm.irm_data import query_for_postions,\
                                    mm_adjusted_query_for_postions,\
                                    query_for_postions_rr_shock,\
                                    get_risk_calc,\
                                    cons_org_struct,\
                                    query_for_postions_custom_grid
from core.risk.irm.irm_data import shifts_grid_dataframe
from core.risk.irm.irm_simulator import IRMSimulator,\
                                        IRMAssetValueSimulator,\
                                        IRMSimulatorOneFactorStudentCopula
from core.risk.irm.irm_simulator import IRMSimulatorDerived
from core.risk.irm.irm_simulator import IRMSimulatorMaturityMismatches
from core.risk.irm.random_source import random_source,\
                                        random_source_with_seed,\
                                        RandomSourceBase
from core.utils.date_helper import LAST_BUSINESS_DAY,\
                                    to_datetime,\
                                    date_format
from datetime import datetime
import core.connection.sqltool as sqltool
# for the new class for multiple multipliers matrices
import sys
paths = ['C:/working/git/code-lib/', 'C:/working/git/code-lib/ad-hoc']
for p in paths:
    if p not in sys.path:
        sys.path.append(p)
from Ola.irm_data_ola import load_issuers_country_data,\
                                load_country_to_region_mapping,\
                                load_gics_to_industry_mapping
import traceback


class PositionSimulations(object):
    def __init__(self):
        self.cursor = None
        self.eod_date = config()["eod_date"]
        self.ir_model_id = config()["ir_model_id"]
        self.rating_groups = config()["rating_groups"]
        self.JTD_ORDINAL = config().get("jtd_ordinal",len(self.rating_groups))
        self.simulations = config()["simulations"]
        self.returns_needed = config()["returns_needed"]
        self.random_source_name = config()["random_source"]
        self.issuers_simulation_cache = {}
        self.update_simulator()
        self.positions = None
        self.issuers = None
        self.sql = []
        self.rr_shock = False

    def update_simulator(self):
        self.simulator = IRMSimulator(
          ir_model_id=self.ir_model_id,
          simulations=self.simulations,
          random_source=random_source(ir_model_id=self.ir_model_id,name=self.random_source_name))
        self.reset_issuer_simulation_cache()

    def with_simulator(self,simulator,fill_in_parameters=True):
        self.simulator = simulator
        self.simulator.ir_model_id = self.ir_model_id
        self.simulator.simulations = self.simulations
        self.simulator.random_source = random_source(ir_model_id=self.ir_model_id,
                                                     name=self.random_source_name)
        self.reset_issuer_simulation_cache()
        return self

    def with_cursor(self,cursor):
        "Set the database cursor to be used in the simulation."
        self.cursor=cursor
        return self
        
    def with_default_cursor(self):
        "Set the database cursor based on config."
        return self.with_cursor(get_cursor())
        
    def with_eod_date(self,eod_date):
        "Set the EOD date to be used in the simulation."
        self.eod_date = eod_date
        return self
        
    def with_default_eod_date(self):
        "Set the EOD date based on config."
        return self.with_eod_date(config()["eod_date"])

    def load_positions(self):
        "Load positions from the database."
        self.positions,sql = query_for_postions(self.eod_date, self.ir_model_id, self.cursor)
        self.sql.append(sql)
        return self

    def load_positions_rr_shock(self,rr_shock):
        "Load positions from the database."
        self.positions,sql = query_for_postions_rr_shock(self.eod_date, self.ir_model_id, rr_shock, self.cursor)
        self.sql.append(sql)
        return self
        
    def with_issuers(self,issuers):
        "Set issuers to be used in the simulation."
        self.issuers=issuers
        self.reset_issuer_simulation_cache()
        return self

    def replace_cnr_by_ccc(self, issuers):
        x = pd.DataFrame(issuers).T.replace(['CNR'], ['CCC'])
        x_dict = x.T.to_dict()
        return {k: x_dict[k] for k in list(issuers.keys())}

    def load_issuers(self):
        "Load issuers from the database."
        issuers,sql=get_issuers(eod_date=self.eod_date,cursor=self.cursor)
        #issuers = self.replace_cnr_by_ccc(issuers)
        logging.debug("Loaded issuers: "+", ".join(issuers.keys()))
        self.sql.append(sql)
        self.reset_issuer_simulation_cache()
        return self.with_issuers(issuers)

    def load_issuers_wMarkit(self):
        "Load issuers from the database and chaning NR to Markit implied if available"
        issuers,sql=get_issuers_wMarkit(eod_date=self.eod_date,cursor=self.cursor)
        logging.debug("Loaded issuers: "+", ".join(issuers.keys()))
        self.sql.append(sql)
        self.reset_issuer_simulation_cache()
        return self.with_issuers(issuers)

    def with_migration_effects(self,migration_effects):
        "Set migration effects to be used in the simulation."
        self.migration_effects = migration_effects
        self.reset_issuer_simulation_cache()
        return self
    
    def load_migration_effects(self):
        "Load migration effects from the database."
        me,sql=query_for_migration_effects(ir_model_id=self.ir_model_id,cursor=self.cursor)
        self.sql.append(sql)
        self.reset_issuer_simulation_cache()
        return self.with_migration_effects(me)

    def calibrate_migration_effects(self,calibration_date=None, years=5, grid=None):
        """
        Create migration effects by calibrating on historical data.

        By default, calibration uses 5 years of data (can be modified by the years parameter).
        Grid is the interpolation grid in a dataframe format. If None (default),
        the grid is loaded from MARS.
        Calibration date is None by default, in wich case the last business day is used.
    
        Args:
            calibration_date        (date):      Date of calibration, historical data before the calibration date are used
            years                   (int):       Number of years to go back from calibration date. Must be integer.
            grid                    (dataframe): Dataframe with SC_ID and SHIFT columns or None for default
    
        Returns:
            (self):   Returns self (builder pattern)
        """
        from core.risk.irm.migration_multiplier import calibrate_as_interpolation
        if grid is None:
            grid, sql = shifts_grid_dataframe(cursor=self.cursor)
            self.sql.append(sql)
        calibration_date=date_format(to_datetime(LAST_BUSINESS_DAY if calibration_date is None else calibration_date))
        interpolation = list(calibrate_as_interpolation(calibration_date=calibration_date,years=years,grid=grid))
        return self.with_migration_effects(interpolation)
        
    def with_ir_model_id(self, ir_model_id):
        "Set IRM model id to be used in the simulation."
        self.ir_model_id = ir_model_id
        self.update_simulator()
        return self
    
    def with_default_ir_model_id(self):
        "Use default interest rate model id from config."
        return self.with_ir_model_id(config()["ir_model_id"])

    @method_cache
    def migration_effects_by_key(self,key):
        "Get all migration effects associated with the given key"
        return [e[1] for e in self.migration_effects if e[0]==key]
        
    def create_migration_mv(self, position_returns_entry, issuer):
        mv = np.zeros(len(self.rating_groups)+1,np.double)

        interpol_prefix = issuer["issuer_type"] + "|" + issuer["rating_grp_id"] + "|"

        for i,to_rating in enumerate(self.rating_groups):
            scenario_value = 0.0

            for migration_effect in self.migration_effects_by_key(interpol_prefix + to_rating):
                scenario_return = position_returns_entry["returns"].get(int(migration_effect["sc_id"]))

                if scenario_return is not None:
                    scenario_value += scenario_return * migration_effect["wgt"]

            mv[i] = scenario_value # migration component

        jtds = position_returns_entry["returns"].get(-1000) # default component

        mv[-1] = 0.0 if jtds is None else jtds

        return mv

    def reset_issuer_simulation_cache(self):
        self.issuers_simulation_cache={}
        return self
    
    def get_issuer_simulation(self, issuer):
        issuer_id = issuer["org_id"]
        s = self.issuers_simulation_cache.get(issuer_id)
        if s is None:
            s=self.simulator.simulate_all_properties(issuer, self.cursor)
            self.issuers_simulation_cache[issuer_id]=self.simulator.simulate_all_properties(issuer, self.cursor)
        return s

    def simulate_all_postions_iter(self):
        logging.info("Simulate all position")
        from tqdm import tqdm
        issuers_not_found=[]
        for i,pr in tqdm(enumerate(self.positions.values())):
            issuer = self.issuers.get(str(int(pr["issuer_org_id"])))
            if i%100==0:
                logging.debug("Simulating position %d/%d"%(i+1,len(self.positions)))
            if issuer is not None:
                migration_mv = self.create_migration_mv(pr,issuer)
                yield dict(self.get_issuer_simulation(issuer), position_returns_entry=pr, migration_mv=migration_mv)
            else:
                issuers_not_found.append(pr["issuer_org_id"])
        if len(issuers_not_found):
            issuers_not_found=sorted(set(issuers_not_found))
            message = "Some position issuers not found: "+ ", ".join(map(str,issuers_not_found))
            logging.warning(message)
        self.issuers_not_found=issuers_not_found


    def simulate_all_postions(self):
        self.simulated_positions=list(self.simulate_all_postions_iter())
        return self



    def export_issuer_events_iter(self,UPDATE_PGM_ID="IRM_IMPACT",tuple_format=False,only_defaults=False):
        from tqdm import tqdm
        for org_id, issuer in tqdm(self.issuers.items()):
            simulation=self.get_issuer_simulation(issuer)["simulation"]
            for i,x in enumerate(simulation):
                try:
                    if x == len(self.rating_groups):
                        NEW_RATING_GRP_ID="D"
                    else:
                        NEW_RATING_GRP_ID=self.rating_groups[x]
                except:
                    logging.error("Unknown event: %ds"%x)
                    NEW_RATING_GRP_ID="? "+str(x)
                if only_defaults and NEW_RATING_GRP_ID!="D":
                    continue
                if tuple_format:
                    yield (
                      self.eod_date,
                      self.ir_model_id,
                      int(org_id),
                      i,
                      int(issuer["rating_id"]),
                      NEW_RATING_GRP_ID,
                      UPDATE_PGM_ID
                      )
                else:
                    yield dict(
                      EOD_DATE=self.eod_date,
                      IR_MODEL_ID=self.ir_model_id,
                      ORG_ID=int(org_id),
                      ENTRY_NO=i,
                      OLD_RATING_ID=int(issuer["rating_id"]),
                      NEW_RATING_GRP_ID=NEW_RATING_GRP_ID,
                      UPDATE_PGM_ID=UPDATE_PGM_ID
                      )
                    
                    
                    
    def export_issuer_events_frame(self,UPDATE_PGM_ID="IRM_IMPACT",tuple_format=False,only_defaults=False):
        from tqdm import tqdm
        d=[]
        for org_id, issuer in tqdm(self.issuers.items()):
            simulation=self.get_issuer_simulation(issuer)["simulation"]
            d.append(simulation)
        return d
#            for i,x in enumerate(simulation):
#                try:
#                    if x == len(self.rating_groups):
#                        NEW_RATING_GRP_ID="D"
#                    else:
#                        NEW_RATING_GRP_ID=self.rating_groups[x]
#                except:
#                    logging.error("Unknown event: %ds"%x)
#                    NEW_RATING_GRP_ID="? "+str(x)
#                if only_defaults and NEW_RATING_GRP_ID!="D":
#                    continue
#                if tuple_format:
#                    yield (
#                      self.eod_date,
#                      self.ir_model_id,
#                      int(org_id),
#                      i,
#                      int(issuer["rating_id"]),
#                      NEW_RATING_GRP_ID,
#                      UPDATE_PGM_ID
#                      )
#                else:
#                    yield dict(
#                      EOD_DATE=self.eod_date,
#                      IR_MODEL_ID=self.ir_model_id,
#                      ORG_ID=int(org_id),
#                      ENTRY_NO=i,
#                      OLD_RATING_ID=int(issuer["rating_id"]),
#                      NEW_RATING_GRP_ID=NEW_RATING_GRP_ID,
#                      UPDATE_PGM_ID=UPDATE_PGM_ID
#                      )
#

        def export_issuer_events_to_sqlite(self, filename, UPDATE_PGM_ID="IRM_IMPACT", table="IR_SC_ISSUER_EVENT",
                                           drop=False, only_defaults=False):
            import sqlite3
            connection = sqlite3.connect(filename)
            cursor = connection.cursor()

            def exe(statement):
                logging.debug(statement)
                return cursor.execute(statement)

            def batch(it):
                b = []
                for x in it:
                    b.append(x)
                    if len(b) == 100:
                        yield b
                        b = []
                if len(b):
                    yield b

            if drop:
                exe("DROP TABLE IF EXISTS %(table)s" % locals())
            exe("""
    CREATE TABLE IF NOT EXISTS %(table)s (
        EOD_DATE          TEXT,
        IR_MODEL_ID       INTEGER,
        ORG_ID            INTEGER,
        ENTRY_NO          INTEGER,
        OLD_RATING_ID     INTEGER,
        NEW_RATING_GRP_ID TEXT,
        UPDATE_PGM_ID     TEXT
    )
    """ % locals())
            connection.commit()
            print("event table created")
            for i, b in enumerate(batch(self.export_issuer_events_iter(UPDATE_PGM_ID=UPDATE_PGM_ID, tuple_format=True,
                                                                       only_defaults=only_defaults))):
                #            exe("""
                # INSERT INTO %(table)s (EOD_DATE, IR_MODEL_ID, ORG_ID, ENTRY_NO, OLD_RATING_ID, NEW_RATING_GRP_ID, UPDATE_PGM_ID)
                # VALUES ('%(EOD_DATE)s', %(IR_MODEL_ID)d, %(ORG_ID)d, %(ENTRY_NO)d, %(OLD_RATING_ID)d, '%(NEW_RATING_GRP_ID)s', '%(UPDATE_PGM_ID)s')"""%d)
                cursor.executemany("""
    INSERT INTO %(table)s (EOD_DATE, IR_MODEL_ID, ORG_ID, ENTRY_NO, OLD_RATING_ID, NEW_RATING_GRP_ID, UPDATE_PGM_ID)
    VALUES (?,?,?,?,?,?,?)""" % locals(), b)

                if i % 100 == 0:
                    # print(i)
                    connection.commit()
            connection.close()

    def export_issuer_events_to_oracle(self, cursor=None, schema=None, UPDATE_PGM_ID="IRM_IMPACT", table="IR_SC_ISSUER_EVENT", drop=False, only_defaults=False, line_param=True):
        """
            It exports a table similar to the production marsp.ir_sc_issuer_event

            Args:
                table                   (string):    Name of the table where the data will be inserted
                drop                    (bool):      If true, if a table already exists it is dropped
                only_defaults           (bool):      If true defaults only are reported
                line_param              (bool):      If line_param = False, data are collected into batches of 100 rows and inserted
                                                     batch by batch. This makes the code faster but could not work on some machines.
                                                     If line_param = True, the rows are inserted line by line.
           """
        if schema is None:
            schema = config()["database_user"].upper()
            if schema[0]!="G":
                raise Exception("Export schema needs to be specified explicitly for database user %s"%(config()["database_user"]))
            
        if cursor is None:
            cursor=self.cursor
            
        def exe(statement):
            logging.debug(statement)
            return cursor.execute(statement)
        
        def batch(it):
            b=[]
            for x in it:
                b.append(x)
                if len(b)==100:
                    yield b
                    b=[]
            if len(b):
                yield b
                
        if drop:
            exe("""
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE %(schema)s.%(table)s';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;
"""%locals())
        try:
            exe("""
CREATE TABLE %(schema)s.%(table)s (
    EOD_DATE           DATE,
    IR_MODEL_ID        NUMBER(3,0),
    ORG_ID             NUMBER(10,0),
    ENTRY_NO           NUMBER(7,0),
    OLD_RATING_ID      VARCHAR2(255),
    NEW_RATING_GRP_ID  VARCHAR2(255),
    UPDATE_PGM_ID      VARCHAR2(255),
    UPDATE_DATETIME    DATE
)        
    """%locals())
        except:
            logging.exception("CREATE table %(schema)s.%(table)s failed"%locals())
        exe("""GRANT SELECT ON %(schema)s.%(table)s TO GMRM_ROLE"""%locals())

        if line_param:
            
            for i, d in enumerate(self.export_issuer_events_iter(UPDATE_PGM_ID=UPDATE_PGM_ID, tuple_format=False, only_defaults=only_defaults)):
                d.update(locals())
                exe("""
    INSERT INTO %(schema)s.%(table)s (EOD_DATE, IR_MODEL_ID, ORG_ID, ENTRY_NO, OLD_RATING_ID, NEW_RATING_GRP_ID, UPDATE_PGM_ID, UPDATE_DATETIME)
    VALUES (to_date('%(EOD_DATE)s', 'yyyy-mm-dd'), %(IR_MODEL_ID)d, %(ORG_ID)d, %(ENTRY_NO)d, %(OLD_RATING_ID)d, '%(NEW_RATING_GRP_ID)s', '%(UPDATE_PGM_ID)s', SYSDATE)"""%d)
    
                if i%10000==0:
                    print("COMMIT %d"%i)
                    try:
                        cursor.commit()
                    except:
                        logging.exception("Commit error in export_issuer_events_to_oracle")
                        traceback.print_exc()
    
            try:
                cursor.commit()
            except:
                logging.exception("Commit error in export_issuer_events_to_oracle")
                traceback.print_exc()
        else:

            for i,b in enumerate(batch(self.export_issuer_events_iter(UPDATE_PGM_ID=UPDATE_PGM_ID,tuple_format=True,only_defaults=only_defaults))):
                 cursor.executemany("""
                 INSERT INTO %(schema)s.%(table)s (EOD_DATE, IR_MODEL_ID, ORG_ID, ENTRY_NO, OLD_RATING_ID, NEW_RATING_GRP_ID, UPDATE_PGM_ID, UPDATE_DATETIME)
                 VALUES (?,?,?,?,?,?,?,SYSDATE)"""%locals(),b)
            try:
                cursor.commit()
            except:
                logging.exception("Commit error in export_issuer_events_to_oracle")
                traceback.print_exc()
                


    def aggregated_measures(self,org_ids):
        logging.debug("Aggregated measures for %d org_ids"%len(org_ids))
        logging.debug("Simulated positions: %d"%len(self.simulated_positions))
        mv=np.zeros(self.simulations,np.double)
        jtd=np.zeros(self.simulations,np.double)
        cs=np.zeros(self.simulations,np.double)
        jtd_count=np.zeros(self.simulations,np.int)
        JTD_ORDINAL=self.JTD_ORDINAL
        for r in self.simulated_positions:
            pr = r["position_returns_entry"]
            if pr["org_id"] in org_ids:
                s=r["simulation"]
                migration_mv=r["migration_mv"]
                issuer_mv = migration_mv[s]
                
                mv+=issuer_mv
                jtd_index = s==JTD_ORDINAL
                cs_index = np.logical_not(jtd_index)
                jtd[jtd_index]+=issuer_mv[jtd_index]
                cs[cs_index]+=issuer_mv[cs_index]
                jtd_count+=jtd_index
                
        return mv,jtd,cs,jtd_count

    def export_scenario_PnLs(self,org_ids,outputFile = "PL.csv" ):
        mv = self.aggregated_measures(org_ids)[0]
        with open(outputFile, "w") as f:
            f.write("\n".join(str(x) for x in mv))

    def aggregated_measures_with_issuer_contributions(self,org_ids):
        logging.debug("Aggregated measures for %d org_ids"%len(org_ids))
        logging.debug("Simulated positions: %d"%len(self.simulated_positions))
        mv=np.zeros(self.simulations,np.double)
        jtd=np.zeros(self.simulations,np.double)
        cs=np.zeros(self.simulations,np.double)
        jtd_count=np.zeros(self.simulations,np.int)
        JTD_ORDINAL=self.JTD_ORDINAL
        issuer_contribution={}
        for r in self.simulated_positions:
            pr = r["position_returns_entry"]
            if pr["org_id"] in org_ids:
                s=r["simulation"]
                migration_mv=r["migration_mv"]
                issuer_mv = migration_mv[s]
                
                jtd_index = s==JTD_ORDINAL
                cs_index = np.logical_not(jtd_index)
                
                issuer_jtd=np.zeros(self.simulations,np.double)
                issuer_jtd[jtd_index]=issuer_mv[jtd_index]

                issuer_cs=np.zeros(self.simulations,np.double)
                issuer_cs[cs_index]=issuer_mv[cs_index]

                issuer_id = str(pr["issuer_org_id"])
                if issuer_id in issuer_contribution:
                    dummy,aggregated_issuer_mv,aggregated_issuer_jtd,aggregated_issuer_cs,aggregated_jtd_count=issuer_contribution[issuer_id]
                    issuer_contribution[issuer_id]=(pr,
                      aggregated_issuer_mv+issuer_mv,
                      aggregated_issuer_jtd+issuer_jtd,
                      aggregated_issuer_cs+issuer_cs,
                      aggregated_jtd_count+jtd_index
                      )
                else:
                    issuer_contribution[issuer_id]=(pr,issuer_mv,issuer_jtd,issuer_cs,np.array(jtd_index,np.int))
                    
                mv+=issuer_mv
                jtd+=issuer_jtd
                cs+=issuer_cs
                jtd_count+=jtd_index

        return [(None,mv,jtd,cs,jtd_count)]+list(issuer_contribution.values())

    def aggregated_measures_with_contributions(self, org_ids, aggregation_key_function = lambda pr:str(pr["issuer_org_id"])):
        logging.debug("Aggregated measures for %d org_ids" % len(org_ids))
        logging.debug("Simulated positions: %d" % len(self.simulated_positions))
        mv = np.zeros(self.simulations, np.double)
        jtd = np.zeros(self.simulations, np.double)
        cs = np.zeros(self.simulations, np.double)
        jtd_count = np.zeros(self.simulations, np.int)
        JTD_ORDINAL = self.JTD_ORDINAL
        contribution = {}
        for r in self.simulated_positions:
            pr = r["position_returns_entry"]
            if pr["org_id"] in org_ids:
                s = r["simulation"]
                migration_mv = r["migration_mv"]
                issuer_mv = migration_mv[s]

                jtd_index = s == JTD_ORDINAL
                cs_index = np.logical_not(jtd_index)

                issuer_jtd = np.zeros(self.simulations, np.double)
                issuer_jtd[jtd_index] = issuer_mv[jtd_index]

                issuer_cs = np.zeros(self.simulations, np.double)
                issuer_cs[cs_index] = issuer_mv[cs_index]

                aggregation_key = aggregation_key_function(pr)
                if aggregation_key in contribution:
                    dummy, aggregation_key, aggregated_issuer_mv, aggregated_issuer_jtd, aggregated_issuer_cs, aggregated_jtd_count = \
                    contribution[aggregation_key]
                    contribution[aggregation_key] = (pr,
                                                      aggregation_key,
                                                      aggregated_issuer_mv + issuer_mv,
                                                      aggregated_issuer_jtd + issuer_jtd,
                                                      aggregated_issuer_cs + issuer_cs,
                                                      aggregated_jtd_count + jtd_index
                                                      )
                else:
                    contribution[aggregation_key] = (pr, aggregation_key, issuer_mv, issuer_jtd, issuer_cs, np.array(jtd_index, np.int))

                mv += issuer_mv
                jtd += issuer_jtd
                cs += issuer_cs
                jtd_count += jtd_index

        return [(None, None, mv, jtd, cs, jtd_count)] + list(contribution.values())

    def calculate_component_VaR_for_risk_calcs(self):
        from tqdm import tqdm
        riskcalc,sql = get_risk_calc(self.cursor)
        logging.info("Calculate component VaR for risk calcs")
        logging.info("risk calcs: %d"%len(riskcalc))
        self.sql.append(sql)
        cons_orgs,sql = cons_org_struct(self.eod_date, self.cursor)
        self.sql.append(sql)
        last_cons_org=None
        for rc in tqdm(riskcalc):
            logging.debug("cons_org_id: %d"%rc["cons_org_id"])
            if last_cons_org!=rc["cons_org_id"]:
                last_cons_org=rc["cons_org_id"]
                try:
                    mv,jtd,cs,jtd_count = self.aggregated_measures(cons_orgs[str(last_cons_org)])
                except KeyError:
                    logging.error("Cons org record missing:"+str(last_cons_org))
                    continue
                index=tail_indices(mv,self.returns_needed)
                total_defaults=np.sum(jtd_count)
                tail_defaults=np.sum(jtd_count[index])
                tail_size=len(index)
                mv_var  = np.average(mv[index])
                jtd_contribution = np.average(jtd[index])
                cs_contribution  = np.average(cs[index])
                jtd_var = tail_average(jtd,self.returns_needed)
                cs_var  = tail_average(cs,self.returns_needed)
            if str(last_cons_org) in cons_orgs:
                risk = dict(SPR=cs_contribution,DFT=jtd_contribution).get(rc["risk_factor_id"])
                yield dict(rc, mvVaR=mv_var, jtdVaR=jtd_var, csVaR=cs_var, risk=risk,
                           jtdContrib=jtd_contribution, csContrib=cs_contribution,
                           total_defaults=total_defaults,tail_defaults=tail_defaults,tail_size=tail_size
                           )
            else:
                logging.warning("Skipping ORG %s - not in cons_org"%last_cons_org)

    def calculate_component_VaR_for_org_node(self,cons_org, aggregation_key_function = lambda pr:str(pr["issuer_org_id"])):
        logging.info("Calculate component VaR for org node %s"%cons_org)
        cons_orgs,sql = cons_org_struct(self.eod_date, self.cursor)
        contributions=self.aggregated_measures_with_contributions(cons_orgs[str(cons_org)],aggregation_key_function=aggregation_key_function)
        _,_,total_mv,total_jtd,total_cs,jtd_count=contributions[0]
        index=tail_indices(total_mv,self.returns_needed)
        total_defaults=np.sum(jtd_count)
        tail_defaults=np.sum(jtd_count[index])
        tail_size=len(index)
        index_default = tail_indices(total_jtd, self.returns_needed)
        for pr, key, mv, jtd, cs, jtd_index in contributions:
            mv_var  = np.average(mv[index])
            jtd_contribution = np.average(jtd[index])
            cs_contribution  = np.average(cs[index])
            jtd_var = tail_average(jtd,self.returns_needed)
            cs_var  = tail_average(cs,self.returns_needed)
            default_var=np.average(jtd[index_default])

            aggregation_id = cons_org if key is None else key
            total = pr is None
            
            logging.debug("Size of mv,jtd,cs:"+str((len(mv),len(jtd),len(cs))))
            
            yield dict(mvVaR=mv_var, jtdVaR=jtd_var, csVaR=cs_var, defaultVaR = default_var,
                       total=total,aggregation_id=aggregation_id,
                       jtdContrib=jtd_contribution, csContrib=cs_contribution,
                       total_defaults=total_defaults,tail_defaults=tail_defaults,tail_size=tail_size,
                       )

    def calculate_component_ES_and_VaR_for_org_node(self, cons_org,
                                                    aggregation_key_function = lambda pr:str(pr["issuer_org_id"]),
                                                    VaR_measure=True, confidence_level=None):
        logging.info("Calculate component VaR for org node %s"%cons_org)
        returns_needed = self.returns_needed if confidence_level is None else int(confidence_level*self.simulations)
        cons_orgs,sql = cons_org_struct(self.eod_date, self.cursor)
        contributions=self.aggregated_measures_with_contributions(cons_orgs[str(cons_org)],aggregation_key_function=aggregation_key_function)
        _,_,total_mv,total_jtd,total_cs,jtd_count=contributions[0]
        if VaR_measure:
            index=np.argsort(total_mv)[:returns_needed]
        else:
            index=tail_indices(total_mv, returns_needed)
        total_defaults=np.sum(jtd_count)
        tail_defaults=np.sum(jtd_count[index])
        tail_size=len(index)
        for pr, key, mv, jtd, cs, jtd_index in contributions:
            if VaR_measure:
                mv_var_contribution  = mv[index[-1]]
                jtd_var_contribution = jtd[index[-1]]
                cs_var_contribution  = cs[index[-1]]
                """
                d.update(dict(
                    mvVaRcontribution  = mv_var_contribution,
                    jtdVaRcontribution = jtd_var_contribution,
                    csVaRcontribution   = cs_var_contribution)
                    )
                """
                d = dict(
                    org_id = key,
                    mvVaRcontribution=mv_var_contribution,
                    jtdVaRcontribution=jtd_var_contribution,
                    csVaRcontribution=cs_var_contribution)

                #jtd_var = tail_average(jtd, returns_needed)
                #cs_var  = tail_average(cs, returns_needed)
                yield d
            else:
                mv_es_contribution  = np.average(mv[index])
                jtd_es_contribution = np.average(jtd[index])
                cs_es_contribution  = np.average(cs[index])

                mv_es  = tail_average(mv,self.returns_needed)
                jtd_es = tail_average(jtd,self.returns_needed)
                cs_es  = tail_average(cs,self.returns_needed)

                aggregation_id = cons_org if key is None else key
                total = pr is None

                d = dict(mvES=mv_es, jtdES=jtd_es, csES=cs_es,
                         total=total,aggregation_id=aggregation_id,
                         mvEScontribution=mv_es_contribution, jtdESContrib=jtd_es_contribution, csESContrib=cs_es_contribution,
                         total_defaults=total_defaults,tail_defaults=tail_defaults,tail_size=tail_size,
                         )
                yield d
            #logging.debug("Size of mv,jtd,cs:"+str((len(mv),len(jtd),len(cs))))

    def calculate_component_ES_and_VaR_for_org_node_with_fix_tail(self, cons_org,
                                                                  aggregation_key_function=lambda pr: str(
                                                                      pr["issuer_org_id"]), VaR_measure=True,
                                                                  fix_tail_index=None, fix_tail_default=None):
        logging.info("Calculate component VaR for org node %s" % cons_org)
        cons_orgs, sql = cons_org_struct(self.eod_date)
        contributions = self.aggregated_measures_with_contributions(cons_orgs[str(cons_org)],
                                                                    aggregation_key_function=aggregation_key_function)
        _, _, total_mv, total_jtd, total_cs, jtd_count = contributions[0]


        if VaR_measure:
            index = np.argsort(total_mv)[:self.returns_needed]
        else:
            index = tail_indices(total_mv, self.returns_needed)
        if VaR_measure:
            index_default = np.argsort(total_jtd)[:self.returns_needed]
        else:
            index_default = tail_indices(total_jtd, self.returns_needed)

        for pr, key, mv, jtd, cs, jtd_index in contributions:
            if VaR_measure:
                mv_var_contribution = mv[index[-1]]
                default_var = jtd[index_default[-1]]

                if (np.any(fix_tail_index) == None) or (np.any(fix_tail_default) == None):
                    d = dict(mvVaRcontribution=mv_var_contribution,
                             defaultVaR=default_var, )
                else:
                    mv_var_contribution_fix = mv[fix_tail_index[-1]]
                    default_var_fix = jtd[fix_tail_default[-1]]
                    d = dict(mvVaRcontribution=mv_var_contribution,
                             defaultVaR=default_var,
                             mvVaRcontribution_fix=mv_var_contribution_fix,
                             defaultVaR_fix=default_var_fix, )

                yield index, index_default, d
            else:
                mv_es = tail_average(mv, self.returns_needed)
                default_es = np.average(jtd[index_default])
                if (np.any(fix_tail_index) == None) or (np.any(fix_tail_default) == None):
                    d = dict(mvES=mv_es,
                             defaultES=default_es, )
                else:
                    mv_es_fix = np.average(mv[fix_tail_index])
                    default_es_fix = np.average(jtd[fix_tail_default])
                    d = dict(mvES=mv_es,
                             defaultES=default_es,
                             mvES_fix=mv_es_fix,
                             defaultES_fix=default_es_fix, )

                yield index, index_default, d



    def calculate_component_VaR_table(self,cons_org, aggregation_key_function = lambda pr:str(pr["issuer_org_id"]), tuple_format=False, default_risk = False, confidence_level=None):
        """
         g49708: This function allows to print the result in the same format as the Mars table marsp.risk_spread_product
         which can be later used for computing impact for example, by rating
         """

        # now no excel formatting needs to be done befroe inserting the rows
        logging.info("Calculate component VaR for org node %s"%cons_org)
        returns_needed = self.returns_needed if confidence_level is None else int(confidence_level * self.simulations)
        cons_orgs,sql = cons_org_struct(self.eod_date, self.cursor)
        contributions=self.aggregated_measures_with_contributions(cons_orgs[str(cons_org)],aggregation_key_function=aggregation_key_function)
        _,_,total_mv,total_jtd,total_cs,jtd_count=contributions[0]
        index=tail_indices(total_mv, returns_needed)
        index_default = tail_indices(total_jtd, returns_needed)
        for pr, key, mv, jtd, cs, jtd_index in contributions:
            jtd_contribution = np.average(jtd[index])
            cs_contribution  = np.average(cs[index])
            default_contribution = np.average(jtd[index_default])
            
            aggregation_id = cons_org if key is None else key

            logging.debug("Size of mv,jtd,cs:"+str((len(mv),len(jtd),len(cs))))

            if tuple_format:
                if aggregation_id == 50004:
                    continue
                else:
                    org_id, product_id, spread_id = [int(item) for item in aggregation_id.split() if item.isdigit()]
                    yield (self.eod_date.strftime('%d-%m-%Y'),'IRC_LIN_CS_50K_1Y',cons_org,spread_id, product_id, cs_contribution) # for sql compatibility
                    yield (self.eod_date.strftime('%d-%m-%Y'), 'IRC_JTD_50K_1Y', cons_org,spread_id, product_id, jtd_contribution) # for sql compatibilit
                    if default_risk:
                        yield (self.eod_date.strftime('%d-%m-%Y'), 'IRC_DEFAULT_RISK_50K_1Y', cons_org, spread_id, product_id,default_contribution)
            else:
                yield dict(eod_date=self.eod_date, risktype='IRC_LIN_CS_50K_1Y', consorg=cons_org, # for sql compatibility
                           aggregation_id=aggregation_id,
                           risk=cs_contribution)
                yield dict(eod_date=self.eod_date, risktype='IRC_JTD_50K_1Y', consorg=cons_org, # for sql compatibility
                           aggregation_id=aggregation_id,
                           risk=jtd_contribution)
                if default_risk:
                    yield dict(eod_date=self.eod_date, risktype='IRC_DEFAULT_RISK_50K_1Y', consorg=cons_org,
                           aggregation_id=aggregation_id,
                           risk=default_contribution)

    def calculate_component_ES_and_VaR_table(self, cons_org,
                                             aggregation_key_function=lambda pr: str(pr["issuer_org_id"]),
                                             VaR_measure=True, tuple_format=False, default_risk=False):
        if VaR_measure:
            print_variable = "Value-at-Risk"
        else:
            print_variable = "Expected Shortfall"
        logging.info("Calculate component " + print_variable + " for org node %s" % cons_org)
        cons_orgs, sql = cons_org_struct(self.eod_date)
        contributions = self.aggregated_measures_with_contributions(cons_orgs[str(cons_org)],
                                                                    aggregation_key_function=aggregation_key_function)
        _, _, total_mv, total_jtd, total_cs, jtd_count = contributions[0]

        if VaR_measure:
            index = np.argsort(total_mv)[:self.returns_needed]
        else:
            index = tail_indices(total_mv, self.returns_needed)

        if VaR_measure:
            index_default = np.argsort(total_jtd)[:self.returns_needed]
        else:
            index_default = tail_indices(total_jtd, self.returns_needed)

        for pr, key, mv, jtd, cs, jtd_index in contributions:
            if VaR_measure:
                jtd_contribution = jtd[index[-1]]
                cs_contribution = cs[index[-1]]
                default_contribution = jtd[index_default[-1]]
            else:
                jtd_contribution = np.average(jtd[index])
                cs_contribution = np.average(cs[index])
                default_contribution = np.average(jtd[index_default])

            aggregation_id = cons_org if key is None else key

            logging.debug("Size of mv,jtd,cs:" + str((len(mv), len(jtd), len(cs))))

            if tuple_format:
                if aggregation_id == 50004:
                    continue
                else:
                    org_id, product_id, spread_id = [int(item) for item in aggregation_id.split() if item.isdigit()]
                    yield (self.eod_date.strftime('%d-%m-%Y'), 'IRC_LIN_CS_50K_1Y', cons_org, spread_id, product_id,
                           cs_contribution)  # for sql compatibility
                    yield (self.eod_date.strftime('%d-%m-%Y'), 'IRC_JTD_50K_1Y', cons_org, spread_id, product_id,
                           jtd_contribution)  # for sql compatibilit
                    if default_risk:
                        yield (
                            self.eod_date.strftime('%d-%m-%Y'), 'IRC_DEFAULT_RISK_50K_1Y', cons_org, spread_id,
                            product_id,
                            default_contribution)
            else:
                yield dict(eod_date=self.eod_date, risktype='IRC_LIN_CS_50K_1Y', consorg=cons_org,
                           # for sql compatibility
                           aggregation_id=aggregation_id,
                           risk=cs_contribution)
                yield dict(eod_date=self.eod_date, risktype='IRC_JTD_50K_1Y', consorg=cons_org,  # for sql compatibility
                           aggregation_id=aggregation_id,
                           risk=jtd_contribution)
                if default_risk:
                    yield dict(eod_date=self.eod_date, risktype='IRC_DEFAULT_RISK_50K_1Y', consorg=cons_org,
                               aggregation_id=aggregation_id,
                               risk=default_contribution)

    def calculate_default_risk_table(self, cons_org, aggregation_key_function=lambda pr: str(pr["issuer_org_id"]),
                                      tuple_format=False, VaR_measure=True, confidence_level=None):
        """
         g50087: This functions allows to print out the component default risk as defined in EGIM:
         For the purposes of this document, default risk in the IRC means the risk charge calculated with the
         institution’s IRC methodology and on the institution’s current IRC portfolio, but without taking the effect
         of rating migrations into account. Thus, default risk in the IRC is a stand-alone risk number and not the
         default risk contribution to the IRC amount.
         """

        # now no excel formatting needs to be done befroe inserting the rows
        logging.info("Calculate component VaR for org node %s" % cons_org)
        returns_needed = self.returns_needed if confidence_level is None else int(confidence_level * self.simulations)
        cons_orgs, sql = cons_org_struct(self.eod_date)
        contributions = self.aggregated_measures_with_contributions(cons_orgs[str(cons_org)],
                                                                    aggregation_key_function=aggregation_key_function)
        _, _, total_mv, total_jtd, total_cs, jtd_count = contributions[0]
        index = total_jtd.argsort()[:returns_needed]
        if VaR_measure:
            index = index[-1]
        for pr, key, mv, jtd, cs, jtd_index in contributions:
            jtd_contribution = np.average(jtd[index])

            aggregation_id = cons_org if key is None else key

            logging.debug("Size of mv,jtd,cs:" + str((len(mv), len(jtd), len(cs))))

            if tuple_format:
                if aggregation_id == 50004:
                    continue
                else:
                    org_id, product_id, spread_id = [int(item) for item in aggregation_id.split() if item.isdigit()]
                    yield (self.eod_date.strftime('%d-%m-%Y'), 'IRC_DEFAULT_RISK_50K_1Y', cons_org, spread_id, product_id,
                           jtd_contribution)  # for sql compatibility
            else:
                yield dict(eod_date=self.eod_date, risktype='IRC_DEFAULT_RISK_50K_1Y', consorg=cons_org,  # for sql compatibility
                           aggregation_id=aggregation_id,
                           risk=jtd_contribution)

    # g53036
    # calculates 99.8% ETL and 99.9% VaR : top of house
    # confidence interval is an input

    def calculate_topofhouse_ETL_and_VaR(self, etl_confidence=99.8, var_confidence=99.9, cons_org=50004, get_scenarios=False):
            logging.info("Calculate ETL and VaR measure for org node %s" % cons_org)
            cons_orgs, sql = cons_org_struct(self.eod_date)
            total_mv, total_jtd, total_cs, jtd_count = self.aggregated_measures(cons_orgs[str(cons_org)])
            returns_needed_etl = int(round(self.simulations * (100 - etl_confidence) / 100))
            returns_needed_var = int(round(self.simulations * (100 - var_confidence) / 100))
            index = tail_indices(total_mv, returns_needed_etl)
            tail_size = len(index)
            sorted_total_mv = sorted(total_mv[index])
            var_risk = sorted_total_mv[returns_needed_var - 1]
            etl_risk = np.average(total_mv[index])
            seed = config().get("seed", RandomSourceBase.RANDOM_SEED)
            random_source = config().get("random_source")

            if get_scenarios:
                x={i:j for (i,j) in zip(index,total_mv[index])}
                import operator
                sorted_x = sorted(x.items(), key=operator.itemgetter(1))
                keys=[item[0] for item in sorted_x]
                yield dict(etl_scenarios=keys, var_scenario=keys[returns_needed_var-1])
            else:
                 yield dict(ETL=etl_risk, VaR=var_risk, tail_size=tail_size, simulations=self.simulations, seed=seed,random_source=random_source)

    def scenario_returns_for_org_node(self,cons_org,UPDATE_PGM_ID="IRM_RETURNS",tuple_format=False):
        from tqdm import tqdm
        from core.utils.date_helper import date_format
        logging.info("Returns for org node %s"%cons_org)
        cons_orgs,sql = cons_org_struct(self.eod_date)
        contributions=self.aggregated_measures(cons_orgs[str(cons_org)])
        mv,jtd,cs,jtd_count=contributions
        tail_index=tail_indices(mv,self.returns_needed)
        org=int(cons_org)
        for i in tqdm(range(len(mv))):
            if tuple_format:
                yield (
                      date_format(self.eod_date),
                      self.ir_model_id,
                      org,
                      i,
                      float(mv[i]),
                      float(jtd[i]),
                      float(cs[i]),
                      int(jtd_count[i]),
                      int(i in tail_index),
                      UPDATE_PGM_ID,
                )
            else:
                yield dict(
                      EOD_DATE=self.eod_date,
                      IR_MODEL_ID=self.ir_model_id,
                      ORG_ID=org,
                      ENTRY_NO=i,
                      TOTAL_RETURN=float(mv[i]),
                      JTD_RETURN=float(jtd[i]),
                      MIGRATION_RETURN=float(cs[i]),
                      JTD_COUNT=int(jtd_count[i]),
                      IN_TAIL=int(i in tail_index),
                      UPDATE_PGM_ID=UPDATE_PGM_ID,
                )

    def bootsrap_convergence(self, grid_points, bootstrap_length=10000, org=50004, ):
        import pandas as pd
        from math import sqrt, log
        from tqdm import tqdm
        df = pd.DataFrame(self.scenario_returns_for_org_node(org))
        full_return = df.iloc[:,8]
        log_error_es=[]
        log_error_var=[]

        for count, items in tqdm(enumerate(grid_points,0)):
            returns_needed_etl=int(round(0.002*grid_points[count]))
            returns_needed_var = int(round(0.001 * grid_points[count]))
            sorted_returns = [sorted(np.random.choice(full_return, size=items, replace=False)) for i in range(bootstrap_length)]
            etl=[np.average(returns[0:returns_needed_etl]) for returns in sorted_returns]
            var = [returns[returns_needed_var - 1] for returns in sorted_returns]
            log_error_es.append(log(np.std(etl)/sqrt(bootstrap_length)))
            log_error_var.append(log(np.std(var)/sqrt(bootstrap_length)))
        return {"log_error_es" : log_error_es, "log_error_var" : log_error_var}

    def export_scenario_returns(self, org=50004, UPDATE_PGM_ID="IRM_RETURNS"):
        import pandas as pd
        df = pd.DataFrame(self.scenario_returns_for_org_node(org, UPDATE_PGM_ID=UPDATE_PGM_ID, tuple_format=False))
        return df

    def export_scenario_returns_to_csv(self,org=50004,output="IRM_SC_RETURNS.csv",UPDATE_PGM_ID="IRM_RETURNS"):
        import pandas as pd
        df = pd.DataFrame(self.scenario_returns_for_org_node(org,UPDATE_PGM_ID=UPDATE_PGM_ID,tuple_format=False))
        df.to_csv(output)

    def export_scenario_returns_to_excel(self,org=50004,output="IRM_SC_RETURNS.xlsx",UPDATE_PGM_ID="IRM_RETURNS"):
        import pandas as pd
        writer = pd.ExcelWriter(output)
        df = pd.DataFrame(self.scenario_returns_for_org_node(org,UPDATE_PGM_ID=UPDATE_PGM_ID,tuple_format=False))
        df.to_excel(writer,"Returns")

    def export_scenario_returns_to_oracle(self,org,cursor=None,schema=None,table="IRM_SC_RETURNS",UPDATE_PGM_ID="IRM_RETURNS",drop=False):
        if schema is None:
            schema = config()["database_user"].upper()
            if schema[0]!="G":
                raise Exception("Export schema needs to be specified explicitly for database user %s"%(config()["database_user"]))
            
        if cursor is None:
            cursor=self.cursor
            
        def exe(statement):
            logging.debug(statement)
            return cursor.execute(statement)
        def batch(it):
            b=[]
            for x in it:
                b.append(x)
                if len(b)==100:
                    yield b
                    b=[]
            if len(b):
                yield b
                
        if drop:
            exe("""
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE %(schema)s.%(table)s';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;
"""%locals())
        try:
            exe("""
CREATE TABLE %(schema)s.%(table)s (
    EOD_DATE           DATE,
    IR_MODEL_ID        NUMBER(3,0),
    ORG_ID             NUMBER(10,0),
    ENTRY_NO           NUMBER(7,0),
    TOTAL_RETURN       NUMBER,
    JTD_RETURN         NUMBER,
    MIGRATION_RETURN   NUMBER,
    JTD_COUNT          NUMBER(10,0),
    IN_TAIL            NUMBER(1,0),
    UPDATE_PGM_ID      VARCHAR2(15),
    UPDATE_DATETIME    DATE
)        
    """%locals())
        except:
            logging.exception("CREATE table %(schema)s.%(table)s failed"%locals())
        exe("""GRANT SELECT ON %(schema)s.%(table)s TO GMRM_ROLE"""%locals())

        for i,b in enumerate(batch(self.scenario_returns_for_org_node(org,UPDATE_PGM_ID=UPDATE_PGM_ID,tuple_format=True))):
#            exe("""
#INSERT INTO %(table)s (EOD_DATE, IR_MODEL_ID, ORG_ID, ENTRY_NO, OLD_RATING_ID, NEW_RATING_GRP_ID, UPDATE_PGM_ID)
#VALUES ('%(EOD_DATE)s', %(IR_MODEL_ID)d, %(ORG_ID)d, %(ENTRY_NO)d, %(OLD_RATING_ID)d, '%(NEW_RATING_GRP_ID)s', '%(UPDATE_PGM_ID)s')"""%d)
            cursor.executemany("""
INSERT INTO %(schema)s.%(table)s (EOD_DATE, IR_MODEL_ID, ORG_ID, ENTRY_NO, TOTAL_RETURN, JTD_RETURN, MIGRATION_RETURN, JTD_COUNT, IN_TAIL, UPDATE_PGM_ID, UPDATE_DATETIME)
VALUES (to_date(?, 'yyyy-mm-dd'),?,?,?,?,?,?,?,?,?,SYSDATE)"""%locals(),b)
        try:
            cursor.commit()
        except:
            logging.exception("Commit error in export_issuer_events_to_oracle")
            traceback.print_exc()

    #g53036 : automates the impact by rating class

    def get_impact_by_rating_class(self,org,cursor=None,schema=None,table="risk_numbers",drop=True):

        if schema is None:
            schema = config()["database_user"].upper()
            if schema[0]!="G":
                raise Exception("Export schema needs to be specified explicitly for database user %s"%(config()["database_user"]))
        if cursor is None:
            cursor=self.cursor

        def exe(statement):
            logging.debug(statement)
            return cursor.execute(statement)

        def batch(it):
            b = []
            for x in it:
                b.append(x)
                if len(b) == 100:
                   yield b
                   b = []
            if len(b):
               yield b

        if drop:
                exe("""
        BEGIN
           EXECUTE IMMEDIATE 'DROP TABLE %(schema)s.%(table)s';
        EXCEPTION
           WHEN OTHERS THEN
              IF SQLCODE != -942 THEN
                 RAISE;
              END IF;
        END;
        """ % locals())
        try:
                exe("""
        CREATE TABLE %(schema)s.%(table)s (
            EOD_DATE DATE,
            RISK_TYPE_ID VARCHAR2(20),
            CONS_ORG_ID NUMBER(10),
            SPREAD_ID NUMBER(12),
            PRODUCT_ID NUMBER(5),
            RISK NUMBER,
            UPDATE_PGM_ID VARCHAR2(15),
            UPDATE_DATETIME DATE
                    )  tablespace info_5      
        """ % locals())
        except:
            logging.exception("CREATE table %(schema)s.%(table)s failed" % locals())
            exe("""GRANT SELECT ON %(schema)s.%(table)s TO GMRM_ROLE""" % locals())

        for i, b in enumerate(batch(self.calculate_component_VaR_table(org, aggregation_key_function = lambda
                            pr: "%(issuer_org_id)s , prod:%(product_id)10s , spread:%(spread_id)10s" % pr, tuple_format=True))):
                cursor.executemany("""
        INSERT INTO %(schema)s.%(table)s (EOD_DATE,RISK_TYPE_ID,CONS_ORG_ID,SPREAD_ID,PRODUCT_ID,RISK)
        VALUES (to_date(?,'dd-mm-yyyy'),?,?,?,?,?)""" % locals(), b)
        try:
                cursor.commit()
        except:
                logging.exception("Commit error in export_issuer_events_to_oracle")
                traceback.print_exc()
        eod_date=config()["eod_date"]
        sql_script=exe("""
                    select * from
                    (
                    select a.eod_date eod_date, a.risk_type_id risk_type_id, 'New Params' type, a.cons_org_id cons_org_id, d.rating_grp_id rating_grp_id, sum(-1*a.risk) risk
                    from %(schema)s.%(table)s  a
                    , marsp.specific_spread_dyn b
                    , marsp.rating_supergrp_rating_grp c
                    , marsp.rating_grp_rating d
                    where
                    a.eod_date= DATE '%(eod_date)s'
                    and a.cons_org_id = 50004
                    and a.eod_date = b.eod_date (+)
                    and a.spread_id = b.spread_id (+)
                    and c.rating_supergrp_id = 'IR'
                    and c.rating_grp_id = d.rating_grp_id
                    and d.rating_id = nvl(b.rating_id,22)
                    group by a.eod_date, a.risk_type_id, a.cons_org_id, d.rating_grp_id
                    )
                    pivot (max(risk) for risk_type_id in ('IRC_LIN_CS_50K_1Y', 'IRC_JTD_50K_1Y'))
                    ;
                    """ % locals())
        rating_impacts=[]
        for i,row in enumerate(sql_script):
            rating_impacts.append(dict(eod_date=row[0], type=row[1],cons_org_id=row[2], rating_grp_id=row[3], IRC_LIN_CS_50K_1Y=row[4],IRC_JTD_50K_1Y=row[5]))
        return rating_impacts

    def with_default_flow(self):
        return (self
        .with_default_cursor()
        .with_default_eod_date()
        .with_default_ir_model_id()
        .load_issuers()
        .load_migration_effects()
        .load_positions()
        .simulate_all_postions()
        )
        
    def with_spread_multiplier_calibration_flow(self,calibration_date=None,years=5,grid=None):
        return (self
        .with_default_cursor()
        .with_default_eod_date()
        .with_default_ir_model_id()
        .load_issuers()
        .calibrate_migration_effects(calibration_date=calibration_date,years=years,grid=grid)
        .load_positions()
        .simulate_all_postions()
        )
# g53036 creates a test class
# enables IRM impact calculations with varying seeds/simulation no.
class Test_Simulations(PositionSimulations):

      def __init__(self):
          self.cursor = None
          self.eod_date = config()["eod_date"]
          self.ir_model_id = config()["ir_model_id"]
          self.rating_groups = config()["rating_groups"]
          self.JTD_ORDINAL = config().get("jtd_ordinal", len(self.rating_groups))
          self.simulations = config()["simulations"]
          self.returns_needed = config()["returns_needed"]
          self.random_source_name = config()["random_source"]
          self.seed = config()["seed"]
          self.issuers_simulation_cache = {}
          self.update_simulator()
          self.positions = None
          self.issuers = None
          self.sql = []


      # overloaded method
      def update_simulator(self):
             self.simulator = IRMSimulator(
             ir_model_id=self.ir_model_id,
             simulations=self.simulations,
             random_source=random_source_with_seed(seed=self.seed,ir_model_id=self.ir_model_id, name=self.random_source_name),
             )
             self.reset_issuer_simulation_cache()


      def with_returns_needed(self, returns_needed):
        "Set the confidence to be used in the simulation."
        self.returns_needed=returns_needed
        return self

      def with_simulations(self, simulations):
          "Set the no. of simulations"
          self.simulations=simulations
          return self

      def with_seed(self, seed):
            "Set a seed to the simulation"
            self.seed = seed
            return self
            
            
      #overloaded method
      def with_ir_model_id(self, ir_model_id):
          "Set interest rate model id to be used in the simulation."
          self.ir_model_id = ir_model_id
          self.update_simulator()
          return self
      # this method is depricated..will be removed soon
      def new_scenario_returns_for_org_node(self, cons_org):
          from tqdm import tqdm
          logging.info("VaR Returns for org node %s" % cons_org)
          cons_orgs, sql = cons_org_struct(self.eod_date)
          contributions = self.aggregated_measures(cons_orgs[str(cons_org)])
          mv, jtd, cs, jtd_count = contributions
          return_list=[float(mv[i]) for i in tqdm(range(len(mv)))]
          sorted_return_list=sorted(return_list)[0:self.returns_needed]
          print(np.average(sorted_return_list))
          return dict(
                 EOD_DATE=self.eod_date,
                 RETURN_LIST=return_list,
                 SORTED_LIST=sorted_return_list
          )

# 2 factor implementation

class TwoFactorPositionSimulations(PositionSimulations):
    def update_simulator(self):
        self.simulator = IRMSimulatorDerived(
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=random_source(ir_model_id=self.ir_model_id, name=self.random_source_name)
        )
        self.reset_issuer_simulation_cache()

class AssetValue(PositionSimulations):
    def update_simulator(self):
        self.simulator = IRMAssetValueSimulator(
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=random_source(ir_model_id=self.ir_model_id, name=self.random_source_name)
        )
        self.reset_issuer_simulation_cache()



class PositionSimulationsMultiplier(PositionSimulations):

    def __init__(self):
        PositionSimulations.__init__(self)
        self.connect = None


    def with_connect(self, conn):
        "Set the database connection to be used in the simulation."
        self.connect = conn
        return self

    def add_key_region_to_issuers(self, issuers, category):
        issuers_df = pd.DataFrame(issuers).T
        if category in ['region', 'REGION']:
            issuers_ctry = load_issuers_country_data(self.connect, self.eod_date)
            ctry_to_region = load_country_to_region_mapping(self.connect)
            df_out = issuers_df.merge(issuers_ctry.rename(columns={'ORG_ID': 'org_id'}), how='left', on='org_id').merge(
                ctry_to_region, how='left', on='COUNTRY_ID')
            df_out['REGION'].replace([np.nan, 'Main Nordic', 'Europe minus nordic'], ['World', 'Europe', 'Europe'],
                                     inplace=True)
            df_out = df_out[list(issuers_df.columns) + ['REGION']].set_index('org_id', drop=False)
        elif category in ['sector', 'SECTOR']:
            industry_mapping = load_gics_to_industry_mapping(self.connect)
            df_out = issuers_df.merge(industry_mapping, how='left', left_on='gics_id', right_on='INDUSTRY_ID')
            df_out = df_out[list(issuers_df.columns) + ['INDUSTRY_NAME']].set_index('org_id', drop=False)
        elif category in ['1Y', '2Y', '5Y', '10Y']:
            return issuers
        else:
            raise Exception('Unknown category. category should be SECTOR or REGION.')
        df_out.index = df_out.index.astype(str, copy=False)
        del df_out.index.name
        return df_out.T.to_dict()

    def load_issuers(self, category):
        "Load issuers from the database."
        issuers,sql=get_issuers(eod_date=self.eod_date,cursor=self.cursor)
        #issuers = self.replace_cnr_by_ccc(issuers)
        logging.debug("Loaded issuers: "+", ".join(issuers.keys()))
        self.sql.append(sql)
        self.reset_issuer_simulation_cache()
        issuers = self.add_key_region_to_issuers(issuers, category)
        return self.with_issuers(issuers)

    def load_migration_effects(self, me):
        "Load migration effects from the database."
        self.reset_issuer_simulation_cache()
        return self.with_migration_effects(me)

    def create_migration_mv(self, position_returns_entry, issuer, category):
        mv = np.zeros(len(self.rating_groups)+1,np.double)
        if category in ['region', 'REGION']:
            interpol_prefix = issuer["REGION"] + "|" + issuer["issuer_type"] + "|" + issuer["rating_grp_id"] + "|"
        elif category in ['sector', 'SECTOR']:
            interpol_prefix = issuer["INDUSTRY_NAME"] +  "|" + issuer["rating_grp_id"] + "|"
        elif category in ['1Y', '2Y', '5Y', '10Y']:
            interpol_prefix = issuer["issuer_type"] + "|" + issuer["rating_grp_id"] + "|"
        else:
            raise Exception('Unknown category. category should be SECTOR or REGION.')

        for i,to_rating in enumerate(self.rating_groups):
            scenario_value = 0.0

            for migration_effect in self.migration_effects_by_key(interpol_prefix + to_rating):
                scenario_return = position_returns_entry["returns"].get(int(migration_effect["sc_id"]))

                if scenario_return is not None:
                    scenario_value += scenario_return * migration_effect["wgt"]

            mv[i] = scenario_value # migration component

        jtds = position_returns_entry["returns"].get(-1000) # default component

        mv[-1] = 0.0 if jtds is None else jtds

        return mv

    def simulate_all_postions_iter(self, category):
        logging.info("Simulate all position")
        from tqdm import tqdm
        issuers_not_found = []
        for i, pr in tqdm(enumerate(self.positions.values())):
            issuer = self.issuers.get(str(int(pr["issuer_org_id"])))
            if i % 100 == 0:
                logging.debug("Simulating position %d/%d" % (i + 1, len(self.positions)))
            if issuer is not None:
                migration_mv = self.create_migration_mv(pr, issuer, category)
                yield dict(self.get_issuer_simulation(issuer), position_returns_entry=pr, migration_mv=migration_mv)
            else:
                issuers_not_found.append(pr["issuer_org_id"])
        if len(issuers_not_found):
            issuers_not_found = sorted(set(issuers_not_found))
            message = "Some position issuers not found: " + ", ".join(map(str, issuers_not_found))
            logging.warning(message)
        self.issuers_not_found = issuers_not_found

    def simulate_all_postions(self, category):
        self.simulated_positions = list(self.simulate_all_postions_iter(category))
        return self


class PositionSimulationsOneFactorStudent(PositionSimulations):
    def __init__(self, gamma_dist = None):
        self.gamma_dist = gamma_dist
        PositionSimulations.__init__(self)


    def update_simulator(self):
        self.simulator = IRMSimulatorOneFactorStudentCopula(
          ir_model_id=self.ir_model_id,
          simulations=self.simulations,
          random_source=random_source(ir_model_id=self.ir_model_id,name=self.random_source_name),
          gamma_dist=self.gamma_dist)
        self.reset_issuer_simulation_cache()


class PositionSimulationsCapitalCentres(PositionSimulations):

    def __init__(self):
        PositionSimulations.__init__(self)
        self.connect = None

    def load_issuers(self):
        "Load issuers from the database."
        issuers,sql=get_issuers_modified(self.eod_date, self.cursor)
        logging.debug("Loaded issuers: "+", ".join(issuers.keys()))
        self.sql.append(sql)
        self.reset_issuer_simulation_cache()
        return self.with_issuers(issuers)


class PositionSimulationsMaturityMismatches(PositionSimulations):

    def __init__(self):
        PositionSimulations.__init__(self)
        self.connect = None

    def get_position_simulation(self, position_returns_entry, issuer):
        return self.simulator.simulate_position_properties(position_returns_entry, issuer, self.cursor)

    def simulate_all_postions_iter(self):
        print(
            "\n/----------------------------------------------------------------------/\n" +
            "              Simulating all positions.                                     " +
            "\n/----------------------------------------------------------------------/\n"
            )
        # Create empty list to populate with positions without 'issuer_org_id'.
        issuers_not_found = []

        # tqdm is used to visualise progress, no impact on loop is expected.
        from tqdm import tqdm

        # self.positions is a dictionary of position returns (pr) dictionaries.
        # In every iteration 'i' becomes a position counter, 'pr' becomes a dictionary with:
        # ORG_ID,
        # POSITION_GRP_ID,
        # SPREAD_ID,
        # PRODUCT_ID,
        # ISSUER_ORG_ID,
        # EFFECT_ID                 (New for this child-class)
        # time_to_maturity          (New for this child-class)
        # KEY                       (A string concatenation of PRODUCT_ID & SPREAD_ID )
        # RETURNS                   (A list of values, per unique record of the other fields).
        for i, pr in tqdm(enumerate(self.positions.values())):
            issuer = self.issuers[str(int(pr['issuer_org_id']))]
            if issuer is not None:
                migration_mv = self.create_migration_mv(pr, issuer)
                yield dict(
                    self.get_position_simulation(pr, issuer),
                    position_returns_entry=pr,
                    migration_mv=migration_mv
                )
            else:
                issuers_not_found.append(pr["issuer_org_id"])
        if len(issuers_not_found) > 0:
            issuers_not_found = sorted(set(issuers_not_found))
            message = "Could not find the issuer_org_id:  " + ", ".join(map(str, issuers_not_found))
            logging.warning(message)
        self.issuers_not_found = issuers_not_found

    # Query with the time-to-maturity is added to the position_returns_entry dictionary
    def load_positions(self):
        """Load returns on effect-level with time-to-maturity from MARSP."""
        print("\n/----------------------------------------------------------------------/")
        print("\n  Loading returns on effect-level with time-to-maturity from MARSP.   \n")
        print("/----------------------------------------------------------------------/\n")
        print("Start: " + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        # self.positions, sql = mm_adjusted_query_for_postions(self.eod_date, self.cursor)
        self.positions = get_returns_by_maturity(self.eod_date, self.ir_model_id, cons_org_id=50004)
        print("End: " + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        return self

# G03641: For custom grid points
class PositionSimulations_custom_grid(PositionSimulations):
    # method to set database user from e.g. config file
    def with_database_user(self, database_user):
        self.database_user = database_user
        return self

    def load_positions(self):
        "Load positions from the database."
        self.positions, sql = query_for_postions_custom_grid(self.eod_date, self.ir_model_id, self.database_user, self.cursor)
        self.sql.append(sql)
        return self

    def load_migration_effects(self, grid_points):
        "Load migration effects from the database."
        # me,sql=query_for_migration_effects_custom_grid(ir_model_id=self.ir_model_id,grid_points=grid_points, cursor=self.cursor)
        me, sql = query_for_migration_effects_custom_grid(ir_model_id=self.ir_model_id, grid_points=grid_points, database_user=self.database_user, cursor=self.cursor)
        self.sql.append(sql)
        self.reset_issuer_simulation_cache()
        return self.with_migration_effects(me)
