# -*- coding: utf-8 -*-
import os
import sys

sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])

import logging
import json
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure

import core.risk.irm.irm_data as irmdata
import core.risk.irm.migration_matrix as mm
from core.risk.irm.config import config, load_config, config_yaml
from core.risk.irm.connection import get_cursor
from core.connection.sqltool import table_id_query_with_sql

from flask import Flask
from flask import make_response
from flask import Blueprint
from cgi import escape

irm_app = Blueprint('irm', __name__)

def css():
    return """
        body{
          font-family:Sans-serif;
          padding-left:10px;
          padding-right:10px;
        }
        h1{
          border-style: none none solid none;
        }
        th {
          foreground-color: #000a73;
          background-color: #c0eeff;
          text-align: left;
          padding-top:4px;
          padding-bottom:4px;
          padding-left:10px;
          padding-right:10px;
        }
        td {
          padding-top:4px;
          padding-bottom:4px;
          foreground-color: #000a73;
          background-color: #eefaffff;
          padding-left:10px;
          padding-right:10px;
        }
        table {
          padding-top:4px;
          padding-bottom:4px;
          padding-left:4px;
          padding-right:4px;
          background-color: #ebf6ff;
          border-color: #000a73;
          margin:10px;
        }
        .sql {
          padding-top:4px;
          padding-bottom:4px;
          padding-left:10px;
          padding-right:10px;
          background-color: #ebf6EE;
          foreground-color: #0000FF;          
          font-family: monospace;
          margin:10px;
        }
        img{
          margin:10px;        
        }
        .float {
          float: left;
        }
        .clear {
          clear: both;
        }
"""


@irm_app.route("/api/irm/overview.html")
def overview_html():
    CSS=css()

    logging.debug("WEBAPI overview")
    s="""<html>
  <head>
    <title>Overview</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Overview</h1>
    <table>      
"""%locals()
    s+="""      <tr><th><a href="/api/irm/config.html">Configuration</a></th><td><a href="/api/irm/config.json">json</a> <a href="/api/irm/config.yaml">yaml</a></td></tr>\n"""
    s+="""      <tr><th><a href="/api/irm/query_for_migration_effects/%(ir_model_id)s.html">Migration effects %(ir_model_id)s</a></th><td><a href="/api/irm/query_for_migration_effects/%(ir_model_id)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th><a href="/api/irm/get_issuers/%(eod_date)s.html">Issuers %(eod_date)s</a></th><td><a href="/api/irm/get_issuers/%(eod_date)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th><a href="/api/irm/get_risk_calc.html">Risk calc</a></th><td><a href="/api/irm/get_risk_calc.json">json</a></td></tr>\n"""
    s+="""      <tr><th><a href="/api/irm/migrations/GOVM_%(ir_model_id)s.html">Migrations Sovereign %(ir_model_id)s</a></th><td><a href="/api/irm/migrations/GOVM_%(ir_model_id)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th><a href="/api/irm/migrations/CORP_%(ir_model_id)s.html">Migrations Corporate %(ir_model_id)s</a></th><td><a href="/api/irm/migrations/CORP_%(ir_model_id)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th>Cons org structure %(eod_date)s</th><td><a href="/api/irm/cons_org_struct/%(eod_date)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th>Positions %(eod_date)s</th><td><a href="/api/irm/query_for_postions/%(eod_date)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th>Gaussian vector 1</th><td><a href="/api/irm/get_gaussian_vector/1.json">json</a></td></tr>\n"""
    s+="""      <tr><th>Systemic vector %(ir_model_id)s</th><td><a href="/api/irm/get_systemic_vector_json/%(ir_model_id)s.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th><a href="/api/irm/sovereign_historical_spreads/2016-09-07_2017-09-07.html">Sovereign historical spreads</a></th><td><a href="/api/irm/sovereign_historical_spreads/2016-09-07_2017-09-07.json">json</a></td></tr>\n"""%config()
    s+="""      <tr><th><a href="/api/irm/corporate_historical_spreads/2016-09-07_2017-09-07.html">Corporate historical spreads</a></th><td><a href="/api/irm/corporate_historical_spreads/2016-09-07_2017-09-07.json">json</a></td></tr>\n"""%config()
    s+="""
    </table>    
  </body>
</html>"""
    return s
    

@irm_app.route("/api/irm/query_for_migration_effects/<ir_model_id>.json")
def query_for_migration_effects_json(ir_model_id):
    logging.debug("WEBAPI call query_for_migration_effects %s (JSON)"%ir_model_id)
    return json.dumps(irmdata.query_for_migration_effects(int(ir_model_id)))

@irm_app.route("/api/irm/query_for_migration_effects/<ir_model_id>.html")
def query_for_migration_effects_html(ir_model_id):
    CSS=css()
    logging.debug("WEBAPI call query_for_migration_effects %s (HTML)"%ir_model_id)
    d, sql = irmdata.query_for_migration_effects(int(ir_model_id))
    sql=escape(sql)
    s="""<html>
  <head>
    <title>query_for_migration_effects %(ir_model_id)s</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Migration effects %(ir_model_id)s</h1>
"""%locals()

    s+="""
    <table>
      <tr><th>Key</th><th>Scenario Id</th><th>Weights</th></tr>
"""%locals()
    for r in d:
        key=r[0]
        weight = r[1]["wgt"]
        sc_id = r[1]["sc_id"]
        s+="      <tr><td>%(key)s</td><td>%(sc_id)s</td><td>%(weight)s</td></tr>\n"%locals()
    s+="""
    </table>    
    <pre class="sql">
    %(sql)s
    </pre>
  </body>
</html>"""%locals()
    return s

@irm_app.route("/api/irm/cons_org_struct/<eod_date>.json")
def cons_org_struct_json(eod_date):
    logging.debug("WEBAPI call cons_org_struct %s (JSON)"%eod_date)
    return json.dumps(irmdata.cons_org_struct(eod_date))
    

@irm_app.route("/api/irm/query_for_postions/<eod_date>.json")
def query_for_postions_json(eod_date):
    logging.debug("WEBAPI call query_for_postions %s (JSON)"%eod_date)
    return json.dumps(irmdata.query_for_postions(eod_date))

@irm_app.route("/api/irm/config.json")
def config_json():
    logging.debug("WEBAPI call config (JSON)")
    return json.dumps(config())

@irm_app.route("/api/irm/config.yaml")
def config_yaml_():
    logging.debug("WEBAPI call config (yaml)")
    return config_yaml()

@irm_app.route("/api/irm/config.html")
def config_html():
    CSS=css()
    logging.debug("WEBAPI call config (HTML)")
    s="""<html>
  <head>
    <title>IRM Config</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>IRM Config</h1>
    <table>      
"""%locals()
    for key,value in sorted(config().items()):
        label =key.replace("_"," ")
        s+="      <tr><th>%(label)s</th><td>%(value)s</td></tr>\n"%locals()
    s+="""
    </table>    
  </body>
</html>"""
    return s

def issuer(org_id):
    return table_id_query_with_sql(get_cursor(),"ORG",datetime_as_date_string=True)(int(org_id))
    
@irm_app.route("/api/irm/issuer/<issuer_id>.json")
def issuer_json(issuer_id):    
    logging.debug("WEBAPI call issuer %s (JSON)"%issuer_id)
    return json.dumps(issuer(issuer_id))

@irm_app.route("/api/irm/get_issuers/<eod_date>.json")
def get_issuers_json(eod_date):
    logging.debug("WEBAPI call get_issuers %s (JSON)"%eod_date)
    return json.dumps(irmdata.get_issuers(eod_date))


@irm_app.route("/api/irm/get_issuers/<eod_date>.html")
def get_issuers_html(eod_date):
    from unidecode import unidecode
    CSS=css()
    logging.debug("WEBAPI call get_issuers %s (HTML)"%eod_date)
    d, sql = irmdata.get_issuers(eod_date)
    sql=escape(sql)    
    s="""<html>
  <head>
    <title>get_issuers %(eod_date)s</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>  
    <h1>Issuers %(eod_date)s</h1>
    <h2>Issuers by type and rating</h2>
    <ul>
"""%locals()
    for issuer_type in sorted(set(x["issuer_type"] for x in d.values())):
        s+="""
        <li>%(issuer_type)s
          <ul>
"""%locals()
        for rating_grp_id in config()["rating_groups"]:
          s+="""
            <li><b>%(rating_grp_id)s:</b>
"""%locals()
          sep=""
          for issuer_id, idio_vec_no in sorted((r["org_id"],r["idio_vec_no"]) for r in d.values() if r["issuer_type"]==issuer_type and r["rating_grp_id"]==rating_grp_id):
              try:
                  name = unidecode(issuer(issuer_id)[0]["name"])
              except:
                  name="???"
              s+=sep+"%(name)s (%(issuer_id)s)"%locals()
              sep=", "
          s+="            </li>\n"
        s+="""
          </ul>
        </li>
"""
            
    s+="""
    </ul>
    <h2>Issuers - raw data</h2>
    <table>
      <tr><th>Issuer ID</th><th>Type</th><th>Rating</th><th>Rating ID</th><th>Org ID</th><th>idio vec no</th></tr>
"""%locals()
    for issuer_id,r in sorted(d.items()):
        rr=dict(issuer_id=issuer_id)
        rr.update(r)
        s+="      <tr><td>%(issuer_id)s</td><td>%(issuer_type)s</td><td>%(rating_grp_id)s</td><td>%(rating_id)s</td><td>%(org_id)s</td><td>%(idio_vec_no)s</td></tr>\n"%rr
    s+=("""
    </table>    
    <pre class="sql">
    %(sql)s
    </pre>
  </body>
</html>"""%locals())
    return s

@irm_app.route("/api/irm/get_risk_calc.json")
def get_risk_calc_json():
    logging.debug("WEBAPI call get_risk_calc (JSON)")
    return json.dumps(irmdata.get_risk_calc())

@irm_app.route("/api/irm/get_risk_calc.html")
def get_risk_calc_html():
    CSS=css()
    logging.debug("WEBAPI call get_risk_calc (HTML)")
    d, sql = irmdata.get_risk_calc()
    sql=escape(sql)    
    s="""<html>
  <head>
    <title>get_risk_calc</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Risk Calc</h1>
    <table>
      <tr><th>Risk type ID</th><th>Risk factor ID</th><th>Cons Org ID</th></tr>
"""%locals()
    for r in d:
        s+="      <tr><td>%(risk_type_id)s</td><td>%(risk_factor_id)s</td><td>%(cons_org_id)s</td></tr>\n"%r
    s+=("""
    </table>    
    <pre class="sql">
    %(sql)s
    </pre>
  </body>
</html>"""%locals())
    return s

@irm_app.route("/api/irm/get_gaussian_vector/<vector_no>.json")
def get_gaussian_vector_json(vector_no):
    logging.debug("WEBAPI call get_gaussian_vector %(vector_no)s (JSON)"%locals())
    return json.dumps(irmdata.get_gaussian_vector(int(vector_no)))

@irm_app.route("/api/irm/get_systemic_vector/<ir_model_id>.json")
def get_systemic_vector_json(ir_model_id):
    logging.debug("WEBAPI call get_systemic_vector %(ir_model_id)s (JSON)"%locals())
    return json.dumps(irmdata.get_systemic_vector(int(ir_model_id)))
    
@irm_app.route("/api/irm/migrations/<issuer_type_id>_<ir_model_id>.json")
def migrations_json(issuer_type_id,ir_model_id):
    logging.debug("WEBAPI call migrations %(issuer_type_id)s - %(ir_model_id)s (JSON)"%locals())
    return json.dumps(mm.migrations(issuer_type_id,int(ir_model_id)))

@irm_app.route("/api/irm/migrations/<issuer_type_id>_<ir_model_id>.html")
def migrations_html(issuer_type_id,ir_model_id):
    CSS=css()
    logging.debug("WEBAPI call migrations %(issuer_type_id)s - %(ir_model_id)s (HTML)"%locals())
    d, sql = mm.migrations(issuer_type_id,int(ir_model_id))
    sql=escape(sql)
    s="""<html>
  <head>
    <title>migrations %(issuer_type_id)s - %(ir_model_id)s</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Migrations %(issuer_type_id)s - %(ir_model_id)s</h1>
    <table>
      <tr><th>Rating</th><th>Rating ID</th><th>Migration Probability</th><th>Attach</th><th>Detach</th></tr>
"""%locals()
    for r in d:
        rr=dict(issuer_type_id=issuer_type_id,ir_model_id=ir_model_id)
        rr.update(r)
        s+="""
        <tr>
          <td>%(rating_grp_id)s</td>
          <td>%(rating_id)s</td>
          <td>%(migr_prob)s</td>
          <td>%(attach)s</td>
          <td>%(detach)s</td>
          <td><a href="/api/irm/migrator/%(issuer_type_id)s_%(rating_id)s_%(ir_model_id)s.html">migrator</a>
              <a href="/api/irm/migrator/%(issuer_type_id)s_%(rating_id)s_%(ir_model_id)s.json">(json)</a></td>
        </tr>\n"""%rr
    s+=("""
    </table>    
    <pre class="sql">
    %(sql)s
    </pre>
  </body>
</html>"""%locals())
    return s

@irm_app.route("/api/irm/migrator/<issuer_type_id>_<rating_id>_<ir_model_id>.json")
def migrator_json(issuer_type_id,rating_id,ir_model_id):
    logging.debug("WEBAPI call migrator %(issuer_type_id)s - %(rating_id)s - %(ir_model_id)s (JSON)"%locals())
    return json.dumps(mm.Migrator.for_rating(issuer_type_id=issuer_type_id,ir_model_id=int(ir_model_id),rating_id=int(rating_id)).to_dict())

@irm_app.route("/api/irm/migrator/<issuer_type_id>_<rating_id>_<ir_model_id>.html")
def migrator_html(issuer_type_id,rating_id,ir_model_id):    
    logging.debug("WEBAPI call migrator %(issuer_type_id)s - %(rating_id)s - %(ir_model_id)s (HTML)"%locals())
    m = mm.Migrator.for_rating(issuer_type_id=issuer_type_id,ir_model_id=int(ir_model_id),rating_id=int(rating_id))
    md=m.to_dict()
    md["CSS"]=css()
    
    md["boundaries"]="\n        <ul>\n"+"".join("          <li>%+14.8f</li>\n"%b for b in m.migrations_boundaries())+"        </ul>\n"
    md["check_migrations"],md["check_migrations_message"]=m.check_migrations()
    try:
        md["pd"]=m.default_probability()
    except:
        md["pd"]="Not known"
    s="""<html>
  <head>
    <title>Migrator %(issuer_type_id)s - %(rating_id)s - %(ir_model_id)s</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Migrator %(issuer_type_id)s - %(rating_id)s - %(ir_model_id)s</h1>
    <table>
      <tr><th>Issuer type</th><td>%(issuer_type_id)s</td></tr>
      <tr><th>Rating ID</th><td>%(rating_id)s</td></tr>
      <tr><th>IR Model ID</th><td>%(ir_model_id)s</td></tr>    
      <tr><th>Probability of Default</th><td>%(pd)s</td></tr>    
      <tr><th>Boundaries</th><td>%(boundaries)s</td></tr>    
      <tr><th>Check</th><td><em>%(check_migrations)s</em> %(check_migrations_message)s</td></tr>    
    </table>
    
    <h2>Migrations</h2>    
    <table class="float">
      <tr><th>Rating</th><th>Rating ID</th><th>Migration Probability</th><th>Attach</th><th>Detach</th></tr>
"""%md
    for r in m.migrations:
        s+="      <tr><td>%(rating_grp_id)s</td><td>%(rating_id)s</td><td>%(migr_prob)s</td><td>%(attach)s</td><td>%(detach)s</td></tr>\n"%r
    s+="""
    </table>    
    <img src="/api/irm/migrator/%(issuer_type_id)s_%(rating_id)s_%(ir_model_id)s.png" class="float"/>
    <pre class="sql clear">
    %(sql)s
    </pre>
  </body>
</html>"""%md
    return s

@irm_app.route("/api/irm/migrator/<issuer_type_id>_<rating_id>_<ir_model_id>.png")
def migrator_png(issuer_type_id,rating_id,ir_model_id):    
    logging.debug("WEBAPI call migrator %(issuer_type_id)s - %(rating_id)s - %(ir_model_id)s (PNG)"%locals())
    m = mm.Migrator.for_rating(issuer_type_id=issuer_type_id,ir_model_id=int(ir_model_id),rating_id=int(rating_id))
    from six import BytesIO

    fig=Figure()
    ax=fig.add_subplot(111)
    fig.set_facecolor("#ebf6ff")
    x=np.linspace(-5,5,100)
    y=np.exp(-x*x*0.5)
    ax.plot(x, y,"g-")
    ax.get_yaxis().set_visible(False)
    for i,r in enumerate(m.migrations):
        for x in (r["attach"],r["detach"]):            
            if x is not None and x>-6 and x<6:
                ax.axvline(x=x,color="b")
        x1=-5 if r["attach"] is None else r["attach"]
        x2=+5 if r["detach"] is None else r["detach"]
        x1=max(-5,x1)
        x2=min(+5,x2)
        x=0.9*x1+0.1*x2
        y=0.1+0.1*i
        ax.text(x,y,r["rating_grp_id"])
    canvas=FigureCanvas(fig)
    png_output = BytesIO()
    canvas.print_png(png_output)
    response=make_response(png_output.getvalue())
    response.headers['Content-Type'] = 'image/png'
    return response

@irm_app.route("/api/irm/sovereign_historical_spreads/<from_date>_<to_date>.json")
def sovereign_historical_spreads_json(from_date,to_date):
    logging.debug("WEBAPI call sovereign_historical_spreads_json %(from_date)s - %(to_date)s (JSON)"%locals())
    return json.dumps(irmdata.historical_spreads(from_date=from_date,to_date=to_date,sovereign=True))

@irm_app.route("/api/irm/corporate_historical_spreads/<from_date>_<to_date>.json")
def corporate_historical_spreads_json(from_date,to_date):
    logging.debug("WEBAPI call corporate_historical_spreads_json %(from_date)s - %(to_date)s (JSON)"%locals())
    return json.dumps(irmdata.historical_spreads(from_date=from_date,to_date=to_date,sovereign=False))

@irm_app.route("/api/irm/sovereign_historical_spreads/<from_date>_<to_date>.html")
def sovereign_historical_spreads_html(from_date,to_date):
    CSS=css()
    logging.debug("WEBAPI call sovereign_historical_spreads_html %(from_date)s - %(to_date)s (HTML)"%locals())
    df, sql = irmdata.historical_spreads_dataframe(from_date=from_date,to_date=to_date,sovereign=True)
    sql=escape(sql)
    s="""<html>
  <head>
    <title>Sovereign Historical Spreads %(from_date)s - %(to_date)s</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Sovereign Historical Spreads %(from_date)s - %(to_date)s</h1>
    """%locals()
    s+=df.to_html()
    s+="""
    <pre class="sql">
    %(sql)s
    </pre>
  </body>
</html>"""%locals()
    return s

@irm_app.route("/api/irm/corporate_historical_spreads/<from_date>_<to_date>.html")
def corporate_historical_spreads_html(from_date,to_date):
    CSS=css()
    logging.debug("WEBAPI call corporate_historical_spreads_html %(from_date)s - %(to_date)s (HTML)"%locals())
    CSS=css()
    df, sql = irmdata.historical_spreads_dataframe(from_date=from_date,to_date=to_date,sovereign=False)
    sql=escape(sql)

    s="""<html>
  <head>
    <title>Corporate Historical Spreads %(from_date)s - %(to_date)s</title>
    <style>
%(CSS)s
    </style>
  </head>
  <body>
    <h1>Corporate Historical Spreads %(from_date)s - %(to_date)s</h1>
    """%locals()
    s+=df.to_html()
    s+="""
    <pre class="sql">
    %(sql)s
    </pre>
  </body>
</html>"""%locals()
    return s

if __name__ == "__main__":
    load_config()
    app=Flask(__name__)
    app.register_blueprint(irm_app)
    app.run(debug=True)