import os
import sys

sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])
import numpy as np
from enum import Enum
import logging
import pandas as pd
from core.utils.date_helper import date_format, to_datetime
from core.risk.irm.irm_data import historical_spreads_dataframe
from core.risk.irm.irm_data import shifts_grid_dataframe
from datetime import date
from tqdm import tqdm

"""
The aim of this module is to estimate the migration multiplier matrices for the IRM model.

5 csv files have to be given as input to the code. These contain data for 5 consecutive years for corporate/sovereign
and are obtained by running the queries below, for the correct year:

-- sovereign
select a.contributiondate, a.ticker, a.avrating, a.spread5y
 from tw_markit_net.markit_comp_convention a
 where a.contributiondate >='15-MAY-14' and a.contributiondate <'15-MAY-15'
   and a.sector='Government' and a.tier='SNRFOR'
   and a.spread5y is not null and a.avrating is not null
 order by a.ticker, a.contributiondate

-- corporate
select a.contributiondate, a.ticker, a.avrating, a.spread5y
   from tw_markit_net.markit_comp_convention a
   where a.contributiondate >='15-MAY-14' and a.contributiondate <'15-MAY-15'
     and a.sector<>'Government' and a.tier='SNRFOR'
     and spread5y is not null and avrating is not null
   order by a.ticker, a.contributiondate;

In order to run the code, you need to give the name of the files as input

Notes:
    Author:

    ======= =========   =========   ====================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ====================================================================================
    1       09mar2017   g46987      Creation of the code
    2       01sep2017   g46987      Massive refactoring in order to turn the code into a module
    3       03sep2020   g02211      Add matrices_as_interpolation_for_mult_multiplier_matrices, a version of 
                                    matrices_as_interpolation in case of multiple multplier matrices by sectors or regions
    ======= =========   =========   ====================================================================================
"""

class Rating(Enum):
    AAA = 0
    AA  = 1
    A   = 2
    BBB = 3
    BB  = 4
    B   = 5
    CCC = 6
    CNR = 7

def array2d_str(arr, elem_format="%s", col_sep=", ", row_sep="\n"):
    return row_sep.join(col_sep.join(elem_format % x for x in row) for row in arr)

def array2d_fill_full(array_lower_triang_transposed):
    size = len(array_lower_triang_transposed) + 1
    array_lower_triang = np.array(array_lower_triang_transposed).T
    res = np.eye(size, dtype=np.double)  # diagonal 1
    # upper triangle
    for i in range(size):
        for j in range(i + 1, size):
            res[i][j] = 1.0 / array_lower_triang_transposed[i][j - 1]

    # lower triangle
    for i in range(1, size):
        for j in range(i):
            res[i][j] = array_lower_triang[i - 1][j]
    return res.tolist()

def make_spread_multiplier_matrix_from_dataframe(df, filter = 'TRUE'):
    if filter == 'TRUE':
        # Filter out rows with repeating spreads indicating missing data
        print('Removing repeating spreads\n')
        df=df[(df.TICKER!=df.TICKER.shift()) | (df.SPREAD5Y!=df.SPREAD5Y.shift())].copy()

    # Convert CC,C and D to CNR
    df.loc[df.AVRATING.isin(["CC","C","D"]),"AVRATING"]="CNR"
    
    # Make geometric average of spreads inside a rating group for each day
    df["AVERAGE_SPREAD"]=np.log(df.SPREAD5Y)
    daily_averages=np.exp(df.groupby(["CONTRIBUTIONDATE","AVRATING"]).AVERAGE_SPREAD.mean()).to_frame()
    daily_averages.reset_index(inplace=True)

    result =np.zeros((len(Rating)-1,len(Rating)-1),np.double)
    missing=[]
    for r1 in Rating:
        if r1==Rating.CNR:
            continue
        ratings1=daily_averages[daily_averages.AVRATING==r1.name]
        dates1=ratings1.CONTRIBUTIONDATE
        for r2 in Rating:
            if r2.value <=r1.value:
                continue
            # Select average spreads v1,v2 for ratings r1 and r2 for common dates
            ratings2=daily_averages[daily_averages.AVRATING==r2.name]
#            if r2==Rating.CNR:
#                print(ratings1)
#                print(ratings2)
            dates2=ratings2.CONTRIBUTIONDATE
            index1=dates1.isin(dates2)
            index2=dates2.isin(dates1)
            assert(np.all(dates1[index1].to_numpy()==dates2[index2].to_numpy()))
            v1=ratings1[index1]["AVERAGE_SPREAD"].to_numpy().reshape((len(ratings1[index1],)))
            v2=ratings2[index2]["AVERAGE_SPREAD"].to_numpy().reshape((len(ratings2[index2],)))

            # calculate the spread change as a geometric average of fractions v1/v2 where v1<v2
            less=v1<v2
            if np.any(less):
                result[r1.value,r2.value-1]=np.exp(np.average(np.log(v1[less]/v2[less])))
            else:
                element="  %3s - %3s"%(r1.name,r2.name)
                if element not in missing:
                    missing.append(element)
            
    if len(missing):        
        logging.warning("No data for spread multiplier elements:\n%s"%(",\n".join(missing)))
    return result
    

def average_spread_multiplier_matrix_alt(matrices):
    m=np.array(matrices)
    index=m>0
    m[index]=np.log(m[index])
    a=np.exp(np.average(m,0))
    a[np.logical_not(np.any(index,0))]=-1
    return a

def average_spread_multiplier_matrix(matrices):
    """It computes the geometric average of of the spreads contained in matrices.
       For example, matrices may contain 5 matrices each being the matrix of spread multipliers estimated from one of 5 years.
       In this case the function will estimate a final matrix where each element is the geometric average of the 5 corresponding elements
       contained in the 5 matrices. If one of the 5 elements is zero, it is ignored.
       
       If all the 5 elements are zero, the multiplier is fixed to -1, indicating we do not have enough data for the estimation.
       """
    m = np.zeros(matrices[0].shape,np.double)

    for i in range(m.shape[0]):
        for j in range(i, m.shape[1]):
            prod = 1.0
            count = 0
            for n,multipliers in enumerate(matrices):
                try:
                    if multipliers[i][j] > 0.0:
                        prod = prod * multipliers[i][j]
                        count = count + 1
                    else:
                        logging.warning("matrix element[%(i)d][%(j)d] of matrix %(n)d is non-positive, therefore ignorred"%locals())                        
                except:
                    logging.exception("matrix element[%(i)d][%(j)d] of matrix %(n)d ignorred"%locals())
            if count > 0:
                m[i][j] = pow(prod, 1.0 / float(count))
            else:
                m[i][j] = -1.0
    return m
    

def usage(args, comment="# "):
    print(comment + "Loading 5 csv files with yearly observations, order is important")
    print(comment + "Processing files: " + ", ".join(args[:5]))

def calibrate_multipliers(calibration_date, sovereign=True, years=5):
    
    logging.info("IRM %s multipliers calibration"%("SOVEREIGN" if sovereign else "CORPORATE"))

    d=to_datetime(calibration_date)
    yearly_matrices=[]
    for i in range(years,0,-1):
        from_date = date_format(to_datetime(date(year=d.year-i,month=d.month,day=d.day)))
        to_date = date_format(to_datetime(date(year=d.year-i+1,month=d.month,day=d.day)))
        logging.info("Period:    %d"%i)
        logging.info("From date: %s"%from_date)
        logging.info("To   date: %s"%to_date)
        df,sql = historical_spreads_dataframe(from_date=from_date,to_date=to_date,sovereign=sovereign)
        logging.debug("Historical spreads fetched using SQL:\n"+sql)
        yearly_matrices.append(make_spread_multiplier_matrix_from_dataframe(df))
        
    return array2d_fill_full(average_spread_multiplier_matrix(yearly_matrices))


def default_interpolation_grid_dataframe():
    return pd.DataFrame(dict(
        SC_ID=[
            10020101,
            10020102,
            10020103,
            10020104,
            10000342,
            10020105,
            10020106,
            10020107,
            10020108,
            10020109,
            10020110,
            10020111,
            10020112,
            10020113,
            10020114],
        SHIFT=[
            0.01,
            0.25,
            0.5,
            0.75,
            1,
            1.25,
            1.5,
            2,
            3,
            5,
            7,
            10,
            15,
            25,
            50]
    ))
    
def spread_multipliers_to_interpolation(matrix, filt=None, sovereign=True, grid=None):
    if grid is None:
        grid = default_interpolation_grid_dataframe()

    shifts_grid=grid["SHIFT"].as_matrix().reshape((len(grid),))
    sc_ids=grid["SC_ID"].as_matrix().reshape((len(grid),))

    issuer_type_id="GOVM" if sovereign else "CORP"
    for r1 in Rating:
        from_rating_grp_id=r1.name
        for r2 in Rating:
            to_rating_grp_id=r2.name
            shift=matrix[r1.value,r2.value]
            gridindex = np.searchsorted(shifts_grid,shift)
            if filt in ['Asia', 'Europe', 'N. America', 'World']:
                key = "%(filt)s|%(issuer_type_id)s|%(from_rating_grp_id)s|%(to_rating_grp_id)s" % locals()
            elif filt in ['FINANCE', 'UNKNOWN', 'PUBLIC', 'MATERIAL', 'TELECOM', 'ENERGY','UTILITY', 'INDUST', 'CONS DSC', 'IT', 'CONS STP', 'HEALTH']:
                key = "%(filt)s|%(from_rating_grp_id)s|%(to_rating_grp_id)s" % locals()
            else:
                key = "%(issuer_type_id)s|%(from_rating_grp_id)s|%(to_rating_grp_id)s" % locals()
            if gridindex==0:
                yield (key,dict(sc_id=sc_ids[0],wgt=1.0))
            elif gridindex>=len(shifts_grid):
                yield (key,dict(sc_id=sc_ids[-1],wgt=1.0))
            else:
                weight=(shift-shifts_grid[gridindex-1])/(shifts_grid[gridindex]-shifts_grid[gridindex-1])
                if weight!=1:
                    yield (key,dict(sc_id=sc_ids[gridindex-1],wgt=1.0-weight))
                if weight!=0:
                    yield (key,dict(sc_id=sc_ids[gridindex],wgt=weight))


def calibrate_as_interpolation(calibration_date, years=5, grid=None):
    for sovereign in (True,False):
        matrix=np.array(calibrate_multipliers(calibration_date=calibration_date, sovereign=sovereign, years=years))
        for r in spread_multipliers_to_interpolation(matrix,sovereign=sovereign, grid=grid):
            yield r

def matrices_as_interpolation(sovereign_matrix, corporate_matrix, grid=None):
    for sovereign, matrix in ((True, sovereign_matrix),(False, corporate_matrix)):
        for r in spread_multipliers_to_interpolation(matrix,sovereign=sovereign, grid=grid):
            yield r

def matrices_as_interpolation_for_mult_multiplier_matrices(files, category, grid=None):
    if category in ['region', 'REGION']:
        list_regions = ['Asia', 'Europe', 'N. America', 'World']
        for reg in list_regions:
            sov = pd.read_excel(files[0], sheet_name=reg, index_col=0)
            corp = pd.read_excel(files[1], sheet_name=reg, index_col=0)
            for sovereign, matrix in ((True, np.array(sov)), (False, np.array(corp))):
                for r in spread_multipliers_to_interpolation(matrix, reg, sovereign=sovereign, grid=grid):
                    yield r
    elif category in ['sector', 'SECTOR']:
        list_sectors = ['FINANCE', 'UNKNOWN', 'PUBLIC', 'MATERIAL', 'TELECOM', 'ENERGY','UTILITY', 'INDUST', 'CONS DSC', 'IT', 'CONS STP', 'HEALTH']
        for sect in list_sectors:
            matrix = np.array(pd.read_excel(files[0], sheet_name=sect, index_col=0))
            for r in spread_multipliers_to_interpolation(matrix, sect, grid=grid):
                yield r
    else:   #if category in ['1Y', '2Y', '5Y', '10Y']:
        sov = pd.read_excel(files[0], sheet_name='sovereign', index_col=0)
        corp = pd.read_excel(files[0], sheet_name='corporate', index_col=0)
        for sovereign, matrix in ((True, np.array(sov)), (False, np.array(corp))):
            for r in spread_multipliers_to_interpolation(matrix, sovereign=sovereign, grid=grid):
                yield r

    #else:
    #    raise Exception('Unknown category. category should be SECTOR or REGION.')


def matrix_to_migration_effect_inserts(matrix, multiplier_id, remark="", sovereign=True, table="MARSP.MIGRATION_EFFECT", term="5Y"):
    for r1 in Rating:
        from_rating_grp_id=r1.name
        for r2 in Rating:
            to_rating_grp_id=r2.name
            shift=matrix[r1.value,r2.value]
            yield """INSERT INTO %(table)s (MULTIPLIER_ID, FROM_RATING_GRP_ID, TO_RATING_GRP_ID, TERM_ID,
REL_QUOTIENT, ABS_QUOTIENT, REMARK, UPDATE_USER_ID, UPDATE_DATETIME)
  VALUES (%(multiplier_id)d, '%(from_rating_grp_id)s', '%(to_rating_grp_id)s', '%(term)s', %(shift)18.15f, NULL, '%(remark)s', user, sysdate)
"""%locals()

def interpolation_to_inserts(interpolation,sovereign_multiplier_id,corporate_multiplier_id,table="MARSP.IR_INTERPOLATION", update_pgm_id="IR_INTERPOL"):
    map_to_multiplier=dict(CORP=corporate_multiplier_id,GOVM=sovereign_multiplier_id)
    for key, r in interpolation:
        issuer_type, from_rating_grp_id, to_rating_grp_id = key.split("|")
        sc_id=r["sc_id"]
        wgt=r["wgt"]
        multiplier_id=map_to_multiplier[issuer_type]
        yield """INSERT INTO %(table)s (MULTIPLIER_ID, FROM_RATING_GRP_ID, TO_RATING_GRP_ID, SC_ID, WGT, UPDATE_PGM_ID, UPDATE_DATETIME)
  VALUES (%(multiplier_id)d, '%(from_rating_grp_id)s', '%(to_rating_grp_id)s', '%(sc_id)s', %(wgt)18.15f, '%(update_pgm_id)s', sysdate)
"""%locals()

class SpreadCalibration:
    """
    Class encapsulating the spread calibration flow.
    Supports:

      - loading spreads,
      - calibrating the spread multiplier matrix,
      - creation of spread multiplier intrerpolation object
      - input/output in various formats    
    """
    
    def __init__(self,cursor=None):
        self.spreads=None
        self.sql=[]
        self.grid=default_interpolation_grid_dataframe()
        self.cursor=cursor
        
    def with_spreads(self,df_list):
        self.spreads=df_list
        return self.concatenate_spreads()

    def load_spreads(self, calibration_date, years=5):
        logging.info("Load spreads")    
        d=to_datetime(calibration_date)
        self.spreads=[]
        for sovereign in [True,False]:
            for i in range(years,0,-1):
                from_date = date_format(to_datetime(date(year=d.year-i,month=d.month,day=d.day)))
                to_date = date_format(to_datetime(date(year=d.year-i+1,month=d.month,day=d.day)))
                logging.info("Period:    %d"%i)
                logging.info("From date: %s"%from_date)
                logging.info("To   date: %s"%to_date)
                df,sql = historical_spreads_dataframe(from_date=from_date,to_date=to_date,sovereign=sovereign, cursor=self.cursor)
                self.sql.append(sql)
                logging.debug("Historical spreads fetched using SQL:\n"+sql)
                self.spreads.append(dict(sovereign=sovereign, dataframe=df, year=d.year-i+1, sql=sql))
        return self.concatenate_spreads()
    
    def with_interpolation_grid(self,grid):
        self.grid=grid
        return self
    
    def load_interpolation_grid(self):
        grid, sql = shifts_grid_dataframe(cursor=self.cursor)
        self.sql.append(sql)
        return self.with_interpolation_grid(grid)
    
    def calibrate_spread_multiplier_matrices(self):
        spreads=self.spreads
        yearly_matrices = [make_spread_multiplier_matrix_from_dataframe(s["dataframe"]) for s in spreads if s["sovereign"]]
        self.sovereign_spread_multiplier_matrix = array2d_fill_full(average_spread_multiplier_matrix(yearly_matrices))
        yearly_matrices = [make_spread_multiplier_matrix_from_dataframe(s["dataframe"]) for s in spreads if not s["sovereign"]]
        self.corporate_spread_multiplier_matrix = array2d_fill_full(average_spread_multiplier_matrix(yearly_matrices))
        return self
    
    def interpolation(self):
        return [x for x in matrices_as_interpolation(self.sovereign_spread_multiplier_matrix,self.corporate_spread_multiplier_matrix,self.grid)]
        
    def concatenate_spreads(self):
        dfs=[]
        for s in self.spreads:
            df=s["dataframe"].copy()
            df["YEAR"]=s["year"]
            df["SOVEREIGN"]=s["sovereign"]
            dfs.append(df)            
        self.spreads_df=pd.concat(dfs)
        self.spreads_original_df=self.spreads_df.copy()
        return self

    def map_CNR_rating(self):
        df=self.spreads_df
        df.loc[df.AVRATING.isin(["CC","C","D"]),"AVRATING"]="CNR"
        return self
    
    def remove_repeating_observations(self):
        df=self.spreads_df
        self.spreads_df=df[(df.TICKER!=df.TICKER.shift()) | (df.SPREAD5Y!=df.SPREAD5Y.shift())]
        return self

    def invalidate_repeating_observations(self):
        df=self.spreads_df
        self.spreads_df.loc[(df.TICKER!=df.TICKER.shift()) | (df.SPREAD5Y!=df.SPREAD5Y.shift()),"SPREAD5Y"]=float("nan")
        return self
        
    def make_relative_returns(self):
        logging.info("make relative returns")
        df2=self.spreads_df
        df1=df2.shift()
        index = (df1.TICKER==df2.TICKER) & (df1.AVRATING==df2.AVRATING) & df1.SPREAD5Y.notnull() & df2.SPREAD5Y.notnull()
        r = (df2.SPREAD5Y - df1.SPREAD5Y)/df2.SPREAD5Y
        self.spreads_df["RETURNS"]=None
        self.spreads_df.loc[index,"RETURNS"]=r[index]
        return self
    
    def correlations_between_names(self,name1,name2):
        df=self.spreads_df        
        index1=(df.TICKER==name1) & (df.RETURNS.notnull())
        index2=(df.TICKER==name2) & (df.RETURNS.notnull())
        dates1=df.CONTRIBUTIONDATE[index1]
        dates2=df.CONTRIBUTIONDATE[index2]
        index1=index1 & df.CONTRIBUTIONDATE.isin(dates2)
        index2=index2 & df.CONTRIBUTIONDATE.isin(dates1)
        assert(index1.sum()==index2.sum())
        v1=df.RETURNS[index1].as_matrix()
        v2=df.RETURNS[index2].as_matrix()
        return np.correlate(v1,v2)[0],index1.sum()
        
    def save_spreadsheets(self,filename="spreads.xlsx"):
        writer = pd.ExcelWriter(filename, engine='xlsxwriter')
        self.spreads_df.to_excel(writer,"Processed")
        self.spreads_original_df.to_excel(writer,"Original Data")
        pd.DataFrame(dict(SQL=self.sql)).to_excel(writer,"SQL")
        writer.save()
        return self

    def save_spreads_to_msgpack(self,filename="spreads.msgpack"):
        self.spreads_df.to_msgpack(filename)
        return self
    def load_spreads_from_msgpack(self,filename="spreads.msgpack"):
        self.spreads_df=pd.read_msgpack(filename)
        return self
    def load_spreads_from_msgpack_or_database(self,calibration_date, years=5,filename="spreads.msgpack"):
        try:
            self.spreads_df=pd.read_msgpack(filename)
        except:
            logging.error("Can't load spreads from %(filename)s"%locals())
            self.load_spreads(calibration_date,years)
            self.save_spreads_to_msgpack(filename)
        return self

    def save_spreadsheets_csv(self,prefix="spreads"):
        self.spreads_df.to_csv("%(prefix)s_processed.csv"%locals())
        self.spreads_original_df.to_csv("%(prefix)s_original.csv"%locals())
        return self

    def calculate_all_correlations_between_names(self):
        names = self.spreads_df.TICKER.unique()
        for name1 in names:
            for name2 in names:
                print("Correlation %(name1)s - %(name2)s"%locals())
                print(self.correlations_between_names(name1,name2))

    def get_common_return_dates(self,sovereign=True):
        index=(self.spreads_df.SOVEREIGN==sovereign) & self.spreads_df.RETURNS.notnull()
        dates = self.spreads_df[index].groupby(["CONTRIBUTIONDATE"]).count()
        dates.reset_index(inplace=True)
        dates.sort_values("RETURNS",inplace=True,ascending=False)
        return list(dates.CONTRIBUTIONDATE)
    
    def get_returns_series_for_dates(self,sovereign=True,dates=None):
        from collections import Counter
        df=self.spreads_df        
        if dates is None:
            dates = sorted(self.get_common_return_dates(sovereign=sovereign))
        names = list(sorted(list(self.spreads_df[self.spreads_df.SOVEREIGN==sovereign].TICKER.unique())))
        r = np.zeros((len(names),len(dates)),np.double)
        r[:,:]=float("nan")
        
        ratings=[]
        observations=[]
        for i, name in enumerate(tqdm(names)):
            df1=df[(df.TICKER==name) & (df.SOVEREIGN==sovereign)]
            rating,rating_observations = Counter(df1.AVRATING).most_common()[0]
            count=0
            ratings.append(rating)
            for k,row in df1.iterrows():
                if row.AVRATING!=rating:
                    continue
                d=row.CONTRIBUTIONDATE
                try:
                    r[i,dates.index(d)]=row.RETURNS
                    count+=1
                except:
                    pass
            observations.append(count)
        return dict(returns=r,dates=dates,tickers=names,ratings=ratings,observations=observations)
    
    def calculate_returns_matrix(self,sovereign=True):
        import json
        issuer_type="sovereign" if sovereign else "corporate"
        logging.info("Returns for %s"%(issuer_type))
        name = "%(issuer_type)s_returns"%locals()
        try:
            with open(name+".json") as f:
                d=json.load(f)            
            self.returns = np.load(name+".npy")
            self.returns_dates=d["dates"]
            self.returns_tickers=d["tickers"]
            self.returns_ratings=d["ratings"]
            self.returns_observations=d["observations"]
        except:
            logging.exception("Can't load %(issuer_type) returns"%locals())
            d=self.get_returns_series_for_dates(sovereign=sovereign)
            self.returns = d["returns"]
            self.returns_dates=d["dates"]
            self.returns_tickers=d["tickers"]
            self.returns_ratings=d["ratings"]
            self.returns_observations=d["observations"]
            with open(name+".json","w") as f:
                del d["returns"]
                json.dump(d,f)
            np.save(name+".npy",self.returns)
        self.sovereign=sovereign
        return self

    def returns_dot_product_matrix(self):
        r=self.returns
        values=np.zeros((len(r),len(r)),np.double)
        counts=np.zeros((len(r),len(r)),np.int16)
        for i in tqdm(range(len(r))):
            v=r[i]*r
            index = np.logical_not(np.isnan(v))
            assert(len(v)==len(r))
            for j in range(len(v)):
                counts[i,j]=np.sum(index[j])
                values[i,j]=np.sum(v[j][index[j]])
        return values,counts

    def calculate_returns_dot_product_matrix(self):
        sovereign=self.sovereign
        issuer_type="sovereign" if sovereign else "corporate"
        logging.info("Returns dot product for %s"%(issuer_type))
        name = "%(issuer_type)s_returns_product"%locals()
        try:
            self.returns_product = np.load(name+".npy")
            self.returns_product_counts = np.load(name+"_counts.npy")
        except:
            logging.exception("Can't load %(issuer_type) returns dot product matrix"%locals())
            self.returns_product, self.returns_product_counts = self.returns_dot_product_matrix()
            np.save(name+".npy",self.returns_product)
            np.save(name+"_counts.npy",self.returns_product_counts)
        return self

    def returns_correlation_matrix(self):
        r=self.returns
        values=np.zeros((len(r),len(r)),np.double)
        counts=np.zeros((len(r),len(r)),np.int16)
        for i in tqdm(range(len(r))):
            v=r[i]*r
            index = np.logical_not(np.isnan(v))
            assert(len(v)==len(r))
            for j in range(len(v)):
                index_j=index[j]
                sigma_i = np.sqrt(np.average(v[i][index_j]))
                sigma_j = np.sqrt(np.average(r[j][index_j]*r[j][index_j]))
                counts[i,j]=np.sum(index[j])
                values[i,j]=np.average(v[j][index[j]])/(sigma_i*sigma_j)
        return values,counts
        
    def calculate_returns_correlation_matrix(self):
        sovereign=self.sovereign
        issuer_type="sovereign" if sovereign else "corporate"
        logging.info("Returns correlations for %s"%(issuer_type))
        name = "%(issuer_type)s_correlations"%locals()
        try:
            self.returns_correlation = np.load(name+".npy")
            self.returns_correlation_counts = np.load(name+"_counts.npy")
        except:
            logging.exception("Can't load %(issuer_type) returns correlation matrix"%locals())
            self.returns_correlation, self.returns_correlation_counts = self.returns_correlation_matrix()
            np.save(name+".npy",self.returns_correlation)
            np.save(name+"_counts.npy",self.returns_correlation_counts)
        return self

    def market_vector_dataframe(self):
        df = (
        self.spreads_df[["CONTRIBUTIONDATE","SOVEREIGN","RETURNS"]][self.spreads_df.RETURNS.notnull()]
        .groupby(["CONTRIBUTIONDATE","SOVEREIGN"])
        .agg(["sum","count"])
        .reset_index())
        df.columns=["CONTRIBUTIONDATE","SOVEREIGN","SUM","COUNT"]
        
        for sovereign in [True,False]:
            index=df.SOVEREIGN==sovereign
            dfi = df[index]
            r=(dfi.SUM*dfi.COUNT).sum()
            r2=(dfi.SUM*dfi.SUM*dfi.COUNT).sum()
            count=dfi.COUNT.sum()
            sigma = np.sqrt(r2/count)
            df.loc[index,"MARKET"]=dfi.SUM/sigma
                   
        #df.to_csv("market.csv")
        #writer = pd.ExcelWriter("market.xlsx", engine='xlsxwriter')
        #df.to_excel(writer,"Market")
        #writer.save()
        return df

    def market_vector_dataframe_with_rating(self):
        market_df = self.market_vector_dataframe()
        df = (
        self.spreads_df[["CONTRIBUTIONDATE","SOVEREIGN","AVRATING","RETURNS"]][self.spreads_df.RETURNS.notnull()]
        .groupby(["CONTRIBUTIONDATE","SOVEREIGN","AVRATING"])
        .agg(["sum","count"])
        .reset_index())
        df.columns=["CONTRIBUTIONDATE","SOVEREIGN","AVRATING","SUM","COUNT"]
        
        for sovereign in [True,False]:
            market_dfi = market_df[market_df.SOVEREIGN==sovereign]
            market = {row[1].CONTRIBUTIONDATE : (row[1].SUM, row[1].COUNT) for row in market_dfi.iterrows()}
            for rating in Rating:
                index = (df.SOVEREIGN==sovereign) & (df.AVRATING == rating.name)
                dfi   = df[index]
                
                count = dfi.COUNT.sum()
                sum_mean = (dfi.SUM*dfi.COUNT).sum()/count
                centered_sum= dfi.SUM-sum_mean
                r2    = (centered_sum*centered_sum*dfi.COUNT).sum()
                sigma = np.sqrt(r2/count)
                mv = [market[x] for x in dfi.CONTRIBUTIONDATE]
                market_sum   = np.array([x[0] for x in mv])
                market_count = np.array([x[1] for x in mv])
                mean = np.sum(market_sum*market_count)/np.sum(market_count)
                market_sum-=mean
                
                market_sigma = np.sqrt(np.sum(market_sum*market_sum*market_count)/np.sum(market_count))
                df.loc[index,"RATING_VECTOR"]=centered_sum/sigma
                df.loc[index,"MARKET_SUM"] = market_sum
                df.loc[index,"MARKET_COUNT"] = market_count
                df.loc[index,"MARKET_VECTOR"]=market_sum/market_sigma

#        df["PRODUCT"]=df.SUM*df.COUNT*df.MARKET_SUM*df.MARKET_COUNT
#        df["SUMCOUNT"]=df.SUM*df.COUNT
#        df["SUM2COUNT"]=df.SUM*df.SUM*df.COUNT
#        df["MARKET_SUMCOUNT"]=df.MARKET_SUM*df.COUNT
#        df["MARKET_SUM2COUNT"]=df.MARKET_SUM*df.MARKET_SUM*df.COUNT
                
        df.to_csv("market_segment.csv")
        writer = pd.ExcelWriter("market_segment.xlsx", engine='xlsxwriter')
        df.to_excel(writer,"Rating Segment")
        writer.save()
        return df
        
    def rating_segments_correlations_to_market_vector(self):
        df=self.market_vector_dataframe_with_rating()
        for sovereign in [True,False]:
            for rating in Rating:
                index = (df.SOVEREIGN==sovereign) & (df.AVRATING == rating.name)
                dfi   = df[index]
                correlation = (dfi.RATING_VECTOR*dfi.COUNT*dfi.MARKET_VECTOR*dfi.MARKET_COUNT).sum()/dfi.COUNT.sum()/dfi.MARKET_COUNT.sum()
                correlation2 = (dfi.RATING_VECTOR*dfi.COUNT*dfi.MARKET_VECTOR*dfi.MARKET_COUNT).sum()/(dfi.COUNT*dfi.MARKET_COUNT).sum()
                correlation3 = (dfi.RATING_VECTOR*dfi.COUNT*dfi.MARKET_VECTOR).sum()/dfi.COUNT.sum()
                correlation4 = (dfi.RATING_VECTOR*dfi.MARKET_COUNT*dfi.MARKET_VECTOR).sum()/dfi.MARKET_COUNT.sum()
                correlation5 = (dfi.RATING_VECTOR*dfi.MARKET_VECTOR).mean()
                print(sovereign,rating.name,correlation,correlation2,correlation3,correlation4,correlation5)
                
    def rating_to_market_correlations(self):
        logging.info("Calcualte correlations of rating groups to market")
        correlations={}
        correlations2={}
        stddev={}
        weights={}
        n=len(self.returns_tickers)
        m=self.returns_correlation
        c=self.returns_correlation_counts
        assert(m.shape == (n,n))
        assert(c.shape == (n,n))
        assert(len(self.returns_tickers) == n)
        assert(len(self.returns_ratings) == n)
        for i,rating in enumerate(tqdm(self.returns_ratings)):
#            print ("%3d %-10s %s"%(i,self.returns_tickers[i],", ".join("%+5.3f"%x for x in m[i])))
#            print ("%3d %-10s %s"%(i,self.returns_ratings[i],", ".join("%6d"%x for x in c[i])))
            w=np.array(c[i])
            w[i]=0
            index=w>0
            try:
                w=w[index]
                sw=np.sum(w)
            except:
                continue
            if sw==0:
                continue
            avg=np.average(m[i][index],weights=w)
            correlations[rating]=correlations.get(rating,0.0)+avg*sw
            correlations2[rating]=correlations.get(rating,0.0)+avg*avg*sw
            weights[rating]=weights.get(rating,0.0)+sw
        for rating in correlations.keys():
            correlations[rating]/=weights[rating]
            correlations2[rating]/=weights[rating]            
            stddev[rating]=np.sqrt(correlations2[rating]-correlations[rating]*correlations[rating])
        print("Correlations")
        for r in Rating:
            print ("%3s %10s +- %10s, %10d"%(r.name,correlations.get(r.name,0),stddev.get(r.name,0),weights.get(r.name,0)))
        print() 
        return self

    def get_returns_series_for_rating(self,rating,sovereign=True):
        df=self.spreads_df
        df=df[(df.SOVEREIGN==sovereign) & (df.AVRATING==rating)]
        dates = list(sorted(list(df.CONTRIBUTIONDATE.unique())))
        names = list(sorted(list(df.TICKER.unique())))
        r = np.zeros((len(names),len(dates)),np.double)
        r[:,:]=float("nan")
        
        for i, name in enumerate(tqdm(names)):
            df1=df[df.TICKER==name]
            for k,row in df1.iterrows():
                d=row.CONTRIBUTIONDATE
                try:
                    r[i,dates.index(d)]=row.RETURNS
                except:
                    pass
        return r,names,dates

    def rating_correlation_variants(self,rating,sovereign=True):
        def normalize(v):
            nv=v-np.average(v)
            nv/=np.std(nv)
            return nv
        r,names,dates=self.get_returns_series_for_rating(rating,sovereign)
        assert(r.shape == (len(names),len(dates)))
        correlations1=[]
        correlations2=[]
        correlations3=[]
        weights1=[]
        weights2=[]
        weights3=[]
        for i in tqdm(range(len(names))):
            ri=r[i]
            index_i=np.isfinite(ri)
            for j in range(i):
                rj=r[j]
                index_j=np.isfinite(rj)
                index=np.logical_and(index_i,index_j)
                n=np.sum(index)
                if n:
                    xi=normalize(ri[index])
                    xj=normalize(rj[index])
                    bibj=np.average(xi*xj)
                    bibj_floored=max(0,bibj)
                    #print (bibj,np.sum(index),np.average(xi),np.std(xi),np.average(xj),np.std(xj))
                    if np.isfinite(bibj) and bibj>=0:
                        correlations1.append(bibj)
                        weights1.append(np.sum(index))
                    if np.isfinite(bibj_floored):
                        correlations2.append(bibj_floored)
                        weights2.append(np.sum(index))
                    if np.isfinite(bibj):
                        correlations3.append(bibj)
                        weights3.append(np.sum(index))
                        
        c=np.sqrt(np.array(correlations1))
        w=np.array(weights1)
        average_correlation1=np.sum(c*w)/np.sum(w)
        average_stddev1=np.sum((c-average_correlation1)*(c-average_correlation1)*w)/np.sum(w)

        c=np.sqrt(np.array(correlations2))
        w=np.array(weights2)
        average_correlation2=np.sum(c*w)/np.sum(w)
        average_stddev2=np.sum((c-average_correlation2)*(c-average_correlation2)*w)/np.sum(w)

        c=np.array(correlations3)
        w=np.array(weights3)
        average_correlation3=np.sum(c*w)/np.sum(w)
        average_stddev3=np.sqrt(np.sum((c-average_correlation3)*(c-average_correlation3)*w)/np.sum(w))
        average_correlation3=np.sqrt(average_correlation3)

        c=np.array(correlations3)        
        w=np.array(weights3)
        w[c<0]=0
        average_correlation4=np.sum(c*w)/np.sum(w)
        average_stddev4=np.sqrt(np.sum((c-average_correlation3)*(c-average_correlation3)*w)/np.sum(w))
        average_correlation4=np.sqrt(average_correlation4)
        
        return average_correlation1, average_stddev1, average_correlation2, average_stddev2, average_correlation3, average_stddev3, average_correlation4, average_stddev4

    def rating_correlation(self,rating,sovereign=True):
        def normalize(v):
            nv=v-np.average(v)
            nv/=np.std(nv)
            return nv
        r,names,dates=self.get_returns_series_for_rating(rating,sovereign)
        assert(r.shape == (len(names),len(dates)))
        correlations=[]
        weights=[]
        for i in tqdm(range(len(names))):
            ri=r[i]
            index_i=np.isfinite(ri)
            for j in range(i):
                rj=r[j]
                index_j=np.isfinite(rj)
                index=np.logical_and(index_i,index_j)
                n=np.sum(index)
                if n:
                    xi=normalize(ri[index])
                    xj=normalize(rj[index])
                    bibj=np.average(xi*xj)
                    if np.isfinite(bibj):
                        correlations.append(bibj)
                        weights.append(np.sum(index))
                        
        c=np.array(correlations)
        w=np.array(weights)
        n=np.sum(w)
        average_c=np.sum(c*w)/n
        beta=np.sqrt(average_c)
        sigma_c=np.sqrt(np.sum((c-average_c)*(c-average_c)*w)/n)
        sigma=sigma_c/(np.sqrt(2)*beta)
        
        return beta,sigma

def aggregate_returns(series_matrix):
    a=np.zeros(series_matrix.shape[1], np.float)
    c=np.zeros(series_matrix.shape[1], np.float)
    for i in range(len(series_matrix)):
        index = np.logical_not(np.isnan(series_matrix[i]))
        v=series_matrix[index]
        v/=np.std(v)
        a[index]+=v
        c[index]+=1
    a[c!=0]/=c[c!=0]
    return a



    #def get_common_observations(self,sovereign=True, number_of_dates=350):
if __name__=="__main__":
    from core.risk.irm.config import configure
    from core.caching.cache_driver import set_cache_mode
    configure()
    set_cache_mode("on")
    
    sc = (
    SpreadCalibration()   
       .load_spreads_from_msgpack_or_database("2016-09-14")
       #.load_interpolation_grid()
       .map_CNR_rating()
       .remove_repeating_observations()
       .make_relative_returns()
       #.rating_segments_correlations_to_market_vector()
       
#       .calculate_returns_matrix(True)
#       .calculate_returns_correlation_matrix()
#       .rating_to_market_correlations()
#       .calculate_returns_matrix(False)
#       .calculate_returns_correlation_matrix()
#       .rating_to_market_correlations()
       #.get_common_return_dates()
       #.get_returns_series_for_dates()
       #.save_spreadsheets_csv("test")
       #.calculate_all_correlations_between_names()
    )
#    for sovereign in [True,False]:
#        for rating in Rating:
#            beta1, sigma1, beta2, sigma2, beta3, sigma3, beta4, sigma4 = sc.rating_correlation_variants(rating.name,sovereign=sovereign)
#            print ("(I  ) %6s %3s %+6.4f +- %10.8f"%(sovereign,rating.name,beta1,sigma1))
#            print ("(II ) %6s %3s %+6.4f +- %10.8f"%(sovereign,rating.name,beta2,sigma2))
#            print ("(III) %6s %3s %+6.4f +- %10.8f"%(sovereign,rating.name,beta3,sigma3))
#            print ("(IV ) %6s %3s %+6.4f +- %10.8f"%(sovereign,rating.name,beta4,sigma4))
#        print()

    for years in [5,6,7,8]:        
        sc = (
        SpreadCalibration()   
           .load_spreads("2016-10-16",years=years)
           .map_CNR_rating()
           .remove_repeating_observations()
           .make_relative_returns()
        )
        
        print("%d years"%years)
        print("==================================================")
        for sovereign in [True,False]:
            for rating in Rating:
                beta, sigma = sc.rating_correlation(rating.name,sovereign=sovereign)
                print ("%6s %3s %14.12f +- %10.8f"%(sovereign,rating.name,beta,sigma))
            print()
        print()
        print()

#    for sovereign,issuer_type in [(True,"GOVM"),(False,"CORP")]:
#        print(issuer_type)
#        sc=(
#            SpreadCalibration()   
#           .load_spreads_from_msgpack_or_database("2016-09-14")
#           .load_interpolation_grid()
#           .map_CNR_rating()
#           .remove_repeating_observations()
#           .make_relative_returns()
#           .calculate_returns_matrix(sovereign)
#           .calculate_returns_correlation_matrix())
#        sc.rating_to_market_correlations()
#        C=sc.returns_correlation
#        Cn=sc.returns_correlation_counts
#        tickers = sc.returns_tickers
#        ratings = sc.returns_ratings
#        columns = ["%-3s %s"%(r,t) for t,r in zip(tickers,ratings)]
#        df = pd.DataFrame(C,columns=columns,index=columns)
#        scolumns = [x[1] for x in sorted((Rating[r].value,c) for c,r in zip(columns,ratings))]
    
        #df=df[scolumns]
        #df=df.reindex(scolumns)
        #writer = pd.ExcelWriter("corr_%s.xlsx"%issuer_type, engine='xlsxwriter')
        #df.to_excel(writer,"Correlations")
        #writer.save()


if __name__=="__main":
    args = sys.argv[1:]

    if (len(args) < 5):
        usage(args)
        print("# Exiting: not enough input files")
        sys.exit(1)

    files = args[:5]
    usage(files)

    spreadMults_prev=[make_spread_multiplier_matrix_from_dataframe(pd.read_csv(f,sep="|",header=0)) for f in files]
    spreadMults=average_spread_multiplier_matrix(spreadMults_prev)
    spreadMults_full = array2d_fill_full(spreadMults)

    # ===================================================================================
    # Output
    # ===================================================================================

    print("#" + ("=" * 74))
    print("# Migration-spread change-multiplier matrix for: " + ", ".join(files))
    print("#" + ("=" * 74))
    print(array2d_str(spreadMults_full, elem_format="%5.2f"))

    print("#" + ("=" * 74))
    print(array2d_str(spreadMults_full, elem_format="%20.17f"))
