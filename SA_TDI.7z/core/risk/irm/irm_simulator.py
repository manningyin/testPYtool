# -*- coding: utf-8 -*-
import logging
# import copy
import os
import sys
from math import sqrt

import numpy as np
import pandas as pd
import scipy.stats as st
from scipy import stats

import core.risk.irm.random_source as rs
from core.risk.irm.config import config
from core.risk.irm.irm_data import get_correlations
# from   core.risk.irm.random_source import random_source_with_seed
from core.risk.irm.migration_matrix import Migrator, MigratorMaturityMismatch, rating_to_group, MigratorCyclicality

dir_path = os.path.dirname(os.path.realpath(__file__))
dir_path = os.path.abspath(os.path.join(dir_path, '..', '..', '..'))
paths = [dir_path, os.path.join(dir_path, 'ad-hoc')]
for p in paths:
    if p not in sys.path:
        sys.path.append(p)
from Ola.irm_data_ola import load_sector_rating_region_mapping


# The variable name asset_value refers to the latent variable used to simulate the copula

def simulate_idiosyncratic(issuer, ir_model_id=None, simulations=None, random_source=None):
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source
    rnds, sql1 = random_source.issuer_series(issuer, simulations=simulations)
    return rnds, sql1


def simulate_systematic(issuer, ir_model_id=None, simulations=None, random_source=None):
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source
    sv, sql2 = random_source.systemic_vector(simulations)
    return sv, sql2


def simulate_asset_value(issuer, correlation, ir_model_id=None, simulations=None, random_source=None):
    simulations = config()["simulations"] if simulations is None else simulations
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source

    complementary_correlation = np.sqrt(1.0 - correlation ** 2)

    rnds, sql1 = random_source.issuer_series(issuer, simulations=simulations)
    sv, sql2 = random_source.systemic_vector(simulations)
    asset_value = rnds * complementary_correlation + sv * correlation
    return asset_value, [sql1, sql2]

def simulate_asset_value_t_student(issuer, correlation, gamma_dist, ir_model_id=None, simulations=None, random_source=None):
    simulations = config()["simulations"] if simulations is None else simulations
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source

    complementary_correlation = np.sqrt(1.0 - correlation ** 2)

    rnds, sql1 = random_source.issuer_series(issuer, simulations=simulations)
    sv, sql2 = random_source.systemic_vector(simulations)
    asset_value = gamma_dist*(rnds * complementary_correlation + sv * correlation)

    return asset_value, [sql1, sql2]


def kstest_p_value(asset_value, ir_model_id=None, random_source=None):
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source
    statistics, p_value = stats.kstest(asset_value, random_source.get_distribution().cdf, N=50000)
    return p_value


def qqplot_r_value(asset_value, ir_model_id=None, random_source=None):
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source
    a, b = stats.probplot(asset_value, dist=random_source.get_distribution())
    return b[2]


def get_IRB_correlation(migrator, low=0.12, high=0.24, exponent=50.0):
    pd = migrator.default_probability()
    weight = (1.0 - np.exp(-exponent * pd)) / (1.0 - np.exp(-exponent))
    return np.sqrt(low * weight + high * (1.0 - weight))


def simulate_asset_value_two_factors(issuer, correlation_firstfactor, correlation_secondfactor, crossfactor_correlation,
                                     ir_model_id=None, simulations=None, random_source=None):
    simulations = config()["simulations"] if simulations is None else simulations
    random_source = rs.random_source(ir_model_id) if random_source is None else random_source

    rnds, sql1 = random_source.issuer_series(issuer, simulations=simulations)
    sv1, sql2 = random_source.systemic_vector(simulations)
    sv2, sql3 = random_source.second_factor(issuer, simulations)
    asset_value = (correlation_firstfactor + crossfactor_correlation * correlation_secondfactor) * sv1 + \
                  (correlation_secondfactor * sqrt(1 - crossfactor_correlation * crossfactor_correlation)) * sv2 + \
                  sqrt(
                      1 - correlation_firstfactor ** 2 - correlation_secondfactor ** 2 - 2 * crossfactor_correlation * correlation_firstfactor * correlation_secondfactor) * rnds
    return asset_value, [sql1, sql2, sql3]


class IRMSimulator(object):
    def __init__(self, ir_model_id=None, simulations=None, random_source=None, lower_bound=0.12, upper_bound=0.24):
        self.ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
        self.random_source = rs.random_source(self.ir_model_id) if random_source is None else random_source
        self.simulations = config()["simulations"] if simulations is None else simulations
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound

    def correlations(self, migrator):
        return get_IRB_correlation(migrator, low=self.lower_bound, high=self.upper_bound)

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id, cursor=cursor)
        self.random_source.cursor = cursor
        asset_value, sql = simulate_asset_value(
            issuer=issuer,
            correlation=self.correlations(migrator),
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type=self.random_source.distribution_type)

    def simulate_all_properties(self, issuer, cursor=None):
        return dict(simulation=self.simulate(issuer, cursor))





class IRMAssetValueSimulator(IRMSimulator):
    def __init__(self, ir_model_id=None, simulations=None, random_source=None, lower_bound=0.12, upper_bound=0.24,
                 gamma_dist=None):
        IRMSimulator.__init__(self, ir_model_id=ir_model_id, simulations=simulations, random_source=random_source,
                              lower_bound=lower_bound, upper_bound=upper_bound)
        self.gamma_dist = gamma_dist

    def simulate_asset_value(self, issuer):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        asset_value, sql = simulate_asset_value(
            issuer=issuer,
            correlation=self.correlations(migrator),
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return asset_value, sql

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        asset_value, sql = self.simulate_asset_value(issuer)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type=self.random_source.distribution_type)

    def simulate_events_with_p_value(self, issuer):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        asset_value, sql = self.simulate_asset_value(issuer)
        ks_pvalue = kstest_p_value(asset_value, ir_model_id=None, random_source=None)
        qq_r_intercept = qqplot_r_value(asset_value, ir_model_id=None, random_source=None)
        return migrator.migrates_to_ordinal_vector(asset_value,
                                                   distribution_type=self.random_source.distribution_type), asset_value, ks_pvalue, qq_r_intercept

    def simulate_all_properties(self, issuer, cursor=None):
        simulation, asset_value, ks_pvalue, qq_r_intercept = self.simulate_events_with_p_value(issuer)
        return dict(simulation=simulation, asset_value=asset_value, ks_p_value=ks_pvalue, qq_r_intercept=qq_r_intercept)


class IRMSimulatorWithUniformShock(IRMSimulator):
    """This is used for stress tests required by TRIM"""

    def __init__(self, ir_model_id=None, simulations=None, random_source=None, lower_bound=0.12, upper_bound=0.24,
                 shock=0.0, floor=0.0, cap=1.0):
        IRMSimulator.__init__(self, ir_model_id, simulations, random_source, lower_bound, upper_bound)
        self.shock = shock
        self.floor = floor
        self.cap = cap

    def stressed_correlations(self, migrator):
        c = get_IRB_correlation(migrator, low=self.lower_bound, high=self.upper_bound) + self.shock
        # return max(min(self.floor,c),self.cap)
        return max(min(c, self.cap), self.floor)
        # return c

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        asset_value, sql = simulate_asset_value(
            issuer=issuer,
            correlation=self.stressed_correlations(migrator),
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type=self.random_source.distribution_type)


class IRMSimulatorWithCorrelationConstant(IRMSimulator):
    "it allows to perform stress test of IRM with constant correlation = 0,1"

    def __init__(self, ir_model_id=None, simulations=None, random_source=None, correlation=0.5):
        self.ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
        self.random_source = rs.random_source(self.ir_model_id) if random_source is None else random_source
        self.simulations = config()["simulations"] if simulations is None else simulations
        self.correlation = correlation

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        asset_value, sql = simulate_asset_value(
            issuer=issuer,
            correlation=self.correlation,
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type=self.random_source.distribution_type)

class IRMSimulatorWithCorrelationConstantStressedPD(IRMSimulatorWithCorrelationConstant):
    "it allows to perform stress test of IRM with constant correlation = 0,5 and with pd floor"

    def __init__(self, ir_model_id=None, simulations=None, random_source=None, shock=0.0, how='abs', correlation=0.5):
        IRMSimulatorWithCorrelationConstant.__init__(self, ir_model_id=ir_model_id, simulations=simulations, random_source=random_source,
                                                     correlation=correlation)
        self.shock = shock
        self.how = how

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating_stressed(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                                ir_model_id=self.ir_model_id, shock=self.shock, how=self.how,
                                                cursor=cursor)
        self.random_source.cursor = cursor
        asset_value, sql = simulate_asset_value(
            issuer=issuer,
            correlation=self.correlation,
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="normal")


class IRMSimulatorWithCorrelationTable(IRMSimulator):
    def __init__(self, ir_model_id=None, simulations=None, random_source=None, correlation_table=None):
        self.ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
        self.random_source = rs.random_source(self.ir_model_id) if random_source is None else random_source
        self.simulations = config()["simulations"] if simulations is None else simulations
        self.correlation_table = correlation_table
        if correlation_table is None:
            self.with_constant_correlations()

    def with_constant_correlations(self, correlation=0.0):
        self.correlation_table = {}
        for issuer_type in ["GOVM", "CORP"]:
            self.correlation_table[issuer_type] = {}
            for rating_id in range(1, 24):
                self.correlation_table[issuer_type][rating_id] = correlation
        return self

    def with_correlations(self, table):
        for issuer_type, rating, correlation in table:
            try:
                rating_ids = [int(rating)]
            except:
                rating_ids = [i for i in range(1, 24) if rating_to_group(i) == rating]
            if not len(rating_ids):
                logging.warning("No rating_ids correspond to rating %s" % rating)
            for rating_id in rating_ids:
                self.correlation_table[issuer_type][rating_id] = float(correlation)
        print("CORRELATION TABLE", self.correlation_table)
        return self

    def correlations(self, migrator):
        return self.correlation_table[migrator.issuer_type_id][migrator.rating_id]


class MarsIRMSimulator(IRMSimulator):
    conversion = dict(
        AAA=0,
        AA=1,
        A=2,
        BBB=3,
        BB=4,
        B=5,
        CCC=6,
        CNR=7,
        D=8
    )

    def __init__(self, ir_model_id=None, simulations=None, eod_date=None, cursor=None):
        from core.risk.irm.connection import get_cursor
        self.ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
        self.simulations = config()["simulations"] if simulations is None else simulations
        self.cursor = get_cursor() if cursor is None else cursor
        self.eod_date = config()["eod_date"] if eod_date is None else eod_date

    def simulate(self, issuer):
        self.cursor.execute("""
SELECT
  ENTRY_NO,
  NEW_RATING_GRP_ID
FROM marsp.IR_SC_ISSUER_EVENT
WHERE
  IR_MODEL_ID= %d
  AND ORG_ID = %d
  AND EOD_DATE = to_date('%s', 'yyyy-mm-dd')
ORDER BY ENTRY_NO ASC        
        """ % (self.ir_model_id, int(issuer["org_id"]), self.eod_date)
                            )
        db_events = self.cursor.fetchall()
        events = np.ones(self.simulations, np.int) * self.conversion.get(issuer["rating_grp_id"], 7)
        for entry_no, rating in db_events:
            events[entry_no - 1] = self.conversion.get(rating, 7)
        return events


# Tamal implements a derived class
class IRMSimulatorDerived(IRMSimulator):

    def simulate(self, issuer, correlation_id=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        correlation_id = config()["correlation_id"] if correlation_id is None else correlation_id
        correlations, correlation_table = get_correlations(correlation_id)
        correlation_first_factor = correlation_table[str("0") + str(issuer["rating_grp_id"])]
        correlation_second_factor = correlation_table[str(int(issuer["gics_id"])) + str(issuer["rating_grp_id"])]
        corr_upper_bound = self.get_bounds_cross_correlations(correlations, correlation_table)

        self.gics_ids = [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 96, 99]
        self.trial_data = [0.62, 0.58, 0.52, 0.20, 0.40, 0.36, 0.10, 0.18, 0.22, 0.61, 0.25, 0.29]
        self.cross_correlations = [min(max(-1, data), corr_upper_bound) for data in self.trial_data]
        self.collected_results = dict(zip(self.gics_ids, self.cross_correlations))

        asset_value, sql = simulate_asset_value_two_factors(
            issuer=issuer,
            # correlation_firstfactor=self.correlations(migrator),
            correlation_firstfactor=correlation_first_factor,
            correlation_secondfactor=correlation_second_factor,
            crossfactor_correlation=self.collected_results[int(issuer["gics_id"])],
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type=self.random_source.distribution_type)

    def get_bounds_cross_correlations(self, correlations, correlation_table):
        max_cross_correlation = 1
        for item in correlations:
            if item['gics_id'] != 0:
                updated_cross_correlation = min(self.get_bound_auxilliary(correlation_table, item),
                                                max_cross_correlation)
                max_cross_correlation = updated_cross_correlation
        return max_cross_correlation

    def get_bound_auxilliary(self, correlation_table, issuer):
        market_factor_loadings = correlation_table["0" + str(issuer["rating_grp_id"])] * correlation_table[
            "0" + str(issuer["rating_grp_id"])]
        sector_factor_loadings = correlation_table[str(int(issuer["gics_id"])) + str(issuer["rating_grp_id"])] * \
                                 correlation_table[str(int(issuer["gics_id"])) + str(issuer["rating_grp_id"])]
        cross_factor_term = correlation_table[str(int(issuer["gics_id"])) + str(issuer["rating_grp_id"])] * \
                            correlation_table["0" + str(issuer["rating_grp_id"])]
        final = float((1 - market_factor_loadings - sector_factor_loadings)) / (2 * cross_factor_term)
        return final


# derived class to represent the credit spread factor copula model introduced November 2019
# class initiated by g47102
# WORK IN PROGRESS


def get_delta(conn, eod_date,
              issuers_data):  # return a matrix of 0 and 1 with columns the issuers and  rows the factors. input ..
    x = load_sector_rating_region_mapping(conn, eod_date, issuers_data).set_index('org_id')
    x = x.replace(['CONS STP', 'CONS DSC', 'Main Nordic', 'Europe minus nordic'],
                  ['CONSSTP', 'CONSDSC', 'Nordic', 'Europe'])
    factor = ['AAA', 'AA', 'A', 'BBB', 'BB', 'B', 'CCC', 'Asia', 'Europe',
              'N. America', 'Nordic', 'World', 'CONSDSC', 'CONSSTP', 'ENERGY',
              'FINANCE', 'HEALTH', 'INDUST', 'IT', 'MATERIAL', 'PUBLIC', 'TELECOM',
              'UTILITY', 'Global']
    y = pd.DataFrame(columns=x.index, index=factor)
    for A in x.index:
        y[A] = np.isin(factor, np.array(x.loc[A])) + 0
    y.loc['Global'] = np.ones(np.shape(y)[1])
    return y


def omega_omegabar(b, global_rsqr, sigma, delta, std_vect):
    x = np.array([])
    z = np.array([])
    cov_matrix = pd.DataFrame(np.matmul(np.diag(std_vect), np.matmul(sigma, np.diag(std_vect))), columns=delta.index,
                              index=delta.index)
    for A in delta.columns:
        s = 0
        for risk_1 in delta.index:
            for risk_2 in delta.index:
                s += delta.loc[risk_1, A] * delta.loc[risk_2, A] * b[risk_1] * b[risk_2] * cov_matrix.loc[
                    risk_1, risk_2]
        x = np.append(x, np.sqrt(global_rsqr / s))
        z = np.append(z, np.sqrt(1 - global_rsqr))

    return np.diag(x), np.diag(z)


def simulation_one_week_horizon_time(sigma, nu, n_samples, global_rsqr, b, delta, std_vect):
    d = np.shape(delta)[1]
    cov_matrix = np.matmul(np.diag(std_vect), np.matmul(sigma, np.diag(std_vect)))
    p = len(sigma)
    L = np.linalg.cholesky(cov_matrix)

    Z = np.matmul(L, np.random.multivariate_normal(np.zeros(p), np.diag(np.ones(p)), n_samples).T).T
    V = np.random.multivariate_normal(np.zeros(d), np.diag(np.ones(d)), n_samples)
    loading = np.matmul(np.diag(np.array(np.array(b))), np.array(delta))
    Omega, Omegabar = omega_omegabar(b, global_rsqr, sigma, delta, std_vect)

    Y = np.matmul(Z, np.matmul(loading, Omega)) + np.matmul(V, Omegabar)
    for i in range(n_samples):
        W = st.chi2.rvs(nu)
        Y[i] = np.sqrt(nu / W) * Y[i]
    Y = np.array(Y, dtype=float)
    return pd.DataFrame(Y, columns=delta.columns)


def simulation_n_weeks_horizon_time(sigma, nu, n_samples, global_rsqr, b, h_time, std_vect, delta):
    d = np.shape(delta)[1]
    Y = pd.DataFrame(np.zeros((n_samples, d)), columns=delta.columns)
    for j in range(h_time):
        X = simulation_one_week_horizon_time(sigma, nu, n_samples, global_rsqr, b, delta, std_vect)
        Y = Y.add(X)
    return Y


def simulate_asset_value_factor_copula(calibration, simulations, issuer,
                                       delta):  # simulations is the number of samples n_samples

    sigma = calibration['correlation matrix']
    nu = calibration['degree of freedom']
    global_rsqr = calibration['r-squared']
    b = calibration['factor loading']
    std_vect = calibration['standard deviation']
    h_time = 1
    Y = simulation_n_weeks_horizon_time(sigma, nu, simulations, global_rsqr, b, h_time, std_vect, delta)
    return Y[issuer]


# def get_sector_rating_region(conn, eod_date, issuers_data):
#   return load_sector_rating_region_mapping(conn, eod_date, issuers_data)


class IRMSimulatorFactorCopula(IRMSimulator):
    def __init__(self, calibration, Y, delta, conn, eod_date, issuers_data):
        super().__init__()
        self.calibration = calibration
        self.delta = delta
        self.Y = Y

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id, cursor=cursor)
        asset_value = self.Y[issuer["org_id"]]
        #return migrator.migrates_to_ordinal_vector_(asset_value)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type=self.random_source.distribution_type)


class IRMSimulatorOneFactorStudentCopula(IRMSimulator):
    def __init__(self, ir_model_id=None, simulations=None, random_source=None, lower_bound=0.12, upper_bound=0.24,
                 gamma_dist=None):
        IRMSimulator.__init__(self, ir_model_id=ir_model_id, simulations=simulations, random_source=random_source,
                              lower_bound=lower_bound, upper_bound=upper_bound)
        self.gamma_dist = gamma_dist

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id, cursor=cursor)
        self.random_source.cursor = cursor
        asset_value, sql = simulate_asset_value_t_student(
            issuer=issuer,
            correlation=self.correlations(migrator),
            gamma_dist=self.gamma_dist,
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="student")


class IRMSimulatorStudentStressedPD(IRMSimulatorOneFactorStudentCopula):
    def __init__(self, ir_model_id=None, simulations=None, random_source=None, lower_bound=0.12, upper_bound=0.24,
                 gamma_dist=None, shock=0.0, how='abs'):
        IRMSimulatorOneFactorStudentCopula.__init__(self, ir_model_id = ir_model_id, simulations = simulations, random_source = random_source,
                                                    lower_bound = lower_bound, upper_bound=upper_bound, gamma_dist=gamma_dist)
        self.shock = shock
        self.how = how


    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating_stressed(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                                ir_model_id=self.ir_model_id, shock=self.shock, how=self.how,
                                                cursor=cursor)
        self.random_source.cursor = cursor
        asset_value, sql = simulate_asset_value_t_student(
            issuer=issuer,
            correlation=self.correlations(migrator),
            gamma_dist=self.gamma_dist,
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="student")



    def simulate_all_properties(self, issuer, cursor=None):
        return dict(simulation=self.simulate(issuer, cursor))


class IRMSimulatorStudentWithCorrelationConstant(object):
    "it allows to perform stress test of IRM with constant correlation = 0,1"

    def __init__(self, ir_model_id=None, simulations=None, random_source=None, gamma_dist = None, correlation=0.5):
        self.ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
        self.random_source = rs.random_source(self.ir_model_id) if random_source is None else random_source
        self.simulations = config()["simulations"] if simulations is None else simulations
        self.gamma_dist = gamma_dist
        self.correlation = correlation

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                       ir_model_id=self.ir_model_id)
        asset_value, sql = simulate_asset_value_t_student(
            issuer=issuer,
            correlation=self.correlation,
            gamma_dist=self.gamma_dist,
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="student")

    def simulate_all_properties(self, issuer, cursor=None):
        return dict(simulation=self.simulate(issuer, cursor))

class IRMSimulatorStudentWithCorrelationConstantStressedPD(IRMSimulatorStudentWithCorrelationConstant):
    "it allows to perform stress test of IRM with constant correlation = 0,5 and with pd floor"

    def __init__(self, ir_model_id=None, simulations=None, random_source=None, gamma_dist = None, shock=0.0, how='abs', correlation=0.5):
        IRMSimulatorStudentWithCorrelationConstant.__init__(self, ir_model_id = ir_model_id, simulations=simulations, random_source=random_source,
                                                            gamma_dist=gamma_dist, correlation=correlation)
        self.shock = shock
        self.how = how

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating_stressed(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                                ir_model_id=self.ir_model_id, shock=self.shock, how=self.how,
                                                cursor=cursor)
        self.random_source.cursor = cursor
        asset_value, sql = simulate_asset_value_t_student(
            issuer=issuer,
            correlation=self.correlation,
            gamma_dist=self.gamma_dist,
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="student")


class IRMSimulatorStressedPD(IRMSimulator):
    def __init__(self, ir_model_id=None, simulations=None, random_source=None, shock=0.0, how='abs'):
        IRMSimulator.__init__(self, ir_model_id, simulations, random_source)
        self.shock = shock
        self.how = how

    def correlations(self, migrator):
        return get_IRB_correlation(migrator, low=self.lower_bound, high=self.upper_bound)

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating_stressed(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                                ir_model_id=self.ir_model_id, shock=self.shock, how=self.how,
                                                cursor=cursor)
        self.random_source.cursor = cursor
        asset_value, sql = simulate_asset_value(
            issuer=issuer,
            correlation=self.correlations(migrator),
            ir_model_id=self.ir_model_id,
            simulations=self.simulations,
            random_source=self.random_source)
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="normal")

    def simulate_all_properties(self, issuer, cursor=None):
        return dict(simulation=self.simulate(issuer, cursor))


class IRMSimulatorFactorCopulaStressedPD(IRMSimulatorFactorCopula):
    def __init__(self, calibration, Y, delta, conn, eod_date, issuers_data, shock=0.0, how='abs'):
        super().__init__(calibration, Y, delta, conn, eod_date, issuers_data)
        self.shock = shock
        self.how = how

    def simulate(self, issuer, cursor=None):
        migrator = Migrator.for_rating_stressed(issuer_type_id=issuer["issuer_type"], rating_id=issuer["rating_id"],
                                                ir_model_id=self.ir_model_id, shock=self.shock, how=self.how,
                                                cursor=cursor)
        asset_value = self.Y[issuer["org_id"]]
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="normal")


class IRMSimulatorMaturityMismatches(IRMSimulator):
    def __init__(self, calibration, y, delta, conn, eod_date, issuers_data, credit_event_thresholds):
        super().__init__()
        self.calibration = calibration
        self.delta = delta
        self.Y = y
        self.migration_tables = credit_event_thresholds

    def simulate(self, issuer, time_to_maturity, cursor=None):
        # Migrator.for_rating_pr() returns a Migrator-instantiated object with data and query in 'migrations' and 'sql'.
        # The data frame migrator.migrations is the table | rating_id | rating_grp_id | attach | detach | migr_prob |.
        migrator = MigratorMaturityMismatch.for_rating(
            issuer_type_id=issuer["issuer_type"],
            rating_id=issuer["rating_id"],
            ir_model_id=self.ir_model_id,
            time_to_maturity=time_to_maturity,
            migration_tables=self.migration_tables,
            cursor=cursor
        )

        # Asset returns for the issuer in scope
        if self.Y is None:
            asset_value, sql = simulate_asset_value(
                issuer=issuer,
                correlation=self.correlations(migrator),
                ir_model_id=self.ir_model_id,
                simulations=self.simulations,
                random_source=self.random_source)
        else:
            asset_value = self.Y[issuer["org_id"]]
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="normal")

    def simulate_position_properties(self, position_returns_entry, issuer, cursor=None):
        return dict(simulation=self.simulate(issuer, position_returns_entry["time_to_maturity"], cursor))

class IRMSimulatorCyclicality(IRMSimulator):
    def __init__(self, calibration, y, delta, conn, eod_date, issuers_data, credit_event_thresholds, run_type):
        super().__init__()
        self.calibration = calibration
        self.delta = delta
        self.Y = y
        self.migration_tables = credit_event_thresholds
        self.run_type = str(run_type)
        
    def simulate(self, issuer, cursor=None):
        # Migrator.for_rating_pr() returns a Migrator-instantiated object with data and query in 'migrations' and 'sql'.
        # The data frame migrator.migrations is the table | rating_id | rating_grp_id | attach | detach | migr_prob |.
        migrator = MigratorCyclicality.for_rating(
            issuer_type_id=issuer["issuer_type"],
            rating_id=issuer["rating_id"],
            ir_model_id=self.ir_model_id,
            run_type=self.run_type,
            migration_tables=self.migration_tables,
            cursor=cursor
        )
        
        # Asset returns for the issuer in scope
        asset_value = self.Y[issuer["org_id"]]
        return migrator.migrates_to_ordinal_vector(asset_value, distribution_type="normal")
        
        