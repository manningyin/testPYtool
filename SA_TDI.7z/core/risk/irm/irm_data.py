# -*- coding: utf-8 -*-
import os
import sys
import pandas as pd
import numpy as np
import pyodbc

from core.connection import database_connect
import core.connection.sqltool as sqltool
from core.risk.irm.connection import get_cursor, sqlite_connection, get_sqlite_cursor
from core.risk.irm.config import config
import logging
from core.utils.date_helper import date_format, to_datetime, to_business_date
from datetime import date, timedelta
from core.caching.cache_driver import json_cache

sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])

rating_interpolations_for_model = sqltool.query_all_with_sql("""
SELECT 
  mm.issuer_type_id,
  ip.from_rating_grp_id,
  ip.to_rating_grp_id,
  ip.sc_id,
  ip.wgt
FROM
  marsp.ir_interpolation ip, 
  marsp.irm_model_matrix mm
WHERE
  mm.ir_model_id = %(ir_model_id)d
  and ip.multiplier_id = mm.multiplier_id
""")


@json_cache
def query_for_migration_effects(ir_model_id, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    interpolations, sql = rating_interpolations_for_model(cursor=cursor, ir_model_id=ir_model_id)
    logging.debug("query_for_migration_effects SQL\n" + sql)
    migrations = [
        ("%(issuer_type_id)s|%(from_rating_grp_id)s|%(to_rating_grp_id)s" % r, dict(sc_id=r["sc_id"], wgt=r["wgt"])) for
        r in interpolations]
    return migrations, sql


################################### THIS PART IS RELATED TO THE CUSTOMIZED GRID ########################################
# G03641

# Function to create the table sc_grp_sc for the customized grid
def create_sc_grp_sc(grid_points, database_user):
    sql_drop = f"""
    drop table {database_user}.sc_grp_sc
    """
    sql_create = f"""
    create table {database_user}.sc_grp_sc tablespace USERS as
    select *
    from marsp.sc_grp_sc
    where sc_grp_id = 29
          and 1=2
    """
    print("Table 'sc_grp_sc' created in USERS tablespace for:", database_user)
    shift_id_dictionary = {
        0.01: 10020101, 0.25: 10020102, 0.5: 10020103, 0.75: 10020104, 1: 10000342, 1.25: 10020105,
        1.5: 10020106, 2: 10020107, 3: 10020108, 5: 10020109, 7: 10020110, 10: 10020111, 15: 10020112,
        25: 10020113, 50: 10020114
        }
    sc_grp_ids = [shift_id_dictionary[grid_point] for grid_point in grid_points]
    sqllist_insert = [f"""
    insert into {database_user}.sc_grp_sc values
    (29,{id},null,user,sysdate)""" for id in sc_grp_ids]
    
    # Executing the queries.
    c = pyodbc.connect(database_connect.get_string('INFOP'))
    cursor = c.cursor()
    try:
        cursor.execute(sql_drop)
    except pyodbc.ProgrammingError:
        pass
    cursor.execute(sql_create)
    for item in sqllist_insert:
        cursor.execute(item)
    cursor.commit()
    c.close()


# Creating table ir_interpolation for the customized grid case
def create_ir_interpolation(database_user):
    sql_drop = f"""
    drop table {database_user}.ir_interpolation
    """
    
    sql_create = f"""
        create table {database_user}.ir_interpolation tablespace USERS as
        select * 
        from marsp.ir_interpolation
        where 1=2
        """
    print("Table 'ir_interpolation' created in USERS tablespace for:", database_user)
    sql_insert1 = f"""
        insert into {database_user}.ir_interpolation 
        with ord as (
            select a.sc_id,
                   c.shift/100 + 1 shift, 
                   row_number() over (order by c.shift) num
            from {database_user}.sc_grp_sc a,
                 marsp.sc b,
                 marsp.sc_spread_shift c
            where a.sc_grp_id = 29
              and a.sc_id = b.sc_id
              and b.sc_spread_id = c.sc_spread_id
            order by shift
            ), intervals as (
            select d.sc_id lower_sc_id,
                   e.sc_id upper_sc_id,
                   d.shift lower_shift,
                   e.shift upper_shift
            from ord d, 
                 ord e
            where e.num = d.num + 1
            ), relevant_shifts as (            
            select f.multiplier_id,
                   f.from_rating_grp_id,
                   f.to_rating_grp_id,
                   f.rel_quotient
            from marsp.migration_effect f
            where  f.term_id = '5Y'            
            )
            select g.multiplier_id,
                   g.from_rating_grp_id,
                   g.to_rating_grp_id,
                   h.lower_sc_id sc_id,
                   (upper_shift - rel_quotient) / (upper_shift - lower_shift) wgt,
                   'IR_INTERPOL' update_pgm_id,
                   sysdate update_datetime
            from relevant_shifts g,
                 intervals       h
            where g.rel_quotient >= h.lower_shift
              and g.rel_quotient  < h.upper_shift
            union all
            select g.multiplier_id,
                   g.from_rating_grp_id,
                   g.to_rating_grp_id,
                   h.upper_sc_id,
                   (rel_quotient - lower_shift) / (upper_shift - lower_shift) wgt,
                   'IR_INTERPOL' update_pgm_id,
                   sysdate update_datetime
            from relevant_shifts g,
                 intervals       h
            where g.rel_quotient > h.lower_shift
              and g.rel_quotient < h.upper_shift
            order by 1,2
            """
    
    sql_insert2 = f"""
        insert into {database_user}.ir_interpolation 
        with ord as (
            select a.sc_id,
                   c.shift/100 + 1 shift, 
                   row_number() over (order by c.shift) num
            from {database_user}.sc_grp_sc a,
                 marsp.sc b,
                 marsp.sc_spread_shift c
            where a.sc_grp_id = 29
              and a.sc_id = b.sc_id
              and b.sc_spread_id = c.sc_spread_id
            order by shift
            ), extrema as (
            select distinct first_value(d.sc_id) over (order by d.num asc) first_sc_id
                          , min(d.shift) over ()  first_shift
                          , first_value(d.sc_id) over (order by d.num desc) last_sc_id
                          , max(d.shift) over ()  last_shift
            from ord d
            ), relevant_shifts as (
            select f.multiplier_id,
                   f.from_rating_grp_id,
                   f.to_rating_grp_id,
                   f.rel_quotient
            from marsp.migration_effect f
            where f.term_id = '5Y'
            )
            select g.multiplier_id,
                   g.from_rating_grp_id,
                   g.to_rating_grp_id,
                   case 
                    when g.rel_quotient < h.first_shift then h.first_sc_id
                    when g.rel_quotient > h.last_shift then h.last_sc_id  
                   end sc_id,
                   1 wgt,
                   'IR_INTERPOL' update_pgm_id,
                   sysdate update_datetime
            from relevant_shifts g,
                 extrema         h
            where g.rel_quotient < h.first_shift
               or g.rel_quotient > h.last_shift"""
    
    c = pyodbc.connect(database_connect.get_string('INFOP'))
    cursor = c.cursor()
    try:
        cursor.execute(sql_drop)
    except pyodbc.ProgrammingError:
        pass
    cursor.execute(sql_create)
    cursor.execute(sql_insert1)
    cursor.execute(sql_insert2)
    
    cursor.commit()
    c.close()


def rating_interpolations_for_model_custom_grid(database_user):
    return sqltool.query_all_with_sql(f"""
SELECT 
  mm.issuer_type_id,
  ip.from_rating_grp_id,
  ip.to_rating_grp_id,
  ip.sc_id,
  ip.wgt
FROM
  {database_user}.ir_interpolation ip, 
  marsp.irm_model_matrix mm
WHERE
  mm.ir_model_id = %(ir_model_id)d
  and ip.multiplier_id = mm.multiplier_id
""")


@json_cache
def query_for_migration_effects_custom_grid(ir_model_id, grid_points, database_user, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    # Creates tables for custom grid
    create_sc_grp_sc(grid_points, database_user), create_ir_interpolation(database_user)
    
    interpolations, sql = rating_interpolations_for_model_custom_grid(database_user)(cursor=cursor,
                                                                                     ir_model_id=ir_model_id)
    logging.debug("query_for_migration_effects SQL\n" + sql)
    migrations = [
        ("%(issuer_type_id)s|%(from_rating_grp_id)s|%(to_rating_grp_id)s" % r, dict(sc_id=r["sc_id"], wgt=r["wgt"])) for
        r in interpolations]
    return migrations, sql


################################### END OF CUSTOMIZED GRID PART
# #########################################################

cons_org_query = sqltool.query_all_with_sql("""
SELECT
  h.cons_org_id,
  h.org_id
FROM
  marsp.cons_org_structure_std_hist h  
WHERE
  h.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
""")


@json_cache
def cons_org_struct(eod_date, cursor=None):
    eod_date = date_format(to_datetime(eod_date))
    cursor = get_cursor() if cursor is None else cursor
    d = {}
    cons_org_records, sql = cons_org_query(cursor=cursor, eod_date=eod_date)
    logging.debug("cons_org_struct SQL\n" + sql)
    for r in cons_org_records:
        cons_org_id = str(int(r["cons_org_id"]))
        org_id = int(r["org_id"])
        s = d.get(cons_org_id, [org_id])
        if org_id not in s:
            s.append(org_id)
        d[cons_org_id] = s
    return d, sql

RETURNS_QUERY_PACK ="""
select a.eod_date,
       a.org_id,
       a.position_grp_id,
       a.sc_id,
       a.product_id,
       a.spread_id,
       a.return_base,
       a.update_pgm_id,
       a.update_datetime,
       ss.org_id issuer_org_id
FROM marsp_reporting.sc_spread_return_v a
     join marsp.cons_org_structure_std_hist o on o.org_id = a.org_id and o.eod_date = a.eod_date
     JOIN marsp.sc_grp_sc b on a.sc_id = b.sc_id
     JOIN marsp.specific_spread ss on a.spread_id = ss.spread_id
     join marsp.position_supergrp_position_grp p on a.position_grp_id = p.position_grp_id
WHERE a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.rm_spread_supergrp_id = 1
  and b.sc_grp_id = 29
  and o.cons_org_id = 50004
  and p.position_supergrp_id = '%(mp)s'
UNION ALL
SELECT a.eod_date,
       a.org_id,
       a.position_grp_id,
       -1000,
       a.product_id,
       a.interest_id spread_id,
       a.sens_base   return_base,
       a.update_pgm_id,
       a.update_datetime,
       ss.org_id     issuer_org_id
FROM marsp.interest_param_sens a
     join marsp.cons_org_structure_std_hist o on o.org_id = a.org_id and o.eod_date = a.eod_date
     JOIN marsp.specific_spread ss on a.interest_id = ss.spread_id
     join marsp.position_supergrp_position_grp p on a.position_grp_id = p.position_grp_id
WHERE a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.param_id = 2
  and o.cons_org_id = 50004
  and p.position_supergrp_id = '%(dp)s'"""

# NOTE: OLD RETURNS QUERY
RETURNS_QUERY = """
select
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  a.sc_id,
  a.product_id,
  a.spread_id,
  a.return_base,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org,
  a.position_grp_id
FROM marsp.sc_spread_return  a
JOIN marsp.sc_grp_sc b on a.sc_id = b.sc_id
JOIN marsp.specific_spread ss on a.spread_id = ss.spread_id
WHERE
      a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.rm_spread_supergrp_id = 1
  and b.sc_grp_id = 29
  and a.org_id in (select org_id from marsp.cons_org_structure_std_hist where cons_org_id = 50004 and eod_date=
  to_date('%(eod_date)s', 'yyyy-mm-dd'))
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp 
                            where position_supergrp_id = '%(mp)s' )
UNION ALL
SELECT
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  -1000,
  a.product_id,
  a.interest_id spread_id,
  a.sens_base return_base,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org,
  a.position_grp_id
FROM marsp.interest_param_sens a
JOIN marsp.specific_spread ss on a.interest_id = ss.spread_id
WHERE a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.param_id = 2
  and a.org_id in (select org_id from marsp.cons_org_structure_std_hist where cons_org_id = 50004 and eod_date=
  to_date('%(eod_date)s', 'yyyy-mm-dd'))
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp 
                            where position_supergrp_id = '%(dp)s' )
  """


# G03641: Query for custom grid points - function to use user ID from config file.
def RETURNS_QUERY_custom_grid(database_user):
    return f"""
select
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  a.sc_id,
  a.product_id,
  a.spread_id,
  a.return_base,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org,
  a.position_grp_id
FROM marsp.sc_spread_return  a
JOIN {database_user}.sc_grp_sc b on a.sc_id = b.sc_id
JOIN marsp.specific_spread ss on a.spread_id = ss.spread_id
WHERE
      a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.rm_spread_supergrp_id = 1
  and b.sc_grp_id = 29
  and a.org_id in (select org_id from marsp.cons_org_structure_std_hist where cons_org_id = 50004 and eod_date=
to_date('%(eod_date)s', 'yyyy-mm-dd'))
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp 
                            where position_supergrp_id = '%(mp)s' )
UNION ALL
SELECT
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  -1000,
  a.product_id,
  a.interest_id spread_id,
  a.sens_base return_base,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org,
  a.position_grp_id
FROM marsp.interest_param_sens a
JOIN marsp.specific_spread ss on a.interest_id = ss.spread_id
WHERE a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.param_id = 2
  and a.org_id in (select org_id from marsp.cons_org_structure_std_hist where cons_org_id = 50004 and eod_date=
to_date('%(eod_date)s', 'yyyy-mm-dd'))
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp 
                            where position_supergrp_id = '%(dp)s' )
  """


RETURNS_QUERY_NEW = """
select
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  a.sc_id,
  a.product_id,
  a.spread_id,
  a.return_base,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org
FROM marsp_reporting.sc_spread_return_v  a
JOIN marsp.sc_grp_sc b on a.sc_id = b.sc_id
JOIN marsp.specific_spread ss on a.spread_id = ss.spread_id
WHERE
      a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.rm_spread_supergrp_id = 1
  and b.sc_grp_id = 29
  and a.org_id in (select org_id from marsp.cons_org_structure_std where cons_org_id = 50004)
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp where
  position_supergrp_id = 'IRM')
UNION ALL
SELECT
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  -1000,
  a.product_id,
  a.interest_id spread_id,
  a.sens_base return_base,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org
FROM marsp.interest_param_sens a
JOIN marsp.specific_spread ss on a.interest_id = ss.spread_id
WHERE a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.param_id = 2
  and a.org_id in (select org_id from marsp.cons_org_structure_std where cons_org_id = 50004)
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp where
  position_supergrp_id = 'IRD')
  """

returns_query = sqltool.query_all_with_sql(RETURNS_QUERY,
                                           keys=["eod_date", "org_id", "position_grp_id", "sc_id", "product_id",
                                                 "spread_id", "return_base", "update_pgm_id", "update_datetime",
                                                 "issuer_org_id"]
                                           )


# Also function to take user ID as input, which can be fetched from config file.
def returns_query_custom_grid(database_user):
    return sqltool.query_all_with_sql(RETURNS_QUERY_custom_grid(database_user),
                                      keys=["eod_date", "org_id", "position_grp_id", "sc_id", "product_id",
                                            "spread_id", "return_base", "update_pgm_id", "update_datetime",
                                            "issuer_org_id"]
                                      )


returns_query_iterator = sqltool.query_iterator_with_sql(RETURNS_QUERY,
                                                         keys=["eod_date", "org_id", "position_grp_id", "sc_id",
                                                               "product_id",
                                                               "spread_id", "return_base", "update_pgm_id",
                                                               "update_datetime", "issuer_org_id"]
                                                         )

RETURNS_QUERY_RR_SHOCK = """
select
  a.eod_date,
  a.org_id,
  a.position_grp_id,
  a.sc_id,
  a.product_id,
  a.spread_id,
  a.return_base,
  a.return_base return_up,
  a.return_base return_down,
  a.update_pgm_id,
  a.update_datetime,
  ss.org_id issuer_org
FROM marsp_reporting.sc_spread_return_v  a
JOIN marsp.sc_grp_sc b on a.sc_id = b.sc_id
JOIN marsp.specific_spread ss on a.spread_id = ss.spread_id
WHERE
      a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
  and a.rm_spread_supergrp_id = 1
  and b.sc_grp_id = 29
  and a.org_id in (select org_id from marsp.cons_org_structure_std_hist where cons_org_id = 50004 and eod_date=
  to_date('%(eod_date)s', 'yyyy-mm-dd'))
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp 
                            where position_supergrp_id = '%(mp)s' )
UNION ALL
select
 eod_date,
 org_id,
 position_grp_id,
 -1000,
 product_id,
 spread_id,
 return_base,
 case when RR <> 0 then
 JTD_0 + ((return_base-JTD_0)/RR)*(RR_capped) 
 else JTD_0
 end return_up , -- formula from methodology document
 case when RR <> 0 then
 JTD_0 + ((return_base-JTD_0)/RR)*(RR_floored)
 else JTD_0 
 end return_up , -- formula from methodology document
 update_pgm_id,
 update_datetime,
 issuer_org_id
 from
 (
 select  a.eod_date eod_date,
 a.org_id org_id,
 a.position_grp_id position_grp_id,
 a.product_id product_id,
 a.interest_id spread_id,
 a.sens_base return_base,
 coalesce(a1.sens_base,0) JTD_0,
 h.RECOVERY_PCT RR,
 (h.RECOVERY_PCT + (100+%(rr_shock)d) - abs(h.RECOVERY_PCT-(100-%(rr_shock)d)))/2 RR_capped, -- formula from methodology document
 (h.RECOVERY_PCT-%(rr_shock)d + abs(h.RECOVERY_PCT-%(rr_shock)d))/2 RR_floored,   -- formula from methodology document
 a.update_pgm_id update_pgm_id,
 a.update_datetime update_datetime,
 ss.org_id issuer_org_id
 FROM marsp.interest_param_sens a
 JOIN marsp.specific_spread ss on a.interest_id = ss.spread_id
 left join marsp.interest_param_sens a1 on a.eod_date = a1.eod_date and a.org_id = a1.org_id and a.interest_id =
 a1.interest_id and a.product_id = a1.product_id and a.position_grp_id = a1.position_grp_id and a1.param_id = 7
 left join marsp.specific_spread_dyn h on ss.spread_id=h.spread_id and a.eod_date=h.eod_date
 WHERE a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
 and a.param_id = 2
  and a.org_id in (select org_id from marsp.cons_org_structure_std_hist where cons_org_id = 50004 and eod_date=
  to_date('%(eod_date)s', 'yyyy-mm-dd'))
  and a.position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp 
                            where position_supergrp_id = '%(dp)s' )
 )
"""

returns_query_rr_shock = sqltool.query_all_with_sql(RETURNS_QUERY_RR_SHOCK,
                                                    keys=["eod_date", "org_id", "position_grp_id", "sc_id",
                                                          "product_id",
                                                          "spread_id", "return_base", "return_up", "return_down",
                                                          "update_pgm_id", "update_datetime", "issuer_org_id"]
                                                    )
returns_query_iterator_rr_shock = sqltool.query_iterator_with_sql(RETURNS_QUERY_RR_SHOCK,
                                                                  keys=["eod_date", "org_id", "position_grp_id",
                                                                        "sc_id", "product_id",
                                                                        "spread_id", "return_base", "return_up",
                                                                        "return_down", "update_pgm_id",
                                                                        "update_datetime", "issuer_org_id"]
                                                                  )

CREATE_RETURNS_SQL = """
CREATE TABLE IF NOT EXISTS returns (
eod_date         TEXT,
org_id           INTEGER,
position_grp_id  INTEGER,
sc_id            INTEGER,
product_id       INTEGER,
spread_id        INTEGER,
return_base      REAL,
update_pgm_id    TEXT,
update_datetime  TEXT,
issuer_org_id    INTEGER
)
"""

INSERT_RETURNS_SQL = """
INSERT INTO returns (
eod_date,
org_id,
position_grp_id,
sc_id,
product_id,
spread_id,
return_base,
update_pgm_id,
update_datetime,
issuer_org_id
)
VALUES (
'%(date)s',
%(org_id)d,
%(position_grp_id)d,
%(sc_id)d,
%(product_id)d,
%(spread_id)d,
%(return_base)f,
'%(update_pgm_id)s',
'%(update_datetime)s',
%(issuer_org_id)d
)
"""

DELETE_RETURNS_SQL = """
DELETE FROM returns WHERE eod_date='%(eod_date)s'
"""

SQLITE_RETURNS_QUERY_SQL = """
SELECT
eod_date,
org_id,
position_grp_id,
sc_id,
product_id,
spread_id,
return_base,
update_pgm_id,
update_datetime,
issuer_org_id
FROM returns
WHERE eod_date = '%(eod_date)s'
"""

sqlite_returns_query = sqltool.query_all_with_sql(SQLITE_RETURNS_QUERY_SQL)


def clone_returns_to_sqlite(eod_date, cursor=None, sqlite_cursor=None):
    eod_date = date_format(to_datetime(eod_date))
    cursor = get_cursor() if cursor is None else cursor
    sqlite_cursor = get_sqlite_cursor() if sqlite_cursor is None else sqlite_cursor
    logging.info("Clone returns to sqlite database")
    
    logging.debug("CREATE_RETURNS_SQL\n" + CREATE_RETURNS_SQL)
    sqlite_cursor.execute(CREATE_RETURNS_SQL)
    logging.debug("DELETE_RETURNS_SQL\n" + DELETE_RETURNS_SQL % locals())
    sqlite_cursor.execute(DELETE_RETURNS_SQL % locals())
    it = returns_query_iterator(eod_date=eod_date, cursor=cursor)
    sql = next(it)
    logging.debug("clone_returns_to_sqlite SQL\n" + sql)
    for i, r in enumerate(it):
        r["date"] = date_format(to_datetime(r["eod_date"]))
        sqlite_cursor.execute(INSERT_RETURNS_SQL % r)
        if i % 100 == 0:
            logging.info("Iserted %d returns" % i)
    sqlite_connection().commit()


def query_for_postions(eod_date, model_id, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    if model_id == 101:
        position_default_part = 'ITD'
        position_migration_part = 'ITM'
    elif model_id == 1:
        position_default_part = 'IRD'
        position_migration_part = 'IRM'
    else:
        print("\nThe passed model_id value was neither 101 nor 1.\nTreating as if model_id = 1.\n")
        position_default_part = 'IRD'
        position_migration_part = 'IRM'
    eod_date = date_format(to_datetime(eod_date))
    if config()["primary_source_of_returns"] == "sqlite":
        logging.info("Fetching returns from the sqlite database.")
        try:
            returns, sql = sqlite_returns_query(cursor=get_sqlite_cursor(), eod_date=eod_date)
        except:
            logging.exception("Error reading from sqlite database.")
            returns = []
        if not len(returns):
            logging.info("No returns found in the sqlite database, fetching returns from MARS")
            clone_returns_to_sqlite(eod_date=eod_date, cursor=cursor)
            try:
                returns, sql = sqlite_returns_query(cursor=get_sqlite_cursor(), eod_date=eod_date)
            except:
                logging.exception("Error reading from sqlite database (2nd attempt).")
                returns = []
        if not len(returns):
            returns, sql = returns_query(
                cursor=cursor,
                dp=position_default_part,
                mp=position_migration_part,
                eod_date=eod_date
                )
    else:
        logging.info("Fetching returns from MARS")
        returns, sql = returns_query(
            cursor=cursor,
            dp=position_default_part,
            mp=position_migration_part,
            eod_date=eod_date
            )
    returns_map = {}
    for r in returns:
        r["date"] = date_format(to_datetime(r["eod_date"]))
        key = "%(date)s|%(org_id)s|%(position_grp_id)s|%(product_id)s|%(spread_id)s" % r
        position_returns = returns_map.get(key, dict(
            org_id=r["org_id"],
            position_grp_id=r["position_grp_id"],
            product_id=r["product_id"],
            spread_id=r["spread_id"],
            issuer_org_id=r["issuer_org_id"],
            key="%(product_id)s;%(spread_id)s" % r,
            returns={}
            ))
        position_returns["returns"][int(r["sc_id"])] = float(r["return_base"])
        returns_map[key] = position_returns
    return returns_map, sql


# G03641: For custom grid
def query_for_postions_custom_grid(eod_date, model_id, database_user, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    if model_id == 101:
        position_default_part = 'ITD'
        position_migration_part = 'ITM'
    elif model_id == 1:
        position_default_part = 'IRD'
        position_migration_part = 'IRM'
    else:
        print("\nThe passed model_id value was neither 101 nor 1.\nTreating as if model_id = 1.\n")
        position_default_part = 'IRD'
        position_migration_part = 'IRM'
    eod_date = date_format(to_datetime(eod_date))
    """
    if config()["primary_source_of_returns"] == "sqlite":
        logging.info("Fetching returns from the sqlite database.")
        try:
            returns, sql = sqlite_returns_query(cursor=get_sqlite_cursor(), eod_date=eod_date)
        except:
            logging.exception("Error reading from sqlite database.")
            returns = []
        if not len(returns):
            logging.info("No returns found in the sqlite database, fetching returns from MARS")
            clone_returns_to_sqlite(eod_date=eod_date, cursor=cursor)
            try:
                returns, sql = sqlite_returns_query(cursor=get_sqlite_cursor(), eod_date=eod_date)
            except:
                logging.exception("Error reading from sqlite database (2nd attempt).")
                returns = []
        if not len(returns):
            returns, sql = returns_query_custom_grid(cursor=cursor, eod_date=eod_date)
    else:
    """
    logging.info("Fetching returns from MARS")
    # Added
    # returns_query_custom_grid_ = returns_query_custom_grid(database_user)
    returns, sql = returns_query_custom_grid(database_user)(
        cursor=cursor,
        dp=position_default_part,
        mp=position_migration_part,
        eod_date=eod_date
        )
    returns_map = {}
    for r in returns:
        r["date"] = date_format(to_datetime(r["eod_date"]))
        key = "%(date)s|%(org_id)s|%(position_grp_id)s|%(product_id)s|%(spread_id)s" % r
        position_returns = returns_map.get(key, dict(
            org_id=r["org_id"],
            position_grp_id=r["position_grp_id"],
            product_id=r["product_id"],
            spread_id=r["spread_id"],
            issuer_org_id=r["issuer_org_id"],
            key="%(product_id)s;%(spread_id)s" % r,
            returns={}
            ))
        position_returns["returns"][int(r["sc_id"])] = float(r["return_base"])
        returns_map[key] = position_returns
    return returns_map, sql


MM_ADJUSTED_RETURNS_QUERY = '''
-- Scope definitions
WITH pspg AS (
    SELECT /*+ materialize */
        a.eod_date,
        a.org_id,
        a.product_id,
        a.spread_id,
        a.position_grp_id,
        a.sc_id,
        a.update_pgm_id,
        b.position_supergrp_id
    FROM
        marsp.sc_spread_return                 a
        JOIN marsp.cons_org_structure_std_hist      co ON co.eod_date = a.eod_date
                                                     AND co.org_id = a.org_id
                                                     AND co.cons_org_id = 50004
        JOIN marsp.position_supergrp_position_grp   b ON a.position_grp_id = b.position_grp_id
                                                       AND b.position_supergrp_id = 'ITM'
        JOIN marsp.sc_grp_sc                        sgs ON a.sc_id = sgs.sc_id
                                    AND sgs.sc_grp_id = 29
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.rm_spread_supergrp_id = 1
    UNION ALL
    SELECT /*+ materialize */
        a.eod_date,
        a.org_id,
        a.product_id,
        a.interest_id as spread_id,
        a.position_grp_id,
        -1000 as sc_id,
        a.update_pgm_id,
        b.position_supergrp_id
    FROM
        marsp.interest_param_sens              a
        INNER JOIN marsp.position_supergrp_position_grp   b ON a.position_grp_id = b.position_grp_id
                                                             AND b.position_supergrp_id = 'ITD'
        INNER JOIN marsp.cons_org_structure_std_hist      co ON a.eod_date = co.eod_date
                                                           AND a.org_id = co.org_id
                                                           AND co.cons_org_id = 50004
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.param_id = 2
)
, pre AS (
    /* ORCA HOLDINGS migration part */
    SELECT /*+ parallel */
        a.eod_date,
        a.org_id,
        a.product_id,
        a.spread_id,
        a.effect_id,
        coalesce(d.maturity_date, d2.maturity_date, d3.maturity_date) - a.eod_date as time_to_maturity,
        a.sc_id,
        a.update_pgm_id,
        a.return_base
    FROM
        marsp.holding_sc_spread_return_1 a
        LEFT JOIN marsp.bond_effect                   d ON a.effect_id = d.effect_id
        LEFT JOIN marsp.future_effect                 d2 ON a.effect_id = d2.effect_id
        LEFT JOIN marsp.option_effect                 d3 ON a.effect_id = d3.effect_id
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.risk_category_id = 'NONLINORCA'
        AND a.rm_spread_supergrp_id = 1
        and sc_id in (select sgs.sc_id from marsp.sc_grp_sc sgs WHERE sgs.sc_grp_id = 29)
                           /* MARS HOLDINGS migration part*/
    UNION ALL
    SELECT   /*+ parallel */
        a.eod_date,
        a.org_id,
        a.product_id,
        a.spread_id,
        a.effect_id,
        coalesce(d.maturity_date, d2.maturity_date, d3.maturity_date) - a.eod_date as time_to_maturity,
        a.sc_id,
        a.update_pgm_id,
        a.return_base
    FROM
        marsp.holding_sc_spread_return a
        LEFT JOIN marsp.bond_effect                   d ON a.effect_id = d.effect_id
        LEFT JOIN marsp.future_effect                 d2 ON a.effect_id = d2.effect_id
        LEFT JOIN marsp.option_effect                 d3 ON a.effect_id = d3.effect_id
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.rm_spread_supergrp_id = 1
        and sc_id in (select sgs.sc_id from marsp.sc_grp_sc sgs WHERE sgs.sc_grp_id = 29)
    UNION ALL
    SELECT  /*+  parallel */
        a.eod_date,
        a.org_id,
        a.product_id,
        a.interest_id   AS spread_id,
        a.effect_id,
        coalesce(d.maturity_date, d2.maturity_date, d3.maturity_date) - a.eod_date as time_to_maturity,
        -1000 as sc_id,
        a.update_pgm_id,
        a.sens_base     return_base
    FROM
        marsp.holding_interest_param_sens   a
        LEFT JOIN marsp.bond_effect                   d ON a.effect_id = d.effect_id
        LEFT JOIN marsp.future_effect                 d2 ON a.effect_id = d2.effect_id
        LEFT JOIN marsp.option_effect                 d3 ON a.effect_id = d3.effect_id
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.param_id = 2
    UNION ALL
/* ORCA DERIVATIVES migration part */
    SELECT /*+ leading(a) use_nl(pspg_itm) parallel */
        a.eod_date,
        b.org_id,
        b.product_id,
        a.spread_id,
        c.effect_id,
        coalesce(e2.maturity_date, c.settlm_date) - a.eod_date AS time_to_maturity,
        a.sc_id,
        a.update_pgm_id,
        a.return_base
    FROM
        marsp.trans_sc_spread_return_1   a
        INNER JOIN marsp.trans_status               b ON a.eod_date = b.eod_date
                                           AND a.trade_id = b.trade_id
                                           AND a.trans_id = b.trans_id
        INNER JOIN marsp.trans                      c ON a.trade_id = c.trade_id
                                    AND a.trans_id = c.trans_id
                                    AND b.org_id = c.org_id
        LEFT JOIN marsp.bond_effect                 e2 ON c.effect_id = e2.effect_id
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.rm_spread_supergrp_id = 1
        and sc_id in (select sgs.sc_id from marsp.sc_grp_sc sgs WHERE sgs.sc_grp_id = 29)
    UNION ALL
/* MARS DERIVATIVES migration part */
    SELECT /*+ parallel */
        a.eod_date,
        b.org_id,
        b.product_id,
        a.spread_id,
        c.effect_id,
        coalesce(e2.maturity_date, c.settlm_date) - a.eod_date AS time_to_maturity,
        a.sc_id,
        a.update_pgm_id,
        a.return_base
    FROM
        marsp.trans_sc_spread_return   a
        INNER JOIN marsp.trans_status             b ON a.eod_date = b.eod_date
                                           AND a.trade_id = b.trade_id
                                           AND a.trans_id = b.trans_id
        INNER JOIN marsp.trans                    c ON a.trade_id = c.trade_id
                                    AND a.trans_id = c.trans_id
                                    AND b.org_id = c.org_id
        LEFT JOIN marsp.bond_effect                 e2 ON c.effect_id = e2.effect_id
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.rm_spread_supergrp_id = 1
        and sc_id in (select sgs.sc_id from marsp.sc_grp_sc sgs WHERE sgs.sc_grp_id = 29)
    UNION ALL
/* Derivatives default part */
    SELECT  /*+ leading(a) use_nl(pspg_itd) parallel */
        a.eod_date,
        a1.org_id,
        a1.product_id,
        a.interest_id   AS spread_id,
        a2.effect_id,
        coalesce(e2.maturity_date, a2.settlm_date) - a.eod_date AS time_to_maturity,
        -1000 as sc_id,
        a.update_pgm_id,
        a.sens_base     return_base
    FROM
        marsp.trans_interest_param_sens   a
        INNER JOIN marsp.trans_status                a1 ON a.eod_date = a1.eod_date
                                            AND a.trade_id = a1.trade_id
                                            AND a.trans_id = a1.trans_id
        INNER JOIN marsp.trans                       a2 ON a.trade_id = a2.trade_id
                                     AND a.trans_id = a2.trans_id
        LEFT JOIN marsp.bond_effect                 e2 ON a2.effect_id = e2.effect_id
    WHERE
        a.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        AND a.param_id = 2
)
, combined_risk AS (
    SELECT /*+ ORDERED parallel */
        p.eod_date,
        p.org_id,
        p.product_id,
        p.spread_id,
        x.position_grp_id,
        ss.org_id as issuer_org_id,
        p.effect_id,
        p.sc_id,
        greatest(3,least(3 * ceil(p.time_to_maturity / 91), 12)) AS time_to_maturity,
        p.return_base
    FROM
        pre   p
        INNER JOIN pspg x ON x.eod_date = p.eod_date
                            AND x.org_id = p.org_id
                            AND x.product_id = p.product_id
                            AND x.spread_id = p.spread_id
                            AND x.sc_id = p.sc_id
        LEFT JOIN marsp.specific_spread   ss ON p.spread_id = ss.spread_id
        WHERE
            (p.update_pgm_id, x.position_grp_id) not in (
                                                        ('IR_BOND_MVT',7092) , ('IR_BOND_MVT',7132) ,
                                                        ('IR_BOND_MVT',7136) , ('IR_BOND_MVT',7137) ,
                                                        ('IR_BOND_MVT',7162) , ('IR_BOND_MVH',7092) ,
                                                        ('IR_BOND_MVH',7132) , ('IR_BOND_MVH',7136) ,
                                                        ('IR_BOND_MVH',7137) , ('IR_BOND_MVH',7162)
                                                        )

)
SELECT
    a.eod_date,
    a.org_id,
    a.product_id,
    a.spread_id,
    a.position_grp_id,
    a.issuer_org_id,
    a.time_to_maturity,
    a.sc_id,
    SUM(a.return_base) AS return_base
FROM
    combined_risk a
GROUP BY
    a.eod_date,
    a.org_id,
    a.product_id,
    a.spread_id,
    a.position_grp_id,
    a.issuer_org_id,
    a.sc_id,
    a.time_to_maturity
;
'''

mm_adjusted_returns_query = sqltool.query_all_with_sql(
    MM_ADJUSTED_RETURNS_QUERY,
    keys=[
        "eod_date",
        "org_id",
        "product_id",
        "spread_id",
        "position_grp_id",
        "issuer_org_id",
        "time_to_maturity",
        "sc_id",
        "return_base",
        ]
    )


def mm_adjusted_query_for_postions(eod_date, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    eod_date = date_format(to_datetime(eod_date))
    if config()["primary_source_of_returns"] == "sqlite":
        logging.info("Fetching returns from the sqlite database.")
        try:
            returns, sql = sqlite_returns_query(cursor=get_sqlite_cursor(), eod_date=eod_date)
        except:
            logging.exception("Error reading from sqlite database.")
            returns = []
        if not len(returns):
            logging.info("No returns found in the sqlite database, fetching returns from MARS")
            clone_returns_to_sqlite(eod_date=eod_date, cursor=cursor)
            try:
                returns, sql = sqlite_returns_query(cursor=get_sqlite_cursor(), eod_date=eod_date)
            except:
                logging.exception("Error reading from sqlite database (2nd attempt).")
                returns = []
        if not len(returns):
            returns, sql = mm_adjusted_returns_query(cursor=cursor, eod_date=eod_date)
    else:
        logging.info("Fetching returns from MARS")
        returns, sql = mm_adjusted_returns_query(cursor=cursor, eod_date=eod_date)
    returns_map = {}
    for r in returns:
        r["date"] = date_format(to_datetime(r["eod_date"]))
        key = "%(date)s|%(org_id)s|%(position_grp_id)s|%(product_id)s|%(spread_id)s|%(time_to_maturity)s" % r
        position_returns = returns_map.get(
            key, dict(
                org_id=r["org_id"],
                product_id=r["product_id"],
                spread_id=r["spread_id"],
                position_grp_id=r["position_grp_id"],
                issuer_org_id=r["issuer_org_id"],
                time_to_maturity=r["time_to_maturity"],
                returns={},
                key="%(product_id)s;%(spread_id)s" % r
                )
            )
        position_returns["returns"][int(r["sc_id"])] = float(r["return_base"])
        returns_map[key] = position_returns
    return returns_map, sql


def query_for_postions_rr_shock(eod_date, model_id, rr_shock, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    if model_id == 101:
        position_default_part = 'ITD'
        position_migration_part = 'ITM'
    elif model_id == 1:
        position_default_part = 'IRD'
        position_migration_part = 'IRM'
    else:
        print("\nThe passed model_id value was neither 101 nor 1.\nTreating as if model_id = 1.\n")
        position_default_part = 'IRD'
        position_migration_part = 'IRM'
    eod_date = date_format(to_datetime(eod_date))
    if config()["primary_source_of_returns"] == "sqlite":
        logging.info(
            "The RR sensitivity analysis is not suported for SQL lite. Please change the primary source of retunrs to "
            "MARS in the config file.")
    else:
        logging.info("Fetching returns from MARS")
        returns, sql = returns_query_rr_shock(cursor=cursor,
                                              dp=position_default_part,
                                              mp=position_migration_part,
                                              eod_date=eod_date,
                                              rr_shock=rr_shock)
    returns_map = {}
    for r in returns:
        r["date"] = date_format(to_datetime(r["eod_date"]))
        key = "%(date)s|%(org_id)s|%(position_grp_id)s|%(product_id)s|%(spread_id)s" % r
        position_returns = returns_map.get(key, dict(
            org_id=r["org_id"],
            position_grp_id=r["position_grp_id"],
            product_id=r["product_id"],
            spread_id=r["spread_id"],
            issuer_org_id=r["issuer_org_id"],
            key="%(product_id)s;%(spread_id)s" % r,
            returns_base={},
            returns_up={},
            returns_down={}
            ))
        position_returns["returns_base"][int(r["sc_id"])] = float(r["return_base"])
        position_returns["returns_up"][int(r["sc_id"])] = float(r["return_up"])
        position_returns["returns_down"][int(r["sc_id"])] = float(r["return_down"])
        
        returns_map[key] = position_returns
    return returns_map, sql


issuer_query = sqltool.query_all_with_sql(
    '''
      with issuers as ( SELECT DISTINCT
        r.rating_id
        , m.idio_vec_no
        , r.org_id
        , rg.rating_grp_id,
        max(nvl(j.gics_id,99)) over (partition by m.org_id) gics_id
    FROM  marsp.org_rating r
        , marsp.ir_org_vector_mapping m
        , marsp.rating_supergrp_rating_grp f
        , marsp.rating_grp_rating rg
        , marsp.specific_spread  h
        , marsp.spread i
        , (select distinct gics_id from marsp.ir_sector_correlation)  j
    WHERE r.eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        and r.seniority_grp_id = 50
        and r.eod_date = m.eod_date
        and r.org_id = m.org_id
        and m.ir_model_id = 1
        and f.rating_supergrp_id = 'IR'
        and rg.rating_grp_id = f.rating_grp_id
        and r.rating_id = rg.rating_id
        and m.org_id = h.org_id
        and h.spread_id = i.spread_id
        and i.gics_id = j.gics_id (+) )
        select iss.rating_id, iss.idio_vec_no, nvl2(h.issuer_org_id, 'GOVM',  'CORP') issuer_type, iss.org_id,
        iss.rating_grp_id,iss.gics_id
        from issuers iss
        left outer join marsp.spread_position_grp_mapping#6 h on iss.org_id = h.issuer_org_id and
        h.int_model_exception in ('GOV_IRM','NCM')''',
    keys=["rating_id", "idio_vec_no", "issuer_type", "org_id", "rating_grp_id", "gics_id"]
    )


@json_cache
def get_issuers(eod_date, cursor=None):
    eod_date = date_format(to_datetime(eod_date))
    cursor = get_cursor() if cursor is None else cursor
    issuers, sql = issuer_query(cursor=cursor, eod_date=eod_date)
    return dict((str(int(r["org_id"])), r) for r in issuers), sql


markit_query = sqltool.query_all_with_sql(
    '''select map.org_id, ct.rating, rat.RATING_ID from tip.ct_reference_rating ct
left join marsp.org_GNFOSN_LINK map on ct.REFERENCE_ENTITY = map.GNFOSN_ORG_SHORT_NAME
left join MARSP.RATING_MAPPING#1 rat on rat.UNIFORM_RATING=ct.rating
where rating_scale = 'MARKIT IMPLIED RATING'
and ct.report_date = to_date('%(report_date)s', 'yyyy-mm-dd')
and map.org_id in (%(org_id)s)''',
    keys=["org_id", "rating", "rating_id"])


@json_cache
def get_issuers_wMarkit(eod_date, cursor=None):
    eod_date = date_format(to_datetime(eod_date))
    cursor = get_cursor() if cursor is None else cursor
    issuers, sql = issuer_query(cursor=cursor, eod_date=eod_date)
    report_date = date_format(to_business_date((to_datetime(eod_date) + timedelta(days=1)), 'f'))
    for k in issuers:
        if k['rating_id'] == '22':
            markit, sql = markit_query(cursor=cursor, report_date=report_date, org_id=k['org_id'])
            if not markit:
                k['Markit'] = 0
            else:
                if markit[0]['rating'] == 'D':
                    k['Markit'] = 0
                else:
                    k['rating_id'] = markit[0]['rating_id']
                    k['rating_grp_id'] = markit[0]['rating']
                    k['Markit'] = 1
        else:
            k['Markit'] = 0
    return dict((str(int(r["org_id"])), r) for r in issuers), sql


correlation_query = sqltool.query_all_with_sql(
    '''
    SELECT  gics_id,
            rating_grp_id,
            value
    FROM marsp.ir_sector_correlation
    WHERE correlation_id=%(correlation_id)d
    ''',
    keys=["gics_id", "rating_grp_id", "value"]
    )


def get_correlations(correlation_id, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    correlations, sql = correlation_query(cursor=cursor, correlation_id=correlation_id)
    correlation_table = {}
    for r in correlations:
        correlation_table[str(int(r["gics_id"])) + str(r["rating_grp_id"])] = r["value"]
    return correlations, correlation_table


riskcalc_query = sqltool.query_all_with_sql(
    """
    SELECT c.cons_org_id
           , a.risk_type_id
           , a.risk_factor_id
        FROM marsp.risk_type a
           , marsp.risk_calc c
           , marsp.ir_risk_type d
       WHERE a.risk_factor_id IN ('SPR','DFT')
         AND a.risk_measure_id    = 'EXP_TAILLOSS'
         AND a.risk_estimator_id  = 'IR_SIMU'
         AND c.risk_type_id       = a.risk_type_id
         AND d.risk_type_id       = a.risk_type_id
         AND d.ir_model_id        = 1
         order by 1
    """)


@json_cache
def issuer_description(org_id):
    return sqltool.table_id_query_with_sql(get_cursor(), "ORG", datetime_as_date_string=True)(int(org_id))


@json_cache
def get_risk_calc(cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    riskcalcs, sql = riskcalc_query(cursor=cursor)
    return riskcalcs, sql


random_query = sqltool.query_all_with_sql(
    """
    SELECT v.value
    FROM marsp.gaussian_vector_value v
    WHERE v.vector_no = %(vector_no)d
    ORDER BY v.entry_no
    """)


@json_cache
def get_gaussian_vector(vector_no, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    random, sql = random_query(cursor=cursor, vector_no=vector_no)
    return [r["value"] for r in random], sql


systemic_query = sqltool.query_all_with_sql(
    """
    SELECT
      marsp.statfunk.inversenormcum((c.entry_no-0.5)/a.vector_length) value
    FROM
      marsp.ir_model                 a,
      marsp.gaussian_vector_value    c
    WHERE
          a.ir_model_id = %(ir_model_id)d
      AND c.vector_no   = 1
    ORDER BY c.entry_no
    """, keys=["value"])


@json_cache
def get_systemic_vector(ir_model_id, cursor=None):
    cursor = get_cursor() if cursor is None else cursor
    systemic, sql = systemic_query(cursor=cursor, ir_model_id=ir_model_id)
    return [r["value"] for r in systemic], sql


sovereign_historical_spreads_raw = sqltool.query_all_with_sql(
    """
    select a.contributiondate, a.ticker, a.avrating, a.spread5y
     from tw_markit_net.markit_comp_convention a
     where a.contributiondate >=to_date('%(from_date)s', 'yyyy-mm-dd') and a.contributiondate <to_date('%(to_date)s',
     'yyyy-mm-dd')
       and a.sector='Government' and a.tier='SNRFOR'
       and a.spread5y is not null and a.avrating is not null
     order by a.ticker, a.contributiondate
    """, datetime_as_date_string=True)

corporate_historical_spreads_raw = sqltool.query_all_with_sql(
    """
    select a.contributiondate, a.ticker, a.avrating, a.spread5y
       from tw_markit_net.markit_comp_convention a
     where a.contributiondate >=to_date('%(from_date)s', 'yyyy-mm-dd') and a.contributiondate <to_date('%(to_date)s',
     'yyyy-mm-dd')
         and a.sector<>'Government' and a.tier='SNRFOR'
         and spread5y is not null and avrating is not null
       order by a.ticker, a.contributiondate;
    """, datetime_as_date_string=True)

historical_spreads_raw = sqltool.query_all_with_sql(
    """
    SELECT
      a.contributiondate,
      a.ticker,
      a.avrating,
      a.sector,
      a.%(spread)s spread,
      CASE a.sector WHEN 'Government' THEN 1 ELSE 0 END AS sovereign from tw_markit_net.markit_comp_convention a
    WHERE
      a.contributiondate >=to_date('%(from_date)s', 'yyyy-mm-dd') AND a.contributiondate <to_date('%(to_date)s',
      'yyyy-mm-dd')
      AND a.tier='SNRFOR'
      AND a.%(spread)s IS NOT NULL AND a.avrating IS NOT NULL
    ORDER BY sovereign, a.avrating, a.sector, a.ticker, a.contributiondate
    """, datetime_as_date_string=True,
    keys=["contributiondate", "ticker", "avrating", "sector", "spread", "sovereign"]
    )


@json_cache
def historical_spreads(from_date, to_date=None, sovereign=True, cursor=None):
    """
    Get historical 5Y spreads for sovereign or corporate entities with rating group in the given time-span.

    This is used in IRM calibration to estimate the spread migration multipliers.

    Args:
        from_date           (str):    Start date of the period (as YYYY-MM-DD string) 
        to_date             (str):    End date of the period (as YYYY-MM-DD string) or None for a one year period
        sovereign           (bool):   sovereign for True, corporate for False
        cursor              (cursor): Database cursor or None for a default cursor

    Returns:
        (list of dicts, str):   tuple with list of resulting records and an sql query

    Example:
        The module is called (from python) like this::

            historical_spreads("2015-05-15")

    Notes:
        Author: g46987 (Orest Dubay)
    """
    
    from datetime import date
    
    if to_date is None:
        d = to_datetime(from_date)
        to_date = date_format(date(year=d.year + 1, month=d.month, day=d.day))
    cursor = get_cursor() if cursor is None else cursor
    
    if sovereign:
        return sovereign_historical_spreads_raw(cursor=cursor, from_date=from_date, to_date=to_date)
    else:
        return corporate_historical_spreads_raw(cursor=cursor, from_date=from_date, to_date=to_date)


@json_cache
def historical_spreads_with_sector(from_date, to_date=None, cursor=None, spread="spread5y"):
    """
    Get historical 5Y spreads for both sovereign or corporate entities with rating group and sector in the given
    time-span.

    This is used in IRM and DRC calibration to estimate the spread migration multipliers and correlations.

    Args:
        from_date           (str):    Start date of the period (as YYYY-MM-DD string) 
        to_date             (str):    End date of the period (as YYYY-MM-DD string) or None for a one year period
        spread              (str):    spread column to fetch (spread5y by default)
        cursor              (cursor): Database cursor or None for a default cursor

    Returns:
        (list of dicts, str):   tuple with list of resulting records and an sql query

    Example:
        The module is called (from python) like this::

            historical_spreads_with_sector("2015-05-15")

    Notes:
        Author: g46987 (Orest Dubay)
    """
    
    from datetime import date
    
    if to_date is None:
        d = to_datetime(from_date)
        to_date = date_format(date(year=d.year + 1, month=d.month, day=d.day))
    cursor = get_cursor() if cursor is None else cursor
    
    return historical_spreads_raw(cursor=cursor, from_date=from_date, to_date=to_date, spread=spread)


def historical_spreads_dataframe(from_date, to_date=None, sovereign=True, cursor=None):
    """
    Get historical 5Y spreads for sovereign or corporate entities with rating group in the given time-span as pandas
    dataframe.

    This is used in IRM calibration to estimate the spread migration multipliers.
    The column headers will be capitalized in order to comply with the convention used in migration_multiplier. 

    Args:
        from_date           (str):    Start date of the period (as YYYY-MM-DD string) 
        to_date             (str):    End date of the period (as YYYY-MM-DD string) or None for a one year period
        sovereign           (bool):   sovereign for True, corporate for False
        cursor              (cursor): Database cursor or None for a default cursor

    Returns:
        (list of dicts, str):   tuple with list of resulting records and an sql query

    Example:
        The module is called (from python) like this::

            historical_spreads_dataframe("2015-05-15")

    Notes:
        Author: g46987 (Orest Dubay)
    """
    import pandas as pd
    
    data, sql = historical_spreads(cursor=cursor, from_date=from_date, to_date=to_date, sovereign=sovereign)
    df = pd.DataFrame(data)
    df.columns = [x.upper() for x in df.columns]
    return df, sql


def historical_spreads_with_sectors_dataframe(from_date, to_date=None, spread="spread5y", cursor=None):
    """
    Get historical spreads for both sovereign and corporate entities with rating group and sector in the given
    time-span as pandas dataframe.

    This is used in IRM and DRC calibration to estimate the spread migration multipliers and correlations.
    The column hearers will be capitalized in order to comply with the convention used in migration_multiplier. 

    Args:
        from_date           (str):    Start date of the period (as YYYY-MM-DD string) 
        to_date             (str):    End date of the period (as YYYY-MM-DD string) or None for a one year period
        spread              (str):    Spread column to fetch (spread5y by default)
        cursor              (cursor): Database cursor or None for a default cursor

    Returns:
        (list of dicts, str):   tuple with list of resulting records and an sql query

    Example:
        The module is called (from python) like this::

            historical_spreads_with_sectors_dataframe("2015-05-15")

    Notes:
        Author: g46987 (Orest Dubay)
    """
    import pandas as pd
    
    data, sql = historical_spreads_with_sector(cursor=cursor, from_date=from_date, to_date=to_date, spread=spread)
    df = pd.DataFrame(data)
    df.columns = [x.upper() for x in df.columns]
    return df, sql


shifts_grid_ranges_raw = sqltool.query_all_with_sql("""
with ord as (
            select a.sc_id,
                   c.shift/100 + 1 shift, 
                   row_number() over (order by c.shift) num
            from marsp.sc_grp_sc a,
                 marsp.sc b,
                 marsp.sc_spread_shift c
            where a.sc_grp_id = 29
              and a.sc_id = b.sc_id
              and b.sc_spread_id = c.sc_spread_id
            order by shift
            )
            select d.sc_id lower_sc_id,
                   e.sc_id upper_sc_id,
                   d.shift lower_shift,
                   e.shift upper_shift
            from ord d, 
                 ord e
            where e.num = d.num + 1
""", keys=["lower_sc_id", "upper_sc_id", "lower_shift", "upper_shift"])


@json_cache
def shifts_grid_ranges(cursor=None):
    """
    Get a grid of spread shifts with the corresponding scenario IDs.

    Records are in form of intervals (lower_shift, upper_shift) (lower_sc_id, upper_sc_id)
    suitable for interpolation.
    
    Returns:
        (list of dicts, str):   tuple with list of resulting records and an sql query

    Notes:
        Author: g46987 (Orest Dubay)
    """
    cursor = get_cursor() if cursor is None else cursor
    return shifts_grid_ranges_raw(cursor=cursor)


shifts_grid_raw = sqltool.query_all_with_sql("""
select a.sc_id,
                   c.shift/100 + 1 shift, 
                   row_number() over (order by c.shift) num
            from marsp.sc_grp_sc a,
                 marsp.sc b,
                 marsp.sc_spread_shift c
            where a.sc_grp_id = 29
              and a.sc_id = b.sc_id
              and b.sc_spread_id = c.sc_spread_id
            order by shift    
""", keys=["sc_id", "shift", "num"])


@json_cache
def shifts_grid(cursor=None):
    """
    Get a grid of spread shifts with the corresponding scenario IDs.
    
    Returns:
        (list of dicts, str):   tuple with list of resulting records and an sql query

    Notes:
        Author: g46987 (Orest Dubay)
    """
    cursor = get_cursor() if cursor is None else cursor
    return shifts_grid_raw(cursor=cursor)


def shifts_grid_dataframe(cursor=None):
    """
    Dataframe version of shifts_grid
    
    Returns:
        (dataframe, str):   tuple with list of resulting records and an sql query

    Notes:
        Author: g46987 (Orest Dubay)
    """
    import pandas as pd
    data, sql = shifts_grid(cursor=cursor)
    df = pd.DataFrame(data)
    df.columns = [x.upper() for x in df.columns]
    return df, sql


issuer_query_capital_centres_as_corp = sqltool.query_all_with_sql(
    '''
    WITH issuers AS (
        SELECT DISTINCT
              r.rating_id
            , m.idio_vec_no
            , r.org_id
            , rg.rating_grp_id
            , max(nvl(j.gics_id,99)) over (partition BY m.org_id) gics_id
        FROM  marsp.org_rating                      r
            , marsp.ir_org_vector_mapping           m
            , marsp.rating_supergrp_rating_grp      f
            , marsp.rating_grp_rating               rg
            , marsp.specific_spread                 h
            , marsp.spread                          i
            , (
                SELECT DISTINCT gics_id
                FROM marsp.ir_sector_correlation
                )                                   j
        WHERE
                r.eod_date              = to_date('%(eod_date)s', 'yyyy-mm-dd')
            AND r.seniority_grp_id      = 50
            AND r.eod_date              = m.eod_date
            AND r.org_id                = m.org_id
            AND m.ir_model_id           = 1
            AND f.rating_supergrp_id    = 'IR'
            AND rg.rating_grp_id        = f.rating_grp_id
            AND r.rating_id             = rg.rating_id
            AND m.org_id                = h.org_id
            AND h.spread_id             = i.spread_id
            AND i.gics_id               = j.gics_id (+)
    )
        SELECT
              iss.rating_id
            , iss.idio_vec_no
            ,
            CASE
                WHEN iss.org_id in (
                                    SELECT DISTINCT issuer_org_id
                                    FROM marsp.spread_position_grp_mapping#6
                                    WHERE int_model_exception = 'NCM'
                                    ) THEN  'CORP'
                ELSE nvl2(h.issuer_org_id, 'GOVM',  'CORP')
            END     issuer_type
            , iss.org_id
            , iss.rating_grp_id
            , iss.gics_id
        FROM            issuers                                 iss
        LEFT OUTER JOIN marsp.spread_position_grp_mapping#6     h
            ON
                iss.org_id = h.issuer_org_id
            AND h.int_model_exception in ('GOV_IRM','NCM')''',
    keys=["rating_id", "idio_vec_no", "issuer_type", "org_id", "rating_grp_id", "gics_id"]
    )


@json_cache
def get_issuers_modified(eod_date, cursor=None):
    eod_date = date_format(to_datetime(eod_date))
    cursor = get_cursor() if cursor is None else cursor
    issuers, sql = issuer_query_capital_centres_as_corp(cursor=cursor, eod_date=eod_date)
    return dict((str(int(r["org_id"])), r) for r in issuers), sql
