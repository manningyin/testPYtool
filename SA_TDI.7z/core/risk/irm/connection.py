# -*- coding: utf-8 -*-

from core.risk.irm.config import database_config, config
import pyodbc
import logging

_connection=None
def connection():
    global _connection
    if _connection is None:
        c = database_config()
        try:
            connection_string = "Driver={Oracle in OraClient12Home_x64_1}; Dbq=%(database)s; Uid=%(user)s; Pwd=%(password)s"%c
            logging.debug("TRY "+connection_string)
            _connection=pyodbc.connect(connection_string)
        except:
            logging.exception("Failed to connect to database, retrying with an alternative connection string.")
            connection_string = "Driver={Oracle in OraClient12Home_x86_1_32bit}; Dbq=%(database)s; Uid=%(user)s; Pwd=%(password)s"%c
            logging.debug("TRY "+connection_string)
            _connection=pyodbc.connect(connection_string)
    return _connection

def get_cursor():
    try:
        return connection().cursor()
    except:
        logging.exception("Can't create cursor, trying to continue without a database connection.")
        return None

_sqlite_connection=None
    
def sqlite_connection():
    import sqlite3
    global _sqlite_connection
    if _sqlite_connection is None:
        logging.debug("Opening sqlite database %(sqlite_database)s"%config())
        _sqlite_connection = sqlite3.connect(config()["sqlite_database"])
    return _sqlite_connection

def get_sqlite_cursor():
    return sqlite_connection().cursor()