# -*- coding: utf-8 -*-

import numpy as np
from scipy import stats

from core.caching.cache_driver import method_cache
from core.risk.irm.config import config
from core.risk.irm.irm_data import get_systemic_vector, get_gaussian_vector
from core.utils.date_helper import to_timestamp
import hashlib

def issuer_seed(issuer,eod_date):
    """Return an integer number calculated from eod_date and issuer suitable as a seed for """
    return (int(to_timestamp(eod_date)) ^ int(issuer["org_id"]))&0xFFFFFFFF

def second_factor_seed(issuer):
        "Create a seed value for the second systematic vector"
        #m=hashlib.md5()
        #m.update(str(int(issuer["gics_id"])))
        return (abs(hash(int(issuer["org_id"])) ^ int(issuer["gics_id"])))&0xFFFFFFFF
        #return eval("0x"+m.hexdigest())&0xFFFFFFFF
        #return ((int(issuer["gics_id"]))) & 0xFFFFFFFF

class RandomSourceBase:
    RANDOM_SEED=-1
    distribution_type=None
    def __init__(self,ir_model_id, masterseed=-1, cursor=None):
        self.ir_model_id=ir_model_id
        self.cursor=cursor
        self.masterseed=masterseed
        
    def systemic_seed(self):
        "Create a seed value for a systemic vector. Depends on masterseed"
        if self.masterseed == self.RANDOM_SEED:
            return None
        else:
            return abs(hash(self.masterseed))&0xFFFFFFFF

    def second_factor_seed(self, issuer):
        "Create a seed value for the second systematic vector"
        if self.masterseed == self.RANDOM_SEED:
            return None
        else:
            return (abs(hash(self.masterseed) ^ int(issuer["org_id"])) ^ int(issuer["gics_id"]))&0xFFFFFFFF

    def issuer_seed(self, issuer, eod_date):
        "Create a seed value for a idiosyncratic vector."
        if self.masterseed == self.RANDOM_SEED:
#            return issuer_seed(issuer,eod_date)
            return None
        else:
            return (abs(hash(self.masterseed)) ^ int(issuer["org_id"]))&0xFFFFFFFF
            
    def __repr__(self):
        return "%s(%d,%d)"%(self.__class__.__name__,self.ir_model_id, self.masterseed)

class NumpyWithSystemicVectorFromMarsRandomSource(RandomSourceBase):
    """Source of normally distributed random numbers for IRM simulations.
    Use numpy for idiosynchratic component, but MARS for the systemic vector."""
    distribution_type=None

    @method_cache
    def systemic_vector(self,simulations):
        """Return systemic vector - this implementation reads the systemic vector from MARS        
        """
        vec,sql = get_systemic_vector(ir_model_id=self.ir_model_id,cursor=self.cursor)
        return np.array(vec,np.double)[:simulations],sql

    def second_factor(self, simulations, sector):
        pass
        
    def issuer_series(self, issuer, simulations, eod_date=None):
        """Return issuer (idiosyncratic) series - this implementation uses numpy to generate the vector"""
        eod_date = config()["eod_date"] if eod_date is None else eod_date
        rs = np.random.RandomState()
        rs.seed(self.issuer_seed(issuer,eod_date))
        return rs.normal(size=simulations),""
    
    def __str__(self):
        return "Systemic random numbers from MARS, idiosyncratic from Numpy, model %d, seed %d"%(self.ir_model_id, self.masterseed)

class NumpyRandomSource(RandomSourceBase):
    """Source of normally distributed random numbers for IRM simulations.
    Use numpy for both issuer series and the systemic vector."""
    distribution_type=None

    @method_cache
    def systemic_vector(self,simulations):
        "Return systemic vector"
        rs = np.random.RandomState()
        rs.seed(self.systemic_seed())
        return rs.normal(size=simulations),""

    def second_factor(self, issuer, simulations):
        "Return second factor vector"
        rs = np.random.RandomState()
        rs.seed(second_factor_seed(issuer))
        return rs.normal(size=simulations),""
        
    def issuer_series(self, issuer, simulations, eod_date=None):
        "Return issuer (idiosyncratic) vector"
        eod_date = config()["eod_date"] if eod_date is None else eod_date
        rs = np.random.RandomState()
        rs.seed(issuer_seed(issuer,eod_date))
        return rs.normal(size=simulations),""

    def get_distribution(self):
        return stats.norm
    
    def __str__(self):
        return "Random numbers from Numpy, model %d, seed %d"%(self.ir_model_id, self.masterseed)


class StudentRandomSource(RandomSourceBase):
    """Source of random numbers following the Student distribution for IRM simulations.
    Use numpy for both issuer series and the systemic vector."""

    distribution_type = "student"

    @method_cache    
    def scale(self,simulations=config()["simulations"]):
        " The scale to transform a Gaussian r.v. in a student-t r.v."
        rs = np.random.RandomState()
        rs.seed((1664525*self.systemic_seed() +	1013904223)&0xFFFFFFFF)
        return np.sqrt(self.get_t_degrees_of_freedom()/rs.chisquare(self.get_t_degrees_of_freedom(),size=simulations))


    @method_cache
    def systemic_vector(self,simulations):
        "Return systemic vector"
        scale = self.scale(simulations)
        rs = np.random.RandomState()
        rs.seed(self.systemic_seed())
        return rs.normal(size=simulations)*scale,""
        #return rs.standard_t(self.get_t_degrees_of_freedom(), size=simulations), ""

    def second_factor(self, issuer, simulations):
        "Return second factor vector"
        scale = self.scale(simulations)
        rs = np.random.RandomState()
        rs.seed(second_factor_seed(issuer))
        return rs.normal(size=simulations)*scale, ""
        #return rs.standard_t(self.get_t_degrees_of_freedom, size=simulations), ""

    def issuer_series(self, issuer, simulations, eod_date=None):
        "Return issuer (idiosyncratic) vector"
        scale = self.scale(simulations)
        eod_date = config()["eod_date"] if eod_date is None else eod_date
        rs = np.random.RandomState()
        rs.seed(issuer_seed(issuer,eod_date))
        return rs.normal(size=simulations)*scale,""
        #return rs.standard_t(self.get_t_degrees_of_freedom(), size=simulations), ""

    def get_distribution(self):
        return stats.t(self.get_t_degrees_of_freedom())

    def get_t_degrees_of_freedom(self):
        return config()["degrees_of_freedom"]
    
    def __str__(self):
        return "Random numbers from Numpy, model %d, seed %d"%(self.ir_model_id, self.masterseed)


class MarspRandomSource(RandomSourceBase):
    """Source of normally distributed random numbers for IRM simulations.
    Use MARS for both issuer series and the systemic vector."""
    distribution_type=None

    @method_cache
    def systemic_vector(self,simulations):
        "Return systemic vector"
        vec,sql = get_systemic_vector(ir_model_id=self.ir_model_id,cursor=self.cursor)
        return np.array(vec),sql

    def second_factor(self, simulations, sector):
        pass
        
    def issuer_series(self, issuer, simulations, eod_date=None):
        "Return issuer (idiosyncratic) vector"
        vec,sql=get_gaussian_vector(issuer["idio_vec_no"], self.cursor)
        return np.array(vec)[:simulations],sql
    def __str__(self):
        return "Random numbers from MARS, model %d, seed %d"%(self.ir_model_id, self.masterseed)


class FactorCopulaRandomSource(RandomSourceBase):
    """Source used for the credit spread factor copula model, applied in the application IRM
    added by g47102 November 2019"""
    def __init__(self):
        super().__init__()

    def generate_scaling_vector(self, simulations, nu):
        rs = np.random.RandomState()
        rs.seed((1664525 * self.systemic_seed() + 1013904223) & 0xFFFFFFFF)
        self.scaling_vector = np.sqrt(nu/rs.chisquare(nu,size=simulations))

    def generate_systemic_vector(self, simulations, rho, nu):
        rs = np.random.RandomState
        rs.seed(self.systemic_seed())
        Z = rs.multivariate_normal(np.zeros(rho.shape[0]), rho, simulations)
        W = self.get_scaling_vector(simulations, nu)
        self.systemic_vector = W * Z

    def generate_issuers_series(self, simulations, issuer, nu, eod_date=None):
        eod_date = config()["eod_date"] if eod_date is None else eod_date
        rs = np.random.RandomState()
        rs.seed(issuer_seed(issuer,eod_date))
        W = self.get_scaling_vector(simulations, nu)
        self.issuers_series.loc[:, issuer] = W * rs.normal(size=simulations)

    def get_scaling_vector(self, simulations, nu):
        if self.scaling_vector is None:
            self.generate_scaling_vector(simulations, nu)
        return self.scaling_vector

    def get_systemic_vector(self, simulations, rho):
        if self.systemic_vector is None:
            self.generate_systemic_vector(simulations, rho)
        return self.systemic_vector

    def get_issuers_series(self, issuer, simulations, eod_date=None):
        if issuer in self.issuers_series.columns:
            self.generate_issuers_series(issuer, simulations, eod_date)
        return self.issuers_series


def random_source(ir_model_id=None,name = None):
    ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
    name = config()["random_source"] if name is None else name
    RandomSource = dict(
      numpy=NumpyRandomSource,
      mars=MarspRandomSource,
      hybrid=NumpyWithSystemicVectorFromMarsRandomSource,
      student=StudentRandomSource,
      ).get(name,NumpyRandomSource)
    return RandomSource(ir_model_id,masterseed=config().get("seed",RandomSourceBase.RANDOM_SEED))

# g53036 added
# enables to run IRM with seeds independent of config()
def random_source_with_seed(seed,ir_model_id=None,name = None):
    ir_model_id = config()["ir_model_id"] if ir_model_id is None else ir_model_id
    name = config()["random_source"] if name is None else name
    seed = config()["seed"] if seed is None else seed
    RandomSource = dict(
      numpy=NumpyRandomSource,
      mars=MarspRandomSource,
      hybrid=NumpyWithSystemicVectorFromMarsRandomSource,
      student=StudentRandomSource,
      ).get(name,NumpyRandomSource)
    return RandomSource(ir_model_id,masterseed=seed)

