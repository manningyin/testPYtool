# -*- coding: utf-8 -*-
import base64

from yaml import load

from core.utils.date_helper import LAST_BUSINESS_DAY

try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper
import logging

def default_config():
    """Return configuration parameters dictionary populated with default values."""
    cfg = dict(
      rating_groups     = ["AAA", "AA", "A", "BBB", "BB", "B", "CCC", "CNR" ],
      simulations       = 50000,
      returns_needed    = 100,
      random_source     = "numpy",
      degrees_of_freedom = 8,
      seed              = -1,
      ir_model_id       = 1,
      eod_date          = LAST_BUSINESS_DAY,
      correlation_id    =1,
      database_user     = "MARS_TEST",
      database          = "infop",
      sqlite_database   = "data.sqlite",
      database_password_encoded = 'IFMUINCZLJIFIMBQKVNFUMCYIM======',
      primary_source_of_returns = "sqlite",
      log_file          = "log.txt",
      log_level         = "INFO",
      cache_mode        = "ON",
      cache_path        = "cache"
      )
    return cfg

_config = None
def config(**kwarg):
    """Return configuration parameters dictionary."""
    global _config
    if _config is None:
        _config = default_config()
        _config.update(kwarg)        
        configure()
    elif len(kwarg):
        _config.update(kwarg)
        configure()
    return _config
    
def database_config():
    "Return database configuration with password decrypted"
    dbc = config()
    return dict(
        user = dbc["database_user"],
        database = dbc["database"],
        password = base64.b32decode(dbc["database_password_encoded"]).decode("utf-8")
    )


def config_yaml():
    "Return current configuration as a yaml string with comments"
    return """
############################ DATABASE ############################

database_user:              %(database_user)s
database:                   %(database)s
database_password_encoded:  %(database_password_encoded)s


######################## MODEL CONFIGURATION #####################

eod_date:                   %(eod_date)-15s # EOD date YYYY-MM-DD, can be LastBD
ir_model_id:                %(ir_model_id)-15s # IR model, usually 1
simulations:                %(simulations)-15s # Number of simulations, usually 50000
returns_needed:             %(returns_needed)-15s # Number of elements in the tail, usually 100
rating_groups:              %(rating_groups)s # Don't change unless you know what you are doing
random_source:              %(random_source)-15s # Can be numpy, mars, student or hybrid
# numpy   - uses numpy for both for systemic ("market") vector and issuer (idiosyncratic) vector
# hybrid  - uses numpy for issuer (idiosyncratic) vector, but MARS for the systemic ("market") vector
# mars    - uses MARS for both for systemic ("market") vector and issuer (idiosyncratic) vector
# student - Student distribution (experimental)
# Note that MARS always  supplies vectors with the same size (50000),
# therefore if you want to change number of simulations, you need to use random_source: numpy.
degrees_of_freedom:         %(degrees_of_freedom)-15s
# Degrees of freedom of the student-t distribution. This needs to be inserted only when student is chosen as random_source
seed:                       %(seed)-15s # Seed for random number generator
# Seed can be any integer between 0 and 2**32 - 1 inclusive
# If seed is -1, a random seed is generated
correlation_id:             %(correlation_id)-15s # the default used is 1 

############################ CACHING #############################
# Caching of returns
# Returns are the largest data set to be loaded,
# they can be loaded either from MARS (primary_source_of_returns: mars)
# or from a local snapshot (primary_source_of_returns: sqlite).
# If the data are not in local snapshot, they are taken from mars - so it is safe to use
# sqlite option.

primary_source_of_returns:  %(primary_source_of_returns)-15s # sqlite or mars                            
sqlite_database:            %(sqlite_database)-15s # path to the sqlite file

############################ LOGGING #############################
log_file:                   %(log_file)-15s # path to the file where the log will be written
log_level:                  %(log_level)-15s # loglevel - can be DEBUG, INFO, WARNING, ERROR, CRITICAL

############################# CACHE ##############################
cache_path:                 %(cache_path)-15s # path to a directory with cache files
cache_mode:                 %(cache_mode)-15s # ON, OFF, REFRESH
# ON  - cache is used
# OFF - cache is not used
# REFRESH - everything is recalculated/fetched and stored in cache
"""%config()

def load_config(path="config.yaml",create_if_not_exists=True):
    """Load config from yaml file
    The configure() is run by this function.
    """
    global _config
    from os.path import exists
    if exists(path):
        with open(path) as f:
            _config=default_config()
            c=load(f,Loader=Loader)            
            _config.update(c)
        configure()
        return True
    else:
        with open(path,"w") as f:
            f.write(config_yaml())
        configure()
        return False
    
def configure_logging():
    "Configure the logger according to the current config"
    logging.basicConfig(filename=config()["log_file"],level=getattr(logging, config()["log_level"], config()["log_level"]))
    logging.getLogger().addHandler(logging.StreamHandler())

def configure_cache():
    "Configure the cache according to the current config"
    import core.caching.cache_driver as cd
    cd.set_cache_path(config()["cache_path"])
    cd.set_cache_mode(config()["cache_mode"])

def configure(**kwarg):
    """Configure the system (e.g. logging and cache) according to the current config
    This needs to be rerun always when configuration is changed by the user.
    
    """
    configure_logging()
    configure_cache()