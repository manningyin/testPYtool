# -*- coding: utf-8 -*-
import logging
import numpy as np
import pandas as pd
import quantum as qt
from functools import partial
from collections import OrderedDict
import csv
from core.caching.cache_driver import method_cache
import enum
import os
import os.path
from core.utils.date_helper import to_datetime
from tqdm import tqdm

import core.risk.local_scaling.impact_queries

logging.basicConfig(level=logging.DEBUG)

class DummyCurve:
    def getVal(self,x):
        return 1.0
DUMMY_CURVE=DummyCurve()

def mkdir(path):
    try:
        os.makedirs(path)
    except:
        pass

class LSFunctionType(enum.Enum):
    PRODUCTION=1
    NEW=2
    
class LocalScalingImpact:
    """
    Impact calculator object.
    Simplest use: VaR = LocalScalingImpact().calculate_VaR()
    """
    def __init__(self, app,
                    eod_date=None,
                    cons_org_id=None,
                    var_model=None,
                    term_based_evaluation=None,
                    production_interest_function_id=None,
                    production_ls_table=None,
                    production_ls_term_table=None,
                    new_interest_function_id=None,
                    new_ls_table=None,
                    new_ls_term_table=None,
                    name=None,
                    results=None
    ):
        import md5
        self.app=app
        self.sc_grp_id_names = {'102': 'Stressed period',
                                '2000': 'Historical period'}
        self.original_calibration = 'marsp.interest_function_value#2'

        uid = md5.new()
        rname=""
        for field in [        
                    "eod_date",
                    "cons_org_id",
                    "var_model",
                    "term_based_evaluation",
                    "production_interest_function_id",
                    "production_ls_table",
                    "production_ls_term_table",
                    "new_interest_function_id",
                    "new_ls_table",
                    "new_ls_term_table",
                    "results"]:
            setattr(self, field, app.data[field] if locals()[field] is None else locals()[field])
            uid.update(str(getattr(self,field,"")))
            uid.update("|*V*|")
            if len(rname):
                rname+="__"
            rname+=str(getattr(self,field,"")).replace(" ","_").replace(".","_").replace("#","-")

        print(rname)
        mkdir(self.results)
        self.term_based_evaluation = str(self.term_based_evaluation).lower() in ["true","y","yes","t","1"]
        self.rname=rname if name is None else name
        self.projections=None    
        self.loaded_eod_date = None
        self.loaded_cons_org_id = None
        self.uid=uid        
        self.iname=uid.hexdigest() if name is None else name
        self.with_empty_interest_map()
        self.with_fx2swap()

    def sc_interest_return_sum(self,eod_date,cons_org_id):
        "Query for sc_interest_return_sum"
        if self.var_model == "regulatory":
            return self.app.database.sc_interest_return_sum_regulatory(eod_date,cons_org_id)
        if self.var_model == "management":
            return self.app.database.sc_interest_return_sum_management(eod_date,cons_org_id)
        raise Exception("Unsupported VaR model:"+self.var_model)

    def sens_position_supergrp_id(self,linear=False):
        "Determine position_supergrp_id depending on the VaR model"
        if linear:
            if self.var_model == "regulatory":
                return "NLI"
            if self.var_model == "management":
                return "NI4"
            raise Exception("Unsupported VaR model:"+self.var_model)
        else:
            if self.var_model == "regulatory":
                return "FC"
            if self.var_model == "management":
                return "FC"
            raise Exception("Unsupported VaR model:"+self.var_model)
            
    def prefetching(self):
        "prefetches all data"
        mars = self.app.database
        if self.loaded_eod_date != self.eod_date:
            logging.info('Fetching interest')
            print('Fetching interest')
            self.interest = dict(mars.interest().loc[:,("INTEREST_ID","NAME")].values)
            logging.info('Fetching projections')
            print('Fetching projections')
            self.projections = dict(mars.interest_projection(self.eod_date).loc[:,("INTEREST_ID","PROJECTION_INTEREST_ID")].values)
            logging.info('Fetching term dates')
            print('Fetching term dates')
            self.term_dates = dict(mars.term_date(self.eod_date).loc[:,("TERM_ID","TERM_DATE")].values)
            logging.info('Fetching EOD rates')
            print('Fetching EOD rates')
            self.interest_rate = self.interest_rate_interpolated()
            logging.info('Fetching scenario')
            print('Fetching scenario')
            self.prefetch_sc_curves()
            self.loaded_eod_date = self.eod_date
            self.loaded_cons_org_id = None

        if self.loaded_cons_org_id != self.cons_org_id:
            logging.info('Fetching returns')
            print('Fetching returns')
            df=self.sc_interest_return_sum(self.eod_date,self.cons_org_id)
            self.returns = dict(zip(map(int,df.SC_ID),df.RTN))
            
            logging.info('Fetching sens_base')
            print('Fetching sens_base')
            df = mars.interest_sens(self.eod_date, self.cons_org_id, self.sens_position_supergrp_id())
            
            self.sens_base = dict(((row.INTEREST_ID, row.TERM_ID), row.SENS_BASE) for index,row in df.iterrows())
            self.loaded_cons_org_id = self.cons_org_id

#        logging.info('Fetching interest functions')
#        self.interest_function = dict(((table, row[0]), row[1])
#                                                   for table in (self.calibration_id, self.original_calibration)
#                                                   for row in self.get_interest_function(table)
#                                                   )
 #       self.fx2swap()
        self.local_scaling_function = dict()
        self.todays_function_values = dict()

        logging.info('Apply local scaling and build curves')
        print('Apply local scaling and build curves')
        self.apply_local_scaling()

    def prefetch_sc_curves(self):
        "get scenarios"
        mars = self.app.database
        domain = []
        shift_values = []
        rate_values = []

        projections = []
        interest_ids = []
        sc_term_ids = []
        sc_ids = []
        print ("Reading shifts")
#        for index,row in mars.sc_interest_shift(self.eod_date).iterrows():
#            if index%10000==0:
#                print (index)
#            interest_ids.append(row.PROJECTION_INTEREST_ID)
#           projections.append(self.projections[row.PROJECTION_INTEREST_ID])
#            sc_ids.append(row.SC_ID)
#            domain.append(self.term_dates[row.TERM_ID])
#           sc_term_ids.append(row.TERM_ID)
#            shift_values.append(row.END_VALUE - row.START_VALUE)
#           rate_values.append(row.START_VALUE)
        df = mars.sc_interest_shift(self.eod_date)
        print ("Postprocessing shifts 1")
        
        interest_ids=df.PROJECTION_INTEREST_ID.values
        projections=[self.projections[x] for x in interest_ids]
        sc_ids = df.SC_ID
        sc_term_ids = df.TERM_ID.values
        domain = [to_datetime(self.term_dates[x]) for x in sc_term_ids]
        shift_values = (df.END_VALUE - df.START_VALUE).values
        rate_values=df.START_VALUE.values
            
        print ("Postprocessing shifts 2")

        self.sc_domain = domain
        self.sc_term_ids = sc_term_ids

        self.sc_shift_values = np.array(shift_values)
        self.sc_rate_values = np.array(rate_values)
        self.sc_interest_ids = np.array(interest_ids)
        self.sc_projections = np.array(projections)
        self.raw_sc_ids = np.array(sc_ids)

        self.sc_rate_values = np.round(self.sc_rate_values,2)

        self.scenarios = list(set(self.raw_sc_ids))
        self.scenarios.sort()

    @method_cache
    def ls_function(self, function_type, interest_id, term_id=None, with_projections=True):
        """Return a local scaling function
        for function_type (LSFunctionType.PRODUCTION or NEW), interest_id and term_id.
        A function for a particular term_id is searched, which may fall back to per interest_id function
        (if term LSF is not found or not defined).
        The interest_id is mapped via self.interest_map (whcih is by default mapping FX curves to SWAP curves).
        Projections are used if the local scaling function is not found. This can be turned off with with_projections=False.        
        """
        #print ("ls_function(%(function_type)s, %(interest_id)s, %(term_id)s, %(with_projections)s)"%locals())
        if interest_id == 9332: # XXX-DUMMY curve
            return lambda x:1.0
        interest_id = self.interest_map.get(interest_id,interest_id)
        interest_ids = set([interest_id, self.projections[interest_id]] if with_projections else [interest_id])
        #print ("Interest IDs:"+str(interest_ids))
        for interest_id in interest_ids:
            if function_type == LSFunctionType.PRODUCTION:
                if self.production_ls_term_table not in [None,""] and term_id is not None:
                    d=self.get_interest_function("default",self.production_ls_term_table,self.production_interest_function_id)
                    f = d.get((interest_id,term_id))
                    if f is not None:
                        return f
                if self.production_ls_table not in [None,""]:
                    d=self.get_interest_function("default",self.production_ls_table,self.production_interest_function_id)
                    f = d.get((interest_id))
                    if f is not None:
                        return f
            elif function_type == LSFunctionType.NEW:
                if self.new_ls_term_table not in [None,""] and term_id is not None:
                    d=self.get_interest_function("new",self.new_ls_term_table,self.new_interest_function_id)
                    f = d.get((interest_id,term_id))
                    if f is not None:
                        return f
                if self.new_ls_table not in [None,""]:
                    d=self.get_interest_function("new",self.new_ls_table,self.new_interest_function_id)
                    f = d.get((interest_id))
                    if f is not None:
                        return f
                        
        raise Exception("LS Function not found: %s interest_id:%s term_id:%s"%(str(function_type),str(interest_id),str(term_id)))

    def apply_local_scaling(self):
        "Apply local scaling to loaded scenario and rates."
        # apply local scaling to historical shocks rates
        self.sc_curves = dict()
        for interest_id in tqdm(np.unique(self.sc_interest_ids)):
            term_ids = np.unique(self.sc_term_ids) if self.term_based_evaluation else [None]
            for term_id in term_ids:
                if term_id is None:
                    idx = np.where((self.sc_interest_ids == interest_id))[0]
                else:
                    idx = np.where((self.sc_interest_ids == interest_id) & (self.sc_term_ids==term_id))[0]
                #idx = np.where(self.sc_interest_ids == interest_id )[0]
                
                for function_type in LSFunctionType:
    #            for table in (self.calibration_id, self.original_calibration):
#                        f_value = self.interest_function[table, interest_id](
#                            np.round(self.sc_rate_values[idx],2))
                    f_value = self.ls_function(function_type,interest_id,term_id)(
                        np.round(self.sc_rate_values[idx],2))
                    shift_values = np.divide(self.sc_shift_values[idx], f_value)
                    sc_ids = self.raw_sc_ids[idx]
                    sc_domains = [to_datetime(self.sc_domain[i]) for i in idx]
                    for sc_id in self.scenarios:
#                        key = (table, interest_id, sc_id)
                        key = (function_type, interest_id, term_id, sc_id)
                        sc_id_idx = np.where(sc_ids == sc_id)[0]
                        if len(sc_id_idx):
                            sc_domain = [sc_domains[i] for i in sc_id_idx]
                            self.sc_curves[key] = qt.CurveLinear.make(sc_domain, shift_values[sc_id_idx])

        # apply local scaling to EOD rates
        self.current_function_value = dict()
        for interest_id in tqdm(np.unique(self.raw_interest_ids)):
            term_ids = np.unique(self.raw_term_ids) if self.term_based_evaluation else [None]
            for term_id in term_ids:
                if term_id is None:
                    idx = np.where((self.raw_interest_ids == interest_id))[0]
                else:
                    idx = np.where((self.raw_interest_ids == interest_id) & (self.raw_term_ids==term_id))[0]
#                idx = np.where(self.raw_interest_ids == interest_id)[0]
                current_domain = [to_datetime(self.raw_domain[i]) for i in idx]
                if len(idx):
                    for function_type in LSFunctionType:
    #                for table in (self.calibration_id, self.original_calibration):
                        key = (function_type, interest_id, term_id)
                        if self.projections[interest_id] == 9332:
                            logging.info("Ignore XXX-DUMMY (interest_id=9332)")
                            f_value=None
                        else:                        
                            f_value = self.ls_function(function_type,interest_id,term_id)(
                                np.round(self.raw_rate_values[idx],2))
                        if f_value is None:
                            value = DUMMY_CURVE
                        else:
                            value = qt.CurveLinear.make(current_domain, f_value)
                        self.current_function_value[key] = value
                else:
                    logging.error("No current interest rates selected for interest_id: %(interest_id)s term_id:%(term_id)s"%locals())
                    print("No current interest rates selected for interest_id: %(interest_id)s term_id:%(term_id)s"%locals())

    def interest_rate_interpolated(self):
        "Get eod_date rates"
        mars = self.app.database
        domain = []
        rate_values = []
        interest_ids = []
        term_ids=[]

        for index,row in mars.interest_rate(self.eod_date).iterrows():
            interest_ids.append(row.INTEREST_ID)
            domain.append(row.MATURITY_DATE)
            term_ids.append(row.TERM_ID)
            rate_values.append(row.INTEREST_PCT)

        self.raw_domain = domain
        self.raw_rate_values = np.array(rate_values)
        self.raw_interest_ids = np.array(interest_ids)
        self.raw_term_ids = np.array(term_ids)

    @method_cache
    def get_interest_function(self, database, table, interest_function_id):
        "Read all LSFs from a single table (and interest_function_id)"
        #currency_id = {row.INTEREST_ID: row.CURRENCY_ID for index,row in mars.interest().iterrows() if row.INTEREST_MARKET_ID in ['FX']}
        #swap_curve = {row.CURRENCY_ID: row.INTEREST_ID for index,row in mars.interest().iterrows() if row.INTEREST_MARKET_ID in ('SWP','SWAP')}
        db = self.app.databases[database]
        print ("get_interest_function(%(database)s, %(table)s, %(interest_function_id)s)"%locals())
        df = db.interest_function_raw(table=table,interest_function_id=interest_function_id)
        
        rates={}
        values={}
        for index,row in df.iterrows():
            if "TERM_ID" in df.columns:
                key = row.INTEREST_ID, row.TERM_ID
            else:
                key = row.INTEREST_ID
            rates[key]=rates.get(key,[])+[row.INTEREST_PCT]
            values[key]=values.get(key,[])+[row.VALUE]
        return {key:partial(np.interp, xp=rates[key], fp=values[key]) for key in sorted(rates.keys())}

#    def fx2swap(self):
#        "Obsolete"
#        mars = self.app.database
#        fx_curve = {row.INTEREST_ID: row.CURRENCY_ID for index,row in mars.interest().iterrows() if row.INTEREST_MARKET_ID in ['FX']}
#        swap_curve = {row.CURRENCY_ID: row.INTEREST_ID for index,row in mars.interest().iterrows() if row.INTEREST_MARKET_ID in ('SWP','SWAP')}
#        for interest_id, currency_id in fx_curve.items():
#            if interest_id <> self.projections[interest_id]:
#                continue
#            for table in (self.calibration_id, self.original_calibration):
#               fx_key = (table, interest_id)
#                swap_key = (table, swap_curve[currency_id])
#                self.interest_function[fx_key] = self.interest_function[swap_key]

    def with_fx2swap(self):
        """Initialize interest map, which maps FX curves to SWAP curves"""
        mars = self.app.database
        if self.projections is None:
            self.projections = dict(mars.interest_projection(self.eod_date).loc[:,("INTEREST_ID","PROJECTION_INTEREST_ID")].values)
        fx_curve = {row.INTEREST_ID: row.CURRENCY_ID for index,row in mars.interest().iterrows() if row.INTEREST_MARKET_ID in ['FX']}
        swap_curve = {row.CURRENCY_ID: row.INTEREST_ID for index,row in mars.interest().iterrows() if row.INTEREST_MARKET_ID in ('SWP','SWAP')}
        interest_map={}
        for interest_id, currency_id in fx_curve.items():
            if interest_id != self.projections[interest_id]:
                continue
            interest_map[interest_id]=swap_curve[currency_id]
        self.interest_map=interest_map
        return self
        
    def with_empty_interest_map(self):
        """Reset interest map"""
        self.interest_map={}
        return self
        
       
    def calculate_return_shift(self):
        "Calculates returns needed for VaR calculation"
        logging.info('Apply local scaling and build curves')
        self.prefetching()

        sens_base = []
        risk_factors = []
#        interest_ids = []

        for key, value in self.sens_base.iteritems():
            risk_factors.append(key)
            sens_base.append(value)

        sens_base = np.array(sens_base)

        logging.info('Calculating returns')
        for sc_id in self.scenarios:
            recalibrated_shock = np.zeros(sens_base.size) * np.nan
            current_shock = np.zeros(sens_base.size) * np.nan
            shock = np.zeros(sens_base.size) * np.nan

            for i, rf in enumerate(risk_factors):
                interest_id = rf[0]
                term_id = rf[1]
                term_date = to_datetime(self.term_dates[term_id])
                key_term_id = term_id if self.term_based_evaluation else None
                production_key=(LSFunctionType.PRODUCTION, interest_id, key_term_id)
                new_key=(LSFunctionType.NEW, interest_id, key_term_id)
                sc_production_key=(LSFunctionType.PRODUCTION, interest_id, key_term_id, sc_id) #In Arnold's there were projections here...
                sc_new_key=(LSFunctionType.NEW, interest_id, key_term_id, sc_id)
                try:
                    recalibrated_shock[i] = self.current_function_value[new_key].getVal(term_date) \
                                            * self.sc_curves[sc_new_key].getVal(term_date)
                    current_shock[i] = self.current_function_value[production_key].getVal(term_date) \
                                       * self.sc_curves[sc_production_key].getVal(term_date)
                except KeyError:
                    try:
                        production_key=(LSFunctionType.PRODUCTION, self.projections[interest_id], key_term_id)
                        new_key=(LSFunctionType.NEW, self.projections[interest_id], key_term_id)
                        sc_production_key=(LSFunctionType.PRODUCTION, self.projections[interest_id], key_term_id, sc_id)
                        sc_new_key=(LSFunctionType.NEW, self.projections[interest_id], key_term_id, sc_id)
                        
                        recalibrated_shock[i] = self.current_function_value[new_key].getVal(term_date)\
                                                * self.sc_curves[sc_new_key].getVal(term_date)
                        current_shock[i] = self.current_function_value[production_key].getVal(term_date)\
                                           * self.sc_curves[sc_production_key].getVal(term_date)
                    except KeyError:
                        logging.exception("Shift calculation failed for interest_id:%(interest_id)s term_id:%(key_term_id)s"%locals())
                        print("Shift calculation failed for interest_id:%(interest_id)s term_id:%(key_term_id)s"%locals())
                        recalibrated_shock[i] = 0
                        current_shock[i] = 0
                shock[i] = recalibrated_shock[i] - current_shock[i]

            yield sc_id, self.returns[sc_id], np.sum(np.multiply(current_shock, sens_base)), np.sum(np.multiply(shock, sens_base))


    def key_risk_factors(self, scenarios_idx):
        "Identifies key risk factors, requires worst days from .calculate_VaR()"
        self.prefetching()

        sens_base = []
        risk_factors = []
        interest_ids = []

        for key, value in self.sens_base.iteritems():
            risk_factors.append(key)
            sens_base.append(value)
            if self.projections[key[0]] not in interest_ids:
                interest_ids.append(self.projections[key[0]])

        sens_base = np.array(sens_base)
        interest_ids = np.array(interest_ids)
        interest_return = np.zeros(interest_ids.size)

        stats = OrderedDict()
        stats['Stressed'] = np.zeros(interest_ids.size)
        stats['Stressed loss'] = np.zeros(interest_ids.size)
        stats['Stressed gain'] = np.zeros(interest_ids.size)
        stats['Historical'] = np.zeros(interest_ids.size)
        stats['Historical loss'] = np.zeros(interest_ids.size)
        stats['Historical gain'] = np.zeros(interest_ids.size)
        logging.info('Calculating returns')
        for sc_idx in scenarios_idx:
            sc_id = self.scenarios[sc_idx]
            recalibrated_shock = np.zeros(sens_base.size) * np.nan
            current_shock = np.zeros(sens_base.size) * np.nan
            shock = np.zeros(sens_base.size) * np.nan

            for i, rf in enumerate(risk_factors):
                interest_id = rf[0]
                term_date = self.term_dates[rf[1]]
                try:
                    recalibrated_shock[i] = self.current_function_value[self.calibration_id, interest_id]\
                                                .getVal(term_date) \
                                            * self.sc_curves[self.calibration_id, self.projections[interest_id], sc_id]\
                                                .getVal(term_date)
                    current_shock[i] = self.current_function_value[self.original_calibration, interest_id]\
                                           .getVal(term_date) \
                                       * self.sc_curves[self.original_calibration, self.projections[interest_id], sc_id]\
                                           .getVal(term_date)
                except KeyError:
                    recalibrated_shock[i] = self.current_function_value[self.calibration_id, self.projections[interest_id]]\
                                                .getVal(term_date)\
                                            * self.sc_curves[self.calibration_id, self.projections[interest_id], sc_id]\
                                                .getVal(term_date)
                    current_shock[i] = self.current_function_value[self.original_calibration, self.projections[interest_id]]\
                                           .getVal(term_date)\
                                       * self.sc_curves[self.original_calibration, self.projections[interest_id], sc_id]\
                                           .getVal(term_date)
                shock[i] = recalibrated_shock[i] - current_shock[i]

            return_shift = np.multiply(shock, sens_base)
            for i, rf in enumerate(risk_factors):
                idx = np.where(interest_ids==self.projections[rf[0]])
                interest_return[idx] += return_shift[i]

            if sc_id < 3000:
                stats['Stressed'] += np.abs(interest_return)
                stats['Stressed loss'] += np.abs(np.minimum(interest_return,0))
                stats['Stressed gain'] += np.abs(np.maximum(interest_return,0))
            else:
                stats['Historical'] += np.abs(interest_return)
                stats['Historical loss'] += np.abs(np.minimum(interest_return,0))
                stats['Historical gain'] += np.abs(np.maximum(interest_return,0))


        topN = 10
        for key, value in stats.iteritems():
            print(key)
            for idx in np.argsort(-value)[:topN]:
                print(interest_ids[idx], value[idx], interest_ids[idx],
                      self.interest[interest_ids[idx]])

    def calculate_IRVaR(self):
        "Calculate impact on interest rate VaR and sVaR"
        file_name,file_name_xlsx = self.write()
        print(file_name)
        sc_grp = ('102', '2000')
        meas = ('orig', 'calc', 'new')
        Rtn = {(a, b): []
               for a in sc_grp
               for b in meas}
        VaR  = {}
        
        df=pd.read_excel(file_name_xlsx)

        for grp in sc_grp:
            index = df.sc_grp_id==int(grp)
            Rtn[grp,'orig']=df.loc[index,"return"].values
            Rtn[grp,'calc']=df.loc[index,"calculated_return"].values
            Rtn[grp,'new']=df.loc[index,"return"].values+df.loc[index,"shift"].values

        for a in sc_grp:
            for b in meas:
                i_Rtn = np.array(Rtn[(a, b)])
                if a == '102':
                    ind = np.argpartition(i_Rtn, 3)[:3]
                else:
                    ind = np.argpartition(i_Rtn, 3)[:6]
                VaR[(a,b)] = -np.sqrt(10.0) * np.sum(i_Rtn[ind]) / 1000.0 / len(ind)

        print('sVaR ', VaR[('102','orig')], ' -> ', VaR[('102','new')])
        print('cVaR ', VaR[('2000','orig')], '  -> ', VaR[('2000','new')])
        return VaR

    def write(self):
        "writes output of calclate_return_shift() to file"
        import re
        #pattern = re.compile("[a-zA-Z0-9_.-]+$")
        #fname = pattern.search(self.interest_function_id).group(0)
        fname=self.iname
        file_name = os.path.join(self.results,"_".join((self.eod_date,str(self.cons_org_id),fname))+'.csv')
        file_name_xlsx = os.path.join(self.results,"_".join((self.eod_date,str(self.cons_org_id),fname))+'.xlsx')
        if os.path.isfile(file_name) and os.path.isfile(file_name_xlsx):
            if os.path.getsize(file_name) > 0 and os.path.getsize(file_name_xlsx) > 0:
                logging.info(file_name)
                logging.info(file_name_xlsx)
                return file_name, file_name_xlsx

        data = [(
          to_datetime(self.eod_date).isoformat(),
          str(self.cons_org_id),
          self.rname,
          2000 if row[0] > 3000 else 102,
          row[0],
          row[1],
          row[2],
          row[3]
        ) for row in self.calculate_return_shift()]
                    
        df = pd.DataFrame(data,columns=('eod_date','cons_org_id', 'calibration', 'sc_grp_id', 'sc_id', 'return', 'calculated_return', 'shift'))
###################### CHECK VVVV        
        #df=mars.read_all_returns(df,to_datetime(self.eod_date).isoformat(),self.cons_org_id)
        #print(df.columns)
        #exit(0)
        writer = pd.ExcelWriter(file_name_xlsx)
        df.to_excel(writer)
        writer.save()
        writer.close()
        
        
        with open(file_name, 'wb') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(('eod_date','cons_org_id', 'calibration', 'sc_grp_id', 'sc_id', 'return', 'calculated_return', 'shift'))
            sc_grp_id = 102
            for row in self.calculate_return_shift():
                if row[0] > 3000:
                    sc_grp_id = 2000
                csvwriter.writerow((to_datetime(self.eod_date).isoformat(),str(self.cons_org_id),self.rname,sc_grp_id)+row)
        return file_name,file_name_xlsx

def VaR_data(app, start_date=None, end_date=None,
    cons_org_id=None,
    var_model=None,
    term_based_evaluation=None,
    production_interest_function_id=None,
    production_ls_table=None,
    production_ls_term_table=None,
    new_interest_function_id=None,
    new_ls_table=None,
    new_ls_term_table=None,
    name=None,
    results=None,
    var_data=None
):
    """Calculate VaR impact for a period between start_date and end_date"""
    import md5
    mars = app.database

    digest = md5.new()
    rname=""

    parameters={}
    for field in [        
                "start_date",
                "end_date",
                "cons_org_id",
                "var_model",
                "term_based_evaluation",
                "production_interest_function_id",
                "production_ls_table",
                "production_ls_term_table",
                "new_interest_function_id",
                "new_ls_table",
                "new_ls_term_table",
                "results",
                "var_data"]:
        parameters[field]=app.data[field] if locals()[field] is None else locals()[field]
        digest.update(str(parameters[field]))
        digest.update("|*V*|")
        if len(rname):
            rname+="__"
        rname+=str(parameters[field]).replace(" ","_").replace(".","_").replace("#","-")
    kwargs = {field:parameters[field] for field in ["cons_org_id",
                "var_model",
                "term_based_evaluation",
                "production_interest_function_id",
                "production_ls_table",
                "production_ls_term_table",
                "new_interest_function_id",
                "new_ls_table",
                "new_ls_term_table",
                "results"]}
    uid = digest.hexdigest()
    name = uid if name is None else name
    parameters["uid"]=uid

    dates = mars.eod_date_interval(from_date=parameters["start_date"],to_date=parameters["end_date"]).START_DATE.values

    data=[]
    
    try:
        mkdir(parameters["var_data"])
        cache_path=os.path.join(parameters["var_data"],"%(cons_org_id)s_%(uid)s.msg"%parameters)
        sheet_path=os.path.join(parameters["var_data"],"%(cons_org_id)s_%(uid)s.xlsx"%parameters)
        logging.info("VaR data caching: "+cache_path)        
    except:
        cache_path=None
        logging.error("VaR data not caching")
    
    df=None
    if cache_path is not None and os.path.exists(cache_path):
        try:
            logging.info("VaR data read: "+cache_path)
            df = pd.read_msgpack(cache_path)
            writer = pd.ExcelWriter(sheet_path, engine='xlsxwriter')
            df.to_excel(writer, sheet_name='Sheet1')
            return df
        except:
            logging.exception("VaR data read failed: "+cache_path)

    logging.info("VaR data recalculation: "+str(cache_path))
    for eod_date in dates:
        lsi = LocalScalingImpact(app, eod_date=eod_date, name=eod_date+"_"+name, **kwargs)
        VaR = lsi.calculate_IRVaR()
        data.append(dict(
            date = eod_date,
            prod_VaR = VaR[('2000', 'orig')],
            prod_sVaR =VaR[('102', 'orig')],
            VaR = VaR[('2000', 'new')],
            sVaR = VaR[('102', 'new')]
        ))
    df=pd.DataFrame(data)
    
    if cache_path is not None:
        logging.info("VaR data store: "+cache_path)        
        df.to_msgpack(cache_path)
        writer = pd.ExcelWriter(sheet_path, engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Sheet1')
    return df
