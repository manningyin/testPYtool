# -*- coding: utf-8 -*-
from core.utils.dbapp import Registry

app=Registry

app.database.register_query("scenarios",
    """SELECT sc_id FROM marsp.sc_grp_sc_dyn
    WHERE eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
      AND sc_grp_id in (102,2000)
      ORDER BY 1
    """,
    cached=True,
    tags=["scenario","scen","scenarios"],
    description="List of historical and stressed scenario ids")

app.database.register_query("interest_projection",
    """SELECT eod_date,
        rigm.rm_interest_supergrp_id,
        interest_id ,
        pim.projection_interest_id
      FROM marsp.rm_interest_grp_mapping rigm
      JOIN marsp.rm_interest_grp rig USING (rm_interest_grp_id)
      JOIN marsp.projection_interest_mapping pim USING (eod_date, interest_id, projection_id)
      WHERE rigm.rm_interest_supergrp_id = 2
      and eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
    """,
    cached=True,
    tags=["ir","interest","rate","rates","projection","projections"],
    description="Table of interest projections")

app.database.register_query("interest_sens",
    """WITH p AS (
        SELECT
            to_date('%(eod_date)s', 'yyyy-mm-dd') AS eod_date,
            %(cons_org_id)s as cons_org_id,
            '%(position_supergrp_id)s' as position_supergrp_id
        FROM DUAL
        ), irp AS (
            SELECT eod_date,
                rigm.rm_interest_supergrp_id,
                interest_id ,
                pim.projection_interest_id
            FROM p
            JOIN marsp.rm_interest_grp_mapping rigm USING (eod_date)
            JOIN marsp.rm_interest_grp rig USING (rm_interest_grp_id)
            JOIN marsp.projection_interest_mapping pim USING (eod_date, interest_id, projection_id)
            WHERE rigm.rm_interest_supergrp_id = 2
             and interest_id in (SELECT i.interest_id from marsp.interest i where i.interest_market_id not in ('CCS_OIS','CCS_LIB'))
        ), ir_sens AS (
        SELECT
            eod_date ,
            org_id,
            position_grp_id,
            a.product_id,
            interest_id ,
            a.term_id ,
            a.sens_base AS sens_base
        FROM p
        JOIN marsp.interest_sens a using (eod_date)
        JOIN marsp.cons_org_structure_std b using (org_id, cons_org_id)
        JOIN marsp.position_supergrp_position_grp c using (position_grp_id, position_supergrp_id)
        WHERE ABS(a.sens_base) > 1e-3
        )
        SELECT interest_id, term_id, sum(sens_base) as sens_base
        from ir_sens
        join irp using (eod_date, interest_id)
        group by interest_id, term_id
        having abs(sum(sens_base)) > 0
        order by 1, 2
    """,
    cached=True,
    tags=["ir","interest","rate","rates","sens","sensitivity","sensitivities","org","eod"],
    description="EOD Interest rate sensitivities of an org. unit")

app.database.register_query("sc_interest_return_sum_management",
    """WITH p AS (
        SELECT
            to_date('%(eod_date)s', 'yyyy-mm-dd') AS eod_date,
            %(cons_org_id)s as cons_org_id
        FROM DUAL
    ), returns as (
        SELECT --+full(b) leading(a b)
            eod_date ,
            'IR' AS var_type ,
            cons_org_id,
            sc_id ,
            c.sc_grp_id ,
            return_base AS rtn,
            d.position_supergrp_id
        FROM p
        JOIN marsp.cons_org_structure_std a using (cons_org_id)
        JOIN marsp.sc_interest_return_sum b using (eod_date, org_id)
        JOIN marsp.sc_grp_sc_dyn c using (eod_date, sc_id)
        JOIN marsp.POSITION_SUPERGRP_POSITION_GRP d using (position_grp_id)
        WHERE   b.rm_interest_supergrp_id = 2
        AND b.update_pgm_id           = 'INT_SC_SUM_SI'
        AND d.position_supergrp_id = 'NI4'
        AND c.sc_grp_id IN (102, 2000))
    select sc_id, sc_grp_id, sum(rtn) rtn return from returns
    group by sc_id, sc_grp_id
    order by 1,2
    """,
    cached=True,
    tags=["ir","interest","return","returns","management","mgmt","var","full","reval"],
    description="Select full reval IR scenario returns for management VaR")

app.database.register_query("sc_interest_return_sum_regulatory",
    """    WITH p AS (
        SELECT
            to_date('%(eod_date)s', 'yyyy-mm-dd') AS eod_date,
            %(cons_org_id)s as cons_org_id
        FROM DUAL
    ), returns as (
        SELECT --+full(b) leading(a b)
            eod_date ,
            'IR' AS var_type ,
            cons_org_id,
            sc_id ,
            c.sc_grp_id ,
            return_base AS rtn,
            d.position_supergrp_id
        FROM p
        JOIN marsp.cons_org_structure_std a using (cons_org_id)
        JOIN marsp.sc_interest_return_sum b using (eod_date, org_id)
        JOIN marsp.sc_grp_sc_dyn c using (eod_date, sc_id)
        JOIN marsp.POSITION_SUPERGRP_POSITION_GRP d using (position_grp_id)
        WHERE   b.rm_interest_supergrp_id = 3 -- Reg. VaR
        --AND b.update_pgm_id           = 'INT_SC_SUM_SI' -- Not needed ???
        AND d.position_supergrp_id = 'NLI' -- Reg VaR
        AND c.sc_grp_id IN (102, 2000))
    select sc_id, sc_grp_id, sum(rtn) rtn from returns
    group by sc_id, sc_grp_id
    order by 1,2
    """,
    cached=True,
    tags=["ir","interest","return","returns","regulatory","reg","var","full","reval"],
    description="Select full reval IR scenario returns for regulatory VaR")

app.database.register_query("sc_interest_return_management",
    """
    WITH p AS (
        SELECT
            to_date('%(eod_date)s', 'yyyy-mm-dd') AS eod_date,
            %(cons_org_id)s as cons_org_id
        FROM DUAL
        ), irp AS (
        SELECT eod_date,
            rigm.rm_interest_supergrp_id,
            interest_id ,
            pim.projection_interest_id
        FROM p
            JOIN marsp.rm_interest_grp_mapping rigm USING (eod_date)
            JOIN marsp.rm_interest_grp rig USING (rm_interest_grp_id)
            JOIN marsp.projection_interest_mapping pim USING (eod_date, interest_id, projection_id)
        WHERE rigm.rm_interest_supergrp_id = 2
            and interest_id in (SELECT i.interest_id from marsp.interest i where i.interest_market_id not in ('CCS_OIS','CCS_LIB'))
        ), returns as (
        SELECT --+full(b) leading(a b)
            eod_date ,
            'IR' AS var_type ,
            cons_org_id,
            sc_id ,
            c.sc_grp_id ,
            interest_id,
            return_base AS rtn,
            d.position_supergrp_id
        FROM p
        join irp using(eod_date)
        JOIN marsp.cons_org_structure_std a using (cons_org_id)
        JOIN marsp_reporting.sc_interest_return_v b using (eod_date, org_id, interest_id)
        JOIN marsp.sc_grp_sc_dyn c using (eod_date, sc_id)
        JOIN marsp.POSITION_SUPERGRP_POSITION_GRP d using (position_grp_id)
        WHERE   b.rm_interest_supergrp_id = 2
        AND b.update_pgm_id           = 'IRLINR'
        AND d.position_supergrp_id = 'FC'
        AND c.sc_grp_id IN (102, 2000))
    select sc_id, sc_grp_id, interest_id, sum(rtn) rtn from returns
    group by sc_id, sc_grp_id, interest_id
    order by 1,2    
    """,
    cached=True,
    tags=["ir","interest","return","returns","management","mgmt","var","linear"],    
    description="Select linear IRscenario returns for management VaR")

app.database.register_query("sc_interest_return_regulatory",
    """WITH p AS (
        SELECT
            to_date('%(eod_date)s', 'yyyy-mm-dd') AS eod_date,
            %(cons_org_id)s as cons_org_id
        FROM DUAL
        ), irp AS (
        SELECT eod_date,
            rigm.rm_interest_supergrp_id,
            interest_id ,
            pim.projection_interest_id
        FROM p
            JOIN marsp.rm_interest_grp_mapping rigm USING (eod_date)
            JOIN marsp.rm_interest_grp rig USING (rm_interest_grp_id)
            JOIN marsp.projection_interest_mapping pim USING (eod_date, interest_id, projection_id)
        WHERE rigm.rm_interest_supergrp_id = 3 -- Reg. VaR
            and interest_id in (SELECT i.interest_id from marsp.interest i where i.interest_market_id not in ('CCS_OIS','CCS_LIB'))
        ), returns as (
        SELECT --+full(b) leading(a b)
            eod_date ,
            'IR' AS var_type ,
            cons_org_id,
            sc_id ,
            c.sc_grp_id ,
            interest_id,
            return_base AS rtn,
            d.position_supergrp_id
        FROM p
        join irp using(eod_date)
        JOIN marsp.cons_org_structure_std a using (cons_org_id)
        JOIN marsp_reporting.sc_interest_return_v b using (eod_date, org_id, interest_id)
        JOIN marsp.sc_grp_sc_dyn c using (eod_date, sc_id)
        JOIN marsp.POSITION_SUPERGRP_POSITION_GRP d using (position_grp_id)
        WHERE   b.rm_interest_supergrp_id = 3
        -- AND b.update_pgm_id           = 'IRLINR'
        AND d.position_supergrp_id = 'FC'
        AND c.sc_grp_id IN (102, 2000))
    select sc_id, sc_grp_id, interest_id, sum(rtn) rtn from returns
    group by sc_id, sc_grp_id, interest_id
    order by 1,2
    """,
    cached=True,
    description="Select linear IR scenario returns for regulatory VaR")

app.database.register_query("interest",
    """
    SELECT interest_id, currency_id, name, interest_market_id
    FROM marsp.interest
    order by 1
    """,
    cached=True,
    cache_dataframe_in_memory = True,
    description="Table of interest IDs")

app.database.register_query("sc_interest_shift",
    """
            WITH p AS (
        SELECT
            to_date('%(eod_date)s', 'yyyy-mm-dd') AS eod_date
        FROM DUAL
    ), shift AS
    (SELECT a.timeinterval_id AS sc_id
      , A.INTEREST_ID as projection_interest_id
      , A.TERM_ID
      , C.INTEREST_PCT START_VALUE
      , A.QUOTIENT*C.INTEREST_PCT END_VALUE
    FROM MARSP.INTEREST_QUOTIENT a
    INNER JOIN MARSP.TIMEINTERVAL b
    ON  A.TIMEINTERVAL_ID = B.TIMEINTERVAL_ID
    INNER JOIN MARSP.HS_INTEREST_RATE c
    ON  C.INTEREST_ID = a.INTEREST_ID
    AND C.TERM_ID     = a.TERM_ID
    AND C.EOD_DATE    = b.START_DATE
    WHERE  A.MISSING_B = 'N'
    UNION ALL
    SELECT a.timeinterval_id AS sc_id
      , A.INTEREST_ID as projection_interest_id
      , A.TERM_ID
      , C.INTEREST_PCT START_VALUE
      , D.INTEREST_PCT END_VALUE
    FROM MARSP.INTEREST_QUOTIENT a
    INNER JOIN MARSP.TIMEINTERVAL b
    ON  A.TIMEINTERVAL_ID = B.TIMEINTERVAL_ID
    INNER JOIN MARSP.HS_INTEREST_RATE c
    ON  C.INTEREST_ID = a.INTEREST_ID
    AND C.TERM_ID     = a.TERM_ID
    AND C.EOD_DATE    = b.START_DATE
    INNER JOIN MARSP.HS_INTEREST_RATE d
    ON  d.INTEREST_ID = a.INTEREST_ID
    AND d.TERM_ID     = a.TERM_ID
    AND d.EOD_DATE    = B.END_DATE
    WHERE        A.MISSING_B = 'Y'
)
SELECT sc_grp_id, sc_id, projection_interest_id, term_id, start_value, end_value
FROM p
join marsp.sc_grp_sc_dyn using (eod_date)
JOIN shift USING (sc_id)
join marsp.ladder_term using (term_id)
where sc_grp_id in (102,2000)
and ladder_id = 68
order by 2,3, term_no    """,
    cached=True,
    description="Scenario interest shifts")

app.database.register_query("eod_date_interval",
    """
    SELECT start_date
    FROM MARSP.TIMEINTERVAL
    WHERE start_date >= to_date('%(from_date)s', 'yyyy-mm-dd')
    AND start_date   <= to_date('%(to_date)s', 'yyyy-mm-dd')
    order by 1
    """,
    cached=True,
    description="EOD date interval")

app.database.register_query("term_date",
    """
        SELECT term_id, term_date
        FROM marsp.term_date
        WHERE eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
        order by term_date
    """,
    cached=True,
    cache_dataframe_in_memory = True,
    description="Term dates for EOD")


app.database.register_query("interest_function_raw",
    """
    SELECT *
    FROM %(table)s a
    WHERE INTEREST_FUNCTION_ID = %(interest_function_id)s
    order by INTEREST_ID, INTEREST_PCT
    """,
    cached=True,
    description="All local scaling functions from a table")

app.database.register_query("interest_rate",
    """
    SELECT INTEREST_ID
        , term_id
        , maturity_date
        , INTEREST_PCT
    FROM marsp.interest_rate
    WHERE eod_date = to_date('%(eod_date)s', 'yyyy-mm-dd')
         and price_type_id            =  'INT'
    order by interest_id, maturity_date
    """,
    cached=True,
    description="Interest rates")


app.database.register_query("production_interest_function_raw",
    """
    SELECT INTEREST_FUNCTION_ID
        , INTEREST_ID
        , INTEREST_PCT
        , VALUE
    FROM %(table)s a
    WHERE INTEREST_FUNCTION_ID = %(interest_function_id)s
    order by INTEREST_ID, INTEREST_PCT
    """,
    cached=True,
    description="All local scaling functions from a table")

