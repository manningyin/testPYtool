"""
Module to calculate expected shortfall

This module should handle everything regarding to expected shortfall calculation
"""
import math
import warnings
import numpy as np
import pandas as pd
from core.position.valuation_service import scenario_pl

warnings.warn('core.risk.expected_shortfall is deprecated. Please redirect your ES / VaR calculations to core.risk.risk_measures')


def calculate_ES(pl_vector, quantile):
    """
    The function calculate the expected shortfall based on the input pl vector and quantile.
    We assume the function take the actual loss (negative means loss) and will return back the expected shortfall number
    (the loss expressed in positive term)

    quantile is expressed as percentage
    TODO: Quantile is given as function argument as (100-percentile)/100.

    Args:
        pl_vector     (list type):           Contain the scenario pl fields
        quantile          (float):           The quantile you want to calculate for

    Returns:
       (dataframe):     contain three fields,'ES', 'total Scenario','no of scenario in ES'

    Notes:
       Author: g48454

    Example:
        Suppose you want to calculate 97.5% of ES by given pl vector
        The module is called (from python) like this::
        
            something_returned = calculate_ES(scenarioPL=plvector, quantiles=0.025)
    """
    total_scenario = len(pl_vector)
    # ===================================================================================
    # step 1: sort the pl vector  ASCENDING
    # ===================================================================================
    pl_vector_sorted = sorted(pl_vector)

    # ===================================================================================
    # step 2: calculate how many scenario need for the quartile calculation.
    # and get the scenario from the sorted pl vector
    # ===================================================================================
    quantile_index = int(math.ceil(quantile * total_scenario))
    tail_returns = pl_vector_sorted[0:quantile_index]

    # ===================================================================================
    # step 3: calculate the average of the selected scenario, that is the expected shortfall
    # because expected shortfall is expressed in loss term, so loss is with positive sign.
    # ===================================================================================
    if len(tail_returns) > 0:
        expected_shortfall = -np.mean(tail_returns)
    else:
        expected_shortfall = None

    scenario_in_cal = len(tail_returns)
    return pd.DataFrame([[expected_shortfall, total_scenario, scenario_in_cal]],
                        columns=['ES', 'total_scenario', 'no_of_scenario_in_ES'])


def calculate_VaR(pl_vector, quantile):
    total_scenario = len(pl_vector)

    var = -np.nanpercentile(pl_vector, 100 * quantile)

    return pd.DataFrame([[var, total_scenario]], columns=['VAR', 'total_scenario'])


