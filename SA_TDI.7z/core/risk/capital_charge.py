from core.connection import database_connect
from core.utils import date_helper
import pandas as pd
import pyodbc


def load_SA_capital(eod_date):
    oracle_date = date_helper.oracle_to_date(eod_date)
    sql_str = """select a.eod_date, a.cons_org_id, b.name, a.risk capital, a.risk*12.5 REA
                 from MARSP.RC_RISK a, MARSP.RC_CATEGORY b
                 where a.cons_org_id = 50004
                 and a.rc_category_id = b.RC_CATEGORY_ID
                 and a.eod_date = %(oracle_date)s /* Results only on Wednesdays and EOM */
                 and a.rc_category_id in (9116,9117,9118,9119,9120)""" % locals()
    return pd.read_sql(sql_str, pyodbc.connect(database_connect.get_string('INFOP')))


def load_mars_var(eod_date, cons_org_id=50004):
    if eod_date.isoweekday() != 3:
        raise ValueError
    oracle_date = date_helper.oracle_to_date(eod_date)
    sql_str = """select eod_date, decode(rc_measure_id, 1, 'VaR', 208, 'sVaR') measure, risk
                 from marsp.rc_risk a
                 where a.cons_org_id = %(cons_org_id)s
                 and a.eod_date >= MARSP.DAGE.ADDERDAGE(%(oracle_date)s, -70, null, 'BNK')
                 and a.rc_category_id = 408
                 and a.rc_measure_id in (1, 208)
                 order by rc_measure_id, eod_date desc""" % locals()
    df = pd.read_sql(sql_str, pyodbc.connect(database_connect.get_string('INFOP')))
    var = df[df['MEASURE'] == 'VaR']
    svar = df[df['MEASURE'] == 'sVaR']
    t_1_var = var[1:2]['RISK'].tolist()[0]
    t_1_svar = svar[1:2]['RISK'].tolist()[0]
    var60avg = var[1:61]['RISK'].mean()
    svar60avg = svar[1:61]['RISK'].mean()
    return {'t_1_var': t_1_var,
            't_1_svar': t_1_svar,
            'var60avg': var60avg,
            'svar60avg': svar60avg}


def load_risk_figures(eod_date, cons_org_id=50004):
    if eod_date.isoweekday() != 3:
        raise ValueError
    oracle_date = date_helper.oracle_to_date(eod_date)


def ima_capital_charge(var, svar, irm, crm, var_avg, svar_avg, irm_avg, crm_avg,
                       var_mult=3.3, svar_mult=3.5, irm_mult=2.45, crm_mult=1.15, crm_floor=0):

    return (max(var_avg*var_mult, var)
            + max(svar_avg*svar_mult, svar)
            + irm_mult*max(irm_avg, irm)
            + max(crm_mult*max(crm_avg, crm), crm_floor))


if __name__ == '__main__':
    import datetime as dt
    print(load_mars_var(dt.datetime(2019,1,4)))