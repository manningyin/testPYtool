
"""
The  general frtb  prototype include some common functions include:
* I/O with excel spreadsheet
* error handling
* expected shortfall calculation
* scenario generation
* pnl attribution analysis
* back testing
* IMCC calculation
* NMRF estimation


Warning:
    This is a super class, and can not run it standalone, you need implement child class to make it work for each product.
    For inspiration, check the implementation on:

        - core.risk.frtb_credit.credit_prototype.py ( a prototype for bond product which use qt as pricing engine)
        - core.risk.frtb_credit.future_prototype.py ( a prototype for bond future product which use qt as pricing engine)
        - core.risk.frtb_credit.cds_prototype.py ( a prototype for bond future product which use cds as pricing engine)

Notes:
    Author: g48454 (Shengyao Zhu)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       14dec2016   G48454      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
# ======== Standard Code to add code-lib to PYTHONPATH ========
if __name__ == '__main__':
    import os, sys
    sys.path = list((x for x in sys.path if x.find('code-lib') == -1))  # Remove existing code-lib paths
    sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])    # Add current code-lib path
# =============================================================
import six
import orca
import quantum as qt
import orca.utilities.soap as soap
import numpy
import datetime
import pickle
import pandas as pd
from pandas.tseries.offsets import BDay
import traceback
import os
import core.system.guestbook as logging
import core.utils.date_helper as dateutils
from core.utils.git_helper import git_version
from core.utils.error_handler import track_error,clean_errors,ErrorHandler

class frtb_prototype:
    def __init__(self,Pos_Lists,name,analysisStartDate,analysisEndDate,resultFilePath='default'):
        """
        An initiaation function of the frtb prototype

        Args:
            Pos_Lists              (list of str):       List of position identifiers
            analysisStartDate      (datetime):          Start date of the analysis
            analysisEndDate      (datetime):            End date of the analysis

        Returns:
            a frtb prototype


        Warning:
            Actually, you are not suppose to call this initial function directly, all call should be done in the child class.

        Notes:
            Author: g48454
        """

        logging.checkin()

        self.username = os.environ['USERNAME']
        self.git_version = git_version()
        self.name = name
        self.Position_Lists = Pos_Lists
        self.analysisStartDate = analysisStartDate
        self.analysisEndDate = analysisEndDate
        # ===================================================================================
        # the stressed period is hard code here
        # ===================================================================================
        self.stressedStartPeriod = datetime.datetime(2008,9,23) # 2008-10-1 - 10 BDay
        self.stressedEndPeriod = datetime.datetime(2009,10,1)
        self.analysisRange = self.define_md_range(self.analysisStartDate, self.analysisEndDate)
        self.stressedRange = self.define_md_range(self.stressedStartPeriod,self.stressedEndPeriod)

        # ===================================================================================
        # verbose control whether the error handling module will print the information
        #
        # ===================================================================================
        self.verbose = False
        # ===================================================================================
        # Try log in functions
        # ===================================================================================
        try:
            self.login = orca.utilities.soap.login_from_file()
        except:
            self.login = orca.utilities.soap.soap_login_tipt7()
        # need to change default folder due to the share drive migration
        self.defaultCacheFolder = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/06 FRTB/13 Prototype/cache/'
        self.defaultResultFolder = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/06 FRTB/13 Prototype/result/'
        if resultFilePath == 'default':
            self.resultFileLocation = self.defaultResultFolder + self.username + '_frtb_prototype' \
                                      + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + '.xlsx'
        else:
            self.resultFileLocation=resultFilePath
        self.resultDataFrameList = []
        self.resultDataFrameName = []
        self.marketDataCache = []
        self.marketDataCacheLocation = []
        self.riskFactorLists = []
        self.class_name = self.__class__.__name__
        # set up the error recording panda dataframe
        clean_errors()
        self.errorMessageDataFrame = pd.DataFrame()

    def scenarioNPV(self,returnName):
        """
        You should implement a scenario NPV function in each of the prototype if want to calculate the ES number

        Notes:
            Author: g48454
        """
        raise NotImplementedError

    def raise_serious_error(self,message,position):
        print("----------serious error  ---------------")
        print(message)
        print("we will not continue on this position :" + position)
        self.Position_Lists.remove(position)
        print("-----------------------------------------")

        self.trackError(position=position,
                        comments=message)

    def trackError(self, errorMessage='', position='', date='', comments=''):
        """
        Add an error message to the error message function

        Returns:
            add one error message to the errorMessageDataFrame object in the frtb_prototype class
        """
        module_name = traceback.extract_stack(None, 2)[0][2]
        if date != '':
             date=dateutils.to_date_str(date)
        try:
            error_str = str(errorMessage.message)
        except:
            error_str = ""

        track_error(error_message= error_str,
                    identifier=position,
                    date = date,
                    comments = comments,
                    module_name=module_name)
        # moduleName=traceback.extract_stack(None, 2)[0][2] # get the function name
        # if date != '':
        #     date=dateutils.to_date_str(date)
        # if errorMessage=='':
        #     self.errorMessageDataFrame = self.errorMessageDataFrame.append(
        #     pd.DataFrame([[moduleName, '', Position, date, comments]],
        #     columns=['Module', 'System Error', 'Position', 'Date', 'Comments']))
        # else:
        #     self.errorMessageDataFrame=self.errorMessageDataFrame.append(
        #     pd.DataFrame([[moduleName,errorMessage.message,Position,date,comments]],
        #     columns=['Module','System Error','Position','Date','Comments']))
        #
        # if self.verbose:
        #     print("an error has been raised : " + errorMessage.message + '_' + comments)

    def return_func_name(self):
        """
        Return the function name of caller in the exception handling function
        """
        
        return traceback.extract_stack(None, 2)[0][2]

    def define_md_range(self,startd,endd):
        return pd.date_range(startd, endd, freq=BDay())

    def convert_to_date(self,x):
        x=dateutils.to_datetime(x)
        return x.date()


    def aggregatte_rtpl(self):
        RTPL_DataFrame = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_All')]
        df = RTPL_DataFrame.groupby(['Day1'],as_index=False).sum()
        df['Position'] = 'total'
        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('RTPL_Total')

    def plAttribution(self,rtpl_dataframename='RTPL_All'):
        """
        The code will perform pl attribution, the code will do the followings:
        1) work out how many months we need do pl attribution, depends on the startDate and endDate specifiied in class
        2) calculate average ratio (ratio 1) and variance ratio (ratio 2) for each position and each month


        Args:
            HPL (Dataframe): a Panda DataFrame contain following information 'Position', 'Day 1', 'Day 2'
            , unExplained_PL, HPL and RTPL
        Returns:
            pl attribution DataFrame : pl attribution DataFrame contain position, ratio1, ratio 2 and month

        Author:
            g48454

        Reviewd by:
            Nicolaj Schmit
        """
        
        noofPLAttributionMonths = (self.analysisEndDate.year - self.analysisStartDate.year) * 12  + \
                                  self.analysisEndDate.month - self.analysisStartDate.month +1
        df2=pd.DataFrame()

        try:
            RTPL_DataFrame=self.resultDataFrameList[self.resultDataFrameName.index(rtpl_dataframename)]
        except Exception as e:
            self.trackError(errorMessage=e,
                        comments='can not find RTPL DataFrame, the pl attribution can not be processed')
            return

        # ===================================================================================
        # The below code will do the following:
        # 1) get the unique positions from the data frame
        # 2) for each position, work out how many months need p&l attribution
        # 3) calculate p&l attribution results month by month, pos by pos
        # 4) output all of them to a data frame.
        # ===================================================================================
        try:
            unique_pos_list=RTPL_DataFrame['Position'].unique()
        except Exception as e:
            self.trackError(errorMessage=e,
                            comments='The RTPL is empty, the pl attribution can not be processed')
            return

        for currPos in unique_pos_list:
            # return the dataframe for pl attribution on this isin
            try:
                currISIN_PTPL_DataFrame=RTPL_DataFrame[RTPL_DataFrame['Position']==currPos]
            except Exception as e:
                self.trackError(errorMessage=e, position=currPos,
                                comments='pl attribution not working for this ISIN for all period')
                continue
            # loop on all these months
            currd=datetime.datetime(self.analysisStartDate.year, self.analysisStartDate.month, 1)
            for x in range(0,noofPLAttributionMonths):
                try:
                    nextd = qt.addTenor(date=currd, tenor='1M')
                    date_scope = (currISIN_PTPL_DataFrame['Day1'] >= self.convert_to_date(currd)) \
                                 & (currISIN_PTPL_DataFrame['Day1'] < self.convert_to_date(nextd))
                    dateFrameWithInScope=currISIN_PTPL_DataFrame[date_scope]
                    unExplainedPL=dateFrameWithInScope["unExplained_PL"]
                    HPL=dateFrameWithInScope.HPL
                    ratio1 = numpy.mean(unExplainedPL) / numpy.std(HPL,ddof = 1)
                    ratio2 = numpy.var(unExplainedPL) / numpy.var(HPL)
                except Exception as e:
                    self.trackError(errorMessage=e, position=currPos, date=currd,
                                    comments='pl attribution not working for this ISIN and this period')
                    ratio1='na'
                    ratio2='na'
                df_signleAnalysis = pd.DataFrame([[currPos, self.convert_to_date(currd), dateutils.to_date_str(nextd),
                                                   ratio1, ratio2
                                              ]],
                                            columns=['Position', 'start date', 'end date', 'ratio1', 'ratio2'
                                                     ])
                df2=df2.append(df_signleAnalysis)
                currd=nextd

        self.resultDataFrameList.append(df2)
        self.resultDataFrameName.append('ratio_'+rtpl_dataframename)

    def scenario_generator(self,common_dates_list,returnName,bumpRiskFactors,return_days = 10):
        """
        The code will generate the return based on risk factor
        
        Args:
             common_dates_list      (list of dates):    The scope of dates that you want to generate scenario
             returnName             (str):              Key word used for generate scenario, will be used in ES calculation part well.
             bumpRiskFactors        {list of str}:      The risk factor you want to bump
             return_days            (int):              The x day return
             
        Returns:
            A panda dataframe contain scenario

        Example:
            An example can be find in calculateESNumbers function implemented in frtb prototype

        Warning:
            current structural is not ideal, still try to optimize this part of code now (Shengyao)
        
        Notes:
            Author: g48454
        """
        
        df=pd.DataFrame()
        finalRFName = []
        for x in range(0, len(common_dates_list)):
            startd = common_dates_list[x]
            endd = startd + BDay(return_days)
            startd_str=dateutils.to_date_str(startd)
            endd_str=dateutils.to_date_str(endd)
            todayScenario=[]
            todayRFName=[]
            haveReturnToday=False
            for riskFactor in self.riskFactorLists:

                # ===================================================================================
                # generate scenario for risk free rate , bond swap basis and cdsspread, in principal, it can works for all curve obecjt
                # ===================================================================================
                if riskFactor in ['riskfreecurve','bondSwapBasis','cdsspread']:
                    item=self.marketDataCache.getObjectFromCacheSet(riskFactor)
                    try:
                        scenarioNumber,rfNameList=self.calculateReturnForCurve(item,startd,endd)
                        if riskFactor not in bumpRiskFactors:
                            scenarioNumber = [0] * len(rfNameList)
                        todayScenario = todayScenario + scenarioNumber
                        todayRFName = todayRFName + rfNameList
                        haveReturnToday = True
                    except:
                        haveReturnToday = False


                # ===================================================================================
                # generate scenario for z spread dyanmic
                # ===================================================================================
                if riskFactor in ['zSpread']:
                    scenarioNumber=[0] * len(self.Position_Lists)
                    try:
                        idx=self.resultDataFrameName.index('Zspread')
                        zSpreadResult=self.resultDataFrameList[idx]
                    except:
                        zSpreadResult=pd.DataFrame()

                    if riskFactor in bumpRiskFactors:
                        isinNumber=0
                        for currISIN in self.Position_Lists:
                            try:
                                startdDF = zSpreadResult.loc[(zSpreadResult['ISIN'] == currISIN)
                                                       & (zSpreadResult['INFO_DATE'] == startd_str)]
                                start_zspread = startdDF['ZSPREAD']
                                endDF = zSpreadResult.loc[(zSpreadResult['ISIN'] == currISIN)
                                                       & (zSpreadResult['INFO_DATE'] == endd_str)]
                                end_zspread = endDF['ZSPREAD']
                                scenarioNumber[isinNumber]=(end_zspread-start_zspread).values[0]
                                isinNumber=isinNumber+1
                            except:
                                haveReturnToday=False
                                continue
                    rfNameList = []
                    for currISIN in self.Position_Lists:
                        rfNameList.append('zspread_' + currISIN)
                    todayScenario = todayScenario + scenarioNumber
                    todayRFName = todayRFName + rfNameList


            if haveReturnToday:
                df_temp = pd.DataFrame([[dateutils.to_date_str(startd), dateutils.to_date_str(endd)] + todayScenario],
                                        columns=['start Day', 'end Day'] + todayRFName
                                        )
                df = df.append(df_temp)
                finalRFName=todayRFName

        df=df[['start Day', 'end Day'] + finalRFName]
        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('scenario_'+returnName)

    def calculateES(self,quantiles,returnName , calVaR = False):
        """
        Calculate ES based on the scenario NPV
        
        Args:
             scenarioNPV  (dataframe): a dataframe that contain scenarioNPV

        Returns:
            A panda dataframe contain ES calculation

        Example:
            An example can be find in calculateESNumbers function implemented in frtb prototype

        Notes:
            Author: g48454
        """
        
        from core.risk import risk_measures
        if calVaR:
            result_df_name = 'VaR result'
        else:
            result_df_name = 'ES result'

        inx=self.resultDataFrameName.index('scenario NPV_'+returnName)
        scenarioNPVResult=self.resultDataFrameList[inx]
        haveAlreadyCalculatedES=False
        try:
            df=self.resultDataFrameList[self.resultDataFrameName.index(result_df_name)]
            haveAlreadyCalculatedES=True
        except:
            df=pd.DataFrame()

        for currPos in self.Position_Lists:
            try:
                pl_vector=scenarioNPVResult.loc[(scenarioNPVResult['Position'] == currPos)
                                             & (scenarioNPVResult['Scenario Number'] != 'Base Scenario')].values.squeeze().tolist()
                if not calVaR:
                    temp_result = risk_measures.expected_shortfall(pl_vector, quantiles)
                    df = df.append(pd.DataFrame([[currPos, 'ES_' + returnName,temp_result['es'],
                                                temp_result['no_of_scenarios'],len(temp_result['tail'])]],
                                           columns=['Position','ES Calculation Name','ES10d','total_scenario','no_of_scenario_in_ES']))

                    df = df.append(pd.DataFrame([[currPos, 'VAR_' + returnName, temp_result['var'],
                                                  temp_result['no_of_scenarios']]],
                                                columns=['Position', 'VaR Calculation Name', 'VaR', 'total_scenario']))
            except Exception as e:
                if not calVaR:
                    self.trackError(errorMessage=e, position=currPos,
                                    comments='Can not calculate Expected ShortFall for this isin')
                    df=df.append(pd.DataFrame([[currPos,'ES_' + returnName, 'NA',0,0]],
                                              columns=['Position', 'ES Calculation Name', 'ES10d', 'total_scenario',
                                                       'no_of_scenario_in_ES']))
                else:
                    self.trackError(errorMessage=e, position=currPos,
                                    comments='Can not calculate Expected ShortFall for this isin')
                    df = df.append(pd.DataFrame([[currPos, 'VAR_' + returnName, 'NA', 0]],
                                                columns=['Position', 'VaR Calculation Name', 'VaR', 'total_scenario']))
                continue

        if haveAlreadyCalculatedES:
            self.resultDataFrameList[self.resultDataFrameName.index(result_df_name)]=df
        else:
            self.resultDataFrameList.append(df)
            self.resultDataFrameName.append(result_df_name)

    def back_testing(self):
        """
        This part of the code try to do the back testing (which is included in the definition of done :))

        The code will try to calculate 1d VaR and also list the daily pl vector in same excel, and user need check whether there are any outlier on the excel.


        Notes:
            Author: g48454
        """
        self.scenario_generator(common_dates_list=self.analysisRange,
                                returnName="backtesting",
                                bumpRiskFactors=self.riskFactorLists,
                                return_days=1)
        self.scenarioNPV(returnName = "backtesting")
        self.calculateES(quantiles=0.01,returnName="backtesting",calVaR=True)

        # parse hypithetical pnl
        pl_df = self.resultDataFrameList[self.resultDataFrameName.index('RTPL_All')][['Day1','Position','HPL']]

        # parse var number
        var_df = self.resultDataFrameList[self.resultDataFrameName.index('VaR result')]
        var_df_only_backtesting = var_df.loc[var_df["VaR Calculation Name"] == "VAR_backtesting"]

        final_df = pl_df.merge(var_df_only_backtesting,
                    left_on = "Position",
                    right_on = "Position",
                    how = "left")

        self.resultDataFrameList.append(final_df)
        self.resultDataFrameName.append("back_testing")





    def addScenarioToCurve(self,curve,scenario,asoft,buckets = None, floor_atzero = False):
        """
        add scenario to the curve
        """
        if buckets is None:
            buckets = self.riskFactorBuckets
        tempDateList=[]
        tempRateList=[]
        for k in range(0,len(buckets)-1):
            bucket=buckets[k]
            tempt=qt.addTenor(asoft,bucket)
            if abs(scenario[k]) < 10:
                tempRate=curve.getVal(tempt) + scenario[k]
            else:
                tempRate = curve.getVal(tempt)

            if floor_atzero:
                tempRate = max(tempRate,0.0001)

            tempDateList.append(tempt)
            tempRateList.append(tempRate)

        if type(curve) is qt.CurveCatrom:
            return qt.CurveCatrom.make(tempDateList, tempRateList)
        elif type(curve) is qt.CurveFlat:
            return qt.CurveFlat.make(tempDateList, tempRateList)

    def calculateReturnForCurve(self,curveCache,startd,endd):
    # calculate the return for curves between two dates
    # now only support absolute return
        riskFactorType = curveCache.name
        if riskFactorType in ['riskfreecurve','bondSwapBasis']:
            startCurve=curveCache.getvalue(startd)
            endCurve=curveCache.getvalue(endd)
            buckets = self.riskFactorBuckets
        elif riskFactorType in ['cdsspread']:
            startCurve = curveCache.getvalue(startd).hazardCurve
            endCurve = curveCache.getvalue(endd).hazardCurve
            buckets = self.cdsBuckets
        scenarioList=[]
        rate1List = []
        rate2List = []
        rfNameList = []

        for bucket in buckets:
            tempd1=qt.addTenor(startd,bucket)
            tempd2=qt.addTenor(endd,bucket)
            rate1=startCurve.getVal(tempd1)
            rate2=endCurve.getVal(tempd2)
            # only absolute return is supported
            scenarioList.append(rate2-rate1)
            rfNameList.append(riskFactorType+bucket)
            # this piece of code is for testing, wont impact on the overall numbers
            rate1List.append(rate1)
            rate2List.append(rate2)
        return scenarioList,rfNameList



    def putCacheIntoFile(self,path,varaible):
        with open(path, 'w') as f:  # Python 3: open(..., 'wb')
            pickle.dump(varaible, f)
        self.marketDataCacheLocation=path

    def loadCacheFromFile(self,path):

        last_moodification_date=os.path.getmtime(path)
        last_modification_datetime=datetime.datetime.utcfromtimestamp(last_moodification_date)
        delta_time=datetime.datetime.today()-last_modification_datetime
        if delta_time.days>5:
            print ('The data cache set you requested is created older than five days' )
            print ('--- the cashflow and price might changed in original database / web service')
            print('--- are you sure you want to continue?  type y to continue, other input will stop :')
            choice = raw_input().lower()
            if choice not in ['y']:
                print(' the program will stop')
                return

        with open(path) as f:  # Python 3: open(..., 'rb')
            obj=pickle.load(f)
        self.attachMarketDataCacheSet(obj)
        self.marketDataCacheLocation=path
        return obj

    def calculateESNumbers(self,dateRange,name,riskFactors,include_theta=False,info=1):
        """
        the code will do the following:
        1) call scenario generator to generate scenario
        2) call secnarioNPV function to perform scenario NOV
        3) call calculate ES function to calculate ES

        The function need the marketdata cache object has been loaded.


        Example:
            An example can be find in calculateIMCC function implemented in credit prototype

        Author:
            g48454
        """
        try:
            self.scenario_generator(
                common_dates_list=dateRange,
                returnName=name,
                bumpRiskFactors=riskFactors)
            # revaluate NPV under different scenario
            self.scenarioNPV(returnName=name, include_theta=include_theta)
            # revaluate NPV under different scenario
            self.calculateES(quantiles=0.025, returnName=name)
        except Exception as e:
            self.trackError(errorMessage=e ,
                            comments='ES calculation can not finished for ' + name)
            return
        if info==1:
            print('---ES calculation finished for: ' + name)

    def writeResultToExcel(self):
    ##################################################
    # write the dateframe created in each analysis into a result file
    ##################################################

        self.attachTheDisgnosticInformation()
        self.attachMarketDataInfo()
        writerObj = pd.ExcelWriter(self.resultFileLocation, engine='xlsxwriter')
        # output the results for all calculations
        for x in range(0,len(self.resultDataFrameName)):
            df=self.resultDataFrameList[x]
            try:
                self.writeToExcel_autoAdj(writer=writerObj,
                              sheetname=self.resultDataFrameName[x],
                              df=df)
            except Exception as e:
                self.trackError(errorMessage=e,comments='This DataFrame can not be write to excel: ' + self.resultDataFrameName[x] )

        # output the error messages
        errorobj = ErrorHandler.get_instance()
        self.errorMessageDataFrame = errorobj.error_df
        self.writeToExcel_autoAdj(writer=writerObj,
                                  sheetname='error message',
                                  df=self.errorMessageDataFrame)
        print('The calculation has been saved in: ' + os.path.normpath(self.resultFileLocation) )
        writerObj.save()

    def attachMarketDataInfo(self):
        df = pd.DataFrame()
        if hasattr(self.marketDataCache,"cacheList"):
            for market_data_cache in self.marketDataCache.cacheList:
                for date in market_data_cache.cacheDate:
                    df = df.append(pd.DataFrame(data = [[market_data_cache.name,date]],
                                                columns=['market data', 'date']))

        self.resultDataFrameList.append(df)
        self.resultDataFrameName.append('market data loaded')


    def attachTheDisgnosticInformation(self):
        # output the diagnostic information for the credit prototype information
        summaryDF = pd.DataFrame()
        if six.PY2:
            typs = [str, datetime.datetime,bool,float,unicode]
        else:
            typs = [str, datetime.datetime,bool,float]
        for key, value in self.__dict__.items():
            if (not key.startswith("__")) and type(value) in typs and key not in ['DAMD_concet_string']:
                tempdf = pd.DataFrame([[key, value]], columns=['key', 'value'])
                summaryDF = summaryDF.append(tempdf)
        for x in range(0, len(self.Position_Lists)):
            tempdf = pd.DataFrame([['Position-' + str(x), self.Position_Lists[x]]], columns=['key', 'value'])
            summaryDF = summaryDF.append(tempdf)

        self.resultDataFrameList.append(summaryDF)
        self.resultDataFrameName.append('Analysis Summary')

    def writeToExcel_autoAdj(self,writer,sheetname,df):
    # this code write the dataframe obj to excel, auto adjust the column width
        df.to_excel(writer, sheet_name=sheetname,index=False)  # send df to writer
        worksheet = writer.sheets[sheetname]  # pull worksheet object
        for idx, col in enumerate(df):  # loop through all columns
            series = df[col]
            try:
                max_len = max((
                    series.astype(str).map(len).max(),  # len of largest item
                    len(str(series.name))  # len of column name/header
                )) + 1  # adding a little extra space
            except Exception as e:
                max_len=100
                self.trackError(errorMessage='',comments='Can not decide max len for sheet name :' + sheetname)
            worksheet.set_column(idx, idx, max_len)  # set column width

    def attachMarketDataCacheSet(self,obj):
        self.marketDataCache=obj

