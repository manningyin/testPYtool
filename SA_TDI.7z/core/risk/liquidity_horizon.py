"""
Module for determining standard FRTB liquidity horizons for various asset classes

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       22feb2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

def fx_rate(foreign_currency,domestic_currency,info = 0):
    """
    Returns default (as per Basel text) liquidity horizons for fx pairs

    Args:
        foreign_currency    (str):      Standard three letter short-name for the "foreign" currency
                                        (also known as base or main)
        domestic_currency   (str):      Standard three letter short-name for the "domestic" currency
                                        (also known as quote or counter). Typically EUR

    Returns:
        (int):   Liquidity horizons (in days)

    Raises:

        
    Example:

        The module is called (from python) like this::
        
            lh = fx_rate(foreign_currency = 'USD', domestic_currency = 'EUR')

    Warning:

    Notes:
        Author: g50444
    """
    currency_pair = (foreign_currency,domestic_currency)

    liquid_currency_pairs = [
        ('USD', 'EUR'),
        ('USD', 'JPY'),
        ('USD', 'GBP'),
        ('USD', 'AUD'),
        ('USD', 'CAD'),
        ('USD', 'CHF'),
        ('USD', 'MXN'),
        ('USD', 'CNY'),
        ('USD', 'NZD'),
        ('USD', 'RUB'),
        ('USD', 'HKD'),
        ('USD', 'SGD'),
        ('USD', 'TRY'),
        ('USD', 'KRW'),
        ('USD', 'SEK'),
        ('USD', 'ZAR'),
        ('USD', 'INR'),
        ('USD', 'NOK'),
        ('USD', 'BRL'),
        ('EUR', 'JPY'),
        ('EUR', 'GBP'),
        ('EUR', 'CHF'),
        ('JPY', 'AUD'),
    ]

    if currency_pair in liquid_currency_pairs:
        liquidity_horizon = 10
    else:
        liquidity_horizon = 20

    return liquidity_horizon


if __name__ == '__main__':
    print(fx_rate('USD','DKK'))