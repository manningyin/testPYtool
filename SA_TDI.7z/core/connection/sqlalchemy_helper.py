import os
import re

from sqlalchemy import create_engine

import core.connection.credentials
import core.utils.encryption

__TNSNAMES = dict()
__ACTIVE_ENGINES = dict()


def parse_tns(var="", specific=""):
    """
    Reads in a TNS names file (as a string or file) and outputs a dictionary of all possible values.
    :param var: can be a string or file (default is empty string, will look for 'tnsnames.ora' file at the location
                    specified by 'TNS_ADMIN' system variable).
    :param specific: user choice of what keys they want returned. input list needs to be comma separated. if empty, all
                        TNS entries are returned.
    :return: database_dicts: all TNS entries in a clean dictionary.
    :return: database_specific: user choice of what keys they want returned.
    """
    def short_name(tnsname):
        return tnsname.upper().replace('.WORLD', '')
    tns = ""
    if var == "":
        for d in os.environ.get('PATH').split(';'):
            if os.path.exists(os.path.join(d, '../network/admin/tnsnames.ora')):
                file = os.path.join(d, '../network/admin/tnsnames.ora')
                break
        else:
            raise EnvironmentError('Cannot find tnsnames.ora in any location')
        with open(file, 'r') as sqlfile:
            text = sqlfile.read()
    else:
        if os.path.exists(var):
            with open(var, 'r') as sqlfile:
                text = sqlfile.read()
        elif type(var) is str:
            tns = var

    text = re.sub(r'#[^\n]*\n', '\n', text)  # remove comments
    text = re.sub(r'( *\n *)+', '\n', text.strip())  # remove excess blank lines

    databases = []
    start = 0
    index = 0
    while index < len(text):
        num_of_parenthesis = 0
        index = text.find('(')  # find first parenthesis
        while index < len(text):
            if text[index] == '(':
                num_of_parenthesis += 1
            elif text[index] == ')':
                num_of_parenthesis -= 1
            index += 1
            if num_of_parenthesis == 0:  # if == 0, we found all parenthesis for tns entry
                break

        databases.append(text[start:index].strip())
        text = text[index:]
        index = 0  # reset for next tns entry

    all_databases = {}
    for each in databases:
        clean = each.replace(" ", "").replace("\n", "")
        if clean.startswith('#'):
            continue
        database_name = re.match(r'([^=]+)=', clean).group().strip('=')
        connection_string = clean.replace(database_name, "").strip('=')
        short_name = database_name.upper().replace('.WORLD', '')
        __TNSNAMES[short_name] = connection_string

    if specific:
        specific_list = specific.upper().replace(' ', '').split(',')
        list_of_keys = all_databases.keys()
        found_list = []
        database_specific = {}

        for each in specific_list:
            # creates a regex statement to find any instance of 'each' in any of the keys
            reg = re.compile(".*(" + each + ").*")
            # searched the 'list_of_keys' for any instance of 'each' and returns the first instance
            found = [m.group() for i in list_of_keys for m in [reg.search(i)] if m]
            if found:
                for every in found:
                    found_list.append(every)

        for each in found_list:
            database_specific[each] = all_databases[each]

        return database_specific
    else:
        return __TNSNAMES


def engine_factory(tnsname, threaded=True):
    _tnsname = tnsname.upper().replace('.WORLD', '')
    if _tnsname not in __ACTIVE_ENGINES:
        if _tnsname not in __TNSNAMES:
            parse_tns()
        if _tnsname not in __TNSNAMES:
            raise ValueError('Not a valid TNSNAME %s', tnsname)
        # ask for username and password
        credentials = core.connection.credentials.get_personal_credentials(_tnsname)

        db_str = "oracle+cx_oracle://{user}:{password}@{dsn}".format(user=credentials['USER'],
                                                                     password=core.utils.encryption.decrypt(
                                                                         credentials['PASSWORD'],
                                                                         credentials['ENCRYPTION_TYPE']),
                                                                     dsn=__TNSNAMES[_tnsname])
        engine = create_engine(db_str, arraysize=100000, convert_unicode=True, threaded=threaded,
                               max_identifier_length=30, echo=False)
        # Test engine
        engine.connect()
        # todo when offsite -> sqlalchemy.exc.DatabaseError: (cx_Oracle.DatabaseError) ORA-12170: TNS:Connect timeout occurred
        __ACTIVE_ENGINES[_tnsname] = engine
    engine = __ACTIVE_ENGINES[_tnsname]
    return engine

if __name__ == '__main__':
    engine = engine_factory('INFOP')
    pass