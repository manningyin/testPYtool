
"""
Contains functions related to connecting to network locations, computers and servers.


Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       17may2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

def connect_to_server(server):
    """
    Connecting to network server, using stored credentials from the credentials module.

    Args:
        server      (str):  Name of the server or pc that you want to connect to.


    Example:
        The module is called (from python) like this::

            from core.utils import directory

            server = '//ap-risk5t'
            folder_path = '/frtb-csv/uat/d1'
            if not directory.is_accessible(server + folder_path):
                from core.connection import network
                network.connect_to_server(server)


    Warning:

    Notes:
        Author: g50444
    """
    import subprocess
    from core.connection import credentials
    from core.utils import encryption

    if server.startswith(r'\\') or server.startswith('//'):
        clean_server_name = server.replace(r'\\','').replace('//','')
    else:
        clean_server_name = server

    credentials = credentials.get_connection_info(clean_server_name)

    x = subprocess.call('net use /user:' +
                        credentials['USER'] + ' ' +
                        r'\\' + clean_server_name + ' ' +
                        encryption.decrypt(encrypted_string = credentials['PASSWORD'],
                                           encode_type= credentials['ENCRYPTION_TYPE'],
                                           )
                        )