# -*- coding: utf-8 -*-

'''
Module to get information from a sql query string.

It contains a function that returns the columns selected in a sql select string

Warning:

Notes:
    Author: g46987

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       18OCT2016   g50444      Initial creation (copy from code made by g50091)
    2       16FEB2017   g50444      Re-writing column names function. Making method more simple.
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''


def column_names(query, info = 0):
    """
    This function determines and returns which columns that will be extracted based on a sql select clause.

    The function uses a "scan text" approach, and does NOT connect to any databases.

    Args:
        query   (str):      A sql-style select query as "select a, b, c from x". Select * IT NOT supported
        info    (int):      OPTIONAL! Level of information printed. The higher, the more information is printed

    Returns:
        (list): List of column names

    Example:
        The module is called (from python) like this::

            from core.connection import query_info

            columns = query_info.column_names('select a.price_id, price, a.eod_date as date from table a')

    Warning:
        The function does currently not support "select as" (select x as y) statements

    Notes:
        Author: g50091
    """

    # ===================================================================================
    # Getting "select-part" of the query.
    # That is, everything before first "from" statement
    # ===================================================================================

    select_statement = query[:query.upper().replace('\n', ' ').find(' FROM ')]

    # Empty list which will be filled with colum names
    columns = []

    # ===================================================================================
    # Looping over all elements in the select statement (separated by commas),
    # taking the last word of each element as being the name of the column returned
    # from the query.
    #
    # While doing this we keep track of open parenthesis, making sure not to return
    # anything if we are inside an non-closed parenthesis.
    #
    # Appending the column names to the list of column names
    # ===================================================================================
    open_parenthesis_count = 0
    for select_part in select_statement.rsplit(','):
        column_name = select_part.rsplit(None, 1)[-1].rsplit('.', 1)[-1].replace('(*)','')
        clean_column_name = column_name.replace('(*)','').replace(')','')

        open_parenthesis_count += (select_part.count('(') - select_part.count(')'))
        if open_parenthesis_count == 0:
            columns.append(clean_column_name.upper())

    return columns

if __name__ == '__main__':
    from core.connection import query_info

    columns = query_info.column_names("""
        SELECT min(a.b), max(c.d) cd from a,b
        """)
    print(columns)