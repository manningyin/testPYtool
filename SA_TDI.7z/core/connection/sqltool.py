
"""from pyparsing import Word, delimitedList, Optional, \
    Group, alphas, alphanums,  \
    restOfLine, Keyword, upcaseTokens, Regex, NotAny, Suppress"""
import re
import logging
import datetime
import core.utils.date_helper as dateutils
from decimal import Decimal

def select_raw_column_names(query):
    """
    Similar function has already exists in core (core.connection.query_info.column_names())

    This function has been changed to use existing module. Call of this module should be changed, in order to reduce
    duplicate functions in the code library.
    """
    from core.connection import query_info

    return query_info.column_names(query)

def convert_decimal(row):
    """Convert numbers represented as Decimal to either int or float."""
    out=[]
    for x in row:
        if type(x) is Decimal:
            if int(x)==x:
                out.append(int(x))
            else:
                out.append(float(x))
        else:
            out.append(x)
    return out

def table_query(cursor,table,schema="MARSP",condition=None):
    fields = table_fields(cursor=cursor,schema=schema,table=table)
    query_fields = ",\n".join("  "+x["column_name"].upper() for x in fields)
    query="SELECT %s\nFROM %s.%s\n"%(query_fields,schema,table)
    if condition in (None,""):
        return query
    else:
        return query+"WHERE\n"+condition
    
def query_iterator(query, keys=None, datetime_as_date_string=False, **kwarg0):
    """Convert a sql query string to a function.
    """    
    def qf(query=query, keys=keys, **kwarg):
        cursor=kwarg["cursor"]
        arg={}
        arg.update(kwarg0)
        arg.update(kwarg)        
        sql = query%arg
        logging.debug(sql)
        if keys is None:
            keys = [x.lower() for x in select_raw_column_names(query)]
        cursor.execute(sql)
        while True:
            row = cursor.fetchone()
            if row is None:
                break
            row = convert_decimal(row)
            if datetime_as_date_string:
                row = [(dateutils.date_format(x) if type(x) is datetime.datetime else x) for x in row]
            d=dict(zip(keys,row))
            yield d
    return qf

def query_iterator_with_sql(query, keys=None, datetime_as_date_string=False, **kwarg0):
    """Convert a sql query string to a function.
    The returned function returns the expanded sql query as a first result of an iterator.
    
    """    
    def qf(query=query, keys=keys, **kwarg):
        cursor=kwarg["cursor"]
        arg={}
        arg.update(kwarg0)
        arg.update(kwarg)        
        sql = query%arg
        logging.debug(sql)
        yield sql
        if keys is None:
            keys = [x.lower() for x in select_raw_column_names(query)]
        cursor.execute(sql)
        while True:
            row = cursor.fetchone()
            if row is None:
                break
            row = convert_decimal(row)
            if datetime_as_date_string:
                row = [(dateutils.date_format(x) if type(x) is datetime.datetime else x) for x in row]
            d=dict(zip(keys,row))
            yield d
    return qf

def query_all_with_sql(query, keys=None, datetime_as_date_string=False, **kwarg0):
    """
    Convert a sql query string to a function.
    The returned function returns a tuple with two elements:
    - list of rows (as dictionaries) and
    - sql query.
    """
    def qf(query=query, keys=keys, **kwarg):
        cursor=kwarg["cursor"]
        arg={}
        arg.update(kwarg0)
        arg.update(kwarg)        
        sql = query%arg
        logging.debug(sql)
        
        if keys is None:
            keys = [x.lower() for x in select_raw_column_names(query)]
        cursor.execute(sql)
        rows=[]
        while True:
            row = cursor.fetchone()
            if row is None:
                break
            row = convert_decimal(row)
            if datetime_as_date_string:
                row = [(dateutils.date_format(x) if type(x) is datetime.datetime else x) for x in row]
            d=dict(zip(keys,row))
            rows.append(d)
        return rows,sql
    return qf
    
def create_sql_condition(values,table_fields):
    global formatTypeMap
    query=""
    sep     = "\n     "

    table_fields_dictionary = dict((field["column_name"].lower(),field) for field in table_fields)
    
    for key,value in values:
        field = table_fields_dictionary[key.lower()]
        format_function = formatTypeMap.get(field["data_type"],format_string)
        query += sep+"%-15s"%key.upper()
        if type(value) in (list,tuple):
            query += " IN ("+(", ".join(map(format_function,value)))+")\n"
        else:
            query += " = " + format_function(value) + "\n"            
        sep = "\n AND "
    return query

def date_between_condition(from_date=None,to_date=None,and_prefix=False,field="EOD_DATE"):
    prefix = "AND " if and_prefix else ""
    if from_date is None:
        if to_date is None:
            date_condition=""  
        else:
            t = dateutils.to_datetime(to_date)
            date_condition=prefix+field+t.strftime(" <= to_date('%Y-%m-%d', 'yyyy-mm-dd')")
    else:
        if to_date is None:
            t = dateutils.to_datetime(from_date)
            date_condition=prefix+field+t.strftime(" >= to_date('%Y-%m-%d', 'yyyy-mm-dd')")
        else:
            t1 = dateutils.to_datetime(from_date)
            t2 = dateutils.to_datetime(to_date)
            date_condition=prefix+field+t1.strftime(" BETWEEN to_date('%Y-%m-%d', 'yyyy-mm-dd') ")
            date_condition+=t2.strftime("AND to_date('%Y-%m-%d', 'yyyy-mm-dd')")
    return date_condition
    
class TableAccess:
    def __init__(self,cursor,table,schema):
        self.cursor=cursor
        self.table=table
        self.schema=schema
        self.table_query=table_query(cursor,table,schema)
        self.table_id = self.table.lower()+"_id"
        self.table_fields = table_fields(cursor,table,schema)
        
    def query(self,id=None,**kwarg):
        if id is not None:
            kwarg[self.table_id]=id
        return self.table_query+create_sql_condition(kwarg,self.table_fields)
    def __call__(self,id=None,**kwarg):
        pass
    
def query_single(query, keys=None, datetime_as_date_string=False, **kwarg0):
    """Convert a sql query string to a function.
    """    
    def qf(query=query, keys=keys, **kwarg):
        arg={}
        arg.update(kwarg0)
        arg.update(kwarg)        
        try:
            return next(query_iterator(query=query,datetime_as_date_string=datetime_as_date_string)(**arg))            
        except StopIteration:
            return None
    return qf

def query_single_with_sql(query, keys=None, datetime_as_date_string=False, **kwarg0):
    """Convert a sql query string to a function.
    Returns a tuple with the dictionary of values representing the first row returned by the query (or None if nothing is returned)
    as first and the query itself as a second tuple element.
    """    
    def qf(query=query, keys=keys, **kwarg):
        arg={}
        arg.update(kwarg0)
        arg.update(kwarg)        
        it = query_iterator_with_sql(query=query,datetime_as_date_string=datetime_as_date_string)(**arg)
        sql=next(it)
        try:
            return next(it),sql            
        except StopIteration:
            return None,sql
    return qf
    
def table_id_query(cursor,table,schema="MARSP",datetime_as_date_string=False):
    def qf(identifier):
        identifier = "'%s'"%identifier if type(identifier) is str else str(identifier)
        query=table_query(cursor,table=table,schema=schema,condition="%s_ID = %s"%(table.upper(),identifier))
        return query_single(query=query,cursor=cursor,datetime_as_date_string=datetime_as_date_string)()
    return qf

def table_id_query_with_sql(cursor,table,schema="MARSP",datetime_as_date_string=False):
    def qf(identifier):
        identifier = "'%s'"%identifier if type(identifier) is str else str(identifier)
        query=table_query(cursor,table=table,schema=schema,condition="%s_ID = %s"%(table.upper(),identifier))
        return query_single_with_sql(query=query,cursor=cursor,datetime_as_date_string=datetime_as_date_string)()
    return qf

    
table_fields_raw = query_iterator("""
SELECT
  t.OWNER,
  t.TABLE_NAME,
  t.COLUMN_NAME,
  t.DATA_TYPE,
  c.COMMENTS
FROM
  SYS.ALL_TAB_COLUMNS t,
  SYS.ALL_COL_COMMENTS c
WHERE
  t.OWNER='%(owner)s' AND t.TABLE_NAME='%(table)s' AND
  c.OWNER='%(owner)s' AND c.TABLE_NAME='%(table)s' AND
  t.COLUMN_NAME = c.COLUMN_NAME
""")

def table_fields(cursor,table,schema="MARSP"):
    """Returns list of table fields.
    
    Returns s list of dictionaries, each dictionary describing a field (column) of a database table.
    Each dictionary will have at least "column_name" key and "data_type" key.
    """
    fields = []
    for field in table_fields_raw(cursor=cursor,table=table,owner=schema):
        f={}
        f.update(field)
        f["data_type"] = f["data_type"].replace("("," ").split()[0].upper()
        fields.append(f)
    return fields
    
sqliteTypeMap=dict(
    CLOB           = "TEXT",
    TIMESTAMP      = "TEXT",
    RAW            = "BLOB",
    DATE           = "TEXT",
    FLOAT          = "REAL",
    XMLTYPE        = "TEXT",
    NCHAR          = "TEXT",
    NUMBER         = "NUMERIC",
    ROWID          = "INTEGER",
    BINARY_FLOAT   = "REAL",
    CHAR           = "TEXT",
    VARCHAR2       = "TEXT",
    ANYDATA        = "BLOB",
    INTERVAL       = "TEXT",
    NCLOB          = "TEXT",
    BLOB           = "BLOB",
    BINARY_DOUBLE  = "REAL",
    NVARCHAR2      = "TEXT",
    UNDEFINED      = "BLOB",
    LONG           = "INTEGER",
    UROWID         = "INTEGER"
)

def escape(text):
    return re.sub(r'[^\x00-\x7F]','?', str(text)).replace("'","''")

def format_timestamp(timestamp):
    "Format a timestamp to sql query"
    t = dateutils.to_datetime(timestamp)
    return t.strftime("TIMESTAMP '%Y-%m-%d %H:%M:%S'")
    
def format_date(date):
    "Format a date to sql query"
    t = dateutils.to_datetime(date)
    print (t)
    return t.strftime("to_date('%Y-%m-%d', 'yyyy-mm-dd')")
    #return t.strftime("DATE '%Y-%m-%d'")

def format_timestamp_sqlite(timestamp):
    "Format a timestamp to sql query for sqlite"
    t = dateutils.to_datetime(timestamp)
    return t.strftime("'%Y-%m-%d %H:%M:%S'")
    
def format_date_sqlite(date):
    "Format a date to sql query for sqlite"
    t = dateutils.to_datetime(date)
    return t.strftime("'%Y-%m-%d'")
    
def format_string(x):
    "Format a string to sql query"
    return "'%s'"%escape(x)    
def format_float(x):
    "Format a floating point number to sql query"
    return "%g"%float(x)
def format_int(x):
    "Format an integer number to sql query"
    return "%g"%int(x)
    
formatTypeMap=dict(
    CLOB           = format_string,
    TEXT           = format_string,
    TIMESTAMP      = format_timestamp,
    DATE           = format_date,
    FLOAT          = format_float,
    NUMERIC        = format_float,
    REAL           = format_float,
    NCHAR          = format_string,
    NUMBER         = format_float,
    ROWID          = format_int,
    BINARY_FLOAT   = format_float,
    CHAR           = format_string,
    VARCHAR2       = format_string,
    NCLOB          = format_string,
    BINARY_DOUBLE  = format_float,
    NVARCHAR2      = format_string,
    LONG           = format_int,
    INTEGER        = format_int,
    UROWID         = format_int,
)

formatTypeMapSqlite=dict(formatTypeMap.items())
formatTypeMapSqlite.update(dict(
    TIMESTAMP      = format_timestamp_sqlite,
    DATE           = format_date_sqlite,
))

defaultValueTypeMap=dict(
    CLOB           = "",
    TEXT           = "",
    TIMESTAMP      = "1900-01-01 00:00:00",
    DATE           = "1900-01-01",
    FLOAT          = 0,
    NUMERIC        = 0,
    REAL           = 0,
    NCHAR          = "",
    NUMBER         = 0,
    ROWID          = 0,
    BINARY_FLOAT   = 0,
    CHAR           = "",
    VARCHAR2       = "",
    NCLOB          = "",
    BINARY_DOUBLE  = 0,
    NVARCHAR2      = "",
    LONG           = 0,
    INTEGER        = 0,
    UROWID         = 0,
)

def format_parameters(dictionary,fields,format_map):
    """Formats values of a dictionary as strings that can be passed to SQL code.
    
    dictionary - contains dictionary of arguments
    fields - list of dictionaries, that must contain "column_name" and "data_type" keys describing the required output.
    format_map - dictionary converting type to a format functions, typically formatTypeMap or formatTypeMapSqlite
    """
    d={}
    for field in fields:
        key           = field["column_name"].lower()
        field_type    = field["data_type"]
        default_value = defaultValueTypeMap.get(field_type,"")
        format_field  = format_map.get(field_type,format_string)
        value         = dictionary.get(key,default_value)
        d[key]        = format_field(value)
    return d
    
        
def sqlite_table_clone_create_statement(cursor,table,created_table=None, schema="MARSP",sqlite_type_map=None):
    """Returns a SQL CREATE statement for creating a clone of a oracle database table.
    cursor - cursor to an oracle database
    table  - name of a table to be cloned
    created_table - name of a table to be created, if None, the table will be used
    schema - database schema of a table to be cloned
    sqliteTypeMap - dictionary mapping oracle data types to sqlite types; None means default mapping
    """
    created_table = table if created_table is None else created_table
    sqlite_type_map = sqliteTypeMap if sqlite_type_map is None else sqlite_type_map    
    
    sql="CREATE TABLE IF NOT EXISTS %s (\n"%created_table
    sep=""                                    
    for field in table_fields(cursor=cursor,schema=schema,table=table):
        t=field["data_type"].replace("("," ").split()[0]

        sql += sep+"  %-20s %s"%(field["column_name"],sqlite_type_map.get(t,"TEXT"))
        sep=",\n"
    sql+="\n)\n"
    return sql

def table_insert_statement(cursor,table,insert_table=None, schema="MARSP"):
    """Returns a SQL INSERT statement for inserting whole row into a table from a dictionary.
    cursor - cursor to an oracle database - needed to get column names and types
    table  - name of a table to be queried for column names and types
    insert_table - name of a table to be inserted to, if None, the table will be used
    schema - database schema associated with table
    """
    insert_table = table if insert_table is None else insert_table
    
    sql="INSERT INTO %s (\n"%insert_table
    sep=""                                    
    for field in table_fields(cursor=cursor,schema=schema,table=table):
        sql += sep+"  %s"%field["column_name"]
        sep=",\n"
    sql+="\n)\nVALUES (\n"
    sep=""                                    
    for field in table_fields(cursor=cursor,schema=schema,table=table):
        sql += sep+"  %%(%s)s"%(field["column_name"].lower())
        sep=",\n"
    sql+="\n)\n"
    return sql

def clone_table_to_sqlite_database(source_connection,destination_connection,table,source_table=None,destination_table=None,source_schema="MARSP",condition=None):
    """Clone table.
    
    This can be used to clone (part of an) oracle table, e.g. to a sqlite database.
    """
    source_cursor=source_connection.cursor()
    destination_cursor=destination_connection.cursor()
    source_table = table if source_table is None else source_table
    destination_table = table if destination_table is None else destination_table
    
    logging.info("Cloning %(source_schema)s.%(source_table)s to sqlite table %(destination_table)s"%locals())
    create_table_sql=sqlite_table_clone_create_statement(source_cursor,source_table,created_table=destination_table,schema=source_schema)
    logging.debug("Create sqlite table %(destination_table)s"%locals())
    logging.debug(create_table_sql)
    destination_cursor.execute(create_table_sql)

    select_sql = table_query(source_cursor,table=source_table,schema=source_schema,condition=condition)
    logging.debug("Query table %(source_table)s"%locals())
    logging.debug(select_sql)

    insert_sql = table_insert_statement(source_cursor, source_table, insert_table=destination_table, schema=source_schema)
    logging.debug("Insert to %(destination_table)s"%locals())
    logging.debug(insert_sql)

    fields = table_fields(cursor=source_cursor,table=source_table,schema=source_schema)
    for i,row in enumerate(query_iterator(select_sql)(cursor=source_cursor)):        
#        logging.debug(format_parameters(row,fields,format_map=formatTypeMapSqlite))
#        logging.debug(insert_sql%format_parameters(row,fields,format_map=formatTypeMapSqlite))
        destination_cursor.execute(insert_sql%format_parameters(row,fields,format_map=formatTypeMapSqlite))
        if i%100==0:
            logging.info("Cloning row %d"%i)
            destination_connection.commit()
    destination_connection.commit()
#    destination_cursor.execute("COMMIT")

