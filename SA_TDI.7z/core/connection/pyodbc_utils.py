"""
PYODBC database connector utility functions.

Exposes some built-in functionality of the PYODBC package (SQL-database connections).

**Example:**
 Run unit-test
    .../code-lib/unit_test/connection/test_db_connection.py

Notes:
    Author: g46474

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       16mar2017   G46474      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""


import pyodbc


# immutable
def get_column_names(cursor=None):
    """
    Tuple of column names. \n
    :param pyodbc.Cursor.execute() cursor: Provided by database read.
    """
    names = []
    for attribute in cursor.description:
        names.append(attribute.__getitem__(0))
    return tuple(names)


# TODO: implement immutable mapping type, i.e. frozenDict
# mutable
def get_column_names_and_types(cursor=None):
    """
    Dictionary of column names and resulting *Python types* (=types database entries are *converted to* automatically).\n
    :param pyodbc.Cursor.execute() cursor: Provided by database read.
    """
    name_type = dict()
    for attribute in cursor.description:
        name = attribute[0]
        type = attribute[1]
        name_type[name] = type
    return name_type


# TODO: not working
#def get_row_count(cursor=None):
#    from itertools import tee
#    # "clone" of iterator (cursor) to not reset input argument when iterating over it.
#    cursor, ccursor = tee(cursor)
#    count = sum(1 for _ in ccursor)
#    return count

def get_db_user(connection=None):
    """
    String of user (=schema) name. \n
    :param pyodbc.Connection connection: Provided by database read.
    """
    return connection.getinfo(pyodbc.SQL_USER_NAME)


def get_db_name(connection=None):
    """
    E.g. string 'infop' for MARS production. \n
    :param pyodbc.Connection connection: Provided by database read.
    """
    return connection.getinfo(pyodbc.SQL_SERVER_NAME)


def get_db_system_name(connection=None):
    """E.g. string 'Oracle'. \n
    :param pyodbc.Connection connection: Provided by database read.
    """
    return connection.getinfo(pyodbc.SQL_DBMS_NAME)


# TODO: possible others:
# SQL_DATABASE_NAME  retuns EMPTY
# SQL_DRIVER_NAME
# SQL_ODBC_VER


def print_db_info(connection=None):
    """
    Prints database *connection* information. Bundle of individual functions in :py:mod:`./pyodbc_utils.py` \n
    :param pyodbc.Connection connection: Provided by database read.
    """
    print('Database name:  {}.'.format(get_db_name(connection)))
    print('User name:      {}.'.format(get_db_user(connection)))
    print('Db system:      {}.'.format(get_db_system_name(connection)))
    return
