"""
This module contain some userful functions if you would like use sqllite module

SQLite is a relational database management system contained in a C programming library.
Basically, it provide an easy to use and fast local database in memory.

Make sure you have already download sqllite from the path
https://www.sqlite.org/2017/sqlite-tools-win32-x86-3190300.zip

And put the sqlite.exe file in to the path
C:/sqllite/

Warning:
    you have to put a sqlite exe file in the below path
    C:/sqllite/

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       24Jun2017   G48484      Initial creation
    ======= =========   =========   ========================================================================================
"""
import os
import sqlite3
import subprocess
import core.connection.pyodbc_utils as pyodbc_utils
import core.connection.database_extract as database_extract
import decimal
import unidecode


def initialize_sqlite_service():
    """
    The function will start a sqlite process in windows if such a process not existed.

    The function will firstly check whether 'sqlite3' already existed in the task list
    If yes, do nothing. If not, start the process

    Example:
        initialize_sqlite_service()

    Warning:
        Make sure you have sqlite in your C:\sqlite\
        Download sqlite from here
        https://www.sqlite.org/2017/sqlite-tools-win32-x86-3190300.zip

    Notes:
        Author: g48454
    """

    s = subprocess.check_output('tasklist', shell=True)
    if "sqlite3.exe" in str(s):
        pass
    else:
        try:
            os.startfile("C:\sqlite\sqlite3.exe")
        except:
            raise Exception("Please make sure you have put sqlite in your C drive..")


def copy_table_to_sqlite_db(schema, table_name, sqlite_conn):
    # ==================================================================================
    # firstly let us crate a table with the same structual as the table in new database
    # ===================================================================================
    table_name_in_sqlite = create_sqlite_table_with_same_structural_as_original_table(schema, table_name, sqlite_conn)

    # ==================================================================================
    # create cursor for the table that want to copy from
    # ===================================================================================
    sql = return_select_all_string_for_given_table(table_name)
    my_connection = database_extract.cursor_with_query(database=schema,
                                                       query=sql,
                                                       )

    cursor = my_connection['cursor']
    cols = normalized_column_names(my_connection["keys"])
    cols_sql_string = "(" + ",".join(cols) + ")"
    placeholder_list = ["?"] * len(cols)
    placeholder_string = "(" + ",".join(placeholder_list) + ")"
    insert_sql = "INSERT INTO " + table_name_in_sqlite + cols_sql_string + " VALUES " + placeholder_string
    # ===================================================================================
    # loop through cursor and insert records one by one
    # ===================================================================================
    cursor_sqlite = sqlite_conn.cursor()
    number_records = 0
    failed_rows = 0
    for raw_extracted_row in cursor.execute(sql):
        extracted_row = dict(zip(cols, raw_extracted_row))
        extracted_row_list = [extracted_row[x] for x in cols]
        extracted_row_list = format_list(extracted_row_list)
        try:
            cursor_sqlite.execute(insert_sql, extracted_row_list)
        except:
            failed_rows += 1
        number_records += 1
        if number_records % 10000 == 0:
            print("Has finished " + str(number_records) + " records")
    sqlite_conn.commit()
    # ===================================================================================
    # output necessary information
    # ===================================================================================
    print("Have copied table " + table_name + " from " + schema + " to sqlite table: " + table_name_in_sqlite)
    print("In total " + str(number_records-failed_rows) + " records have been copied")
    print("Failed rows: %s" % failed_rows)


def format_list(row_List):
    # ===================================================================================
    # because some data format is not working in sqlite, we have to convert it to another format
    # ===================================================================================
    out = []
    for x in row_List:
        if type(x) is decimal.Decimal:
            out.append(float(x))
        elif type(x) is str:
            out.append(unidecode._unidecode(x))
        else:
            out.append(x)
    return out


def create_sqlite_table_with_same_structural_as_original_table(schema, table_name, sqlite_conn):
    # ==================================================================================
    # Creates a table with the same structural as the table in the original database
    # ===================================================================================
    my_connection = database_extract.cursor_with_query(database=schema, query=return_select_all_string_for_given_table(table_name))
    cursor = my_connection['cursor']
    name_and_type = return_column_names_and_types_for_given_table(cursor=cursor)
    primary_keys = get_primary_keys(table_name[table_name.find('.') + 1:], cursor)
    new_table_name = table_name.replace(".", "_")  # sqlite understands "." as database delimiter, so we replace with "_"
    create_table_sql = create_table_string(table_name=new_table_name, column_names_and_types=name_and_type, primary_keys=primary_keys)
    sqlite_conn.execute(create_table_sql)
    return new_table_name


def connect_to_sqlite_db(path):
    return sqlite3.connect(path)


def read_data_from_db(conn, sql):
    return [x for x in conn.execute(sql)]


def return_names(conn, sql):
    return pyodbc_utils.get_column_names(conn.execute(sql))


def return_column_names_and_types_for_given_table(cursor):
    return pyodbc_utils.get_column_names_and_types(cursor)


def get_primary_keys(table_name, cursor):
    statistics = list(cursor.statistics(table_name))
    out = []
    for row in statistics:
        if row[8] is not None and row[5] is not None:
            if 'PK' in row[5]:
                out.append(row[8].encode())
    return out


def create_table_string(table_name, column_names_and_types, primary_keys):
    string = "CREATE TABLE IF NOT EXISTS " + table_name + " ("
    for col_name in normalized_column_names(column_names_and_types.keys()):
        string += col_name + ", "
    string += "PRIMARY KEY " + str(tuple(primary_keys)).upper().replace("'", "") + ");"
    return string


def normalized_column_names(col_list):
    new_list = []
    for x in col_list:
        if x == "index":
            x = "_index"
        new_list.append(x)
    return new_list


def return_select_all_string_for_given_table(tablename):
    return "select * from "+tablename


if __name__ == '__main__':
    initialize_sqlite_service()
    print("open database successfully")
    db_path = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/06 FRTB/13 Prototype/SQLite_database/MarketData_20180411.db'
    conn = connect_to_sqlite_db(db_path)
    copy_table_to_sqlite_db(schema="DAMDS", table_name="GMCCR_TIMESERIES.FRTB_HS_CREDIT_BONDBASIS", sqlite_conn=conn)
    copy_table_to_sqlite_db(schema="DAMDS", table_name="GMCCR_TIMESERIES.FRTB_HS_INTEREST_RATE", sqlite_conn=conn)
    copy_table_to_sqlite_db(schema="DAMDS", table_name="GMCCR_TIMESERIES.FRTB_HS_CREDIT_ZSPREAD", sqlite_conn=conn)
    # copy_table_to_sqlite_db(schema="DAMDS", table_name="GMCCR_TIMESERIES.FRTB_HS_CREDIT_CDS", sqlite_conn=conn)
    # copy_table_to_sqlite_db(schema="DAMDS", table_name="GMCCR_TIMESERIES.FRTB_HS_CREDIT_BONDBASIS", sqlite_conn=conn)
    # copy_table_to_sqlite_db(schema="DAMDS", table_name="GMCCR_TIMESERIES.FRTB_HS_FX", sqlite_conn=conn)
    conn.close()
