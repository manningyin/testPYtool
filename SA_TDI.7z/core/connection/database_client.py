import os, sys
os.environ["NLS_LANG"] = "English_Denmark.UTF8"
import pyodbc
import core.connection.database_connect as db_connect
import pandas as pd


class Field:
    def __init__(self, fieldName):
        self.fieldName = fieldName

    def query(self,value):
        if type(value) is list:
            if len(value)==0:
                return None
            elif len(value)==1:
                if 'eod_date' in self.fieldName:
                    return "(%s = DATE %s)"%(self.fieldName,repr(value[0]))
                else:
                    return "(%s = %s)"%(self.fieldName,repr(value[0]))
            else:
                return "(%s IN (%s))"%(self.fieldName,", ".join([repr(x) for x in value]))
        if 'eod_date' in self.fieldName:
            return "(%s = DATE %s)"%(self.fieldName,repr(value))
        else:
            return "(%s = %s)"%(self.fieldName,repr(value))


class client():

    def __init__(self, schema='marsp', database_alias='infop',  **kwargs):
        db_string = db_connect.get_string(database_alias=database_alias, **kwargs)
        self._connection = pyodbc.connect(db_string)
        self._known_tables = {}
        self._schema = schema.upper()

    @staticmethod
    def _build_where(**kwargs):
        qs = []
        for key, value in kwargs.items():
            if value == None:
                continue
            qs.append(Field(key).query(value))

        if qs == []:
            return None
        if len(qs):
            q = " AND ".join(qs)
            if len(q):
                return " WHERE " + q
            else:
                return ""
        else:
            return ""

    def _get_columns(self,_any_table_name):
        cur = self._connection.cursor()
        columns = '*'
        where = 'WHERE 1 = 2'
        SQL = """
          SELECT %(columns)s
            FROM %(schema)s.%(_any_table_name)s
            %(where)s
        """ % locals()
        cur.execute(SQL)
        return [x[0].lower() for x in cur.description]

    def _build_query(self, _any_table_name, **kwargs):
        keys = self._known_tables[_any_table_name]
        columns = ', '.join(keys)

        args = {k: v for k, v in kwargs.items() if k in keys}
        where = self._build_where(**args)
        schema = self.schema

        return """
          SELECT %(columns)s
            FROM %(schema)s.%(_any_table_name)s
            %(where)s
        """ % locals()

    def _table_generator(self, _any_table_name, **kwargs):
        cur = self._connection.cursor()

        keys = self._known_tables[_any_table_name]
        columns = ', '.join(keys)

        args = {k: v for k, v in kwargs.items() if k in keys}
        where = self._build_where(**args)

        SQL = """
          SELECT %(columns)s
            FROM %(schema)s.%(_any_table_name)s
            %(where)s
        """ % locals()

        cur.arraysize = 50
        for values in cur.execute(SQL):
            yield dict(zip(keys, values))

    def _has_table(self,_any_table_name):
        if _any_table_name in self._known_tables:
            return True
        else:
            SQL = """SELECT table_name
                     FROM all_tables
                     WHERE owner = :1 and table_name = :2"""
            cursor = self._connection.cursor()
            if (_any_table_name in cursor.execute(SQL, (self._schema, _any_table_name)).next()):
                self._known_tables[_any_table_name] = self._get_columns(_any_table_name=_any_table_name)
                return True
        return False

    def __getattr__(self, name):
        if self._has_table(_any_table_name=name.upper()):
            def wrapper(**kwargs):
                return self._table_generator(name.upper(),**kwargs)
            return wrapper
        else:
            raise AttributeError

def generator2dataframe(obj):
    d = {}
    for row in obj:
        for key in row:
            try:
                d[key].append(row[key])
            except KeyError:
                d[key] = [row[key]]
    return pd.DataFrame(d)

if __name__ == '__main__':
    marsp = client(schema='marsp', database_alias='INFOP')
    for row in marsp.interest(interest_id=59):
        print(row)

    df = generator2dataframe(marsp.interest())