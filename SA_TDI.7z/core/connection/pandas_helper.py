import hashlib
import json
import os
import tempfile
import logging

import pandas as pd

logger = logging.getLogger(__name__)





def expand_sql_lists(sql, params, chunk_size=1000):
    def expand_sql_list(placeholder, values):
        for i in range(0, len(values), chunk_size):
            chunk = values[i:i + chunk_size]
            i_params = {}
            i_placeholder = []
            for j, _ in enumerate(chunk):
                i_params['%s_%03d' % (placeholder, j)] = values[i + j]
                i_placeholder.append(':%s_%03d' % (placeholder, j))
            yield i_placeholder, i_params
    sub_params = [{}]
    sub_placeholders = [{}]
    for i_p in params:
        if isinstance(params[i_p], (tuple, list)):
            new_params = []
            new_placeholders = []
            for i_placeholder, i_params in expand_sql_list(i_p, params[i_p]):
                for p, h in zip(sub_params, sub_placeholders):
                    new_p = dict()
                    new_p.update(p)
                    new_p.update(i_params)
                    new_params.append(new_p)
                    new_h = dict()
                    new_h.update(h)
                    new_h.update({i_p: i_placeholder})
                    new_placeholders.append(new_h)
            sub_params = new_params
            sub_placeholders = new_placeholders
        else:
            for new_p in sub_params:
                new_p[i_p] = params[i_p]
    for p, h in zip(sub_params, sub_placeholders):
        new_sql = sql
        for placeholder in h:
            new_sql = new_sql.replace(':%s' % placeholder, '%s' % ', '.join(h[placeholder]))
        yield new_sql, p


def read_sql_cached(sql, con, index_col=None, coerce_float=True, params=None, parse_dates=None, columns=None,
                    chunksize=None, update_cache=False, cache_dir=None, expand_lists=False) -> pd.DataFrame:
    kwargs = dict(con=con, index_col=index_col, coerce_float=coerce_float, params=params, parse_dates=parse_dates,
                  columns=columns, chunksize=chunksize)
    if cache_dir is None:
        cache_dir = os.path.join(tempfile.gettempdir(), 'code-lib')

    sql_hash = hashlib.md5(sql.encode('utf-8')).hexdigest()

    kwargs_hash = hashlib.md5(json.dumps(kwargs, sort_keys=True, default=str).encode('utf-8')).hexdigest()
    cache_path = os.path.join(cache_dir, sql_hash)
    cache_full = os.path.join(cache_path, kwargs_hash + '.pickle.bz2')
    if update_cache or (not os.path.exists(cache_full)):
        os.makedirs(cache_path, exist_ok=True)
        if expand_lists:
            i_kwargs = dict(con=con, index_col=index_col, coerce_float=coerce_float,
                            parse_dates=parse_dates, columns=columns, chunksize=chunksize)
            pd.concat((pd.read_sql(i_sql, params=i_params, **i_kwargs) for i_sql, i_params in expand_sql_lists(sql, params)),
                      ignore_index=True).to_pickle(cache_full)
        else:
            pd.read_sql(sql, **kwargs).to_pickle(cache_full)

    result = pd.read_pickle(cache_full)
    return result


def read_sql_expressions_from_file(file, encoding=None):
    """
    Read SQL expressions from .sql file

    First -- comment before expressions is key in dictionary
    Expressions are separated by ';'

    :param file: .sql file
    :return: dict with expressions
    """
    with open(file, 'r', encoding=encoding) as sqlfile:
        text = sqlfile.read()
    results = {}
    current = ''
    state = None
    first_comment = True
    title_str = ''
    for c in text:
        if state is None:  # default state, outside of special entity
            current += c
            if c in '"\'':
                # quoted string
                state = c
            elif c == '-':
                # probably "--" comment
                state = '-'
            elif c == '/':
                # probably '/*' comment
                state = '/'
            elif c == ';':
                # remove it from the statement
                current = current[:-1].strip()
                title_str = title_str.strip()
                # and save current stmt unless empty
                if current:
                    if title_str in results:
                        raise ValueError(title_str)
                    else:
                        results[title_str] = current
                        #results[title_str] = lambda con, kwargs: read_sql_cached(current, con, **kwargs)

                first_comment = True
                title_str = ''
                current = ''
        elif state == '-':
            if c != '-':
                # not a comment
                state = None
                current += c
                continue
            # remove first minus
            current = current[:-1]
            # comment until end of line
            state = '--'
        elif state == '--':
            if c == '\n':
                # end of comment
                # and we do include this newline
                current += c
                state = None
                first_comment = False
            elif first_comment:
                title_str += c
            # else just ignore
        elif state == '/':
            if c != '*':
                state = None
                current += c
                continue
            # remove starting slash
            current = current[:-1]
            # multiline comment
            state = '/*'
        elif state == '/*':
            if c == '*':
                # probably end of comment
                state = '/**'
        elif state == '/**':
            if c == '/':
                state = None
            else:
                # not an end
                state = '/*'
        elif state[0] in '"\'':
            current += c
            if state.endswith('\\'):
                # prev was backslash, don't check for ender
                # just revert to regular state
                state = state[0]
                continue
            elif c == '\\':
                # don't check next char
                state += '\\'
                continue
            elif c == state[0]:
                # end of quoted string
                state = None
        else:
            raise Exception('Illegal state %s' % state)

    if current:
        current = current.rstrip(';').strip()
        title_str = title_str.strip()
        if current:
            if title_str in results:
                raise ValueError
            else:
                results[title_str] = current
                #results[title_str] = lambda con, kwargs: read_sql_cached(current, con, **kwargs)

    return results

def build_sql_functions_from_file(file, encoding=None):
    sql = read_sql_expressions_from_file(file, encoding)
    return {title_str: lambda con, kwargs: read_sql_cached(sql[title_str], con, **kwargs) for title_str in sql}
