GateKeeper: JonasB

This folder contains functionallity for connecting to external databases, systems and applications.