# TradeHub UAT Client Certificate for `int_client_id`

This directory contains a client certificate issued by the UAT Communication
Layer (CL) Certificate Authority, for use by your TradeHub client in the UAT
environment.

## Overview

This UAT certificate is used to identify your client application to the
TradeHub servers (and, if you use the TradeHub Consumer API for realtime
consumption of messages, also to identify your application to the CL brokers.

The files you need for your application depend on the TradeHub API language
you are using (Java, .NET, Python, etc.). So for example, JKS format stores
are commonly used by Java applications, and PKCS12 format stores are more
commonly used by .NET applications. Please see the API documentation for
your preferred language for more details.

## File Descriptions

Generally, you do not need to know the details of what these files contain,
but some information is given here to aid potential troubleshooting.

The files in this directory are:

* PEM format containers (useful only for low level debugging)
* JKS format stores (typically useful to Java API clients)
* PKCS12 format stores (typically useful to non-Java API clients)
* Passwords for the stores and private key.

### PEM Container Format Files

The PEM format files are generally only useful for low level debugging, and
as a TradeHub client you are unlikely to need to use them, but will instead
use the JKS or PKCS12 format stores.

* `int_client_id.encrypted_private_key.pem`

   A PEM-encoded *encrypted* private key file. This UAT private key was
   generated on your behalf by the TradeHub team. The password to decrypt this
   key is stored in the file `int_client_id.keystore.pw`.

   It is unlikely that you will need to use this file if you are using a
   standard TradeHub API, since the APIs should support extraction of this
   private key from one of the JKS or PKCS12 keystores. It is included here for
   potential debugging purposes only.

* `int_client_id.public_cert.pem`

   A PEM-encoded public client certificate file. This UAT certificate was
   requested on your behalf by the TradeHub team, and issued and signed by the
   Communication Layer's UAT Certificate Authority.

   It is unlikely that you will need to use this file if you are using a
   standard TradeHub API, since the APIs should support extraction of this
   certificate from one of the JKS or PKCS12 keystores. It is included here for
   potential debugging purposes only.

* `int_client_id.cert_key_pair.pem`

  A file containing your PEM-encoded public client certificate AND your
  PEM-encoded *encrypted* private key file.

  It is unlikely that you will need to use this file if you are using a
  standard TradeHub API, since the APIs should support extraction of the
  certificate and encrypted private key from one of the JKS or PKCS12
  keystores. It is included here for potential debugging purposes only.

* `int_client_id.decrypted_private_key.pem`

   A PEM-encoded *decrypted* private key file. This is the same private
   key as stored in `int_client_id.private_key.pem`, but with encryption
   removed.

   You would not normally keep a copy of an unencrypted private key on disk.
   It is included here for potential debugging purposes only.
   
* `UAT_CL_CA_root.cert.pem`   

   A PEM-encoded copy of the UAT Communication Layer Certificate Authority's
   public certificate. 
   
   This can be manually added to an existing client truststore should you wish 
   to use an existing system-wide truststore (instead of using one of the JKS 
   or PKCS12 format truststores we have supplied).
   
   Having this certificate in the truststore ensures your client will 
   implicitly trust the TradeHub UAT server (which itself has a certificate 
   issued by the UAT CL CA).

### JKS Format Stores

* `int_client_id.keystore.jks`

  A JKS format keystore, containing your certificate-key pair (i.e. your
  public client certificate and your encrypted private key).

  The keystore is password protected. The password is found in the file
  `int_client_id.keystore.pw`.

  Your encrypted private key, stored within this keystore, can be decrypted
  with the same password. (You would normally use a different password for
  this, but to keep things simple in UAT, we used the same password).

* `int_client_id.truststore.jks`

  A JKS format keystore, containing a copy of the UAT Communication
  Layer Certificate Authority's public key.

  This can be used by your client to implicitly trust the TradeHub
  server (which itself has a certificate issued by the UAT CL CA).

  The truststore is password-protected with the password found in
  `int_client_id.truststore.pw`.

### PKCS12 Format Stores

* `int_client_id.keystore.p12`

  A PKCS12 format keystore, containing your certificate-key pair (i.e. your
  public client certificate and your encrypted private key).

  As with the JKS format keystore, this PKCS12 format keystore is
  password-protected using the same password, found in
  `int_client_id.keystore.pw`.

  Your encrypted private key, stored within this keystore, can be decrypted
  with the same password.

* `int_client_id.truststore.p12 `

  A PKCS12 format keystore, containing a copy of the UAT Communication
  Layer Certificate Authority's public key.

  This can be used by your client to implicitly trust the TradeHub
  server (which itself has a certificate issued by the UAT CL CA).

  The truststore is password-protected with the password found in
  `int_client_id.truststore.pw`.

### Passwords

* `int_client_id.keystore.pw`

   Password for the JKS format keystore and the PKCS12 format keystore.
   This is also the password used for the encrypted private key.

* `int_client_id.truststore.pw`

   Password for the JKS format truststore and the PKCS12 format truststore.

For more information, please contact us at <tradehub@nordea.com>.

