"""
Module for connecting and pulling trade and position data from TradeHub. Default environment set in core.system.ext_envir

This module has the ability to connect to the TradeHub API and thereby fetch information from the mongo database. Note
that currently only obfuscated production environment is supported. To support UAT environment, a specific UAT license
must be granted by the TradeHub team.
To parse the FPML files sent by TradeHub, a naive fpml parser has been implemented, which has not been thoroughly tested
and thus might be prone to errors.

Notes:
    Author: g48606
    Updated by: g01571
                g50381

"""
from tradehub import query_api
from tradehub import MessageMetadata
from core.utils import date_helper
from core.utils import fpml_helper
from core.system import ext_envir
from functools import reduce
import operator
from core.types import PositionType, Portfolio


class TradeHubHelper:
    def __init__(self):
        self.__qs = ext_envir.TradeHub().config

        self.__all_field_paths = {
            # Trade information paths
            'trade_id': [['executionAdvice', 'trade','tradeHeader','partyTradeIdentifier',1,'tradeId'],
                           ['executionAdvice', 'novation', 'newTrade', 'tradeHeader', 'partyTradeIdentifier', 1, 'tradeId'],
                           ['executionAdvice', 'trade', 'tradeHeader', 'partyTradeIdentifier',  'tradeId'],
                           ['executionAdvice', 'novation', 'newTrade', 'tradeHeader', 'partyTradeIdentifier', 'tradeId'],
                           ['executionAdvice', 'amendment', 'trade', 'tradeHeader', 'partyTradeIdentifier', 'tradeId']],
            'trade_status': [['executionAdvice', 'trade', 'tradeHeader', 'partyTradeInformation', 'status'],
                             ['executionAdvice', 'amendment', 'trade', 'tradeHeader', 'partyTradeInformation', 'status']],
            'trade_price': [['executionAdvice', 'trade', 'instrumentTradeDetails', 'pricing', 'quote', 1, 'value'],
                            ['executionAdvice', 'amendment', 'trade', 'instrumentTradeDetails', 'pricing', 'quote', 1, 'value']],
            'accrued_interest':  [['executionAdvice', 'trade', 'instrumentTradeDetails', 'pricing', 'quote', 2, 'value'],
                                  ['executionAdvice', 'amendment', 'trade', 'instrumentTradeDetails', 'pricing', 'quote', 2, 'value']],
            'trade_quantity': [['executionAdvice', 'trade', 'instrumentTradeDetails', 'quantity', 'number'],
                                 ['executionAdvice', 'trade', 'instrumentTradeDetails', 'quantity', 'nominal', 'amount'],
                               ['executionAdvice', 'amendment', 'trade', 'instrumentTradeDetails', 'quantity', 'number'],
                               ['executionAdvice', 'amendment', 'trade', 'instrumentTradeDetails', 'quantity', 'nominal', 'amount']],
            'trade_settlement':  [['executionAdvice', 'trade', 'instrumentTradeDetails', 'settlement', 'settlementAmount', 'amount'],
                                  ['executionAdvice', 'amendment', 'trade', 'instrumentTradeDetails', 'settlement', 'settlementAmount', 'amount']],
            'trade_principal' : [['executionAdvice', 'trade', 'instrumentTradeDetails', 'principal', 'principalAmount', 'gross'],
                                 ['executionAdvice', 'amendment', 'trade', 'instrumentTradeDetails', 'principal', 'principalAmount', 'gross']],
            'trade_date': [['executionAdvice', 'trade', 'tradeHeader', 'tradeDate'],
                           ['executionAdvice', 'novation', 'newTrade', 'tradeHeader', 'tradeDate'],
                           ['executionAdvice', 'amendment', 'effectiveDate']],
            'trade_timestamp': [['executionAdvice', 'trade', 'tradeHeader', 'partyTradeInformation','executionDateTime'],
                                ['executionAdvice', 'amendment', 'executionDateTime']],
            'isCorrection': [['executionAdvice', 'isCorrection']],

            # Position information paths
            'isin': [['executionAdvice', 'trade', 'instrumentTradeDetails', 'equity', 'instrumentId']],
            'portfolio_id': [['executionAdvice', 'trade', 'tradeHeader', 'partyTradeInformation', 'portfolio'],
                             ['executionAdvice', 'amendment', 'trade', 'tradeHeader', 'partyTradeInformation', 'portfolio'],
                             ['executionAdvice', 'novation', 'newTrade', 'tradeHeader', 'partyTradeInformation', 'portfolio']],
            'position_instrument': [['positionReport', 'position', 'constituent', 'holding', 'bond', 'instrumentId']],
            'position_quantity': [['positionReport', 'position', 'constituent', 'holding', 'quantity']],
            'position_type': [['positionReport', 'position', 'constituent', 'holding', 'type']],
            'position_id': [['positionReport', 'position', 'positionId']],
            'position_portfolio_id': [['positionReport', 'position', 'constituent', 'holding', 'partyHoldingInformation', 'portfolio']]
        }

    @staticmethod
    def __get_path(input_dict, keys):
        for k in keys:
            try:
                output = reduce(operator.getitem, k, input_dict)
            except KeyError:
                output = None
            if output is not None:
                return output
        return None

    def __get_trade_type(self, nested_dict):
        if self.__get_path(nested_dict, [['executionAdvice', 'trade']]) is not None:
            return 'normal'
        elif self.__get_path(nested_dict, [['executionAdvice', 'amendment']]) is not None:
            return 'amendment'
        elif self.__get_path(nested_dict, [['executionAdvice', 'novation']]) is not None:
            return 'novation'
        elif self.__get_path(nested_dict, [['executionAdvice', 'termination']]) is not None:
            return 'termination'
        else:
            return 'unknown'

    # ===================================================================================
    # Some Helper Functions
    # ===================================================================================
    @staticmethod
    def __display_records(records):
        for record in records:
            print("Record FPML:", record.payload)
            print("Record messageId:", record.messageId)
            print("Record timestamp:", record.timestamp)

    @staticmethod
    def __create_metadata(position_type, source=Portfolio.Markets):
        if position_type == PositionType.Holding:
            d = {"MessageType": "Position",
                 "MarketsTreasury": source.name,
                 "FrontBackOffice": "FrontOffice",
                 "PositionType": "SettlementDated"}
        elif position_type == PositionType.Trans:
            d = {"MessageType": "Trade",
                 "MarketsTreasury": source.name,
                 "FrontBackOffice": "FrontOffice"}

        else:
            raise Exception('Please enter the metadata type')

        return MessageMetadata(attributes=d)

    def __custom_query(self, condition, metadata):
        records = self.__qs.QueryData(query_api.Query(
            condition=condition,
            meta=metadata,
            returnPayload=True))
        return records

    def __extract_fields_from_records(self, records):
        out = []
        for record in records:
            tmp_dict = {}
            d = fpml_helper.nested_dict_fpml_parser(record.payload)
            for field, paths in self.__all_field_paths.items():
                val = self.__get_path(d, paths)
                if val is not None:
                    tmp_dict[field] = val
            trade_type = self.__get_trade_type(d)
            if trade_type is not None:
                tmp_dict['trade_type'] = trade_type
            out.append(tmp_dict)
        return out

    # ===================================================================================
    # Supported Queries
    # ===================================================================================
    def __last_in_group_query(self, condition, metadata, group_by):
        """
        A find query on the TradeHub mongo database that returns the latest entry in the group(s)

        Args:
            condition          (str): MongoDB query condition (as used in '.find()')
            metadata           (obj): TradeHub metadata object - use functions in module (either positions or trades)
            group_by   (list of str): List of group by elements given as strings

        Returns:
            (obj): TradeHub latest in group query object

        Notes:
            Author: g48606
        """
        th_query = query_api.LatestInGroupQuery(condition=condition,
                                                meta=metadata,
                                                groupByFields=group_by,
                                                returnPayload=True)

        return self.__qs.QueryLatestInGroup(th_query)

    def query_trade_from_portfolio(self, trade_date, source_system, portfolio_name, position_type=PositionType.Trans):
        source_systems = source_system if isinstance(source_system, list) else [source_system]
        source_systems_str = '["' + '", "'.join(source_systems) + '"]'
        iso_date = date_helper.to_datetime(trade_date).date().isoformat()
        condition = """{$and: 
                [
                    {"extracted.sentBy": {$in: %(source_systems_str)s}}, 
                    {"extracted.portfolio": "%(portfolio_name)s"}, 
                    {"extracted.tradeDate": ISODate("%(iso_date)s")}
                ]
            }""" % locals()
        metadata = TradeHubHelper.__create_metadata(position_type)
        records = self.__custom_query(condition, metadata)
        return self.__extract_fields_from_records(records)

    def query_by_nordea_trade_id(self, id, position_type=PositionType.Trans, portfolio=Portfolio.Markets):
        condition = '{"extracted.nordeaTradeId" : "%s"}' % id
        metadata = self.__create_metadata(position_type, portfolio)
        records = self.__custom_query(condition, metadata)
        return self.__extract_fields_from_records(records)

    def query_by_tradehub_id(self, id, position_type=PositionType.Trans, portfolio=Portfolio.Markets):
        condition = '{"_id" : "%s"}' % id
        metadata = self.__create_metadata(position_type, portfolio)
        records = self.__custom_query(condition, metadata)
        return self.__extract_fields_from_records(records)

    def query_payload_by_isins(self, isins, position_type=PositionType.Holding, portfolio=Portfolio.Markets):
        assert isinstance(isins, (list, tuple))
        isin_str = '", "'.join(isins)
        condition = """{$and:
            [
                {"extracted.instrumentISIN": {$in: ["%s"]}},
            ]
        }""" % isin_str
        metadata = self.__create_metadata(position_type, portfolio)
        records = list(self.__last_in_group_query(condition=condition, metadata=metadata, group_by=['extracted.instrumentISIN']))
        return [fpml_helper.nested_dict_fpml_parser(record.payload) for record in records]

    def query_settled_positions(self, date, portfolio_name, source_system, position_type=PositionType.Holding):
        """
        Get the settled positions for given date, portfolio and source system.

        This function implicitly assumes the user wants the last recorded value in TradeHub for each ISIN. If data for some
        specific database datetime is needed, the user should use "query" instead of "last_in_group_query". Further, note
        that to parse the TradeHub return, the "naive_fpml_parser" is used, which hasn't been thoroughly tested and thus
        might be prone to some bugs.

        Args:
            date                  (date):    The date to get positions for
            portfolio_name         (str):    Portfolio name
            source_system  (list or str):    Source system
            position_type         (Enum):    The position type

        Returns:
            (dict): Dictionary with ISIN as keys and positions as values

        Notes:
            Author: g48606
        """
        source_systems = source_system if isinstance(source_system, list) else [source_system]
        source_systems = '["' + '", "'.join(source_systems) + '"]'
        iso_date = date_helper.to_datetime(date).date().isoformat()
        condition = """{$and:
            [
                {"extracted.sentBy": {$in: %(source_systems)s}},
                {"extracted.portfolio": "%(portfolio_name)s"},
                {"extracted.asOfDate": ISODate("%(iso_date)s")},
            ]
        }""" % locals()

        positions_metadata = self.__create_metadata(position_type)
        # We request only the last recorded value for each ISIN. If the user wants all recorded values (can contain
        # duplicates or incorrect values), the "query" function should be used instead.
        records = self.__last_in_group_query(condition=condition,
                                             metadata=positions_metadata,
                                             group_by=['extracted.instrumentISIN'])

        return self.__extract_fields_from_records(records)


if __name__ == '__main__':
    import datetime as dt
    from pprint import pprint
    t_helper = TradeHubHelper()

    # ==================================================================================
    #  Query an ISIN
    # ==================================================================================
    # out = t_helper.query_payload_by_isins(isins=['SE0007125927'])
    # pprint(out)

    # ===================================================================================
    # Nordea Trade Id
    # ===================================================================================
    # out = t_helper.query_by_nordea_trade_id("INFINITY-2393669")
    # out = t_helper.query_by_nordea_trade_id("CALYPSO-277028682")
    out = t_helper.query_by_nordea_trade_id("BLOOMBERG-6946172753488904215")
    pprint(out)
    # ===================================================================================
    #  Query a trade with tradehub id
    # ===================================================================================
    #out = t_helper.query_by_tradehub_id(id='85a7a3710b5ac7cdef386aafb94a817b6956759a',
    #                                   position_type=PositionType.Trans,
    #                                    portfolio=Portfolio.Markets)
    # pprint(out)

    # # ===================================================================================
    # # Query by Portfolio
    # # ===================================================================================
    # out = t_helper.query_trade_from_portfolio(trade_date=dt.datetime(2018, 4, 10),
    #                                           portfolio_name='DKEFISSA',
    #                                           source_system='INFINITY')
    # pprint(out)
    #
    # # ==================================================================================
    # # Query Portfolio by tradehub id
    # # ===================================================================================
    # out = t_helper.query_by_tradehub_id(id='4e72524e0c511429bb7b454488c441cf0195d5bf',
    #                                     position_type=PositionType.Holding,
    #                                     portfolio=Portfolio.Markets)
    # pprint(out)
    #
    # # ===================================================================================
    # # Query Settled positions
    # # ===================================================================================
    # out = t_helper.query_settled_positions(date=dt.datetime(2018, 2, 16), portfolio_name='MMNORGE', source_system='CALYPSO')
    # pprint(out)

