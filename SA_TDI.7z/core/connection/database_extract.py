"""
Extract data from a database matching a user provided query

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01NOV2016   G50444      Initial creation
    2       24Nov2016   g48454      Added support input external connection string
    ======= =========   =========   ========================================================================================

"""

import pyodbc
import core.connection.database_connect as database_connect
import pandas as pd


def as_dataframe(database, query, info = 0):
    """
    Extracting data from a database - returning a dataframe

    Args:
        database    (str):  Name of the database matching the code-lib alias
        query       (str):  Sql providing the extract criteria - e.g. select * from my_schema.my_table

    Returns:
        (dataframe): The data extracted from the database

    Example:
        The module is called (from python) like this::

            from core.connection import database_extract

            sql = "select * from marsp.currency_price where currency_id ='USD'"
            my_data = database_extract.as_dataframe('infop',sql)

    Notes:
        Author: JBrandt (g50444)
    """

    # Connecting to database
    connection_string = database_connect.get_string(database_alias = database, info = info)
    connection = pyodbc.connect(connection_string)

    # Reading data
    try:
        df = pd.read_sql(sql = query, con = connection)
    except Exception as e:
        if str(e).find('ORA-00936') >= 0 or str(e).find('ORA-00904') >= 0:
            raise SyntaxError('Problem occured when extracting data from database: ' + database + '\n'
                              + 'It seems like an sql syntax error. Sql statement: \n'
                              + query)
        else:
            raise Exception('Problem occured when extracting data from ' + database + ' Exception message: \n' + str(e))

    # Cleaning up
    try:
        connection.close()
    except:
        # Not closing a connection is a non-fatal issue
        pass

    return df


def select_from_query(database,
                      query,
                      connection_string  = None,
                      info               = 0
                      ):
    """
    This function will execute a sql query on a chosen database, and return the extracted data in a list of dicts.

    All data is returned in one chunk, when all data has been fetched.
    Hence, current version of the function is not well suited for parallel processing

    Args:
        database            (str):      Name/abbreviation for the database that calling module wich to connect to.
        query               (str):      SQL select query, with specific column definitions (not select "star")
        connection_string   (str):      Optional. User can input the connection string
                                        If not, the function will generate a string for the chosen database
        info                (int):      Optional. Level of information printed. The higher, the more information is printed

    Returns:
        (dict): All rows extracted from the database

    Raises:

    Example:
        The module is called (from python) like this::

            from core.connection import database_extract

            sql =   '''
                    select eod_date,currency_id, price
                    from marsp.currency_price
                    where eod_date = to_date('2017-02-01','yyyy-mm-dd')
                    '''
        
            my_data = database_extract.select_from_query(   database    = 'infop',
                                                            query       = sql,
                                                            )

    Warning:
        This function waits until ALL rows have been extracted before continuing

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # Creating connection string, and connecting to database
    # ===================================================================================

    if connection_string == None:
        connection_string = database_connect.get_string(database_alias  = database,
                                                        info            = info
                                                        )

    try:
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()
    except Exception:
        raise Exception('Not able to access database ' + database)

    # ===================================================================================
    # Creating cursor (with query)
    # ===================================================================================

    cursor_connection = cursor_with_query(  database            = database,
                                            query               = query,
                                            connection_string   = connection_string,
                                            info                = info,
                                            )

    cursor  = cursor_connection['cursor']
    keys    = cursor_connection['keys']

    # ===================================================================================
    # Extracting data from database
    # ===================================================================================

    try:
        return_data = []
        for row in cursor.fetchall():
            if row is not None:
                return_data.append(dict(zip(keys,row)))
    except Exception as e:
        raise ConnectionError('Problem occurred when extracting. Module message:',e)

    # ===================================================================================
    # Closing connection to database and returning data
    # ===================================================================================

    try:
        close_cursor(cursor_connection)
    except Exception as e:
        # Not closing a connection is not considered as a important issue
        pass

    return return_data

# ===================================================================================
# below code provide another way to get data from sql.
# ===================================================================================
def select_from_query_use_sql_engine(database,
                          query
                          ):
    engine = database_connect.return_sql_engine(database)
    df = pd.read_sql(query
            ,params = {}
            ,con = engine)
    return df.to_dict('records')


def cursor_with_query(database,
                      query,
                      connection_string = None,
                      info      = 0
                      ):
    """
    Creating cursor with query, which can be used (outside this function) for extracting data from data source

    Args:
        database            (srt):      Name/alias for the database (infop or similar)
        query               (str):      Full select statement / sql
        connection_string   (str):      Optional. User can input the connection string
                                        If not, the function will generate a string for the chosen database
        info                (int):      Level of information printed. The higher, the more information is printed

    Returns:
        (dict{cursor,keys,connection}):

    Raises:

    Example:
        The module is called (from python) like this::

            from core.connection import database_extract
        
            sql =   '''
                        select currency_id, price 
                        from marsp.currency_price 
                        where eod_date = to_date('01-12-2016','dd-mm-yyyy')
                    '''
            my_connection = database_extract.cursor_with_query( database    = 'INFOP',
                                                                query       = sql,
                                                                )
            cursor = my_connection['cursor']
            cols = my_connection["keys"]

            cursor.arraysize = 20

            my_data = []
            for raw_extracted_row in cursor:
                extracted_row = dict(zip(cols, raw_extracted_row))

                my_data.append(extracted_row)

            print(my_data)

            database_extract.close_cursor(my_connection,1)

    Warning:
        Note that this function OPENS a connection, but does not close it...
        Please use the close_cursor function (in this module) to close the connection.
        See example in the example section.

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # Creating connection string, and connecting to database
    # ===================================================================================

    if connection_string is None:
        connection_string = database_connect.get_string(database_alias  = database,
                                                        info            = info
                                                        )

    try:
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()
    except Exception as e:
        raise ConnectionError('Not able to access database ' + database)

    # ===================================================================================
    # Determining which columns to expect
    # ===================================================================================

    xcursor = cursor.execute(query)

    try:
        from core.connection import pyodbc_utils
        keys = tuple(x.lower() for x in pyodbc_utils.get_column_names(xcursor))
    except Exception as e:
        Exception('Problem occurred in query_info.column_names: ' + e)

    if info > 0:
        print('Expected columns :', keys)
        print('Query            :', query)


    # ===================================================================================
    # Returning dict with cursor,
    # ===================================================================================

    return {'cursor': cursor, 'keys': keys, 'connection': connection}

def close_cursor(cursor_connection, info = 0):
    """
    Closes cursor and connection created by "cursor_with_query" (in this module)

    Args:
        cursor_connection       (dict):         {cursor,connection} - Matching returned output from cursor_with_query

        info                    (int):              Level of information printed. The higher, the more information is printed

    Returns:
        (None):   Nothing

    Raises:


    Example:
        See example from "cursor_with_query" function (in this query)

    Warning:


    Notes:
        Author: g50444
    """

    try:
        cursor = cursor_connection['cursor']
        cursor.close()
        if info > 0:
            print('Cursor closed')
    except Exception as e:
        # Not closing a cursor is not considered as a important issue
        pass
    try:
        connection = cursor_connection['connection']
        connection.close()
        if info > 0:
            print('Connection closed')
    except Exception as e:
        # Not closing a connection is not considered as a important issue
        pass


# def falm_connection(sqlstring, server):
#     """
#     !!!READ WARNING!!!: Establishes a connection to the FALM database, pulls data using provided SQL string
#
#     Args:
#         sqlstring          (string):    String containing the SQL code to be executed
#         server              string):    Which FALM server to connect to.
#                                         Choices are: UAT (VDA1CD0048), Pre-prod (VDA1XS0096), Prod (VDD1XS0099)
#     Returns:
#         (dataframe):   Dataframe with the pulled SQL table
#
#     Example:
#         The module is called (from python) like this::
#
#             df = falm_connection("select * from InputDB_EVE_D.dbo.InterestRates where RateCurveName = 'EUR_FWD'",
#                                  "VDA1XS0096")
#
#     Warning:
#         OBS OBS OBS!!!: Function will not work unless you have a user on the QAONEADR domain with access to either UAT,
#         pre-prod or prod servers. Further, you need to open "Credential Manager" (find in Windows Start menu by search)
#         and add a windows credential. In the server name line write servername followed by port, e.g. "VDA1XS0096:1433".
#         In the user line write "QAONEADR\g*****", and in the password line write your QAONEADR password. NB: If you
#         change your QAONEADR password in the future, please also change it in the credential manager.
#
#     Notes:
#         Author: g48606
#     """
#     driver = database_connect.get_odbc_driver('SQL_Server')
#     connection = pyodbc.connect('Driver={%s}; Server=%s; Trusted_connection=yes' % (driver, server))
#     df = pd.read_sql(sqlstring, connection)
#     connection.close()
#     return df


def stars_connection(sqlstring):
    """
    Establishes connection to STARS Teradata, pulls data using given SQL string.

    Requires that access has been granted to STARS Teradata for the user in question.

    Args:
        sqlstring          (string):    String containing the SQL code to be executed
    Returns:
        (dataframe):   Dataframe with the pulled SQL table

    Example:
        The module is called (from python) like this::

            df = stars_connection("select * from starsp_sl_views.MARKET_BENCHMARK_RATE where Currency = 'EUR'")

    Notes:
        Author: g48606
    """
    user = input("Input your g-logon: ")
    pwd = input("Input your password: ")
    connection = pyodbc.connect('Driver={Teradata}; Server=NDWP3.DKD1; Uid=%(user)s; pwd=%(pwd)s; Authentication=LDAP; '
                                'DBCName=NDWP3' % locals())
    connection.close()
    return pd.read_sql(sqlstring, connection)


if __name__ == '__main__':
    sql = """select * from (with choose_proj as (
                        select rm_vgm.vol_id, v.name, max(proj.projection_vol_id) proj_vol_id  -- some vols will have more than one mapping during the period, we therefore need to choose one. Generic proxies have low vol_id's, we therefore choose high vol_id.
                        from  marsp.timeinterval a1,
                              marsp.timeinterval b1,
                              marsp.rm_vol_grp_mapping    rm_vgm,
                              marsp.rm_vol_grp            rm_volgrp,
                              marsp.projection_vol_mapping   proj,
                              marsp.vol v
                        where  a1.end_date = to_date('2017-10-25 00:00:00','yyyy-mm-dd hh24:mi:ss')
                        and    a1.timeinterval_id - 255 = b1.timeinterval_id   -- must cover the period of month-ends used for nmrf ses estimate
                        and    rm_vgm.eod_date >= b1.end_date
                        and    rm_vgm.rm_vol_supergrp_id = 5
                        and    rm_vgm.rm_vol_grp_id = rm_volgrp.rm_vol_grp_id
                        and    proj.eod_date = rm_vgm.eod_date
                        and    proj.projection_id = rm_volgrp.projection_id
                        and    rm_vgm.vol_id = proj.vol_id
                        and    rm_vgm.vol_id in (750)
                        and    rm_vgm.vol_id = v.vol_id
                        group by rm_vgm.vol_id, v.name
                        )
                        select c.vol_id, c.name, a.timeinterval_id sc_id, b.end_date, a.quotient
                        from marsp.vol_quotient a
                        , marsp.timeinterval b
                        , choose_proj d
                        , marsp.vol c
                        where
                           b.end_date between to_date('2007-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss') and to_date('2017-10-25 00:00:00','yyyy-mm-dd hh24:mi:ss')
                        and a.timeinterval_id = b.timeinterval_id
                        and d.proj_vol_id = a.vol_id
                        and d.vol_id = c.vol_id
                        order by c.vol_id, a.timeinterval_id)

    """

    a = select_from_query('infop',sql)
    print(a)
