"""
Get access to databases both using common and personal database / sign-on credentials

Warning:
    Sensitive or personal credentials MUST NOT be stored in this module.
    Use the "STORED_IN_PERSONAL_FOLDER" functionality for handling of these.

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       02JAN2017   G50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import os
import inspect
import base64
import six
import subprocess
from core.file import csv_IO
from core.caching import cache_driver
from core.utils import directory
from core.utils import version_independent
from core.utils import encryption


credential_store_folder = 'C:/setup/core/'
credential_store_file_path = os.path.join(credential_store_folder,'signon_info.csv')


def get_connection_info(connection_alias, info=0):
    """
    Get basic list of all credential pairs, used for sign-on to databases and external applications.


    Args:
        connection_alias        (str):              Name/alias for the connection that you want credentials for.
        info                    (int):              Level of information printed.  The higher, the more information is printed

    Returns:
        (dict):   Sign-on credentials and encryption type (user, password, encryption_type)

    Raises:

    Example:
        The module is called (from python) like this::
        
            signon_credentials = get_signon_info('INFOP' ,info = 0)

    Warning:

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # NB: All keys in the dictionaries below will be included as part of the sign-on string,
    # with the exception of DB_TYPE (must be specified), and the ENCRYPTION_TYPE (optional)
    #
    # DB_TYPE is used to find the correct connection odbc driver
    # ENCRYPTION_TYPE is used only for system users where the encrypted password is included
    # directly in the dictionary below
    # ===================================================================================
    signon_info = {
        # ===================================================================================
        # System users (shared users with password stored here) - encryption_type must be
        # specified with a key
        # ===================================================================================
        'INFOD'     :{'DB_TYPE':'Oracle'    ,'DBQ':'INFOD'      ,'USER':'MARSP' ,'PASSWORD':'Q293YW5kY2hpY2tlbjE2'      ,'ENCRYPTION_TYPE':'base64'},
        'UNITTEST'  :{'DB_TYPE':'Oracle'    ,'DBQ':'INFO3D'     ,'USER':'MARSP' ,'PASSWORD':'VGgxNV8xNV9BX1BBNTV3MHJE'  ,'ENCRYPTION_TYPE':'base64'},
        'AP-RISK5T' :{'DB_TYPE':'Oracle'    ,'DBQ':'AP-RISK5T'  ,'USER':'GUEST' ,'PASSWORD':'c2U='                      ,'ENCRYPTION_TYPE':'base64'},
        
        # TODO: Following currently uses same login on all environments. This needs to be changed
        'RFR'       :{'DB_TYPE':'Mongo'     ,'SOURCE':'admin'   ,'USER':'arnold','PASSWORD':'UDB3bnpBbGw='              ,'ENCRYPTION_TYPE':'base64'},
        'SE'        :{'DB_TYPE':'Mongo'     ,'SOURCE':'admin'   ,'USER':'arnold','PASSWORD':'UDB3bnpBbGw='              ,'ENCRYPTION_TYPE':'base64'},
        'ORCA'      :{                                           'USER':'NA','PASSWORD':'STORED_IN_PERSONAL_FOLDER'},

        # ===================================================================================
        # Personal users (password stored in personal folder) - is important that PASSWORD=='STORED_IN_PERSONAL_FOLDER'
        # as this keyword is used to trigger function that loads password from personal folder
        # ===================================================================================
        'INFOP'     :{'DB_TYPE':'Oracle'      ,'DBQ':'INFOP'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'INFOP_G'   :{'DB_TYPE':'Oracle'      ,'DBQ':'INFOP'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'INFOP_RO'  :{'DB_TYPE':'Oracle'      ,'DBQ':'INFOP'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'INFO3D'    :{'DB_TYPE':'Oracle'      ,'DBQ':'INFO3D'       ,'USER':'MARSP'           ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'INFOT'     :{'DB_TYPE':'Oracle'      ,'DBQ':'INFOT'        ,'USER':'MARSP'           ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'INFOAT'    :{'DB_TYPE':'Oracle'      ,'DBQ':'INFOAT'       ,'USER':'MARSP'           ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'INFOBT'    :{'DB_TYPE':'Oracle'      ,'DBQ':'INFOBT'       ,'USER':'MARSP'           ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
   'RISK_MANAGEMENT':{'DB_TYPE':'Oracle'      ,'DBQ':'INFOP'        ,'USER':'RISK_MANAGEMENT' ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'DAMDP_RO'  :{'DB_TYPE':'Oracle'      ,'DBQ':'DAMDP_RO'     ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'DAMDS'     :{'DB_TYPE':'Oracle'      ,'DBQ':'DAMDS'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'DAMDP'     :{'DB_TYPE':'Oracle'      ,'DBQ':'DAMDP'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'TRMP_RO'   :{'DB_TYPE':'Oracle'      ,'DBQ':'TRMP_RO'      ,'USER':'MARSP'           ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'TWP_RO'    :{'DB_TYPE':'Oracle'      ,'DBQ':'TWP_RO'       ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'TWP'       :{'DB_TYPE':'Oracle'      ,'DBQ':'TWP'          ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'TRMP'      :{'DB_TYPE':'Oracle'      ,'DBQ':'TRMP'         ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'DAMDS_WH'  :{'DB_TYPE':'Oracle'      ,'DBQ':'DAMDS'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_HORN_OF_WINTER'},
        'CRITP'     :{'DB_TYPE':'Oracle'      ,'DBQ':'CRITP'        ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'CVARCP'    :{'DB_TYPE':'Oracle'      ,'DBQ':'CVARCP'       ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'TIPP'      :{'DB_TYPE':'Oracle'      ,'DBQ':'TIPP'         ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'TIPP_RO'   :{'DB_TYPE':'Oracle'      ,'DBQ':'TIPP_RO'      ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        'RISKWP'    :{'DB_TYPE':'Oracle'      ,'DBQ':'RISKWP'       ,'USER':'NA'              ,'PASSWORD':'STORED_IN_PERSONAL_FOLDER'},
        # ===================================================================================
        # Trusted users (i.e. use windows credentials) - remember to add the key 'TRUSTED_CONNECTION':'YES'
        # ===================================================================================
        'TRMP_TRUST':{'DB_TYPE':'Oracle'        ,'TRUSTED_CONNECTION':'YES' ,'DBQ':'TRMP'           ,'NO_ODBC': True},
        'EDM'       :{'DB_TYPE':'SQL_Server'    ,'TRUSTED_CONNECTION':'YES' ,'SERVER':'VDA1CD0428'  ,'DATABASE':'EDM_GMCCR'},
        'FALMV'     :{'DB_TYPE':'SQL_Server'    ,'TRUSTED_CONNECTION':'YES' ,'SERVER':'VDA1XS0096'},
        'FALMP'     :{'DB_TYPE':'SQL_Server'    ,'TRUSTED_CONNECTION':'YES' ,'SERVER':'VDD1XS0099'},
        'FALMU'     :{'DB_TYPE':'SQL_Server'    ,'TRUSTED_CONNECTION':'YES' ,'SERVER':'VDA1CD0048'},
        'STARSP'    :{'DB_TYPE':'Teradata'      ,'TRUSTED_CONNECTION':'YES' ,'SERVER':'NDWP.DKD1'  ,'DBCName':'NDWP' ,'AUTHENTICATION':'LDAP'},

        # ===================================================================================
        # Windows Authentication (no user name and password)
        # The FORCE_NO_DSN == True option can be used to make sure that a full sign-on string
        # (including data base driver) is created. Otherwise a system DSN (ODBC) connection
        # will be used (if it exists).
        # ===================================================================================
        # Not everyone has TWP/TRMP connectino using Windows Authentication. These are disabled for now.
        # 'TWP':{'DB_TYPE':'Oracle'           ,'DBQ':'TWP'},
        # 'TRMP':{'DB_TYPE':'Oracle'          ,'DBQ':'TRMP'   ,'FORCE_NO_DSN': True},
    }

    try:
        relevant_signon_info = signon_info[connection_alias.upper()]
    except KeyError:
        error_message = ("No connection info found for alias '%s'. To fix, you must add connection info for '%s' to the"
                         " function %s.%s" % (connection_alias, connection_alias, __name__, inspect.stack()[0][3]))
        raise KeyError(error_message)

    return relevant_signon_info


def get_personal_credentials(connection_alias, info = 0):
    """
    Find personal credentials stored in physical file for a specific connection alias

    The function returns a dictionary with  user (name), password and the encryption type.
    Please always store passwords as encrypted...!

    Args:
        connection_alias        (str):              Name/alias for the connection that you want credentials for.
        info                    (int):              Level of information printed.  The higher, the more information is printed

    Returns:
        (dict):   Sign-on credentials and encryption type (user, password, encryption_type)

    Example:
        The module is called (from python) like this::

            signon_credentials = get_personal_credentials('INFOP' ,info = 0)

    Notes:
        Author: g50444
    """

    connection_alias_upcase = connection_alias.upper()

    # ==================================================================
    # Section 1: Looking for credentials in the personal csv storage
    # ==================================================================
    if os.path.isfile(credential_store_file_path) is True:

        signon_info_list = csv_IO.read_with_filter( file                 = credential_store_file_path,
                                                    filter_column_name   = 'DATABASE_ALIAS',
                                                    column_filter        = connection_alias_upcase,
                                                    info                 = 0
                                                    )
        signon_list_length = len(signon_info_list)
    else:
        # Sign-on info file does not exist.
        # We manually set the number of found credentials to zero, so user will be asked
        signon_list_length = 0

    # Exception is raised if no matching rows are found
    if signon_list_length == 1:
        # ==================================================================
        # Section 2: Handling of too many credentials found
        # ==================================================================

        # All fine. One matching sign-on credential pair found- just as we hoped
        if type(signon_info_list) is dict:
            signon_info = signon_info_list
        else:
            # List is converted to dictionary
            signon_info = signon_info_list[0]

    elif signon_list_length == 0:
        # ==================================================================
        # Section 3: Asking user for signon credentials. Adding to file.
        # ==================================================================

        # No sign-on credentials found for the specified database alias.
        # Ask user for input, and add it to the file...
        signon_info = update_personal_credentials(connection_alias = connection_alias_upcase,info = info)
    else:
        raise ValueError("Expected one or zero rows for DATABASE_ALIAS = '" + connection_alias_upcase
                         +"' in "   + credential_store_file_path
                         + " but "  + str(signon_list_length) + " was found!"
                         )

    user            = signon_info['USER']
    pw              = signon_info['PASSWORD']
    encryption_type = signon_info['ENCRYPTION_TYPE']

    return {'USER': user,'PASSWORD': pw, 'ENCRYPTION_TYPE': encryption_type}


def update_personal_credentials(connection_alias, info = 0):
    connection_alias_upcase = connection_alias.upper()
    signon_info = user_input_credentials(connection_alias=connection_alias_upcase,
                                         info=info
                                         )
    try:
        directory.create(directory_path=credential_store_folder,
                         info=info
                         )

        csv_IO.add_rows(file_path=credential_store_file_path,
                        data_to_add=[signon_info],
                        info=info
                        )
    except:
        print('Not able to save personal credentials in "' + credential_store_file_path + '". Not critical.')

    return signon_info


def user_input_credentials(connection_alias, info = 0):
    """
    Interface for getting user credentials from the user

    The function asks user for user-name and password for the specified connection alias.
    Password is instantly encrypted using base64 encryption.

    Args:
        connection_alias        (str):              Name/alias for the connection that you want credentials for.
        info                    (int):              Level of information printed.  The higher, the more information is printed

    Returns:
        (dict):   Sign-on credentials and encryption type (user, password (encrypted), encryption_type)

    Raises:

    Example:
        The module is called (from python) like this::
        
            Sign-on_credentials = user_input_credentials('INFOP' ,info = 0)

    Warning:
        The password is encrypted at input, but encryption is very basic and easy to decrypt

    Notes:
        Author: g50444
    """

    connection_alias_upcase = connection_alias.upper()


    try:
        # ===================================================================================
        # easygui is currently not part of the standard distribution. We fall back to old method
        # when the module can't be imported (until added to the distribution).
        # ===================================================================================
        import easygui
        # ===================================================================================
        # If user "forgets" to input user-name of password the input will be interpret as
        # an empty string. In that case they will be asked again.
        # This is done by initializing user_name and password to empty strings, and
        # putting the input box in a while loop.
        # ===================================================================================
        user_name       = ''
        pw_encrypted    = ''
        org_msg         = "Please enter sign-on credentials for " + connection_alias + "."
        msg             = org_msg
        title           = "Credentials for " + connection_alias

        while '' in (user_name, pw_encrypted):
            login = easygui.multpasswordbox(msg     = msg,
                                            title   = title,
                                            fields  = ["User Name", "Password"],
                                            )
            user_name = login[0]
            pw_encrypted = encryption.encrypt(login[1])
            msg = "Did not get input for either User Name of Password. You can do better! \n\n" + org_msg
    except ImportError:
        user_name   = version_independent.get_input("Please enter a username for " + connection_alias_upcase + ": ")
        password    = version_independent.get_input("Please enter the password for "
                                                    + user_name
                                                    + "@"
                                                    + connection_alias_upcase
                                                    + ": "
                                                    )

        pw_encrypted    =  encryption.encrypt(password)

    if info > 0:
        print(user_name)

    return {'DATABASE_ALIAS':connection_alias_upcase,'USER': user_name,'PASSWORD': pw_encrypted, 'ENCRYPTION_TYPE': 'base64'}


def delete_personal_credentials(connection_alias, info = 0):
    """
    Delete personal credentials stored on local drive, for a specific connection alias


    Args:
        connection_alias        (str):        Name/alias for the connection that you want credentials for.  
        param info              (int):        Level of information printed.  The higher, the more information is printed

    Returns:
        Nothing

    Raises:

    Example:
        The module is called (from python) like this::
        
            delete_personal_credentials(connection_alias = 'h:/setup/core/signon_info.csv', info = 0)

    Warning:

    Notes:
        Author: g50444
    """

    connection_alias_upcase = connection_alias.upper()

    try:
        csv_IO.delete_rows(file_path                    = credential_store_file_path,
                           delete_filter_column_name    = 'DATABASE_ALIAS',
                           delete_column_filter         = connection_alias_upcase,
                           case_sensitive               = False,
                           info                         = info
                           )
    except:
        raise


def get_HttpNtlmAuth(test_connection=True):
    """
    Function to get the HTTP NTLM authorization used for connecting to the MDS web service. Has a crude implementation
    for testing if the connection works against a market data for a hardcoded ISIN+date on MDS - if a password issue
    is observed, the user is prompted to re-enter their password
    """
    import requests_ntlm
    info = get_personal_credentials('windows')
    encoded_pw = info['PASSWORD'].encode("utf-8")
    pw = base64.b64decode(encoded_pw)
    pw = pw.decode() if isinstance(pw, bytes) else pw
    user = info['USER']
    auth = requests_ntlm.HttpNtlmAuth(username=user, password=pw, send_cbt=False)
    if test_connection:
        found_working_auth = False
        try_users = [user, 'ONEADR//'+user, 'ONEADR//ONEADR//'+user]
        for x in try_users:
            if not found_working_auth:
                if try_NtlmAuth(requests_ntlm.HttpNtlmAuth(username=x, password=pw, send_cbt=False)):
                    found_working_auth = True

        if not found_working_auth:
            ask_update_pass_for_windows()
    return auth


def ask_update_pass_for_windows():
    update_pw = version_independent.get_input('\n' + '=' * 60 + "\n The found windows credentials did not provide access."
                                                                "\n The issue seems to be password related.\n\n Would you "
                                                                "like to input your credentials manually and try again? "
                                                                "(Y/N): ").upper()
    if update_pw == 'Y':
        delete_personal_credentials(connection_alias='windows')
        update_personal_credentials(connection_alias='windows')
    else:
        raise UserWarning("Password did not provide access...")


def try_NtlmAuth(auth):
    import requests
    service_arg = "http://mds.oneadr.net/v1/marketdata/prices/reval?Isins=DK0009792525&TradeDate=2017-04-28&format=json"

    headers = {'accept': 'application/json;odata=verbose'}
    response = requests.get(url=service_arg, auth=auth, headers=headers)
    status_code = response.status_code
    if 200 <= status_code < 300:
        return True
    else:
        return False


@cache_driver.easy_cache(credential_store_folder)
def get_outlook_mail_address():
    """
    Returns your email address by querying powershell.

    Returns:
        Your email address (i.e. xxx@nordea.com)

    Notes:
        Author: g48606
    """
    bitstring_mail = "KABbAEEARABTAEkAXQAoACIATABEAEEAUAA6AC8ALwAiACAAKwAgACgAdwBoAG8AYQBtAGkAIAAvAGYAcQBkAG4AKQApACkALgBtAGEAaQBsAA=="
    mail = subprocess.Popen("powershell.exe -e " + bitstring_mail, stdout=subprocess.PIPE).stdout.readline().strip()
    if six.PY3:
        mail = mail.decode()
    return mail


if __name__ == '__main__':
    # from core.connection import database_connect
    # a = database_connect.get_string('trmp')
    # print(a)
    print(get_outlook_mail_address())