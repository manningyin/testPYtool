"""
A module for connecting to the various APIs we are using. A few functions for connecting to the MongoDB for RFR and SE
is also included in this module

The functions in this module fetches environment specific connection information from core.system.ext_envir. If
credentials are needed, these are taken from core.connection.credentials.
This information is then passed on to the various python packages (scenario-definer, scenario-generator,
scenario-executor, risk-factor-repository, etc.) which then returns the requested API instance.

Warning:
    If the API connection doesn't seem to work, please make sure your python package for the given API is up-to-date.
    Example of update (for scenario-definer): "pip install --upgrade --force-reinstall scenario-definer==1.0"

    If the connection still does not work, you can get in touch with IT

Notes:
    Author: g48606

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       21feb2018   G48606      Initial creation
    2       19nov2018   G46435      Added report-orchestrator api
    ======= =========   =========   ========================================================================================
"""
try:
    import ripl_core
except ModuleNotFoundError:
    err = "You are missing the ripl_core package. Please install it through pip"
    raise ModuleNotFoundError(err)
from core.system import ext_envir
from core.connection import credentials
from core.utils import encryption
from pymongo import MongoClient
import scenario_definer.build_api_client
import scenario_generator.build_api_client
import report_orchestrator.build_api_client
import se_full_valuation.build_api_client
import risk_factor_repository.build_api_client
import trade_information_service.build_api_client
import vip_definer.build_api_client
import risk_factor_curator.build_api_client
import isin_categorization_reconciliator.build_api_client
import warnings
import consul


def get_function_with_suffix(api_class, function_name):
    """
    The auto-generated python code for linking to the SWAGGER-UI gives functions suffixes between 0 and 9 if several
    functions has the same name or has had the same name. This function finds the suffixes for a given function by
    using "hasattr" and looping over integers between 0 and 9. If more than one function exists, a warning is raised
    and the first one is returned.

    Args:
        api_class    (class instance):  Instance of the API class for the service (definer/generator/executor/etc.)
        function_name           (str):  Name of the function we wish to use

    Returns:
        (method):  The function attribute of the class (with correct suffix)

    Raises:
         If the API has several functions with the same name (but different suffix), a warning will be raised
         If the API has no functions with the given name, an error will be raised

    Notes:
        Author: g48606
    """
    out = []
    if hasattr(api_class, function_name):
        out.append(function_name)
    for i in range(10):
        if hasattr(api_class, function_name + str(i)):
            out.append(function_name + str(i))
    if len(out) > 1:
        error_msg = "API has several functions with the same name: %s \n we will use the first function: '%s'" % (out, out[0])
        warnings.warn(error_msg)
    if len(out) < 1:
        error_msg = "API did not contain requested function: %s" % function_name
        raise AttributeError(error_msg)
    else:
        return getattr(api_class, out[0])


class risk_factor_repository_api:
    """
    Using the external environment configuration found in core.system.ext_envir for Risk Factor Repository, this class
    returns API instances for the following services:

        - Risk factor controller
        - Risk factor metadata controller
        - Risk factor context controller
        - Market data context controller
    """
    def __init__(self, envir=None):
        _server_map = ext_envir.RiskFactorRepository().risk_factor_repository
        if envir is not None:
            _server_map['environment'] = envir
        _api = risk_factor_repository.build_api_client.build_api_client(**_server_map)
        self.riskfactor = risk_factor_repository.RiskFactorControllerApi(api_client=_api)
        self.metadata = risk_factor_repository.RiskFactorMetaDataControllerApi(api_client=_api)
        self.riskfactorcontext = risk_factor_repository.RiskFactorsContextControllerApi(api_client=_api)
        self.marketdatacontext = risk_factor_repository.MarketDataMappingControllerApi(api_client=_api)
        self.rf_with_metadata = risk_factor_repository.RiskFactorWithMetaDataControllerApi(api_client=_api)
        self.proxycontext = risk_factor_repository.RiskFactorProxyControllerApi(api_client=_api)


def risk_factor_curator_api():
    server_map = ext_envir.RiskFactorRepository().risk_factor_curator
    api = risk_factor_curator.build_api_client.build_api_client(**server_map)
    return risk_factor_curator.RiskFactorFactoryControllerApi(api_client=api)


def historical_scenario_definer_api():
    """
    Using the external environment configuration found in core.system.ext_envir for ScenarioEngine, this function returns
    an API instance for scenario definer
    """
    server_map = ext_envir.ScenarioEngine().scenario_definer
    api = scenario_definer.build_api_client.build_api_client(**server_map)
    return scenario_definer.HistoricalScenarioControllerApi(api_client=api)


def deterministic_scenario_definer_api():
    """
    Using the external environment configuration found in core.system.ext_envir for ScenarioEngine, this function returns
    an API instance for scenario definer
    """
    server_map = ext_envir.ScenarioEngine().scenario_definer
    api = scenario_definer.build_api_client.build_api_client(**server_map)
    return scenario_definer.DeterministicScenarioControllerApi(api_client=api)


class scenario_generator_api:
    """
    Using the external environment configuration found in core.system.ext_envir for ScenarioEngine, this function returns
    an API instance for scenario generator
    """
    def __init__(self):
        server_map = ext_envir.ScenarioEngine().scenario_generator
        api = scenario_generator.build_api_client.build_api_client(**server_map)
        self.scenario_pack = scenario_generator.ScenarioPackControllerApi(api_client=api)
        self.historical_scenario = scenario_generator.HistoricScenarioGeneratorControllerApi(api_client=api)
        self.deterministic_scenario = scenario_generator.DeterministicScenarioGeneratorControllerApi(api_client=api)


def report_orchestrator_api():
    """
    Using the external environment configuration found in core.system.ext_envir for ScenarioEngine, this function returns
    an API instance for report orchestrator
    """
    server_map = ext_envir.ScenarioEngine().report_orchestrator
    api = report_orchestrator.build_api_client.build_api_client(**server_map)
    return report_orchestrator.ReportConfigurationControllerApi(api_client=api)


def report_dispatcher_api():
    """
       Using the external environment configuration found in core.system.ext_envir for ScenarioEngine, this function returns
       an API instance for report orchestrator
       """
    server_map = ext_envir.ScenarioEngine().report_orchestrator
    api = report_orchestrator.build_api_client.build_api_client(**server_map)
    return report_orchestrator.ReportDispatcherControllerApi(api_client=api)


def event_trigger_api():
    server_map = ext_envir.ScenarioEngine().report_orchestrator
    api = report_orchestrator.build_api_client.build_api_client(**server_map)
    return report_orchestrator.EventTriggerConfigurationControllerApi(api_client=api)


def report_controller_api():
    server_map = ext_envir.ScenarioEngine().report_orchestrator
    api = report_orchestrator.build_api_client.build_api_client(**server_map)
    return report_orchestrator.ReportControllerApi(api_client=api)


def report_execution_controller_api():
    server_map = ext_envir.ScenarioEngine().report_orchestrator
    api = report_orchestrator.build_api_client.build_api_client(**server_map)
    return report_orchestrator.ExecutionResultStorageReferenceControllerApi(api_client=api)


def report_downloader_api():
    server_map = ext_envir.ScenarioEngine().report_orchestrator
    api = report_orchestrator.build_api_client.build_api_client(**server_map)
    return report_orchestrator.ClStorageDownloadControllerApi(api_client=api)


def se_full_reval_api():
    """
    Using the external environment configuration found in core.system.ext_envir for ScenarioEngine, this function returns
    an API instance for full reval scenario execution
    """
    server_map = ext_envir.ScenarioEngine().se_full_reval
    api = se_full_valuation.build_api_client.build_api_client(**server_map)
    return se_full_valuation.ScenarioDslExecutionControllerApi(api_client=api)


class trade_position_api:
    def __init__(self):
        _server_map = ext_envir.TradePositionGateway().trade_information_service
        _api = trade_information_service.build_api_client.build_api_client(**_server_map)
        self.position_controller = trade_information_service.PositionInformationControllerApi(api_client=_api)
        self.trade_controller = trade_information_service.TradeInformationControllerApi(api_client=_api)


def virtual_portfolio_api():
    server_map = ext_envir.TradePositionGateway().vip_definer
    api = vip_definer.build_api_client.build_api_client(**server_map)
    # return vip_definer.VipCriteriaConfigurationResourceApi(api_client=api)
    return vip_definer.VipCriteriaConfigurationControllerApi(api_client=api)


def isin_categorisation_reconciliator():
    server_map = ext_envir.TradePositionGateway().isin_categorisation_reconciliator
    api = isin_categorization_reconciliator.build_api_client.build_api_client(**server_map)
    return isin_categorization_reconciliator.CategorizationControllerApi(api_client=api)


def _connect_mongo(consulHost, consulPort, consulScheme, consulTag, service=None, token=None):
    """
    A helper function used for creating connections to MongoDB. Returns an instance of the mongo client with server
    information
    """
    # TODO: MongoDB only works for consulTag = 'dev' currently, thus this is hard-coded here. Should be fixed...
    if consulTag != 'dev':
        print("MongoDB only works for consulTag = 'dev' currently, thus we override user input")
        consulTag = 'dev'
    client = consul.Consul(host=consulHost, port=consulPort, scheme=consulScheme)
    service = client.health.service(service=service, passing=True, tag=consulTag, token=token)
    return MongoClient(map(lambda n: n['Node']['Address'] + ':' + str(n['Service']['Port']), service[1]))


def get_rf_db():
    """
    Opens a connection to the MongoDB for RFR by using the external environment configuration found in
    core.system.ext_envir for Risk Factor Repository and the credentials found in core.connection.credentials
    """
    server_map = ext_envir.RiskFactorRepository().risk_factor_repository
    client = _connect_mongo(service='mongo_SE=None', **server_map)
    rf_db = client['rfr']
    creds = credentials.get_connection_info('RFR')
    creds['PASSWORD'] = encryption.decrypt(creds['PASSWORD'], encode_type=creds.pop('ENCRYPTION_TYPE'))
    rf_db.authenticate(name=creds['USER'], password=creds['PASSWORD'], source=creds['SOURCE'])
    return rf_db


def get_se_db():
    """
    Opens a connection to the MongoDB for SE by using the external environment configuration found in
    core.system.ext_envir for Scenario Engine and the credentials found in core.connection.credentials
    """
    server_map = ext_envir.RiskFactorRepository().risk_factor_repository
    client = _connect_mongo(service='mongo_SE=None', **server_map)
    se_db = client['se-definition']
    creds = credentials.get_connection_info('SE')
    creds['PASSWORD'] = encryption.decrypt(creds['PASSWORD'], encode_type=creds.pop('ENCRYPTION_TYPE'))
    se_db.authenticate(name=creds['USER'], password=creds['PASSWORD'], source=creds['SOURCE'])
    return se_db


if __name__ == '__main__':
    # rfr_api = risk_factor_repository_api()
    # sd_api = historical_scenario_definer_api()
    # sg_api = scenario_generator_api()
    ro_api = report_orchestrator_api()
    print(ro_api)
    #rf_db = get_rf_db()
    #se_db = get_se_db()



