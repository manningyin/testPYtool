"""
Common utility functions for using Orca
Functions is copied from ad-hoc/frtb_ima_prototype/test

Notes:
    Author: g48454

    ======= =========   =========   ===================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ===================================================================================
    1       08JUL2017   Shengyao    Initial creation
    2       13jul2017   JonasB      Added source_system function
    3       19feb2018   Oskar       Redirected configuration to core.system.ext_envir and removed redundant functions
    ======= =========   =========   ===================================================================================
"""
import orca.types
import orca.services.service_bundle as req
import datetime as dt
from core.caching import cache_driver
from core.system import ext_envir
import pandas as pd
import quantum as qt
import six
_eod_hour = 23
_eod_minute = 59


def yesterday():
    """
    Functions is copied from ad-hoc/frtb_ima_prototype/test
    """
    return dt.datetime.today().replace(hour=_eod_hour, minute=_eod_minute, second=0, microsecond=0) - dt.timedelta(days=1)


def to_eod(date, hour=_eod_hour, minute=_eod_minute):
    return dt.datetime(year=date.year, month=date.month, day=date.day, hour=hour, minute=minute)


def get_orca_timestamp(eod_date, db_date=yesterday()):
    """
    Functions is copied from ad-hoc/frtb_ima_prototype/test
    """
    datetime0 = to_eod(date = eod_date, hour = _eod_hour, minute=_eod_minute)
    return orca.types.ContextTimeStamp.end_of_day_from_date(value_date=datetime0)


@cache_driver.memory_cache
def cur_orca_version():
    _cfg = ext_envir.ORCA().config
    return req.PricingService(_cfg).get_version().result().python_client_version


# @cache_driver.memory_cache
def get_orca_request():
    """
    Wrapper for opening a connection to the current configured external environment for ORCA.

    Features:
    - Loads configured environment from data/config.yml
    - Loads username and encrypted password from local credentials file (c:\setup\mr\signon_info.csv)
    - Checks most recent available python version for configured environment against version number of locally installed
      ORCA version

    Notes:
        Author: g48606
    """
    _cfg = ext_envir.ORCA().config
    # print(_cfg)
    _envir = ext_envir.ORCA().envir.upper()
    _orca_version = cur_orca_version()
    _local_version = orca.__version__
    if _orca_version != _local_version:
        print('There is a newer version of ORCA (%(_envir)s environment) available: %(_orca_version)s. Your current '
              'version is %(_local_version)s.\nPlease update to the newest ORCA version using the command "pip install '
              'orca==%(_orca_version)s"' % locals())
    return req.ServiceBundle(_cfg)


@cache_driver.easy_cache(cachepath="C:/working/data/easy_cache/holiday_factory/")
def get_orca_holiday_factory():
    req = get_orca_request()
    return req.get_holiday_factory_for_all_centers().result()


def orca_bdates_eur_calendar(start_date, end_date):
    req = get_orca_request()
    hf = req.get_holiday_factory('EUR', get_orca_timestamp(end_date)).result()
    fixed_holidays = hf.fixedHolidays
    bdates = pd.bdate_range(start=start_date, end=end_date)
    return bdates.difference(fixed_holidays)


@cache_driver.MemoizeMutable
@cache_driver.easy_cache()
def get_global_holidays():
    """
    get global holiday calendar for scenario calculation, use ECB target calendar
    """
    return ORCA_holidays([qt.Currency.EUR])[qt.Currency.EUR]


@cache_driver.MemoizeMutable
@cache_driver.easy_cache()
def ORCA_holidays(currencies):
    date0 = yesterday()
    _service_requests = get_orca_request()
    _holiday_factory = _service_requests.get_holiday_factory_for_all_centers().result()
    liborconv = _service_requests.get_libor_convention(currencies=currencies,
                                                       timestamp=get_orca_timestamp(date0),
                                                       holiday_factory=_holiday_factory).result()
    if six.PY2:
        return dict((ccy, liborconv[ccy].fixedHolidays()) for ccy in currencies)
    else:
        return dict((ccy, liborconv[ccy].fixedHolidays) for ccy in currencies)


def easy_value_isins(eod, isins, scenarios=None):
    ctx = orca.types.ModelConfigurationContext.make_eod_context()
    stamp = get_orca_timestamp(eod)
    securities = tuple(orca.types.SecurityIdentifier(isin, orca.types.SecurityType.BOND) for isin in isins)
    spec = orca.types.TradeSpecification(security_identifiers=securities)

    req = get_orca_request()
    return req.value_trade(time_stamp=stamp, model_configuration_context=ctx, trade_specification=spec, scenarios=scenarios).result()


if __name__ == '__main__':
    ext_envir.update(ext_envir.ORCA.dev)
    a = orca_bdates_eur_calendar(dt.datetime(2018, 1, 1), dt.datetime(2018, 2, 1))

    from core.system import ext_envir
    ext_envir.update(ext_envir.ORCA.prod)