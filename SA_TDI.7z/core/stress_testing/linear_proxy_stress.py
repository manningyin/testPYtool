import pyodbc
import pandas as pd
from core.caching.cache_driver import easy_cache
from core.connection import database_connect
from core.stress_testing import stress_helper
from core.utils import date_helper


class InterestProxyStress:
    def __init__(self, cons_org_id=50004, position_supergrp='NI4', rm_interest_supergrp=2, database='INFOP'):
        self._cons_org_id = cons_org_id
        self._position_supergrp = position_supergrp
        self._rm_interest_supergrp = rm_interest_supergrp
        self._database = database

    def interest_proxies_with_data(self, eod_date):
        oracle_date = date_helper.oracle_to_date(eod_date)
        conn = pyodbc.connect(database_connect.get_string(self._database))
        sql_sens = """select /*+ materialize */ distinct a.INTEREST_ID
                      from MARSP.INTEREST_SENS a, MARSP.CONS_ORG_STRUCTURE_STD_HIST B, MARSP.POSITION_SUPERGRP_POSITION_GRP C
                      where a.EOD_DATE = %s
                      and a.EOD_DATE = B.EOD_DATE
                      and a.ORG_ID = B.ORG_ID
                      and B.CONS_ORG_ID = %s
                      and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                      and C.POSITION_SUPERGRP_ID = '%s'
                      group by a.EOD_DATE, a.INTEREST_ID""" % (oracle_date, self._cons_org_id, self._position_supergrp)
        interest_ids_with_sens = ', '.join(map(str, pd.read_sql(sql_sens, conn)['INTEREST_ID'].astype(int).tolist()))

        sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.INTEREST_ID SPECIFIC_INTEREST_ID, E.name SPECIFIC_NAME, 
                               C.PROJECTION_INTEREST_ID, D.name PROJECTION_NAME, D.INTEREST_MARKET_ID PROJECTION_MARKET
                        from MARSP.RM_INTEREST_GRP_MAPPING a, MARSP.RM_INTEREST_GRP B, MARSP.PROJECTION_INTEREST_MAPPING C, 
                             MARSP.INTEREST D, MARSP.INTEREST E, MARSP.INTEREST_RATE F
                        where RM_INTEREST_SUPERGRP_ID = %s
                        and a.EOD_DATE = %s
                        and a.RM_INTEREST_GRP_ID = B.RM_INTEREST_GRP_ID
                        and B.PROJECTION_ID = C.PROJECTION_ID
                        and a.INTEREST_ID = C.INTEREST_ID
                        and a.EOD_DATE = C.EOD_DATE
                        and C.PROJECTION_INTEREST_ID = D.INTEREST_ID
                        and C.INTEREST_ID = E.INTEREST_ID
                        and C.INTEREST_ID != C.PROJECTION_INTEREST_ID
                        and C.INTEREST_ID in (%s)
                        and a.EOD_DATE = F.EOD_DATE
                        and a.INTEREST_ID = F.INTEREST_ID
                        and F.TERM_ID = '1Y'""" % (self._rm_interest_supergrp, oracle_date, interest_ids_with_sens)

        df = pd.read_sql(sql=sql_string, con=conn)
        df['SPECIFIC_INTEREST_ID'] = df['SPECIFIC_INTEREST_ID'].astype(int)
        df['PROJECTION_INTEREST_ID'] = df['PROJECTION_INTEREST_ID'].astype(int)
        return df

    def interest_sens_specifics(self, eod_date, interest_ids):
        interest_ids = interest_ids if isinstance(interest_ids, list) else [interest_ids]
        interest_id_lst = ", ".join(map(str, interest_ids))
        date = date_helper.oracle_to_date(eod_date)
        sql_string = """select a.INTEREST_ID, d.TO_TERM_ID TERM_ID, SUM(a.SENS_BASE*d.WGT) SENS_BASE
                        from MARSP.INTEREST_SENS a, MARSP.CONS_ORG_STRUCTURE_STD_HIST B, 
                             MARSP.POSITION_SUPERGRP_POSITION_GRP C, MARSP.LADDER_TERM_WGT D
                        where a.EOD_DATE = %s
                        and a.EOD_DATE = B.EOD_DATE
                        and a.ORG_ID = B.ORG_ID
                        and B.CONS_ORG_ID = %s
                        and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                        and C.POSITION_SUPERGRP_ID = '%s'
                        and a.TERM_ID = D.TERM_ID
                        and a.EOD_DATE = D.EOD_DATE
                        and D.TO_LADDER_ID = 68
                        and a.INTEREST_ID in (%s)
                        group by a.INTEREST_ID, D.TO_TERM_ID""" % (date, self._cons_org_id, self._position_supergrp, interest_id_lst)
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql=sql_string, con=conn)
        df['INTEREST_ID'] = df['INTEREST_ID'].astype(int)
        return df

    def interest_specific_rates(self, eod_date, interest_ids, with_corrections):
        ir_table = 'HS_INTEREST_RATE' if with_corrections else 'INTEREST_RATE'
        price_type = '--' if with_corrections else ''
        date = date_helper.oracle_to_date(eod_date)
        interest_lst = ', '.join(map(str, interest_ids))
        sql_string = """select A.EOD_DATE, A.INTEREST_ID, A.TERM_ID, B.INTEREST_MARKET_ID, A.INTEREST_PCT
                        from MARSP.%s a, MARSP.INTEREST b, MARSP.LADDER_TERM c
                        where A.INTEREST_ID in (%s)
                        and A.INTEREST_ID = b.INTEREST_ID
                     %s and A.PRICE_TYPE_ID = 'INT'
                        and A.TERM_ID = C.TERM_ID
                        and C.LADDER_ID = 68
                        order by A.EOD_DATE, A.INTEREST_ID, A.TERM_ID""" % (ir_table, interest_lst, price_type)
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql_string, conn)
        start_day = pd.read_sql("select MARSP.DAGE.ADDERDAGE(%s, -500, null, 'BNK') X from dual" % date, conn)['X'][0]
        df['INTEREST_ID'] = df['INTEREST_ID'].astype(int)
        df = df[df['EOD_DATE'] >= start_day]
        return df

    def interest_proxy_basis(self, eod_date, specific_id, proxy_id):
        date = date_helper.oracle_to_date(eod_date)
        sql_string = """select a.EOD_DATE, a.TERM_ID, A.INTEREST_PCT - B.INTEREST_PCT PROXY_BASIS
                        from MARSP.INTEREST_RATE a, MARSP.INTEREST_RATE B, MARSP.LADDER_TERM C
                        where a.INTEREST_ID = %(specific_id)s
                        and b.INTEREST_ID = %(proxy_id)s
                        and a.EOD_DATE = B.EOD_DATE
                        and a.TERM_ID = B.TERM_ID
                        and a.TERM_ID = C.TERM_ID
                        and c.LADDER_ID = 68
                        and a.EOD_DATE > MARSP.DAGE.ADDERDAGE(%(date)s, -500, null, 'BNK')
                        order by a.EOD_DATE, c.TERM_NO""" % locals()
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql=sql_string, con=conn)
        return df

    def interest_proxy_ES(self, eod_date):
        interest_proxies = self.interest_proxies_with_data(eod_date=eod_date)
        sens = self.interest_sens_specifics(eod_date=eod_date,
                                            interest_ids=interest_proxies['SPECIFIC_INTEREST_ID'].tolist())
        specific_rates = self.interest_specific_rates(eod_date=eod_date,
                                                      interest_ids=interest_proxies['SPECIFIC_INTEREST_ID'].tolist(),
                                                      with_corrections=False)
        proxy_rates = self.interest_specific_rates(eod_date=eod_date,
                                                   interest_ids=interest_proxies['PROJECTION_INTEREST_ID'].unique(),
                                                   with_corrections=True)

        out_specific = pd.DataFrame()
        out_proxy = pd.DataFrame()
        for row in interest_proxies.iterrows():
            specific = row[1]['SPECIFIC_INTEREST_ID']
            proxy = row[1]['PROJECTION_INTEREST_ID']
            specific_sens = sens[sens['INTEREST_ID'] == specific]
            if specific_sens.empty or all(x == 0 for x in specific_sens['SENS_BASE']):
                continue

            specific_ts = specific_rates[specific_rates['INTEREST_ID'] == specific].copy().sort_values(by='EOD_DATE')
            tmp_df = pd.DataFrame()
            for term_id in specific_ts['TERM_ID'].unique():
                tmp = specific_ts[specific_ts['TERM_ID'] == term_id].copy()
                tmp['INTEREST_RETURN'] = tmp['INTEREST_PCT'] - tmp['INTEREST_PCT'].shift(1)
                tmp_df = tmp_df.append(tmp)
            specific_ts = tmp_df
            specific_ts = specific_ts.merge(specific_sens[['TERM_ID', 'SENS_BASE']], on='TERM_ID')
            specific_ts['RETURN'] = specific_ts['INTEREST_RETURN'] * specific_ts['SENS_BASE']
            out_specific = out_specific.append(specific_ts)

            proxy_ts = proxy_rates[proxy_rates['INTEREST_ID'] == proxy].copy().sort_values(by='EOD_DATE')
            tmp_df = pd.DataFrame()
            for term_id in proxy_ts['TERM_ID'].unique():
                tmp = proxy_ts[proxy_ts['TERM_ID'] == term_id].copy()
                tmp['INTEREST_RETURN'] = tmp['INTEREST_PCT'] - tmp['INTEREST_PCT'].shift(1)
                tmp_df = tmp_df.append(tmp)
            proxy_ts = tmp_df
            proxy_ts = proxy_ts.merge(specific_sens[['TERM_ID', 'SENS_BASE']], on='TERM_ID')
            proxy_ts['RETURN'] = proxy_ts['INTEREST_RETURN'] * proxy_ts['SENS_BASE']
            out_proxy = out_proxy.append(proxy_ts)

        out = dict()
        for market in interest_proxies['PROJECTION_MARKET'].unique():
            proxy_es = sum(sorted(out_proxy[out_proxy['INTEREST_MARKET_ID'] == market].groupby('EOD_DATE').sum()['RETURN'])[:6])/6
            proxy_ids = out_proxy[out_proxy['INTEREST_MARKET_ID'] == market]['INTEREST_ID'].unique()
            specific_ids_matching_proxy_ids = interest_proxies[interest_proxies['PROJECTION_INTEREST_ID'].isin(proxy_ids)]['SPECIFIC_INTEREST_ID'].unique()
            specific_es = sum(sorted(out_specific[out_specific['INTEREST_ID'].isin(specific_ids_matching_proxy_ids)].groupby('EOD_DATE').sum()['RETURN'])[:6])/6
            out[market] = [proxy_es, specific_es, specific_es/proxy_es]

        specific_total = sum(sorted(out_specific.groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_total = sum(sorted(out_proxy.groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        total_ratio = specific_total / proxy_total

        cols = ['Proxy ES', 'Specific ES', 'Ratio']
        out_df = pd.DataFrame.from_dict(out, orient='index')
        out_df.columns = cols

        market_split_specific = sum(x[1] for x in out.values())
        market_split_proxy = sum(x[0] for x in out.values())
        out_df = out_df.append(pd.DataFrame([[market_split_proxy, market_split_specific, market_split_specific/market_split_proxy]],
                                            index=['Market split'], columns=cols))
        out_df = out_df.append(pd.DataFrame([[proxy_total, specific_total, total_ratio]],
                                            index=['Total'], columns=cols))

        return out_df

    def interest_basis_ES(self, eod_date):
        interest_proxies = self.interest_proxies_with_data(eod_date=eod_date)
        sens = self.interest_sens_specifics(eod_date=eod_date, interest_ids=interest_proxies['SPECIFIC_INTEREST_ID'].tolist())

        out = pd.DataFrame()
        for row in interest_proxies.iterrows():
            # row[0] is the index of the row, row[1] is the actual contents of the row
            specific = row[1]['SPECIFIC_INTEREST_ID']
            proxy = row[1]['PROJECTION_INTEREST_ID']
            specific_sens = sens[sens['INTEREST_ID'] == specific]
            if specific_sens.empty or all(x == 0 for x in specific_sens['SENS_BASE']):
                continue
            # NB: Important that this is all sens equal to 0, rather than the sum equal to 0 - it could potentially net out
            basis_ts = self.interest_proxy_basis(specific_id=specific, proxy_id=proxy)
            basis_ts = basis_ts.merge(specific_sens, on='TERM_ID')
            basis_ts['RETURN'] = basis_ts['PROXY_BASIS'] * basis_ts['SENS_BASE']

            out = out.append(basis_ts)

        final = out.groupby('EOD_DATE').sum()[['RETURN']].sort_values(by='RETURN', ascending=True)
        expected_shortfall = sum(final['RETURN'][:6]) / 6
        return expected_shortfall


class SpreadProxyStress:
    def __init__(self, cons_org_id=50004, position_supergrp='AC2', rm_spread_supergrp=1, database='INFOP'):
        self._cons_org_id = cons_org_id
        self._position_supergrp = position_supergrp
        self._rm_spread_supergrp = rm_spread_supergrp
        self._database = database

    def spread_proxies_with_data(self, eod_date):
        date = date_helper.oracle_to_date(eod_date)
        sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.SPREAD_ID SPECIFIC_SPREAD_ID, E.name SPECIFIC_NAME, C.PROJECTION_SPREAD_ID, D.name PROJECTION_NAME
                        from MARSP.RM_SPREAD_GRP_MAPPING a, MARSP.RM_SPREAD_GRP B, MARSP.PROJECTION_SPREAD_MAPPING C, MARSP.SPREAD D, MARSP.SPREAD E, marsp.SPREAD_RATE f
                        where RM_SPREAD_SUPERGRP_ID = %s
                        and a.EOD_DATE = %s
                        and a.RM_SPREAD_GRP_ID = B.RM_SPREAD_GRP_ID
                        and B.PROJECTION_ID = C.PROJECTION_ID
                        and a.SPREAD_ID = C.SPREAD_ID
                        and a.EOD_DATE = C.EOD_DATE
                        and C.PROJECTION_SPREAD_ID = D.SPREAD_ID
                        and C.SPREAD_ID = E.SPREAD_ID
                        and C.SPREAD_ID != C.PROJECTION_SPREAD_ID
                        and a.EOD_DATE = F.EOD_DATE
                        and a.SPREAD_ID = F.SPREAD_ID
                        and F.TERM_ID = '5Y'""" % (self._rm_spread_supergrp, date)
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql=sql_string, con=conn)
        df['SPECIFIC_SPREAD_ID'] = df['SPECIFIC_SPREAD_ID'].astype(int)
        df['PROJECTION_SPREAD_ID'] = df['PROJECTION_SPREAD_ID'].astype(int)
        return df

    def spread_proxy_basis(self, eod_date, specific_id, proxy_id):
        date = date_helper.oracle_to_date(eod_date)
        sql_string = """select a.EOD_DATE, a.TERM_ID, A.SPREAD_PCT - B.SPREAD_PCT PROXY_BASIS
                        from MARSP.SPREAD_RATE a, MARSP.SPREAD_RATE B
                        where a.SPREAD_ID = %(specific_id)s
                        and b.spread_id = %(proxy_id)s
                        and a.EOD_DATE = B.EOD_DATE
                        and a.TERM_ID = B.TERM_ID
                        and a.eod_date > MARSP.DAGE.ADDERDAGE(%(date)s, -500, null, 'BNK')
                        order by a.EOD_DATE, a.TERM_ID""" % locals()
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql=sql_string, con=conn)
        return df

    def spread_specific_quotients(self, eod_date, spread_ids):
        date = date_helper.oracle_to_date(eod_date)
        spread_id_lst = ', '.join(map(str, spread_ids))
        sql_string = """select b.END_DATE EOD_DATE, a.SPREAD_ID, a.TERM_ID, a.QUOTIENT
                        from MARSP.SPREAD_QUOTIENT a, MARSP.TIMEINTERVAL b
                        where a.SPREAD_ID in (%(spread_id_lst)s)
                        and a.SC_ID = B.TIMEINTERVAL_ID
                        order by a.SPREAD_ID, a.TERM_ID, B.END_DATE""" % locals()
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql_string, conn)
        start_day = pd.read_sql("select MARSP.DAGE.ADDERDAGE(%s, -500, null, 'BNK') X from dual" % date, conn)['X'][0]
        df['SPREAD_ID'] = df['SPREAD_ID'].astype(int)
        df = df[df['EOD_DATE'] >= start_day]
        return df

    def specific_spread_sens(self, eod_date, spread_ids):
        spread_ids = spread_ids if isinstance(spread_ids, list) else [spread_ids]
        spread_id_lst = ", ".join(map(str, spread_ids))
        date = date_helper.oracle_to_date(eod_date)
        sql_string = """select a.SPREAD_ID, d.TO_TERM_ID TERM_ID, SUM(a.SENS_BASE*d.WGT) SENS_BASE
                        from MARSP.SPREAD_SENS a, MARSP.CONS_ORG_STRUCTURE_STD_HIST B, MARSP.POSITION_SUPERGRP_POSITION_GRP C, MARSP.LADDER_TERM_WGT D
                        where a.EOD_DATE = %s
                        and a.EOD_DATE = B.EOD_DATE
                        and a.ORG_ID = B.ORG_ID
                        and B.CONS_ORG_ID = %s
                        and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                        and C.POSITION_SUPERGRP_ID = '%s'
                        and a.TERM_ID = D.TERM_ID
                        and a.EOD_DATE = D.EOD_DATE
                        and D.TO_LADDER_ID = 1
                        and a.SPREAD_ID in (%s)
                        group by a.SPREAD_ID, D.TO_TERM_ID""" % (date, self._cons_org_id, self._position_supergrp, spread_id_lst)
        conn = pyodbc.connect(database_connect.get_string('INFOP'))
        df = pd.read_sql(sql=sql_string, con=conn)
        df['SPREAD_ID'] = df['SPREAD_ID'].astype(int)
        return df

    def spread_basis_ES(self, eod_date):
        spread_proxies = self.spread_proxies_with_data(eod_date)
        sens = self.specific_spread_sens(eod_date=eod_date, spread_ids=spread_proxies['SPECIFIC_SPREAD_ID'].tolist())

        out = pd.DataFrame()
        for row in spread_proxies.iterrows():
            specific = row[1]['SPECIFIC_SPREAD_ID']
            proxy = row[1]['PROJECTION_SPREAD_ID']
            specific_sens = sens[sens['SPREAD_ID'] == specific]
            if specific_sens.empty or sum(specific_sens['SENS_BASE']) == 0:
                continue
            basis_ts = self.spread_proxy_basis(eod_date=eod_date, specific_id=specific, proxy_id=proxy)
            basis_ts = basis_ts.merge(specific_sens, on='TERM_ID')
            basis_ts['RETURN'] = basis_ts['PROXY_BASIS'] * basis_ts['SENS_BASE']

            out = out.append(basis_ts)

        final = out.groupby('EOD_DATE').sum()[['RETURN']].sort_values(by='RETURN', ascending=True)
        expected_shortfall = sum(final['RETURN'][:6]) / 6
        return expected_shortfall

    def spread_proxy_ES(self, eod_date):
        spread_proxies = self.spread_proxies_with_data(eod_date)
        sens = self.specific_spread_sens(eod_date=eod_date, spread_ids=spread_proxies['SPECIFIC_SPREAD_ID'].tolist())

        specific_quotients = self.spread_specific_quotients(eod_date=eod_date, spread_ids=spread_proxies['SPECIFIC_SPREAD_ID'].tolist())
        specific_ratings = stress_helper.get_credit_ratings(eod_date=eod_date, spread_ids=spread_proxies['SPECIFIC_SPREAD_ID'].tolist())
        specific_quotients = specific_quotients.merge(pd.DataFrame([(key, value) for key, value in specific_ratings.items()], columns=['SPREAD_ID', 'RATING']), on='SPREAD_ID')

        proxy_quotients = self.spread_specific_quotients(eod_date=eod_date, spread_ids=spread_proxies['PROJECTION_SPREAD_ID'].unique())
        proxy_ratings = stress_helper.get_credit_ratings(eod_date=eod_date, spread_ids=spread_proxies['PROJECTION_SPREAD_ID'].tolist())
        proxy_quotients = proxy_quotients.merge(pd.DataFrame([(key, value) for key, value in proxy_ratings.items()], columns=['SPREAD_ID', 'RATING']), on='SPREAD_ID')

        out_specific = pd.DataFrame()
        out_proxy = pd.DataFrame()
        for row in spread_proxies.iterrows():
            specific = row[1]['SPECIFIC_SPREAD_ID']
            proxy = row[1]['PROJECTION_SPREAD_ID']
            specific_sens = sens[sens['SPREAD_ID'] == specific]
            if specific_sens.empty or all(x == 0 for x in specific_sens['SENS_BASE']):
                continue

            specific_ts = specific_quotients[specific_quotients['SPREAD_ID'] == specific].copy().sort_values(by='EOD_DATE')
            specific_ts = specific_ts.merge(specific_sens[['TERM_ID', 'SENS_BASE']], on='TERM_ID')
            specific_ts['RETURN'] = specific_ts['QUOTIENT'] * specific_ts['SENS_BASE']
            out_specific = out_specific.append(specific_ts)

            proxy_ts = proxy_quotients[proxy_quotients['SPREAD_ID'] == proxy].copy().sort_values(by='EOD_DATE')
            proxy_ts = proxy_ts.merge(specific_sens[['TERM_ID', 'SENS_BASE']], on='TERM_ID')
            proxy_ts['RETURN'] = proxy_ts['QUOTIENT'] * proxy_ts['SENS_BASE']
            out_proxy = out_proxy.append(proxy_ts)

        _321a = ['AAA', 'AA', 'AA+', 'AA-', 'A', 'A+', 'A-']
        specific_321a = sum(sorted(out_specific[out_specific['RATING'].isin(_321a)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_321a = sum(sorted(out_proxy[out_proxy['RATING'].isin(_321a)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6

        _321b = ['BBB', 'BBB+', 'BBB-', 'BB', 'BB+', 'BB-', 'B', 'B+', 'B-']
        specific_321b = sum(sorted(out_specific[out_specific['RATING'].isin(_321b)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_321b = sum(sorted(out_proxy[out_proxy['RATING'].isin(_321b)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6

        _321cnr = ['CCC', 'CCC+', 'CCC-', 'CC', 'C', 'NR']
        specific_321cnr = sum(sorted(out_specific[out_specific['RATING'].isin(_321cnr)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_321cnr = sum(sorted(out_proxy[out_proxy['RATING'].isin(_321cnr)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6

        specific_index = sum(sorted(out_specific[out_specific['RATING'] == 'INDEX'].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_index = sum(sorted(out_proxy[out_proxy['RATING'] == 'INDEX'].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6

        specific_tot = sum(sorted(out_specific.groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_tot = sum(sorted(out_proxy.groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6

        specific_rating_split = specific_321a + specific_321b + specific_321cnr + specific_index
        proxy_rating_split = proxy_321a + proxy_321b + proxy_321cnr + proxy_index
        total_ratio = specific_tot / proxy_tot

        out_df = pd.DataFrame([[proxy_321a, specific_321a, specific_321a/proxy_321a],
                               [proxy_321b, specific_321b, specific_321b/proxy_321b],
                               [proxy_321cnr, specific_321cnr, specific_321cnr/proxy_321cnr],
                               [proxy_index, specific_index, specific_index/proxy_index],
                               [proxy_rating_split, specific_rating_split, specific_rating_split/proxy_rating_split],
                               [proxy_tot, specific_tot, total_ratio]],
                              index=['AAA to A', 'BBB to B', 'CCC and below', 'Index', 'Rating split', 'Total'],
                              columns=['Proxy ES', 'Specific ES', 'Ratio'])
        return out_df


class EquityProxyStress:
    def __init__(self, cons_org_id=50004, position_supergrp='NLE', rm_equity_supergrp=1, database='INFOP'):
        self._cons_org_id = cons_org_id
        self._position_supergrp = position_supergrp
        self._rm_equity_supergrp = rm_equity_supergrp
        self._database = database

    def equities_with_significant_sens(self, eod_date):
        date = date_helper.oracle_to_date(eod_date)
        sql_string = """select * from (
                        select a.EOD_DATE, a.EQUITY_ID, SUM(a.SENS_BASE) SENS_BASE
                        from MARSP.EQUITY_SENS a, MARSP.CONS_ORG_STRUCTURE_STD_HIST B, MARSP.POSITION_SUPERGRP_POSITION_GRP C
                        where a.EOD_DATE = %s
                        and a.EOD_DATE = B.EOD_DATE
                        and a.ORG_ID = B.ORG_ID
                        and B.CONS_ORG_ID = %s
                        and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                        and C.POSITION_SUPERGRP_ID = '%s'
                        group by a.EOD_DATE, A.EQUITY_ID)
                        where ABS(SENS_BASE) > 1000
                        order by ABS(SENS_BASE) desc""" % (date, self._cons_org_id, self._position_supergrp)
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql=sql_string, con=conn)
        df['EQUITY_ID'] = df['EQUITY_ID'].astype(int)
        return df

    def equity_proxies_with_data(self, eod_date):
        date = date_helper.oracle_to_date(eod_date)
        equities_with_sens = self.equities_with_significant_sens(eod_date)
        equity_ids = equities_with_sens['EQUITY_ID'].tolist()
        equity_id_str = ', '.join(map(str, equity_ids))
        sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.EQUITY_ID SPECIFIC_EQUITY_ID, E.name SPECIFIC_NAME, 
                               C.PROJECTION_EQUITY_ID, D.name PROJECTION_NAME
                        from MARSP.RM_EQUITY_GRP_MAPPING a, MARSP.RM_EQUITY_GRP B, MARSP.PROJECTION_EQUITY_MAPPING C, 
                             MARSP.EQUITY D, MARSP.EQUITY E, MARSP.EQUITY_QUOTIENT F, MARSP.TIMEINTERVAL G
                        where RM_EQUITY_SUPERGRP_ID = %s
                        and a.EOD_DATE = %s
                        and a.RM_EQUITY_GRP_ID = B.RM_EQUITY_GRP_ID
                        and B.PROJECTION_ID = C.PROJECTION_ID
                        and a.EQUITY_ID = C.EQUITY_ID
                        and a.EOD_DATE = C.EOD_DATE
                        and C.PROJECTION_EQUITY_ID = D.EQUITY_ID
                        and C.EQUITY_ID = E.EQUITY_ID
                        and C.EQUITY_ID in (%s)
                        and C.EQUITY_ID != C.PROJECTION_EQUITY_ID
                        and a.EOD_DATE = G.END_DATE
                        and E.EFFECT_ID = F.EFFECT_ID
                        and G.TIMEINTERVAL_ID = F.TIMEINTERVAL_ID""" % (self._rm_equity_supergrp, date, equity_id_str)
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql_string, conn)
        df['SPECIFIC_EQUITY_ID'] = df['SPECIFIC_EQUITY_ID'].astype(int)
        df['PROJECTION_EQUITY_ID'] = df['PROJECTION_EQUITY_ID'].astype(int)
        return df

    def equity_specific_quotients(self, eod_date, equity_ids):
        date = date_helper.oracle_to_date(eod_date)
        equity_lst = ', '.join(map(str, equity_ids))
        sql_string = """select C.END_DATE EOD_DATE, b.EQUITY_ID, a.QUOTIENT, D.NAME REGION
                        from MARSP.EQUITY_QUOTIENT a, MARSP.EQUITY b, MARSP.TIMEINTERVAL c, MARSP.REGION D
                        where a.EFFECT_ID = b.EFFECT_ID
                        and b.EQUITY_ID in (%(equity_lst)s)
                        and a.TIMEINTERVAL_ID = c.TIMEINTERVAL_ID
                        and b.REGION_ID = d.REGION_ID
                        order by b.EQUITY_ID, c.END_DATE""" % locals()
        conn = pyodbc.connect(database_connect.get_string(self._database))
        df = pd.read_sql(sql_string, conn)
        start_day = pd.read_sql("select MARSP.DAGE.ADDERDAGE(%s, -500, null, 'BNK') X from dual" % date, conn)['X'][0]
        df['EQUITY_ID'] = df['EQUITY_ID'].astype(int)
        df = df[df['EOD_DATE'] >= start_day]
        return df

    def equity_proxy_ES(self, eod_date):
        equity_proxies = self.equity_proxies_with_data(eod_date)
        sens = self.equities_with_significant_sens(eod_date)
        specific_prices = self.equity_specific_quotients(eod_date=eod_date, equity_ids=equity_proxies['SPECIFIC_EQUITY_ID'].tolist())
        proxy_prices = self.equity_specific_quotients(eod_date=eod_date, equity_ids=equity_proxies['PROJECTION_EQUITY_ID'].unique())

        out_specific = pd.DataFrame()
        out_proxy = pd.DataFrame()
        for row in equity_proxies.iterrows():
            specific = row[1]['SPECIFIC_EQUITY_ID']
            proxy = row[1]['PROJECTION_EQUITY_ID']
            specific_sens = float(sens[sens['EQUITY_ID'] == specific]['SENS_BASE'])

            specific_ts = specific_prices[specific_prices['EQUITY_ID'] == specific].copy().sort_values(by='EOD_DATE')
            specific_ts['RETURN'] = specific_ts['QUOTIENT'] * specific_sens

            proxy_ts = proxy_prices[proxy_prices['EQUITY_ID'] == proxy].copy().sort_values(by='EOD_DATE')
            proxy_ts['RETURN'] = proxy_ts['QUOTIENT'] * specific_sens

            out_specific = out_specific.append(specific_ts)
            out_proxy = out_proxy.append(proxy_ts)

        out_dict = dict()
        for region in out_proxy['REGION'].unique():
            proxy_es = sum(sorted(out_proxy[out_proxy['REGION'] == region].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
            proxy_ids = out_proxy[out_proxy['REGION'] == region]['EQUITY_ID'].unique()
            specific_ids_matching_proxy_ids = equity_proxies[equity_proxies['PROJECTION_EQUITY_ID'].isin(proxy_ids)]['SPECIFIC_EQUITY_ID'].unique()
            specific_es = sum(sorted(out_specific[out_specific['EQUITY_ID'].isin(specific_ids_matching_proxy_ids)].groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
            out_dict[region] = [proxy_es, specific_es, specific_es/proxy_es]

        cols = ['Proxy ES', 'Specific ES', 'Ratio']
        out_df = pd.DataFrame.from_dict(out_dict, orient='index')
        out_df.columns = cols

        specific_total = sum(sorted(out_specific.groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        proxy_total = sum(sorted(out_proxy.groupby('EOD_DATE').sum()['RETURN'])[:6]) / 6
        total_ratio = specific_total / proxy_total

        region_split_specific = sum(x[1] for x in out_dict.values())
        region_split_proxy = sum(x[0] for x in out_dict.values())
        out_df = out_df.append(pd.DataFrame([[region_split_proxy, region_split_specific, region_split_specific/region_split_proxy]],
                                            index=['Region split'], columns=cols))
        out_df = out_df.append(pd.DataFrame([[proxy_total, specific_total, total_ratio]],
                                            index=['Total'], columns=cols))

        return out_df
