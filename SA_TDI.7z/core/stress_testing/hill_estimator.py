import math
import pandas as pd
import numpy as np
import datetime as dt


class HillEstimator:
    """
    Class for calculating the hill estimator given a raw data input. Can also calculate the quantile in a pareto
    distribution using the hill estimator as parameter.

    Args:
        raw_data (dataframe or list): Dataframe containing a time series (i.e. values and time points). Can also be
                                      a list. In this case the end date is assumed to be equal to execution date
        horizon                (int): The period to calculate returns between. For example if the horizon is 10, returns
                                      are calculated between every tenth data point
        return_type            (str): Which type of return should be used. Can be 'log', 'abs' or 'pct' (arithmetic)
    """
    def __init__(self, raw_data=None, return_data=None, horizon=10, return_type='log'):
        self.horizon = horizon
        if raw_data is not None:
            if isinstance(raw_data, list):
                # some handling if initiating with a list rather than dataframe
                raw_data = pd.DataFrame(raw_data)
                raw_data.index = pd.bdate_range(end=dt.date.today(), periods=len(raw_data))
            self.data = pd.DataFrame(raw_data.__deepcopy__())
            assert len(self.data.columns) == 1
            self.data.columns = ['value']
            self.data['return'] = self.get_returns(return_type)
        elif return_data is not None:
            if isinstance(return_data, list):
                # some handling if initiating with a list rather than dataframe
                return_data = pd.DataFrame(return_data)
                return_data.index = pd.bdate_range(end=dt.date.today(), periods=len(return_data))
            self.data = pd.DataFrame(return_data.__deepcopy__())
            assert len(self.data.columns) == 1
            self.data.columns = ['return']
        else:
            raise Exception('No data has been provided, cannot initiate class')

        self.days_per_year = self.calc_days_per_year()

        self.default_k = len(self.data)//100
        self.asc_indep_sorted, self.dsc_indep_sorted = self.non_overlapping_quantiles(len(self.data)//20)  # max_k

    def calc_days_per_year(self):
        # Days per year are required to calculate a yearly frequency of an event happening, which is used as a scaling
        # factor in the pareto quantile
        day_diff = (self.data.index[-1] - self.data.index[0]).days
        no_of_years = day_diff // 365.25
        if no_of_years == 0:
            days_per_year = 252
        else:
            days_per_year = len(self.data) // no_of_years
        return days_per_year

    def get_returns(self, return_type):
        # Adds returns to the dataframe using pandas magic
        if return_type == 'log':
            return np.log(self.data['value'] / self.data['value'].shift(self.horizon))
        elif return_type == 'pct':
            return self.data.pct_change(self.horizon)
        elif return_type == 'abs':
            return self.data['value'] - self.data['value'].shift(self.horizon)

    def non_overlapping_quantiles(self, k):
        """
        Finds the quantiles given that the returns must be non-overlapping. This ensures that we do not over-estimate
        the risk by including the same event in multiple returns.

        When a highest/lowest return has been identified, all days around it with a radius equal to the horizon the
        class was initiated with, are blacklisted and thus cannot be added to the output subsequently.

        Args:
            k   (int): Length of the quantile (or order statistic)

        Returns:
            (tuple of dataframes): A tuple containing two dataframes, one for ascending and one for descending

        Notes:
            Author: g48606
        """
        copy_df = self.data.__deepcopy__()[['return']]

        srt_asc = copy_df.copy().sort_values('return', ascending=True)
        srt_dsc = copy_df.copy().sort_values('return', ascending=False)

        asc_df = pd.DataFrame()
        dsc_df = pd.DataFrame()
        for i in range(k):
            asc_cur_idx = srt_asc.index[0]
            asc_cur_loc = copy_df.index.get_loc(asc_cur_idx)
            asc_df = asc_df.append(pd.DataFrame([copy_df.iloc[asc_cur_loc]]))

            blacklisted = copy_df[asc_cur_loc - self.horizon + 1:asc_cur_loc + self.horizon].index.tolist()
            srt_asc.drop(labels=blacklisted, inplace=True, errors='ignore')

            dsc_cur_idx = srt_dsc.index[0]
            dsc_cur_loc = copy_df.index.get_loc(dsc_cur_idx)
            dsc_df = dsc_df.append(pd.DataFrame([copy_df.iloc[dsc_cur_loc]]))

            blacklisted = copy_df[dsc_cur_loc - self.horizon + 1:dsc_cur_loc + self.horizon].index.tolist()
            srt_dsc.drop(labels=blacklisted, inplace=True, errors='ignore')

        return asc_df, dsc_df

    def hill_plot(self):
        # Plots the hill estimator for varying choices of k. This plot is useful for determining a region where the
        # hill estimator is stable, and thus is more reliable (too low k leads to high variance, too high k leads to
        # including events which aren't part of the tail)
        min_k = len(self.data)//200
        max_k = len(self.data)//20

        asc_hill, dsc_hill = [], []
        for k in range(min_k, max_k):
            asc_hill.append(self.hill_estimator(lower=True, k=k))
            dsc_hill.append(self.hill_estimator(lower=False, k=k))

        plot_df = pd.DataFrame(dict(lower=asc_hill, upper=dsc_hill))
        plot_df.index = range(min_k, max_k)
        plot_df.index.name = 'k'
        plot_df.plot(title='Hill plot', xticks=range(int(round(min_k, -1)), max_k, 10))

    def hill_estimator(self, lower, k=None):
        # Calculation of the hill estimator. Takes the average of the log differences of the quantile with the rest of
        # the tail
        if k is None:
            k = self.default_k
        sorted_returns = self.asc_indep_sorted['return'][:k] if lower else self.dsc_indep_sorted['return'][:k]
        log_diffs = [math.log(float(x) / sorted_returns[-1]) for x in sorted_returns[:-1]]

        hill_est = sum(log_diffs) / len(log_diffs)
        return hill_est

    def hill_quantile(self, yearly_freq, lower, k=None):
        # Scaling of the original quantile of the return series with a pareto distribution using the hill estimator as
        # parameter. Also takes as argument the frequency of the event happening, where freq=1 is one year
        p = 1.0 / (self.days_per_year * yearly_freq)
        if k is None:
            k = self.default_k

        orig_quantile = self.asc_indep_sorted['return'][k-1] if lower else self.dsc_indep_sorted['return'][k - 1]
        hill_est = self.hill_estimator(lower=lower, k=k)

        return orig_quantile * ((k-1) / (p * (len(self.data) - self.horizon))) ** hill_est


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import datetime as dt
    raw_data = pd.read_csv('C:/Users/g48606/Desktop/testcsv.csv', header=0, parse_dates=True)

    out = dict()
    for i in range(0, len(raw_data.columns), 2):
        tmp = raw_data[raw_data.columns[i:i + 2].tolist()].copy()
        tmp[tmp.columns[0]] = [dt.datetime.strptime(x, '%Y-%m-%d').date() for x in tmp[tmp.columns[0]]]
        tmp = tmp.set_index(tmp.columns[0], drop=True)
        tenor = tmp.columns[0]
        he = HillEstimator(tmp, 10, return_type='abs')
        out[tenor] = he.hill_quantile(yearly_freq=1, lower=True)

        # he.hill_plot()
    print(out)