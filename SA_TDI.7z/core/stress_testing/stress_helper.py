import datetime as dt
import pyodbc
import traceback

import pandas as pd

from core.connection import database_connect
from core.market_data.mars_helper import get_ir_vol_id
from core.utils import date_helper


def create_save_path(*args):
    """
    Determines the path and file name to save a given file in (as .xlsx) using a timestamp to avoid duplicate naming

    Args:
        *args   (str): Strings to be used as part of the file name (e.g. the input variables for the function where
                       create_save_path is called

    Returns:
        (str): The path and file name concatenated in a single string

    Notes:
        Author: g48606
    """
    function_name = traceback.extract_stack(None, 2)[0][2]
    path = 'C:/Users/g48606/Desktop/Stress Engine'
    # path = '//S64a603/sek6310/Market Risk Management/Market Risk Analysis/Desk Risk Management/Stress Test/Data for shock calibration'
    name = '/%s_%s_%s.xlsx' % (function_name, '_'.join(map(str, args)).replace(' ', '-'), dt.datetime.now().strftime('%Y%m%d_%H%M%S'))
    return path + name


def remove_initial_day_gaps(df, max_day_gap=30):
    """
    Takes an input dataframe and removes any data previous to a user specified day-gap

    Loops through the dataframe and checks whether there are gaps above max_day_gap in the index. If this is the case,
    The dataframe is truncated to return only data AFTER said gap.

    Args:
        df        (dataframe): Input data to be checked for day gaps
        max_day_gap     (int): The minimum length of the day gap before it triggers truncation of data

    Returns:
        (dataframe): The dataframe without data before any day gaps

    Notes:
        Author: g48606
    """
    s_idx = 0
    for idx in range(1, len(df)):
        if (df.iloc[idx, 0] - df.iloc[idx - 1, 0]).days > max_day_gap:
            s_idx = idx
    return df[s_idx:].copy().reset_index(drop=True)


def format_term_data(df):
    """
    Transposes time series with term structure from one column into several columns.

    As each time series can have different index, the columns in the output dataframe might have varying column length.
    Additionally, data will be presented as [date1, term1_vals, date2, term2_vals, ...].
    In case a certain tenor has less than 500 data points after the "remove_initial_day_gaps" filter has been applied,
    it will be skipped and not included in the output.

    Args:
        df        (dataframe): Input dataframe where data for all terms is kept in the same column

    Returns:
        (dataframe): Output where term structure goes along the columns

    Notes:
        Author: g48606
    """
    sorted_tenors = date_helper.sort_tenors(df['TERM_ID'].unique())
    df_lst = []
    included_tenors = []
    for tenor in sorted_tenors:
        tmp_df = df[df['TERM_ID'] == tenor].copy()[['EOD_DATE', 'VALUE']].reset_index(drop=True)
        filtered_tmp_df = remove_initial_day_gaps(tmp_df)
        if len(filtered_tmp_df) < 500:
            print("Data for %s has not been included, as it contained too few data points (sub 500)" % tenor)
            continue
        included_tenors.append(tenor)
        if len(tmp_df) > len(filtered_tmp_df):
            print(str(len(tmp_df) - len(filtered_tmp_df)) + " rows were removed due to holes in time series for " + tenor)
        filtered_tmp_df['EOD_DATE'] = [x.strftime('%Y-%m-%d') for x in filtered_tmp_df['EOD_DATE']]
        df_lst.append(filtered_tmp_df)

    new_df = pd.concat(df_lst, ignore_index=True, axis=1)
    new_df.columns = sum([['Date', tenor] for tenor in included_tenors], [])
    return new_df


def format_surface_data(df):
    sorted_maturities = date_helper.sort_tenors(df['MATURITY_TERM_ID'].unique())
    sorted_tenors = date_helper.sort_tenors(df['TENOR_TERM_ID'].unique())
    df_lst = []
    included_maturity_tenors = []
    for maturity_term in sorted_maturities:
        for tenor_term in sorted_tenors:
            tmp_df = df[(df['MATURITY_TERM_ID'] == maturity_term) & (df['TENOR_TERM_ID'] == tenor_term)].copy()[['EOD_DATE', 'VALUE']].reset_index(drop=True)
            filtered_tmp_df = remove_initial_day_gaps(tmp_df)
            if len(filtered_tmp_df) < 500:
                print("Data for (%s, %s) has not been included, as it contained too few data points (sub 500)" % (maturity_term, tenor_term))
                continue
            included_maturity_tenors.append((maturity_term, tenor_term))
            if len(tmp_df) > len(filtered_tmp_df):
                print(str(len(tmp_df) - len(filtered_tmp_df)) + " rows were removed due to holes in time series for (%s, %s)" % (maturity_term, tenor_term))
            tmp_df['EOD_DATE'] = [x.strftime('%Y-%m-%d') for x in tmp_df['EOD_DATE']]
            df_lst.append(tmp_df)

    new_df = pd.concat(df_lst, ignore_index=True, axis=1)
    new_df.columns = sum([['Date', '(' + mat + ', ' + ten + ')'] for mat, ten in included_maturity_tenors], [])
    return new_df


def format_singlename_data(df):
    identifiers = sorted(df['IDENTIFIER'].unique())
    identifiers_iterator = list(identifiers)
    df_lst = []

    for identifier in identifiers_iterator:
        tmp_df = df[df['IDENTIFIER'] == identifier].copy()[['EOD_DATE', 'VALUE']].reset_index(drop=True)
        filtered_tmp_df = remove_initial_day_gaps(tmp_df)
        if len(filtered_tmp_df) < 500:
            print("Data for %s has not been included, as it contained too few data points (sub 500)" % identifier)
            identifiers.remove(identifier)
            continue
        if len(tmp_df) > len(filtered_tmp_df):
            print(str(len(tmp_df) - len(filtered_tmp_df)) + " rows were removed due to holes in time series for " + identifier)
        filtered_tmp_df['EOD_DATE'] = [x.strftime('%Y-%m-%d') for x in filtered_tmp_df['EOD_DATE']]
        df_lst.append(filtered_tmp_df)

    new_df = pd.concat(df_lst, ignore_index=True, axis=1)
    new_df.columns = sum([['Date', identifier] for identifier in identifiers], [])
    return new_df


def get_credit_ratings(eod_date, spread_ids):
    date = date_helper.oracle_to_date(eod_date)
    spread_lst = ', '.join(map(str, spread_ids))
    sql_string = """select a.SPREAD_ID, C.name RATING
                    from MARSP.SPECIFIC_SPREAD a, MARSP.ORG_RATING B, MARSP.RATING C
                    where a.SPREAD_ID in (%(spread_lst)s)
                    and a.ORG_ID = B.ORG_ID
                    and B.SENIORITY_GRP_ID = 50
                    and B.EOD_DATE = %(date)s
                    and B.RATING_ID = C.RATING_ID""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    df['SPREAD_ID'] = df['SPREAD_ID'].astype(int)
    df = df.set_index('SPREAD_ID')
    out_dict = df['RATING'].to_dict()

    not_identified = [id for id in spread_ids if id not in out_dict]
    not_identified_string = ', '.join(map(str, not_identified))
    if not_identified:
        sql_string2 = """select a.SPREAD_ID, a.SPREAD_TYPE_ID
                         from MARSP.SPREAD a
                         where a.SPREAD_ID in (%(not_identified_string)s)""" % locals()
        df2 = pd.read_sql(sql_string2, conn)
        df2['SPREAD_ID'] = df2['SPREAD_ID'].astype(int)
        others = df2[df2['SPREAD_TYPE_ID'] != 'GENERIC']['SPREAD_ID'].tolist()
        out_dict.update({x: u'INDEX' for x in others})

        generics = df2[df2['SPREAD_TYPE_ID'] == 'GENERIC']['SPREAD_ID'].tolist()
        generics_str = ', '.join(map(str, generics))
        if generics:
            sql_string3 = """select a.SPREAD_ID, B.name RATING
                             from MARSP.GENERIC_SPREAD a, MARSP.RATING b
                             where a.SPREAD_ID in (%(generics_str)s)
                             and a.RATING_ID = b.RATING_ID""" % locals()
            df3 = pd.read_sql(sql_string3, conn)
            df3['SPREAD_ID'] = df3['SPREAD_ID'].astype(int)
            df3 = df3.set_index('SPREAD_ID')
            out_dict.update(df3['RATING'].to_dict())

    return out_dict


if __name__ == '__main__':
    for market in ['LAMDA', 'SWPTN']:
        for ccy in ['SEK', 'NOK', 'DKK', 'EUR', 'USD']:
            print(market, ccy, get_ir_vol_id(ccy, market))