from core.connection import database_connect
from core.utils import date_helper
from core.caching.cache_driver import easy_cache
import pandas as pd
import pyodbc


@easy_cache()
def load_spread_series(eod_date, nordic_region):
    date = date_helper.oracle_to_date(eod_date)
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    nordic_str = '' if nordic_region else 'not'
    relevant_spreads = """select SPREAD_ID from (
                          select a.SPREAD_ID, sum(a.SENS_BASE) SENS
                          from MARSP.SPREAD_SENS a, marsp.cons_org_structure_std_hist b, MARSP.POSITION_SUPERGRP_POSITION_GRP c, MARSP.SPECIFIC_SPREAD d, MARSP.ISSUER_ORG e, MARSP.COUNTRY f
                          where a.EOD_DATE = %s
                          and a.EOD_DATE = B.EOD_DATE
                          and a.ORG_ID = B.ORG_ID
                          and B.CONS_ORG_ID = 50004
                          and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                          and C.POSITION_SUPERGRP_ID = 'AC2'
                          and a.SPREAD_ID = d.SPREAD_ID
                          and d.ORG_ID = e.ORG_ID
                          and a.EOD_DATE = e.EOD_DATE
                          and e.COUNTRY_ID = f.COUNTRY_ID
                          and f.REGION_ID %s in (2,3,4,13)
                          group by a.SPREAD_ID)
                          order by ABS(SENS) desc""" % (date, nordic_str)
    spread_ids = pd.read_sql(relevant_spreads, conn)['SPREAD_ID'].astype(int).tolist()[:1000]
    spread_id_str = ', '.join(map(str, spread_ids))

    sql_string = """select a.EOD_DATE, F.RATING_GRP_ID, a.TERM_ID, AVG(A.SPREAD_PCT) SPREAD_PCT, COUNT(A.SPREAD_PCT) SPREAD_COUNT
                    from MARSP.SPREAD_RATE a, MARSP.SPECIFIC_SPREAD B, MARSP.ISSUER_ORG C, MARSP.COUNTRY D, MARSP.ORG_RATING E, MARSP.RATING_GRP_RATING F
                    where a.SPREAD_ID = B.SPREAD_ID
                    and a.SPREAD_ID in (%s)
                    and a.eod_date = c.eod_date
                    and B.ORG_ID = C.ORG_ID
                    and C.COUNTRY_ID = D.COUNTRY_ID
                    and D.REGION_ID %s in (2,3,4,13)
                    and B.ORG_ID = E.ORG_ID
                    and a.EOD_DATE = E.EOD_DATE
                    and E.SENIORITY_GRP_ID = 50
                    and E.RATING_ID = F.RATING_ID
                    and a.SPREAD_PCT < 1000
                    and F.RATING_GRP_ID in ('AAA', 'AA', 'A', 'BBB', 'BB', 'B', 'CCC', 'CC', 'C', 'D', 'NR')
                    group by a.EOD_DATE, F.RATING_GRP_ID, a.TERM_ID""" % (spread_id_str, nordic_str)
    df = pd.read_sql(sql_string, conn)
    df = df[df['SPREAD_COUNT'] >= 5]
    return df


def get_basis_quotients(eod_date):
    nordic = load_spread_series(eod_date=eod_date, nordic_region=True)
    non_nordic = load_spread_series(eod_date=eod_date, nordic_region=False)

    unique_days = sorted(set(non_nordic['EOD_DATE'].unique()).intersection(nordic['EOD_DATE'].unique()))
    merged = nordic.merge(non_nordic, how='inner', on=['EOD_DATE', 'RATING_GRP_ID', 'TERM_ID'])
    # for date in unique_days:#range(horizon, len(unique_days)):
    #     merged = nordic[nordic['EOD_DATE'] == date].merge(non_nordic[non_nordic['EOD_DATE'] == date], ho)

        # start_nordic = nordic[nordic['EOD_DATE'] == unique_days[idx - horizon]]
        # end_nordic = nordic[nordic['EOD_DATE'] == unique_days[idx]]
        # nordic_common_spreads = set(start_nordic['SPREAD_ID'].unique()).intersection(set(end_nordic['SPREAD_ID'].unique()))
        #
        # f_start_nordic = start_nordic[start_nordic['SPREAD_ID'].isin(nordic_common_spreads)]
        # f_end_nordic = end_nordic[end_nordic['SPREAD_ID'].isin(nordic_common_spreads)]
        #
        #
        # nordic_merged = end_nordic[end_nordic['SPREAD_ID'].isin(nordic_common_spreads)].merge(
        #     start_nordic[start_nordic['SPREAD_ID'].isin(nordic_common_spreads)],
        #     on=['SPREAD_ID', 'RATING_GRP_ID', 'TERM_ID'])
        #
        # shift = end_nordic[end_nordic['SPREAD_ID'].isin(nordic_common_spreads)] - start_nordic[start_nordic['SPREAD_ID'].isin(nordic_common_spreads)]
        #
        # start_non_nordic = non_nordic[non_nordic['EOD_DATE'] == unique_days[idx - horizon]]
        # end_non_nordic = non_nordic[non_nordic['EOD_DATE'] == unique_days[idx]]
        # non_nordic_common_spreads = set(start_non_nordic['SPREAD_ID'].unique()).intersection(set(end_non_nordic['SPREAD_ID'].unique()))
        #
        # f_start_non_nordic = start_non_nordic[start_non_nordic['SPREAD_ID'].isin(non_nordic_common_spreads)]
        # f_end_non_nordic = end_non_nordic[end_non_nordic['SPREAD_ID'].isin(non_nordic_common_spreads)]

    a = 0


if __name__ == '__main__':
    import datetime as dt
    print(get_basis_quotients(eod_date=dt.datetime(2018, 6, 28), horizon=10))