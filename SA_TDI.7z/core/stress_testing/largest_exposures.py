"""
For risk factor groups which are split into a lot of single names, i.e. credit and equities, we need to select which
single names to use for calibration of stress shocks. This module does that through sorting exposures by sensitivity
and choosing the N absolute largest exposures (i.e. both negative and positive).

Several of the functions can also be scoped on sector/region/rating, however no standardised way of scoping has been
devised.

Notes:
    Author: g48606

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       2018aug08   g84606      Initial creation
    ======= =========   =========   ========================================================================================
"""
from core.connection import database_connect
import pandas as pd
import pyodbc


def largest_equity_exposures(no_of_exposures=50, nordic_region=True, financials=False):
    outcomment = '' if nordic_region else '--'
    financials = '' if financials else 'not'
    sql_string = """select a.EOD_DATE, B.EQUITY_ID, B.name, C.name REGION, a.SENS_BASE 
                    from (
                      select EOD_DATE, EQUITY_ID, SENS_BASE from
                        (
                        select a.EOD_DATE, a.EQUITY_ID, ROUND(SUM(a.SENS_BASE),2) SENS_BASE
                        from MARSP.EQUITY_SENS a, MARSP.CONS_ORG_STRUCTURE_STD_HIST B, MARSP.POSITION_SUPERGRP_POSITION_GRP c
                        where a.ORG_ID = B.ORG_ID
                        and B.CONS_ORG_ID = 50004
                        and a.ORG_ID not in (select /*+ materialize */ X.ORG_ID from MARSP.CONS_ORG_STRUCTURE_STD_HIST X where X.CONS_ORG_ID = 50249)
                        and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                        and C.POSITION_SUPERGRP_ID = 'NLE'
                        and a.EOD_DATE = B.EOD_DATE
                        and a.EOD_DATE = '29jun18'
                        group by a.EOD_DATE, a.EQUITY_ID
                        )
                      order by ABS(SENS_BASE) desc
                    ) a, MARSP.EQUITY B, MARSP.REGION c
                    where a.EQUITY_ID = B.EQUITY_ID
                    and B.REGION_ID = C.REGION_ID
                    and B.GICS_ID %(financials)s like '40%%'
     %(outcomment)s and C.NAME in ('DENMARK', 'SWEDEN', 'NORWAY', 'FINLAND')
                    and rownum <= %(no_of_exposures)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    data['EQUITY_ID'] = data['EQUITY_ID'].astype(int)
    return data


def largest_equity_vol_exposures(no_of_exposures=25, sectors=None, not_sectors=None):
    sec_none = '--' if sectors is None else ''
    sectors_str = '[]' if sectors is None else "', '".join(map(str, sectors))
    not_sec_none = '--' if not_sectors is None else ''
    not_sectors_str = '[]' if not_sectors is None else "', '".join(map(str, not_sectors))
    sql_string = """select * from (
                      select a.eod_date, b.name, B.CURRENCY_ID, F.NAME gics_sector, round(sum(a.SENS_BASE),2) SENS_BASE
                      from MARSP.VOL_SENS a, MARSP.VOL B, MARSP.POSITION_SUPERGRP_POSITION_GRP C, MARSP.CONS_ORG_STRUCTURE_STD_HIST D, MARSP.EQUITY E, MARSP.GICS F
                      where a.EOD_DATE = '29jun18'
                      and a.VOL_ID = B.VOL_ID
                      and B.UNDL_TYPE_ID = 'EQT_PX'
                      and a.POSITION_GRP_ID = C.POSITION_GRP_ID
                      and C.POSITION_SUPERGRP_ID in ('EX4', 'EX5')
                      and a.ORG_ID = D.ORG_ID
                      and a.eod_date = d.eod_date
                      and D.CONS_ORG_ID = 50004
                      and a.ORG_ID not in (select /*+materialize */ ORG_ID from MARSP.CONS_ORG_STRUCTURE_STD_HIST where EOD_DATE = '29jun18' and CONS_ORG_ID = 50249)
                      and B.UNDL_EFFECT_ID = E.EFFECT_ID
                      and FLOOR(E.GICS_ID/power(10, FLOOR(log(10, E.GICS_ID)) - 1)) = F.GICS_ID
         %(sec_none)s and F.NAME in ('%(sectors_str)s')
     %(not_sec_none)s and F.NAME not in ('%(not_sectors_str)s')
                      group by a.EOD_DATE, B.name, B.CURRENCY_ID, F.NAME
                      order by ABS(SENS_BASE) desc)
                    where rownum <= %(no_of_exposures)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    data['NAME'] = [x.replace("'", "") for x in data['NAME']]
    return data


def largest_spread_exposures(no_of_issuers, countries=None, rating_groups=None):
    rating_groups = rating_groups if isinstance(rating_groups, list) else [rating_groups]
    countries = countries if isinstance(countries, list) else [countries]
    country_list = "', '".join(map(str, countries))
    if rating_groups == [None]:
        rating_groups = ['AAA', 'AA', 'A', 'BBB', 'BB', 'B', 'CCC', 'CC', 'C', 'NR']
    outcomment = '--' if countries == [None] else ''
    rating_grp_list = "', '".join(rating_groups)
    sql_string = """select * from (
                      select a.EOD_DATE, a.SPREAD_ID, C.name, B.COUNTRY_ID, ROUND(SUM(a.NET_SENS_BASE),2) SENS_BASE, E.name RATING
                      from MARSP.NET_SPREAD_SENS_AC a, MARSP.ISSUER_ORG B, MARSP.SPREAD C, MARSP.ORG_RATING D, MARSP.RATING E, MARSP.RATING_GRP_RATING F
                      where a.EOD_DATE = '29jun18'
                      and a.CONS_ORG_ID = 50004
                      and a.POSITION_SUPERGRP_ID = 'AC'
                      and a.TO_LADDER_ID = 0
                      and B.ORG_ID = a.ISSUER_ORG_ID
                      and a.EOD_DATE = B.EOD_DATE
                      and a.SPREAD_ID = C.SPREAD_ID
       %(outcomment)s and B.COUNTRY_ID in ('%(country_list)s')
                      and D.SENIORITY_GRP_ID = 50
                      and a.EOD_DATE = D.EOD_DATE
                      and B.ORG_ID = D.ORG_ID
                      and D.RATING_ID = E.RATING_ID
                      and E.RATING_ID = F.RATING_ID
                      and F.RATING_GRP_ID in ('%(rating_grp_list)s')
                      group by a.EOD_DATE, a.SPREAD_ID, B.COUNTRY_ID, C.NAME, E.name
                      order by ABS(SENS_BASE) desc)
                    where rownum <= %(no_of_issuers)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    df['SPREAD_ID'] = df['SPREAD_ID'].astype(int)
    return df


if __name__ == '__main__':
    # print(largest_spread_exposures(no_of_issuers=25, countries=['DK', 'NO', 'FI', 'SE'], rating_groups=None))
    # print(largest_equity_exposures(no_of_exposures=25, nordic_region=True, financials=True))
    # print(get_vol_proxies(39, 'FX'))
    # print(largest_equity_vol_exposures(25))
    # print(largest_equity_vol_exposures(25, sectors=['FINANCE']))
    print(largest_equity_vol_exposures(25, sectors=['HEALTH']))
    # print(largest_equity_vol_exposures(25, not_sectors=['FINANCE']))
    # print(largest_equity_vol_exposures(25, sectors=['FINANCE', 'HEALTH']))
    # print(largest_equity_vol_exposures(25, not_sectors=['FINANCE', 'HEALTH']))


