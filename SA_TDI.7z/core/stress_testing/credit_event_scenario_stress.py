from core.connection import database_connect
from core.utils import date_helper
from core.caching import cache_driver
from enum import Enum
import pandas as pd
import pyodbc


class RecoveryRates(Enum):
    # Different choices of recovery rates for getting the JtD risk (the loss given default)
    # The values correspond to the PARAM_ID in MARSP.PARAM
    IssuerRecovery = 2
    FortyRecovery = 5
    ZeroRecovery = 7


@cache_driver.easy_cache()
def largest_jtd_exposures(no_of_issuers, date):
    """
    Gets the 'n' number of counterparties with largest JtD exposure for a given date

    To determine the issuers, we assume the loss is achieved using issuers own recovery rate

    Args:
        no_of_issuers   (int): Number of issuers to return
        date           (date): The date to find issuers for

    Returns:
        (pd.DataFrame): DataFrame containing issuers and our loss given their default

    Notes:
        Author: g48606
    """
    oracle_date = date_helper.oracle_to_date(date)
    sql_string = """select * from (
                    select b.issuer_ref_entity bi_name, sum(a.net_sens_base) net_sens_base
                    from marsp.net_jtd_sens_ac a, marsp.hist_issuer_org_data b
                    where a.eod_date = %(oracle_date)s
                    and a.cons_org_id = 50004
                    and a.position_supergrp_id = 'AC'
                    and b.eod_date (+) = a.eod_date
                    and b.issuer_org_id (+) = a.issuer_org_id
                    group by b.issuer_ref_entity
                    order by sum(a.net_sens_base))
                    where rownum <= %(no_of_issuers)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    return df


@cache_driver.easy_cache()
def largest_credit_spreads(no_of_issuers, date):
    """
    Gets the 'n' number of counterparties with largest credit spreads for a given date

    Looks at spreads for all counterparties with senior debt (seniority_id 2), converts all spreads to '5Y' point by
    interpolation, and picks the 'n' counterparties with the largest spreads.

    Args:
        no_of_issuers   (int): Number of issuers to return
        date           (date): The date to find issuers for

    Returns:
        (pd.DataFrame): DataFrame containing issuers and their spread

    Notes:
        Author: g48606
    """
    oracle_date = date_helper.oracle_to_date(date)
    sql_string = """select * from (
                    select b.issuer_ref_entity bi_name, max(d.spread_pct) spread_pct
                    from marsp.net_spread_sens_ac a, marsp.hist_issuer_org_data b, marsp.spread c, marsp.spread_rate d
                    where a.eod_date = %(oracle_date)s
                    and a.cons_org_id = 50004
                    and a.position_supergrp_id = 'AC'
                    and a.to_ladder_id = 0
                    and a.to_term_id = '5Y'
                    and a.spread_id = c.spread_id
                    and c.seniority_id = 2
                    and d.eod_date = a.eod_date
                    and d.spread_id = c.spread_id
                    and d.term_id = a.to_term_id
                    and d.price_type_id = 'INT'
                    and a.eod_date = b.eod_date
                    and a.issuer_org_id = b.issuer_org_id
                    group by b.issuer_ref_entity
                    order by 2 desc)
                    where rownum <= %(no_of_issuers)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    return df


@cache_driver.easy_cache()
def jtd_risk(bi_names, date, recovery_type):
    oracle_date = date_helper.oracle_to_date(date)
    param_id = getattr(recovery_type, 'value')
    bi_names = bi_names if isinstance(bi_names, list) else [bi_names]
    str_bi_names = "('" + "', '".join(map(str, bi_names)) + "')"
    sql_string = """select E.ISSUER_NAME, E.ISSUER_REF_ENTITY BI_NAME, SUM(A.SENS_BASE) LGD
                    from MARSP.INTEREST_PARAM_SENS a, 
                         MARSP.POSITION_SUPERGRP_POSITION_GRP b, 
                         MARSP.CONS_ORG_STRUCTURE_STD_HIST c, 
                         MARSP.SPECIFIC_SPREAD d, 
                         MARSP.HIST_ISSUER_ORG_DATA e
                    where A.POSITION_GRP_ID = B.POSITION_GRP_ID
                    and B.POSITION_SUPERGRP_ID = 'AC'
                    and A.EOD_DATE = %(oracle_date)s
                    and A.EOD_DATE = C.EOD_DATE
                    and A.ORG_ID = C.ORG_ID
                    and C.CONS_ORG_ID = 50004
                    and A.ORG_ID not in (select /*+ materialize */ org_id
                                         from MARSP.CONS_ORG_STRUCTURE_STD_HIST x
                                         where X.EOD_DATE = %(oracle_date)s
                                         and X.CONS_ORG_ID = 500915) /* here we exclude correlation book */
                    and A.PARAM_ID = %(param_id)s /* JtD with issuers own recovery */
                    and A.INTEREST_ID = D.SPREAD_ID
                    and A.EOD_DATE = E.EOD_DATE
                    and D.ORG_ID = E.ISSUER_ORG_ID
                    and E.ISSUER_REF_ENTITY in %(str_bi_names)s
                    group by E.ISSUER_REF_ENTITY, E.ISSUER_NAME""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    return df


def largest_equity_positions(no_of_issuers, date, long_short, include_nonlinear=False):
    if long_short.lower() == 'long':
        ordering = 'desc'
    elif long_short.lower() == 'short':
        ordering = 'asc'
    else:
        raise NameError("long_short must be given as either 'long' or 'short'")
    oracle_date = date_helper.oracle_to_date(date)
    position_supergrp = 'NLE' if include_nonlinear else 'EX5'
    sql_string = """select * from (
                    select A.EQUITY_ID, D.NAME EQUITY_NAME, SUM(A.SENS_BASE) SENS
                    from MARSP.EQUITY_SENS a, 
                         MARSP.POSITION_SUPERGRP_POSITION_GRP b, 
                         MARSP.CONS_ORG_STRUCTURE_STD_HIST c, 
                         MARSP.EQUITY d
                    where A.POSITION_GRP_ID = B.POSITION_GRP_ID
                    and B.POSITION_SUPERGRP_ID = '%(position_supergrp)s'
                    and A.EOD_DATE = %(oracle_date)s
                    and A.EOD_DATE = C.EOD_DATE
                    and A.ORG_ID = C.ORG_ID
                    and C.CONS_ORG_ID = 50004
                    and A.EQUITY_ID = D.EQUITY_ID
                    group by A.EQUITY_ID, D.NAME
                    order by 3 %(ordering)s)
                    where rownum <= %(no_of_issuers)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    df['EQUITY_ID'] = df['EQUITY_ID'].astype(int)
    return df


def equity_price(equity_id, date):
    oracle_date = date_helper.oracle_to_date(date)
    sql_string = """select A.PRICE
                    from MARSP.PRICE a
                    where A.EOD_DATE = %(oracle_date)s
                    and A.EFFECT_ID in (select EFFECT_ID from MARSP.EQUITY_EFFECT where EQUITY_ID = %(equity_id)s
                                        union all
                                        select EFFECT_ID from MARSP.INDEX_EFFECT where EQUITY_ID = %(equity_id)s)
                    and A.PRICE_TYPE_ID = 'INT'""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    return df


if __name__ == '__main__':
    import datetime as dt
    run_date = dt.datetime(2018, 6, 28)
    risk1 = jtd_risk(bi_names=largest_jtd_exposures(no_of_issuers=2, date=run_date)['BI_NAME'].tolist(),
                     date=run_date,
                     recovery_type=RecoveryRates.ZeroRecovery)
    risk2 = largest_equity_positions(no_of_issuers=2, date=run_date, long_short='long', include_nonlinear=False)
    risk3 = largest_equity_positions(no_of_issuers=2, date=run_date, long_short='short', include_nonlinear=False)
    print(risk1)
    print(risk2)
    print(risk3)
    # jtd_issuers = largest_jtd_exposures(no_of_issuers=3, date=dt.datetime(2018, 6, 7))
    # cs_issuers = largest_credit_spreads(no_of_issuers=3, date=dt.datetime(2018, 6, 7))
    #
    # print(jtd_issuers)
    # print('\n')
    # print(cs_issuers)
    # print('\n')
    # risk1 = jtd_risk(bi_names=jtd_issuers['BI_NAME'].tolist(),
    #                  date=dt.datetime(2018, 6, 7),
    #                  recovery_type=RecoveryRates.ZeroRecovery)
    #
    # risk2 = jtd_risk(bi_names=cs_issuers['BI_NAME'].tolist(),
    #                  date=dt.datetime(2018, 6, 7),
    #                  recovery_type=RecoveryRates.ZeroRecovery)
    # print(risk1)
    # print('\n')
    # print(risk2)
