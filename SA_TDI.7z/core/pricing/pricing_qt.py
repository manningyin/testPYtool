"""
This module contains functions for pricing using qToolkit

Notes:
    Author: g48454
"""
import quantum as qt

import core.caching.abstract_loader_classes
from core.pricing import linear_fx_converter
from core.pricing import model_factory
from core.pricing import pricing_qt_bond
from core.pricing import pricing_scenarios
from core.pricing import pricing_utils
from core.scenario import scenario_utils
from core.utils import error_handler, date_helper


def apply_scenarios_to_qt_model(model, scenarios):
    """
    Takes a model from ModelFactory and applies a scenario to it using qToolkit. The new model is then returned.

    Notes:
        Author: g48606
    """
    new_model = qt.applyScenarioToModel(model=model,
                                        scenarioNameFilters=[item["name"] for item in scenarios],
                                        scenarios=[item["data"] for item in scenarios],
                                        bumpTypes=[item["type"] for item in scenarios])
    return new_model


def forward_qt_model(model, valuation_date, trade_id=""):
    """
    Forwards a model from ModelFactory with a new valuation date. The new model is returned

    Notes:
        Author: g48606
    """
    try:
        new_model = qt.forwardModel(model, valuation_date)
    except Exception as e:
        error_handler.track_error(error_message=str(e), identifier=trade_id, date=valuation_date,
                                  comments='Forwarding of qToolkit model failed')
        return model
    return new_model


def qt_valuation(trade_ids, eod_date, scenarios=None, valuation_date=None):
    """
    Uses qToolkit for pricing of a list of trade_ids at a given eod_date. It is optional to pass a valuation date for
    forwarding the model, and passing any scenario to be applied to the model

    Notes:
        Author: g48454
    """
    if valuation_date is None:
        valuation_date = eod_date

    # ===================================================================================
    # here we have two flow, for all securities, we go to the security flow, for others we go to the trade flow.
    # ===================================================================================
    return pricing_utils.send_trades_and_securities_to_different_flow(trade_ids=trade_ids,
                                                                      trade_pricing_method=qt_valuation_trades,
                                                                      security_pricing_method=qt_valuation_security,
                                                                      eod_date=eod_date,
                                                                      scenarios=scenarios,
                                                                      valuation_date=valuation_date)


def qt_valuation_trades(trade_ids, eod_date, scenarios, valuation_date):
    scenarios = pricing_utils.format_scenario(scenarios)
    trade_ids = pricing_utils.format_trade_ids(trade_ids)

    models_dict = model_factory.ModelFactoryLoader(trade_ids, eod_date, eod_date).data

    out = {}
    for trade in trade_ids:
        try:
            models_for_this_trade = models_dict[(eod_date, trade)]
            if isinstance(models_for_this_trade, str):
                error_handler.track_error(error_message=models_for_this_trade,
                                          identifier=trade,
                                          date=eod_date,
                                          comments='Trade generator cannot return the trade')
                continue
            temp_out = {'trade_id': trade.trade_id}  # TODO: Change this line when ORCA updates TradeIdentifier
        except KeyError as e:
            error_handler.track_error(error_message='KeyError' + str(e),
                                      identifier=trade,
                                      date=eod_date,
                                      comments="Can't find the model from ModelFactoryLoader")
            continue
        for leg_no, (model, leg) in enumerate(models_for_this_trade, 1):
            # =============================================================================================== #
            # Enumerate counts the index in the for loop (starting from 1), to use for determining the leg_no
            # =============================================================================================== #
            if date_helper.to_datetime(eod_date) != date_helper.to_datetime(valuation_date):
                model = forward_qt_model(model, valuation_date, trade.trade_id)
            model = pricing_scenarios.apply_scenarios_to_model(scenarios, model)

            price_local_ccy = model.value(leg.leg, leg.fixings)
            local_ccy = leg.leg.currency.value

            price_base_ccy = linear_fx_converter.linear_fx_convert(currency=local_ccy,
                                                                   eod_date=valuation_date,
                                                                   price=price_local_ccy,
                                                                   scenarios=scenarios)
            temp_out['value_leg_' + str(leg_no)] = price_local_ccy
            temp_out['currency_leg_' + str(leg_no)] = local_ccy
            temp_out['value_in_base_currency_leg_' + str(leg_no)] = price_base_ccy
        out[(eod_date, trade)] = temp_out
    return out


def qt_valuation_security(securities, eod_date, scenarios):
    return pricing_qt_bond.pricing_qt_bonds(securities, eod_date, scenarios)


class ValuationLoaderQT(core.caching.abstract_loader_classes.MatrixLoader):
    """
    Valuation loader for qToolkit. Calculates + caches / loads a valuation for each input of trade identifier,
    eod_date, valuation_date and list of scenario.
    In order to uniquely identify which list of scenario has been passed (independent of possible list permutations),
    the "scenarios_unique_key" function is used, which utilizes a hashing function to generate a unique key.

    Args:
        trade_ids    (list of Trades):   List of trades of type core.types.transaction_types.*
        eod_date        (dt.datetime):   Date for pricing, determines the model and position
        valuation_date  (dt.datetime):   Date for valuation (forwarding of the model)
        scenarios     (list of dicts):   List of scenario (in ORCA/qToolkit format) to be applied to the model
        load_from_source       (bool):   Bool determining if caching should be used, or we should recalculate
        cache_path              (str):   If another path than default cache path should be used

    Returns:
        (dict):   Returns dictionary with (eod_date, (trade_id, source)) as key, and pricing result as value

    Notes:
        Author: g48606
    """
    def __init__(self, trade_ids, eod_date, valuation_date=None, scenarios=None, load_from_source=False, cache_path=None):
        self.valuation_date = eod_date if valuation_date is None else valuation_date
        self.scenarios = [] if scenario_utils.empty_scenario(scenarios) else scenarios
        core.caching.abstract_loader_classes.MatrixLoader.__init__(self, names=trade_ids, startd=eod_date, endd=eod_date, load_from_source=load_from_source, cache_path=cache_path)

    def return_unique_name(self):
        identifier_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for identifier in identifier_list:
            sc_key = scenario_utils.scenarios_unique_key(self.scenarios)
            out[self.startd, identifier] = '_'.join([self.__class__.__name__, self.startd.strftime('%Y%m%d'),
                                                     str(identifier), self.valuation_date.strftime('%Y%m%d'), sc_key])
        return out

    def source_loading_function(self, names, date):
        return qt_valuation(trade_ids=names, eod_date=date, scenarios=self.scenarios, valuation_date=self.valuation_date)


if __name__ == '__main__':
    import datetime as dt
    from core.types import _transactions
    trade_ids = [_transactions.TradeIdentifier(trade_id='3042110', source_system='INFINITY')]
    curve1 = qt.CurveLinear.make([dt.datetime(2017, 3, 2), dt.datetime(2047, 3, 2)], [0.01, 0.01])
    curve2 = qt.CurveLinear.make([dt.datetime(2017, 3, 2), dt.datetime(2047, 3, 2)], [0.01, 0.01])
    sc_list1 = [{'name': 'CHF.RATE.BASISSPREAD', 'type': 'ADDITION', 'data': curve1}, {'name': 'EUR/NZD.FX.SPOT', 'type': 'MULTIPLICATION', 'data': 1.0030185707723602}]
    sc_list2 = [{'name': 'CHF.RATE.BASISSPREAD', 'type': 'ADDITION', 'data': curve2}, {'name': 'EUR/NZD.FX.SPOT', 'type': 'MULTIPLICATION', 'data': 1.0030185707723602}]

    a = ValuationLoaderQT(trade_ids, dt.datetime(2019, 3, 15), scenarios=sc_list1, valuation_date=dt.datetime(2019, 3, 15), load_from_source=False)
    # print(a.data)
    # print(b.data)

    a.clean_cache_if_any()
