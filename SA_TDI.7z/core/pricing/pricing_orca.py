"""
This module contains functions for pricing using orca

Notes:
    Author: g48606
Updated by:
    12nov2019, g01571, Added support for orca ScenarioType
"""
import core.caching.abstract_loader_classes
import core.types
import orca.types
from core.pricing import pricing_utils
from core.scenario import scenario_utils
from core.utils import error_handler
from core.connection import orca_connect


def orca_valuation(position_ids, eod_date, scenarios=None, valuation_date=None):
    req = orca_connect.get_orca_request()

    scenarios = [pricing_utils.get_orca_sc_type(sc) for sc in scenarios]
    trade_spec = core.types.get_trade_spec(position_ids)
    orca_output = req.value_trade(time_stamp=orca_connect.get_orca_timestamp(eod_date),
                                  model_configuration_context=orca.types.ModelConfigurationContext.make_eod_context(),
                                  trade_specification=trade_spec,
                                  scenarios=scenarios).result()

    out = parse_orca_trade_pricing_result_to_dict(orca_output, eod_date)
    for pos in position_ids:
        try:
            _id = getattr(pos, 'trade_id') if hasattr(pos, 'trade_id') else getattr(pos, 'ISIN') + '-BOND'
            out[eod_date, pos] = out.pop((eod_date, _id))
        except KeyError:
            # Pricing errors are already logged in "parse_orca_trade_pricing_result_to_dict"
            continue
    return out


def parse_orca_trade_pricing_result_to_dict(orca_output, eod_date):
    out = {}
    for item in orca_output:
        if item.error is not None:
            err = item.error
            trade_identifier = err.trade_info.trade_identifier
            if trade_identifier is not None:
                source = next(key for key, value in dict(orca.types.SourceSystem.__members__).items() if value.value == trade_identifier.source_system)
                trade_id = trade_identifier.trade_id
                identifier = trade_id + ', ' + source
            else:
                identifier = 'No_id_returned'
            if err is not None:
                err_msg = err.error_message
            else:
                err_msg = 'No_err_returned'
            error_handler.track_error(error_message=err_msg, identifier=identifier, date=eod_date,
                                      comments='ORCA returned error when requesting price')
        elif item.result is not None:
            res = item.result
            out[eod_date, res.trade_info.trade_identifier.trade_id] = res
        else:
            error_handler.track_error(error_message='NA', date=eod_date,
                                      comments='Cannot parse ORCA pricing result to dict, please debug')
    return out


class ValuationLoaderORCA(core.caching.abstract_loader_classes.MatrixLoader):
    """
    Valuation loader for qToolkit. Calculates + caches / loads a valuation for each input of trade identifier,
    eod_date and list of scenario.
    In order to uniquely identify which list of scenario has been passed (independent of possible list permutations),
    the "scenarios_unique_key" function is used, which utilizes a hashing function to generate a unique key.

    Args:
        trade_ids    (list of trades):   Dictionary with source_system as key and trade_ids as value
        eod_date        (dt.datetime):   Date used for the pricing (model, position, valuation)
        scenarios     (list of dicts):   List of scenario (in ORCA/qToolkit format) to be applied to the model
        load_from_source       (bool):   Bool determining if caching should be used, or we should recalculate
        cache_path              (str):   If another path than default cache path should be used

    Returns:
        (dict):   Returns dictionary with (eod_date, (trade_id, source)) as key, and pricing result as value

    Warning:
        ORCA does currently _NOT_ support model forwarding, and thus this is not supported by the loader

    Notes:
        Author: g48606
    """
    def __init__(self, trade_ids, eod_date, scenarios=None, load_from_source=False, cache_path=None):
        self.valuation_date = eod_date
        self.scenarios = [] if scenario_utils.empty_scenario(scenarios) else scenarios
        core.caching.abstract_loader_classes.MatrixLoader.__init__(self, names=trade_ids,
                                                                   startd=eod_date,
                                                                   endd=eod_date,
                                                                   load_from_source=load_from_source,
                                                                   cache_path=cache_path)

    def return_unique_name(self):
        identifier_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for identifier in identifier_list:
            sc_key = scenario_utils.scenarios_unique_key(self.scenarios)
            out[self.startd, identifier] = '_'.join([self.__class__.__name__, self.startd.strftime('%Y%m%d'),
                                                     str(identifier), self.valuation_date.strftime('%Y%m%d'), sc_key])
        return out

    def source_loading_function(self, trade_ids, date):
        return orca_valuation(position_ids=trade_ids, eod_date=date, scenarios=self.scenarios, valuation_date=date)


if __name__ == '__main__':
    import datetime as dt
    from core.types import TradeIdentifier, SecurityIdentifier

    # curve1 = qt.CurveLinear.make([dt.date(2017, 3, 2), dt.date(2047, 3, 2)], [0.01, 0.01])
    # curve2 = qt.CurveLinear.make([dt.date(2017, 3, 2), dt.date(2047, 3, 2)], [0.01, 0.01])
    # sc_list1 = [{'name': 'CHF.RATE.BASISSPREAD', 'type': 'ADDITION', 'data': curve1}, {'name': 'EUR/NZD.FX.SPOT', 'type': 'MULTIPLICATION', 'data': 1.0030185707723602}]
    # sc_list2 = [{'name': 'CHF.RATE.BASISSPREAD', 'type': 'ADDITION', 'data': curve2}, {'name': 'EUR/NZD.FX.SPOT', 'type': 'MULTIPLICATION', 'data': 1.0030185707723602}]
    trade_ids = [SecurityIdentifier('DK0002012350', 'DKK')]

    a = ValuationLoaderORCA(trade_ids, dt.datetime(2019, 10, 9), scenarios=[], load_from_source=False)
    b = ValuationLoaderORCA(trade_ids, dt.datetime(2019, 10, 9), scenarios=[], load_from_source=False)

    # pprint(a.data)
    # pprint(b.data)
    print(a.data_source, b.data_source)
    # a.clean_cache_if_any()
    # b.clean_cache_if_any()

