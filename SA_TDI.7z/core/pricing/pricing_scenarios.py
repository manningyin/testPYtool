import quantum as qt


def filter_additive_fwd_rate_scenarios(scenarios):
    """ Go through all scenarios and find and group those that are additive in fwd rates.

    This procedure is necessary as all scenarios to a given currency needs to be applied together.
    """
    result = {}
    for scenario in scenarios:
        # TODO improve check here - preferably no string check
        if scenario['type'] != 'ADDITION_IN_FORWARD_RATES':
            continue

        if not is_scenario_a_fwd_rate_scenario(scenario['name']):
            raise Exception('Can not apply scenario bump type %s to scenario of name %s.', scenario['type'], scenario['name'])

        scenario_name, _, tenor = scenario['name'].rpartition('.')
        scenario_curve = scenario['data']

        if scenario_name not in result:
            result[scenario_name] = {'tenors': [], 'spreadCurves': []}

        result[scenario_name]['tenors'].append(tenor)
        result[scenario_name]['spreadCurves'].append(scenario_curve)

    return result


def is_scenario_a_fwd_rate_scenario(scenario_name):
    # TODO use risk factor service data to answer this question.
    tokens = scenario_name.upper().split('.')
    return 'RATE' in tokens and 'FWD' in tokens


def apply_single_additive_fwd_rate_scenario_to_model(model, scenario_name, scenario_data):
    # TODO: Do some filter on this for currencies...
    original_fwd_curve = qt.getFwdCurveFromModel(model, scenario_name)
    adjusted_fwd_curve = qt.FwdCurveWithAdditiveSpread(original_fwd_curve, **scenario_data)
    return qt.setFwdCurveOnModel(model, scenario_name, adjusted_fwd_curve)


def apply_additive_fwd_rate_scenarios_to_model(scenarios, model):
    additive_fwd_rate_scenarios = filter_additive_fwd_rate_scenarios(scenarios)
    for scenario_name, scenario_data in additive_fwd_rate_scenarios.items():
        try:
            model = apply_single_additive_fwd_rate_scenario_to_model(model, scenario_name, scenario_data)
        except:
            continue
    return model


def filter_standard_scenarios(scenarios):
    result = {'scenarioNameFilters': [], 'scenarios': [], 'bumpTypes': []}
    for scenario in scenarios:

        # TODO improve check here - preferably no string check
        if scenario['type'] == 'ADDITION_IN_FORWARD_RATES':
            continue

        result['scenarioNameFilters'].append(scenario['name'])
        result['scenarios'].append(scenario['data'])
        result['bumpTypes'].append(scenario['type'])

    return result


def apply_standard_scenarios_to_model(scenarios, model):
    filtered_scenarios = filter_standard_scenarios(scenarios)
    return qt.applyScenarioToModel(model, **filtered_scenarios)


def apply_scenarios_to_model(scenarios, models):
    models_adjusted_for_fwd_rates = apply_additive_fwd_rate_scenarios_to_model(scenarios, models)
    models_adjusted = apply_standard_scenarios_to_model(scenarios, models_adjusted_for_fwd_rates)
    return models_adjusted
