"""
Below module provide an equivalent implementation for linear FX converter.
In current production implementation, orca perform the linear fx converter when transform the pricing from the local ccy
to original ccy.
This service is not possible to use when you use other Pricing Engine than orca, so that we prepare another linear FX converter here.

The converter load the fx rate from marsp, which can be slightly different than fx rate orca is using.

a regression test framework has been set to control the pricing error, please refer to regression_test\pricing\test_pricing_service.
    Author: g48454
"""
import datetime as dt

import core.scenario.scenario_utils
from core.market_data.market_data_loader import FxSpotLoader
from core.connection.orca_connect import get_orca_request


def linear_fx_convert(currency, eod_date, price, scenarios):

    if currency == "EUR":
        return price

    # ===================================================================================
    # Firstly we get the base spot price from the INFOP by using loader,
    # here we just need the first row of the returned dataframe
    # ===================================================================================

    spot_price_df = FxSpotLoader(name = [currency],
                                 startd=eod_date,
                                 endd=eod_date,
                                 source = "INFOP").data
    spot_price_base = spot_price_df[currency].iloc[0]

    if core.scenario.scenario_utils.empty_scenario(scenarios):
        out = price * spot_price_base
    else:
        out = price * get_back_scenario_fx_rate(spot_price_base,scenarios,currency)
    return out


def get_back_scenario_fx_rate(spot_base, scenarios, currency):
    str1 = currency + '/EUR.FX.SPOT'
    str2 = 'EUR/' + currency + '.FX.SPOT'
    scenario_name = [x['name'] for x in scenarios]

    if str1 in scenario_name:
        orca_scenario = parse_scenario_from_scenarios_by_given_name(str1, scenarios)
        out = apply_scenario_to_fx_rates(spot_base,orca_scenario)
    elif str2 in scenario_name:
        orca_scenario = parse_scenario_from_scenarios_by_given_name(str2, scenarios)
        out = 1.0/apply_scenario_to_fx_rates(1.0/spot_base,orca_scenario)
    else:
        out = spot_base

    return out


def apply_scenario_to_fx_rates(fx_base_rate, scenario):
    out = fx_base_rate
    if scenario["type"] == 'ADDITION':
        out = fx_base_rate + scenario['data']
    elif scenario["type"] == 'MULTIPLICATION':
        out = fx_base_rate * scenario['data']
    return out


def parse_scenario_from_scenarios_by_given_name(given_name, scenarios):
    return [x for x in scenarios if x['name'] == given_name][0]


if __name__ == '__main__':
    import quantum as qt
    req = get_orca_request()
    temp = req.request_risk_factors_fx_spot(currencies=[qt.Currency.EUR,qt.Currency.NOK])
    print(temp.result())
    eod_date = dt.datetime(2017,12,29)
    linear_fx_convert("NOK", eod_date, 100, [])