"""
Contain a few helper functions used by the pricing service
Notes:
    Author: g48454
"""
from core.types import get_trade_spec
from core.utils import singleton, error_handler
from core.connection import orca_connect
from core.caching import cache_driver
from core.system import ext_envir
import core.types
import orca.types


def separate_trade_and_security(position_ids):
    trades, securities = [], []
    # input a list of the position id, the function will get back the security and trades
    for x in position_ids:
        if isinstance(x, core.types.TradeIdentifier):
            trades.append(x)
        elif isinstance(x, core.types.SecurityIdentifier):
            securities.append(x)
        else:
            error_handler.track_error(error_message="Position type not recognized", identifier=str(x))
    return trades, securities


def format_scenario(scenarios):
    return [] if scenarios is None else scenarios


def format_trade_ids(trade_ids):
    return trade_ids if isinstance(trade_ids, list) else [trade_ids]


def send_trades_and_securities_to_different_flow(trade_ids,trade_pricing_method,security_pricing_method,eod_date,scenarios,valuation_date):
    """
    Since the security and trades will have different pricing flow, the function serve as a distributor to distribute the trades to different flow.


    Args:
        trade_ids                    (dict): Dictionary with source_system as key and trade_ids as value
        eod_date              (dt.datetime): Date used for the pricing (model, position, valuation)
        scenarios           (list of dicts): List of scenario (in ORCA/qToolkit format) to be applied to the model
        trade_pricing_method       (method): Pricing method for trades
        security_pricing_method    (method): Pricing method for securities
        valuation_date        (dt.datetime): The valuation date


    Returns:
        (dict):   output

    Notes:
        Author: g48454
    """

    # ===================================================================================
    # Format the scenario and trade ids
    # ===================================================================================
    scenarios = format_scenario(scenarios)
    trade_ids = format_trade_ids(trade_ids)

    # ===================================================================================
    # Separate the trade list and security list
    # ===================================================================================
    trade_list, security_list = separate_trade_and_security(trade_ids)
    trade_pricing_result_dict = {}
    security_pricing_result_dict = {}

    # ===================================================================================
    # Send the trades and securities to different flow
    # ===================================================================================
    if len(trade_list) > 0:
        trade_pricing_result_dict = trade_pricing_method(trade_list, eod_date, scenarios, valuation_date)
    if len(security_list) > 0:
        security_pricing_result_dict = security_pricing_method(security_list, eod_date, scenarios)

    # ===================================================================================
    # Merge two dicts
    # ===================================================================================
    pricing_result_dict = trade_pricing_result_dict.copy()
    pricing_result_dict.update(security_pricing_result_dict)

    return pricing_result_dict


class SingleLoadedVariables(singleton.Singleton):
    """
    Class utilizing the singleton pattern to generate an orca request for querying ORCA. Further, an instance of the
    holiday factory for all centers is created

    Notes:
        Author: g48606
    """
    def __init__(self):
        self.cfg = ext_envir.ORCA().config
        self.req = orca_connect.get_orca_request()
        self.hf = self.req.get_holiday_factory_for_all_centers().result()


def get_orca_sc_type(sc):
    if not isinstance(sc, orca.types.Scenario):
        t = orca.types.ScenarioType.__getattr__(sc['type'])
        sc = orca.types.Scenario(name=sc['name'], data=sc['data'], type=t)
    return sc


@cache_driver.memory_cache
def get_trade_list(trade_identifiers, date):
    single_loaded_variables = SingleLoadedVariables.get_instance()
    cfg = single_loaded_variables.cfg
    req = single_loaded_variables.req
    hf = single_loaded_variables.hf

    trade_handler = TradeHandler(cfg, req, hf)
    trade_generator = trade_handler.request_trades(date, trade_identifiers)
    return list(trade_generator)


@cache_driver.memory_cache
def typename_from_trade(orca_trade, date):
    try:
        trade_leg = orca_trade[0]
        typename = trade_leg.leg.typename
    except IndexError:
        try:
            err_identifier = str(orca_trade.trade_identifier.trade_id) + ', ' + str(orca_trade.trade_identifier.source_system.name)
        except:
            err_identifier = 'NA'
        error_handler.track_error(error_message=orca_trade, identifier=err_identifier, date=date,
                                  comments='Trade generator has issue with the trade')
        typename = 'NA'
    return typename


# def config_name_from_trade(orca_trade=None, date=None):
#     """
#     As ORCA has previously used different model configuration names for different products, a setup has been created to
#     handle trade specific config names. As of now, this is only relevant when pricing CDS, everything else uses the
#     "ORCA_REVAL" config_name for valuation...
#
#     Notes:
#         Author: g48606
#     """
#     if orca_trade is None:
#         return "ORCA_REVAL"
#     typename = typename_from_trade(orca_trade=orca_trade, date=date)
#     if typename == 'CreditDefaultSwap':
#         return "ORCA_REVAL_CDS"
#     return "ORCA_REVAL"


# def trade_identifiers_by_config_name(trade_identifiers, date):
#     """
#     Fetches the configuration names for a list of trade_identifiers, and groups the trades in a dictionary with config
#     name as the key and a list of trade_identifiers as values
#
#     Notes:
#         Author: g48606
#     """
#     trade_list = get_trade_list(trade_identifiers=trade_identifiers, date=date)
#
#     out = {}
#     for trade in trade_list:
#         config_name = config_name_from_trade(orca_trade=trade, date=date)
#         try:
#             leg_info = trade[0].trade_info
#             trade_id, source_system = leg_info.trade_identifier.trade_id, leg_info.trade_identifier.source_system.name
#         except IndexError:
#             trade_id, source_system = trade.trade_identifier.trade_id, trade.trade_identifier.source_system.name
#         trade_with_source = [core.types.transaction_types.Trades(trade_id=trade_id, source_system=source_system)]
#         out.setdefault(config_name, []).extend(generate_orca_identifier(trade_with_source))
#
#     # If for some reason the trade list does not contain all provided trade identifiers, here we add them to the output,
#     # giving them the default model configuration name
#     output_trade_identifiers = sum(out.values(), [])  # flatten list
#     default_config_name = config_name_from_trade()  # no arguments gets default config name
#     for trade_identifier in trade_identifiers:
#         if trade_identifier not in output_trade_identifiers:
#             out.setdefault(default_config_name, []).append(trade_identifier)
#     return out
