"""
This is a implementation to perform bond pricing by using qtoolkit

The long term plan is to use model security factory to fetch the model from orca,
this implementation will be removed when that functionality is ready in orca.

Currently the model implemented actually is just a simple yield to price model by using qtoolkit function.
Assume the scenario is only expressed is:

zspread (zero coupon) without term structural.
or a zero coupon scenario curve with term structual

Notes:
    Author: g48454
"""
import quantum as qt

import core.types
from core.caching import cache_driver
from core.market_data.market_data_loader import \
    ORCABondCashFlowLoader, BondPriceMatrixLoader
from core.pricing import linear_fx_converter
from core.utils import error_handler


def pricing_qt_bonds(securities, eod_date, scenarios):
    if not scenarios:
        # ===================================================================================
        # If no scenario is provided, get the reval price from the mds service
        # ===================================================================================
        out = get_reval_price_v(securities, eod_date)
    else:
        out = scenario_pricing(securities, eod_date, scenarios)

    return out


def get_reval_price_v(securities, eod_date):
    isins = [x.ISIN for x in securities]
    temp = BondPriceMatrixLoader(names=isins,
                                 startd=eod_date,
                                 endd=eod_date).data
    out = {}
    for security in securities:
        temp_out = {}
        try:
            mv_dirty = temp[eod_date, security.ISIN]
            temp_out['mv_dirty'] = mv_dirty
            temp_out['security'] = security
        except:
            error_handler.track_error(error_message='',
                                      date=eod_date,
                                      identifier=security,
                                      comments='Cannot get price from orca for this isin')
            continue
        try:
            mv_dirty_base = linear_fx_converter.linear_fx_convert(currency=security.currency, eod_date=eod_date, price=mv_dirty, scenarios=[])
            temp_out['mv_dirty_base_currency'] = mv_dirty_base
        except:
            error_handler.track_error(error_message='',
                                      date=eod_date,
                                      identifier=security,
                                      comments='Cannot finish the fx linear convert for this isin')
        out[eod_date, security] = temp_out
    return out



def get_cashflow_v(isins,eod_date):
    temp = ORCABondCashFlowLoader(names= isins,
                                  startd=eod_date,
                                  endd=eod_date).data
    out = {}
    for isin in isins:
        try:
            out[isin] = temp[eod_date,isin]
        except:
            error_handler.track_error(error_message='',
                                      date=eod_date,
                                      identifier=isin,
                                      comments='Cannot get cashflow from orca for this isin')
    return out


def scenario_pricing(securities, eod_date, scenarios):
    isins = [x.ISIN for x in securities]
    price_list = get_reval_price_v(securities, eod_date)
    cashflow_list = get_cashflow_v(isins, eod_date)
    out = pricing_for_various_scenarios(securities, price_list, cashflow_list, scenarios, eod_date)
    return out


def pricing_for_various_scenarios(securities, price_list, cashflow_list, scenarios, eod_date):
    credit_curve = empty_credit_curve(eod_date)
    disc_curve = empty_discount_curve(eod_date)
    out = {}

    for security in securities:
        isin_ = security.ISIN
        # ===================================================================================
        # get the cashflow and reval price for the corresponding isin
        # ===================================================================================
        try:
            cf = cashflow_list[isin_]
            price = price_list[eod_date, security]
        except:
            continue

        # ===================================================================================
        # calculate the zspread and apply the scenario to zspread
        # ===================================================================================
        try:
            zspread_base = qt.impliedZSpreadCc(disc_curve, credit_curve, cf, price["mv_dirty"])
        except:
            error_handler.track_error(error_message='',
                                      date=eod_date,
                                      identifier=security,
                                      comments='Zspread calculation failed, price input is %s' % price["mv_dirty"])
            continue

        # to see whether there is a zspread scenario, if yes, perform pricing on zspread scenarios.
        zspread_scenario = return_corresponding_zpsread_scenarios(isin_, scenarios)
        if zspread_scenario != 0:
            mv_dirty = perform_pricing_with_zspread_scenario(isin_, zspread_base, zspread_scenario, disc_curve, credit_curve, cf)
        else:
            shock_curve = return_corresponding_zc_scenarios(scenarios)
            if shock_curve != 0:
                mv_dirty = perform_pricing_with_zc_scenario(isin_, zspread_base, shock_curve, disc_curve, credit_curve, cf)
            else:
                mv_dirty = price["mv_dirty"]

        out[eod_date, security] = {"mv_dirty": mv_dirty, "security": security}

        try:
            mv_dirty_base = linear_fx_converter.linear_fx_convert(currency=security.currency, eod_date=eod_date, price=mv_dirty, scenarios=[])
            out[eod_date, security]['mv_dirty_base_currency'] = mv_dirty_base
        except:
            error_handler.track_error(error_message='',
                                      date=eod_date,
                                      identifier=security,
                                      comments='linear fx convert failed')
    return out

def perform_pricing_with_zc_scenario(isin_,zspread_base,shock_zc_curve,disc_curve,credit_curve,cf):
    disc_curve_with_scenario = qt.DiscCurveFromDiscCurveAndSpread.make(disc_curve,shock_zc_curve)
    # ===================================================================================
    # calculate the price under scenario
    # ===================================================================================
    try:
        mv_dirty = qt.bondCashFlowPvCc(disc_curve_with_scenario, credit_curve, cf)
    except:
        error_handler.track_error(error_message='',
                                  date=eod_date,
                                  identifier=isin_,
                                  comments='scenario price failed , use 0 instead')
        mv_dirty = 0
    return mv_dirty


def perform_pricing_with_zspread_scenario(isin_,zspread_base,zspread_scenario,disc_curve,credit_curve,cf):
    zspread = qt.ZSpread.make(isin=isin_, spread=zspread_base + zspread_scenario)

    disc_curve_w_z_spread = qt.DiscCurveWithZSpread.make(disc_curve, zspread)
    # ===================================================================================
    # calculate the price under scenario
    # ===================================================================================
    try:
        mv_dirty = qt.bondCashFlowPvCc(disc_curve_w_z_spread, credit_curve, cf)
    except:
        error_handler.track_error(error_message='',
                                  date=eod_date,
                                  identifier=isin_,
                                  comments='scenario price failed , use 0 instead')
        mv_dirty = 0
    return mv_dirty


def return_corresponding_zpsread_scenarios(isin,scenarios):
    scenario_name = 'RATE.ZSPREAD.' + isin
    temp = [x['data'] for x in scenarios if x['name'] == scenario_name]
    if len(temp) == 0:
        out = 0
    else:
        out = temp[0]
    return out

def return_corresponding_zc_scenarios(scenarios):
    scenario_name = 'ZC_Curve'
    temp = [x['data'] for x in scenarios if x['name'] == scenario_name]
    if len(temp) == 0:
        out = 0
    else:
        out = temp[0]
    return out


@cache_driver.easy_cache()
def empty_credit_curve(eod_date):
    d = [qt.datetime.datetime(2017, 11, 18), qt.datetime.datetime(2050, 11, 28)]
    h = [0, 0]  # input, empty hazard rate
    hc = qt.CurveFlat.make(d, h)
    return qt.CreditCurveInterpolated.make('emptyCurve', "EUR", eod_date, hc, 0.4)

@cache_driver.easy_cache()
def empty_discount_curve(eod_date):
    d = [qt.datetime.datetime(2017, 11, 18), qt.datetime.datetime(2050, 11, 28)]
    h = [0, 0]  # input, empty hazard rate
    hc = qt.CurveFlat.make(d, h)
    return qt.DiscCurveZeroCoupon.make(date=eod_date,
                                        ccy="EUR",
                                       curve=hc)


if __name__ == '__main__':
    from core.pricing import pricing
    from pprint import pprint
    import datetime as dt
    from core.types._transactions import SecurityIdentifier

    eod_date = dt.datetime(year=2017, month=12, day=29)
    #pos = PI_coverage_positions(eod_date)
    trade_ids = [SecurityIdentifier("SE0006593992", "SEK")]

    # bump the zspread scenario....
    #zspread_scenario = [{'name': 'RATE.ZSPREAD.DK0009288524', 'type': 'ADDITION', 'data': 0}]
    zc_scenarios = [{'name': 'ZC_Curve', 'type': 'ADDITION', 'data': qt.CurveLinear.make(dates=[qt.datetime.datetime(2017, 11, 18)],
                                                                                         vals=[0.001])}]


    b = pricing.pricing_service(trade_ids, eod_date,
                                engine=core.types.PricingEngine.QT,
                                scenarios=[])
    pprint(b)

    #c = pricing.pricing_service(trade_ids, eod_date,
    #                            engine=pricing.PricingEngine.ORCA,
    #                            scenarios=[])
    #pprint(c)

    #print(len(b), len(c))

