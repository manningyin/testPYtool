"""
This module contain the pricing service for different models (for example orca or qToolkit)

It can be used for either base pricing or scenario pricing.

Please be aware the differences between pricing and valuation in the prototype:

pricing is mark to model on transaction level.
valuation is mark to model on position level.

Notes:
    Author: g48454
"""
import random
import warnings
from core.pricing import pricing_orca
from core.pricing import pricing_qt
from core.scenario import scenario_utils
from core.types import PricingEngine


def pricing_service(trade_ids, eod_date, engine, scenarios=None, valuation_date=None):
    """
    Pricing service

    Args:
        trade_ids          (dict or list of trades):
        eod_date           (datetime.datetime):      eod_date of the pricing, determines base model and position info.
        engine             (PricingEngine, Enum):    which pricing engine you want to choose
        scenarios          (list of scenarios):           scenario that you want to put into the calculation
        valuation_date    (datetime.datetime or None):       the valuation date, can be useful if you want to forward the model

    Returns:
        (valuation result):   dicts of dicts

    Example:
        The module is called (from python) like this::

            trade_ids = {'INFINITY': ['2661435', '2304262', '2711269']}
            a = pricing(trade_ids, dt.datetime(2017,9,1), engine=PricingEngine.QT)

    Notes:
        Author: g48454
    """
    # ======================================================================================== #
    # Test whether the engine is correctly passed using the PricingEngine class
    # ======================================================================================== #
    if type(engine) == str:
        raise Exception("Please specify the engine using the PricingEngine class. Engine passed is: " + engine)

    # ======================================================================================== #
    # If any scenario are passed, loop through them and remove any invalid scenario. Invalid
    # scenario are logged using the error handler (core.utils.error_handler)
    # ======================================================================================== #
    if not scenario_utils.empty_scenario(scenarios):
        scenarios = scenario_utils.format_scenarios(scenarios)

    # ======================================================================================== #
    # Determine which engine has been passed to the function, and use the appropriate loader
    # The loader has inbuilt caching functionality using the NameDateStrategy to ensure only
    # un-cached data is loaded from source
    # ======================================================================================== #
    if engine == PricingEngine.ORCA:
        if valuation_date is not None and valuation_date != eod_date:
            warnings.warn("WARNING: ORCA does currently not support forwarding. Valuation is calculated at eod_date")
        out = pricing_orca.ValuationLoaderORCA(trade_ids=trade_ids, eod_date=eod_date, scenarios=scenarios).data
    elif engine == PricingEngine.QT:
        out = pricing_qt.ValuationLoaderQT(trade_ids=trade_ids, eod_date=eod_date, scenarios=scenarios, valuation_date=valuation_date).data
    elif engine == PricingEngine.TEST:
        out = pricing_test(trade_ids,eod_date)
    else:
        raise NotImplementedError("Support for pricing using engine '%s' not implemented " % engine)

    # ======================================================================================== #
    # The valuation loaders currently output dictionaries with key like (eod_date + identifier).
    # As the pricing service only takes one date at a time (as opposed to a date_range), we omit
    # the date from output dictionary keys
    # ======================================================================================== #
    out = {key[-1]: value for key, value in out.items()}
    return out


def pricing_test(trade_ids,eod_date):
    out = {}
    for trade in trade_ids:
        out[(eod_date, trade)] = {'value_in_base_currency_leg_1':random.randint(9000,10000)/100.0,
                                  'value_leg_1':random.randint(9000,10000)/100.0,
                                  'currency_leg_1':'EUR'}
    return out


def parse_pricing_output_local_ccy(pricing_output):
    """
    Function for parsing the output of pricing by aggregating the price in local currency for each leg of the
    trade

    Warning:
        In most cases we want to aggregate the base currency valuation rather than the local currency valuation, thus
        this function is mainly for testing purposes

    Notes:
        Author: g48606
    """
    out = {}
    for trade in pricing_output.keys():
        out[trade] = sum([value for key, value in pricing_output[trade].items()
                          if 'value_leg_' in key
                          or key == 'mv_dirty']) # we don't want get the mv_dirty_base_currency in here, so the condition is explicit
    return out


def parse_pricing_output_base_ccy(pricing_output, include_acc_interest=False):
    """
    Function for parsing the output of pricing by aggregating the price in base currency for each leg of the
    trade

    Return a dict of pricing results with trades as key

    Notes:
        Author: g48606
    """
    out_price = {}
    for trade in pricing_output.keys():
        out_price[trade] = sum([value for key, value in pricing_output[trade].__dict__.items()
                          if 'value_in_base_currency_leg_' in key
                          or key in ['mv_dirty_base_currency', 'value_in_base_currency']])
    if not include_acc_interest:
        return out_price
    else:
        out_accrued_interest = {}
        for trade in pricing_output.keys():
            acc_int_local = pricing_output[trade].__dict__.get('accrued_interest', 0)
            exchange_rate = pricing_output[trade].__dict__.get('value_in_base_currency', 0)/pricing_output[trade].__dict__.get('value', 1)
            acc_int_base = acc_int_local * exchange_rate
            out_accrued_interest[trade] = acc_int_base
        return out_price, out_accrued_interest
    

if __name__ == '__main__':
    from pprint import pprint
    from core.types import TradeIdentifier, SecurityIdentifier
    import datetime as dt
    eod_date = dt.datetime(year=2017, month=4, day=10)

    trade_ids = [TradeIdentifier(trade_id='2661435', source_system='INFINITY'),
                 TradeIdentifier(trade_id='2711269', source_system='INFINITY'),
                 TradeIdentifier(trade_id='2230094', source_system='INFINITY'),
                 TradeIdentifier(trade_id='2331941', source_system='INFINITY'),
                 TradeIdentifier(trade_id='0170404009137', source_system='WALLSTREET'),
                 TradeIdentifier(trade_id='0170403009974', source_system='WALLSTREET'),
                 SecurityIdentifier(ISIN='NO0010705536', currency='NOK')]

    scenarios = [{"name": "EUR/USD.FX.SPOT",
                  "type": "MULTIPLICATION",
                  "data": 1.3}]

    # print("Base valuation:")
    # print("\t test:")
    # a = pricing_service(trade_ids, eod_date, engine=PricingEngine.TEST)
    # price_a = parse_pricing_output_base_ccy(a)
    # pprint(price_a)
    # print("\n")

    # print("\t qToolkit:")
    # a = pricing_service(trade_ids, eod_date, engine=PricingEngine.QT)
    # price_a = parse_pricing_output_base_ccy(a)
    # pprint(price_a)
    # print("\n")

    print("\t ORCA:")
    b = pricing_service(trade_ids, eod_date, engine=PricingEngine.ORCA)
    price_b = parse_pricing_output_base_ccy(b)
    pprint(price_b)
    print("\n")

    # print("Scenario valuation:")
    # print("\t qToolkit:")
    # c = pricing_service(trade_ids, eod_date, engine=PricingEngine.QT, scenarios=scenarios)
    # price_c = parse_pricing_output_base_ccy(c)
    # pprint(price_c)
    # print("\n")

    print("\t ORCA:")
    d = pricing_service(trade_ids, eod_date, engine=PricingEngine.ORCA, scenarios=scenarios)
    price_d = parse_pricing_output_base_ccy(d)
    pprint(price_d)
    print("\n")
