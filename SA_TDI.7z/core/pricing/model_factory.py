from orca.bonds.bond_data import BondData
# from orca.models.builders._DEPRECATED_linear_bond import ModelBuilder as BondModelBuilder
from orca_model_core.models.factory import Factory
from orca.types import ModelConfigurationContext, ContextTimeStamp
import core.caching.abstract_loader_classes
from core.pricing import pricing_utils
from core.types import _transactions
from core.utils import dict_helper
from core.connection import orca_connect
import logging


def orca_model_trades(trade_ids, date):
    """
    Calls ORCA ModelFactory to create models for each leg in the list of trades provided, at the given date.
    Outputs a dictionary with (date, (trade_id, source_system)) as key, and a list of models for each leg in the trade
    as value.

    Notes:
        Author: g48606
    """

    # ============================================================================ #
    # Fetches an ORCA request and holiday factory using the singleton pattern
    # ============================================================================ #
    single_loaded_variables = pricing_utils.SingleLoadedVariables.get_instance()
    cfg = single_loaded_variables.cfg
    req = single_loaded_variables.req
    hf = single_loaded_variables.hf

    # ============================================================================ #
    # Calls the ORCA TradeHandler to generate a list of trade objects
    # ============================================================================ #
    trade_specification = pricing_utils.get_trade_spec(trade_ids)
    stamp = ContextTimeStamp.end_of_day_from_date(date)
    trade_list = req.retrieve_trades(stamp, trade_specification, holiday_factory=hf).result()

    # ============================================================================ #
    # Opens an instance of the ModelFactory for creating models
    # ============================================================================ #
    model_factory = Factory.from_service_bundle(orca_connect.to_eod(date), hf, req)

    # ============================================================================ #
    # Looping over trades we extract trade_id, source_system and model config name
    # ============================================================================ #
    out = {}
    for trade in trade_list:
        # The trade contains more than one leg, but we can just get trade info from the first leg
        try:
            leg_of_trade = trade[0][0]
        except (IndexError, TypeError):
            try:
                err_identifier = str(trade.trade_id) + ', ' + str(trade.source_system)
                out[date, (trade.trade_id, trade.source_system)] = str(trade.message)
            except:
                err_identifier = 'NA'
            logging.error(f'Trade generator has issue with the trade: {trade}, {err_identifier}, {date}')
            continue
        trade_id = leg_of_trade.trade_info.trade_identifier.trade_id
        source_system = leg_of_trade.trade_info.trade_identifier.source_system.name
        model_configuration_name = ModelConfigurationContext.make_eod_context()#pricing_utils.config_name_from_trade(orca_trade=trade, date=date)

        # ============================================================================ #
        # Looping over legs in the trade we fetch model spec and generate the model
        # ============================================================================ #
        models_list = []
        for leg in trade[0]:
            model_spec = leg.model_specification
            model = model_factory.create(model_configuration_name, model_spec)
            models_list.append((model, leg))
        out[date, _transactions.TradeIdentifier(trade_id=trade_id, source_system=source_system)] = models_list
        # Credit names can be found with leg.get_leg().name and notional with leg.get_leg().notional
        # Product name can be found with leg.get_leg().typename
    return out


def orca_model_bonds(security_ids, date):
    context_time_stamp = orca_connect.get_orca_timestamp(date)
    model_config_name = ModelConfigurationContext.make_eod_context()

    # ============================================================================ #
    # Fetches an ORCA request and holiday factory using the singleton pattern
    # ============================================================================ #
    single_loaded_variables = pricing_utils.SingleLoadedVariables.get_instance()
    req = single_loaded_variables.req
    hf = single_loaded_variables.hf

    # ============================================================================ #
    # Opens an instance of the ModelFactory for creating models
    # ============================================================================ #
    model_factory = Factory(orca_connect.to_eod(date), hf, req)


    # ===================================================================================
    # Build models
    # ===================================================================================
    isins = [x.ISIN for x in security_ids]
    out = {}

    # ===================================================================================
    # Build models
    # ===================================================================================
    if len(isins) > 0:
        bond_data = BondData.load_bond_data(req, orca_connect.to_eod(date), isins, hf)
        builder = BondModelBuilder(context_time_stamp=context_time_stamp,
                                   model_configuration_context=model_config_name,
                                   isins=isins,
                                   bond_data=bond_data,
                                   model_factory=model_factory,
                                   holiday_factory=hf,
                                   services=req)

        for security in security_ids:
            try:
                out[date,security] = builder.create(security.ISIN)
            except Exception as e:
                logging.error(f'Builder did not get back model for the ISIN {security.ISIN} on {date}. Error message: {e}')
                continue

    return out


class ModelFactoryLoader(core.caching.abstract_loader_classes.MatrixLoader):
    """
    A subclass for creating and caching models from the ORCA ModelFactory

    Notes:
        Author: g48606
    """
    def __init__(self, trade_ids, startd, endd, load_from_source=False, cache_path=None):
        trade_ids = dict_helper.dict_to_tuples(trade_ids)
        core.caching.abstract_loader_classes.MatrixLoader.__init__(self, names=trade_ids, startd=startd, endd=endd, load_from_source=load_from_source, cache_path=cache_path)

    def source_loading_function(self, names, date):
        # ===================================================================================
        # Step 1: separate the trades and fetch the models using the trade flow from orca
        # ===================================================================================
        trade_lists = [x for x in names if type(x) is _transactions.TradeIdentifier]
        out = dict()
        if trade_lists:
            out.update(orca_model_trades(trade_lists, date))

        # ===================================================================================
        # Step 2: get the securities and fetch the models using the bonds flow from orca
        # TODO: the implementation assume all other securities works as same as bonds
        # ===================================================================================

        security_list = [x for x in names if type(x) is _transactions.SecurityIdentifier]
        if security_list:
            out.update(orca_model_bonds(security_list, date))

        return out


if __name__ == '__main__':
    import datetime as dt
    from pprint import pprint
    trade_ids = [_transactions.TradeIdentifier(trade_id='2661435', source_system='INFINITY'),
                 _transactions.TradeIdentifier(trade_id='2711269', source_system='INFINITY'),
                 _transactions.TradeIdentifier(trade_id='2230094', source_system='INFINITY'),
                 _transactions.TradeIdentifier(trade_id='2331941', source_system='INFINITY'),
                 _transactions.TradeIdentifier(trade_id='0170404009137', source_system='WALLSTREET'),
                 _transactions.TradeIdentifier(trade_id='0170403009974', source_system='WALLSTREET'),
                 _transactions.SecurityIdentifier(ISIN='XS0728763938', currency="USD")]

    a = ModelFactoryLoader(trade_ids=trade_ids, startd=dt.datetime(2017, 5, 14), endd=dt.datetime(2017, 5, 16))
    pprint(a.data)
