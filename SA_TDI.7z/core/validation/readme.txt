GateKeeper: JonasB

The validation folder should contain differnt modules used for various types of validations.

That could be:
- input data structure is as expected
  - Does a pandas dataframe have the expected colums?
  - Does a list of dictionaries have the expected dictionaries in all rows?
