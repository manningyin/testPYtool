"""
Module for validation of various file characteristics

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       28feb2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""


import os
def exist(file_path):
    """
    Checks if a file exists. Returns True if file exists. Otherwise False is returned (in all cases)

    If folder or drive does not exist (or is currently unavailable), the function interprets this as the file
    not existing and returns False.

    Args:
        file_path    (str):    Full path of the file that should be examined

    Returns:
        (bool):   True if file exists - Otherwise False

    Raises:

    Example:
        The module is called (from python) like this::
        
            if exist('C:/Temp/qToolkit_Config/login.txt') == True:
                print('the file exists!')
            else:
                print('the file does not exist')

    Warning:
        Please note that function returns True if the file exists.
        False in ANY other case, disregarding the reason (drive or folder does not exist).
    Notes:
        Author: g50444
    """

    if os.path.isfile(file_path) is True:
        file_exist = True
    else:
        file_exist = False

    return file_exist
