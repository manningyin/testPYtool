"""
Performing various read and write operations on flat text files.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       11JAN2016   G50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import os.path

def add_row(file_path,
            new_entry,
            add_to_top_of_file  = False,
            info                = 0
            ):
    """
    Adding a text string as new row in a flat text file. File is created if it does not exist in advance.

    Args:
        file_path               (str):      Full path of the destination file
        new_entry               (str):      String that will be added as new row to the target file
        info                    (int):      Level of information printed.
                                            The higher, the more information is printed

    Returns:
        None

    Raises:

    Example:
        The module is called (from python)::

            add_row(file_path   = 'c:\\Working\\git\\test.txt',
                    new_entry   = 'This is a new row',
                    info        = 0
                    )

    Warning:

    Notes:
        Author: g50444
    """

    if os.path.exists(file_path) is True:
        # If the file already exists, we will add a row

        try:
            if add_to_top_of_file == False:
                with open(file_path, "a") as f:
                    f.write(new_entry +'\n')
            else:
                with open(file_path, 'r+') as f:
                    existing_content = f.read()
                    f.seek(0, 0)
                    f.write(new_entry.rstrip('\r\n') + '\n' + existing_content)
        except:
            print('Not able to add data to:',file_path)
            raise
    else:
        # If the file does not exist, we will create it
        try:
            with open(file_path, "w") as f:
                f.write(new_entry +'\n')
        except:
            print('Not able to create file and add data to:', file_path)
            raise


import ast
def read_as_list_of_objects(file_path, info = 0):
    """
    Reads a file with object definitions on each line, into a list of the objects.

    The objects supported are:
     - strings, bytes, numbers, tuples, lists, dicts, sets, booleans, and None.

    Args:
        file_path               (str):          Path to flat file with lines in dictionary format

    Returns:
        (list of dicts):  All lines from the file (file_path), loaded into a list.

    Raises:

    Example:
        Having a file with dictionaries (expressed in a text-string) on each row, this function will read it into a list of
        dictionaries. Having a file other object (such as a list) the same will happen, and it will be read into a list of
        objects of that particular type.

        For a file with the following context (two lines)::
            {'variable_one': 90, 'variable_two': 'hello'}
            {'variable_one':210, 'variable_two': 'world'}

        This function will read it into a list of (two) dictionaries.

        The module is called (from python) like this::
        
            my_data_in_list = read_as_list_of_objects(file_path = 'c:/some_folder/some_file.txt')

    Warning:

    Notes:
        Author: g50444
    """

    # Defining empty list where lines will be appended
    output_list = []

    # ===================================================================================
    # In the statement below we are:
    # 1) Opening file for reading
    # 2) Looping over all lines in the file
    # 3) Evaluating line expression - converting text strings definitions of objects,
    #    into true Python objects
    # 4) Appends the object to list
    # ===================================================================================

    with open(file_path, 'r') as file:
        for line in file:
            if info > 0:
                print('Line:',line)
            d = ast.literal_eval(line)
            output_list.append(d)

    return output_list