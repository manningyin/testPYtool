"""
Module for creating filenames


Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       13mar2017   g50444      Initial creation
    2       23feb2018   JBrandt     (g50444) Adding get_extension function for determining file extension.
    ======= =========   =========   ========================================================================================

"""

import uuid
import os
def unique( folder,
            file_extension,
            prefix              = '',
            suffix              = '',
            return_full_path    = True,
            info                = 0
            ):
    """
    Creates a unique filename, which does currently not exist, and will not be suggested (again) by this function.

    Args:
        folder              (str):      Full path of the destination folder
        file_extension      (str):      File extension, without the "dot" - e.g. CSV (for suggested_file_name.csv)
        prefix              (str):      OPTIONAL! User chosen prefix of the suggested unique name.
        suffix              (str):      OPTIONAL! User chosen suffix of the suggested unique name.
        return_full_path    (bool):     If True, the full path of the suggested file-name will be returned
        info                (int):      Level of information printed.
                                        The higher, the more information is printed

    Returns:
        (str):   Suggested unique file name (as full folder path if chosen)

    Raises:

        
    Example:
        The module is called (from python) like this::
        
            suggested_file_name = unique(   folder          = 'c:\\temp',
                                            file_extension  = 'txt',
                                            prefix          = '20170301_',
                                            suffix          = '',
                                            ):

    Warning:

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # Extension can be passed both as ".xxx" or simply "xxx".
    # That is handled here...
    # ===================================================================================
    if file_extension.startswith('.'):
        mod_file_extension = file_extension
    else:
        mod_file_extension = '.' + file_extension

    if folder.endswith('/') or folder.endswith('\\'):
        mod_folder = folder
    else:
        mod_folder = folder + '\\'


    suggested_filename = None

    # ===================================================================================
    # In this while loop we:
    # 1) Create a suggested filename.
    # 2) Add folder-path
    # 3) Print (if chosen)
    # 4) Checks if there is already a file with the suggested name.
    #    - If so, suggested name is cleared, back to 1)
    # ===================================================================================
    while suggested_filename == None:
        suggested_filename      = prefix + str(uuid.uuid1()) + suffix + mod_file_extension
        suggested_full_filepath = mod_folder + suggested_filename

        if info > 0:
            print('Suggested file-name:', suggested_filename)

        if os.path.exists(suggested_full_filepath) == True:
            suggested_filename = None

    if return_full_path == True:
        return suggested_full_filepath
    else:
        return suggested_filename

def get_extension(filename):
    """
    Determined the extension (xxx in filename.xxx) of a filename of full file-path.

    Function will return the letters after the last "dot" in UPPER-case.

    Args:
        filename    (str):  Name of the file or full file path. - Including the extension (e.g. h:/my_file.html)

    Returns:
        (str):  File extension in UPPER case.


    Example:
        Test:

            >>> from core.file import filename
            >>> my_file = core
            >>> file_ext = filename.get_extension(my_file)
            >>> file_ext
            'PY'

    Warning:

    Notes:
        Author: JBrandt (g50444)
    """
    return filename[filename.rfind(".")+1:].upper()

if __name__ == '__main__':
    a = unique( folder = 'c:\\temp',
            file_extension = 'txt',
            prefix  = 'jonas_',
            info    = 1
            )
    print(a)