"""
Reading data from a .CSV file and returning data in various formats.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       22dec2016   JBrandt     Initial creation
    2       27feb2017   JBrandt     Added case_sensitive as parameter in read_with_filter function
    3       08mar2018   JBrandt     Added read_with_filterS (many filters) alternative to read_with_filter (one filter)
    ======= =========   =========   ========================================================================================

"""
import sys
import csv
import os


def read_with_filter(file                       ,
                     filter_column_name         ,
                     column_filter              ,
                     filter_criteria    = 'equal',
                     case_sensitive     = False,
                     info               = 0
                     ):
    '''
    Reads from a .csv-file, only the rows that matches a specific criteria. Returns list of dicts


    Args:
        file                    (str):      Full path of .csv-file that should be read
        filter_column_name      (str):      Name of the column for which a filter should be applied
        column_filter           (dynamic):  Criteria that the "filter_column_name" must match (contents must be equal to)
        filter_criteria         (str):      Method for comparing variables in the filter.
                                            - equal:            returns rows EQUAL to criteria
                                            - not_equal:        returns rows NOT EQUAL to criteria
        case_sensitive          (bool):     Determines if the filtering (variable comparision) should be case sensitive or not.
        info                    (int):      Level of information printed.
                                            The higher, the more information is printed

    Returns:
        (list of dicts):   Rows extracted from csv-file that matches the criteria

    Raises:


    Example:
        The module is called (from python) like this::
        
            read_with_filter(file               = 'c:/text.csv',
                             filter_column_name = 'trade_id',
                             column_filter      = 100321,
                             filter_criteria    = 'equal',
                             case_sensitive     = False,
                             info               = 0
                             )
    Warning:

    Notes:
        Author: g50444
    '''

    # Creating empty list which rows will be appended to...
    rows_matching_criteria = []

    # There are small  differences in the "with open" syntax between Python 2 and 3.
    # Therefore we have specific "with open" statements for the two versions.
    #
    # BUT! Since everything else is the same, we create a local function that is used within
    # both sections.

    # Defining the local function used to
    def __read_csv_file():
        reader = csv.DictReader(file)
        for row in reader:
            if (filter_column_name is None) and (column_filter is None):
                # If there are no filters, all rows are read
                rows_matching_criteria.append(row)

            else:
                # ==================================================
                # Some filtering criteria must be applied...
                # ==================================================
                if filter_criteria.lower() == 'equal' or filter_criteria is None:
                    # Filter criteria tested.
                    # Only rows matching will be written to the list.
                    if case_sensitive == True:
                        # Values are compared in "true" case
                        if row[filter_column_name] == column_filter:
                            rows_matching_criteria.append(row)
                    else:
                        # Values are compared in "lower" case
                        if row[filter_column_name].lower() == column_filter.lower():
                            rows_matching_criteria.append(row)
                elif filter_criteria.lower() == 'not_equal':
                    # Filter criteria tested.
                    # Only rows NOT matching will be written to the list.
                    if case_sensitive == True:
                        # Values are compared in "true" case
                        if not row[filter_column_name] == column_filter:
                            rows_matching_criteria.append(row)
                    else:
                        # Values are compared in "lower" case
                        if not row[filter_column_name].lower() == column_filter.lower():
                            rows_matching_criteria.append(row)
                else:
                    raise KeyError(
                        'The provided filter criteria: ' + filter_criteria + ' is NOT among the supported ("equal" and "not_equal")')

    if sys.version_info.major > 2:
        with open(file, 'r', newline='') as file:
            # Call of the function defined above
            __read_csv_file()
    else:
        with open(file, 'rb') as file:
            # Using the same local function as in the "newer" Python version part
            # since the version difference is only within the "with open" function
            __read_csv_file()

    return rows_matching_criteria


def read_with_filters(  file,
                        filters,
                        case_sensitive = False,
                        info=0
                     ):
    """
    Reads from a .csv-file, only the rows that matches specific criterias. Returns list of dicts.

    Args:
        file                    (str):      Full path of .csv-file that should be read
        filters                 (dict):     Filters that will be applied in a dict
                                            {'filter_var_1':'filter_value_1','filter_var_2':'filter_value_2'}
        case_sensitive          (bool):     Determines if the filtering (variable comparision) should be case sensitive or not.
        info                    (int):      Level of information printed.
                                            The higher, the more information is printed

    Returns:
        (list of dicts):   Rows extracted from csv-file that matches the criteria

    Raises:

    Example:
        The module is called (from python) like this::

            read_with_filter(file               = 'c:/text.csv',
                             filters            = {'trade_id': 100321,'source_system':'wallstreet'},
                             case_sensitive     = False,
                             info               = 0
                             )
    Warning:

    Notes:
        Author: JBrandt
    """

    # Creating empty list which rows will be appended to...
    rows_matching_criteria = []
    filter_keys = filters.keys()

    # There are small differences in the "with open" syntax between Python 2 and 3.
    # Therefore we have specific "with open" statements for the two versions.
    #
    # BUT! Since everything else is the same, we create a local function that is used within
    # both sections.

    # Defining the local function used to
    def __read_csv_file():
        reader = csv.DictReader(file)
        for row in reader:
            include = True # Per default we read the row...
            if (filters is None):
                # If there are no filters, all rows are read
                pass
            else:
                # ===================================================================================
                # Some filtering criteria must be applied...
                # Filter criteria tested.
                # Only rows matching will be written to the list.
                # ===================================================================================
                if case_sensitive == True:
                    # Values are compared in "true" case
                    for key in filter_keys:
                        if row[key] == filters[key]:
                            # Default value for "include" is True. Only when filter does not match, we change to False.
                            pass
                        else:
                            include = False
                else:
                    # Values are compared in "lower" case
                    for key in filter_keys:
                        if row[key].lower() == filters[key].lower():
                            # Default value for "include" is True. Only when filter does not match, we change to False.
                            pass
                        else:
                            include = False
            if include == True:
                rows_matching_criteria.append(row)

    if sys.version_info.major > 2:
        with open(file, 'r', newline='') as file:
            # Call of the function defined above
            __read_csv_file()
    else:
        with open(file, 'rb') as file:
            # Using the same local function as in the "newer" Python version part
            # since the version difference is only within the "with open" function
            __read_csv_file()

    return rows_matching_criteria


def export(file_path, data, info = 0):
    '''
    Exporting list of dicts to csv file_path.

    Args:
        file_path   (str):              Full path of the  destination file_path (including .csv extension)
                                        Remember to use "/" - c:/directory.py/subfolder/
        data        (list of dicts):    Data that should be added to the existing csv-file_path.
                                         All dictionaries must be in consistent structure
        info        (int):              Level of information printed.
                                         The higher, the more information is printed

    Returns:
        Nothing.. Data is written to a newly created file...

    Raises:

    Example:
        The module is called (from python) like this::
        
            export(file_path    = 'c:/my_folder/my_file.csv',
                   data         = [
                                        {'VAR_1' : 4564 , 'VAR_2' : 'Hello'},
                                        {'VAR_1' : 7    , 'VAR_2' : 'World'},
                                        {'VAR_1' : 12   , 'VAR_2' : 'Of'},
                                        {'VAR_1' : 1000 , 'VAR_2' : 'Tomorrow'}
                                        ],
                    info        = 0
                    )

    Warning:
        If file already exists, it will be replaced

    Notes:
        Author: g50444
    '''

    # Finding the column-headers (variable names)
    keys = data[0].keys()

    # Writing data to file_path
    if sys.version_info.major > 2:
        with open(file_path, 'w', newline='') as dest_file:
            dict_writer = csv.DictWriter(dest_file, keys)
            dict_writer.writeheader()
            dict_writer.writerows(data)
    else:
        with open(file_path, 'wb') as dest_file:
            dict_writer = csv.DictWriter(dest_file, keys)
            dict_writer.writeheader()
            dict_writer.writerows(data)


def add_rows(file_path,
             data_to_add,
             info = 0
             ):
    """
    Adding rows to an existing csv file_path. If it does not exist in advance, the function will create it.
    
    Adding data is done the "hard" way.
    1) Read full file_path
    2) Add new rows to local version
    3) Write the extended contents to the file_path (replacing the old version)
    
    Args:
        file_path           (str):              Full path of the existing destination file_path (including .csv extension)
                                                Remember to use "/" - c:/directory.py/subfolder/
        data_to_add         (list of dicts):    Data that should be added to the existing csv-file_path.
                                                All dictionaries must be in consistent structure
        info                (int):              Level of information printed.
                                                The higher, the more information is printed

    Returns:
        Nothing.. Data is written to an existing file_path...

    Raises:

    Example:
        The module is called (from python) like this::
        
            add_rows(file_path      = 'c:/my_folder/my_file.csv',
                     data_to_add    = [
                                        {'VAR_1' : 4564 , 'VAR_2' : 'Hello'},
                                        {'VAR_1' : 7    , 'VAR_2' : 'World'},
                                        {'VAR_1' : 12   , 'VAR_2' : 'Of'},
                                        {'VAR_1' : 1000 , 'VAR_2' : 'Tomorrow'}
                                        ],
                     info           = 0
                     )

    Warning:
        The function is vulnerable to simultaneous runs...!
        If the destination file_path does not exist, it will simply be created

    Notes:
        Author: g50444
    """
    
    if os.path.isfile(file_path) is True:
        # Only reading file_path - if it exists...
        try:
            total_rows = read_with_filter(file                  = file_path,
                                          filter_column_name    = None,  # Filter functionality not used
                                          column_filter         = None,  # Filter functionality not used
                                          info                  = info
                                          )
        except:
            raise

        try:
            for line in data_to_add:
                total_rows.append(line)
        except:
            raise

    else:
        # File did not exist. The new file_path should just contain the contribution from data_to_add
        total_rows = data_to_add

    # Replacing file_path...
    try:
        if info > 0:
            print('total_rows',total_rows)

        export(file_path= file_path,
               data         = total_rows,
               info         = info
               )
    except:
        raise


def delete_rows(file_path,
                delete_filter_column_name,
                delete_column_filter,
                case_sensitive = False,
                info    = 0
                ):
    '''
    Deletes rows in a CSV file, matching a specified criteria

    The function deletes all rows in a csv file for which a column with the name as stated in the "delete_filter_column_name".
    has the contents as stated in the delete_column_filter.

    The module simply creates a copy of the file with all rows that does not match the deletion criteria, and overwrites
    the previous version with this. Hence ALL ROWS in the csv file are read, which could result in performance issues for large files.

    Args:
        file_path                   (str):          Full path of the .csv file from where rows should be deleted
        delete_filter_column_name   (str):          Name of a column in the csv file that the deletion criteria should examine/
                                                    check for matches
        delete_column_filter        (str):          Matches of this string in the "delete_filter_column_name" column, will
                                                    result in the row being deleted.
        case_sensitive              (bool):         If True, comparision will be case sensitive. If False it will not.
        info                        (int):          Level of information printed.
                                                    The higher, the more information is printed

    Returns:
        Nothing

    Example:
        Given a CSV file c:/my_folder/superheroes.csv with the contents...

        SURNAME,ALIAS
        Anderson,Neo
        Kent,Superman

        After the call below, the contents will be:
        SURNAME,ALIAS
        Anderson,Neo

        The module is called (from python) like this::
        
            delete_rows(file_path               = 'c:/my_folder/superheroes.csv'
                        ,filter_column_name     = 'SURNAME'
                        ,delete_column_filter   = 'Kent'
                        ,case_sensitive         = False
                        ,info                   = 0
                        )

    Warning:
        Rows are in fact deleted from the csv files.
        If there are no more rows after the delete, the csv file itself is also deleted

    Notes:
        Author: g50444
    '''

    try:
        file_future_contents = read_with_filter(file                    = file_path,
                                                 filter_column_name     = delete_filter_column_name,
                                                 column_filter          = delete_column_filter,
                                                 filter_criteria        = 'not_equal',
                                                 case_sensitive         = case_sensitive,
                                                 info                   = info
                                                 )
    except:
        raise

    if len(file_future_contents) > 0:
        try:
            export(file_path    = file_path,
                   data         = file_future_contents,
                   info         = info
                   )
        except:
            raise
    else:
        # There are no more rows in the file. It is deleted.
        os.remove(file_path)