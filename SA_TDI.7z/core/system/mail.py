"""
Performs various tasks related to mail conmmunications


Warning:

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       16mar2017   g48454      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from core.connection import credentials
from email.mime.application import MIMEApplication
import pandas as pd
import numpy as np
import uuid
import os

# magic server got from IT
_server = "HHHHUB02"
_port = 25


_sender = credentials.get_outlook_mail_address()
def create_simple_mail(to,msg,title):
    # ===================================================================================
    # return an outlook email instance
    # ===================================================================================
    mail = MIMEMultipart()
    mail['Subject'] = title
    if type(to) is list:
        mail['To'] = ", ".join(to)
    else:
        mail['To'] = to
    mail['From'] = _sender
    return mail


def mail_simple_msg(to,msg,title):
    # ===================================================================================
    # send an simple message without html
    # ===================================================================================
    mail=create_simple_mail(to,msg,title)
    mail.attach(MIMEText(msg))
    smtp_connection = smtplib.SMTP(_server, _port, timeout=120)
    smtp_connection.sendmail(_sender, to, mail.as_string())


def mail_dataframe_as_html(to,msg,title,dfs):
    dfs = dfs if isinstance(dfs, list) else [dfs]
    # ===================================================================================
    # send an simple message with a dataframe object expressed as html page
    # ===================================================================================
    mail = create_simple_mail(to, msg, title)
    html_str = msg
    html_str += '<tr></tr><tr></tr>'
    html_str += ''.join(df.to_html() for df in dfs)
    mail.attach(MIMEText(html_str, 'html'))
    smtp_connection = smtplib.SMTP(_server, _port, timeout=120)
    smtp_connection.sendmail(_sender, to, mail.as_string())


def mail_html(to,title,html,attachments = None):
    mail = create_simple_mail(to=to, msg=None, title=title)
    mail.attach(MIMEText(html, 'html'))
    if attachments is not None:
        for f in attachments:
            mail = attach_file_to_mail(mail,f)
    smtp_connection = smtplib.SMTP(_server, _port, timeout=120)
    smtp_connection.sendmail(_sender, to, mail.as_string())


def attach_file_to_mail(mail,f):
    with open(f, "rb") as fil:
        part = MIMEApplication(
            fil.read(),
            Name=os.path.basename(f)
        )
        part['Content-Disposition'] = 'attachment; filename="%s"' % os.path.basename(f)
        mail.attach(part)
    return mail


class CreateAttachmentPaths:
    def __init__(self, df_attachments, df_names):
        df_attachments = df_attachments if isinstance(df_attachments, (list, tuple)) else [df_attachments]
        df_names = df_names if isinstance(df_names, (list, tuple)) else [df_names]
        assert len(df_attachments) == len(df_names)
        self._attachments = df_attachments
        self._names = df_names
        self._file_location = 'C:/Users/%s/%s/' % (os.getenv('username'), str(uuid.uuid4()))

    def __enter__(self):
        if os.path.isdir(self._file_location):
            raise IsADirectoryError("Directory already exists. Aborting")
        os.makedirs(self._file_location)
        attach_paths = []
        for attach, name in zip(self._attachments, self._names):
            tmp_path = self._file_location + '%s.csv' % name
            attach.to_csv(tmp_path)
            attach_paths.append(tmp_path)
        self.paths = attach_paths
        return self.paths

    def __exit__(self, exc_type, exc_val, exc_tb):
        for path in self.paths:
            os.remove(path)
        os.removedirs(self._file_location)


def add_df_html(title, _df):
    def pd_format(_df):
        f1 = lambda _x: '{:,.0f}'.format(_x)
        f2 = lambda _x: '{:.2f}'.format(_x)
        return {column: f1 if column != 'Ratio' else f2
                for (column, dtype) in _df.dtypes.items()
                if dtype in [np.dtype('int64'), np.dtype('float64')]}

    df_html = _df.to_html(formatters=pd_format(_df)).replace('<tr>', '<tr style="text-align: right;">')
    return '<tr> %s </tr>' % title + df_html + '<tr></tr><tr></tr>'


def add_str_html(col_name, val):
    return '<tr> <b> %s </b> : %s </tr>' % (col_name, val)


if __name__ == '__main__':
    files = [r"\\dcd00cb-evs02\ABD\Market Risk Models & Measures\09 Stress testing\EBA Stress 2018 Bonds\results\stress_20180226-083837.xlsx",
             r"\\dcd00cb-evs02\ABD\Market Risk Models & Measures\09 Stress testing\EBA Stress 2018 Bonds\Scenarios.xlsx"]
    mail_html(to=credentials.get_outlook_mail_address(),
              html="",
              title="Hello %s" % os.environ['username'],
              attachments=files)
    mail_simple_msg(to=credentials.get_outlook_mail_address(),
                    msg="Hello %s" % os.environ['username'],
                    title="Hello %s" % os.environ['username'])
    df = pd.DataFrame(data=["test"])
    mail_dataframe_as_html(to=credentials.get_outlook_mail_address(),
                           msg="Hello %s" % os.environ['username'],
                           title="Hello %s" % os.environ['username'],
                           dfs=df)
