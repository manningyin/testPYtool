"""
This application is supposed to give the user an overview of which of the installed packages in the Python distribution
is actually used by the project (user must provide the project path).

The purpose of this module is to give the user an overview of which packages are used, and which packages can be removed
without creating any issues.

The module allows the user to see how many times a given package is imported in the project. However, this is not
sufficient as packages which are not imported in the project might be required by other packages which in fact ARE used
in the project. To circumvent this, a package will be flagged for dependency if any of the packages it is required by
are imported at least once in the project

The final output of the module is a list of packages used, and a list of packages not used

Notes:
    Author: g48606
"""
from collections import defaultdict
from pip._vendor import pkg_resources
import pandas as pd
import pip
import os

# First we use pip to find all locally installed packages (in ../Lib/site-packages)
locally_installed_packages = sorted([x.key for x in pip.get_installed_distributions()])


def find_all_imports(root_path):
    count_dict = defaultdict(lambda: 0)
    for subdir, dirs, files in os.walk(root_path):
        for file_ in files:
            file_path = subdir + os.sep + file_

            # ===================================================================================
            # WARNING: SHOULD WE IGNORE IMPORTS IN THE DISTRIBUTION TEST FILE???
            # ===================================================================================
            if file_path.endswith('batch\\distribution\\test.py'):
                continue

            if file_path.endswith('.py'):
                py_file = file(file_path)
                for line in py_file:
                    stripped = line.strip()
                    if stripped.startswith('import'):
                        package = stripped[7:].split('.')[0].split(',')[0].split(' ')[0].replace('_', '-').lower()
                        if package == 'mdh':
                            package = 'mdh-cli'
                        if package in locally_installed_packages:
                            count_dict[package] += 1
                    elif stripped.startswith('from') and 'import' in stripped:
                        package = stripped[5:].split('.')[0].split(',')[0].split(' ')[0].replace('_', '-').lower()
                        if package == 'mdh':
                            package = 'mdh-cli'
                        if package in locally_installed_packages:
                            count_dict[package] += 1
    return dict(count_dict)


def get_package_dependencies(_package_name):
    _package = pkg_resources.working_set.by_key[_package_name]
    out = [r.name for r in _package.requires() if r.name in locally_installed_packages]
    return out


def get_required_by_packages():
    requires = dict()
    for package in locally_installed_packages:
        requires.setdefault(package, []).extend(get_package_dependencies(package))

    required_by = dict()
    for key, values in requires.items():
        for value in values:
            required_by.setdefault(value, []).append(key)
    return required_by


def dependency_dataframe(project_path):
    """
    Function description

    Args:
        project_path    (str): Root path for project to investigate

    Returns:
        (dataframe): Description

    Notes:
        Author: g48606
    """
    tmp = find_all_imports(project_path)
    all_packages = {x: tmp.pop(x, 0) for x in locally_installed_packages}

    out = pd.DataFrame([all_packages]).T
    out.columns = ['Imports']
    out['Dependency'] = 'N'

    required_by = get_required_by_packages()
    for package in out.index:
        required_by_packages = required_by.get(package, [])
        for required_by_package in required_by_packages:
            if out['Imports'][required_by_package] > 0:
                out.at[package, 'Dependency'] = 'Y'
    return out


if __name__ == '__main__':
    from core.system import envir
    df = dependency_dataframe(envir.codelib_path())

    packages_not_used = df[(df['Imports'] == 0) & (df['Dependency'] == 'N')].index.tolist()
    packages_used = df[(df['Imports'] > 0) | (df['Dependency'] == 'Y')].index.tolist()


    print(packages_not_used)
