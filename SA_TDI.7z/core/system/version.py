# -*- coding: utf-8 -*-
"""
Module for handling and keeping track of versions of 1) Python distribution packages and 2) code-lib releases



Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       05may2017   g46987      Initial creation
    2       08may2017   g50444      Added functions validate_package_version and required_package
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import re

# Parsing version string in the format of major.minor (e.g. 6.0)
_PACKAGE_VERSION_PATTERN = re.compile(r"PACKAGE +version +(?P<number>[0-9].[0-9]+) +\((?P<date>[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9])\)")
# Parsing version string in the format of major (e.g. 6)
_PACKAGE_VERSION_PATTERN_NO_MINOR = re.compile(r"PACKAGE +version +(?P<number>[0-9]+) +\((?P<date>[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9])\)")

def package_version_parser(txt):
    """
    Parse a package version from a string.
    In case if package version is unknown, the version number will be zero, otherwise it will be a positive integer.

    Args:
        x   (str):    text containing

    Returns:
        (str,int,str):  tuple of package version string, package version number (int) and package date (string).

    Example:
        see unittest test_package_version_parser (test/utils/test_version.py)
    Notes:
        Author: Orest
    """
    try:
        m = _PACKAGE_VERSION_PATTERN.search(txt)
        if m is None:
            m = _PACKAGE_VERSION_PATTERN_NO_MINOR.search(txt)
        if m is None:
            return "PACKAGE version UNKNONW",0,"0000-00-00"
        else:
            return m.group(0),float(m.group("number")),m.group("date")
    except:
        return "PACKAGE version UNKNONW",0,"0000-00-00"
        

def package_readme_path():
    """
    Returns path to the package readme file.
    Package readme file is a html file containing a package version string.

    Returns:
        (str): path to the readme file

    Notes:
        Author: Orest
    """
    from os.path import split,join
    return join(split(return_perfix())[0],"Readme.html")


def return_perfix():
    import sys
    if hasattr(sys, 'real_prefix'):
        # if the code is running in vitrual env
        out = sys.real_prefix
    else:
        # if the code is running normally..
        out = sys.prefix
    return out

def package_version():
    """
    Returns package version.
    Package version is a tuple containing
    - package version string,
    - version number and
    - version date.

    Returns:
        (str,int,str):  tuple of package version string, package version number (int) and package date (string).

    Example:
        see unittest test_package_version (test/utils/test_version.py)
    Notes:
        Author: Orest
    """
    with open(package_readme_path(),'r') as f:
        file = f.read()
        package_ver = package_version_parser(file)
        return package_ver

def package_version_number():
    """
    Returns package version number.

    Returns:
        (int): package version number (int), zero if unknown.

    Example:
        see unittest test_package_version_number (test/utils/test_version.py)
    Notes:
        Author: Orest
    """
    package_ver = package_version()
    return package_ver[1]

def codebase():
    """
    Returns the version of current code-base

    Args:

    Returns:
        (number):   major.minor

    Raises:

    Example:
        The module is called (from python) like this::

            from core.system import version
            version.code_version()

    Warning:

    Notes:
        Author: g50444
    """

    import datetime
    if datetime.date.today() > datetime.date(2017,5,5):
        return 0.3
    elif datetime.date.today() > datetime.date(2017,1,1):
        return 0.2
    else:
        return 0.1


def required_package():
    """
    Determines which python package (distribution) that should be used for current code-base

    Returns:
        (int): Number of the distribution that should be used to run current code-base version

    Example:
        The module is called (from python) like this::

            from core.system import version
            version.required_package()

    Warning:

    Notes:
        Author: g50444
    """

    codebase_version = codebase()

    if codebase_version >= 0.3:
        return 4
    else:
        return 1

def validate_package_version():
    """
    Validates that code is running on the required Market Risk Analytics Python distribution.

    Returns:
        (None):   Nothing - Sometimes raises warning

    Raises:
        warning.warn(<Not using MR Analytics Python distribution>)
        warning.warn(<Using old version of MR Analytics distribution>)


    Example:
        The module is called (from python) like this::

            from core.system import version
            version.validate_package_version()

    Notes:
        Author: g50444
    """

    try:
        current_package_version = package_version_number()
    except IOError:
        # If the package readme file does not exist, and IOError is raised
        # We see this as a "distribution does not exist" issue
        current_package_version = None

    if current_package_version == None:
        import warnings
        warning_message = (
                'You are NOT using a MR Analytics Python distribution. Please ask for instructions how to get this! ' +
                'MR Analytics will only support code-lib running on the proper Python distribution.'
        )
        warnings.warn(warning_message)
        print(warning_message)
    else:
        if current_package_version < required_package():
            import warnings
            warning_message = (
                'You are running an old version of the MR Analytics Python distribution. This may cause problems! ' +
                'Please upgrade from version ' + str(package_version_number()) + ' to ' + str(required_package()) + '.'
            )
            warnings.warn(warning_message)
            print(warning_message)



if __name__ == '__main__':
    b = package_version()
    print(b)
    a = package_readme_path()
    package_version_parser(open(a).read())
    #a.close()
