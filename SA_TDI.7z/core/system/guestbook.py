"""
Module for logging user usage of applications

Usage of this module is thought to be limited to first "outer layer" of applications.
That is in the case where a user calls an application that uses various modules and functions,
only the call of call of the actual application is of interest.

Example:
    User -> Application X.Function A  -> Function 2 -> Function 5
            Application X.Function A  -> Function 3 -> Function 4 -> Function 6
            
    It is most likely only of interest to log the users initial call - of the Function A in the Application X.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       10JAN2016   G50444      Initial creation
    2       03MAY2017   g50444      Now only checking in if function is called from first invocation of code-lib library.
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import getpass
import inspect
import datetime
import sys
from core.utils import git_helper, string_utils as string
from core.file import flat_file
from core.system import envir, version
from core.utils import directory
from core.utils.singleton import Singleton
import os

def checkin(info = 0):
    """
    Performs registration of current invocation of function.

    The function registers:
        - Name of the function that calls this function
        - Date and Time of invocation
        - Users g-number
        - Users version of Python (which invokes the function)
        - Git revision number

    Args:
        info        (int):      Level of information printed. The higher, the more information is printed

    Returns:
        None

    Example:
        The module is called (from python) like this::

            def my_application(x,y,z):
                checkin()
            my_application(1,1,1)

    Warning:

    Notes:
        Author: g50444
    """

    # Determining folder for guestbook
    checkin_log_file_path = envir.guestbook_file_path()

    # Making sure that folder exists, and creating it if not
    directory.create(checkin_log_file_path)

    # Getting information about the module/function calling this function.
    # - Going "one step up" in the call stack
    calling_object          = inspect.stack()[1]
    # Check whether this process have already been checked by using Singleton
    already_check_in_context = already_check_in.get_instance()

    if not already_check_in_context._already_checked:
        already_check_in_context._already_checked = True
        # Extracting the information about the calling object
        function_name       = calling_object[3]
        module_file_path    = calling_object[1].replace('\\','/')

        # Finding module name from module (file) path
        module_name         = module_file_path[module_file_path.rfind('/') + 1 : -3]
        module_function     = module_name + '.' + function_name

        user                = getpass.getuser()
        checkin_time        = datetime.datetime.strftime(datetime.datetime.now(), '%d-%m-%Y %H:%M:%S')

        # ===================================================================================
        # The sys.version has a very long string with exact information about the running
        # Python version. That is assessed to be too long.
        # Instead we make a short string with (almost) the same information, but easier to
        # read (fast). Example: "3.5.2.final"
        # ===================================================================================
        python_version      = (
                                str(sys.version_info.major) + '.' +
                                str(sys.version_info.minor) + '.' +
                                str(sys.version_info.micro) + '.' +
                                str(sys.version_info.releaselevel)
                              )
        git_revision        = git_helper.git_version()

        try:
            distribution_package = version.package_version_number()
        except:
            distribution_package = 'NA'

        # Creating a string matching the dict syntax, but with a static variable order
        logging_variable_names = ['checkin_time',
                                  'user',
                                  'git_revision',
                                  'python_version',
                                  'distribution_package',
                                  'module_function',
                                  'module_file_path']
        try:
            checkin = string.ordered_dict_string(variables_for_dict = logging_variable_names, info = info)
        except:
            print('Not able to create string of guestbook information. No guestbook of this run!')
            pass
        else:
            try:
                # Writing "dict" string with information to the standard guestbook file
                flat_file.add_row(file_path             = checkin_log_file_path,
                                  new_entry             = str(checkin),
                                  add_to_top_of_file    = True,
                                  info                  = info
                                  )
            except:

                print('Not able to save guestbook information to file:', checkin_log_file_path, 'No guestbook of this run!')

        version.validate_package_version()

        if info >= 1:
            checkin_string = 'Function'': "' + module_function + '"' + ' was started ' + checkin_time + ' by ' + user
            print("=================================== Function Checkin ===================================")
            print(checkin_string)
            print("========================================================================================")

class already_check_in(Singleton):
    _already_checked = False


def checkout(info = 0):

    # Getting information about the module/function calling this function.
    # - Going "one step up" in the call stack
    calling_object      = inspect.stack()[1]

    # Extracting the information about the calling object
    module_file_path    = calling_object[1]

    # Finding module name from module (file) path
    module_name         = module_file_path[module_file_path.replace('\\','/').rfind('/') + 1 : -3]

    if info >= 1:
        checkout_time = datetime.datetime.strftime(datetime.datetime.now(), '%d-%m-%Y %H:%M:%S')
        checkout_string = 'Module'': "' + module_name + '"' + ' has checked out at ' + checkout_time
        print("========================================= Module CheckOut ========================================")
        print(checkout_string)
        print("==================================================================================================")


def return_the_first_function_called_in_code_lib():
    """
    Return the first function called in running application which located in "code-lib" folder

    Args:

    Returns:
        (inspect.FrameInfo):    First function in the call-tree, located inside the code-lib directory

    Raises:

    Example:

    Warning:

    Notes:
        Author: G48454
    """

    # return the first function called in this application which located in "code-lib" folder
    calling_objects     = inspect.stack()
    current_position    = -1

    # Abspath is used due to Python 2 issues, where spyder defaults to relative path
    while (os.path.abspath(calling_objects[current_position][1]).find('code-lib') == -1) or (calling_objects[current_position][3] == '<module>'):
        current_position = current_position - 1

    return calling_objects[current_position]

if __name__ == '__main__':
    def outer_function_test():
        checkin(1)
    outer_function_test()