"""
Modules that provides configurations to set for core

Configurations might be as following
- Stop caching
- Caching expiry durations

Warning:

Notes:
    Author: g01571

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       12NOV2019   g01571      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import inspect
import os
import yaml
from core.system import envir
from core.utils import singleton
try:
    import aenum
except ModuleNotFoundError:
    raise ModuleNotFoundError("Please install 'aenum' (pip install aenum) and re-run your code.")


class DefaultConfigurationOptions(aenum.Enum):
    """"
    Enumerator that would show all the possible options
    """
    _settings_ = aenum.NoAlias
    caching_expiry_duration_in_days = 3
    do_caching = True
    show_cache_warning = False


def default_config():
    """
    Returns a dictionary with default configurations

    Returns:
        (dict): Dictionary of default config

    Notes:
        Author: g01571
    """
    return {x.name: x.value for x in DefaultConfigurationOptions}


class ConfigHandler(singleton.Singleton):

    """
    A singleton class for loading the config file for external environments, or if it doesn't exist, creating the file
    and then loading it. The singleton pattern is used to allow the user to make temporary environment changes in an
    instance of the code.

    Inspired from core.system.ext_envir
    """
    def __init__(self):

        self._DATA_PATH = envir.data_path()
        self._FILE_OUT = self._DATA_PATH + '/config_codelib.yml'
        self.config = self._read_config_file()

    def _make_config_file(self):
        """
        Creates the config file if it does not exist.
        Inspired from core.system.ext_envir
        """
        # If the folder specified by the data path does not exist, it is created
        if not os.path.isdir(self._DATA_PATH):
            os.makedirs(self._DATA_PATH)

        # Using a standard text writer to write the string in "config_yaml()" to the _FILE_OUT
        with open(self._FILE_OUT, "w") as fo:
            yaml.dump(default_config(), fo, default_flow_style=False)

    def _read_config_file(self):
        """"
        Reads the configuration file
        """
        if not os.path.isfile(self._FILE_OUT):
            self._make_config_file()

        with open(self._FILE_OUT, "r") as fi:
            out = yaml.load(fi)
        return out

    def recreate(self):
        if os.path.isfile(self._FILE_OUT):
            os.remove(self._FILE_OUT)
        self._make_config_file()
        self.config = self._read_config_file()


def get():
    """"
    Creates instance of the Singleton class
    """
    handler = ConfigHandler.get_instance()
    return handler.config


def update(**kwargs):
    """"
    Updates the configurations used

    Expects the input configuration to be in the DefaultConfigurationOptions enumerator

    """
    # Rule: update function is not allowed to be called from inside code-lib/core (except for availability_test)
    call_path = os.path.normpath(inspect.stack()[1][1])
    if envir.codelib_path() + '\\core' in call_path and 'availability_test' not in call_path:
        error_msg = "Update function not allowed to be called from within code-lib/core"
        raise Exception(error_msg)
    else:
        handler = ConfigHandler.get_instance()
        # Update singleton environment dictionary with input keyword arguments..
        update_dict = {DefaultConfigurationOptions.__dict__[i].name:v for i, v in kwargs.items()}

        handler.config.update(update_dict)


if __name__ == '__main__':
    print(get())
