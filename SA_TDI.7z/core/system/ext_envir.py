"""
This module allows for a centralised place for handling environments for external systems (e.g. ORCA,
ScenarioEngine, Risk Factor Repository, etc.)

The handling works by placing a config file in the code-lib data folder (which is dependant on the internal code-lib
environment). At creation all external systems are given a default environment, specified in the "default_config()"
method. After the config file has been created, it can be opened (in notepad or similar) and modified by the user.

Two functions are important to know for users of this module: "get()" and "update()".
    - get():    used for fetching the environments for all external system
    - update(): used to make a temporary update to the environment which will persist until code session has ended
                (for scripts this means at code termination)

Example:
    The module is called (from python) like this::

        from core.system import ext_envir
        print(ext_envir.get())
        print(ext_envir.get()['ORCA'])
        ext_envir.update(ext_envir.ORCA.uat)
        print(ext_envir.get())

Warning:
    Two rules are specified for the "update()" function:
        1): It cannot be called from within code-lib/core (changing the config file should not be something that is done
            by default in any base methods in code-lib, but something you want to do in a specific application / unit
            test)

Notes:
    Author: g48606 (Oskar Rosendal)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       19feb2018   G48606      Initial creation
    2       19nov2018   G46435      Added report-orchestrator to ScenarioEngine class
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    1       07mar2018   JBrandt     OK          Added to-do's realted to code-standard and structure
    ======= =========   ========    =========   ============================================================================
"""
from functools import lru_cache
import inspect
import os
#import ripl_core.get_access_token
import ripl_core_auth.get_access_token
from collections import namedtuple
import yaml
from future.utils import with_metaclass
from core.connection import credentials
from core.system import envir
from core.utils import singleton, encryption

_DATA_PATH = envir.data_path()
_FILE_OUT = _DATA_PATH + '/config_ext_envir.yml'


def default_config():
    """
    Returns a dictionary with default environments for all external services.

    The external environments to be used might depend on which internal environment is used (whether code-lib is run
    from dev, test or prod), and thus the cfg file allows for a separate specification

    Returns:
        (dict): Dictionary of default external environments for each internal environment

    Notes:
        Author: g48606
    """
    cfg = dict(
        # Define the default environments to be used when using RiskLib
        MARS=MARS.INFOP,
        ScenarioEngine=ScenarioEngine.uat,
        ORCA=ORCA.uat,
        RiskFactorRepository=RiskFactorRepository.uat,
        TradeHub=TradeHub.obfuscated,
        MDS=MDS.prod,
        MDHub=MDHub.int,
        TradePositionGateway=TradePositionGateway.uat,
        # RIPL=RIPL.uat,
    )
    return cfg


def config_yaml():
    """
    Creates the string which is written to the config file.

    To be able to include comments in the yaml file, we create a string from the default_cfg dictionary while adding
    lines with relevant comments to the file.

    Warning:
        This function looks up the keys of the default_cfg dictionary directly and will break if key names are changed.

    Returns:
        (str): string to be written to the config file

    Notes:
        Author: g48606
    """
    default_cfg = default_config()

    dev_envir = '\n'.join(['    ' + key + ': ' + value.envir for key, value in default_cfg['dev_envir'].items()])
    test_envir = '\n'.join(['    ' + key + ': ' + value.envir for key, value in default_cfg['test_envir'].items()])
    prod_envir = '\n'.join(['    ' + key + ': ' + value.envir for key, value in default_cfg['prod_envir'].items()])

    envirs = '\n'.join([key + ': ' + value.envir for key, value in default_cfg.items()])
    return_str = ("""############## EXTERNAL ENVIRONMENTS FOR RISKLIB ##############\n"""
                  + envirs)
    return return_str


class EnvirHandler(singleton.Singleton):
    """
    A singleton class for loading the config file for external environments, or if it doesn't exist, creating the file
    and then loading it. The singleton pattern is used to allow the user to make temporary environment changes in an
    instance of the code.
    """
    def __init__(self):
        self.environments = self._read_envir_file()

    @staticmethod
    def _make_envir_file():
        """
        Calls the "config_yaml" method to create the config file string, which is then written to the data path which
        is specified by core.system.envir.data_path()

        Notes:
            Author: g48606
        """
        # If the folder specified by the data path does not exist, it is created
        if not os.path.isdir(_DATA_PATH):
            os.makedirs(_DATA_PATH)

        # Using a standard text writer to write the string in "config_yaml()" to the _FILE_OUT
        with open(_FILE_OUT, "w") as fo:
            fo.write(config_yaml())

    def _read_envir_file(self):
        """
        Loads the environments from the config file

        If the config file doesn't exist, self._make_envir_file() is first called, and then loaded afterwards. Then a
        filtering is performed, where only the configuration relevant for the internal code-lib environment is kept

        Notes:
            Author: g48606
        """
        if not os.path.isfile(_FILE_OUT):
            self._make_envir_file()

        with open(_FILE_OUT, "r") as fi:
            out = yaml.load(fi, Loader=yaml.BaseLoader)
            # After the file has been loaded, only keep the dictionary needed for the current code-lib environment
            # out = out[envir.detect()]
        return out

    def recreate(self):
        if os.path.isfile(_FILE_OUT):
            os.remove(_FILE_OUT)
        self._make_envir_file()
        self.environments = self._read_envir_file()


def get():
    """
    Returns the list of external system environments for the code-lib environment from where it's called

    This function instantiates the singleton class "EnvirHandler", and returns the environment attribute of the class.
    The environments are a dictionary with a key for each external system, and the value being the current configured
    environment for the given external system.
    It is also possible to find this information by going to the data path and opening the config file in a text editor

    Returns:
        (dict): dictionary holding the external systems and their configurated environments

    Example:
        The module is called (from python) like this::

            from core.system import ext_envir
            ext_envir.get()
    """
    handler = EnvirHandler.get_instance()
    return handler.environments


def update(*args):
    """
    Allows user to temporarily update the environments specified in the config file.

    These updates will persist until the current running program has terminated (due to the singleton pattern), but will
    NOT get written to the config file. Permanent environment updates are performed by opening the config file in the
    data path and typing in a new default environment to use.

    Args:
        args (ext_envir.<source-class with env attribute>): The argument name specifies the external system to temporarily
                                                            update environment for, and the value specifies which environment
                                                            should be used rather than the default one.
                                                            E.g. ext_envir.ORCA.uat

    Example:
        The module is called (from python) like this::

            from core.system import ext_envir
            ext_envir.update(ext_envir.RiskFactorRepository.uat,
                             ext_envir.ScenarioEngine.uat,
                             ext_envir.ORCA.dev)

    Notes:
        Author: g48606
    """
    kwargs = {x.system: x.envir for x in args}
    handler = EnvirHandler.get_instance()

    # Print environment update, if any
    for arg in args:
        if arg.envir != handler.environments.get(arg.system):
            print("%s is now connecting to '%s' environment (changed from '%s' environment)"
                  % (arg.system, arg.envir, handler.environments.get(arg.system)))
    # Update singleton environment dictionary with input keyword arguments..
    handler.environments.update(**kwargs)


# =====================================================================================================================
# The code below specifies classes holding environment specific information for each external system.
# =====================================================================================================================
class EnvirMeta(type):
    """
    Meta class allowing subclasses of ExternalServices to both have enumerator functionality and normal class
    functionality.

    More technical, when a class attribute is called, instead of just returning the value of the class attribute, a
    NamedActivator is returned with the source (child class name) and the value, mimicking the enumerator functionality.
    Furthermore, the __dir__ class method is overridden to only return class attributes

    Notes:
        Author: g48606
    """
    def __new__(mcs, name, bases, dct):
        c = super(EnvirMeta, mcs).__new__(mcs, name, bases, dct)
        c._member_names = []
        for key, value in c.__dict__.items():
            if isinstance(value, str) and not key.startswith("__"):
                c._member_names.append(key)
                setattr(c, key, NamedActivator(system=c.__name__, envir=value))
        return c

    def __dir__(cls):
        return cls._member_names


class NamedActivator:
    """
    Class mimicking the behaviour of the named tuple, with the exception that an 'active()' method is also implemented,
    which can be used to change the external environment for the given service
    """
    def __init__(self, system, envir):
        self.envir = envir
        self.system = system

    def __repr__(self):
        return f"Source(system='{self.system}', envir='{self.envir}')"

    def activate(self):
        update(self)

    def __dir__(self):
        return ['activate()', 'envir', 'system']


class ExternalServices(with_metaclass(EnvirMeta)):
    """
    Parent class defining all elements which is common between each external system.

    This includes setting the default environment according to the environment handler, and checking that the given
    environment is legal for the given external system. Further, it is required that each child class implements the
    method "_server_mapping", specifying which server each environment is mapped to.

    Notes:
        Author: g48606
    """
    def __init__(self):
        # WARNING: The below line fetches the environment using the "get()" function and a key look-up on the child
        # class name. Thus if the name of the child class does not correspond to a key in the ext_envir file, an error
        # is raised.
        try:
            self.envir = get()[self.__class__.__name__]
        except KeyError:
            handler = EnvirHandler.get_instance()
            handler.recreate()
            err_str = "Recreated environment file, as core.system.ext_envir.default_config has been changed. \n\n" + \
                      "Any changes made using ext_envir.update during this code execution has been disregarded. \n\n" + \
                      "Please re-run your code if you're using ext_envir.update"
            print(err_str)
            raise Exception(err_str)
        if not hasattr(self.__class__, self.envir.replace('-', '_')):  # Replace dash with underscore in envir name
            error_msg = "The environment '%s' has not been specified for %s" % (self.envir, self.__class__.__name__)
            raise AttributeError(error_msg)

    @property
    def _server_mapping(self, *args, **kwargs):
        raise NotImplementedError

    @staticmethod
    def get_credentials(ext_envir):
        """
        Uses the core.connection.credentials module to fetch credentials information for ORCA, the user_id and decrypted
        password is then returned

        Returns:
            (dict): dictionary holding user_id and decrypted password
        """
        creds = credentials.get_personal_credentials(ext_envir)
        uid = creds['USER']
        pwd = encryption.decrypt(encrypted_string=creds['PASSWORD'], encode_type=creds['ENCRYPTION_TYPE'])
        return dict(user=uid, password=pwd)


class ORCA(ExternalServices):
    """
    Class specifying legal environments for ORCA, and their respective server mapping.
    """
    # Legal environments for ORCA
    uat = 'uat'
    dev = 'dev'
    prod_user = 'prod_user'
    prod = 'prod'
    CI = 'CI'
    ap_orca4t = 'ap-orca4t'

    def __init__(self):
        ExternalServices.__init__(self)
        self.server = self._server_mapping()
        self.config = self._create_config()

    def _server_mapping(self):
        if self.envir.lower() == 'uat':
            out = ['ap-orca28t', 'ap-orca29t', 'ap-orca30t', 'ap-orca31t']
        elif self.envir.lower() == 'prod':
            out = ['ap-orca2p', 'ap-orca3p', 'ap-orca8p']
        elif self.envir.lower() == 'prod_user':
            out = ['ap-orca4p', 'ap-orca5p', 'ap-orca6p']
            out = ['messagebus-orca-userprod.oneadr.net']
        elif self.envir.lower() == 'dev':
            out = ['ap-orca5t']
        elif self.envir.lower() == 'ci':
            out = ['ap-orca4t.oneadr.net']
        elif self.envir.lower() == 'ap-orca4t':
            out = ['ap-orca4t']
        else:
            raise NotImplementedError
        return out

    def _create_config(self):
        """
        Method creating the configuration which must override the default configuration to be able to connect to ORCA.
        The "self.config" attribute is called from within core.utils.orca_helper

        Returns:
            (config):   ORCA configuration object which can be passed as argument when requesting ORCA services
        """
        import orca.configuration
        creds = self.get_credentials('ORCA')
        overwrites = [('rabbit_mq.hosts', self.server),
                      ('rabbit_mq.user', creds['user']),
                      ('rabbit_mq.password', creds['password'])]
        return orca.configuration.Configuration(overwrites=overwrites)


class TradeHub(ExternalServices):
    """
    Class specifying legal environments for TradeHub, and their respective server mapping.
    """
    # Legal environments for TradeHub
    uat = 'uat'
    obfuscated = 'obfuscated'

    def __init__(self):
        ExternalServices.__init__(self)
        self.server = self._server_mapping()
        self.config = self._create_config()

    def _server_mapping(self):
        if self.envir.lower() == 'uat':
            out = 'ap-th3t.oneadr.net'
        elif self.envir.lower() == 'obfuscated':
            out = 'ap-th1t.oneadr.net'
        else:
            raise NotImplementedError
        return out

    def _create_config(self):
        import tradehub
        dir_path = os.path.normpath(envir.codelib_path() + '\\core\\connection\\')
        config_dict = dict(
            host=self.server,
            port=1111,
            keystore_path=os.path.join(dir_path,"acls\\int_client_id\\keystore.p12"),
            truststore_path=os.path.join(dir_path,"acls\\int_client_id\\truststore.p12"),
            keystore_password=open(os.path.join(dir_path,'acls\\int_client_id\\keystore.pw')).read(),
            truststore_password=open(os.path.join(dir_path,'acls\\int_client_id\\truststore.pw')).read()
        )
        return tradehub.query_api.authenticate_with_pkcs12(**config_dict)


class MDS(ExternalServices):
    """
    Class specifying legal environments for MDS, and their respective server mapping.
    """
    # Legal environments for MDS
    prod = 'prod'
    test = 'test'

    def __init__(self):
        ExternalServices.__init__(self)
        self.server = self._server_mapping()

    def _server_mapping(self):
        if self.envir.lower() == 'prod':
            out = 'http://mds.oneadr.net/v1/marketdata'
        elif self.envir.lower() == 'test':
            out = 'http://vda1cs1527/v1/marketdata'
        else:
            raise NotImplementedError
        return out


class MARS(ExternalServices):
    """
    Class specifying legal environments for MARS, and their respective server mapping.
    """
    # Legal environments for MARS
    INFOP = 'INFOP'
    INFOD = 'INFOD'
    INFO3D = 'INFO3D'
    INFOAT = 'INFOAT'
    INFOT = 'INFOT'
    INFOBT = 'INFOBT'

    def __init__(self):
        ExternalServices.__init__(self)
        self.server = self._server_mapping()

    def _server_mapping(self):
        return self.envir.upper()


class DAMD(ExternalServices):
    """
    Class specifying legal environments for DAMD(S), and their respective server mapping.
    """
    # Legal environments for DAMD
    DAMDS = 'DAMDS'

    def __init__(self):
        ExternalServices.__init__(self)
        self.server = self._server_mapping()

    def _server_mapping(self):
        if self.envir.upper() == 'DAMDS':
            out = 'DAMDS'
        else:
            raise NotImplementedError
        return out


class RiskFactorRepository(ExternalServices):
    """
    Class specifying legal environments for Risk Factor Repository, and their respective server mapping.
    """
    # Legal environments for Risk Factor Repository
    uat = 'uat'
    bt = 'bt'
    dev = 'dev'
    prod = 'prod'
    groundhog = 'groundhog'

    def __init__(self):
        ExternalServices.__init__(self)
        self.risk_factor_repository = self._server_mapping(rfm_type='rfr-service')
        self.risk_factor_curator = self._server_mapping(rfm_type='rfc-service')

    def _server_mapping(self, rfm_type):
        if self.envir.lower() == 'prod':
            out = dict(consulHost='consul.sre.oneadr.net',
                       useConsul=True,
                       consulPort=443,
                       consulScheme='https',
                       environment=self.envir,
                       consulToken='bce04cb4-5561-16b1-2c50-f442e87c0fcb')

        # Bt environment doesn't require nordea token so we sent dummy psw to not use ninaa (if ninaa down this work)
        elif self.envir.lower() == 'bt':   
            out = dict(consulHost='consul.infra.itcm.oneadr.net',
                       useConsul=True,
                       consulPort=8500,
                       consulScheme='http',
                       environment=self.envir,
                       nordeaToken='asdasdasd')
        else:
            out = dict(consulHost='consul.ripl.qaoneadr.local',
                       useConsul=True,
                       consulPort=8500,
                       consulScheme='http',
                       environment=self.envir)
        return out


class ScenarioEngine(ExternalServices):
    """
    Class specifying legal environments for Scenario Engine, and their respective server mapping.
    """
    # Legal environments for Scenario Engine
    uat = 'uat'
    bt = 'bt'
    dev = 'dev'
    prod = 'prod'
    groundhog = 'groundhog'

    def __init__(self):
        ExternalServices.__init__(self)
        self.scenario_definer = self._server_mapping(se_type='scenario-definer')
        self.scenario_generator = self._server_mapping(se_type='scenario-generator')
        self.scenario_executor = self._server_mapping(se_type='scenario-executor')
        self.se_full_reval = self._server_mapping(se_type='se-full-valuation')
        self.report_orchestrator = self._server_mapping(se_type='report-orchestrator')

    def _server_mapping(self, se_type):
        if self.envir.lower() == 'prod':
            out = dict(consulHost='consul.sre.oneadr.net',
                       useConsul=True,
                       consulPort=443,
                       consulScheme='https',
                       environment=self.envir,
                       consulToken='bce04cb4-5561-16b1-2c50-f442e87c0fcb')
        else:
            out = dict(consulHost='consul.ripl.qaoneadr.local',
                       useConsul=True,
                       consulPort=8500,
                       consulScheme='http',
                       environment=self.envir)
        return out


class TradePositionGateway(ExternalServices):
    uat = 'uat'
    bt = 'bt'
    dev = 'dev'
    prod = 'prod'

    def __init__(self):
        ExternalServices.__init__(self)
        self.vip_definer = self._server_mapping(service='vip-definer')
        self.trade_information_service = self._server_mapping(service='trade-information-service')
        self.isin_categorisation_reconciliator = self._server_mapping(service='isin-categorization-reconciliator')

    def _server_mapping(self, service):
        if self.envir.lower() == 'prod':
            out = dict(consulHost='consul.sre.oneadr.net',
                       useConsul=True,
                       consulPort=443,
                       consulScheme='https',
                       environment=self.envir,
                       consulToken='bce04cb4-5561-16b1-2c50-f442e87c0fcb')
        else:
            out = dict(consulHost='consul.ripl.qaoneadr.local',
                       useConsul=True,
                       consulPort=8500,
                       consulScheme='http',
                       environment=self.envir)
        return out


class MDHub(ExternalServices):
    """
    Class specifying legal environments for Market Data Hub, and their respective server mapping.
    """
    # Legal environments for Market Data Hub
    dev = 'dev'
    int = 'int'

    def __init__(self):
        ExternalServices.__init__(self)
        self.server = self._server_mapping()

    def _server_mapping(self):
        if self.envir.lower() == 'dev':
            return 'dev'
        if self.envir.lower() == 'int':
            return 'int'
        else:
            raise NotImplementedError


if __name__ == '__main__':
    print(get())
    print(ScenarioEngine.uat)
    ScenarioEngine()
    obj = TradeHub()
    print('server: ' + str(obj.server))
    print('config: ' + str(obj.config))
