"""
The module contain a few tests for dependency tests

Notes:
    Author: g48454

"""
import pandas as pd
import risk_factor_repository
from core.connection import credentials
import requests
import json
from distutils.version import StrictVersion
from core.connection import database_connect


def database(database_list):
    """
    Check whether in user's computer there is credential stored for each database and whether credential is working

    Args:
        database_list          (list of dbs):     list of databases

    Returns:
        (dataframe):   A df contain results

    Example:
        The module is called (from python) like this::

            something_returned = database(['INFOP', 'DAMDS'] )

    Notes:
        Author: g48454
    """
    result_df = pd.DataFrame()
    for credential in database_list:
        result = database_connect.credential_test(credential)
        single_df = pd.DataFrame(data=[["credential test " + credential, result]], columns=['Test Name', 'Result'])
        result_df = result_df.append(single_df)
    return result_df


def python_distribution(distribution_number=7.2):
    from core.system import version
    try:
        python_version_number = version.package_version_number()
    except:
        python_version_number = 0

    single_df = pd.DataFrame(data=[["MRIA Python version have to be %s:" % distribution_number, python_version_number == distribution_number]],
                             columns=['Test Name', 'Result'])
    return single_df


def mds(test_env=False):
    service_arg = "http://mds.oneadr.net" if not test_env else "http://vda1cs1527"
    service_arg += "/v1/marketdata/prices/reval?Isins=DK0009792525&TradeDate=2017-04-28&format=json"
    auth = credentials.get_HttpNtlmAuth()
    try:
        headers = {'accept': 'application/json;odata=verbose'}
        response = requests.post(url=service_arg
                                , auth=auth
                                 , headers=headers)
        #print(response.status_code)
        #print(response.content)
        data = json.loads(response.content)
        result = True
    except:
        result = False

    return pd.DataFrame(data=[["mds service access test", result]],
                             columns=['Test Name', 'Result'])


def orca_version(test_version = '0.20.2'):
    import orca
    test_result = StrictVersion(orca.__version__) >= StrictVersion(test_version)
    single_df = pd.DataFrame(data=[["orca version has to be :" + test_version, test_result]],
                             columns=['Test Name', 'Result'])
    return single_df


def decide(checks):
    import sys
    df = pd.DataFrame()
    for item in checks:
        df = df.append(item)

    print("Dependency check result:")
    print(df)
    l = df.Result.tolist()
    if l.count(False) > 0:
        print("There is a dependency problem, prototype aborted!")
        sys.exit()


def rfr_dependency(min_req_version):
    rfr_v = risk_factor_repository.__version__.split(".")
    req_v = min_req_version.split(".")
    if int(rfr_v[0]) > int(req_v[0]):
        return True
    elif int(rfr_v[0]) == int(req_v[0]):
        if int(rfr_v[1]) > int(req_v[1]):
            return True
        elif int(rfr_v[1]) == int(req_v[1]):
            if int(''.join(x for x in rfr_v[2] if x.isdigit())) >= int(''.join(x for x in req_v[2] if x.isdigit())):
                return True
    return False


def outlier_detection_dependency_test():
    from packaging import version

    try:
        import bokeh
        assert version.parse(bokeh.__version__) >= version.parse('1.0.4')
    except (ModuleNotFoundError, AssertionError):
        raise ImportError("Current version of bokeh is not updated. Please ensure to have bokeh version 1.0.4 or newer")

    try:
        from numpy._distributor_init import NUMPY_MKL
    except ImportError:
        raise ImportError("""numpy+mkl (Math Kernel Library) is not installed. The mkl extension in needed for scipy to 
                             work. You can download it here: \n https://www.lfd.uci.edu/~gohlke/pythonlibs/#numpy""")
