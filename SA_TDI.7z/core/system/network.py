"""
Performs various tasks related to network drives.

Including translating drive-letters into full network UNC paths.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       05mar2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import subprocess
import re


def get_UNC_path(mapped_drive_letter, info = 0):
    """
    Returns the UNC path of a mapped network drive.


    Args:
        mapped_drive_letter     (str):      Letter of the mapped drive (e.g. H or Z)
        info                    (int):              Level of information printed. The higher, the more information is printed

    Returns:
        (str):   Full UNC path of network location (\\servername\sharename\..\..)

    Raises:

    Example:

    Warning:
        Different approach is in practice used when running module in PyCharm.
        The win32com module cannot be imported in Pycharm, which is why a fallback approach has been implemented.

    Notes:
        Author: g50444
    """
    try:
        # Some issues in current distribution when importing this from Pycharm...
        # ... so fallback method has been implemented.
        import win32com.client as client
    except:
        # Fallback version...
        return get_UNC_path_cmd(mapped_drive_letter = mapped_drive_letter, info = info)

    # Finding all mapped network drives
    network = client.Dispatch('WScript.Network')
    all_network_drives = network.EnumNetworkDrives()

    # Looping through object of drive-letters and paths following each other as rows
    for idx,value in enumerate(all_network_drives):

        if idx % 2 == 0:
            # ===================================================================================
            # Drive letters are in place 0,2,4,6,... (even elements)
            # These even elements are identified using modulus calculation
            # (where there is no remainder after division by 2)
            # ===================================================================================
            drive_letter = value
        else:
            # Odd elements contain the network (UNC) path
            network_path = value
            if drive_letter[:1].upper() == mapped_drive_letter[:1].upper():
                # ===================================================================================
                # We compare only the first element (the letter) in the drive.
                # This way, it does not matter if "H" , "H:" or "H:\\" is given as input.
                # ===================================================================================
                return network_path
    raise KeyError('No mapped network drive found for letter: "' + mapped_drive_letter + '"')


def get_UNC_path_cmd(mapped_drive_letter, info = 0):
    """
    Returns the UNC path of a mapped network drive, using CMD-commands to find it.

    The functions uses the CMD (command prompt) "use net" command, and interprets
    the returned text string...

    Args:
        mapped_drive_letter     (str):      Letter of the mapped drive (e.g. H or Z)
        info                    (int):      Level of information printed. The higher, the more information is printed

    Returns:
        (str):   Full UNC path of network location (\\servername\sharename\..\..)

    Raises:

    Example:
        The module is called (from python) like this::
        
            network_path = get_UNC_path_cmd('H:', info = 0)

    Warning:

    Notes:
        Author: JBrandt (g50444)
    """

    try:
        raw_cmd_string = subprocess.check_output('net use')
    except:
        raise WindowsError('Error when executing CMD-command. Cannot find mapped network drives.')

    # ===================================================================================
    # Structure of the string is:
    # Status    Drive Letter    Network Path        Network
    # OK        H:              \\server\share      Microsoft Windows Network
    #
    # ===================================================================================

    for idx,line in enumerate(re.split('\r|\n',raw_cmd_string)):
        # First rows are headers, and we are only interested in active mapped drives (status OK)
        if (idx > 5 and line.startswith('OK')):
            # Reducing line - removing the OK at the beginning...
            line = line[2:].lstrip()
            drive = line[:1]
            if drive.upper() == mapped_drive_letter[:1].upper():
                # the drive letter has been found
                UNC_path = line[3:].lstrip().split(' ')[0]
                return UNC_path

    raise KeyError('Not able to find mapped network drive letter: ' + mapped_drive_letter)


def get_path_of_local_mapped_drive(mapped_drive_letter):
    """
    Returns the local path of a folder mapped to a drive, using CMD-commands to find it.

    The functions uses the CMD (command prompt) "subst" command, and interprets the returned text string...

    Args:
        mapped_drive_letter     (str):      Letter of the mapped drive (e.g. H or Z)
        info                    (int):      Level of information printed. The higher, the more information is printed

    Returns:
        (str):   Full path of local location (c:\my-folder)

    Raises:

    Example:
        The module is called (from python) like this::

            network_path = get_path_of_local_mapped_drive('H:')

    Warning:

    Notes:
        Author: JBrandt (g50444)
    """
    try:
        raw_cmd_string = subprocess.check_output('subst')
    except:
        raise WindowsError('Error when executing CMD-command. Cannot find mapped drive.')

    # ===================================================================================
    # Structure of the string is:
    # H:\\: = > C:\\h - drive\r\n
    # ===================================================================================

    for line in re.split('\r|\n', raw_cmd_string):
        # The line of interest should start with the mapped drive letter
        if (line.upper().startswith(mapped_drive_letter.upper())):
            # Reducing line - removing the OK at the beginning...
            local_path = line[8:].lstrip()
            return local_path
    raise KeyError('Not able to find mapped drive letter: ' + mapped_drive_letter)


# def get_h_drive_path():
#     """
#         Returns the UNC path of the h drive
#
#     Args:
#         None
#
#     Returns:
#         (str):   Full UNC path of h drive location (\\servername\sharename\..\..)
#
#     Notes:
#         Author: g48454
#     """
#     try:
#         out = get_UNC_path("H")
#     except:
#         # H-Drive is not a network drive...? We will try to find the local full path.
#         try:
#             out = get_path_of_local_mapped_drive("H")
#         except:
#             import getpass
#             out = r"//DCD02HH-EVS04/Home/" + getpass.getuser().upper() + "/"
#     return out


if __name__ == '__main__':
    a = get_path_of_local_mapped_drive('k:')
    print(a)