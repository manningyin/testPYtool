"""
Module for fetching and changing data in the Windows Registry

Module has been named after the windows GUI for this - called RegEdit

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       15FEB2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
try:
    import winreg
except ImportError:
    import _winreg


def regkey_handle(path, info = 0):
    """
    Returns an element in the windows registry as a handle (for further processing)

    Args:
        path        (list or str):      Path of the key in the Windows Registry.
        info        (int):              Level of information printed. The higher, the more information is printed

    Returns:
        (PyHKEY/handle):    Reference to a key in the windows registry

    Raises:
        KeyError: The key was not found

    Example:
        The module is called (from python) like this::
        
            my_reg_handle = regkey_handle(path = "HKEY_LOCAL_MACHINE\\SOFTWARE\\ODBC\\ODBC.INI\\ODBC Data Sources")

    Warning:

    Notes:
        Author: g50444
    """


    if isinstance(path, str):
        # Making sure that path is a list of path elements
        path = path.split("\\")

    # ===================================================================================
    # We walk down the "folder" (or "registry key hierarchy") path.
    # In each level we search for the address/location of the next folder, which will
    # be the starting point in our next loop.
    # ===================================================================================

    for i,key in enumerate(path):
        if info > 0:
            print('Looking for key:',key)
        try:
            if i == 0:
                # ===================================================================================
                # First level of the registry, we look up using its name
                # Defining the starting point handle...
                # ===================================================================================
                next_starting_handle = getattr(winreg, path[0])
            else:
                next_starting_handle = winreg.OpenKey(next_starting_handle, key)
        except:
            if not i == 0:
                upper_level = '"' + path[i-1] + '"'
            else:
                upper_level = 'Registry Root'
            raise KeyError('Not able to find the "' + key + '" element in the ' + upper_level + ' folder.',
                           'Please check that the path is correct!')

    return next_starting_handle

def regkey_value(path, name, info = 0):
    """
    Returns the content of a key/name in the Windows Registry

    Args:
        path        (list or str):      Path of the key in the Windows Registry.
                                        Eg. "HKEY_LOCAL_MACHINE\\HARDWARE\\DESCRIPTION\\System\\BIOS" or
                                        ["HKEY_LOCAL_MACHINE","HARDWARE","DESCRIPTION","System","BIOS"]
        name        (str):              Name of the element/name/registry in the key
        start_key   (int):              Leave empty! Used in inside function loop (over itself)

    Returns:
        (srt):   Value of the element in the key

    Raises:
        KeyError('The registry name could not be found.')
        
    Example:
        The module is called (from python) like this::

            driver_name = regkey_value( path        = r"HKEY_LOCAL_MACHINE\SOFTWARE\ODBC\ODBC.INI\ODBC Data Sources",
                                        name        = 'INFOP'
                                        )


    Warning:
        This module does not support case sensitive/specific values, e.g. it will not distinguish between
        "ThisDriver" and "THISDRIVER".

    Notes:
        Author: g50444
    """

    handle = regkey_handle(path = path, info = info)

    if info > 0:
        print('regkey_handle',regkey_handle)

    desc, i = None, 0
    while not desc or desc[0].upper() != name.upper():
        try:
            desc = winreg.EnumValue(handle, i)
        except OSError:
            raise KeyError('The registry name: "' + name + '" could not be found.')
        i += 1

    # Found it!
    return desc[1]

def regkey_contents(path, info = 0):
    """
    Returns the content of a level in the Windows Registry key hierarchy

    Args:
        path        (list or str):      Path of the level in the Windows Registry.
                                        Eg. "HKEY_LOCAL_MACHINE\\HARDWARE\\DESCRIPTION\\System\\BIOS" or
                                        ["HKEY_LOCAL_MACHINE","HARDWARE","DESCRIPTION","System","BIOS"]
        start_key   (int):              Leave empty! Used in inside function loop (over itself)

    Returns:
        (list):   Contents of level in the hierarchy. E.g. the keys that exist in the specified level/path

    Raises:

    Example:
        The module is called (from python) like this::

            path_contents = regkey_contents(path   = r"HKEY_LOCAL_MACHINE\SOFTWARE\ODBC\ODBC.INI\ODBC Data Sources")

    Warning:

    Notes:
        Author: g50444
    """

    handle = regkey_handle(path = path, info = info)

    if info > 0:
        print('regkey_handle',regkey_handle)

    i = 0
    regkey_contents = []
    no_more_keys = False
    while not no_more_keys == True:
        try:
            regkey_contents.append(winreg.EnumValue(handle, i)[0])
        except:
            no_more_keys = True
        i += 1
    return regkey_contents

if __name__ == '__main__':

    for driver in regkey_contents(r"HKEY_LOCAL_MACHINE\SOFTWARE\ODBC\ODBCINST.INI\ODBC Drivers", info = 0):
        if not driver.upper().find('ORACLE') == -1:
            print(driver)

    # print(a)