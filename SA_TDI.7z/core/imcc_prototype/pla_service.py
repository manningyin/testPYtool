"""
Module for performing FRTB pl-attribution tests.

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01jan2018   g48454      Initial creation (header added by JBrandt)
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    1       13mar2018   JBrandt     OK          Added some comments as part of review.
    ======= =========   ========    =========   ============================================================================
"""


import pandas as pd
from core.utils import error_handler
import datetime as dt
import quantum as qt
import numpy as np
from core.utils import date_helper


def pl_attribution(RTPL_DataFrame):
    """
    Function for calculating FRTB pl-attribution measures for a dataframe of positions and their RTPL results.

    The code will do the followings:

        1) work out how many months we need do pl attribution, depends on the startDate and endDate specified in class
        2) calculate average ratio (ratio 1) and variance ratio (ratio 2) for each position and each month

    Args:
        RTPL_DataFrame (Dataframe): DF with following columns 'Position', 'Day1', 'Day2', unExplained_PL, HPL and RTPL
    Returns:
        (DataFrame): pl attribution DF with columns: 'Position', 'start date', 'end date', 'ratio1', 'ratio2'

    Notes:
        Author: g48454 (Shengyao)
    """

    # ===================================================================================
    # Format the data frame including reindex and convert all dates to datetime
    # ===================================================================================
    RTPL_DataFrame = RTPL_DataFrame.reset_index()
    RTPL_DataFrame['Day1'] = [date_helper.to_datetime(x) for x in RTPL_DataFrame['Day1'].tolist()]

    # Determining for how many months we need to do the calculation
    start_date = RTPL_DataFrame['Day1'].min()
    end_date = RTPL_DataFrame['Day1'].max()
    pl_attribution_month_count = ((end_date.year - start_date.year) * 12 + 
                                  end_date.month - start_date.month + 1
                                  )

    # Initialising empty dataframe used for storing output for each position
    all_position_pla = pd.DataFrame()

    # ===================================================================================
    # The below code will do the following:
    # 1) get the unique positions from the data frame
    # 2) for each position, work out how many months need p&l attribution
    # 3) calculate p&l attribution results month by month, pos by pos
    # 4) output all of them to a data frame.
    # ===================================================================================
    try:
        unique_pos_list = RTPL_DataFrame['Position'].unique()
    except Exception as e:
        error_handler.track_error(  error_message   = e,
                                    comments        = 'The RTPL is empty, the pl attribution can not be processed',
                                  )
        return

    for current_position in unique_pos_list:
        # Selecting a specific position from the overall RTPL data
        try:
            current_ISIN_RTPL = RTPL_DataFrame[RTPL_DataFrame['Position'] == current_position]
        except Exception as e:
            # No rows for current_position found. Skipping to next position.
            error_handler.track_error(  error_message   = e,
                                        identifier      = current_position,
                                        comments        = 'Not able to calculate pl attribution for this position ' + 
                                                          'for all periods.'
                                        )
            continue

        # Loop through all months identified for PL-Attribution calculation
        current_date = dt.datetime(start_date.year, start_date.month, 1)
        for x in range(0, pl_attribution_month_count):
            try:
                next_date = qt.addTenor(date=current_date, tenor='1M')
                next_date = date_helper.to_datetime(next_date)

                # ===================================================================================
                # Selecting all pl-dates within the currently processed month.
                # This is technically done by creating a series of "True"/"False" matching to rows in
                # the dataframe, indicating if the row matches the date-selection criteria.
                # Then applying the True/False list as a filter to the dataframe, so
                # "current_month_and_ISIN_RTPL" only contains rows that matches the data filter.
                # ===================================================================================
                current_month_filter =  (
                                            (current_ISIN_RTPL['Day1'] >= current_date) &
                                            (current_ISIN_RTPL['Day1'] < next_date)
                                         )

                current_month_and_ISIN_RTPL = current_ISIN_RTPL[current_month_filter]
                
                unexplained_PL = current_month_and_ISIN_RTPL["unExplained_PL"]

                pla_ratio_1 = mean_ratio(unexplained_PL=unexplained_PL, HPL=current_month_and_ISIN_RTPL.HPL)
                pla_ratio_2 = variance_ratio(unexplained_PL=unexplained_PL, HPL=current_month_and_ISIN_RTPL.HPL)

            except Exception as e:
                error_handler.track_error(error_message=e, identifier=current_position, date=current_date,
                                          comments='Not able to calculate pl attribution for this position and this period')
                pla_ratio_1 = 'na'
                pla_ratio_2 = 'na'
            # Collecting data for current position and adding it to general output dataframe
            single_position_pla= pd.DataFrame([
                                                    [current_position,
                                                     current_date,
                                                     date_helper.to_date_str(next_date),
                                                     pla_ratio_1,
                                                     pla_ratio_2
                                                     ]
                                                ],
                                                columns =
                                                    ['Position',
                                                     'start date',
                                                     'end date',
                                                     'ratio1',
                                                     'ratio2'
                                                     ]
                                                )
            all_position_pla = all_position_pla.append(single_position_pla)
            current_date = next_date

    return all_position_pla


def mean_ratio(unexplained_PL, HPL):
    """
    Calculates the PL-A mean ratio (ratio 1) - mean unexplained PL over the standard deviation of HPL.

    Args:
        unexplained_PL          (pd.Series):    Value of the unexplained PL (RTPL - HPL) for a chosen period (e.g. month)
        HPL                     (pd.Series):    HPL for the period matching the unexplained_PL

    Returns:
        (number):   PL Attribution ratio 1 - mean unexplained PL over the standard deviation of HPL.

    Example:
        The module is called (from python) like this:

            >>> from core.imcc_prototype import pla_service
            >>> round(pla_service.mean_ratio(unexplained_PL = [0.01,0.01,0.1,0.1,0.01], HPL = [10.02,9.0,11.0,9.8,12.1]),4)
            0.0385

    Notes:
        Author: JBrandt
    """
    ratio = np.mean(unexplained_PL) / np.std(HPL, ddof=1)
    return ratio


def variance_ratio(unexplained_PL, HPL):
    """
    Calculates the PL-A variance ratio (ratio 2) - ratio of variances of unexplained daily PL and variances of daily HPL

    Args:
        unexplained_PL          (pd.Series):    Value of the unexplained PL (RTPL - HPL) for a chosen period (e.g. month)
        HPL                     (pd.Series):    HPL for the period matching the unexplained_PL

    Returns:
        (number):   PL Attribution ratio 2 - variances of unexplained daily PL over variance of daily HPL.

    Example:
        The module is called (from python) like this:

            >>> from core.imcc_prototype import pla_service
            >>> round(pla_service.variance_ratio(unexplained_PL = [0.01,0.01,0.1,0.1,0.01], HPL = [10.02,9.0,11.0,9.8,12.1]),4)
            0.0017

    Notes:
        Author: JBrandt
    """
    ratio = np.var(unexplained_PL) / np.var(HPL)
    return ratio


if __name__ == '__main__':
    import datetime as dt
    from core.scenario.orca_scenario import ScenarioFlow
    from core.scenario import orca_scenario
    from core.position import position_service
    from core.imcc_prototype import rtpl_service
    from core.types import _scenarios, PricingEngine
    import pandas as pd
    from tqdm import tqdm

    pd.set_option('display.max_rows', 200)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    final_df = pd.DataFrame()
    datelist = pd.bdate_range(dt.datetime(2017, 4, 1), periods=20).tolist()
    for eod_date in tqdm(datelist):
        positions = position_service.PositionServiceLoader(book_id=6100100, date=eod_date).data
        scenarios = orca_scenario.generate(risk_factor_list=[],
                                           scenario_flow=ScenarioFlow.Test,
                                           eod_date=eod_date,
                                           observation_period=_scenarios.ObservationPeriod.RTPL)
        sc_list = scenarios['RTPL']
        try:
            PLA = rtpl_service.RTPL_Service(positions=positions,
                           eod_date=eod_date,
                           pricing_engine=PricingEngine.TEST,
                           scenario_list=sc_list)
            PLA.calculate_accrued_int = False
        except:
            continue

        try:
            df_prices = PLA.aggregated_pl_results(forward_pricing=False, linear_decomp=False, drop_zero_scenarios=True, info=0)
        except:
            continue
        final_df = final_df.append(df_prices)
    print(final_df)
    ratio_df = pl_attribution(RTPL_DataFrame=final_df)
    print(ratio_df)