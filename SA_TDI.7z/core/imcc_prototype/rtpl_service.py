import pandas as pd
from pandas.tseries.offsets import BDay
from core.utils import error_handler
from core.market_data.old_loaders.bond_price import BondPrice
from core.position import position_service, valuation_service
from core.pricing import linear_fx_converter
import core.types


class RTPL_Service:
    """
    A general class object for calculating HPL, RTPL and linearly decomposed RTPL. Output is presented in a nicely
    formatted DataFrame, which then can be stored as an excel file for further in-depth analysis.

    To get positions required by the constructor, core.position.position_service.PositionServiceLoader can be called with a
    date and a book_id / portfolio_id. Alternatively, the user can create a dictionary of positions themselves, with
    position_id as key and quantity as value (set quantity to 1 to get unit price). It is important that the given list
    of position_ids exists in TradeHub. Accepted types of position_ids are:

        - (TRADE_ID, SOURCE_SYSTEM), e.g. ('2661435', 'INFINITY')
        - (ISIN, 'SECURITY', CCY), e.g. ('NO0010705536', 'SECURITY', 'NOK')
        - core.types.trades.Trade
        - core.types.trades.Security

    To get the scenarios required by the constructor, core.scenario.generate.generate can be called with
    a risk_factor_context (instance of core.risk_factor.factory.context_factory.ContextFactory), a scenario_flow and an
    eod_date

    Args:
        positions          (dict):      Dictionary with position_ids as keys and quantities as values
        eod_date           (date):      The eod date for which to price the base valuation (should be the same used to
                                        collect scenarios and positions)
        pricing_engine     (Enum):      The engine to use for pricing (core.pricing.PricingEngine), ORCA/QT
        scenario_list      (list):      List of scenarios to apply when calculating RTPL (and optionally for the linear
                                        decomposition of RTPL)

    Public methods:
        .aggregated_pl_results(forward_pricing, linear_decomp, drop_zero_columns, info)
            This function calculates RTPL and collects HPL, RTPL, and optionally linear decomposed RTPL in a nice
            formatted DataFrame with some other relevant information (product types, unexplained PL, etc..)

    Private methods:
        See individual functions for a short description

    Notes:
        Author: g48606
    """
    def __init__(self, positions, eod_date, pricing_engine, scenario_list, d2=None):
        self.d1 = eod_date
        if d2 is None:
            d2 = eod_date + BDay(1)
        self.d2 = d2
        self.positions = positions
        self.scenario_list = scenario_list
        self.calculate_accrued_int = True

        self.pricing_engine = pricing_engine
        self.price_d1, self.acc_interest_d1 = valuation_service.position_valuation(positions=self.positions, eod_date=self.d1, engine=self.pricing_engine)
        self.price_d2, self.acc_interest_d2 = valuation_service.position_valuation(positions=self.positions, eod_date=self.d2, engine=self.pricing_engine)

    def _get_forward_prices(self):
        """
        Loads the forward prices lazily instead of in the initiation, as they might not be needed for all executions
        """
        if not hasattr(self, 'price_d1_fwd'):
            self.price_d1_fwd, self.acc_interest_d1_fwd = valuation_service.position_valuation(positions=self.positions, eod_date=self.d1, engine=self.pricing_engine, valuation_date=self.d2)
        return self.price_d1_fwd, self.acc_interest_d1_fwd

    @staticmethod
    def _calculate_pl(base_valuation, pl_valuation):
        """
        Loops through all keys in the provided base_valuation, and subtracts teh base_valuation from the PL_valuation,
        to get the actual PL numbers. If a key existing in the base_valuation doesn't exist in the pl_valuation, zero
        is used instead
        """
        return {key: pl_valuation[key] - base_valuation[key] if key in pl_valuation else 0 for key in base_valuation}

    def _calculate_theta_pl(self):
        """
        Calculates the theta effect as the difference between the forwarded price and the base valuation
        """
        return self._calculate_pl(base_valuation=self.price_d1, pl_valuation=self._get_forward_prices()[0])

    def _calculate_hpl(self, clean=True, forward_pricing=False):
        """
        Calculates the HPL as the difference between valuations at eod_date + 1 and eod_date. If forward pricing has
        not been used, the theta effect is subtracted from the HPL to align with the RTPL (which will not have a forward
        component in this case)
        """
        hpl = self._calculate_pl(base_valuation=self.price_d1, pl_valuation=self.price_d2)
        if forward_pricing:
            hpl = self._calculate_pl(base_valuation=self._calculate_theta_pl(), pl_valuation=hpl)
        if self.calculate_accrued_int:
            accr_int = self._fetch_accrued_interest()
            for key in hpl:
                if clean:
                    hpl[key] = hpl[key] - accr_int.get(key, 0)
                if key not in accr_int:
                    error_handler.track_error(error_message='No accrued interest ', identifier=str(key),
                                              comments='Orca not returning any accrued for the identifier')
        return hpl

    def _fetch_accrued_interest(self):
        out = {}
        intersection = set(self.acc_interest_d1.keys()).intersection(self.acc_interest_d2.keys())
        for i in intersection:
            out[i] = self.acc_interest_d2[i] - self.acc_interest_d1[i]
        return out

    def _calculate_rtpl(self, forward_pricing=False):
        """
        Calculates the RTPL as the difference between valuation with scenarios and the base valuation. If user chooses
        to calculate with forward pricing, the forwarded eod_date valuation will be used, and the RTPL calculation will
        also be forwarded
        """
        if forward_pricing:
            anchor_date = self.d2
            base_valuation = self._get_forward_prices()[0]
        else:
            anchor_date = self.d1
            base_valuation = self.price_d1
        rtpl_valuation, _ = valuation_service.position_valuation(positions=self.positions,
                                                                 eod_date=self.d1,
                                                                 engine=self.pricing_engine,
                                                                 valuation_date=anchor_date,
                                                                 scenarios=self.scenario_list)
        return self._calculate_pl(base_valuation=base_valuation, pl_valuation=rtpl_valuation)

    def _scenario_valuation_decomp(self, forward_pricing=False, drop_zero_scenarios=True, info=0):
        """
        Calculates the linearly decomposed RTPL (performs valuation by bumping one scenario at a time). Everything is
        stored in a DataFrame. Forward pricing here is implemented similarly to ._calculate_rtpl(). Further, user can
        choose to not save the result for scenarios that has zero impact on the price, by setting drop_zero_scenarios
        to True
        """
        if forward_pricing:
            anchor_date = self.d2
            base_valuation = self._get_forward_prices()[0]
        else:
            anchor_date = self.d1
            base_valuation = self.price_d1

        df = pd.DataFrame()
        for idx, scenario in enumerate(self.scenario_list):
            if info and idx % 10 == 0:
                print("\t Valued %s of %s scenarios" % (idx, len(self.scenario_list)))
            price_this_scenario, _ = valuation_service.\
                position_valuation(positions=self.positions,
                                   eod_date=self.d1,
                                   engine=self.pricing_engine,
                                   scenarios=[scenario],
                                   valuation_date=anchor_date)
            pl_explained_by_scenario = self._calculate_pl(base_valuation=base_valuation,
                                                          pl_valuation=price_this_scenario)
            temp_df = pd.DataFrame([pl_explained_by_scenario], index=['Explained by ' + scenario['name']])
            if drop_zero_scenarios and all([x == 0 for x in temp_df.iloc[0].values]):
                continue
            df = df.append(temp_df)
        return df

    def aggregated_pl_results(self, forward_pricing=False, linear_decomp=False, drop_zero_scenarios=True, info=0):
        """
        The only public method of the PLAttribution class. After constructing a class instance, this method can be
        called to return a DataFrame with PL attribution results.

        Args:
            forward_pricing     (bool):     If true, calculates HPL and RTPL with forward pricing
            linear_decomp       (bool):     If true, calculates the linear decomposition of all provided scenarios used
                                            to calculate RTPL
            drop_zero_scenarios (bool):     If true, ignores in the linear decomposition which has no effect on the
                                            valuation
            info                 (int):     If > 0, prints information to console when running the code
        """
        base_valuation = self._get_forward_prices()[0] if forward_pricing else self.price_d1
        accr_it = self._fetch_accrued_interest()
        hpl_clean = self._calculate_hpl(clean=True, forward_pricing=forward_pricing)
        hpl_dirty = self._calculate_hpl(clean=False, forward_pricing=forward_pricing)
        rtpl = self._calculate_rtpl(forward_pricing=forward_pricing)

        df = pd.DataFrame([base_valuation], index=['Price_Day1'])
        df = df.append(pd.DataFrame([self.price_d2], index=['Price_Day2']))
        df = df.append(pd.DataFrame([accr_it], index=['Accr_int_ch']))
        df = df.append(pd.DataFrame([hpl_clean], index=['HPL_clean']))
        df = df.append(pd.DataFrame([hpl_dirty], index=['HPL_dirty']))
        df = df.append(pd.DataFrame([rtpl], index=['RTPL']))

        if linear_decomp:
            if info:
                print("Calculating linear decomposition of RTPL")
            rtpl_decomp_df = self._scenario_valuation_decomp(forward_pricing=forward_pricing,
                                                             drop_zero_scenarios=drop_zero_scenarios,
                                                              info=info)
            df = df.append(rtpl_decomp_df)

        df = df.transpose()

        df.insert(5, "UnExpPL", df['HPL_clean'] - df['RTPL'])
        df.insert(0, "Day2", self.d2.strftime('%Y-%m-%d'))
        df.insert(0, "Day1", self.d1.strftime('%Y-%m-%d'))
        df.insert(0, "Product", [x.get_product_type_from_mars() for x in df.index])
        df.index = [x.to_tuple() for x in df.index]
        df.insert(0, "Position", df.index)

        return df


if __name__ == '__main__':
    import datetime as dt
    from core.scenario import orca_scenario
    from core.utils import dataframe_helper
    pd.set_option('display.max_rows', 200)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    # eod_date = dt.datetime(2017, 4, 10)
    # positions = position_service.PositionServiceLoader(book_id=6100100, date=eod_date).data
    # scenarios = orca_scenario.generate(risk_factor_list=[],
    #                                    scenario_flow=core.types.ScenarioFlow.ScenarioEngine,
    #                                    eod_date=eod_date,
    #                                    observation_period=core.types.ObservationPeriod.RTPL)
    # PLA = RTPL_Service(positions=positions,
    #                    eod_date=eod_date,
    #                    pricing_engine=core.types.PricingEngine.ORCA,
    #                    scenario_list=scenarios)
    # df_prices = PLA.aggregated_pl_results(forward_pricing=False, linear_decomp=False, drop_zero_scenarios=True, info=1)
    #
    # # This part adds the quantity to the output DataFrame for comparison...
    # quantities = pd.DataFrame([positions]).transpose()
    # quantities.index = [x.to_tuple() for x in quantities.index]
    # quantities.columns = ['Quantity']
    # df_prices = df_prices.join(quantities)
    #
    # # Save output df to excel file on desktop
    # dataframe_helper.output_df_to_excel(dfs=df_prices, sheet_names='PL_attribution')
