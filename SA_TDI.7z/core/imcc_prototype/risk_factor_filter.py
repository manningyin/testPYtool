"""
Risk Factor Filter is a service that filter out all relevant risk factors for a list of trades

Now we are using the orca model factory to filter out all relevant risk factors.

"""

import quantum as qt
from core.risk_factor.factory.credit import credit_helper
from orca.types import ModelConfigurationContext
import core.pricing.model_factory
from core.caching.cache_driver import easy_cache
from core.types._transactions import *
from core.connection import orca_connect
from core.utils.error_handler import track_error
from core.position import position_service


def orca_scenario_name(trade_ids, eod_date):
    """
    The function try to get the corresponding scenario name by using orca model factory


    Args:
        trade_ids          (list of trades):
        eod_date           (datetime.datetime):      eod_date of the pricing, determines base model and position info.

    Returns:
        (list) : a list of scenario names

    Notes:
        Author: g48454
    """
    models = core.pricing.model_factory.ModelFactoryLoader(trade_ids=trade_ids,
                                                           startd=eod_date,
                                                           endd=eod_date).data
    risk_factors = []
    for key in models.keys():
        temp = models[key]
        if type(temp) is list:
            for model_and_leg in temp:
                (model, leg) = model_and_leg
                risk_factors.extend(fetch_risk_factors(model))
        else:
            model = temp
            risk_factors.extend(fetch_risk_factors(model))
    return list(set(risk_factors))


def fetch_risk_factors(model):
    return [name.label for name in qt.getMarketDataScenarioNames(model)]


@easy_cache()
def fetch_risk_factors_for_all_bonds_in_portfolio(portfolio_id,eod_date):
    isins = position_service.isins_in_portfolio(book_ids = portfolio_id, date = eod_date)
    return get_back_risk_factors_from_securities_via_sensitivity(isins,eod_date)


def get_back_risk_factors_from_securities_via_sensitivity(isins, eod_date):
    # ===================================================================================
    # Orca has a sensitivity calculation service to calculate the the sensitivity of the trades.
    # Also can be served as a way to expose risk factors
    # ===================================================================================
    sensitivities = risk_securities(isins, eod_date)
    out = []
    for sens in sensitivities:
        try:
            all_risks = sens[0].result.instrument_risk + sens[0].result.zero_coupon_risk
            for x in all_risks:
                out.append(x.risk_label)
        except:
            continue
    return list(set(out))


def risk_securities(isins, eod_date):
    # should be a vectorized implementation, but currently orca has problem when inputting a list of isins,
    # so decided to do it isin by isin
    req = orca_connect.get_orca_request()

    out = []
    for isin in isins:
        try:
            temp = req.risk_securities(
                    orca_connect.get_orca_timestamp(eod_date),
                    ModelConfigurationContext.make_eod_context(),
                    [isin],
                    []
                ).result()
            out.append(temp)
        except:
            track_error(identifier=isin,comments="ORCA do not get sensitivity back")
            continue
    return out


def risk_trades(trades, eod_date):
    req = orca_connect.get_orca_request()
    out = []
    for trade in trades:
        try:
            spec = orca.types.TradeSpecification([trade.to_orca()])
            temp = req.risk_trades(time_stamp=orca_connect.get_orca_timestamp(eod_date),
                                   model_configuration_name=ModelConfigurationContext.make_eod_context(),
                                   trade_specification=spec,
                                   scenarios=[]).result()
            out += temp
        except:
            track_error(identifier=trade, comments='ORCA failed to return sensitivity')
            continue
    return out


if __name__ == '__main__':
    import datetime as dt
    from pprint import pprint
    from core.pricing import pricing_utils

    #print(fetch_risk_factors_for_all_bonds_in_portfolio(9073, dt.datetime(2017, 4, 10)))
    import os
    from core.types._transactions import TradeIdentifier


    trade_ids = [TradeIdentifier(trade_id='1407797035', source_system='CALYPSO')]
    orca_scenario_name(trade_ids, dt.datetime(2018,10,16))

    isin_list = ['NO0010757925','NO0010811136','NO0010737158','NO0010788904','NO0010730872','NO0010660806','NO0010814403',
                 'NO0010819220','NO0010809932','NO0010459910','NO0010670797','NO0010710080','NO0010638075','NO0010786767',
                 'NO0010702863','NO0010819725','NO0010683634','NO0010646813','NO0010816929','NO0010818321','NO0010816283']
    isin_list = ['USF22797RT78','XS1079786239','XS1278718686','DE000DB7XHP3','XS1075963485','DK0030329818','XS1245292807',
                 'XS1068561098','XS1299724911','FR0012199123','XS1043181269','XS0876682666','DE000A0KAAA7','DE000A14J9N8',
                 'XS1068574828','XS0849517650','XS1190987427','XS1150695192','US46625HJY71','XS1783217067','XS1586367945',
                 'XS1793250041','XS1107291541','FR0010239319','XS1511589605']
    xx = get_back_risk_factors_from_securities_via_sensitivity(isin_list, dt.datetime(2018, 10, 16))
    pprint(xx)

    trade_ids_2 = [SecurityIdentifier(ISIN=x, currency="USD") for x in isin_list]

    trade_ids_3 = [SecurityIdentifier(ISIN='XS0728763938', currency="USD"),
                   TradeIdentifier(trade_id="bad", source_system="INFINITY")]

    trade_ids_4 = [SecurityIdentifier(ISIN='DK0002022078', currency="USD")]
    a = orca_scenario_name(trade_ids_2, dt.datetime(2018, 1, 31))
    pprint(a)
