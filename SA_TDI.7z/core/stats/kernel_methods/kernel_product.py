import numpy as np
from matplotlib import cm
import pandas as pd
import multiprocessing as mp


class Parallel_Kernel(object):
    """
    Class for using Parallel computing. Needed due to OOP.
    """
    def pool_kernel(self, column, column_den, row):
        """
        Function to calculate einstein summation between row and column of two Kernel matrixes for parallel computing
        :param column: Column of values of Kernel Matrix 1 used in numerator of kestimate function
        :param column_den: Column of values of Kernel Matrix 2 used in denominator of kestimate function
        :param row: row of Values of Kernel Matrix 2
        :return: scalar - result of column and row multiplication with results summed up
        """
        return np.einsum('jk, jl -> ', column, row), np.einsum('jk, jl -> ', column_den, row)
        # return np.sum((column * row)), np.sum((column_den * row))


class Kernel(object):
    def __init__(self, **kwargs):
        kwargs = kwargs
    """
    Parent class for Kernel analysis. Currently Gaussian and Epanechnikov Kernels are implemented
    Contains different methods and tools:

    1) Conditional mean and variance for one dimensional data
    2) Conditional mean and variance for two-dimensional data (dates/tenors)
    3) Kernel density estimation for one- and two-dimensional data 
    5) Nadaraya-Watson estimator for obe and two-dimensional data
    6) Product Kernel
    7) Confidence interval for Nadaraya-Watson with flagging outliers

    Initializer is implemented in child classes depending on data passed.
    
    Examples:
    -------

    >>> from mpl_toolkits.mplot3d import Axes3D; import matplotlib.pyplot as plt; import numpy as np
    >>> from random import randrange; from math import cos, sin, log10; from matplotlib import cm
    >>> from core.stats.kernel_methods import kernel_product as kernels

    # 1. KDE estimation for random 1D data with mean=1 and std=2 and bandwidth = 0.5
    >>> data = np.random.normal(1,2,size=1000); grid_pdf = np.arange(-9,10,0.05)
    >>> pdf = kernels.Kernel1D.kde(kernels.Kernel1D(0.6).epanechnikov, data, grid_pdf) # Creating pdf using 1D child class

    # 2. KDE estimation for random 2D data with mean=[1,1] and std=[2,2] and bandwidth = [0.5, 0.6]
    >>> data = np.random.normal([1, 1], [2, 2], size=(10000, 2)) # generating two datasets
    >>> x = data[:, 0]; y = data[:, 1]; ndata = len(x); bandwidths = [1, 1] # Prepreparing data
    >>> xgrid = np.mgrid[-7:7:50j]; ygrid = np.mgrid[-7:7:50j]; grid = np.array([xgrid, ygrid]) # creating two grids
    >>> kernel_obj = kernels.KernelND(bandwidths).epanechnikov(data.T)(grid) # Getting kernel on 2-D data
    >>> my_product = kernels.KernelND.makeproduct(kernel_obj); my_product = 1 / ndata * my_product # Applying Density

    # 3. Conditional mean and variance for 1D data with bandwidth 0.6
    >>> data_1D = np.zeros(10000); data_1D[0] = 0 # Random data generation
    >>> for t in range(1, 10000):
    ...  eps = np.random.normal(0, 1)
    ...  if data_1D[t-1] < 0:
    ...     data_1D[t] = 0.8 * data_1D[t-1] + 1.5 + eps
    ...  else:
    ...     data_1D[t] = -0.8 * data_1D[t-1] + eps
    >>> grid_1D = np.sort(data_1D)[100:-100:10] # Creating grid based on data
    >>> dataout = data_1D[1:] # Creating "current data", which is conditional on itself t-1
    >>> mn_1D = kernels.Kernel1D.cond_mean(kernels.Kernel1D(0.6).gaussian, dataout, data_1D[:-1], grid_1D) # Mean
    >>> var_1D = kernels.Kernel1D.cond_variance(kernels.Kernel1D(0.6).gaussian, dataout, data_1D[:-1], grid_1D) #Var

    # 4. Conditional mean and variance for 2D data
    >>> sample = 10000; x = np.zeros(sample); y = np.zeros(sample)  # Generating random data with some model
    >>> for t in range(1, sample):
    ...    np.random.seed(t); eps = np.random.normal(0, 1); np.random.seed(t); randint = [-1, 1][randrange(2)]
    ...    if t < sample / 2:
    ...        x[t] = (log10(t + 1) * 2 + eps) * randint
    ...    else:
    ...        x[t] = (log10(sample - t) * 2 + eps) * randint
    ...    y[t] = np.sqrt(1 + x[t - 1] ** 2 + abs(y[t - 1])) + eps
    >>> gridx = np.sort(x)[100:-100:100]; gridy = np.sort(y)[100:-100:100]
    >>> bandwidths = [0.5, 0.5]; ndata = len(x) # Preparing smoothing parameter
    >>> xx, yy = np.meshgrid(gridx, gridy) # meshgrid for further plotting
    >>> data = np.array([x[:-1], y[:-1]])  # making data in necessary format (each column is separate data/dimension)
    >>> dataout = y[1:] # 1-dimensional array, e.g. it is conditional on data above
    >>> grid = np.array([gridx, gridy]) # Preparing grid in correct format. Each row is a own grid for data/dimension
    >>> mn = kernels.KernelND.cond_mean(kernels.KernelND(bandwidths).gaussian, dataout, data, grid) # Get Mean
    >>> var = kernels.KernelND.cond_variance(kernels.KernelND(bandwidths).gaussian, dataout, data, grid) # Get Variance

    # 5a) Nadaraya-Watson regression of `x` on `y`.
    #     Estimate `g` in `y=g(x) + noise`.

    >>> samplesize_1 = 100; bw_1 = 0.5
    >>> x_1 = np.empty(samplesize_1); y_1 = np.empty(samplesize_1)
    >>> timegrid_1 = np.array(range(0, samplesize_1))
    >>> for t in timegrid_1: # Creating model cox(x)*2 + random
    ...  eps_1 = np.random.normal(0, 2)
    ...  x_1[t] = np.random.normal(0, 2)
    ...  y_1[t] = x_1[t]**2 * np.cos(x_1[t]) + eps_1
    >>> xgrid_1 = np.mgrid[min(x_1):max(x_1):200j]
    >>> nw_1, kernel = kernels.Kernel1D.nadaraya_watson(kernels.Kernel1D(bw_1).gaussian, y_1, x_1) # getting N-W estim.
    >>> confmax, confmin, flags = kernels.Kernel1D.nw_confidence_intervals(y_1, nw_1, kernel, 0.95)

    # 5b) Nadaraya-Watson estimate for time series (smoothing).
    #     Estimate `g` in `y=g(time) + noise`.

    >>> samplesize_2 = 200; bw_2 = 8
    >>> y_2 = np.empty(samplesize_2)
    >>> time = np.arange(samplesize_2)
    >>> for t in time: # full cosine period plus Gaussian noise.
    ...   eps = np.random.normal(0, 2)
    ...   y_2[t] = 2*np.cos(2*np.pi*t/samplesize_2) + eps
    >>> tgrid = np.mgrid[min(time):max(time):400j]
    >>> nw_2, kernel2 = kernels.Kernel1D.nadaraya_watson(kernels.Kernel1D(bw_2).gaussian, y_2, time)
    >>> confmax2, confmin2, flags2 = kernels.Kernel1D.nw_confidence_intervals(y_2, nw_2, kernel2, 0.95)

    # Plotting all results and routines from all examples results
    # Example 1 (KDE 1D)
    >>> a = plt.plot(grid_pdf, pdf); a = plt.title('Random Normal 1D. Kernel1D.kde function'); a= plt.grid(); a = plt.show()

    # Example 2 (KDE 2D)
    >>> fig = plt.figure(); ax = fig.gca(projection='3d') # Plotting KDE.
    >>> xx_kde, yy_kde = np.meshgrid(xgrid, ygrid, indexing='ij')
    >>> a = ax.plot_surface(xx_kde, yy_kde, my_product, cmap=cm.coolwarm, rstride=1, cstride=1, linewidth=0)
    >>> a = plt.title('KDE 2D data'); a = plt.grid(); a = plt.show()

    # Example 3 (Conditional mean and variance 1D)
    >>> a = plt.plot(data_1D[:-1], data_1D[1:], '.', label='Data')
    >>> a = plt.plot(grid_1D, mn_1D, '.',  label='Mean'); a = plt.plot(grid_1D, var_1D, '.',  label='Variance')
    >>> a = plt.title('Cond mean and variance lag 1'); a = plt.legend(); a = plt.grid(); a = plt.show()

    # Example 4 (Conditional mean and variance 2D)
    >>> fig = plt.figure(figsize=plt.figaspect(0.5))
    >>> ax = fig.add_subplot(1, 2, 1, projection='3d')
    >>> surf = ax.plot_surface(xx, yy, mn, cmap=cm.coolwarm, linewidth=0, antialiased=False, label = 'Mean')
    >>> surf._facecolors2d=surf._facecolors3d; surf._edgecolors2d=surf._edgecolors3d
    >>> a = plt.xlabel("x grid"); a = plt.ylabel("y grid"); a= ax.set_zlabel('Y'); a = plt.legend()
    >>> a = plt.title('Conditional Mean')
    >>> ax = fig.add_subplot(1, 2, 2, projection='3d')
    >>> surf2= ax.plot_surface(xx, yy, var, cmap=cm.coolwarm, linewidth=0, antialiased=False, label = 'Var')
    >>> surf2._facecolors2d=surf2._facecolors3d
    >>> surf2._edgecolors2d=surf2._edgecolors3d
    >>> a = plt.xlabel("x grid"); a = plt.ylabel("y grid"); a = ax.set_zlabel('Y'); a = plt.legend()
    >>> a = plt.title('Conditional Variance'); a= plt.show()

    # Examples 5a and 5b (Nadaraya-Watson estimator)
    >>> f = plt.figure(); a = plt.subplot(2, 1, 1); a = plt.plot(x_1, y_1, 'o')
    >>> a = plt.plot(x_1, nw_1, label = 'Nadaraya-Watson estimator, Bandwidth: {}.'.format(bw_1))
    >>> plt.plot(x_1, confmax, label='Max conf' )
    >>> plt.plot(x_1, confmin, label='Min conf')
    >>> plt.plot(x_1[flags], y_1[flags], '-or', linestyle='None', label='Outliers')
    >>> a = plt.legend(); a = plt.xlabel('x'); a = plt.ylabel('y = g(x) + noise')
    >>> a = plt.subplot(2, 1, 2); a = plt.plot(time, y_2, 'o')
    >>> a = plt.plot(time, nw_2, label = 'Nadaraya-Watson estimator, bandwidth: {}.'.format(bw_2))
    >>> plt.plot(time, confmax2, label='Max conf' )
    >>> plt.plot(time, confmin2, label='Min conf')
    >>> plt.plot(time[flags2], y_2[flags2], '-or', linestyle='None', label='Outliers')
    >>> a = plt.legend(); a = plt.xlabel('time'); a = plt.ylabel('y = g(time) + noise'); a = plt.show()
    >>> f.savefig("C:\Working\TS outlier detection\LaTex Doc\\95conf.pdf", bbox_inches='tight')

    Author:
            G46474, G02229 (Joerg Wegener, Alex Murzin)
    """

    @classmethod
    def kde(cls, kfunc, data, grid_size_X = 0.01, grid_size_Y = 0.1, multiplier = 0.2) -> np.array:
        """
        Function for estimating KDE using gaussian kernel. Returns 1D or ND nd.array of density estimates.
        :param kfunc: (:class: `handle`) Kernel(bandwidth).gaussian -- function handle: no data yet
        :param data: (:class: `nd.array`,'time-series', 'pd DataFrame') Data values (rates, prices, tenors, days, etc.)
        in form of 1D (m, 1) or ND (m, k) objects, where each row (m) is value (with or without time index). k signifies
        number of columns (for example Tenors with values).
        :param grid_size_X: (:class: `float`) - number between 0 and 1. 0.01 represents % of input Data size on X-dimension
        (e.g. days, rates), meaning in case of 0.01 that there will be 100 points in grid. for 0.02 there will be 50 grid points. Optional argument
        :param grid_size_Y: (:class: `float`) - number between 0 and 1. Represents % of input Data size on Y-dimension
        (e.g. Tenors), meaning in case of 0.1 that there will be 10 equidistant points in grid. Optional argument
        :param multiplier: (:class: `float`) - number between 0 and 1 meaning that grid will be extended left and right by formula:
        (max(data) - min(data)) * multiplier. Needed to correctly plot density (should converge to 0 in sides).
        :return: (:class: `np.array`) array of Density Estimate evaluated on each grid cell. Depending on format of data
        and grid, output can be one- (1 ,n) or multi-dimensional (p, n) where n and p are lengths of ingrid.
        ingrid: grid built on data for possible plotting if necessary
        """
        indata = cls._getindata(cls, data, density=True)
        ingrid = cls._getgrid(cls, indata, grid_size_X = grid_size_X, grid_size_Y = grid_size_Y, multiplier = multiplier, density = True)
        kernel = kfunc(indata)(ingrid)

        if 'ND' in str(kfunc):
            ndata = len(indata[0])
            return 1 / ndata * cls.kde_kestimate(kernel, est_num=1), ingrid
        else:
            ndata = np.size(indata)
            return 1 / ndata * cls.kestimate(kernel, est_num=1), ingrid

    @classmethod
    def cond_mean(cls, kfunc, data, grid_size_X = 0.01, grid_size_Y = 0.05, parallel = False) -> np.array:
        """
        Conditional mean: E(Y_t | X_t-1 = x_t-1).
        Function calculating conditional mean. kfunc specifies type of kernel applied and bandwidth to use
        :param kfunc: (:class: `handle`) Kernel(bandwidth).gaussian -- function handle: no data yet
        :param data: (:class: `nd.array`,'time-series', 'pd DataFrame') Data values (rates, prices, tenors, days, etc.)
        in form of 1D (m, 1) or ND (m, k) objects, where each row (m) is value (with or without time index). k signifies
        number of columns (for example Tenors with values).
        :param grid_size_X: (:class: `float`) - number between 0 and 1. 0.01 represents % of input Data size on X-dimension
        (e.g. days, rates), meaning in case of 0.01 that there will be 100 points in grid. for 0.02 there will be 50 grid points. Optional argument
        :param grid_size_Y: (:class: `float`) - number between 0 and 1. Represents % of input Data size on Y-dimension
        (e.g. Tenors), meaning in case of 0.1 that there will be 10 equidistant points in grid. Optional argument
        :return: (:class: `np.array`) array of Mean values, evaluated on each grid cell. Depending on format of input,
        output can be one (1, n) or two-dimensional (p, n), where n and p are lengths of ingrid.
        ingrid: grid built on data for possible plotting if necessary
        """
        indata = cls._getindata(cls, data)

        if len(np.shape(data)) == 2:
            indata[0] = np.repeat(indata[0], np.shape(data)[1])
            indata[1] = np.tile(indata[1], (1, int(np.size(data) / np.shape(data)[1]))).squeeze()

        ingrid = cls._getgrid(cls, indata, grid_size_X=grid_size_X,  grid_size_Y = grid_size_Y)
        kernel = kfunc(indata)(ingrid)

        if 'ND' in str(kfunc):
            ndata = len(indata[0])

            if isinstance(data, pd.DataFrame):
                data_to_func = data.values.flatten()
            else:
                data_to_func = data.flatten()

            return ndata / (ndata - 1) * cls.kde_kestimate(kernel, est_num = data_to_func, est_denom = 1), ingrid

        else:
            ndata = len(data)
            return ndata / (ndata - 1) * cls.kestimate(kernel, est_num = data, est_denom = 1, parallel = False), ingrid

    @classmethod
    def cond_variance(cls, kfunc, data, grid_size_X = 0.01, grid_size_Y = 0.05, parallel = False) -> np.array:
        """
        Conditional variance: E(X^2_t|X_t-i=x_t-i) - [E(X_t | X_t-i=x_t-i)]^2.
        Function calculating conditional variance.
        Same as :func:`cond_mean`
        :return: (:class: `np.array`) array of Variance values, evaluated on each grid cell. Depending on format of input,
        output can be one (1, n) or two-dimensional (p, n), where n and p are lenghts of grids.
        ingrid: grid built on data for possible plotting if necessary
        """
        indata = cls._getindata(cls, data)

        if len(np.shape(data)) == 2:
            indata[0] = np.repeat(indata[0], np.shape(data)[1])
            indata[1] = np.tile(indata[1], (1, int(np.size(data) / np.shape(data)[1]))).squeeze()

        ingrid = cls._getgrid(cls, indata, grid_size_X = grid_size_X, grid_size_Y = grid_size_Y)
        kernel = kfunc(indata)(ingrid)

        if 'ND' in str(kfunc):
            ndata = len(indata[0])
            if isinstance(data, pd.DataFrame):
                data_to_func = data.values.flatten()
            else:
                data_to_func = data.flatten()

            x2 = cls.kde_kestimate(kernel, est_num=np.square(data_to_func), est_denom=1)
            xmn = cls.kde_kestimate(kernel, est_num=data_to_func, est_denom=1)

        else:
            ndata = len(data)
            x2 = cls.kestimate(kernel, est_num = np.square(data), est_denom = 1, parallel = False)
            xmn = cls.kestimate(kernel, est_num = data, est_denom = 1, parallel = False)

        return ndata / (ndata - 1) * x2 - np.square(xmn), ingrid

    @classmethod
    def skeweness(cls, kfunc, data, grid_size_X = 0.01, grid_size_Y = 0.05, parallel = False) -> np.array:
        """
        Skeweness: E(X^3_t|X_t-i=x_t-i)
        Function calculating third moment. kfunc specifies type of kernel applied and bandwidth to use
        Same as :func:`cond_mean`
        :return: (:class: `np.array`) array of Skeweness values, evaluated on each grid cell. Depending on format of input,
        output can be one (1, n) or two-dimensional (p, n), where n and p are lenghts of grids.
        ingrid: grid built on data for possible plotting if necessary
        """
        indata = cls._getindata(cls, data)

        if len(np.shape(data)) == 2:
            indata[0] = np.repeat(indata[0], np.shape(data)[1])
            indata[1] = np.tile(indata[1], (1, int(np.size(data) / np.shape(data)[1]))).squeeze()

        ingrid = cls._getgrid(cls, indata, grid_size_X = grid_size_X, grid_size_Y = grid_size_Y)
        kernel = kfunc(indata)(ingrid)

        if 'ND' in str(kfunc):
            ndata = len(indata[0])
            if isinstance(data, pd.DataFrame):
                data_to_func = data.values.flatten()
            else:
                data_to_func = data.flatten()
            num = (1/ndata) * cls.kde_kestimate(kernel, est_num=data_to_func**3, est_denom=np.nan)
            denom = ((1/(ndata-1)) * cls.kde_kestimate(kernel, est_num=data_to_func**2, est_denom=np.nan))**(3/2)

        else:
            ndata = len(data)
            num = (1/ndata) * cls.kestimate(kernel, est_num = data**3, est_denom = np.nan, parallel = False)
            denom = ((1/(ndata-1)) * cls.kestimate(kernel, est_num = data**2, est_denom = np.nan, parallel = False))**(3/2)

        return num/denom, ingrid

    @classmethod
    def kurtosis(cls, kfunc, data, grid_size_X = 0.01, grid_size_Y = 0.05, parallel = False) -> np.array:
        """
        Kurtosis: E(X^4_t|X_t-i=x_t-i)
        Function calculating fourth moment. kfunc specifies type of kernel applied and bandwidth to use
        Same as :func:`cond_mean`
        :return: (:class: `np.array`) array of Kurtosis values, evaluated on each grid cell. Depending on format of input,
        output can be one (1, n) or two-dimensional (p, n), where n and p are lenghts of grids.
        ingrid: grid built on data for possible plotting if necessary
        """
        indata = cls._getindata(cls, data)

        if len(np.shape(data)) == 2:
            indata[0] = np.repeat(indata[0], np.shape(data)[1])
            indata[1] = np.tile(indata[1], (1, int(np.size(data) / np.shape(data)[1]))).squeeze()

        ingrid = cls._getgrid(cls, indata, grid_size_X = grid_size_X, grid_size_Y = grid_size_Y)
        kernel = kfunc(indata)(ingrid)

        if 'ND' in str(kfunc):
            ndata = len(indata[0])
            if isinstance(data, pd.DataFrame):
                data_to_func = data.values.flatten()
            else:
                data_to_func = data.flatten()
            num = (1 / ndata) * cls.kde_kestimate(kernel, est_num=data_to_func ** 4, est_denom=np.nan)
            denom = ((1 / ndata) * cls.kde_kestimate(kernel, est_num=data_to_func ** 2, est_denom=np.nan))**2

        else:
            ndata = len(data)
            num = (1 / ndata) * cls.kestimate(kernel, est_num=data ** 4, est_denom=np.nan, parallel=False)
            denom = ((1 / ndata) * cls.kestimate(kernel, est_num=data ** 2, est_denom=np.nan, parallel=False))**2

        return num / denom - 3, ingrid

    @classmethod
    def nadaraya_watson(cls, kfunc, data, parallel = False) -> np.array:
        """
        Nadaraya-Watson estimator of `g` in `y = g(x) + noise`. See auxiliary function _nadaraya_watson
        https://stats.stackexchange.com/questions/125517/what-is-nadaraya-watson-kernel-regression-estimator-for-multivariate-response
        :param data: Same as :func:`cond_mean`
        :param parallel: (:class: `boolean`): True/False - parallel computing used/not used.
        :return: (:class:`np.array`) Estimator of `g`. Shape of `g` is either (1, n), (n, p) for of 1D input,
        and rectangular grid respectively. n is length of time series (days, rows), p - length of columns (e.g. Tenors)
        and child class used.
        ingrid: grid built on data for possible plotting if necessary
        """
        indata = cls._getindata(cls, data)

        if type(indata) is list:
            ingrid = cls._getgrid(cls, indata, grid_size_X = 1/np.size(indata[0]), grid_size_Y = 1/np.size(indata[1]))
        else:
            ingrid = cls._getgrid(cls, indata, grid_size_X=1 / np.size(indata))

        nw, kernel = cls._nadaraya_watson(cls, kfunc, data, indata, ingrid, parallel = parallel)
        return nw, kernel, ingrid

    def _nadaraya_watson(cls, kfunc, raw_data, indata, ingrid, parallel = False) -> np.array:
        """
        auxiliary function. Estimates Kernel matrix and make calculations
        :return: (:class:`np.array`) Estimator of `g`. Shape of `g` is either (1, n), (n, p) for of 1D input,
        and rectangular grid respectively. n is length of time series (days, rows), p - length of columns (e.g. Tenors)
        and child class used.
        """
        kernel = kfunc(indata)(ingrid)
        n = np.size(raw_data)
        return n / (n - 1) * cls.kestimate(kernel, raw_data, est_denom = 1, parallel = parallel), kernel


    def _getgrid(cls, indata, grid_size_X = 0.01, grid_size_Y = 0.05, multiplier = 0, density = False):
        """
        Grid creation function from the input data. Can handle all input formats. In case no dates passed, creates
        artifical grid by assigning integers for each row. Similar approach done for columns for 2D data (e.g. Tenors).
        :param indata: (:class: `nd.array`,'time-series', 'pd DataFrame') Data values (rates, prices, tenors, days, etc.)
        in form of 1D (m, 1) or ND (m, k) objects, where each row (m) is value (with or without time index). k signifies
        number of columns (for example Tenors with values).
        :param grid_size_X: (:class: `float`) - number between 0 and 1. 0.01 represents % of input Data size on X-dimension
        (e.g. days, rates), meaning in case of 0.01 that there will be 100 points in grid. for 0.02 there will be 50 grid points. Optional argument
        :param grid_size_Y: (:class: `float`) - number between 0 and 1. Represents % of input Data size on Y-dimension
        (e.g. Tenors), meaning in case of 0.1 that there will be 10 equidistant points in grid. Optional argument
        :param multiplier: (:class: `float`) - number between 0 and 1 meaning that grid will be extended left and right by formula:
        (max(data) - min(data)) * multiplier. Needed to correctly plot density (should converge to 0 in sides). Optional argument
        :param density: (:class: `boolean`) - True if KDE grid is needed as it is built on rates (values). False for other methods
        as grid is estimated on days (ordinal). False is default.
        :return: (:class:`np.array` or 'list) - array of grid points is returns when 1D input is passed. List is returned
        when 2D data passed, where first list element is grid on dates (or rates if density is True), and second is integers for columns (e.g. Tenors)
        """
        n_data = len(indata)

        if type(indata) is not list and not isinstance(indata, pd.DataFrame):
            n_data = len(indata)
            extension = (max(indata) - min(indata)) * multiplier
            ingrid = np.mgrid[min(indata) - extension:max(indata) + extension: 1j/(n_data/n_data*grid_size_X)+0.0000000000005j]
        else:
            ingrid = []
            if density:
                try:
                    n_cols = indata.columns.size
                    set_x = indata.values
                except:
                    n_cols = max(indata[1])
                    set_x = indata[0]
                extension_X = (np.max(set_x) - np.min(set_x)) * multiplier
                set_y = np.linspace(1, n_cols, n_cols)
                extension_Y = (max(set_y) - min(set_y)) * multiplier
            else:
                n_cols = 1
                set_x = indata[0]
                extension_X = (max(set_x) - min(set_x)) * multiplier
                set_y = indata[1]
                extension_Y = (max(set_y) - min(set_y)) * multiplier

            ingrid.append(np.mgrid[np.min(set_x) - extension_X :np.max(set_x) + extension_X: 1j/(n_data/n_data*grid_size_X)])
            ingrid.append(np.mgrid[min(set_y) - extension_Y :max(set_y) + extension_Y: 1j/(n_cols/n_cols*grid_size_Y)])

        return ingrid

    def _getindata(cls, indata, density = False):
        """
        Data preprocessor function for using data in downstream calculations.
        :param indata: (:class: `nd.array`,'time-series', 'pd DataFrame') Data values (rates, prices, tenors, days, etc.)
        in form of 1D (m, 1) or ND (m, k) objects, where each row (m) is value (with or without time index). k signifies
        number of columns (for example Tenors with values).
        :param density: (:class: `boolean`) - True if KDE grid is needed as it is built on rates (values). False for other methods
        as grid is estimated on days (ordinal)
        :return: (:class:`np.array` or 'list) - object with data to evaluate on grid. List is returned if 2D input is passed.
        """
        data = []
        if isinstance(indata, pd.core.series.Series):
            if density:
                data = indata.values
            else:
                try:
                    data = np.array([i.toordinal() for i in indata.index])
                except:
                    data = np.linspace(1, len(indata), len(indata))

        elif isinstance(indata, pd.DataFrame):
            n_cols = indata.columns.size
            if density:
                data.append(indata.values.flatten())
                data.append(np.tile(np.linspace(1, n_cols, n_cols), (1, int(np.size(indata) / n_cols))).squeeze())
            else:
                data.append([i.toordinal() for i in indata.index])
                data.append(np.linspace(1, n_cols, n_cols))

        elif density:
            if len(np.shape(indata)) == 2:
                n = np.shape(indata)[1]
                data.append(indata.flatten())
                data.append(np.tile(np.linspace(1, n, n), (1, int(np.size(indata) / n))).squeeze())
            else:
                data = indata

        elif len(np.shape(indata)) == 2:
            n_cols = np.shape(indata)[1]
            data.append(np.linspace(1, len(indata), len(indata)))
            data.append(np.linspace(1, n_cols, n_cols))
        else:
            data = np.arange(len(indata))

        return data


    @classmethod
    def nw_confidence_intervals(cls, raw_ts, nw, kernel, conf) -> np.array:
        """
        Function calculating confidence interval for nadaraya-watson estimatior.
        :param raw_ts: (:class: `np.array, 'pd.DataFrame or 'time series')
        :param nw: (:class: `np.array`) Nadaraya-Watson estimator - result of execution function nadaraya_watson
        :param kernel: (:class: `np.array`) Kernel matrix of pointwise estimation - output of nadaraya_watson function
        :param conf: (:class: `float`) Confidence interval for bands. 0.995 by default
        :return: (:class: `np.array`) Upper and lower confidence intervals the same size as input - nw.
        Boolean arrays the same size as input - nw.
        """
        import scipy.stats
        if isinstance(raw_ts, pd.DataFrame):
            outdata = raw_ts.values.flatten()
            raw_ts = raw_ts.values
        else:
            try:
                outdata = raw_ts.flatten()
            except:
                outdata = raw_ts
        nin = outdata.size
        if len(np.shape(nw)) ==1:
            u = outdata.T[:, None] - nw.T[None, :]
            var = np.sum(u ** 2, axis=0) / nin
        else:
            u = outdata.T[None, None, :] - nw[:, :, None]
            var = np.einsum('ijk, ijk -> ij', u, u) / nin
        bandwidth = cls.bandwidth

        if cls.type == 'gaussian': # Coefficient calculation
            constant = 1 / (2*np.sqrt(np.pi)*np.prod(bandwidth))
        else:
            constant = 3/(5*np.prod(bandwidth))
        sterror = np.sqrt((constant*var) / (cls.kestimate(kernel, est_num = 1, est_denom = np.nan, parallel = False))) # Standard error calculation
        coeff = scipy.stats.norm.ppf(conf)
        confmax = nw + sterror*coeff
        confmin = nw - sterror*coeff
        return confmax, confmin, (raw_ts > confmax) | (raw_ts < confmin)


class Kernel1D(Kernel):
    """
    Child class with functions applicable to One dimensional kernel functions and related functionality.
    Initializer creates object, assignes bandwidth.

     :param bandwidth: (:class: `float` or `list`) smoothing parameter for gaussian Kernel. Corresponds to ST.D.
     For multi-dimensional data, `list` is passed of size (1, k)
    Author:
        G02229 (Alex Murzin)
    """

    def __init__(self, bandwidth):
        self.bandwidth = bandwidth
        Kernel1D.bandwidth = bandwidth

    def gaussian(self, data):
        """
        Function returning handle to Gaussian Kernel. Bandwidth is given when invoking the class object
        :param data: (:class: `np.array`) one dimensional array of data of shape (1, m)
        :return: (:class: `handle`) function handle to setgrid function
        """
        h = self.bandwidth  # corresponds to standard deviation
        Kernel1D.type = 'gaussian'
        def setgrid(grid: np.array) -> np.array:
            """
            Function returning kernel of data evaluated on each grid point using Gaussian Kernel
            :param grid: (:class: `np.array`) min(data) <= grid <= max(data). Grid for data evaluation of shape (1, n)
            :return: k: (:class: `np.array`) matrix - result of evaluation of data on each grid point of shape (1, n)
            """
            ngrid = len(np.array([grid]))
            if np.isscalar(data):
                u = grid - data
            else:
                grid = grid.reshape(ngrid, -1)
                u = grid.T[:, None] - data.T[None, :]
            u = np.squeeze(u)
            k = 1 / (np.sqrt(2 * np.pi) * h) * np.exp(-np.square(u / h) / 2)
            return k
        return setgrid

    def epanechnikov(self, data):
        """
        Function returning handle to Epanechnikov Kernel. Bandwidth is given when invoking the class object
        :param data: (:class: `np.array`) one dimensional array of data of shape (1, m)
        :return: setgrid: (:class: `handle`) function handle to setgrid function
        """
        h = self.bandwidth
        Kernel1D.type = 'epanechnikov'
        def setgrid(grid: np.array) -> np.array:
            """
            Function returning kernel of data evaluated on each grid point using Epanechnikov Kernel
            :param grid: (:class: `np.array`) min(data) <= grid <= max(data). Grid for data evaluation of shape (1, n)
            :return: k: (:class: `np.array`) matrix - result of evaluation of data on each grid point of shape (1, n)
            """
            ngrid = len(np.array([grid]))

            if np.isscalar(data):
                u = (grid - data)/h
            else:
                grid = grid.reshape(ngrid, -1)
                u = (grid.T[:, None] - data.T[None, :])/h
            u = np.squeeze(u)
            k = 0.75/h  * (1 - u**2) * (abs(u) <= 1)
            return k
        return setgrid

    def rectangular(self, data):
        """
        Function returning handle to Rectangular Kernel. Bandwidth is given when invoking the class object
        :param data: (:class: `np.array`) one dimensional array of data of shape (1, m)
        :return: setgrid: (:class: `handle`) function handle to setgrid function
        """
        h = self.bandwidth
        Kernel1D.type = 'rectangular'
        def setgrid(grid: np.array) -> np.array:
            """
            Function returning kernel of data evaluated on each grid point using Rectangular Kernel
            :param grid: (:class: `np.array`) min(data) <= grid <= max(data). Grid for data evaluation of shape (1, n)
            :return: k: (:class: `np.array`) matrix - result of evaluation of data on each grid point of shape (1, n)
            """
            ngrid = len(np.array([grid]))
            if np.isscalar(data):
                u = (grid - data)/h
            else:

                grid = grid.reshape(ngrid, -1)
                u = (grid.T[:, None] - data.T[None, :])/h
            u = np.squeeze(u)
            k = 1/(2*h) * (abs(u) <= 1)
            return k
        return setgrid

    @staticmethod
    def kestimate(kernel, est_num = np.nan, est_denom = np.nan, parallel = False) -> np.array:
        """
        Function for kernel estimation. Summing over rows of kernel matrix is performed either for kernel matrix itself,
        or after multiplication by estimator (current data) depending whether kde, mean of rariance is estimated.
        :param kernel: (:class: `np.array`)  Matrix of points evaluated on each grid point using kernel function of
        shape (n, m)
        :param estimator: (:class: `np.array`) current data 1D np.array to multiply by kernel matrix of shape (1, m)
        :return: res: (:class: `np.array`) result of multiplication of Matrix by estimator and following row summation
        of shape (1, n)
        """
        x = est_num
        y = est_denom

        if x is 1:  # common use case, e.g. kernel density estimate. For speed-up & DRY.
            output = np.sum(kernel, axis=1)
        else:
            output = np.dot(x, kernel.transpose())
        if y is 1:
            output_den = np.sum(kernel, axis=1)  # summing along rows -- with constant grid value.
        else:
            output_den = np.dot(y, kernel.transpose())

        if x is np.nan: output = 1
        if y is np.nan: output_den = 1

        return output/output_den


class KernelND(Kernel):
    """
        Child class with functions applicable to multi-dimensional data.
        Initializer creates object, assignes bandwidth.

        :param bandwidth: (:class: `list`) bandwidth (smoothing parameter) for data. Each element of a list corresponds
        to separate data-set passed. Shape(1, k)

        Author:
            G02229 (Alex Murzin)
        """
    def __init__(self, bandwidth):
        self.bandwidth = bandwidth
        KernelND.bandwidth = bandwidth

    def gaussian(self, data):
        """
        Function returning handle to Gaussian Kernel. Bandwidth is given when invoking the class object
        :param data: (:class: `np.array`) multi-dimensional array of data of size (k, m)
        :return: setgrid: (:class: `handle`) function handle to setgrid
        """
        h = self.bandwidth  # corresponds to standard deviation
        KernelND.type = 'gaussian'
        def setgrid(grid: np.array):
            """
            Function returning kernel of data evaluated on each grid point using Gaussian Kernel
            :param grid: (:class: `np.array` or `list`). Possible shapes - array(k, n), - list(k, (1, n), (1, p))
            for square and rectangular grids respectively.
            :return: k: (:class: `np.array`)
             nd.array (k, n, m) or list (k, (n, m), (p,m)) - result of evaluation of
            data on each grid point.
            """

            if len(np.shape(grid)) == 1 or type(grid) == list or type(data) == list:
                u = []; k = []
                for i in range(len(grid)):
                    try:
                        if np.isscalar(grid[0]):
                            u.append(np.array(grid[i]) - data[i])
                        else:
                            u.append(np.array(grid[i])[:, None] - data[i][None, :])
                    except:
                        u.append(np.array(grid[i])[:, None] - data[i])
                    try:
                        k.append(1 / (np.sqrt(2 * np.pi) * h[i]) * np.exp(-np.square(u[i] / np.array(h)[i]) / 2))
                    except:
                        a = 1
            else:
                h_ = np.array(h)[:, None, None]
                u = grid[:, :, None] - data[:, None, :]
                k = 1/(np.sqrt(2*np.pi) * h_) * \
                    np.exp(-np.square(u / h_)/2)

            return k
        return setgrid

    def epanechnikov(self, data) -> np.array:
        """
        Function returning handle to Epanechnikov Kernel. Bandwidth is given when invoking the class object
        :param data: (:class: `np.array`) multi-dimensional array of data of size (k, m)
        :return: setgrid: (:class: `handle`) function handle to setgrid
        """
        h = self.bandwidth
        KernelND.type = 'epanechnikov'
        def setgrid(grid: np.array) -> np.array:
            """
            Function returning kernel of data evaluated on each grid point using Epanechnikov Kernel
            :param grid: (:class: `np.array` or `list`). Possible shapes - array(k, n), - list(k, (1, n), (1, p))
            for square and rectangular grids respectively.
            :return: k: (:class: `np.array`) nd.array (k, n, m) or list (k, (n, m), (p,m)) - result of evaluation of
            data on each grid point.
            """

            if len(np.shape(grid)) == 1 or len(np.shape(data)) == 1 or type(grid) == list or type(data) == list:
                u = []; k = []

                for i in range(len(grid)):

                    try:
                        if np.isscalar(grid[0]):
                            u.append((np.array(grid[i]) - np.array(data[i]))/h[i])
                        else:
                            u.append((np.array(grid[i])[:, None] - np.array(data[i])[None, :])/h[i])
                    except:
                        u.append((np.array(grid[i])[:, None] - np.array(data[i]))/h[i])
                    k.append(0.75 / h[i] * (1 - u[i] ** 2) * (abs(u[i]) <= 1))
            else:
                h_ = np.array(h)[:, None, None]
                u = (grid[:, :, None] - data[:, None, :])/ h_  # To fix here to work with lists.
                k = 0.75 / h_ * (1 - u**2) * (abs(u) <= 1)
            return k
        return setgrid

    def rectangular(self, data) -> np.array:
        """
        Function returning handle to rectangular Kernel. Bandwidth is given when invoking the class object
        :param data: (:class: `np.array`) multi-dimensional array of data of size (k, m)
        :return: setgrid: (:class: `handle`) function handle to setgrid
        """
        h = self.bandwidth
        KernelND.type = 'rectangular'
        def setgrid(grid: np.array) -> np.array:
            """
            Function returning kernel of data evaluated on each grid point using rectangular Kernel
            :param grid: (:class: `np.array` or `list`). Possible shapes - array(k, n), - list(k, (1, n), (1, p))
            for square and rectangular grids respectively.
            :return: k: (:class: `np.array`) nd.array (k, n, m) or list (k, (n, m), (p,m)) - result of evaluation of
            data on each grid point.
            """

            if len(np.shape(grid)) == 1 or len(np.shape(data)) == 1 or type(grid) == list or type(data) == list:
                u = []; k = []

                for i in range(len(grid)):

                    try:
                        if np.isscalar(grid[0]):
                            u.append((np.array(grid[i]) - np.array(data[i]))/h[i])
                        else:
                            u.append((np.array(grid[i])[:, None] - np.array(data[i])[None, :])/h[i])
                    except:
                        u.append((np.array(grid[i])[:, None] - np.array(data[i]))/h[i])
                    k.append(1/ (2*h[i]) * (abs(u[i]) <=1))

            else:
                h_ = np.array(h)[:, None, None]
                u = (grid[:, :, None] - data[:, None, :])/ h_
                k = 1 / (2*h_) * (abs(u) <= 1)
            return k
        return setgrid

    @classmethod
    def makeproduct(self, kernel) -> np.array:
        """
        Function to Create product Kernel  http://www.maths.lth.se/matstat/kurser/fms110mas222/HMLecture1/3nonparam.pdf
        :param kernel: (:class: `np.array` or `list`) nd.array (n, m) or list (k, (n, m), (p,m)) of points evaluated on
        grid using Kernel.
        :return: res (:class: `np.array`) Matrix of shape of grid (n, n) or (n, p) as a result of Kernel Product.
        """
        try:
            res = np.sum(kernel[0, :, None, :] * np.prod(kernel[1:], axis=0), axis=2)
        except:
            res = np.sum(np.array(kernel[0])[:, None, :] * np.array(kernel[1]), axis=2)
        return res

    def kestimate(kernel, est_num = np.nan, est_denom = np.nan, parallel = False) -> np.array:
        """
        Function for kernel estimation for Nafaraya-Watson 2D. Summing over rows of kernel matrix is performed either
        for kernel matrix itself, or after multiplication by estimator (current data) depending whether kde, mean of rariance is estimated.
        :param kernel: (:class: `np.array` or `list`) nd.array (n, m) or list (k, (n, m), (p,m)) of points evaluated on
        grid using Kernel.
        :param estimator: (:class: `np.array`) either 1 or outdata object of size (1,m).
        :return: res: (:class: `np.array`)  nd.array (n, n) or (n, p) as a result of multiplication of estimator by
        kernel
        """
        if isinstance(est_num, pd.DataFrame):
            x = est_num.values
        else:
            x = est_num

        if isinstance(est_denom, pd.DataFrame):
            y = est_denom.values
        else:
            y = est_denom

        rows, cols = (len(kernel[0]), len(kernel[1]))

        if parallel:
            results = []
            t = Parallel_Kernel()
            pool = mp.Pool(mp.cpu_count() - 1)

            for i in np.arange(cols).tolist():

                column_den = kernel[1][:, i][None, :]*y
                column = kernel[1][:, i][None, :] * x
                results.append(pool.starmap(t.pool_kernel, [(column, column_den, kernel[0][k, :][:, None]) for k in np.arange(rows).tolist()]))

            pool.close()
            pool.join()
            temp_output = np.array(results).T
            output = temp_output[0]
            output_den = temp_output[1]

        else:

            output = np.empty(shape=(rows, cols))
            output_den = np.empty(shape=(rows, cols))

            for i in np.arange(cols).tolist():

                column_den = kernel[1][:, i][None, :]*y
                column = kernel[1][:, i][None, :] * x

                for k in np.arange(rows).tolist():
                    if output is 1: pass
                    else: #output[k, i] = np.sum((column * kernel[0][k, :][:, None]))
                        output[k, i] = np.einsum('jk, jl -> ', column, kernel[0][k, :][:, None])
                    if output_den is 1: pass
                    else: #output_den[k, i] = np.sum((column_den * kernel[0][k, :][:, None]))
                        output_den[k, i] = np.einsum('jk, jl -> ', column_den, kernel[0][k, :][:, None])

        if x is np.nan: output = 1
        if y is np.nan: output_den = 1

        # TRIALS:
        # res = np.sum(kernel[0][:, None, :, None] * kernel[1][None, :, None], axis=(1, 2))*x
        # temp_res =  np.einsum('ij, kl -> ikjl', kernel[0], kernel[1])*x # ikjl
        # res = np.sum(temp_res * x, axis=(2, 3))
        # res = np.sum(kernel[0][:, None, :, None] * x * kernel[1][None, :, None], axis=(2, 3))
        # end = time.time()
        # print('After Loop:', end - start)
        # results = [pool.apply_async(t.pool_kernel, args = (k, column, kernel[0][k, :][:, None])) for k in np.arange(rows).tolist()]
        # results_output.append([r.get()[1] for r in results])
        #  output = np.einsum('ij, kl -> ik', kernel[0], kernel[1])

        return output/output_den


    def kde_kestimate(kernel, est_num = np.nan, est_denom = np.nan) -> np.array:
        """
        Function for kernel estimation. Summing over rows of kernel matrix is performed either for kernel matrix itself,
        or after multiplication by estimator (current data) depending whether kde, mean of rariance is estimated.
        Function works for 2D  Mean, Variance, KDE, Skeweness, Kurtosis.
        :param kernel: (:class: `np.array` or `list`) nd.array (n, m) or list (k, (n, m), (p,m)) of points evaluated on
        grid using Kernel.
        :param estimator: (:class: `np.array`) either 1 or outdata object of size (1,m).
        :return: res: (:class: `np.array`)  nd.array (n, n) or (n, p) as a result of multiplication of estimator by
        kernel
        """

        x = est_num
        y = est_denom

        kx = np.array(kernel[1][0:])*x
        ky = np.array(kernel[1][0:])*y

        try:
            output = np.sum(kernel[0, :, None, :] * kx, axis=2)
            output_den = np.sum(kernel[0, :, None, :] * ky, axis=2)
        except:
            output = np.einsum('ijl, kl -> ik', kernel[0][0:][:, None, :], kx)
            output_den = np.einsum('ijl, kl -> ik', kernel[0][0:][:, None, :], ky)

        if x is np.nan: output = 1
        if y is np.nan: output_den = 1

        return output / output_den

if __name__ == '__main__':

    import matplotlib.pyplot as plt
    import numpy as np
    from math import cos, sin, log10
    from core.stats.kernel_methods import kernel_product as kernels

    samplesize_1 = 100; bw_1 = 0.5
    x_1 = np.empty(samplesize_1); y_1 = np.empty(samplesize_1)
    timegrid_1 = np.array(range(0, samplesize_1))
    for t in timegrid_1: # Creating model cox(x)*2 + random
        eps_1 = np.random.normal(0, 2)
        x_1[t] = np.random.normal(0, 2)
        y_1[t] = x_1[t]**2 * np.cos(x_1[t]) + eps_1
    xgrid_1 = np.mgrid[min(x_1):max(x_1):1j*len(x_1)]
    xgrid_1 = np.sort(x_1)
    nw_1, kernel, _ = kernels.Kernel1D.nadaraya_watson(kernels.Kernel1D(bw_1).gaussian, y_1, x_1) # getting N-W estim.
    confmax, confmin, flags = kernels.Kernel1D.nw_confidence_intervals(y_1, nw_1, kernel, 0.99)

    # 5b) Nadaraya-Watson estimate for time series (smoothing).
    #     Estimate `g` in `y=g(time) + noise`.

    samplesize_2 = 200; bw_2 = 3
    y_2 = np.empty(samplesize_2)
    time = np.arange(samplesize_2)
    for t in time: # full cosine period plus Gaussian noise.
      eps = np.random.normal(0, 2)
      y_2[t] = 2*np.cos(2*np.pi*t/samplesize_2) + eps
    tgrid = np.mgrid[min(time):max(time):1j*len(time)]
    nw_2, kernel2,_ = kernels.Kernel1D.nadaraya_watson(kernels.Kernel1D(bw_2).gaussian, y_2, tgrid)
    confmax2, confmin2, flags2 = kernels.Kernel1D.nw_confidence_intervals(y_2, nw_2, kernel2, 0.9998)

    f = plt.figure()
    #a = plt.subplot(2, 1, 1); a = plt.plot(x_1, y_1, 'o')
    #a = plt.plot(xgrid_1, nw_1, label = 'Nadaraya-Watson estimator, Bandwidth: {}.'.format(bw_1))
    #plt.plot(xgrid_1, confmax, label='Max conf' )
    #plt.plot(xgrid_1, confmin, label='Min conf')
    #plt.plot(xgrid_1[flags], xgrid_1[flags], '-or', linestyle='None', label='Outliers')
    #a = plt.legend(); a = plt.xlabel('x'); a = plt.ylabel('y = g(x) + noise')
    #a = plt.subplot(2, 1, 2);
    a = plt.plot(time, y_2, 'o')
    a = plt.plot(time, nw_2, label = 'Nadaraya-Watson estimator, bandwidth: {}.'.format(bw_2))
    #plt.fill_between(time, confmin1, confmax1, color='grey', alpha=.2, label='95%')
    plt.fill_between(time, confmin2, confmax2, color='grey', alpha=.1, label='95%')
    #plt.plot(time, confmax2, label='Max conf' )
    #plt.plot(time, confmin2, label='Min conf')
    plt.plot(time[flags2], y_2[flags2], '-or', linestyle='None', label='Outliers')
    a = plt.legend(); a = plt.xlabel('time'); a = plt.ylabel('y = g(time) + noise'); a = plt.show()
    f.savefig("C:\Working\TS outlier detection\LaTex Doc\\nwconfint.pdf", bbox_inches='tight')