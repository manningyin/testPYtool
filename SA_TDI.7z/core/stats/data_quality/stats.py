import pandas as pd


def get_defect_stats(in_dict, columns=None, last_days=None, opt='numb'):
    """
    Function calculating sum of artefacts for erach tenor. The rules of summation is:
    gap + stale + (outlier | cross-tenor outlier)
    :param dict_output: (:class: `dict`) Dictionary of results (sum and ratio) for each method separately of 4 keys
    :param outliers_dict: (:class: `dict`) Masked array of outliers and cross-tenor outliers using created OR operand
    :return: (:class: `dict`) Updated dictionary with added row SUM of 4 keys.
    """

    if len(in_dict) ==0:
        empty_pd = pd.DataFrame(['Choose method to see statistics'], columns=['Choose method to see statistics'])
        return empty_pd

    if last_days is None:
        last_days = len(list(in_dict.values)[0])
    if columns is None:
        columns = list(in_dict.values)[0].columns

    for k in in_dict:
        in_dict[k] = in_dict[k].iloc[-last_days:]
        in_dict[k] = in_dict[k][columns]

    # ===================================================================================
    # Put defect_type field to each df
    # ===================================================================================

    for defet_type in in_dict:
        in_dict[defet_type]['defect_type'] = defet_type

    all_df = pd.concat(list(in_dict.values()))
    out_df = all_df.groupby('defect_type').sum()
    out_df['Sum'] = out_df.sum(axis=1)

    if opt not in get_options().values():
        raise Exception('Unknown option')

    if opt == 'rat':
        out_df = out_df/last_days * 100
        out_df = out_df.applymap(lambda x: "{:.2f}%".format(x))
    elif opt == 'numb':
        out_df = out_df.applymap(lambda x: int(x))
    cols = list(out_df.columns)
    out_df['Defect Type'] = out_df.index

    return pd.DataFrame(out_df, columns=['Defect Type'] + cols)


def get_options():
    return {'Number': 'numb', 'Percentage': 'rat'}

