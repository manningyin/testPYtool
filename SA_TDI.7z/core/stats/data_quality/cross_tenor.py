import numpy as np
from core.stats.data_quality import detrending_ts as detr
from core.stats.data_quality import outlier_detection as odt
from core.stats.data_quality import stats as stats

class CrossTenorOutliers:
    """
    Parent class for detecting outliers tenor-wise, e.g. comparing 1M with 3M tenor.
    Initializer creates object, assignes timeseries. Currently not in use. Done for future upgrades
    Classmethod do actual flagging. First, the time series of differences between each two neighboring
    tenors is created. Then any method from outlier _detection class can be called to flag outliers - standard deviation
    or ARMA. See outlier_detection examples
    for more information

    :param data: (:class: `np.array`) nd.array of shape (n,m), where n - number of tenors to analyze
    :param tenors: (:class: `np.array`) Boolean array with True values - tenors to analyze

    Examples:
    -------
    >>> import numpy as np; import matplotlib.pyplot as plt
    >>> from core.stats.data_quality import cross_tenor as ct

        # create dummy data and artificial cross tenor shocks
    >>> np.random.seed(50); tst1 = np.random.normal(0, 2, size=100)
    >>> tst2 = tst1+tst1*0.1
    >>> tst2[34] = 0.5; tst2[45] = 0.2; tst2[67] = 0.7; tst1[90] = -0.25
    >>> tst = np.array([tst1, tst2, tst1, tst2])


        # Call function with windowsize=20 and Standard Deviation = 4.
    >>> tenors = [True, False, True, True]
    >>> _, flaggedSTD = ct.CrossTenorOutliers.tenordifference(tst, tenors, windowsize=20, stdthreshold=4)

        # Plotting for visualisation. Uncomment if needed:
    >>> y = np.arange(len(tst[0])); f = plt.figure(); labels = []
    >>> for i in range(0, len(tst)):
    ...     a = plt.plot(y[flaggedSTD[i]], tst[i][flaggedSTD[i]], '-or', linestyle='None')
    ...     a = plt.plot(y, tst[i])
    ...     labels.append(('Tenor ',i))
    >>> a = plt.legend(['Flagged1', 'Tenor1', 'Flagged2', 'Tenor2'], loc='best')
    >>> plt.grid()
    >>> f =plt.gcf()
    >>> plt.show()
    >>> #f.savefig("C:\Working\TS outlier detection\LaTex Doc\crosstenor.pdf", bbox_inches='tight')

        Notes:
            Author: g02229 (Alex)
        """
    def __init__(self, data, tenors, flag=None):
        self.data = data
        self.tenors = tenors
        self.flag = flag

    @staticmethod
    def tenordifference(data, tenors, windowsize=None, stdthreshold=None):
        """
        Calls inner function to get time series of differences between two tenors.
        Calls method from outlier_detection script to analyze obtained time series for outliers.
        :param data: (:class: `nd.array`) Market data values (n,m), where n - each separate tenor.
        :param tenors: (:class: `boolean array`) Boolean array of what columns to use
        :param windowsize: (:class:`int`) size of window in data to measure rolling standard deviation
        :param stdthreshold: (:class:`int`) number of Standard deviations to build threshold
        :return: (:class:`np.array`) Returns boolean array 2 by n of data points (True for identified outliers)
        Outliers are flagged for both passed tenors.
        """
        if len(np.shape(data)) == 1:
            raise ValueError('Only one Tenor chosen. Please choose minimum 2.')
        indicies = np.where(tenors)[0]
        flaggedtenor = np.full((len(data), len(data[0])), False)
        diff_tenors = _gettenordifference(data[tenors])
        diff_ts = np.array([detr.DetrendingTS.differencing(row) for row in data[tenors]])
        ind = 0

        for row in diff_tenors:
            _, flaggedstd, _, _ = odt.OutlierDetection.stdeviation(row, windowsize, stdthreshold)
            ts1 = abs(diff_ts[ind]) > abs(diff_ts[ind+1])
            ts2 = ~ts1
            ts1 = ts1*flaggedstd
            ts2 = ts2*flaggedstd
            flaggedtenor[indicies[ind], :] = flaggedtenor[ind, :] | ts1
            ind += 1
            flaggedtenor[indicies[ind], :] = flaggedtenor[ind, :] | ts2

        return data, flaggedtenor


def _gettenordifference(data):
    """
    Calculates absolute difference between subsequent pair of tenors
    :return: (:class: `nd.array`) Returns time series of absolute differences between each tenor
    """
    return abs(np.subtract(data[1:, :], data[:-1, :]))

'''
def _stdeviation(data, windowsize=None, stdthreshold=None):
    """
    Calls inner function to build standard deviation ranges of data with given parameters.
    :param data: (:class: `np.array`) Market data values
    :param windowsize: (:class:`int`) size of window in data to measure rolling standard deviation
    :param stdthreshold: (:class:`int`) number of Standard deviations to build threshold
    :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as outliers)
    """
    mask = np.isnan(data)
    in_data = data.copy()
    in_data[mask] = np.interp(np.flatnonzero(mask), np.flatnonzero(~mask), data[~mask])
    if len(data) < windowsize - 1:
        raise Exception("Time series is too short for current method")
    rangetsplus = _getstdts(in_data, windowsize, stdthreshold)  # Only considering when difference increase
    return data, (data > rangetsplus)  # last two for plotting


def _getstdts(data, windowsize, stdthreshold):
    """
    Same as :func:`stdeviation`, in terms of input.
    :return: (:class: `np.array`) Returns one np.array which is standard deviations thresholds built on input data
    """
    stdts = np.zeros(len(data))
    stdts[:windowsize] = data[:windowsize].std()
    stdts[windowsize:] = [data[i: i + windowsize].std() for i in range(len(data) - windowsize)]
    stdts = np.multiply(stdts, stdthreshold)
    meants = np.zeros(len(data))
    meants[:windowsize] = data[:windowsize].mean()
    meants[windowsize:] = [data[i: i + windowsize].mean() for i in range(len(data) - windowsize)]
    rangetsplus = np.add(meants, stdts)
    return rangetsplus'''
