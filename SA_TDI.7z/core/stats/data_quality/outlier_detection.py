import numpy as np
from statsmodels.tsa.arima_model import ARMA
from core.stats.data_quality import stats as stats
import warnings

class OutlierDetection:
    """
        Parent class for Detection of outliers (using different methods).
        Initializer assignes timeseries. Not used currently. For any future upgrades.
        Static Methods do actual flagging of suspicious points using different approaches.

        Args:
            data: (:class: `np.array`) Market data values

    Examples:
    -------

    >>> import numpy as np; import matplotlib.pyplot as plt
    >>> from core.stats.data_quality import outlier_detection as od

    # create dummy data
    >>> np.random.seed(20); tst = np.random.normal(0, 1, size=100); tst[50] = 5; tst[90] = -5

    # calling standard deviation method with windowsize 20 and 3 standard deviations
    >>> _, flaggedSTD, maxSTD, minSTD = od.OutlierDetection.stdeviation(tst, windowsize=30, stdthreshold=4)

    # calling MA method of order 1 and confidence interval 99%.
    >>> _, flaggedMA, maxMA, minMA = od.OutlierDetection.arma(tst, maorder=2, maconfidence=0.001)

    # plotting for visualisation. Uncomment if needed:
    >>> y = np.arange(len(tst)); f = plt.figure()
    >>> a= plt.figure(1); a= plt.subplot(211)
    >>> a= plt.plot(y[flaggedSTD], tst[flaggedSTD], '-or', linestyle='None', label="Flagged points STD")
    >>> a= plt.plot(y, maxSTD, label="Upp Conf"); a= plt.plot(y, minSTD, label="Low Conf"); a= plt.plot(y, tst, label="Raw data")
    >>> a= plt.legend(loc='best'); a= plt.xlabel('time'); a= plt.ylabel('value')
    >>> a= plt.subplot(212)
    >>> a= plt.plot(y[flaggedMA], tst[flaggedMA], '-or', linestyle='None', label="Flagged points MA")
    >>> a= plt.plot(y, tst, label="Raw data"); a= plt.plot(y, maxMA, label="Upp Conf"); a= plt.plot(y, minMA, label="Low Conf")
    >>> a= plt.legend(loc=2); plt.show()
    # f.savefig("C:\Working\TS outlier detection\LaTex Doc\stdev.pdf", bbox_inches='tight')

    Notes:
            Author: g02229 (Alex)
        """
    def __init__(self, data):
        self.data = data

    @staticmethod
    def stdeviation(data, windowsize=None, stdthreshold=None):
        """
        Calls inner function to build standard deviation ranges of data with given parameters.
        :param data: (:class: `np.array`) Market data values
        :param windowsize: (:class:`int`) size of window in data to measure rolling standard deviation
        :param stdthreshold: (:class:`int`) number of Standard deviations to build threshold
        :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as outliers)
        """
        mask = np.isnan(data)
        in_data = data.copy()
        in_data[mask] = np.interp(np.flatnonzero(mask), np.flatnonzero(~mask), data[~mask])
        try:
            if len(data) < windowsize - 1:
                raise Exception("Time series is too short for current method")
        except:
            windowsize = len(data)
        rangetsminus, rangetsplus = _getstdts(in_data, windowsize, stdthreshold)
        flagged = ((data < rangetsminus) | (data > rangetsplus))
        return data, flagged, rangetsminus, rangetsplus  # last two for plotting

    @staticmethod
    def arma(data, maorder=1, maconfidence=0.001):
        """
        Calls inner function to build ARMA(1,0,1) confidence intervals of data with given parameters.
        :param data: (:class: `np.array`) Market data values
        :param maorder: (:class:`int`) lag or MA process
        :param maconfidence: (:class:`float`) confidence interval to asses
        :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as outliers)
        """
        warnings.filterwarnings("ignore")
        mask = np.isnan(data)
        in_data = data.copy()
        in_data[mask] = np.interp(np.flatnonzero(mask), np.flatnonzero(~mask), data[~mask])
        windowsize = maorder * 20  # Multiplication by 20 to make data statistically ready for usage
        if len(data) < windowsize - 1:
            raise Exception("Time series is too short for current method or MA order is too high. Choose MA=1 or 2.")
        confmin, confmax = _arma(in_data, windowsize, maorder, maconfidence)
        flagged = (data > confmax) | (data < confmin)
        return data, flagged, confmin, confmax  # Last two arguments just for plotting.


def _getstdts(data, windowsize, stdthreshold):
    """
    Same as :func:`stdeviation`, in terms of input.
    :return: (:class: `np.array`) Returns two np.arrays which are standard deviations thresholds built on input data
    """
    stdts = np.zeros(len(data))
    #reverseddata = data[:windowsize * 2][::-1]  # Reversing data to calculate std in the start of the window.
    #start_std = [reverseddata[i: i + windowsize].std() for i in range(windowsize)]
    #stdts[:windowsize] = start_std[::-1]
    stdts[:windowsize] = data[:windowsize].std()
    stdts[windowsize:] = [data[i: i + windowsize].std() for i in range(len(data) - windowsize)]
    stdts = np.multiply(stdts, stdthreshold)
    meants = np.zeros(len(data))
    #meants[:windowsize] = [reverseddata[i: i + windowsize].mean() for i in range(windowsize)]
    meants[:windowsize] = data[:windowsize].mean()
    meants[windowsize:] = [data[i: i + windowsize].mean() for i in range(len(data) - windowsize)]
    rangetsplus = np.add(meants, stdts)
    rangetsminus = np.subtract(meants, stdts)
    return rangetsminus, rangetsplus


def _arma(data, windowsize, maorder, maconfidence):
    """
    Same as :func:`arma`, in terms of input.
    Runs ARMA(0,n) model on data with defined window to obtain TS of lower and upper bounds of confidence interval
    with specified confidence level. To obtain TS for burnout period (data points in the left tail of size windowsize,
    timeseries is reversed and ARMA is run again.
    :return: (:class: `np.array`) Returns two np.arrays which are confidence intervals of data
    """
    confmaxts = np.zeros(len(data))
    confmints = np.zeros(len(data))
    try:
        confmints, confmaxts = _runarma(data, windowsize, maorder, maconfidence, confmaxts, confmints)

    # Reversing data to run ARMA for the first window of time series.
        reverseddata = data[:windowsize*2][::-1]
        mins, maxs = _runarma(reverseddata, windowsize, maorder, maconfidence)
        confmints[:windowsize] = mins[windowsize:][::-1]
        confmaxts[:windowsize] = maxs[windowsize:][::-1]
    except:
        raise Exception('ARMA did not converge due to data. Choose another method.')
    return confmints, confmaxts


def _runarma(data, windowsize, maorder, maconfidence, confmaxts=None, confmints=None):
    warnings.filterwarnings("ignore")
    if confmaxts is None:
        confmaxts = np.zeros(int(len(data)))
        confmints = np.zeros(int(len(data)))
    for i in range(windowsize, len(data)):
        model = ARMA(data[i - windowsize:i], order=(1,0,maorder))
        res = model.fit(disp=0)
        predicted = res.forecast(alpha=maconfidence)
        confmints[i] = predicted[2].min()
        confmaxts[i] = predicted[2].max()
    return confmints, confmaxts
