import numpy as np
from core.stats.data_quality import stats as stats


class GapFinder:
    """
        Parent class for Finding and flagging gaps in TS.
        Initializer assigns time series. Not used currently. For future developments if needed.
        Methods do actual flagging of missing values.

        Args:
            data: (:class: `np.array`) Market data values

    Examples:
    -------

    >>> import numpy as np; import matplotlib.pyplot as plt
    >>> from core.stats.data_quality import gap_finder as gp

    # Generating random data
    >>> np.random.seed(50); tst = np.random.normal(0, 2, size=100)

    # Creating artificial gaps in random time series
    >>> tst[58:65] = np.nan; tst[24:31] = np.nan; tst[5] = None

    # Calling function to find gaps in data (nans, None)
    >>> _, flaggedgap, info = gp.GapFinder.flaggaps(tst)

    # plotting for visualisation. Uncomment if needed:
    >>> y = np.arange(len(tst)); missedtst = tst.copy(); missedtst[flaggedgap] = 0; f = plt.figure()
    >>> plt.plot(y[flaggedgap], missedtst[flaggedgap], '-or', linestyle='None', label="Flagged Gaps")
    >>> plt.xlabel('time'); plt.ylabel('value'); plt.plot(y, tst, label="Raw TS"); plt.legend(loc='best'); plt.show()
    >>> #f.savefig("C:\Working\TS outlier detection\LaTex Doc\gaps.pdf", bbox_inches='tight')

        Notes:
            Author: g02229 (Alex)
    """

    def __init__(self, data, flag=None):
        self.data = data
        self.flag = flag

    @staticmethod
    def flaggaps(data):
        """
        Calls inner function to find gaps in data.
        :param data: (:class: `np.array`) Market data values
        :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as gaps)
        """
        return data, _flaggaps(data)


def _flaggaps(data):
    """
    Inner function to find gaps in data.
    Same as :func:`flaggaps`, in terms of input.
    :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as gaps)
    """
    return ~np.isfinite(data)
