import numpy as np
from core.stats.kernel_methods import kernel_product as kernels


class DetrendingTS:
    """
    Parent class for Detrending (using different methods).
    Initializer creates object, assignes timeseries.
    Classmethods do actual detrending using different approaches.

    :param data: (:class: `np.array`) Market data values

    Examples:
    -------

    >>> import numpy as np; import matplotlib.pyplot as plt
    >>> from core.stats.data_quality import detrending_ts as dt

    >>> np.random.seed(50)  # create dummy data
    >>> tst = np.linspace(3, 8, 100) + np.random.normal(0,1,size=100)

        # perform detrending by differencing method
    >>> diff = dt.DetrendingTS.differencing(tst)

        # perform detrending by Nadaraya-Watson with Bandwidth = 2
    >>> nw_detr, nw_trend = dt.DetrendingTS.nwdetrending(tst, 1)

        # create grid for plotting
    >>> y = np.arange(len(diff))

        # plotting for visualisation. Uncomment if needed:
    >>> y = np.arange(len(diff)); f = plt.figure()
    >>> a= plt.plot(y,tst,label="Raw TS")
    >>> a= plt.plot(y,nw_trend,label="N-W estimator")
    >>> a= plt.plot(y,nw_detr,label="Detrended by NW")
    >>> # a= plt.plot(y,diff,label="Detrended by Differencing")
    >>> a = plt.xlabel('time'); a = plt.ylabel('value')
    >>> a= plt.legend(loc='best');plt.grid();plt.show()
   #>>> f.savefig("C:\Working\TS outlier detection\LaTex Doc\detr_nw.pdf", bbox_inches='tight')

    Notes:
        Author: g02229 (Alex)
    """

    def __init__(self, data):
        self.data = data

    @staticmethod
    def differencing(data):
        """
        Calculates difference between t and t-1 value, building new detrended time-series.
         :return: (:class: `np.array`) Returns detrended timeseries using differencing method
        """
        values = np.roll(data, 1)
        values = data - values
        values[0] = 0
        return values

    @staticmethod
    def nwdetrending(data, bandwidth = 1):
        """
        Calculates Nadaraya-Watson estimator on data with length of grid = lengh of data and built on time index.
        :param data: (:class: `np.array`) Market data values with time indexes. If no index, data is built 1:n
        :param bandwidth: (:class:`int`) Smoothing parameter, bandwidth of kernel regression.
        :return: (:class: `np.array`) Returns difference between data values and nadaraya-watson estimator (trend),
        which in fact are errors (dedtrended timeseries) distributed around 0.
        """
        try:
            data_1D = np.array([i.toordinal() for i in data.index])
        except:
            data_1D = np.arange(1,len(data)+1)
        nw_1D, _, _ = kernels.Kernel1D.nadaraya_watson(kernels.Kernel1D(bandwidth).gaussian, data, data_1D)
        return data - nw_1D, nw_1D


