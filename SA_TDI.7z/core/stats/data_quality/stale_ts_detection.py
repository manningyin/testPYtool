import numpy as np
from core.stats.data_quality import stats as stats

class StaleTSDetection:
    """
    Parent class for detecting of stale data in time series (unchanged for subsequent periods).
    Initializer creates object, assignes timeseries. Currently not in use. Done for future upgrades
    Classmethods do actual detestion of stale data using two approaches: analyzing differences and comparing them with
    defined accuracy and analyzing rolling standard deviation and comparing obtained time series with threshold.
    Both methods return boolean array, where True value marks stale data.

    :param data: (:class: `np.array`) Market data values

    Examples:
    -------
    >>> import numpy as np; import matplotlib.pyplot as plt
    >>> from core.stats.data_quality import stale_ts_detection as stl

    # create dummy data and artificial stale periods
    >>> np.random.seed(50); tst = np.random.normal(0, 2, size=100)
    >>> tst[0:4] = 0.2; tst[14:15] = 0.2; tst[24:32] = 0.7; tst[98:] = -0.25

    # calling differencing method with accuracy 0.00001. E.g. if difference below accuracy -> True (stale point)
    >>> _, flaggedStale, diffts = stl.StaleTSDetection.detectstale(tst, accuracy=0.00001)

    # calling standard deviation method with rolling window 5 and accuracy 0.1. If rolling st.d falls below 0.1 ->
    # points are flagged as Stale. Usually has slight lag compared to differencing method.
    >>> _, flaggedStaleSTD, stdts = stl.StaleTSDetection.detectstalestd(tst, windowsize=5, accuracy=0.1)

    # Plotting for visualisation. Uncomment if needed:
    >>> y = np.arange(len(tst)); f = plt.figure(); plt.figure(1); plt.subplot(211); plt.xlabel('time'); plt.ylabel('value')
    >>> plt.plot(y[flaggedStaleSTD], tst[flaggedStaleSTD], '-or', linestyle='None', label="Flagged stale")
    >>> plt.plot(y, tst, label="Raw TS"); plt.legend(loc='best');plt.subplot(212);plt.xlabel('time');plt.ylabel('value')
    #>>> plt.plot(y, diffts, label="Differences"); plt.plot(y, np.full(len(tst), 0.00001), label="accuracy")
    >>> plt.legend(loc='best'); plt.subplot(211); plt.xlabel('time'); plt.ylabel('value')
    >>> plt.plot(y[flaggedStaleSTD], tst[flaggedStaleSTD], '-or', linestyle='None', label="Flagged stale STD")
    >>> plt.plot(y, tst, label="Raw TS"); plt.legend(loc='best'); plt.subplot(212); plt.plot(y, stdts, label="StdTS")
    >>> plt.plot(y, np.full(len(tst), 0.1), label="accuracy")
    >>> plt.legend(loc='best'); plt.xlabel('time'); plt.ylabel('value'); plt.show()
    >>> f.savefig("C:\Working\TS outlier detection\LaTex Doc\stalestd.pdf", bbox_inches='tight')

        Notes:
            Author: g02229 (Alex)
        """
    def __init__(self, data, flag=None):
        self.data = data
        self.flag = flag

    @staticmethod
    def detectstale(data, accuracy=0.0001):
        """
        Calls inner function to get time series of differences in data, e.g. x_t - x_(t-1)
        :param data: (:class: `np.array`) Market data values
        :param accuracy: (:class: `float`) threshold for differences to be treated as stale data
        :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as gaps)
        """
        differences, rates = _getdifferences(data, accuracy)
        flagged = np.append(False, abs(differences) <= rates[1:])
        return data, flagged, np.append(rates, abs(differences))  # For plot

    @staticmethod
    def detectstalestd(data, windowsize=None, accuracy=0.0001):
        """
        Calls inner function to get time series of rolling standard devioation.
        :param data: (:class: `np.array`) Market data values
        :param windowsize: (:class: `integer`) Size of a rolling window to calculate Standard deviation
        :param accuracy: (:class: `float`) threshold for standard deviations to be treated as stale data
        :return: (:class: `np.array`) Returns boolean array of data points (True for points classified as gaps)
        Checks whether rolling standard deviation is below some accuracy level.
        Flags as True all stale data points. Early stale points in stale series are not detected due to window lag.
        """
        if len(data) < windowsize-1:
            raise Exception("Time series is too short or std window is too long")
        stdts = _detectstalestd(data, windowsize)
        rates = abs(data*accuracy)
        flagged = np.array(stdts) <= rates
        return data,  flagged, np.array(stdts)  # third argument for plotting


def _getdifferences(data, accuracy):
    """
    Inner function to build time series of differences based on data.
    Same as :func:`getdifferences`, in terms of input.
    :return: (:class: `np.array`) Returns time series of differences
    """
    rates = abs(data*accuracy)
    return abs(np.diff(data)), rates


def _detectstalestd(data, windowsize):
    """
    Builds time series of rolling standard deviation with given window length.
    Burnout window period (first window size observations) are obtained by reversing data series and do rolling STD.
    :param data: (:class: `np.array`) Market data values
    :param windowsize: (:class: `integer`) Size of a rolling window to calculate Standard deviation
    :return: (:class: `np.array`) Returns time series of rolling standard deviation
    """
    stdts = [data[i:i + windowsize].std() for i in range(len(data) - windowsize)]  # TODO: consider using pandas.core.window.Rolling.std or similar (numpy) instead.
    burnoutstd = np.full(windowsize, data[0:windowsize].std())
    return np.append(burnoutstd, stdts)
