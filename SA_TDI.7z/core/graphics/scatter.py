"""
Module for creating graphical plots


Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       14FEB2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import plotly.graph_objs as go
import plotly.offline as po

def plot(dataframe,
         x_axis_var,
         y_axis_vars,
         dest_html_file,
         plot_title,
         y_axis_labels  = None,
         plot_types     = 'markers',
         auto_open      = True,
         info           = 0
         ):
    """
    Creates a plotly "Scatter" plot with optional several time series

    Args:
        dataframe       (dataframe):    Dataframe with all data that should be used in plot
        x_axis_var      (str):          Name of the variable in the dataframe that should be used as X-axis (first axis / horizontal axis)
                                        If set to 'index', x-axis will be the dataframe index
        y_axis_vars     (list of str):  Names of the variables in the dataframe that should be used as Y-axis (second axis / vertical axis)
        dest_html_file  (str):          Destination for the final htm(l) file. Full file path, including the htm(l) extension.
        plot_title      (str):          Title which will appear in the plot
        y_axis_labels   (list of str):  (default = None)! Labels for the time series, used as legend in the plot
        plot_types      (list of str):  (default = 'markers')! Specification of curve graph point marker type ("mode" variable in plotly scatter object.
                                        Choose 'markers' for single points. Examples: 'marker','lines','lines+markers'
        auto_open       (bool):         (default = True) Choose False if the output file should not automatically be opened after creation
                                        (this could be a good ide if you are generating many files by running this function in a loop)
        info            (int):          (default = 0) Controls how much info is written to the log.

    Returns:
        None (but creates a plot)

    Raises:

    Example:
        The module is called (from python) like this::
        
            import pandas as pd
            l = [
                {'x_axis': 1, 'y_axis_1': 10, 'y_axis_2': 9},
                {'x_axis': 2, 'y_axis_1': 12, 'y_axis_2': 11},
                {'x_axis': 3, 'y_axis_1': 9, 'y_axis_2': 7},
                {'x_axis': 4, 'y_axis_1': 8, 'y_axis_2': 8},
                {'x_axis': 5, 'y_axis_1': 11, 'y_axis_2': 12},
                {'x_axis': 6, 'y_axis_1': 15, 'y_axis_2': 16},
                {'x_axis': 7, 'y_axis_1': 7, 'y_axis_2': 8},
                {'x_axis': 8, 'y_axis_1': 6, 'y_axis_2': 6},
                {'x_axis': 9, 'y_axis_1': 8, 'y_axis_2': 7},
                {'x_axis': 10, 'y_axis_1': 10, 'y_axis_2': 9}
                ]
            df = pd.DataFrame(l)

            plot(dataframe      = df,
                 x_axis_var     = 'x_axis',
                 y_axis_vars    = ['y_axis_1','y_axis_2'],
                 y_axis_labels  = ['My time series','My other time series'],
                 dest_html_file = 'c:/Working/test.html',
                 plot_title     = 'This is some test plot',
                 plot_types     = 'lines+markers',
                 auto_open      = True,
                 )


    Warning:

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # The function supports both single and multiple y-axis.
    # When only plotting one single time series, function accepts strings
    # - which are transformed into lists here-
    # ===================================================================================

    def trans_to_list(variable):
        """Evaluates if input is a list - transforms if required, and returns it as a list"""
        if type(variable) == str:
            return [variable]
        else:
            return variable

    y_axis_vars   = trans_to_list(y_axis_vars)
    y_axis_labels = trans_to_list(y_axis_labels)
    plot_types    = trans_to_list(plot_types)

    if info > 0:
        print('Number of y axis variables (time-series):', len(y_axis_vars))

    if not y_axis_labels == None:
        if not len(y_axis_vars) == len(y_axis_labels):
            # Ensuring that the number of time series matches the number of labels
            raise Exception('Number of elements is expected to be the same in y_axis_vars (' +
                            str(len(y_axis_vars))+
                            ') and y_axis_labels (' +
                            str(len(y_axis_labels)) +
                            ')'
                            )

    # ===================================================================================
    # If the x_axis_var is set to 'index', the dataframe index is used as x-axis.
    # Otherwise it is assumed that the value of x_axis_var is a column in the dataframe
    # ===================================================================================

    if x_axis_var == 'index':
        x_axis_series = dataframe.index
    else:
        x_axis_series = dataframe[x_axis_var]

    data = []
    for i in range(0,len(y_axis_vars)):
        # ===================================================================================
        # Plot mode (shaping of the graph) can be set equal for all time series, or specific
        # per time series. If the input of plot_type is just a string,
        # same plot type will be used for all time series.
        # ===================================================================================
        plot_mode = plot_types[min(i,len(plot_types)-1)]

        if not y_axis_labels == None:
            # If no label is chosen, we will use the name of the dataframe column
            label = y_axis_labels[i]
        else:
            label = y_axis_vars[i]

        # Creating time series plot object
        trace = go.Scatter( x       = x_axis_series,
                            y       = dataframe[y_axis_vars[i]],
                            mode    = plot_mode,
                            name    = label
                            )

        data.append(trace)
    # Adding title
    layout = go.Layout(title = plot_title)

    # Combining title and data into figure object
    figure = go.Figure(data = data, layout = layout)

    # Creating html page with plot
    po.plot(figure_or_data  = figure,
            show_link       = False,
            filename        = dest_html_file,
            auto_open       = auto_open
            )


def plot_by_group(  dataframe,
                    x_axis_var,
                    y_axis_var,
                    dest_html_file,
                    plot_title,
                    group_by_var,
                    plot_types      = 'markers',
                    auto_open       = True,
                    info            = 0,
                 ):
    """
    Splitting series into groups, and creates "Scatter" plot with optional several time series

    This is a simple wrapper around the "plot" function (in same module).

    Args:
        dataframe       (dataframe):    Dataframe with all data that should be used in plot
        x_axis_var      (str):          Name of the variable in the dataframe that should be used as X-axis (first axis / horizontal axis)
                                        If set to 'index', x-axis will be the dataframe index
        group_by_var    (str):
        y_axis_var      (str):          Name of the value-variable in the dataframe that is considered as the Y-axis (second axis / vertical axis)
        dest_html_file  (str):          Destination for the final htm(l) file. Full file path, including the htm(l) extension.
        plot_title      (str):          Title which will appear in the plot
        plot_types      (list of str):  Specification of curve graph point marker type ("mode" variable in plotly scatter object.
                                        Choose 'markers' for single points. Examples: 'marker','lines','lines+markers'
        auto_open       (bool):         (default = True) Choose False if the output file should not automatically be opened after creation
                                        (this could be a good ide if you are generating many files by running this function in a loop)
        plot_by_group   (str):          Name of the variable that should be used for grouping.
        info            (int):          (default = 0) Controls how much info is written to the log.

    Returns:
        None (but creates a plot)

    Raises:

    Example:
        The module is called (from python) like this::
        
            import pandas as pd
            l = [
                {'group': 'A', 'x_axis': 1, 'y_axis_1': 10},
                {'group': 'A', 'x_axis': 2, 'y_axis_1': 12},
                {'group': 'A', 'x_axis': 3, 'y_axis_1': 9},
                {'group': 'A', 'x_axis': 4, 'y_axis_1': 8},
                {'group': 'A', 'x_axis': 5, 'y_axis_1': 11},
                {'group': 'A', 'x_axis': 6, 'y_axis_1': 15},
                {'group': 'A', 'x_axis': 7, 'y_axis_1': 7},
                {'group': 'A', 'x_axis': 8, 'y_axis_1': 6},
                {'group': 'A', 'x_axis': 9, 'y_axis_1': 8},
                {'group': 'A', 'x_axis': 10, 'y_axis_1': 10},
                {'group': 'B', 'x_axis': 1, 'y_axis_1': 9},
                {'group': 'B', 'x_axis': 2, 'y_axis_1': 13},
                {'group': 'B', 'x_axis': 3, 'y_axis_1': 9},
                {'group': 'B', 'x_axis': 4, 'y_axis_1': 8},
                {'group': 'B', 'x_axis': 5, 'y_axis_1': 14},
                {'group': 'B', 'x_axis': 6, 'y_axis_1': 16},
                {'group': 'B', 'x_axis': 7, 'y_axis_1': 7},
                {'group': 'B', 'x_axis': 8, 'y_axis_1': 6},
                {'group': 'B', 'x_axis': 9, 'y_axis_1': 9},
                {'group': 'B', 'x_axis': 10, 'y_axis_1': 10},
                ]
            df = pd.DataFrame(l)

            plot_by_group(  dataframe      = df,
                            x_axis_var     = 'x_axis',
                            y_axis_var     = 'y_axis_1',
                            dest_html_file = 'c:/Working/test.html',
                            plot_title     = 'This is some test plot',
                            plot_types     = 'lines+markers',
                            auto_open      = True,
                            group_by_var   = 'group',
                            info           = 1,
                            )

    Warning:

    Notes:
        Author: g50444
    """

    group_by_values = list(dataframe[group_by_var].unique())

    if not type(y_axis_var) == str:
        raise KeyError("Grouping can only be done using one y-axis element. Input is: " + str(y_axis_var) + ". Consider using scatter.plot() instead.")

    if info > 0:
        print(20*'=' + ' Dataframe ' + 20*'=' )
        print(dataframe.head())

    df_transposed = dataframe.pivot(index   = x_axis_var,
                                    columns = group_by_var,
                                    values  = y_axis_var,
                                    )

    plot(dataframe      = df_transposed,
         x_axis_var     = 'index',
         y_axis_vars    = group_by_values,
         dest_html_file = dest_html_file,
         y_axis_labels  = None,
         plot_title     = plot_title,
         plot_types     = plot_types,
         auto_open      = auto_open,
         info           = info,
         )

if __name__ == '__main__':
    import pandas as pd
    l = [
        {'group': 'A', 'x_axis': 1, 'y_axis_1': 10},
        {'group': 'A', 'x_axis': 2, 'y_axis_1': 12},
        {'group': 'A', 'x_axis': 3, 'y_axis_1': 9},
        {'group': 'A', 'x_axis': 4, 'y_axis_1': 8},
        {'group': 'A', 'x_axis': 5, 'y_axis_1': 11},
        {'group': 'A', 'x_axis': 6, 'y_axis_1': 15},
        {'group': 'A', 'x_axis': 7, 'y_axis_1': 7},
        {'group': 'A', 'x_axis': 8, 'y_axis_1': 6},
        {'group': 'A', 'x_axis': 9, 'y_axis_1': 8},
        {'group': 'A', 'x_axis': 10, 'y_axis_1': 10},
        {'group': 'B', 'x_axis': 1, 'y_axis_1': 9},
        {'group': 'B', 'x_axis': 2, 'y_axis_1': 13},
        {'group': 'B', 'x_axis': 3, 'y_axis_1': 9},
        {'group': 'B', 'x_axis': 4, 'y_axis_1': 8},
        {'group': 'B', 'x_axis': 5, 'y_axis_1': 14},
        {'group': 'B', 'x_axis': 6, 'y_axis_1': 16},
        {'group': 'B', 'x_axis': 7, 'y_axis_1': 7},
        {'group': 'B', 'x_axis': 8, 'y_axis_1': 6},
        {'group': 'B', 'x_axis': 9, 'y_axis_1': 9},
        {'group': 'B', 'x_axis': 10, 'y_axis_1': 10},
        ]
    df = pd.DataFrame(l)

    plot_by_group(dataframe      = df,
                 x_axis_var     = 'x_axis',
                 y_axis_var     = 'y_axis_1',
                 y_axis_labels  = ['My time series','My other time series'],
                 dest_html_file = 'c:/Working/test.html',
                 plot_title     = 'This is some test plot',
                 plot_types     = 'lines+markers',
                 auto_open      = True,
                 group_by_var   = 'group',
                 info           = 0,
                 )
