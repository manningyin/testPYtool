"""
Module for plot curves


Notes:
    Author: G48454 (Shengyao Zhu)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       16OCT2017   G48454      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import matplotlib.pyplot as plt
import quantum as qt
_step = '7D'
def plot_qt_curve(qt_curve , anchor = None):
    """
    The function plot the qToolkit curve as a figure

    Args:
        qt_curve (qtoolkit curve format)  any curves defined as CurveInterpolated curve
        anchor (datetime.date) the anchor date of the curve

    Notes:
        Author: g48454 (Shengyao Zhu)
    """
    if anchor is None:
        anchor = qt_curve._get_dates()[0]
    # ===================================================================================
    # get the fine grid and plot the trend
    # ===================================================================================
    (x,y) = sammple_curve_by_more_fine_grids(qt_curve,anchor)
    plt.plot(x, y, '--')
    # ===================================================================================
    # get the real key instrument defined on the curve.
    # ===================================================================================
    (x_l,y_l) = sample_curve_by_key_insturments(qt_curve,anchor)
    plt.plot(x_l,y_l,'ro')
    return plt

def compare_two_curves(qt_curve1,qt_curve2, anchor , curvenames , compare_days = None):
    """
    The function try to compare the two qtoolkit curves and plot the two curves one by one.

    Args:
        qt_curve1       (qtoolkit curve format):    any curves defined as CurveInterpolated curve
        qt_curve2       (qtoolkit curve format):    any curves defined as CurveInterpolated curve
        anchor          (datetime.date):            the anchor date of the curve
        curvenames      (list of str):              the curve names for curve 1 and curve 2
        compare_days    (list of datetime.date):    optional, defined which dates you want to compare, if not specific, the function will compare all dates defined either in curve 1 or in curve 2 object.

    Returns:
        (dataframe):   Meaningful description of data returned by function

    Example:
        The module is called (from python) like this::

            import quantum as qt
            import datetime
            from core.utils.orca_helper import get_orca_request,get_orca_timestamp
            from orca.types import TradeIdentifier, SourceSystem , InfinityMarketDataName
            from core.graphics.curve import plot_qt_curve , compare_two_curves
            rate_curve_names = InfinityMarketDataName("EUROISF_V",
                                            qt.Currency.EUR,
                                            qt.MarketDataInstanceCode.CLOSE)
            request = get_orca_request()
            d1 = datetime.datetime(2017,3,13,19)
            d2 = datetime.datetime(2017,3,14,19)

            curve1 = request.get_curve(get_orca_timestamp(d1), rate_curve_names).result()
            curve2 = request.get_curve(get_orca_timestamp(d2), rate_curve_names).result()
            compare_two_curves(curve1,curve2, anchor = d2.date() , curvenames =['Cuve t0', 'Curve t1'])

    Notes:
        Author: g48454
    """
    f, (ax1, ax2) = plt.subplots(2, 1, sharey=True)
    # plot the two curves one by one
    if compare_days is None:
        (curve1_x, curve1_y) = sample_curve_by_key_insturments(qt_curve1, anchor)
        (curve2_x, curve2_y) = sample_curve_by_key_insturments(qt_curve2, anchor)
    else:
        (curve1_x, curve1_y) = sample_curve_by_given_dates(qt_curve1, anchor , date_list=compare_days)
        (curve2_x, curve2_y) = sample_curve_by_given_dates(qt_curve2, anchor,  date_list=compare_days)
    ax1.plot(curve1_x,curve1_y,'ro')
    ax1.plot(curve2_x, curve2_y, 'go')

    (curve1_x_fine, curve1_y_fine) = sammple_curve_by_more_fine_grids(qt_curve1, anchor)
    (curve2_x_fine, curve2_y_fine) = sammple_curve_by_more_fine_grids(qt_curve2, anchor)
    ax1.plot(curve1_x_fine, curve1_y_fine, 'r--')
    ax1.plot(curve2_x_fine, curve2_y_fine, 'g--')
    # place the legend to the right of the subplot
    ax1.legend(curvenames , bbox_to_anchor=(0., 1.02, 1., .102), loc=3,
           ncol=2, mode="expand", borderaxespad=0.)
    ax1.set_title('Compare the two curves')
    ax1.set_xlabel('Year')
    ax1.set_ylabel('abs rate')
    # compare the curves
    if compare_days is None:
        common_date_list = list(set(get_key_instruments_dates(qt_curve1) + get_key_instruments_dates(qt_curve2)))
        common_date_list.sort()
    else:
        common_date_list = compare_days

    x = return_day_count_list(d = anchor,d_list=common_date_list)
    y = [qt_curve1.getVal(tempd) - qt_curve2.getVal(tempd) for tempd in common_date_list]
    max_diff= max([abs(abs_y) for abs_y in y])
    ax2.bar(x,y,width=0.8, color='b')
    ax2.set_title('Differences, max_diff = ' + str(max_diff))
    ax2.set_xlabel('Year')
    ax2.set_ylabel('abs rate')
    plt.show()
    return


def sammple_curve_by_more_fine_grids(qt_curve,anchor):
    date_list = get_plot_dates(qt_curve, anchor)
    (x, y) = sample_curve_by_given_dates(qt_curve, anchor, date_list)
    return (x,y)



def sample_curve_by_key_insturments(qt_curve,anchor):
    d_l = get_key_instruments_dates(qt_curve)
    (x_l, y_l) = sample_curve_by_given_dates(qt_curve, anchor, d_l)
    return (x_l,y_l)

def sample_curve_by_given_dates(qt_curve,anchor,date_list):
    x_l = return_day_count_list(anchor, date_list)
    y_l = [qt_curve.getVal(d) for d in date_list]
    return(x_l,y_l)

def get_key_instruments_dates(qt_curve):
    return qt_curve._get_dates()

def get_plot_dates(qt_curve , anchor):
    """
    The function will return a fine grid to plot the trend of the curve, the trend of the curve is corresponding to the interpolation method curve used.

    The function get all dates defined in the curve object and then also extend the curves to more fine grid, currently we assume the curve at least have one point in seven days.

    Args:
        qt_curve (qtoolkit curve format)  any curves defined as CurveInterpolated curve
        anchor (datetime.date) the anchor date of the curve

    Returns:
        (dataframe):   A list of datetime.date
    Notes:
        Author: g48454
    """
    basic_date_list = qt_curve._get_dates()
    currt = anchor
    additional_list = []
    while currt < basic_date_list[-1]:
        currt = qt.addTenor(currt,_step)
        additional_list.append(currt)
    out = list(set(basic_date_list+additional_list))
    out.sort()
    return out

def return_day_count_list(d, d_list):
    """
    Finding curve dates from a q-toolkit object, and returning them sorted

    Use daycount ACT36525 since default curve get from ORCA is using this one
    tested by Shengyao)....

    Args:
        qt_curve    (N/A):      XXXXXXXXXXXXX
        anchor      (N/A):      Some other description

    Returns:
        (????):   List of dates or????

    Example:
        The module is called (from python) like this::

            from core.graphics import curve

            dates = curve.get_plot_dates(xxxx,yyyy)


    Notes:
        Author: 48454 (Shengyao Zhu)
    """

    return [qt.yearfraction(d, x, qt.DayCount.ACT36525) for x in d_list]