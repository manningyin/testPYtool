"""
Module for creating interactive graphical SURFACE plots.

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       30may2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import plotly.graph_objs as go
import plotly.offline as po


def plot(dataframe,
         x_axis_var,
         y_axis_var,
         z_axis_var,
         dest_html_file,
         plot_title     = None,
         x_axis_label   = None,
         y_axis_label   = None,
         z_axis_label   = None,
         auto_open      = True,
         ):
    """
    Creates an interactive plotly three dimensional "Surface" plot in a HTML page.

    Please note that the structure of the dataframe is classical "tabular" form - not matrix.
    The surface points must be represented in three columns, representing the x, y and z axis.
    This means that each datapoint in the surface is one row in the input dataframe.

    Please see the example in this documentation...

    If you would prefer matrix form input, please consider adding support of both input forms.

    Args:
        dataframe       (dataframe):    Dataframe with all data that should be used in plot
        x_axis_var      (str):          Name of the variable in the dataframe that should be used as X-axis (first axis / first horizontal axis)
        y_axis_var      (str):          Names of the variables in the dataframe that should be used as Y-axis (second axis / second horizontal  axis)
        z_axis_var      (str):          Names of the variables in the dataframe that should be used as Z-axis (third axis / vertical axis)
        dest_html_file  (str):          Destination for the final htm(l) file. Full file path, including the html extension.
        plot_title      (str):          Title which will appear in the plot
        x_axis_label    (str):          (default = None, variable name will be used) Label for the X-axis, that will be shown in the plot
        y_axis_label    (str):          (default = None, variable name will be used)  Label for the Y-axis, that will be shown in the plot
        z_axis_label    (str):          (default = None, variable name will be used)  Label for the Z-axis, that will be shown in the plot
        auto_open       (bool):         (default = True) Choose False if the output file should not automatically be opened after creation
                                        (this could be a good ide if you are generating many files by running this function in a loop)

    Returns:
        None (but creates a plot in a html page)

    Raises:

    Example:
        The module is called (from python) like this::

            from core.graphics import surface
            import pandas as pd
            l = [
                {'x_axis': 1, 'y_axis': 1, 'z_axis': 4},
                {'x_axis': 1, 'y_axis': 2, 'z_axis': 5},
                {'x_axis': 1, 'y_axis': 3, 'z_axis': 3},
                {'x_axis': 1, 'y_axis': 4, 'z_axis': 2},
                {'x_axis': 2, 'y_axis': 1, 'z_axis': 5},
                {'x_axis': 2, 'y_axis': 2, 'z_axis': 7},
                {'x_axis': 2, 'y_axis': 3, 'z_axis': 4},
                {'x_axis': 2, 'y_axis': 4, 'z_axis': 3},
                {'x_axis': 3, 'y_axis': 1, 'z_axis': 7},
                {'x_axis': 3, 'y_axis': 2, 'z_axis': 8},
                {'x_axis': 3, 'y_axis': 3, 'z_axis': 3},
                {'x_axis': 3, 'y_axis': 4, 'z_axis': 2},
                {'x_axis': 4, 'y_axis': 1, 'z_axis': 4},
                {'x_axis': 4, 'y_axis': 2, 'z_axis': 4},
                {'x_axis': 4, 'y_axis': 3, 'z_axis': 4},
                {'x_axis': 4, 'y_axis': 4, 'z_axis': 4},
                ]

            df = pd.DataFrame(l)

            surface.plot(dataframe      = df,
                         x_axis_var     = 'x_axis',
                         y_axis_var     = 'y_axis',
                         z_axis_var     = 'z_axis',
                         dest_html_file = 'c:/Working/test.html',
                         plot_title     = 'This is some test plot',
                         x_axis_label   = 'My one axis',
                         y_axis_label   = 'My other axis',
                         z_axis_label   = 'The important measure',
                         auto_open      = True,
                         )

    Warning:
        Depending on your browser settings in Chrome you could experience problems displaying the graph.
        There should be no problems in Explorer or firefox...

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # Converting input dataframe from a three column table into a x * y matrix.
    # ===================================================================================
    df_matrix = dataframe.pivot(index   = x_axis_var,
                                columns = y_axis_var,
                                values  = z_axis_var,
                                ).as_matrix()

    data = go.Data([go.Surface(z = df_matrix)])

    # ===================================================================================
    # Adding title and axis labels.
    #
    # Using the input axis label if it has been chosen, otherwise using the
    # variable name...
    # ===================================================================================

    mod_x_axis_label = x_axis_label if x_axis_label is not None else x_axis_var
    mod_y_axis_label = y_axis_label if y_axis_label is not None else y_axis_var
    mod_z_axis_label = z_axis_label if z_axis_label is not None else z_axis_var

    layout = go.Layout( title   = plot_title,
                        scene   = go.Scene  (
                                            xaxis = go.XAxis(title = mod_x_axis_label),
                                            yaxis = go.YAxis(title = mod_y_axis_label),
                                            zaxis = go.ZAxis(title = mod_z_axis_label),
                                            )
                      )

    # ===================================================================================
    # Combining title and data into figure object
    # ===================================================================================
    figure = go.Figure(data = data, layout = layout)

    # ===================================================================================
    # Creating html page with plot
    # ===================================================================================
    po.plot(figure_or_data  = figure,
            show_link       = False,
            filename        = dest_html_file,
            auto_open       = auto_open,
            )

if __name__ == '__main__':
    from core.graphics import surface
    import pandas as pd

    l = [
        {'x_axis': 0, 'y_axis': 1, 'z_axis': 4},
        {'x_axis': 0, 'y_axis': 2, 'z_axis': 5},
        {'x_axis': 0, 'y_axis': 3, 'z_axis': 3},
        {'x_axis': 0, 'y_axis': 4, 'z_axis': 2},
        {'x_axis': 1, 'y_axis': 1, 'z_axis': 4},
        {'x_axis': 1, 'y_axis': 2, 'z_axis': 5},
        {'x_axis': 1, 'y_axis': 3, 'z_axis': 3},
        {'x_axis': 1, 'y_axis': 4, 'z_axis': 2},
        {'x_axis': 2, 'y_axis': 1, 'z_axis': 5},
        {'x_axis': 2, 'y_axis': 2, 'z_axis': 4},
        {'x_axis': 2, 'y_axis': 3, 'z_axis': 4},
        {'x_axis': 2, 'y_axis': 4, 'z_axis': 3},
        {'x_axis': 3, 'y_axis': 1, 'z_axis': 5},
        {'x_axis': 3, 'y_axis': 2, 'z_axis': 4},
        {'x_axis': 3, 'y_axis': 3, 'z_axis': 4},
        {'x_axis': 3, 'y_axis': 4, 'z_axis': 3},
        {'x_axis': 4, 'y_axis': 1, 'z_axis': 4},
        {'x_axis': 4, 'y_axis': 2, 'z_axis': 8},
        {'x_axis': 4, 'y_axis': 3, 'z_axis': 3},
        {'x_axis': 4, 'y_axis': 4, 'z_axis': 2},
        {'x_axis': 5, 'y_axis': 2, 'z_axis': 8},
        {'x_axis': 5, 'y_axis': 3, 'z_axis': 3},
        {'x_axis': 5, 'y_axis': 4, 'z_axis': 2},
        {'x_axis': 5, 'y_axis': 1, 'z_axis': 4},
        {'x_axis': 6, 'y_axis': 2, 'z_axis': 4},
        {'x_axis': 6, 'y_axis': 3, 'z_axis': 4},
        {'x_axis': 6, 'y_axis': 4, 'z_axis': 4},
        {'x_axis': 6, 'y_axis': 1, 'z_axis': 4},
        {'x_axis': 7, 'y_axis': 2, 'z_axis': 4},
        {'x_axis': 7, 'y_axis': 3, 'z_axis': 4},
        {'x_axis': 7, 'y_axis': 4, 'z_axis': 4},
    ]

    df = pd.DataFrame(l)

    surface.plot(dataframe      = df,
                 x_axis_var     = 'x_axis',
                 y_axis_var     = 'y_axis',
                 z_axis_var     = 'z_axis',
                 dest_html_file = 'c:/Working/test.html',
                 # plot_title     = None,
                 # x_axis_label   = None,
                 # y_axis_label   = None,
                 # z_axis_label   = None,
                 auto_open      = False,
                 )
