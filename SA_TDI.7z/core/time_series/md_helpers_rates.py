# this is the ir rate curve code Arnold have hand over to market data team
# put it here because market data team has requested help on integrate this part of the code to general core.time_series
# working still going on to improve the setup


import datetime as dt
import quantum as qt
from core.connection import orca_connect
from core.utils.date_helper import to_datetime
from orca.types import ModelSpecification, InfinityMarketDataName, CurveType
from core.caching.abstract_loader_classes import MatrixLoader


_ORCA_tag = 'uat'
DiscName = {'USD': 'USLI_REV', 'CAD': 'CALI_REV', 'CZK': 'CZPR_REV', 'DKK': 'DKCI_REV', 'HKD': 'HDHI_REV',
            'THB': 'THLI_REV', 'MXN': 'MXME_REV', 'ZAR': 'ZAJI_REV', 'NZD': 'NZLI_REV',
            'HUF': 'HULI_REV', 'TRY': 'TYLI_REV', 'AUD': 'AULI_REV',
            'JPY': 'JYLI_REV', 'RUB': 'RULI_REV', 'IDR': 'IDLI_REV', 'ARS': 'ARLI_REV', 'ISK': 'ISLI_REV',
            'CHF': 'CHLI_REV', 'GBP': 'GBLI_REV', 'NOK': 'NKNI_REV', 'PLN': 'PLWI_REV',
            'BRL': 'BRLI_REV', 'CNY': 'CNLI_REV',
            'LVL': 'LVLI_REV', 'SGD': 'SGLI_REV', 'SEK': 'SESTI_REV', 'EUR': 'EIEU_REV',
            'PHP': 'PHLI_REV', 'MYR': 'MYLI_REV', 'INR': 'INLI_REV', 'COP': 'COLI_REV', 'KWD': 'KWLI_REV', 'EEK': 'EKTA_REV', 'LTL': 'LTLI_REV', 'SAR': 'SALI_REV'}




#for ccy in DiscName:
#    if qt.Currency(ccy) not in currencies:
#        print ccy


def get_libor_curves(idate,currencies):
    curves = dict()
    _service_requests = orca_connect.get_orca_request()
    instanceCode = qt.MarketDataInstanceCode.CLOSE
    curve_keys = [InfinityMarketDataName(name, qt.Currency(ccy), instanceCode) for ccy, name in DiscName.items()]
    try:
        c = _service_requests.get_curves(orca_connect.get_orca_timestamp(idate), curve_keys).result()
    except:
        c = []
        for key in curve_keys:
            try:
                c += _service_requests.get_curves(orca_connect.get_orca_timestamp(idate), [key]).result()
                print(c)
            except Exception as e:
                c += [e]
    for key in curve_keys:
        curve_name = key.currency.stringName + '.DISC.LIBOR.CURVE'
        curves[curve_name] = c[key]
    return curves

def get_curvenames(currencies):
    _service_requests = orca_connect.get_orca_request()

    for ccy in currencies:
        for c in _service_requests.request_risk_factors_interest_rate_curves(ccy.stringName).result():
            yield c['curve_name']

def get_model_param(currencies):
    USD = qt.Currency.USD
    EUR = qt.Currency.EUR
    return {'model_name': qt.ModelName.LINEAR_RATE, 'numeraire_currency': EUR,
            'discount_type': qt.DiscountType.LIBOR,
            'csa_currencies': [USD],
        'libor_currencies': currencies if USD in currencies else currencies +[USD],
        'equity_names': [],
        'credit_names': [],
        'commodity_names': [],
        'fx_pairs': []}


def orca_model(idate, currencies):
    from orca.models import factory
    import orca.types

    _service_requests = orca_connect.get_orca_request()

    holiday_factory = _service_requests.get_holiday_factory_for_all_centers().result()

    model_factory = factory.Factory.from_service_bundle(orca_connect.get_orca_timestamp(idate), holiday_factory, _service_requests)
    model_param = get_model_param(currencies)
    model_spec = orca.types.ModelSpecification(**model_param)
    return model_factory.create(orca.types.ModelConfigurationContext.make_eod_context(), model_spec)


def get_curves(idate , currencies):
    """
    Get interest rate curves from ORCA using a model

    The function has several steps:
    -   Request a model from ORCA
    -   Decompose the model into curves
    -   Convert FORWARD curves into zero coupon curves
    -   Handle available discounting curves
    -   Handle other curves
    """
    # convert list of string to qt

    qt_currencies = [qt.Currency(x) for x in currencies]

    idate = to_datetime(idate).date()

    if idate < dt.date(2012, 1, 1):
        return get_libor_curves(idate, qt_currencies)

    # ===================================================================================
    # Build linear rates model from orca by using different currencies
    # ===================================================================================
    curves = dict()
    # Request ORCA model
    # The Orca model is built from
    _service_requests = orca_connect.get_orca_request()

    model_param = get_model_param(qt_currencies)
    model_spec = ModelSpecification(**model_param)
    model_configuration = _service_requests.get_model_configuration(
        orca_connect.get_orca_timestamp(idate), "ORCA_REVAL", model_spec
    ).result()
    model = orca_model(idate, qt_currencies)

    orca_curves_response = {}
    for ccy in qt_currencies:
        orca_curves_response[ccy] = _service_requests.request_interest_rate_risk_factors(ccy).result()

    curve_info = dict()
    for ccy in qt_currencies:
        orca_curves_response_ccy = orca_curves_response[ccy]
        for c in orca_curves_response_ccy:
            curve_info[c.name] = c

    # FORWARD curves needs zero coupon conversion
    for ccy in qt_currencies:
        fwd_curve = model.getFwdCurve(ccy)
        if type(fwd_curve) is qt.FwdCurveLif:
            tenors = fwd_curve.tenors
            zc_curves = qt.FwdCurveLif.getZeroRateCurves(fwd_curve, '1M')
            orca_curves_response_ccy = orca_curves_response[ccy]
            for c in orca_curves_response_ccy:
                if c.type is CurveType.FORWARD:
                    x = c.name.split('.')
                    # Store the zero coupon curve
                    curve_name = '.'.join([x[0],x[1],'ZCPN',x[3]])
                    curves[curve_name] = zc_curves[tenors.index(c.index_tenor)]
                    # Store the forward rate curve
                    fwd_vals = [fwd_curve.fwdRate(d, c.index_tenor, qt.DayCount.ACT36525) for d in zc_curves[tenors.index(c.index_tenor)].dates]
                    curves[c.name] = qt.CurveCatrom.make(zc_curves[tenors.index(c.index_tenor)].dates, fwd_vals)

    extra_curves = []
    extra_keys = []
    ctx = orca_connect.get_orca_timestamp(idate)   #RV
    for spec in model_configuration.market_data_specs:
        if spec.risk_factor_name not in curve_info:
            continue
        if '.FWD.' in spec.risk_factor_name:
            continue
        if '.DISC.FUNDING' in spec.risk_factor_name:
            #raise NotImplementedError("DISC.FUNDING.CURVE is in the spec")
            extra_curves.append(spec.risk_factor_name)
            extra_keys.append(InfinityMarketDataName(spec.market_data_name.name, spec.market_data_name.currency, spec.market_data_name.instance_code))
            #continue
        curves[spec.risk_factor_name] = _service_requests.get_curve(ctx,spec.market_data_name).result() #RV

    for ccy, name in DiscName.items():
        if qt.Currency(ccy) not in qt_currencies:
            extra_curves.append('RATE.' + ccy + '.DISC.LIBOR')
            extra_keys.append(InfinityMarketDataName(name, qt.Currency(ccy), qt.MarketDataInstanceCode.CLOSE))

    c = _service_requests.get_curves(orca_connect.get_orca_timestamp(idate), extra_keys).result()
    for i, key in enumerate(extra_keys):
        curve_name = extra_curves[i]

        curves[curve_name] = c[key]

    for curve_name, curve in get_basis_curves(curves):
        curves[curve_name] = curve

    return curves


def get_basis_curves(curves):
    items = [(curve_name, curve)
                 for curve_name, curve in curves.items()
                 if '.DISC.LIBOR' not in curve_name]
    for curve_name, curve in items:
        if '.FWD.' in curve_name:
            # Don't mix apples and bananas
            # I think what it try to say is forward rate is not zc curve
            continue
        x = curve_name.split('.')
        main = curves[x[0]+'.'+x[1]+'.DISC.LIBOR']
        domain = []
        values = []
        if hasattr(curve,'dates'):
            for d in curve.dates:
                domain.append(d)
                values.append(curve.getVal(d) - main.getVal(d))
        elif hasattr(curve,'domainValues'):
            for d in curve.domainValues():
                domain.append(d)
                values.append(curve.getVal(d) - main.getVal(d))
        else:
            raise ValueError
        basis_name = curve_name#'.'.join([x[0], x[1], 'TENORBASIS']+x[2:])
        yield basis_name, qt.CurveLinear.make(domain, values)


class OrcaIRCurveLoader(MatrixLoader):
    # a temp loader to load the ir curve with caching functions
    def __init__(self, startd, endd, load_from_source=False, cache_path=None):
        MatrixLoader.__init__(self, names=["All"],
                              startd=startd,
                              endd=endd,
                              load_from_source=load_from_source,
                              cache_path=cache_path)

    def source_loading_function(self, names, date):
        all_ccys = ["EUR","NOK","DKK","USD","CHF","SEK","HKD","CAD","JPY","ZAR","GBP","AUD",
                    "PLN","CZK","HUF","NZD","TRY","RUB","MXN","ISK","HUF"]
        try:
            temp = get_curves(currencies= all_ccys,idate=date)
        except Exception as e:
            print(str(e) + ' ' + str(date.isoformat()))
            temp = dict()
        return {(date,"All"): temp}


if __name__ == '__main__':
    get_curves(dt.datetime(2019,3,15),["EUR","NOK","DKK","USD","CHF","SEK","HKD","CAD","JPY","ZAR","GBP","AUD",
                    "PLN","CZK","HUF","NZD","TRY","RUB","MXN","ISK","HUF"])
    # temp = OrcaIRCurveLoader(startd = dt.datetime(2018,2,1),
    #                 endd = dt.datetime(2018,2,3)
    #                        ).data
    # print(temp.keys())