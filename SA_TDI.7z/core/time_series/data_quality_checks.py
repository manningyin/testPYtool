'''
This module containes a few functions that allow to perform data quality checks on time series.
For example, checks on the number of repeating data.

Notes:
    Author: G49708

    ======= =========   =========   ==============================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ==============================================================================
    1       07/08/2018   G49708     Creation of the code
    ======= =========   =========   ==============================================================================


'''


def checks_repeating_spreads(df, file_name):
    """
    This function checks ticker by ticker, the number of spreads that are repeating.
    
    Args:
        df        (dataframe): a dataframe containing time series for different tickers/names
        file_name (str): the name of the file that will contain the output
        
    Returns: a csv file containing:
        the consecutive number of days with no daily changes
        the total number of consecutive days with no daily changes
        the maximum number of consecutive days with no daily changes
        the total number of days in the ticker time series
    """
    #f = open(file_name, 'w')
    file_name.write("TICKER; TOTAL_COUNT; SUM; MAX; TOTAL_DAYS\n")
    ticker_list = df.TICKER.unique()
    for i in ticker_list:
        ticker_df = df.loc[df['TICKER'] == i]        
        spreads = ticker_df.SPREAD5Y.values        
        total_count = []
        count = 0
        for j in range(0,len(spreads)-1):
            if spreads[j]==spreads[j+1]:
                count = count+1
            else:
                if count !=0: 
                    total_count.append(count+1)
                count = 0
        if count !=0: 
            total_count.append(count+1)
        try:
            max_r = max(total_count)
        except:
            max_r = 0
        try:
            sum_r = sum(total_count)
        except:
            sum_r = 0
        file_name.write("%s; %s; %d; %d; %d\n" %(i, total_count, sum_r, max_r, len(spreads)))
    #f.close()

def checks_repeating_data(ts_list):
    """
    Given a list representing a time series, this function checks for repeating data. 
    
    Args:
    ts_list    (list): The time series to be analysed
                            
    Returns:
        (dictionary): containes
            'repeating_data' the number of consecutive days with no daily changes
            'sum_repeating' the total number of consecutive days with no daily changes
            'max_repeating' the maximum number of consecutive days with no daily changes
            'len_ts': the total length of the time series
    """
    total_count = []
    count = 0

    for j in range(len(list(ts_list))-1):
        if ts_list[j]==ts_list[j+1]:
                count = count+1
        else:
            if count !=0: 
                total_count.append(count+1)
            count = 0
    if count !=0: 
        total_count.append(count+1)
    try:
        max_r = max(total_count)
    except:
        max_r = 0
    try:
        sum_r = sum(total_count)
    except:
        sum_r = 0
    return {'repeating_data': total_count, 'sum_repeating': sum_r, 'max_repeating': max_r, 'len_ts': len(ts_list)}