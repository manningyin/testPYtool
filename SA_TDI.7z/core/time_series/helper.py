import os

import pandas as pd

from core.caching.cache_driver import easy_cache
from core.utils import directory


def get_bond_swap_basis_mapping_dict():
    """
    "Hard" mapping of bond swap basis risk factors to market data.

    This is used both when generating bond swap basis curves, and storing it in DAMDS - AND when using the curves
    for scenario generation etc.

    Args:
        No Input...

    Returns:
        (dict of dicts):   One dictionary for each bond swap basis (curve)

    Example:
        The module is called (from python) like this::

            from core.time_series import helper

            bond_swap_basis_mapping = helper.get_bond_swap_basis_mapping_dict()

    Warning:

    Notes:
        Author: Shengyao (documented by JBrandt (g50444))
    """

    # Creating path for mapping csv-file
    codelib_path = directory.codelib_path()
    mapping_path = r"\\dcd00cb-evs02\ABD\MRM\20 Data\FRTB Credit\bond_swap_basis_mapping.csv"

    # Reading csv file as dataframe
    df = pd.read_csv(filepath_or_buffer  = mapping_path)
    df = df.set_index("Curve Name")
    df["Source Curve Name"] = [str(x) for x in df["Source Curve Name"]]

    # Returning dictionary
    return df.to_dict('index')


def getBackCurrencyForEachCurve(arg):
    return {
        'DKKGOV': 'DKK',
        'SEKGOV': 'SEK',
        'FIMGOV': 'EUR',
        'NOKGOV': 'NOK',
        'DKKMTGNYKSOFTBLT': 'DKK',
        'SEKMTGBLEND': 'SEK'
    }.get(arg, 'EUR')


def return_curve_names_in_scope():
    mapping_dict = get_bond_swap_basis_mapping_dict()
    return mapping_dict.keys()


def return_ccy(curveName):
    mapping_dict = get_bond_swap_basis_mapping_dict()
    return mapping_dict[curveName]["ccy"]

def get_ccy(isin):
    return "EUR"

def get_global_buckets():
    return ['0D', '1D', '2D', '5D', '7D', '10D', '14D', '1M', '2M', '3M', '4M', '5M', '6M', '7M', '8M', '9M', '10M',
            '11M', '1Y', '2Y', '3Y', '4Y', '5Y', '6Y', '7Y', '8Y', '9Y', '10Y', '11Y', '12Y', '13Y', '14Y',
            '15Y', '16Y', '17Y', '18Y', '19Y', '20Y', '21Y', '22Y', '23Y', '24Y', '25Y', '26Y', '27Y', '28Y', '29Y',
            '30Y', '35Y', '40Y', '50Y']

if __name__ == '__main__':
    print(get_bond_swap_basis_mapping_dict())