from core.time_series import hs_market_data_factory
from datetime import datetime
import quantum as qt
from core.utils.date_helper import to_datetime

step = "-1M"
# current period
start_date = datetime(2015,3,1)
ed = datetime(2017,4,30)
sd = qt.addTenor(ed,step)
while sd > start_date.date():
    print(ed,sd)
    print("---- create the factory ----- ")
    s1 = hs_market_data_factory.BondSwapBasisFactory(start_date=to_datetime(sd),end_date = to_datetime(ed))
    print("---- writing data to damds -----")
    s1.write_shocked_timeseries_to_db(source="DAMDS")
    ed = sd
    sd = qt.addTenor(sd, step)


# current period
start_date = datetime(2007,4,30)
ed = datetime(2010,3,31)
sd = qt.addTenor(ed,step)
while sd > start_date.date():
    print(ed,sd)
    print("---- create the factory ----- ")
    s1 = hs_market_data_factory.BondSwapBasisFactory(start_date=to_datetime(sd),end_date = to_datetime(ed))
    print("---- writing data to damds -----")
    s1.write_shocked_timeseries_to_db(source="DAMDS")
    ed = sd
    sd = qt.addTenor(sd, step)