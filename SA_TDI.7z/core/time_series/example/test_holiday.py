from core.connection.orca_connect import get_orca_request

req = get_orca_request()
_holiday_factory = req.get_holiday_factory_for_all_centers().result()