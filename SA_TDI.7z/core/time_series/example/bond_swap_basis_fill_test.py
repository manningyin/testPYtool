from core.time_series import hs_market_data_factory
from datetime import datetime
from core.utils.date_helper import to_datetime
import pandas as pd
ed = datetime(2017,4,20)
sd = datetime(2017,4,10)

print(ed,sd)
pd.set_option('display.max_rows', 200)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

print("------------calculate zspread -----------")
s1 = hs_market_data_factory.ZSpreadFactory(start_date=to_datetime(sd),end_date = to_datetime(ed))
print(s1.shocked_time_series)
s1.write_shocked_timeseries_to_db(source="DAMDS")

print("------------calculate bond swap basis -----------")
s2 = hs_market_data_factory.BondSwapBasisFactory(start_date=to_datetime(sd),end_date = to_datetime(ed))
print(s2.shocked_time_series)
s2.write_shocked_timeseries_to_db(source="DAMDS")