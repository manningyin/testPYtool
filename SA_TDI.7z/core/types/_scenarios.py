from enum import Enum


class Calendar(Enum):
    Mars = 0
    Euro = 1


class NoValue(Enum):
    def __repr__(self):
        return '<%s.%s>' % (self.__class__.__name__, self.name)


class MarketDataUnit(NoValue):
    PERCENTAGE = "%"
    NONE = "NONE"


class ObservationPeriod(NoValue):
    RTPL = 'RTPL'
    SPL = 'SPL'
    VAR = 'VAR'
    CURRENT = 'CURRENT'
    CURRENT_1d = 'CURRENT_1d'
    STRESSED = 'STRESSED'
    FULL = 'FULL'
    ONEDAY = 'ONEDAY'
    ONEMONTH = 'ONEMONTH'
    SENS = 'SENS'

    def shock_horizon(self):
        """
        Each observation period has a shock horizon. This is defined here.

        Returns:
            (int):  Shock horizon

        Notes:
            Author: JBrandt (g50444)
        """
        if self in [ObservationPeriod.RTPL, ObservationPeriod.SPL, ObservationPeriod.SENS]:
            out = 1
        elif self == ObservationPeriod.CURRENT_1d:
            out = 1
        elif self == ObservationPeriod.CURRENT:
            out = 1
        elif self == ObservationPeriod.STRESSED:
            out = 1
        elif self == ObservationPeriod.VAR:
            out = 1
        else:
            raise NotImplementedError("The Observation Period have not been implemented for " + str(self))
        return out

    def scenario_days(self):
        if self in [ObservationPeriod.RTPL, ObservationPeriod.SPL, ObservationPeriod.SENS]:
            out = 1
        elif self == ObservationPeriod.CURRENT_1d:
            out = 1
        elif self == ObservationPeriod.CURRENT:
            out = 249
        elif self == ObservationPeriod.VAR:
            out = 499
        else:
            raise NotImplementedError("The observation period have not been implemented for " + str(self))
        return out

    def scenario_date_offset(self):
        if self in [ObservationPeriod.RTPL, ObservationPeriod.SPL]:
            out = 1
        elif self == ObservationPeriod.VAR:
            out = -1
        else:
            out = 0
        return out

    def stressed_period(self):
        if self == ObservationPeriod.STRESSED:
            return {'start_date': '2008-06-03',
                    'end_date': '2009-06-01'}
        else:
            raise NotImplementedError("Stressed period is only defined for stressed VaR")


class Scope(NoValue):
    FULL = 'FULL'
    REDUCED = 'REDUCED'
    COMPLETE = 'COMPLETE'


class RiskClass(NoValue):
    ALL = 'ALL'
    IR = 'IR'
    CS = 'CS'
    EQ = 'EQ'
    FX = 'FX'
    CO = 'CO'
    IF = 'IF'


class MarketDataSourceType(NoValue):
    MARS = 'mars'
    DAMDS = 'damds'
    MDHUB = 'mdhub'


class HorizonScalingMethod(NoValue):
    NONE = 'None'


class ShockType(NoValue):
    """
    Enum class for known types of shocks.

    Addition:       scenario valuation price = md + scenario shock
    Multiplication: scenario valuation price = md * shock
    Substitution:   scenario valuation price = shock

    Notes:
        Author: JBrandt (g50444)
    """
    ADDITION = 'ADDITION'
    MULTIPLICATION = 'MULTIPLICATION'
    SUBSTITUTION = 'SUBSTITUTION'
    ADDITION_IN_FORWARD_RATES = 'ADDITION_IN_FORWARD_RATES'
    DOMAINUNION_MULTIPLICATION = 'DOMAINUNION_MULTIPLICATION'
    DOMAINUNION_ADDITION = 'DOMAINUNION_ADDITION'


class LiquidityHorizon(NoValue):
    LH10 = 10
    LH20 = 20
    LH40 = 40
    LH60 = 60
    LH120 = 120


class TimeSeriesStructure(NoValue):
    CURVE = 'curve'
    POINT = 'point'
    SURFACE = 'surface'


class AssetClass(Enum):
    IR = 'interest'
    CS = 'spread'
    FX = 'currency'
    EQ = 'equity'


class VaRPeriod(Enum):
    Historic = 2000
    Stressed = 102


class ScenarioCategory(Enum):
    Historical = 'Historical'
    Deterministic = 'Deterministic'
