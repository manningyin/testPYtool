from enum import Enum
from core.risk_factor import risk_factor_utils


class CreationDetails:
    @property
    def predicate(self):
        return risk_factor_utils.Property(group='creationDetails',
                                          name=type(self).__name__,
                                          values=self.name)

    def __or__(self, other):
        if hasattr(other, 'predicate'):
            return self.predicate | other.predicate
        else:
            return self.predicate | other

    def __and__(self, other):
        if hasattr(other, 'predicate'):
            return self.predicate & other.predicate
        else:
            return self.predicate & other

class riskFactorType(CreationDetails, Enum):
    RfInterestRate = 0
    RfCcyPair = 1
    RfBondSwapBasis = 2
    RfResidualZspread = 3
    RfHazardRate = 4
    RfRecoveryRate = 5
    RfRefinanceRate = 6
    RfInterestAtmVolatility = 7
    RfInflationRate = 8

class isRiskModelBucket(CreationDetails, Enum):
    TRUE = 0

class curveMarket(Enum):
    OIS = 0
    LIBOR = 1
    FORWARD = 2
    REPO = 3


class curveType(Enum):
    DISCOUNT = 1
    FORWARD = 2
    BASIS = 3
    SPREAD = 4
    ZSPREAD = 5


class discountingType(Enum):
    GOV_DK = 0
    GOV_SE = 1
    GOV_NO = 2
    GOV_US = 3
    GOV_DE = 4
    GOV_FR = 5
    GOV_FI = 6
    GOV_LU = 7
    GOV_IT = 8
    GOV_AT = 9
    MTG_DK = 10


class discountType(Enum):
    GOVERNMENT = 0
    MORTGAGE = 1
    COVERED = 2


class issuerCountry(Enum):
    DK = 0
    SE = 1
    NO = 2
    US = 3
    FI = 4
    FR = 5
    DE = 6
    LU = 7
    IT = 8
    AT = 9


class LabelKey(Enum):
    master = 0
    orca = 1


class rfLabels(Enum):
    issuerType = 0
    issuerCountry = 1
    foreignCurrency = 2
    curveType = 3
    currency = 4
    issuerCurrency = 5
    bucket = 6
    riskFactorType = 7
    discountType = 8
    domesticCurrency = 9
    volatilityType = 10
    volatilityModel = 11
    maturityTenor = 12
    underlyingTenor = 13
    curveMarket = 14
    isZeroCoupon = 15
