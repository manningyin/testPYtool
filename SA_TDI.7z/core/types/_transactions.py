from enum import Enum
from core.utils import error_handler
from core.connection import database_connect
import pandas as pd
import pyodbc
import pickle
import hashlib
import orca.types
mars_trade_link_table_mapping = {'INFINITY': dict(table_name='TRADE_GNF_LINK', column_name='GNF_TRADE_ID'),
                                 'WALLSTREET': dict(table_name='TRADE_WSM_LINK', column_name='WSM_DEAL_NUMBER'),
                                 'CALYPSO': dict(table_name='TRADE_WOC_LINK', column_name='WOC_SU_KEY'),
                                 'MUREX': dict(table_name='TRADE_MRX_LINK', column_name='MRX_SU_KEY'),
                                 'IFONDS': dict(table_name='TRANS_IFO_LINK', column_name='IFO_ORDRENR'),
                                 'UFONDS': dict(table_name='TRANS_UFO_LINK', column_name='UFO_LOEBENR'),
                                 }
mars_source_name_mapping = {'GNF': 'INFINITY',
                            'WSM': 'WALLSTREET',
                            'WOC': 'CALYPSO',
                            'MRX': 'MUREX',
                            'IFO': 'IFONDS',
                            'UFO': 'UFONDS',
                            }


class PositionType(Enum):
    Holding = 'effect'
    Trans = 'trade'

    def __eq__(self, other):
        return self.name == other.name and self.value == other.value


class Portfolio(Enum):
    Markets = 50004
    Treasury = 53006
    Group = 50000
    Pensions = 30000
    MMNORGE = 6100100


class TransactionTypes(object):
    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return '%s(%s)' % (self.__class__.__name__, ', '.join(sb))

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return self.__dict__ == other.__dict__

    def __hash__(self):
        dump = pickle.dumps(tuple(self.__dict__.items()), -1)
        return int(hashlib.md5(dump).hexdigest(), 16)

    @classmethod
    def from_dict(cls, dictionary):
        return cls(**dictionary)

    def get_product_type_from_mars(self):
        """
        Returns:
            (str): the MARS product type for given ISIN or trade_id

        Notes:
            Author: g48606
        """
        if self.__class__ is TradeIdentifier:
            mars_trade_id = self.mars_trade_id()
            sql_string = """select B.NAME PRODUCT
                            from MARSP.TRADE a, MARSP.PRODUCT b
                            where A.TRADE_ID = %(mars_trade_id)s
                            and A.PRODUCT_ID = B.PRODUCT_ID""" % locals()
        elif self.__class__ is SecurityIdentifier:
            isin = self.ISIN
            sql_string = """select distinct (b.CURRENCY_ID || ' ' || C.NAME) PRODUCT
                              from MARSP.ISIN_EFFECT a, MARSP.EFFECT B, MARSP.EFFECT_GRP c
                              where a.ISIN = '%(isin)s'
                              and a.EFFECT_ID = b.EFFECT_ID
                              and b.EFFECT_GRP_ID = c.EFFECT_GRP_ID""" % locals()
        else:
            error_handler.track_error(comments="Transaction type not recognized")
            return 'UNIDENTIFIED'
        conn = pyodbc.connect(database_connect.get_string('INFOP'))
        df = pd.read_sql(sql_string, conn)
        conn.close()
        out = 'UNIDENTIFIED' if df.empty else df['PRODUCT'][0]
        return out


class TradeIdentifier(TransactionTypes):
    def __init__(self, trade_id, source_system, **kwargs):
        self.trade_id = trade_id
        self.source_system = source_system
        self.__dict__.update(kwargs)

    def to_tuple(self):
        return self.trade_id, self.source_system

    def mars_trade_id(self):
        """
        This function converts the trade identifier to a MARS trade id

        Notes:
            Author: g48606
        """
        try:
            trade_link_table = mars_trade_link_table_mapping[self.source_system]
        except KeyError:
            error_msg = "Alias mapping for provided source system has not yet been added. Please go to " \
                        "core.types.transaction_types.mars_trade_link_table_mapping and add the mapping"
            raise Exception(error_msg)
        trade_id = self.trade_id
        table_name = trade_link_table['table_name']
        column_name = trade_link_table['column_name']

        sql_string = """select A.TRADE_ID
                        from MARSP.%(table_name)s A
                        where A.%(column_name)s = %(trade_id)s""" % locals()
        conn = pyodbc.connect(database_connect.get_string('INFOP'))
        df = pd.read_sql(sql_string, conn)
        conn.close()
        return int(df['TRADE_ID'][0])

    @classmethod
    def from_mars_trade(cls, mars_trade):
        """
        This function converts a MARS trade_id to a trade identifier

        Notes:
            Author: g48606
        """
        sql_string = "select DATA_SOURCE_ID, DATA_SOURCE_IDENTITY from MARSP.TRADE where TRADE_ID = %s" % mars_trade
        df = pd.read_sql(sql_string, pyodbc.connect(database_connect.get_string('INFOP')))
        if df.empty:
            raise ValueError
        data_source_id = df['DATA_SOURCE_ID'][0]
        if data_source_id not in mars_source_name_mapping:
            error_msg = "Alias mapping for provided source system has not yet been added. Please go to " \
                        "core.types.transaction_types.mars_source_name_mapping and add the mapping"
            raise KeyError(error_msg)
        source = mars_source_name_mapping[data_source_id]
        if source == 'CALYPSO':
            return cls.from_mars_trade_to_bloomberg(mars_trade)
        trade_id = df['DATA_SOURCE_IDENTITY'][0].split('/')[-1]
        return cls(trade_id=trade_id, source_system=source)

    @classmethod
    def from_mars_trades(cls, mars_trades):
        return [cls.from_mars_trade(x) for x in mars_trades]

    def to_orca(self):
        source = getattr(orca.types.SourceSystem, self.source_system)
        return orca.types.TradeIdentifier(self.trade_id, source)

    def to_trade_spec(self):
        return orca.types.TradeSpecification([self.to_orca()])

    @classmethod
    def from_mars_trade_to_bloomberg(cls, mars_trade_id):
        from core.connection import api
        sql = "select th_message_id from marsp.th_recon_trade where trade_id = %s" % str(mars_trade_id)
        df = pd.read_sql(sql, pyodbc.connect(database_connect.get_string('INFOP')))
        if df.empty:
            df = pd.read_sql(sql, pyodbc.connect(database_connect.get_string('INFO3D')))
        if df.empty:
            raise ValueError
        th_id = df['TH_MESSAGE_ID'][0]
        th_out = api.trade_position_api().trade_controller.get_trades_by_tradehub_message_ids([th_id])
        th_message_id = None
        if th_out:
            bbg_trade = th_out[0].source_trade_id
            if bbg_trade is None:
                bbg_trade = int(th_out[0].nordea_trade_id.split('-')[-1])
            source = th_out[0].source
            th_message_id = th_out[0].tradehub_message_id
        else:
            bbg_trade = None
            source = 'BLOOMBERG'

        return cls(trade_id=bbg_trade, source_system=source, th_message_id=th_message_id)


class SecurityIdentifier(TransactionTypes):
    def __init__(self, ISIN, currency=None):
        self.ISIN = ISIN
        self.currency = currency

    def to_tuple(self):
        return self.ISIN, "Security", self.currency

    def to_orca(self):
        return orca.types.SecurityIdentifier(self.ISIN, orca.types.SecurityType.BOND)


def get_trade_spec(positions):
    """
    For each pair of trade_id and source system, a TradeIdentifier is created. The TradeIdentifier is a class with 2
    attributes: trade_id and source system. It is used by ORCA to identify trades

    In case the source system is not recognized by the TradeIdentifier, an exception is raised

    Notes:
        Author: g48606
    """
    trades, securities = [], []
    for p in positions:
        if isinstance(p, TradeIdentifier):
            trades.append(p.to_orca())
        elif isinstance(p, SecurityIdentifier):
            securities.append(p.to_orca())
    return orca.types.TradeSpecification(booked_trade_identifiers=trades, security_identifiers=securities)


if __name__ == '__main__':
    # print(TradeIdentifier.from_mars_trade_to_bloomberg(211383096))
    print(TradeIdentifier.from_mars_trades([210711202,211382678,211382631,208409154,211437982,211438539,211437937,211438781]))

    # a = SecurityIdentifier(ISIN="DK0002011386", currency="EUR")
    # b = a.__dict__
    # print(a)
    # print(b)
    #
    # # TODO: figure out how to filter out un-defined attribute
    # print(SecurityIdentifier.from_dict(b))
    #
    # c0 = TradeIdentifier(trade_id='2661435', source_system='INFINITY')
    # print(c0.__dict__)
    # print(c0)
    #
    #
