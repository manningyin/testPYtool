import operator
import datetime as dt
import pandas as pd
import six
if six.PY3:
    from inspect import getfullargspec
else:
    from inspect import getargspec as getfullargspec
from core.utils import version_independent
from itertools import product
import quantum as qt
from enum import Enum
from core.utils import shock_days
from core.utils import date_helper
import pyodbc
from core.connection import database_connect
import warnings
from core.utils import error_handler


class CurveInterpolation(Enum):
    """
    Interpolation types available in qToolkit for curve interpolation
    """
    CurveLinear = 'Linear'
    CurveCatrom = 'Catrom'
    CurveFlat = 'Flat'
    CurveSpline = 'Spline'
    CurveCubicSpline = 'CubicSpline'

    def __str__(self):
        return self.value


class SurfaceInterpolation(Enum):
    """
    Interpolation types available in qToolkit for surface interpolation
    """
    SurfaceDateTenorLinear = 'Double linear'

    def __str__(self):
        return self.value


class MarketDataObject:
    """
    Parent class for the 3 types of market data objects (surface, curve and point).

    Initializer declares variables used in the child classes.
    Other functions overloads representation (string) and basic arithmetic functions (+, -, \*, /)

    Args:
        data            (data):         Market data values: dataframe, series, or float. Depends on the child class
        valuation_date  (date):         Anchor date of the data, used for converting between tenors and maturity dates
        identifier      (str):          Identifier of the market data (name or similar)
        database_date   (date):         Optional argument for database_date for extracted data

    Notes:
        Author: g48606 (Oskar)
    """
    def __init__(self, data, valuation_date, identifier='N/A', database_date=None):
        self.data = data
        self.identifier = identifier
        self.valuation_date = valuation_date
        self.database_date = database_date
        self.keys = []  # Defaulting keys with an empty list. We override this attribute in Surface and Curve
        self.holidays = self.get_holidays()
        self._index_type = self.index_type()

    @staticmethod
    def date_string(date_):
        """
        Returns date / list of dates on the format 'YYYY-MM-DD'. If element is not a datetime.date / datetime.datetime,
        we just return the default string representation of the date instead
        """
        if hasattr(date_, '__iter__'):
            out = str([str(x.date()) if hasattr(x, 'date') else str(x) for x in date_])
        else:
            out = str(date_.date()) if hasattr(date_, 'date') else str(date_)
        return out

    @staticmethod
    def concatenate_args(arg1, arg2):
        """
        Function used for the string representation when adding two class instances. Use cases are e.g. concatenating
        two different valuation dates into a list, taking into account whether the input valuation dates are lists
        already
        """
        if arg1 == arg2:
            out = arg1
        else:
            date1_list = arg1 if isinstance(arg1, list) else [arg1]
            date2_list = arg2 if isinstance(arg2, list) else [arg2]
            out = date1_list + date2_list
        return out

    def get_holidays(self):
        """
        Note from Oskar: I heard from Arnold that main currencies (e.g. USD, EUR and JPY) runs on the so-called 'LIF'
        setup, which always uses EUR holiday calender, whereas all other (exotic) currencies will use local calendar.

        This is not the best place to put this logic.. maybe we should use some service from ORCA to do this?

        TODO: consider, this part of the code should not have connection to orca, market data object should be independent
        """
        try:
            ccy = self.identifier.split('.')[0]
            assert(len(ccy) == 3)
        except:
            ccy = 'EUR'
        if ccy in ('AUD', 'BRL', 'CAD', 'CZK', 'MXN', 'PLN', 'RUB', 'TRY', 'ZAR'):
            qt_ccy = getattr(qt.Currency, ccy)
            holiday = shock_days.ORCA_holidays([qt_ccy])[qt_ccy]
        else:
            holiday = shock_days.get_global_holidays()
        return holiday

    def convert_tenor_to_maturity(self, tenors):
        """
        Using qToolkit DayRule convention (modified following) to add tenors to a valuation date
        """
        out = []
        for tenor in tenors:
            out.append(qt.addTenorAdjust(self.valuation_date, tenor, 'mf', self.holidays))
        return out

    def index_type(self):
        """
        Gets the index type of the data. Is useful to allow index to consist of both term structure or dates
        """
        if hasattr(self.data, 'index'):
            return list(set(type(x) for x in self.data.index))
        return None

    def __str__(self):
        """
        String representation of the market data object. Example is:
        Surface(identifier='None', valuation_date='...', database_date='...', kwargs)

        Objects not used to identify the market data object are excluded (self.data, self.qt_object, self.keys)
        """
        sb = ["identifier=%s" % self.identifier,
              "valuation_date=%s" % self.date_string(self.valuation_date),
              "database_date=%s" % self.date_string(self.database_date)]
        for key in sorted(self.__dict__.keys()):
            if key in ['data', 'qt_object', 'keys', 'identifier', 'valuation_date', 'database_date', 'holidays']\
                    or key.startswith('_'):
                continue
            sb.append("%s=%s" % (key, self.__dict__[key]))
        return '%s(%s)' % (self.__class__.__name__, ', '.join(sb))

    def __repr__(self):
        return self.__str__()

    @staticmethod
    def create_identifier(l_arg, r_arg, op):
        """
        Creates the string that represents the arithmetic operation performed on the market data object. Currently does
        not add parenthesis to display the order of operations if the user performs chained operations
        """
        op_name = op.__name__
        operator_mapping = dict(add='+', sub='-', mul='*', div='/', rsub_operator='-', rdiv_operator='/', truediv='/')

        if op_name in ('rsub_operator', 'rdiv_operator'):
            out = '%s %s %s' % (r_arg, operator_mapping[op_name], l_arg)
        else:
            out = '%s %s %s' % (l_arg, operator_mapping[op_name], r_arg)
        return out

    def operate(self, other, op):
        """
        To refrain from rewriting operator logic for all arithmetic functions, we use the 'operator' module to define
        it only once in below function.
        Second argument determines the operator type (e.g. 'operator.add')
        """

        # Find all arguments the class instance was initialized with, to be used when returning the new class instance
        # NB: We don't include self, data, identifier and valuation_date as special rules apply to these arguments
        init_args = set(getfullargspec(self.__class__.__init__).args) - {'data', 'self', 'identifier', 'valuation_date'}

        # Differentiate between whether the other object is another market data class instance or not
        if isinstance(other, self.__class__):
            # Check whether the keys are equal (if they are, no interpolation is required)
            if self.keys == other.keys:
                out = op(self.data, other.data)
            else:
                # =====================================================================================================
                # Get all unique keys to interpolate upon, then use the interpolation method for each class instance to
                # calculate the value in each key point. Finally, convert the dictionaries back to class object and
                # perform the operation requested
                # =====================================================================================================
                all_keys = list(set(self.keys + other.keys))

                self_interpolated = {key: self.interpolate(key) for key in all_keys}
                other_interpolated = {key: other.interpolate(key) for key in all_keys}

                self_data = self.from_dict(self_interpolated, self.valuation_date).data
                other_data = other.from_dict(other_interpolated, other.valuation_date).data

                out = op(self_data, other_data)
            # Handle input arguments to the returned class object. Identifier should reflect the arithmetic operation,
            # init_args should be concatenated to reflect both classes and valuation date will be inherited from the
            # left-side class of the operation
            identifier = self.create_identifier(self.identifier, other.identifier, op)
            kwargs = {arg: self.concatenate_args(getattr(self, arg), getattr(other, arg)) for arg in init_args}
            kwargs.update(valuation_date=self.valuation_date)
        elif isinstance(other, (int, float, complex)) or hasattr(other, '__iter__'):
            # If the other object is in the natural, real or complex numbers, the arithmetic operation is performed on
            # each entry of the data set using the in-built utility of the pandas package
            out = op(self.data, other)
            identifier = self.create_identifier(self.identifier, other, op)
            kwargs = {arg: getattr(self, arg) for arg in init_args}
            kwargs.update(valuation_date=self.valuation_date)
        else:
            raise NotImplementedError
        return self.__class__(data=out, identifier=identifier, **kwargs)

    def __add__(self, other):
        return self.operate(other, operator.add)

    def __sub__(self, other):
        return self.operate(other, operator.sub)

    def __mul__(self, other):
        return self.operate(other, operator.mul)

    def __div__(self, other):
        if six.PY2:
            return self.operate(other, operator.div)
        else:
            return self.operate(other, operator.truediv)

    def __truediv__(self, other):
        return self.__div__(other)

    def __radd__(self, other):
        return self.__add__(other)

    def __rsub__(self, other):
        def rsub_operator(a1, b1):
            return operator.sub(b1, a1)
        return self.operate(other, rsub_operator)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __rdiv__(self, other):
        def rdiv_operator(a1, b1):
            if six.PY2:
                return operator.div(b1, a1)
            else:
                return operator.truediv(b1, a1)
        return self.operate(other, rdiv_operator)

    def __rtruediv__(self, other):
        return self.__rdiv__(other)


class Surface(MarketDataObject):
    """
        Will support the following:
        - IR vol (from Swaptions) (+)
        - FX vol (-)
        - Cap/Floor (-)
    """
    def __init__(self, data, valuation_date, identifier='N/A', database_date=None,  interpolation_type=SurfaceInterpolation.SurfaceDateTenorLinear):
        MarketDataObject.__init__(self, data=data, identifier=identifier, valuation_date=valuation_date, database_date=database_date)
        self.keys = list(product(self.data.index, self.data.columns))
        self.interpolation_type = interpolation_type
        self.qt_object = self.to_qtoolkit()

    def interpolate(self, args):
        date = qt.addTenorAdjust(self.valuation_date, args[0], qt.BusinessDayConvention.MODIFIED_FOLLOWING, self.holidays)
        return self.qt_object.getVal(date=date, tenor=args[1])

    def parse_as_scenario(self, name, type):
        out = []
        for s_d_i, s_d in enumerate(self.qt_object.surfaceDates):
            for s_t_i, s_t in enumerate(self.qt_object.surfaceTenors):
                a = {'name': "{name}".format(name=name),
                     'tenor': s_t,
                     'maturity': self.data.index[s_d_i],
                     'type': type,
                     'data': self.qt_object.surfaceValues.data[s_d_i].data[s_t_i]}
                out.append(a)
        return out

    @classmethod
    def from_dict(cls, dict_, valuation_date, **kwargs):
        # Dictionary with keys (type: tuple) of the form {(maturity_date, tenor): value}
        idx = pd.MultiIndex.from_tuples(dict_.keys())
        data = pd.DataFrame(list(dict_.values()), index=idx, columns=['Temp']).unstack()['Temp']
        data = data.reindex(date_helper.sort_tenors(list(data.columns)), axis=1)
        data = data.reindex(date_helper.sort_tenors(list(data.index)), axis=0)
        return cls(data=data, valuation_date=valuation_date, **kwargs)

    @classmethod
    def make(cls, vals, maturities, tenors, valuation_date, **kwargs):
        data = pd.DataFrame(data=vals, index=maturities, columns=tenors)
        data = data.reindex(date_helper.sort_tenors(list(data.columns)), axis=1)
        data = data.reindex(date_helper.sort_tenors(list(data.index)), axis=0)
        return cls(data=data, valuation_date=valuation_date, **kwargs)

    @classmethod
    def from_qtoolkit(cls, qt_surface, valuation_date, **kwargs):
        kwargs.update(valuation_date=valuation_date)
        kwargs.update(vals=[i.data for i in qt_surface.surfaceValues.data])
        dates_as_tenors = [qt.convertDateOrTenorToTenor(x, valuation_date) for x in qt_surface.surfaceDates]
        kwargs.update(maturities=dates_as_tenors)
        kwargs.update(tenors=qt_surface.surfaceTenors)
        kwargs.update(interpolation_type=getattr(SurfaceInterpolation, qt_surface.typename))
        return cls.make(**kwargs)

    def to_qtoolkit(self):
        values = self.data.values
        dates = self.data.index.tolist()
        if len(self._index_type) == 1 and self._index_type[0] in version_independent.string_types:
            dates = self.convert_tenor_to_maturity(dates)
        tenors = self.data.columns
        qt_surface = getattr(qt, self.interpolation_type.name)
        return qt_surface.make(dates=dates, tenors=tenors, values=values.tolist())

    def plot(self):
        import matplotlib.pyplot as plt
        from matplotlib import cm
        from mpl_toolkits.mplot3d import Axes3D  # DON'T DELETE THIS IMPORT, IT IS NEEDED FOR 3D PLOT!!!
        import numpy as np
        fig = plt.figure()
        ax = fig.gca(projection='3d')
        tenors = dict(enumerate(self.data.columns))
        maturities = dict(enumerate(self.data.index))

        x, y = np.meshgrid(list(maturities.keys()), list(tenors.keys()), indexing='ij')
        surf = ax.plot_surface(x, y, self.data.values, cmap=cm.coolwarm, rstride=1, cstride=1, linewidth=0)

        title_str = str(self.identifier)
        if self.valuation_date is not None:
            title_str += '\n Valuation date: ' + self.date_string(self.valuation_date)
        plt.title(title_str, fontsize='medium')
        plt.xlabel('Maturity', labelpad=45, weight='heavy')
        plt.ylabel('Tenor', weight='heavy')
        cbarn = plt.colorbar(surf, shrink=0.5)
        # cbarn.set_label('PERCENT')

        if len(maturities) > 100:
            jump = len(maturities)//12
            plt.xticks(list(maturities.keys())[::jump], list(maturities.values())[::jump])
        else:
            plt.xticks(list(maturities.keys())[::3], list(maturities.values())[::3])
        plt.yticks(list(tenors.keys()), list(tenors.values()), rotation='horizontal')

        plt.show()


class TermStructure(MarketDataObject):
    """
    Supports the following:
    - Swap curve (+)
    - Zero coupon curve (+)
    - Hazard curve (+)
    """
    def __init__(self, data, valuation_date, identifier='N/A', database_date=None, interpolation_type=CurveInterpolation.CurveLinear):
        MarketDataObject.__init__(self, data=data, identifier=identifier, valuation_date=valuation_date, database_date=database_date)
        self.keys = list(self.data.index)
        self.interpolation_type = interpolation_type
        self.qt_object = self.to_qtoolkit()

    def interpolate(self, tenor):
        date = qt.addTenorAdjust(self.valuation_date, tenor, qt.BusinessDayConvention.MODIFIED_FOLLOWING, self.holidays)
        return self.qt_object.getVal(date)

    def parse_as_scenario(self, name, type):
        out = []
        for c_d_i, c_d in enumerate(self.qt_object.dates):
            a = {'name': "{name}".format(name=name),
                 'tenor':self.data.index[c_d_i],
                 'maturity': None,
                 'type': type,
                 'data': self.qt_object.vals[c_d_i]}
            out.append(a)
        return out

    @classmethod
    def make(cls, vals, tenors, valuation_date, **kwargs):
        if not isinstance(vals, list):
            vals = list(vals)
        if not isinstance(tenors, list):
            tenors = list(tenors)
        data = pd.Series(data=vals, index=tenors).sort_index()
        data = data.reindex(date_helper.sort_tenors(list(data.index)), axis=0)
        return cls(data=data, valuation_date=valuation_date, **kwargs)

    @classmethod
    def from_dict(cls, dict_, valuation_date, **kwargs):
        tenors, vals = zip(*list(dict_.items()))
        return cls.make(vals=vals, tenors=tenors, valuation_date=valuation_date, **kwargs)

    # WARNING: This function relies on qt.convertDateOrTenorToTenor, which does not correspond 1:1 to qt.addTenor (bug)
    @classmethod
    def from_infinity(cls, infinity_name, valuation_date):
        """Factory from Infinity curve data (source: TIPP data base).

        Returns :class:`pandas.Series` of (tenor-string, curve-values) for given Infinity curve name and EOD date.
        Data source is TIPP database, loaded via MARS.
        Functionality is validated against Nordea's 'Market Environment Manager' for:
                - 'EURAB6E_V' and 'RULI_REV' on dt.datetime(2019, 5, 7)
                - 'JPYXCO_V' on dt.datetime(2013, 10, 30)


        Parameters:
         :param infinity_name:    (:class:`str`):  Infinity curve name
         :param valuation_date:  (:class:`datetime.date`):  Snapshot date of curve

        Units:
         offset: (tenor-strings) Either D,W,M,Y or multiple of D -- to avoid duplicates.

         values: (percent)

        Warnings:
         Warning is raised if bid- is not equal offer-value.

        Author:
            G02229 (Alex)

        Example:
        ---------
         >>>   TermStructure.from_infinity('RULI_REV', dt.datetime(2019, 5, 7))

        """
        oracle_date = date_helper.oracle_to_date(valuation_date)
        sql = """select d.CURVE_OFFSET_DAY,
            d.BID_VALUE*100 as bid_percent,
            d.OFFER_VALUE*100 as offer_percent,
            t.CURVE_DATETIME,
            c.INTERP_CODE
            FROM
            tw_qsleip_net.gotc_CURVE c,
            tw_qsleip_net.gotc_CURVE_DATA d,
            tw_qsleip_net.gotc_CURVE_DATETIME t
            where c.curve_name = '%(infinity_name)s'    
            and trunc(t.CURVE_DATETIME) = %(oracle_date)s
            and t.CURVE_DATETIME = d.CURVE_DATETIME
            and c.curve_id = d.CURVE_ID
            and c.curve_id = t.curve_id
            and t.CURVE_INSTANCE_CODE = 'CLOSE'
            order by d.CURVE_OFFSET_DAY asc
            """ % locals()
        data = pd.read_sql_query(sql, pyodbc.connect(database_connect.get_string('INFOP')))

        interp_db = pd.unique(data['INTERP_CODE'])

        if interp_db == 'CATMULL_ROM':
            interpolation_type = CurveInterpolation.CurveCatrom
        elif interp_db == 'LINEAR':
            interpolation_type = CurveInterpolation.CurveLinear
        else:
            raise NotImplementedError("Interpolation type '%(interp_db)s' not implemented."% locals())

        eq = data['BID_PERCENT'].equals(data['OFFER_PERCENT'])
        if not eq:
            warnings.warn('Bid and offer differ for:' + infinity_name, Warning)
        data['RATE'] = data[['BID_PERCENT', 'OFFER_PERCENT']].mean(axis=1) # mid rate

        day_tenors = [str(int(x)) + 'D' for x in data['CURVE_OFFSET_DAY']]
        maturity_days = [qt.addTenor(valuation_date, x) for x in day_tenors]
        actual_tenors = [qt.convertDateOrTenorToTenor(x, valuation_date) for x in maturity_days]

        # Handles duplicate index (=tenor) values
        try: # tenors strings in 'mixed' formats: D, W, M, Y.
            result = cls.make(vals=data['RATE'].tolist(), tenors=actual_tenors, valuation_date=valuation_date,
                        identifier=infinity_name, interpolation_type=interpolation_type)
        except ValueError: # tenor strings as multiples of D, only. Avoids duplicate tenors as index.
            result = cls.make(vals=data['RATE'].tolist(), tenors=day_tenors, valuation_date=valuation_date,
                        identifier=infinity_name, interpolation_type=interpolation_type)

        return result

    # WARNING: This function relies on qt.convertDateOrTenorToTenor, which does not correspond 1:1 to qt.addTenor (bug)
    @classmethod
    def from_qtoolkit(cls, qt_curve, valuation_date, **kwargs):
        tenors = [qt.convertDateOrTenorToTenor(d, valuation_date) for d in qt_curve.dates]
        kwargs.update(vals=qt_curve.vals)
        kwargs.update(tenors=tenors)
        kwargs.update(valuation_date=valuation_date)
        kwargs.update(interpolation_type=getattr(CurveInterpolation, qt_curve.typename))

        return cls.make(**kwargs)

    def to_qtoolkit(self):
        qt_curve_type = getattr(qt, self.interpolation_type.name)
        if not hasattr(qt_curve_type, 'make'):
            raise TypeError("Chosen curve type is not supported by qToolkit.")
        maturities = self.data.index
        if len(self._index_type) == 1 and self._index_type[0] in version_independent.string_types:
            maturities = self.convert_tenor_to_maturity(maturities)
        qt_curve = qt_curve_type.make(dates=maturities, vals=self.data.values)
        return qt_curve

    def to_dict(self):
        # to the dict curve format that supported by the orca scenario convert service
        return {"interpolation": self.interpolation_type.value,
                "tenors": list(self.data.index),
                "values": list(self.data.values)}

    def forward(self, forward_date):
        return self.make(vals=self.data.values.tolist(),
                         tenors=self.data.index,
                         valuation_date=forward_date,
                         identifier=self.identifier,
                         database_date=self.database_date,
                         interpolation_type=self.interpolation_type)

    def plot(self):
        import matplotlib.pyplot as plt
        plt.plot(range(len(self.data)), self.data.values.tolist(), '--')
        plt.plot(range(len(self.data)), self.data.values.tolist(), 'ro')

        jump = round(len(self.data) / 12)
        plt.xticks(range(len(self.data))[::jump], self.data.index.tolist()[::jump])
        title_str = str(self.identifier) + '\n Valuation date: ' + self.date_string(self.valuation_date)
        plt.title(title_str, fontsize='medium')
        plt.xlabel('Tenors', labelpad=45, weight='heavy')

        plt.show()


class Point(MarketDataObject):
    """
    The object will support the following:
        - FX rate (+)
        - Recovery rate (+)
        - Equity price (-)
        - Z-spread (+)
        - Other? (-)
    """
    def __init__(self, data, valuation_date, identifier=None, database_date=None):
        MarketDataObject.__init__(self, data=data, identifier=identifier, valuation_date=valuation_date, database_date=database_date)
        self.qt_object = self.to_qtoolkit()

    def parse_as_scenario(self, name, type):
        r_name, tenor = self.parse_refi_tenor(name)
        out = {'name': r_name,
               'type': type,
               'tenor': tenor,
               'maturity': None,
               'data': self.qt_object}
        return [out]

    @staticmethod
    def parse_refi_tenor(n):
        """
        Notes:
            Author: g01571 (Ahmet)
        """
        tenor = None
        r_name = n

        if 'DMB.REFI_SPREAD.MTG_DK.' in n:
            tenor = n.split('DMB.REFI_SPREAD.MTG_DK.')[1]
            r_name = 'DMB.REFI_SPREAD.MTG_DK'
        return r_name, tenor

    @classmethod
    def from_dict(cls, dict_, valuation_date, **kwargs):
        vals = list(dict_.values())[0]
        return cls.make(vals=vals, valuation_date=valuation_date, **kwargs)

    @classmethod
    def make(cls, vals, valuation_date, **kwargs):
        out = cls(data = vals, valuation_date = valuation_date, **kwargs)
        return out

    def forward(self, forward_date):
        out = self.make(vals            = self.data,
                        valuation_date  = forward_date,
                        identifier      = self.identifier,
                        database_date   = self.database_date)
        return out

    def to_qtoolkit(self):
        out = float(self.data)
        return out


if __name__ == '__main__':
    pd.set_option('display.max_rows', 200)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)
