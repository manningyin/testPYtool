from ._scenarios import *
from ._transactions import *
from ._risk_factor_labels import *
from .market_data_object import *
try:
    import aenum
except ModuleNotFoundError:
    raise ModuleNotFoundError("Please install 'aenum' (pip install aenum) and re-run your code.")


class EnvirMARS(aenum.Enum):
    _settings_ = aenum.NoAlias
    INFO3D = 'uat'
    INFOBT = 'uat'
    INFOAT = 'uat'
    INFOT = 'uat'
    INFOD = 'dev'
    INFOP = 'prod'


class PricingEngine(Enum):
    ORCA = 1
    QT = 2
    TEST = 3
