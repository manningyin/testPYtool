"""
The module contain functions to calculate delta risk for various products by using different flow

Notes:
    Author: g48454

"""
import quantum as qt
import six

import core.types
from core.utils import version_independent
from enum import Enum
from core.pricing import pricing
from core.types import _transactions
from core.utils import date_helper
from core.connection import database_extract
from collections import defaultdict
from decimal import Decimal
from core.sensitivity import orca_loader


class SensitivityFlow(Enum):
    """
    A class using the Enum package to illustrate the different choices the user has regarding pricing engine for the
    pricing service

    Notes:
        Author: g48454
    """
    ORCA = "ORCA"
    ORCA_Numeric = "ORCA_Numeric"
    MARS = "MARS"

    def __str__(self):
        return self.value


def ir_delta(trade_ids, eod_date, flow):
    """
    Calculate the IR delta for trades

    The IR delta we implemented here is expressed as zero coupon risk : parallel shift on the discount zero coupon curve

    Args:
        trade_ids          (dict or list of transaction types):
        eod_date           (datetime.datetime):        eod_date of the pricing, determines base model and position info.
        flow               (SensitivityFlow, Enum):    which flow you want to use to calculate

    Returns:
        (dictionary):       Keys: trade identifier for the associated local source
                            Values: list of dictionaries. Each dictionary has (at least) the keys: sensitivity,
                            transaction leg identifier and tenor. Some dictionaries show furthermore the sensitivity
                            base and the interest curve the sensitivity belongs to.

    Example:
        The module is called (from python) like this::

            # trades = [transaction_types.Trades(trade_id='1176074', source_system='INFINITY')]
            #
            # a = ir_delta(trade_ids=trades,
            #              eod_date=dt.datetime(2018, 5, 3),
            #              flow=SensitivityFlow.MARS)

    Notes:
        Author: g48454
    """
    if flow is SensitivityFlow.ORCA_Numeric:
        out = numerical_orca_delta_calculator(trade_ids, eod_date)
    elif flow is SensitivityFlow.MARS:
        out = mars_ir_translate(trade_ids, eod_date)
    elif flow is SensitivityFlow.ORCA:
        out = ir_delta_orca(trade_ids, eod_date)
    else:
        raise NotImplementedError("The flow is not implemented %s" % flow)
    return out


def numerical_orca_delta_calculator(trade_ids, eod_date):
    _bump_size = 0.0001  # let us say we bump 1 bps

    # ===================================================================================
    # Below code filter out the relevant disc scenario and generate a parallel shift on the discount zero coupon curve
    # ===================================================================================
    zc_rfs = disc_scenario_name(trade_ids, eod_date)
    bump_curve = qt.CurveFlat.make(dates=[eod_date, qt.addTenor(eod_date, "50Y")],
                                   vals=[_bump_size, _bump_size])
    delta_scenario = [{'name': x,
                       'type': 'ADDITION',
                       'data': bump_curve} for x in zc_rfs]

    # ===================================================================================
    # Call pricing service to get prices.
    # ===================================================================================

    base_price = pricing.pricing_service(trade_ids=trade_ids,
                                         eod_date=eod_date,
                                         engine=core.types.PricingEngine.ORCA)
    scenario_price = pricing.pricing_service(trade_ids=trade_ids,
                                             eod_date=eod_date,
                                             engine=core.types.PricingEngine.ORCA,
                                             scenarios=delta_scenario)

    # ===================================================================================
    # Calculate delta
    # ===================================================================================

    base_price_dict = pricing.parse_pricing_output_base_ccy(base_price)
    scenario_price_dict = pricing.parse_pricing_output_base_ccy(scenario_price)

    out = {}
    for trade in base_price_dict.keys():
        if trade in scenario_price_dict.keys():
            delta = (scenario_price_dict[trade] - base_price_dict[trade]) / _bump_size
            out[trade] = {"delta": delta,
                          "scenario price": scenario_price_dict[trade],
                          "base price":base_price_dict[trade]}

    return out


def disc_scenario_name(trade_ids, eod_date):
    return ['EUR.DISC.OIS.CURVE', 'CZK.DISC.OIS.CURVE', 'DKK.DISC.OIS.CURVE', 'NOK.DISC.OIS.CURVE',
            'HUF.DISC.OIS.CURVE', 'PLN.DISC.OIS.CURVE', 'RON.DISC.OIS.CURVE', 'SEK.DISC.OIS.CURVE',
            'GBP.DISC.OIS.CURVE', 'RUB.DISC.OIS.CURVE', 'CHF.DISC.OIS.CURVE', 'TRY.DISC.OIS.CURVE',
            'CAD.DISC.OIS.CURVE', 'USD.DISC.OIS.CURVE', 'AUD.DISC.OIS.CURVE', 'TRY.DISC.OIS.CURVE',
            'ZAR.DISC.OIS.CURVE', 'MXN.DISC.OIS.CURVE']

    # TODO: change back to below code when model factory is stable
    # rfs = risk_factor_filter.orca_scenario_name(trade_ids=trade_ids, eod_date=eod_date)
    # return [x for x in rfs if 'DISC.OIS' in x]


def extract_ir_delta_from_mars(trades_mars, eod_date):
    """
    Given a list of mars trades it queries them in INFOP to obtain back the sensitivities associated to them.

    Args:
        trades_mars     (list of int):          Each item is a global mars trade_id number.
        eod_date        (datetime.datetime):    eod_date of the pricing, determines base model and position info.

    Returns:
        (dict):
            - keys:     mars trade_id numbers, int type.
            - values:   list of dictionaries. Each dictionary contains the identifying elements term_id and trans_id,
                        a descriptive name, and the corresponding sensitivity and sensitivity base.

    Example:
        The module is called (from python) like this::

            import datetime as dt
            from core.sensitivity import delta

            # Define a list of trades and the wished eod_date.
            trades   = [28627572]
            eod_date = dt.datetime(2012, 6, 29)

            # Call the function
            delta.extract_ir_delta_from_mars(trades, eod_date)

            # Expected return:
            # {'28627572':    [{'name': 'EUR-SWAP',
            #                   'sens': -56.944535495971664,
            #                   'sens_base': -56.944535495971664,
            #                   'term_id': '11M',
            #                   'trans_id': 3},
            #                  {'name': 'EUR-SWAP',
            #                   'sens': 0.29622043119741176,
            #                   'sens_base': 0.29622043119741176,
            #                   'term_id': '14D',
            #                   'trans_id': 3)},
            #                   etc... ]}

        Note: the trades chosen in the example are are equivalent to the ones of the example in mars_ir_delta function
        so that the output have only different keys, but the corresponding values are the same.

    Notes:
        Author: g54713 (Elena Bossolini)
    """

    sql = return_mars_delta_sql(trades_mars, eod_date)

    out_unstructured = database_extract.select_from_query(database="INFOP", query=sql)
    # Make a structured output
    temp_dict = defaultdict(list)
    for item in out_unstructured:

        # formatting the output dict
        for key, value in item.items():
            item[key] = version_independent.uni_to_str(value)
            if type(value) is Decimal:
                item[key] = int(value)

        # Use the trade_id as key and other attributes as value in the output dict
        identifier = 'trade_id'
        dict_key = item[identifier]
        # remove trade_id from the dict
        item.pop(identifier)
        temp_dict[dict_key].append(item)

    # transform the default dict to dict
    out = dict(temp_dict)
    return out


def return_mars_delta_sql(trade_mars, eod_date):
    # Convert trade_ids from a list of integers to a list of strings
    trade_str = [str(x) for x in trade_mars]
    temp_string = "(" + ", ".join(trade_str) + ")"
    sql = """ select a.trade_id, A.TERM_ID, A.TRANS_ID, A.SENS, a.sens_base, B.NAME
              from MARSP.TRANS_INTEREST_SENS a, MARSP.INTEREST b, MARSP.trans d, MARSP.LADDER_TERM c
              where a.interest_id = b.interest_id
              and A.trade_id = d.trade_id
              and d.trans_id = a.trans_id
              and a.trade_id in %s
              and a.eod_date = %s
              and A.TERM_ID = C.TERM_ID
              and C.LADDER_ID = 52
              order by A.TRADE_ID, A.TRANS_ID, C.TERM_NO;
              """ % (temp_string, date_helper.oracle_to_date(eod_date))
    return sql


def mars_ir_translate(trade_ids, eod_date):
    """
    From a trade id corresponding to a specific source system, e.g. 'INFINITY', it returns the sensitivities related to
    this trade for each term and transaction.

    This function calls the function  extract_ir_delta_from_mars(trades_mars,eod_date) in order to query
    the sensitivities in INFOP.

    Args:
        trade_ids          (list of transaction types of class Trade): trade identifier of string type and corresponding
                                                                       local source system, f.ex. 'INFINITY'
        eod_date           (datetime.datetime):        eod_date of the pricing, determines base model and position info.

    Returns:
        (dict):
            - keys:     the element of trade_ids input. Thus, the keys are transaction types objects
            - values:   List of dictionaries. Each dictionary contains the identifying elements term_id and trans_id,
                        a descriptive name, and the corresponding sensitivity and sensitivity base.

    Example:
        Define a list of trades and the wished eod_date
            # trades   = [transaction_types.Trades(trade_id='784843',  source_system='INFINITY')]
            # eod_date = dt.datetime(2012, 6, 29)

        Call the function
            # mars_ir_delta(trades, eod_date)

        Returns:
            # {Trades(source_system='INFINITY', trade_id='784843'): [{'name': 'EUR-SWAP',
            #                                                         'sens': -56.944535495971664,
            #                                                         'sens_base': -56.944535495971664,
            #                                                         'term_id': '11M',
            #                                                         'trans_id': 3},
            #                                                        {'name': 'EUR-SWAP',
            #                                                         'sens': 0.29622043119741176,
            #                                                         'sens_base': 0.29622043119741176,
            #                                                         'term_id': '14D',
            #                                                         'trans_id': 3)},
            #                                                         etc... ]}
    Notes:
        Author: g54713
    """
    # Convert from a list of transaction types to mars trade id, and retain the mapping in a dict for further use.
    trades_mapping = {}
    for trade in trade_ids:
        mars_trade_id = trade.mars_trade_id()
        trades_mapping[mars_trade_id] = trade

    trades_mars = trades_mapping.keys()
    sens_dict = extract_ir_delta_from_mars(trades_mars, eod_date)

    # Restructure the dictionary, by setting as keys the transaction types associated with the mars trade id.
    for key in list(sens_dict.keys()):
        sens_dict[trades_mapping[key]] = sens_dict.pop(key)

    return sens_dict


def ir_delta_orca(trade_ids, eod_date):
    """
    Extracts the sensitivities from ORCA, given a trade identifier and an end of date.

    Example:
        Define a list of trades and the wished eod_date
            # trades   = [transaction_types.Trades(trade_id='1176074',  source_system='INFINITY')]
            # eod_date = dt.datetime(2018, 5, 3)

        Call the function
            # mars_ir_delta(trades, eod_date)

        Returns:
            # {Trades(source_system='INFINITY', trade_id='1176074'): [{'name': u'EUREONON',
            #                                                          'trans_id': u'1',
            #                                                          'sens': -0.14956263224167798},
            #                                                         {'name': u'EUREONTN',
            #                                                          'trans_id': u'1',
            #                                                          'sens': -0.44941415736096874},
            #                                                          etc... ]}
    Notes:
        Author: g54713
    """
    # ===================================================================================
    # call loader from ORCA to get all sensitivities
    # ===================================================================================
    all_sensitivity = orca_loader.ORCATradeRiskLoader(trade_ids=trade_ids,
                                                      eod_date=eod_date
                                                      ).data

    out = defaultdict(list)

    # ===================================================================================
    # parse sensitivity to dict and filter out un-relevant sensitivity
    # ===================================================================================

    for eod_date, trade in all_sensitivity.keys():
        sensi = all_sensitivity[eod_date, trade]
        for risk_trade_result in sensi:
            for instrument_risk in risk_trade_result.instrument_risk:
                if 'OIS.DISC' in instrument_risk.risk_label:
                    for value, instrument_name in zip(instrument_risk.values, instrument_risk.instrument_names):
                        out[trade].append({'sens': value,
                                           'name': instrument_name,
                                           'trans_id': risk_trade_result.trade_leg_id})

    out = dict(out)
    return out


if __name__ == '__main__':
    import datetime as dt
    from core.types import _transactions

    trades = [_transactions.TradeIdentifier(trade_id='1176074', source_system='INFINITY')]
    result = mars_ir_translate(trade_ids=trades,
                                     eod_date=dt.datetime(2012, 6, 29))

    # from pprint import pprint
    # import datetime as dt
    #
    # trades = [transaction_types.Trades(trade_id='1176074', source_system='INFINITY')]
    #
    # # Mars
    # a = ir_delta(trade_ids=trades,
    #              eod_date=dt.datetime(2018, 9, 3),
    #              flow=SensitivityFlow.MARS)
    #
    # # ORCA
    # b = ir_delta(trade_ids=trades,
    #              eod_date=dt.datetime(2018, 9, 3),
    #              flow=SensitivityFlow.ORCA)
    #
    # pprint(a)
    # pprint(b)
