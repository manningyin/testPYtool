"""
This module contains functions for getting sensitivities from ORCA

Notes:
    Author: g01571
"""
import core.caching.abstract_loader_classes
import core.types
import orca.types
from core.utils import error_handler
from core.connection import orca_connect
import quantum as qt
from core.utils import date_helper
import pandas as pd
import datetime as dt
import numpy as np

def orca_sensitivity(isins, eod_date):
    """"
    Calls orca to get the sensitivities and parse the output
    """
    req = orca_connect.get_orca_request()
    trade_ids = (orca.types.SecurityIdentifier(isin, orca.types.SecurityType.BOND) for isin in isins)
    trade_spec = orca.types.TradeSpecification(security_identifiers=trade_ids)
    orca_output = req.risk_trades(time_stamp=orca_connect.get_orca_timestamp(eod_date),
                                  model_configuration_context=orca.types.ModelConfigurationContext.make_eod_context(),
                                  trade_specification=trade_spec,
                                  risk_specification=orca.types.RiskSpecification(cutoff=1e-8)).result()

    out = parse_orca_sensitivity_result_to_dict(orca_output, eod_date, isins)
    return out


def parse_orca_sensitivity_result_to_dict(orca_output, eod_date, isins):
    """"
    Parse orca sensitivity results into a dictionary
    """
    out = {}
    for response in orca_output:
        result = response.result
        #TODO: write the exact identifier
        if not result:
            error_handler.track_error(error_message=response.error.error_message,
                                      identifier=str(isins),
                                      date=eod_date,
                                      comments='Sensitivity failed in ORCA')
            continue
        result = result.__dict__
        out[(eod_date, result['trade_info'].isin)] = []
        # For when risk_trade function is fixed
        relavant_risk_fields = ['curve_risk', 'number_risk', 'tenor_surface_risk']
        sensitivities_now = [sensitivity for r_field in relavant_risk_fields for sensitivity in result[r_field]]

        # PARSE VALUES
        for rf in sensitivities_now:
            out[(eod_date, result['trade_info'].isin)] += parse_sensitivities(rf, isin=result['trade_info'].isin)
    return out


def parse_sensitivities(rf, isin):
    """"
    Creates a list of sensitivities representing each dimension of the input risk factor as a different dictionary
    """
    def parse_surface_dimension(t):
        mapping = {0: "D", 1: "B", 2: "W", 3: "M", 4: "Y"}
        return "{n}{m}".format(n=t.num, m=mapping[t.unit])
    out_l = []
    rf = rf.__dict__
    if 'value' in rf:
        r_name, tenor = parse_tenor_from_point(rf['risk_label'])
        a = {'rf': r_name, 'tenor_dim1': tenor, 'tenor_dim2':None, 'sensitivity': rf['value'], 'ISIN':isin}
        out_l.append(a)
    elif 'values' in rf:
        if len(rf['values']) == 0:
            a = {'rf': rf['risk_label'], 'tenor_dim1':None, 'tenor_dim2':None, 'sensitivity': 'NO ORCA Output',  'ISIN':isin}
            out_l.append(a)
        elif isinstance(rf['values'][0], float) and 'dates' in rf:
            for i, d in enumerate(rf['dates']):
                a = {'rf':rf['risk_label'], 'tenor_dim1': date_helper.to_datetime(d), 'sensitivity':rf['values'][i],  'ISIN':isin}
                out_l.append(a)
        elif hasattr(rf['values'][0], 'tenor_dim_1') and hasattr(rf['values'][0], 'tenor_dim_2'):
            for v in rf['values']:
                a = {'rf': rf['risk_label'], 'tenor_dim1': parse_surface_dimension(v.tenor_dim_1),
                     'tenor_dim2': parse_surface_dimension(v.tenor_dim_2), 'sensitivity': v.value, 'ISIN': isin}
                out_l.append(a)
        else:
            raise Warning('Sensitivity output wasa not parsed ', rf)
    else:
        raise Exception("Value field was not found")
    return out_l


def parse_tenor_from_point(n):
    """"
    Parses tenor and name from the given risk factor (Orca rf name)
    """
    tenor = None
    r_name = n
    if 'DMB.REFI_IO_SPREAD' in n:
        tenor = 'IO'
        r_name = 'DMB.REFI_SPREAD.MTG_DK.IO'
    elif 'DMB.REFI_SPREAD.MTG_DK.' in n:
        tenor = n.split('DMB.REFI_SPREAD.MTG_DK.')[1]
        r_name = 'DMB.REFI_SPREAD.MTG_DK.'+tenor
    return r_name, tenor


class TenorMapper:
    def __init__(self, eod, ladder_id=3):
        ladder = self.get_ladder(ladder_id)
        self.ladder_dict = {date_helper.tenor_to_float(tenor) /12 : tenor for tenor in ladder}
        self.ladder = list(sorted(self.ladder_dict.keys()))
        self.eod = eod

    def get_ladder(self, ladder_id):
        import pyodbc
        from core.connection import database_connect
        import pandas as pd

        sql = "select term_id from marsp.ladder_term where ladder_id = %s" % ladder_id
        conn = pyodbc.connect(database_connect.get_string('INFOP'))
        df = pd.read_sql(sql, conn)
        return date_helper.sort_tenors(df['TERM_ID'].tolist())

    def find_closest_laders_weights(self, y):
        laders_18 = self.ladder
        if pd.isna(y):
            return None, None, None, None

        first_bigger = [n for n, i in enumerate(laders_18) if i > y]

        if len(first_bigger) == 0:
            t1, t2, w1, w2 = (max(laders_18), None, 1, None)
        elif first_bigger[0] == 0:
            t1, t2, w1, w2 = (min(laders_18), None, 1, None)
        else:
            t1 = laders_18[first_bigger[0]-1]
            t2 = laders_18[first_bigger[0]]
            w2 = (y-t1)/(t2-t1)
            w1 = (t2-y)/(t2-t1)
        return t1, t2, w1, w2

    def convert_to_yearly_map(self, row):
        d1 = self.eod
        d2 = row['tenor_dim1']
        if not isinstance(d2, dt.datetime) or d2.year is np.nan:
            return None
        else:
            return qt.yearFraction(d1, d2, qt.DayCount.ACT365)

    @staticmethod
    def get_lader18_sens(group_df, w):
        return (group_df[w]*group_df['sensitivity']).sum()

    def map_senstitivities_to_tenors(self, sensitivities):
        sensitivity_df = pd.DataFrame(sensitivities)
        sensitivity_df['year_tenor'] = sensitivity_df.apply(self.convert_to_yearly_map, axis=1)
        wont_change = sensitivity_df[sensitivity_df['year_tenor'].isna()].drop('year_tenor', axis=1)
        sensitivity_df = sensitivity_df[sensitivity_df['year_tenor'].notna()]
        sensitivity_df[['t1', 't2', 'w1', 'w2']] = pd.DataFrame(
            list(sensitivity_df['year_tenor'].apply(self.find_closest_laders_weights)),
            columns=['t1', 't2', 'w1', 'w2'], index=sensitivity_df.index)
        from_t1 = sensitivity_df.groupby(['t1', 'rf', 'ISIN']).apply(self.get_lader18_sens, 'w1').reset_index()
        from_t2 = sensitivity_df[sensitivity_df.t2.notna()].groupby(['t2', 'rf', 'ISIN']).apply(self.get_lader18_sens, 'w2').reset_index()
        if len(from_t2) == 0:
            from_t2 = pd.DataFrame(columns=['t2', 'rf', 'ISIN'])
        total = pd.merge(from_t1, from_t2, left_on=['t1', 'rf', 'ISIN'],
                         right_on=['t2', 'rf', 'ISIN'], how='outer')
        total['t1'] = total['t1'].fillna(total['t2'])
        total = total.drop('t2', axis=1)
        mapped_sensitivity = total.set_index(['t1', 'rf', 'ISIN']).sum(axis=1).reset_index()
        mapped_sensitivity['t1'] = mapped_sensitivity['t1'].map(self.ladder_dict)
        mapped_sensitivity.rename(columns={0:'sensitivity', 't1': 'tenor_dim1'}, inplace=True)
        mapped_sensitivity = pd.concat([wont_change, mapped_sensitivity]).to_dict('records')
        return mapped_sensitivity


class SensitivityLoaderORCA(core.caching.abstract_loader_classes.MatrixLoader):
    """"
    Loader class for sensitivities
    """
    def __init__(self, trade_ids, eod_date, load_from_source=False, cache_path=None):
        self.valuation_date = eod_date
        core.caching.abstract_loader_classes.MatrixLoader.__init__(self, names=trade_ids,
                                                                   startd=eod_date,
                                                                   endd=eod_date,
                                                                   load_from_source=load_from_source,
                                                                   cache_path=cache_path)

    def return_unique_name(self):
        identifier_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for identifier in identifier_list:
            out[self.startd, identifier] = '_'.join([self.__class__.__name__, self.startd.strftime('%Y%m%d'),
                                                     str(identifier), self.valuation_date.strftime('%Y%m%d')])
        return out

    def source_loading_function(self, isins, date):
        return orca_sensitivity(isins, date)

    def get_mapped_sensitivities(self, ladder_id):
        eod = self.valuation_date
        sensitivities = self.data
        tenor_mapper = TenorMapper(eod, ladder_id=ladder_id)
        mapped_sensitivities = {k: tenor_mapper.map_senstitivities_to_tenors(sensitivities[k]) for k in sensitivities}
        return mapped_sensitivities


if __name__ == '__main__':
    import datetime as dt

    eod = dt.datetime(2019, 11, 4)

    isins = [
        'DK0002020452',
        'DK0002012350',
    ]

    out = SensitivityLoaderORCA(trade_ids=isins, eod_date=eod).data

    print(out)