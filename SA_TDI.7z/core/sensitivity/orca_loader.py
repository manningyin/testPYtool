"""
The module contain a loader implementation to load sensitivity from orca

Notes:
    Author: g48454
"""

import core.caching.abstract_loader_classes
from core.types._transactions import get_trade_spec
from core.connection import orca_connect


class ORCATradeRiskLoader(core.caching.abstract_loader_classes.MatrixLoader):
    """
    Loader function for orca risk_trade service

    Args:
        trade_ids          (list of transaction types of class Trade): trade identifier of string type and corresponding
                                                                       local source system, f.ex. 'INFINITY'
        eod_date        (dt.datetime):   Date used for the pricing (model, position, valuation)
        load_from_source       (bool):   Bool determining if caching should be used, or we should recalculate
        cache_path              (str):   If another path than default cache path should be used

    Returns:
        (dict):   Returns dictionary with (eod_date, (trade_id, source)) as key, and pricing result as value

    Warning:
        ORCA does currently _NOT_ support model forwarding, and thus this is not supported by the loader

    Notes:
        Author: g48606
    """
    def __init__(self, trade_ids, eod_date, load_from_source=False, cache_path=None):
        self.valuation_date = eod_date
        core.caching.abstract_loader_classes.MatrixLoader.__init__(self, names=trade_ids,
                                                                   startd=eod_date,
                                                                   endd=eod_date,
                                                                   load_from_source=load_from_source,
                                                                   cache_path=cache_path)

    def return_unique_name(self):
        identifier_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for identifier in identifier_list:
            out[self.startd, identifier] = '_'.join([self.__class__.__name__, self.startd.strftime('%Y%m%d'),
                                                     str(identifier), self.valuation_date.strftime('%Y%m%d')]
                                                    )
        return out

    def source_loading_function(self, trade_ids, date):

        # ===================================================================================
        # Below function convert the core.types.transaction_type to orca trnasaction type
        # We keep the information in a mapping table
        # ===================================================================================
        trade_spec = get_trade_spec(trade_ids)
        req = orca_connect.get_orca_request()

        # ===================================================================================
        # Call ORCA
        # ===================================================================================
        # TODO: change the use_grid to True when grid is stabl
        # TODO: change to vector implementation when orca request get back is stable
        out = req.risk_trades(time_stamp=orca_connect.get_orca_timestamp(date),
                              model_configuration_name="ORCA_REVAL",
                              trade_specification=trade_spec,
                              use_grid=False).result()

        return out


if __name__ == '__main__':
    from core.types import _transactions
    from pprint import pprint
    import datetime
    trades = [_transactions.TradeIdentifier(trade_id='1176074', source_system='INFINITY'),
              _transactions.TradeIdentifier(trade_id='873787', source_system='INFINITY')
              ]

    a = ORCATradeRiskLoader(trade_ids=trades, eod_date=datetime.datetime(2018,5,3)).data

    pprint(a)





