# -*- coding: utf-8 -*-
'''
Calculate quantities in a sliding window like running average.

Notes:
    Author: Orest Dubay

    ======= ==========   =========   ========================================================================================
    Version Date         Developer   Comment
    ======= ==========   =========   ========================================================================================
    1       2017-06-15   G46987      Initial creation
    ======= ==========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''
import numpy as np
from itertools import islice

def points_around(X,i):
    """
    Iterate over elements of X around X[i] with in an asscending distance from X[i].
    Algorithm assumes that the X values are sorted in an ascending order.

    Args:
        X        (array):           List or array of floats.
        i        (int):             index of the first element

    Returns:
        (array):   array of radii with the same size as X

    Raises:

    Example:
        The module is called (from python) like this::
        
            points_around([1,2,3,4,5],1)

        will yield 2,1,3,4,5

    Notes:
        Author: g46987        
    """
    yield X[i]
    low_index=i
    high_index=i
    while True:
        next_low_index=low_index-1
        next_high_index=high_index+1
        if next_low_index<0:
            if next_high_index>=len(X):
                break
            high_index=next_high_index
            yield X[high_index]
        else:
            if next_high_index>=len(X):
                low_index=next_low_index
                yield X[low_index]
            else:
                r_low=abs(X[i]-X[next_low_index])
                r_high=abs(X[i]-X[next_high_index])
                if r_low<=r_high:
                    low_index=next_low_index
                    yield X[low_index]
                else:
                    high_index=next_high_index
                    yield X[high_index]
        
def npoint_range(X,N):
    """
    Calculate minimum range Ri for each point such that interval <Xi-Ri, Xi+Ri> will contain at least min(N,len(X)) points.
    Algorithm assumes that the X values are sorted in an ascending order.

    Args:
        X        (array):           List or array of floats. Numbers have to be storted in an ascending order.
        N        (int):             Number of points in each "sphere"

    Returns:
        (array):   array of ranges with the same size as X

    Raises:

    Example:
        The module is called (from python) like this::
        
            npoint_radius([1,2,3,4,5],3)

    Warning:

    Notes:
        Author: g46987        
    """
    R=np.zeros(len(X),np.double)
    X=np.array(X)
    for i in range(len(X)):
        start=max(0,i-N)
        end=min(len(X),i+N)
        distances = np.abs(X[start:end]-X[i])
        indices=np.argsort(distances)        
        R[i] = distances[indices[min(N-1,len(distances)-1)]]
    return R

def gaussian_weights(Xpos,X,sigma):
    """
    Calculate weights of influence of points X at point Xpos via a Gaussian distribution.
    Gaussian functions centered at X[i] with sigma[i] are evaluated at Xpos.
    These are to be used in wieghted average.

    Args:
        Xpos     (float):           Position at which the weights are evaluated.
        X        (array):           List or array of floats.
        sigma    (array or float):  Array of sigma parameters of the Gaussian function. It can as well be a single scalar.

    Returns:
        (array):   array of weights

    Raises:

    Example:
        The module is called (from python) like this::
        
            gaussian_weights(1.5,[1,2,3,4,5],[1,1,2,3,4])

    Warning:

    Notes:
        Author: g46987        
    """
    d=X-Xpos
    sigma2=sigma*sigma
    W=np.exp(-d*d/(2.0*sigma2))/np.sqrt(2.0*np.pi*sigma2)
    return W

def sliding_average_with_range(Xgrid,X,Y,R,weights=gaussian_weights):
    """
    Calculate sliding average with specified range and range-dependent weights.
    Xgrid specifies the output grid of values where sliding average over Y[i] values located at X[i] is evaluated.
    Each point (X[i],Y[i]) has a range of influence along X-axis extending by R[i]. The range of influence enters the weight calculator.
    Weight calculator if a function of Xpos, X and R, which calculates weights (influence) of points X to position Xpos given the range of influence R.

    Args:
        Xgrid    (array):           Position at which the weights are evaluated.
        X        (array):           Array of floats with X positions.
        Y        (array):           Array of floats with Y positions. This is an array that will be averaged over.
        R        (array):           Array of ranges in X domain.
        weights  (function):        weights(Xpos,X,R) is a function that calculates weights for each point (see gaussian_weights)

    Example:
        see smooth_sliding_stddev and/or unittest
        
    Returns:
        (array):   array of averages

    Notes:
        Author: g46987        
    """
    Ygrid=np.zeros(len(Xgrid),np.double)
    for i in range(len(Xgrid)):
        W=weights(Xgrid[i],X,R)
        Ygrid[i]=np.sum(Y*W)/np.sum(W)
    return Ygrid

def sliding_stat_with_range(Xgrid,X,Y,R,weights=gaussian_weights):
    """
    Calculate sliding average of Y and Y^2 with specified range and range-dependent weights.
    This can be achieved by two calls of sliding_average_with_range, but it is more efficient since it only calculates weights once.

    Args:
        Xgrid    (array):           Position at which the weights are evaluated.
        X        (array):           Array of floats with X positions.
        Y        (array):           Array of floats with Y positions. This is an array that will be averaged over.
        R        (array):           Array of ranges in X domain.
        weights  (function):        weights(Xpos,X,R) is a function that calculates weights for each point (see gaussian_weights)
        
    Returns:
        (array):   tuple with two array elements: averages of Y and averages of Y^2

    Example:
        see smooth_sliding_stddev and/or unittest

    Notes:
        Author: g46987        
    """
    Ygrid=np.zeros(len(Xgrid),np.double)
    Y2grid=np.zeros(len(Xgrid),np.double)
    for i in range(len(Xgrid)):
        W=weights(Xgrid[i],X,R)
        sumW=np.sum(W)
        Ygrid[i]=np.sum(Y*W)/sumW
        Y2grid[i]=np.sum(Y*Y*W)/sumW
    return Ygrid,Y2grid


def smooth_sliding_average(Xgrid,X,Y,N):
    """
    Calculate smooth average of Y using weights effectively concentrated on N nearest neighbors (in X domain).
    N should be greater than one. If it is greater than len(X), effectively len(X) will be used.

    Args:
        Xgrid    (array):           Position at which the weights are evaluated.
        X        (array):           Array of floats with X positions.
        Y        (array):           Array of floats with Y positions. This is an array that will be averaged over.
        N        (int):             Number of neighbors to consider. 
        
    Returns:
        (array):   Ygrid array of averages

    Example:
        Call as smooth_sliding_average([1,2,3,4,5],[1,3,5],[10,10,11],2)

    Notes:
        Author: g46987        
    """
    index=np.argsort(X)
    X=np.array(X,np.double)[index]
    Y=np.array(Y,np.double)[index]    
    R=npoint_range(X,N)
    return sliding_average_with_range(Xgrid=Xgrid,X=X,Y=Y,R=R,weights=gaussian_weights)


def smooth_sliding_stddev(Xgrid,X,Y,N,assume_zero_mean=False):
    """
    Calculate smooth standard deviation (of Y using weights effectively concentrated on N nearest neighbors (in X domain).
    N should be greater than one. If it is greater than len(X), effectively len(X) will be used.
    If assume_zero_mean is True, then zero mean of Y is assumed and thus the output would be square root of average of Y^2.
    If assume_zero_mean is False (default), then the output would be sqrt(<Y^2> - <Y>^2).
    
    Args:
        Xgrid    (array):           Position at which the weights are evaluated.
        X        (array):           Array of floats with X positions.
        Y        (array):           Array of floats with Y positions. This is an array that will be averaged over.
        N        (int):             Number of neighbors to consider. 
        
    Returns:
        (array):   Ygrid array of averages

    Example:
        Call as smooth_sliding_stddev([1,2,3,4,5],[1,3,5],[10,10,11],2)

    Notes:
        Author: g46987        
    """
    index=np.argsort(X)
    X=np.array(X,np.double)[index]
    Y=np.array(Y,np.double)[index]    
    R=npoint_range(X,N)
    
    AvgY,AvgY2 = sliding_stat_with_range(Xgrid=Xgrid,X=X,Y=Y,R=R,weights=gaussian_weights)
    if not assume_zero_mean:
        AvgY2-=AvgY*AvgY
    return np.sqrt(AvgY2)
    