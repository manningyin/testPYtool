"""
This module implements the brownian bridge which can be used for purpose of stochastic interpolation

Notes:
    Author: g53036(Tamal)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       24May2017   g53036      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import math
import numpy as np


def brownian_bridge_sample(start_value, end_value, start_time, end_time, intermediate_time, no_samples = 1):

    """
    Generate samples from a brownian bridge distribution
    
    Given 2 deterministic (time_point, value_point) pair
    this method generates output samples 
    from a brownian bridge distribution (i.e. normal)
    
    The brownian bridge distribution is normal with parameters depending
    on the input_point and value_point
    
    Args:
        start_time           (float):    1st input time point
        end_time             (float):    2nd input time point
        start_value          (float):    1st output value
        end_value            (float):    2nd output value
        intermediate_time    (float):    time point at which stochastic interpolation needs to be done 
        no_samples           (int):      number of output samples to be generated from brownian bridge 
                                                         
    
    Returns:
        (float):   samples coming from brownian bridge distribution
    
    Raises:
        Assertion errors unless the start time parameter is greater than or equal to zero
        Assertion errors unless the end time parameter is greater than the start time
        Assertion errors unless the intermediate time is less than end time
        Assertion errors unless the intermediate time is greater than start time
        Assertion errors unless the no of samples is greater than or equal to 1
        
    
    Example:
       
        The module is called (from python) like this::
    
            output = brownian_bridge_sample(start_value        = 0.0,
                                     end_value          = 1.0,
                                     start_time         = 0.1,
                                     end_time           = 0.5,
                                     intermediate_time  = 0.3,
                                     no_samples         = 1,
                                     )
    
    Notes:
        Author: g53036(Tamal)
    """
    # regular input checks
    assert (isinstance(start_time, float)), "The start time parameter entered should be a float"
    assert (start_time >= 0), "The start time parameter should be greater than or equal to zero"
    assert (isinstance(end_time, float)), "The end time parameter entered should be a float"
    assert (end_time > start_time), "The end time parameter should be greater than the start time"
    assert (isinstance(start_value, float)), "The start value parameter entered should be a float"
    assert (isinstance(end_value, float)), "The endvalue parameter entered should be a float"
    assert (isinstance(intermediate_time, float)), "The intermediatetime parameter entered should be a float"
    assert (intermediate_time < end_time), "The intermediate time should be less than end time"
    assert (intermediate_time > start_time), "The intermediate time should be greater than start time"
    assert (isinstance(no_samples, int)), "The nosamples parameter entered should be an integer"
    assert (no_samples >= 1), "The nosamples parameter should be an integer atleast greater than or equal to 1"

    mean = float(start_value + ((intermediate_time - start_time) * (end_value - start_value)) / (end_time - start_time))
    sigma =  float(math.sqrt(((end_time - intermediate_time) * (intermediate_time - start_time)) / (end_time - start_time)))
    simulated_value = np.random.normal(mean,sigma,no_samples)
    return simulated_value


