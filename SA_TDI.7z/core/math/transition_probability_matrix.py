"""
Implements basic functionality associated with transition probability matrices (TPM)

In particular :
    - checks if a TPM is a valid TPM (each elements between (0,1) and rows summing up to 1)
    - checks if generators exists for such a TPM
    - calculates generator for TPM and
    - scales a TPM (up by integral powers and down by fractional power between (0,1))

This module aims to estimate 3M TPM / 2Y TPM (for example) from annual TPM

Warning:
      Only works for square matrix for now 

Notes:
    Author: g53036 (Tamal)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       22DEC2017   G53036      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""


import numpy as np
from scipy import linalg

def is_valid_probability_matrix(input_matrix, tol):
    """
    Checks if a transition probability matrix (TPM) is a valid probability matrix

    Checks :
        - if each of elements are non-negative
        - the row sums up to 1
        - if each of the elements lies between (0,1)

    Note that the last condition follows as a consequence of the 1st two

    Args:
        input_matrix           (matrix):    numpy matrix object
        tol                    (float):     sets up a tolerance limit for comparisons

    Returns:
        (boolean):   1 indicates a valid TPM and 0 indicates otherwise

    Example:
        The module is called (from python) like this::

             return_boolean = is_valid_probability_matrix (input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'),
                                                              tol     = 1e-5
                                                          )
    Warning:

       Only works for square matrices

    Notes:
        Author: g53036 (Tamal)
    """

    no_rows  = input_matrix.ndim
    row_sum = input_matrix.sum(axis = 1, dtype ='float')
    base_matrix = np.ones(no_rows, dtype = "float")

    # the below conditions are sufficient to make sure that probabilities are bounded between (0,1)
    unit_row_sum = int(np.allclose(row_sum, base_matrix.T, atol=tol))
    positivity = int(np.all(input_matrix > 0))
    return unit_row_sum * positivity


def does_generator_exists(input_matrix):
    """
    Checks if a generator matrix exists for a given transition probability matrix (only square matrices)

    This function takes a transition probability matrix (TPM) as an input and outputs (boolean) if a generator exists.
    Note that the condition is also a sufficient condition which means
    even if the condition is not fulfilled still the generator matrix may exist (though non-unique).
    However, it is observed that this condition holds for many of the TPM arising
    in the credit literature.

    Reference : Finding Generators for Markov Chains via Empirical Transition Matrices,
    with Applications to Credit Ratings, Robert B. Israel et. al (2000)

    Provides mathematical justification/validation support for calculating generator matrix

    Args:
        input_matrix           (matrix):    numpy matrix object

    Returns:
        (boolean):   Returns 1 if the sufficient condition is satisfied

    Example:

        The module is called (from python) like this::

            boolean_return = does_generator_exists(input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'))

    Warning:
        Please note that having a return value of 0 does not necessarily mean that the generator can not exist.

    Notes:
        Author: g53036 (Tamal)
    """

    diagonal_elements = np.diag(input_matrix, k=0)
    benchmark_array = 0.5 * np.ones(len(diagonal_elements), dtype="float")

    return int(np.all(diagonal_elements - benchmark_array > 0))  # sufficient condition

def scale_probability_matrix(input_matrix, power):
    """
    Raises a square matrix to an integer power or a fractional power between (0,1)

    - Calculates 2 year transition probability matrix (TPM) from annual TPMs
    - Calculates 60 day TPMs for DRC equity/IRM from annual TPM.

    Args:
        input_matrix            (matrix):     numpy matrix object
        power                   (float):      the power to which the matrix is to be raised


    Returns:
        (matrix):  The scaled TPM. Makes sure that the resulting matrix is also TPM

    Example:
        The module is called (from python) like this::

            scaled_matrix        =   scale_probability_matrix(input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'),
                                                              power = 2
                                                              )
    Notes:
        Author: g53036 (Tamal)
    """

    if (int(power) == power and power > 0):
        scaled_transition_matrix = np.linalg.matrix_power(input_matrix, power)
        return scaled_transition_matrix

    elif (power > 0 and power < 1):
        generator_matrix = get_generator_matrix(input_matrix)
        scaled_transition_matrix = linalg.expm(generator_matrix)
        return scaled_transition_matrix
    else:
        print("Please input either positive integer powers or fractional powers between (0,1)")



def get_generator_matrix(input_matrix, no_of_terms = 100):
    """
    Computes generator of a square matrix

    This is based on an algorithm described in
    "Calculating incremental risk charges: The effect of the liquidity horizon"
    by Jimmy Skoglund and Wei Chen (2010)

    The generator matrix is used to determine for example 60 day transition probability matrix (TPM)
    from annual TPM

    Currently the Taylor series is expnded upto 100 terms which seems to be OK for convergence.
    One can adjust this by modifying the "no_of_terms" default parameter

    Args:
        input_matrix            (matrix):           numpy matrix object
        no_of_terms             (int):              (Default=100). Number of terms used in the Tayler Series expansion

    Returns:
        (matrix):   Returns the generator of the TPM

    Example:
        The module is called (from python) like this::

            generator_matrix = get_generator_matrix(input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'),
                                                     no_of_terms = 100
                                                    )

    Notes:
        Author: g53036 (Tamal)
    """

    temp_sum = 0
    no_rows = input_matrix.ndim
    identity_matrix = np.identity(no_rows, dtype="float")
    difference_matrix = input_matrix - identity_matrix
    for power in range(1,no_of_terms):
        generator_matrix = np.linalg.matrix_power(difference_matrix , power)
        temp_sum = temp_sum + ((-1)**(power - 1)/power)*generator_matrix # check above reference for exact formula

    return  temp_sum

