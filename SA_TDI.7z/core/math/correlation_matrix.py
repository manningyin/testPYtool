"""
First line is a short overall description of the module

After one empty line, you should go more into details about what the purpose of the module is - in free text.
This could take up a couple of lines.
This could take up a couple of lines.

Detailed information about specific functions should be done in the function headers.

The description could include an business example:
The module aims to handle everything that has something to do with formatting calendar dates


Notes:
    Author: g53036(Tamal)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       22DEC2017   G53036      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import numpy as np
import  math


def is_correlation_matrix(input_matrix, tol):
    """
    Checks if a correlation matrix is a valid correlation matrix

    This is achieved by performing the below 2 checks :
    - check if the matrix is symmetric, and
    - check if the matrix is positive semi-definite

    Correlations estimated from market most often fails to 
    satisfy the above 2 criterias due to missing/inaccurate data. In such cases
    such a check can be useful.

    Args:
        input_matrix           (matrix):    numpy matrix object

        tol                    (float):     sets up a tolerance limit for comparisons


    Returns:
        (boolean):  1 if valid correlation matrix and 0 otherwise

    Example:
       The module is called (from python) like this::

           import numpy as np
           is_valid = is_correlation_matrix(input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'),
                                            tol     = 1e-5
                                            )
    Notes:
        Author: g53036(Tamal)
    """
    return int(is_symmetric(input_matrix, tol)*is_positive_semi_definite(input_matrix))



def is_symmetric(input_matrix, tol = 1e-8):
    """
    Checks if a matrix is symmetric
 
    Can be used for example to check validity of a correlation/covariance matrix, 
    generating correlated random variables etc.
 
    Args:
        input_matrix           (matrix):    numpy matrix object
 
        tol                    (float):     sets up a tolerance limit for comparisons
 
 
    Returns:
         (boolean):  1 if symmetric and 0 otherwise
 
    Example:
       The module is called (from python) like this::
 
           import numpy as np
           result = is_symmetric(input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'),
                                              tol     = 1e-5
                                              )
 
        Author: g53036(Tamal)
    """
    return int(np.allclose(input_matrix, input_matrix.T, atol=tol) == True)


def is_positive_semi_definite(input_matrix):
    """
    Checks if a matrix is positive semi-definite

    The current implementation checks it by checking if each 
    of the eigen values are non-negative.

    Can be used for example to check validity of a correlation/covariance matrix, 
    generating correlated random variables etc.

    Args:

       input_matrix           (matrix):    numpy matrix object

    Returns:
       (boolean):  1 if positive semi-definite and 0 otherwise

    Example:
        The module is called (from python) like this::

            import numpy as np
            result = is_positive_semi_definite(input_matrix  = np.matrix('0.7 0.3; 0.4 0.6'))

    Notes:
        Author: g53036(Tamal)
    """
    eigenvalues, eigenvector = np.linalg.eig(input_matrix)
    return int((np.all(eigenvalues >= 0) == True))


def correct_correlation_matrix(input_matrix):
    """
    Corrects correlation matrix

    The implementation is based on "The most general methodology to create 
    a valid correlation matrix for risk management and option
    pricing purposes" by Riccardo Rebonato and Peter Jackal (Oct. 1999)


    Can be used for example to check validity of a correlation/covariance matrix, 
    generating correlated random variables etc. The sample code example below is
    the same example as in Section 4 of the above reference. This verifies the fact that the
    corrected correlation matrix is implemented correctly.

    Args:
       input_matrix           (matrix):    numpy matrix object                                               

    Returns:
        (matrix object):  The corrected correlation matrix, i.e. both symmetric and positive semi-definite 

    Example:

        The module is called (from python) like this::

             import numpy as np
             corrected_corr_matrix  = correct_correlation_matrix(input_matrix  = np.matrix('1 0.9 0.7; 0.9 1 0.3; 0.7 0.3 1'))

    Notes:
        Author: g53036(Tamal)
    """

    if (is_symmetric(input_matrix, tol = 1e-8) == 1 and is_positive_semi_definite(input_matrix) == 0):

            eigenvalues, eigenvector = np.linalg.eig(input_matrix)
            #floored_eigenvalue = [math.sqrt(max(value, 0)) for value in eigenvalues]
            floored_eigenvalue = [math.sqrt(max(value, np.finfo(np.float64).eps)) for value in eigenvalues]
            no_of_rows = len(eigenvalues)

            for iter in range(no_of_rows):
                eigenvector[:,iter] *=  floored_eigenvalue[iter]
            for iter in range(no_of_rows):
                eigenvector[iter, :] = eigenvector[iter, :] /np.linalg.norm(eigenvector[iter, :])

            # corrected correlation matrix
            corrected_corr_matrix = eigenvector * eigenvector.T
            return corrected_corr_matrix

    else:
         print ("correct_correlation_matrix() method is not applicable")












