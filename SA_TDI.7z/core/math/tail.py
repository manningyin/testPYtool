# -*- coding: utf-8 -*-
"""
Utilities associated with tail measures.

Notes:
    Author: g46987 (Orest)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1        24082017   G46987      Initial creation
    ======= =========   =========   ========================================================================================
"""

import numpy as np

def tail_indices(a,n,lowest_values=True):
    """
    Return element indices pointing to the n lowest (if lowest_values is True) or highest values in the array a.
    Use the 'tail' function to get the values directly.
    
    The indices are not in any particular order.
    

    Args:
        a             (numpy array):    Array of values to be found tail in
        n             (int):            Number of elements in the tail
        lowest_values (bool):           If True, indices to n lowest values are returned (low tail), else high tail.

    Returns:
        (numpy array of integers):      Indices to a.

    Example:
        The module is called (from python) like this::

            from core.math import tail
            import numpy as np
            # This will return indices to 5 lowest elements (elements with value 0 or 1),
            # the result will be [2,4,6,8,9].

            indices = tail.tail_indices(np.array([2, 3, 1, 4, 0, 3, 0, 2, 1, 1]),5)

    Notes:
        Author: g46987 (Orest)
    """
    
    ## Alternative implementation
    # return np.argsort(a)[:n] if lowest_values else np.argsort(-a)[:n]

    assert(n>0)        
    if n>=len(a):
        return np.arange(len(a))
    if lowest_values:
        return np.argpartition(a,n)[:n]
    else:        
        return np.argpartition(a,len(a)-n)[len(a)-n:]

def tail_average(a,n,lowest_values=True):
    """
    Make an average of n lowest (if lowest_values is True) or highest values in the array a.

    Args:
        a             (numpy array):    Array of values
        n             (int):            Number of elements in the tail
        lowest_values (bool):           If True, average ower lowest values, else highest values.

    Returns:
        (float):      Tail average

    Example:
        The module is called (from python) like this::

            tail_average(np.array([2, 3, 1, 4, 0, 3, 0, 2, 1, 1]),5)

    Notes:
        Author: g46987 (Orest)
    """
    
    return np.average(a[tail_indices(a,n,lowest_values=lowest_values)])
    
def tail(a,n,lowest_values=True):
    """
    Return the n lowest (if lowest_values is True) or highest values in an array a.
    Use the 'tail_indices' function to get the indices of tail elements.    
    
    Elements are not in any particular order.
    
    Args:
        a             (numpy array):    Array of values to be found tail in
        n             (int):            Number of elements in the tail
        lowest_values (bool):           If True, indices to n lowest values are returned (low tail), else high tail.

    Returns:
        (numpy array):      Tail elements of a

    Example:
        The module is called (from python) like this::

            tail(np.array([2, 3, 1, 4, 0, 3, 0, 2, 1, 1]),5)

    Notes:
        Author: g46987 (Orest)
    """
    return a[tail_indices(a,n,lowest_values=lowest_values)]