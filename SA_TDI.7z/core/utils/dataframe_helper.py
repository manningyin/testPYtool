"""
Helper utilities for pandas dataframe. Currently mostly in interaction with Excel.


Notes:
    Author: Shengyao

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       23feb2018   JBrandt     Adding header. Added function to write to multiple sheets.
    ======= =========   =========   ========================================================================================
"""
# -*- coding: utf-8 -*-
import os
import pandas as pd
import datetime as dt
from core.system import envir
from core.file import filename
from core.utils import dict_helper
from core.utils import directory
import sys
from pandas.io.clipboard import clipboard_set
try:
    import openpyxl
except:
    pass


def add_sheet_to_excel(df,
                       full_path,
                       sheet_name       = 'Sheet1',
                       replace_sheet_if_exist = True,
                       include_index    = False,
                       info             = 0
                       ):
    """
    Writes dataframe to a sheet in an excel workbook (already existing or nor).

    If the workbook already exists, it will add a sheet with the specified name.
    If the workbook already has a sheet with the chosen name, the function will either replace the sheet
    or create a new sheet with an integer post-fix added to the sheet name.

    Args:
        df                      (dataframe):    Data that will be inserted into excel file.
        full_path               (str):          Full path for the destination excel file (e.g. h:/save_folder/my_file.xlsx)
        sheet_name              (str):          Name of the sheet where data will be placed in the excel file
        replace_sheet_if_exist  (bool):         [default=True] If True an existing sheet with same name as "sheet_name"
                                                will be replaced. If False the new sheet will be added with sheet-name:
                                                <sheet_name>1
        include_index           (bool):         [default=False] Include the dataframe index in the data written to excel?

    Returns:
        (None):     Nothing - but adds dataframe to excel file.

    Example:
        The module is called (from python) like this::

            import pandas as pd
            from core.utils import dataframe_helper

            my_df = pd.DataFrame(
                    [
                    {'var1': 7, 'var2': 'some_data'},
                    {'var1': 1, 'var2': 'some other data'},
                    {'var1': 19, 'var2': 'text text text'},
                    ]
                    )

            dataframe_helper.add_sheet_to_excel(df                      = my_df,
                                                destination             = 'h:/my_test_data.xlsx',
                                                sheet_name              = 'my_python_test_sheet',
                                                replace_sheet_if_exist  = True,
                                                include_index           = False,
                                                )

    Warning:
        Note that this function DOES NOT support old .xls format.

    Notes:
        Author: JBrandt (g50444)
    """

    if filename.get_extension(full_path) == 'XLS':
        raise KeyError('Old XLS format is not supported. Please use xlsx...')

    # Ensure that the directory exists. If not it will be created.
    directory.create(full_path, info = info)

    writer = pd.ExcelWriter(full_path, engine='openpyxl')

    if os.path.isfile(full_path):
        # Destination excel file already exists.
        book = openpyxl.load_workbook(full_path)
        if replace_sheet_if_exist and (sheet_name in book.sheetnames):
            # The destination excel file already has a sheet with the chosen name.
            # We will delete (an replace) it...
            del book[sheet_name]

        writer.book = book

    df.to_excel(writer, sheet_name = sheet_name, index = include_index)  # send df to writer

    writer.save()
    writer.close()


def read_all_sheets_from_excel(file_path):
    """
    Reads all sheets from an excel workbook into a list of dicts of dataframes.

    The structure of the output is:
        {
        <sheet_name_1> : <sheet as dataframe>,
        <sheet_name_2> : <sheet as dataframe>,
        <sheet_name_3> : <sheet as dataframe>,
        }

    Args:
        file_path   (str):  Path for excel workbook

    Returns:
        (dicts of dataframe):   Dictionary of sheet-names and dataframes holding the data
                                See main header part for example.

    Example:
        The module is called (from python) like this::

            from core.utils import dataframe_helper

            all_workbooks = dataframe_helper.read_all_sheets_from_excel('h:/my_excel_file.xlsx')

            my_sheet_df = all_workbooks['my_chosen_sheet']

    Notes:
        Author: JBrandt (g50444)
    """
    xls = pd.ExcelFile(file_path)

    output = {}

    for sheet_name in xls.sheet_names:
        sheet = pd.read_excel(xls,sheet_name)
        output = dict_helper.merge_dicts(output,{sheet_name : sheet})
    return output


def writeToExcel_autoAdj(writer, sheetname, df, index=False):
    """
    This is a improved version of writing DataFrame to excel (it will auto adjust the column width to fit the content)

    Args:
        writer       (pd.ExcelWriter):    pd ExcelWriter object
        sheetname               (str):    Name of the sheet you want to put in
        df             (pd.DataFrame):    The DataFrame you want to write to
        index                  (bool):    Decide whether use index when output df to excel

    Example:
        The function can be used like this::

            import pandas as pd
            from core.utils import dataframe_helper

            writerObj = pd.ExcelWriter(resultFileLocation, engine='xlsxwriter')
            dataframe_helper.writeToExcel_autoAdj(writerObj, sheetname=calculation, df = result_df)
            writerObj.close()

    Notes:
        Author: g48454 (Shengyao)
    """

    df.to_excel(writer, sheet_name=sheetname, index=index, encoding='utf8')  # send df to writer
    worksheet = writer.sheets[sheetname]  # pull worksheet object
    if index:
        enum_start = 1
        try:
            max_len = max((df.index.astype(str).map(len).max(), len(str(df.index.name)))) + 2
        except:
            max_len = 50
        worksheet.set_column(0, 0, max_len)
    else:
        enum_start = 0
    for idx, col in enumerate(df, enum_start):  # loop through all columns
        series = df[col]
        try:
            max_len = max((
                series.astype(str).map(len).max(),  # len of largest item
                len(str(series.name))  # len of column name/header
            )) + 2  # adding a little extra space
        except:
            max_len = 100
        worksheet.set_column(idx, idx, max_len)  # set column width


def construct_save_path(path=None, name=None):
    if path is None:
        save_path = envir.logging_path()
    else:
        save_path = path
    if name is None:
        module_name = str(os.path.basename(sys.argv[0]).split('.')[0])
        save_name = os.getenv('username') + '_' + module_name + '_' + dt.datetime.now().strftime('%Y%m%d-%H%M%S') + '.xlsx'
    else:
        save_name = name
    if not save_name.endswith('.xlsx'):
        save_name += '.xlsx'
    if not os.path.isdir(save_path):
        os.makedirs(save_path)
    norm_path = os.path.normpath(save_path + '/' + save_name)
    return norm_path


def output_df_to_excel(dfs, name=None, sheet_names=None, path=None, index=False):
    """
    This function takes one or several DataFrames, and prints each one to an excel sheet (in the same file), which
    is then saved to provided path

    Some logic for giving default sheet names is provided, and the "writeToExcel_autoAdj" is utilized to format the
    sheets correctly.

    Args:
        dfs    (DataFrame or list of DataFrames):  Data to be saved to excel. If a list is provided, each is saved in
                                                   a separate sheet
        name                               (str):  Name of the file
        sheet_names         (str or list of str):  Name/names to be given to the sheet(s)
        path                               (str):  The path to where the DataFrame is saved
        index                             (bool):  Whether to include index or not

    Warning:
        This function automatically saves the path to clipboard, thus overwriting anything previously saved to clipboard
        by the user.

    Example:
        The module is called (from python) like this::

            import pandas as pd
            df1 = pd.DataFrame([[1,2,3,4]])
            df2 = pd.DataFrame([[5,6,7,8]])

            output_df_to_excel(dfs=[df1, df2], sheet_names=['Test1', 'Test2'])

    Notes:
        Author: g48606
    """
    dfs = dfs if isinstance(dfs, list) else [dfs]
    names = format_name(no_of_sheets=len(dfs), name=sheet_names)

    norm_path = construct_save_path(path=path, name=name)
    with pd.ExcelWriter(norm_path, engine='xlsxwriter') as writerObj:
        for i in range(len(dfs)):
            writeToExcel_autoAdj(writerObj, sheetname=names[i], df=dfs[i], index=index)
    print("File saved to path: " + norm_path)

    clipboard_set(norm_path)
    print("Path copied to clipboard")


def format_name(no_of_sheets, name):
    names = name if isinstance(name, list) else [name]
    names = [str(x) for x in names]
    if names == ['None']:
        out = ['Sheet' + str(x) for x in range(1, no_of_sheets + 1)]
    elif len(names) < no_of_sheets:
        diff = no_of_sheets - len(names)
        out = names
        for i in range(1, diff + 1):
            out.append('Sheet' + str(i))
    elif len(names) > no_of_sheets:
        out = names[:no_of_sheets]
    else:
        out = names
    return out


def transform_id_columns(df_input):
    df = df_input.copy()
    for col in df.columns:
        if col.endswith('_ID') and df[col].dtype == 'float64':
            df[col] = df[col].astype(int)
    return df