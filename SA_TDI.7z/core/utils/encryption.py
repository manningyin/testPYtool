"""
Module for encrypting and decrypting strings

Make sure to use this module for both encrypting and decrypting, to ensure methods for encrypt- and decrypting..

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       23feb2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import base64

def encrypt(text):
    """
    Function for encoding a text string, using base64 encryption

    Always use this function together with decrypt function in same module, to ensure same methods for encrypt-
    and decrypting..

    Args:
        text        (str):    String that should be encrypted
        
    Returns:
        (str):   Encrypted string

    Raises:

    Example:
        The module is called (from python) like this::
        
            encrypted_string = encrypt('this is something that I what to hide away')

    Warning:

    Notes:
        Author: g50444
    """

    return base64.b64encode(text.encode("utf-8")).decode("utf-8")


def decrypt(encrypted_string, encode_type ='base64'):
    """
    Function for decrypting a string, which has been encrypted by this module.

    Always use this function together with encrypt function in same module, to ensure same methods for encrypt-
    and decrypting..

    Args:
        encrypted_string    (str):      Encrypted string
        encode_type         (str):      Type of encoding. Typically "base64" or None (or "None")
        
    Returns:
        (str):   Regular (decrypted) string
        
    Raises:

    Example:
        The module is called (from python) like this::
        
            readable_string = decrypt('SGVsbG8gV29ybGQuIEkgd2FzIG9ubHkgaGlkaW5nIGZvciBhIHdoaWxlLi4u')

    Warning:

    Notes:
        Author: g50444
    """
    if encode_type is None or encode_type == "None":
        return encrypted_string
    elif encode_type.lower() == 'base64':
        return base64.b64decode(encrypted_string).decode("utf-8")
