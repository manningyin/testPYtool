"""
Module that handles directory operations such as creation, deletion, check contents etc.

Warning:
    Please be aware that this module can be used for creating and deleting folders

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       02JAN2017   G50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import os
def create(directory_path,
           info            =  0
           ):
    """
    This module checks if a directory exists, and creates it if it does not...
    
    First the module checks if the stated folder/directory exists.
     - If it already exists, nothing happens - function terminates.
     - If it does not, the folder/directory is created.
    
    It could also include an business example:
    
    
    Args:
        directory_path      (str):      Full or relative path of a folder that needs to exist when function ends
        info                (int):      Level of information printed. The higher, the more information is printed
    
    Returns:
        (None): Function does not return anything
    
    Raises:
        Re-raising issues from os.makedirs

    Example:
        The module is called (from python) like this
        
            create(directory_path = 'c:/working/test/new_folder/new_subfolder')
            
    Warning:
        This function CREATES folders
    
    Notes:
        Author: g50444
    """

    if directory_path.rfind(".") > max(directory_path.rfind("\\"),directory_path.rfind("/")):
        # The reference contains file. We will find the directory part
        folder_dir_path = directory_path[:directory_path.replace('\\','/').rfind('/') + 1]
    else:
        folder_dir_path = directory_path

    if not os.path.exists(folder_dir_path):
        # Directory does not exist. We will create it.
        if info > 0:
            print('Directory:', folder_dir_path, 'does not exist. It will be created now...')
        try:
            os.makedirs(folder_dir_path)
        except:
            raise

def is_accessible(directory_path):
    """
    Determines if directory is accessible or not.

    Returns True if it is accessible, False if not.

    Args:
        directory_path          (str):    Full path for the directory

    Returns:
        (bool):   True if directory is accessible, False if not

    Raises:

    Example:
        The module is called (from python) like this::

            from core.utils import directory

            if not directory.is_accessible(r'c:\working\data\guestbook'):
                print('Directory "' + r'c:\working\data\guestbook' + '" is not accessible!')

    Warning:

    Notes:
        Author: g50444
    """

    return os.path.isdir(directory_path)


def codelib_path():
    """
    Finds and returns the path of code-lib folder for current code-lib execution.

    Returns:
        (str):  Path of the code-lib - e.g. c:\\working\git\code-lib

    Example:
        The module is called (from python) like this::

            cur_code_lib_path = codelib_path()

    Notes:
        Author: Shengyao
    """
    return os.getcwd()[:os.getcwd().rfind("code-lib") + 8]

def dir(folder):
    """
    Get all elements in a directory as list (corresponding to cmd "dir" function)

    Args:
        folder  (str):      Full path of the folder for which content should be returned

    Returns:
        (list):     All objects in the directory (folders and files)

    Example:
        The module is called (from python) like this::

            h_drive_content = dir('h:/')

    Notes:
        Author: JBrandt
    """
    dir = os.listdir(folder)

    return dir

def starts_and_ends_with(str,
                         startswith = '',
                         endswith   = '',
                         ):
    """
    Determines if a strings starts- and ends with specific sub-strings.

    Combines the build in startswith() and endswith() string-operations. Function is CASE sensitive.

    Args:
        str         (str):  String that should be "examined"
        startswith  (str):  [default = ''] Function can* returns True if the "str" begins with this sub-string.
                            (* this criteria is "AND" combined with the endswith criteria)
        endswith    (str):  [default = ''] Function can* returns True if the "str" ends with this sub-string.
                            (* this criteria is "AND" combined with the startswith criteria)

    Returns:
        (bool):     True if both str begins with the text in "startswith" AND ends with the text in "endswith".

    Example:
        The module is called (from python) like this::

            file_as_expected = starts_and_ends_with(str         = 'my_own_special_purpose_data_file.csv',
                                                    startswith  = 'my_own',
                                                    endswith    = '.csv',
                                                    )
    Warning:

    Notes:
        Author: JBrandt
    """
    filter_match = True

    if str.lower().endswith(endswith.lower()):
        # Filter match (if a non-filter match has not already been found)
        filter_match = True & filter_match
    else:
        # Current objects does not match endswith criteria
        filter_match = False

    if str.lower().startswith(startswith.lower()):
        # Filter match (if a non-filter match has not already been found)
        filter_match = True & filter_match
    else:
        # Current objects does not match file starts-with criteria
        filter_match = False

    return filter_match

def dir_with_filter(folder,
                    starts_with = '',
                    end_swith    ='',
                    ):
    """
    Returns all objects (files and folders) in a directory that matches specific criteria.

    Both filters are case INSENSITIVE.

    Args:
        folder      (str):  Full path of the folder for which content should be returned
        startswith  (str):  [default = ''] Function only returns directory objects with names STARTING with this
                            string (case insensitive).
        end_swith   (str):  [default = ''] Function only returns directory objects with names ENDING with this
                            string. This can be used for file extensions (e.g. .py) (case insensitive).

    Returns:
        (list):     All objects in the directory matching the criteria (folders and files)


    Example:
         The module is called (from python) like this::

            mapping_csv_files = dir_with_filter(folder      = 'c:/Working/git/code-lib/core/time_series/mapping',
                                                starts_with = 'mdhub',
                                                ends_with   = '.csv',
                                                )

    Warning:

    Notes:
        Author: JBrandt
    """
    folder_content = dir(folder) # Getting list of all objects in folder
    matching_filter_objects = []
    for folder_object in folder_content:
        # For each element we check the criteria
        filter_match = starts_and_ends_with(str         = folder_object.lower(),
                                            startswith  = starts_with.lower(),
                                            endswith    = end_swith.lower(),
                                            )
        if filter_match == True:
            # Directory object (file of folder) matches criteria. Adding to list that will be returned.
            matching_filter_objects.append(folder_object)

    return matching_filter_objects


if __name__ == '__main__':

    # a = dir_with_filter(folder = "c:\\Working\\git\\code-lib\\core\\time_series\\mapping\\",
    #                     endswith=".csv",
    #                     starts_with='mdhub',
    #                     )
    a =  mapping_csv_files = dir_with_filter(folder      = 'c:/Working/git/code-lib/core/time_series/mapping',
                                             starts_with = 'mdhub',
                                             end_swith='.csv',
                                             )
    print(a)

    # print(is_accessible(r'\\ap-risk5t\csv-se-dev\D1'))