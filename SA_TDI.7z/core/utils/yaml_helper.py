"""
This module implements a class for safe saving and safe loading yaml files by adding a HASH field. If the file is
changed than the configurations simply does not load.


Notes:
    Author: G48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       23MAR2020   g01571      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import hashlib
import yaml
import json
import os
import datetime as dt


class SignedYAML(yaml.YAMLObject):
    """
       A safe yaml object compatible with yaml module. Saves a checksum to the yaml file. If  any of the configurations
        are changed, loading fails. Can be saved and loaded with all functionalities of yaml module.

       i.e yaml.dump(SignedYAML(config={"a":5}),     same goes with yaml.dumps, yaml.safe_load etc.


       Args:
           config          (dict, list, ie): content of the yaml, should be yaml serializable
           description                (str):   Adds description field to the yaml file
           user                      (bool):   Adds user field to the yaml file
       Warning:
           The configuration to be saved should be JSON serializable meaning that it does not allow Python objects. For
           that see core.caching

       Notes:
           Author: g01571
       """
    yaml_tag = 'SignedYAML'

    def __init__(self, config, description="", user=os.getenv('username'), safe_read=False):
        super().__init__()
        self.__config = config
        self.__hash = self.get_hash(config)
        self.description = description
        self.user = user
        self.date = dt.datetime.now().isoformat()
        self.safe_read = safe_read

    @classmethod
    def get_hash(cls, data):
        """
        Calculates ordered json string of the config input and return the checksum.
        :param data:
        :return:
        """

        data_str = json.dumps(data, sort_keys=True)
        hash_output = hashlib.md5(data_str.encode('utf8')).hexdigest()
        return hash_output

    def get_data(self):
        """
        Safely load data, calculates the cache of the yaml file. If it is different than the one saved on the file,
        fails with "The yaml file you are trying to load was changed" exception
        :return:
        """
        h = self.get_hash(self.__config)
        if (not h == self.__hash) and self.safe_read:
            raise Exception("Object was changed")
        return self.__config

    def set_config(self, config):
        """
        Safely set the config. Calculates checksum of the config file and updates the object
        :param config:
        :return:
        """
        self.__config = config
        self.__hash = self.get_hash(config)


if __name__ == "__main__":
    from core.system.envir import data_path

    config_to_save = SignedYAML(config={'a': 1, 'b': 2, 'c': [4, 10, 1], 'd': {'f': '1'}})
    file = os.path.join(data_path(), 'signed_yaml.yml')

    # Save config safely  (Comment out two lines below after saving once to C:/working/data)
    with open(file, 'w') as f:
        yaml.dump(config_to_save,f)

    # Check out that lines below raises exception when file is changed
    with open(file, 'r+') as f:
        data = yaml.load(f).get_data()

    print(data)