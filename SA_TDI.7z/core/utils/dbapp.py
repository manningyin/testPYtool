# -*- coding: utf-8 -*-
# ======== Standard Code to add code-lib to PYTHONPATH ========
from sys import exit
import sys
import os
import os.path
import pandas as pd
import json
import datetime
import traceback
import logging
from six.moves.urllib.parse import urlencode
from core.utils.parameters import *
import pyodbc
from core.connection.sqltool import convert_decimal
import core.utils.date_helper as dateutils
import io
from unidecode import unidecode

from flask import Flask, Response, abort
from flask import make_response, request, jsonify, redirect
from flask import Blueprint
import time
import re

def is_all_capital(s):
    if len(s):
        return all(x.isupper() or (not x.isalpha()) for x in s)
    else:
        return True

def id_to_list(text):
    l=[]
    s=""
    isac=is_all_capital(text)
  
    for c in text:
        if not c.isalnum() or (not isac and c.isupper()):
            if len(s):
                l.append(s)
                s=""
        if not c.isalnum():
            continue
        s+=c
    if len(s):
        l.append(s)
    return l

def small_caps(text,separator="_"):
    return separator.join(map(lambda x:x.lower(),id_to_list(text)))

def field_to_label(field):
    lab=small_caps(field)
    lab=lab.lower().replace("_"," ")
    lab=lab[0].upper()+lab[1:]
    lab=lab.replace("Undl ","Underlying ")
    lab=lab.replace("Vol ","Volatility ")
    lab=lab.replace(" vol "," volatility ")
    lab=lab.replace("Settlm ","Settlement ")
    lab=lab.replace(" settlm "," settlement ")
    lab=lab.replace(" eod"," EOD")
    lab=lab.replace(" grp "," group ")
    lab=lab.replace("Cpty ","Counterparty ")
    lab=lab.replace("Org ","Org. ")
    lab=lab.replace(" org "," org. ")
    lab=lab.replace(" sec "," sec. ")
    lab=lab.replace("Gnf ","Global Infinity ")
    lab=lab.replace("Sc ","Scenario ")
    lab=lab.replace("Update pgm id","Update pgm. id")
    return lab

def table_label(table):
    lab = field_to_label(table)
    return lab
    
def field_logical_link(database_path, field, schema=None):
    """Guess link based on a field name. This works in MARSP, but may not work in general.
    """
    if schema is not None:
        schema = schema.upper()
    field = field.upper()

    linktab=pd.DataFrame([
    ["PRIMARY_EFFECT_ID", "MARSP",         "/schemas/MARSP/tables/EFFECT"],
    ["UNDL_EFFECT_ID",    "MARSP",         "/schemas/MARSP/tables/EFFECT"],
    ["SETTLM_EFFECT_ID",  "MARSP",         "/schemas/MARSP/tables/EFFECT"],
    ["UPDATE_PGM_ID",     "MARSP",         "/schemas/MARSP/tables/PGM"],
    ["PROJECTION_INTEREST_ID", "MARSP",    "/schemas/MARSP/tables/INTEREST"],
    ["FIXING_TIMING_ID",  "MARSP",         "/schemas/MARSP/tables/TIMING"],
    ["SMILE_VOL_ID",      "MARSP",         "/schemas/MARSP/tables/VOL"],
    ["CONS_ORG_ID",       "MARSP",         "/schemas/MARSP/tables/ORG"],
    ["CPTY_ORG_ID",       "MARSP",         "/schemas/MARSP/tables/ORG"],
    ["CURVE_ID",          "TIP",           "/schemas/TIP/tables/GOTC_CURVE"],
    ], columns=["field","schema","link"])
        
    if schema is None:
        try:
            return database_path+linktab[linktab.field==field].link.values[0]
        except:
            pass
    else:
        try:
            return database_path+linktab[(linktab.field==field) & (linktab.schema==schema)].link.values[0]
        except:
            pass
    if schema is None:
        if field.endswith("_ID"):
            return database_path+"/schemas/MARSP/tables/%s"%(field[:-3])
    if schema in ("MARSP","MARS_TEST"):
        if field.endswith("_ID"):
            return database_path+"/schemas/%s/tables/%s"%(schema,field[:-3])

class Cache:
    def __init__(self,path,expiry):
        "Path to cache files, cache expiry in days (can be float)."
        self.path = path
        self.expiry = float(expiry)*60*60*24
        self.string_memory={}

    def path_for_key(self,key):
        return os.path.join(self.path,key)
        
    def get_string(self,key,create_callback=None):
        if self.expiry<0:
            if create_callback is not None:
                return create_callback()
            else:
                return None
        if key not in self.string_memory:
            path = self.path_for_key(key)
            if (os.path.exists(path) and (time.time()-os.stat(path).st_mtime)<self.expiry):
                value = open(path).read()
                self.string_memory[key]=value
                return value
            else:
                if create_callback is not None:
                    value = create_callback()
                    dir = os.path.split(path)[0]
                    try:
                        os.makedirs(dir)
                    except:
                        pass
                    with open(path,"w") as f:
                        f.write(value)
                    self.string_memory[key]=value
                    return value
                else:
                    return None
        return self.string_memory[key]
        
class QueryResult:
    def __init__(self, success=True, message="OK", columns=[], data=[], sql="", title="", database="", path=None, timestamp=None, json_url=None, html_url=None, cached=False):
        self.success=success
        self.message=message
        self.columns=columns
        self.data=data
        self.sql=sql
        self.title=title
        self.database=database
        self.path=path
        self.json_url=json_url
        self.html_url=html_url
        self.cached = cached
        if timestamp is None:
            timestamp = datetime.datetime.now()
        self.timestamp = timestamp
        
    def df(self,use_labels=False):
        if use_labels:
            columns = [c["label"] for c in self.columns]
        else:
            columns = [c["name"] for c in self.columns]
        return pd.DataFrame(self.data,columns=columns)
    def timestamp_string(self):
        return self.timestamp.strftime("%Y-%m-%d %H:%M:%S")

    @classmethod
    def timestamp_from_string(self,s):
        return datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
        
    def to_json(self, cached=None):
        if cached is None:
            cached=self.cached
        s="{\n"
        s+='"title"     : "%s",\n'%self.title
        s+='"database"  : %s,\n'%json.dumps(self.database)
        s+='"path"      : %s,\n'%json.dumps(self.path)
        s+='"json_url"  : %s,\n'%json.dumps(self.json_url)
        s+='"html_url"  : %s,\n'%json.dumps(self.html_url)
        s+='"success"   : %s,\n'%json.dumps(self.success)
        s+='"timestamp" :"%s",\n'%self.timestamp_string()
        s+='"cached"    : %s,\n'%json.dumps(cached)
        s+='"message"   : %s,\n'%json.dumps(self.message)
        s+='"sql"       : %s,\n'%json.dumps(self.sql)
        s+="\n"
        s+='"columns"   : [\n  '
        s+=",\n  ".join(json.dumps(c) for c in self.columns)+"\n],\n"
        
        s+='"data"      : [\n'
        sep=""
        for row in self.data:
            s+=sep+"  ["
            sep1=""
            for d in row:
                try:
                    s+=sep1+json.dumps(d)
                except:
                    s+=sep1+'"'+repr(d)[1:-1].replace(r"\x",r"\\x").replace('"',r'\"')+'"'
                sep1=", "                
            s+="]"
            sep=",\n"
        s+='\n]}'
        return s

    @classmethod
    def from_json(cls,json_string):
        record = json.loads(json_string)
        return QueryResult(
            success=record.get("success"),
            message=record.get("message"),
            columns=record.get("columns"),
            data=record.get("data"),
            sql=record.get("sql"),
            title=record.get("title"),
            database=record.get("database"),
            path=record.get("path"),
            timestamp=cls.timestamp_from_string(record.get("timestamp")),
            json_url=record.get("json_url"),
            html_url=record.get("html_url"),
            cached=True)
        
class AbstractQuery:
    def __init__(self, name, title=None, cached=False, tags=None, description="", cache_dataframe_in_memory=False):
        self.name = name
        if title is None:
            title = table_label(name)
        self.title=title
        self.cached=cached
        if tags is None:
            tags = title.lower().replace("."," ").split()
            tags.append(name)
        self.tags=tags
        self.description=description
        self.cache_dataframe_in_memory=cache_dataframe_in_memory
        self.df_cache={}

    def parameters_html_form(self, action="#", method="get"):
        s='''
<h2>%s</h2>
  <div class="row">
    <div class="col-sm">
    <b-card>%s</b-card>
    </div>
  </div>
<form action="%s" method="%s">
'''%(self.title,self.description,action,method)
        s+='<button type="submit" class="btn btn-primary" id="submit" value=" Send">Submit</button>'
        s+="</form>\n"
        return s

    def from_key(self,key):
        d=self.resolve_key(key)
        if d is not None:
            return self.get(**d)            
        else:
            raise Exception("Key %s not recognized by %s"%(key,str(self)))

    def subsystem_from_key(self,key):
        if key==self.path():
            return self

    def __call__(self,*arg,**kwarg):
        if self.cache_dataframe_in_memory:
            key = self.key(*arg,**kwarg)
            if key in self.df_cache:
                return self.df_cache[key]
            else:
                df = self.get(*arg,**kwarg).df()
                self.df_cache[key]=df
                return df
        else:
            return self.get(*arg,**kwarg).df()
    def __repr__(self):
        return "%s(%s)"%(self.__class__.__name__,self.path())
    __str__=__repr__
        
class TableAccess(AbstractQuery):
    def __init__(self,name,schema,id_field=None, title=None, cached=False, tags=None, description="", cache_dataframe_in_memory=False):
        AbstractQuery.__init__(self,name, title=title, cached=cached, tags=tags, description=description, cache_dataframe_in_memory=cache_dataframe_in_memory)
        self.schema = schema
        if id_field is None:
            id_field = name.upper()+"_ID"
        self.id_field=id_field

    def parameters_html_form(self, action="#", method="get"):
        d=vars(self)
        d.update(locals())
        d["schemaname"]=self.schema.name
        s='''
<div class="container">
  <div class="row">
    <div class="col-sm">
    <h2>%(title)s</h2>
    Query table <b>%(name)s</b> in schema <b>%(schemaname)s</b>
    </div>
  </div>
  <div class="row">
    <div class="col-sm">
      %(description)s
    </div>
  </div>
  <div class="row">
    <div class="col-sm">
      <form action="%(action)s" method="%(method)s">
'''%d
        s+="""
        <div class="form-group row">
          <label class="col-sm-2 col-form-label" for="identifier">Identifier:</label>
          <div class="col-sm-10">
            <input type="text" id="identifier" name="identifier" class="form-control">
          </div>
        </div>        
        <button type="submit" class="btn btn-primary" id="submit" value=" Query">Query</button>
      </form>
    </div>
  </div>
</div>
"""
        return s

    def path(self):        
        return self.schema.path()+"/tables/"+self.name
    def cache(self):
        return self.schema.database.cache
    def key(self,identifier=None,**kwarg):
        if len(kwarg):
            return None
        if identifier is None:
            return ""
        else:            
            return identifier
    def get_(self,identifier=None,datetime_as_date_string=True,**kwarg):
        schema=self.schema.name
        table = self.name
        id_field = self.id_field
        value = identifier
        try:
            float(value)
        except:
            value=repr(value)
            if not value.startswith("'"):
                value = value[1:]
        if identifier is None:            
            query = "SELECT * FROM %(schema)s.%(table)s"%locals()
        else:
            query = "SELECT * FROM %(schema)s.%(table)s WHERE %(id_field)s = %(value)s"%locals()
        key = self.key(identifier=identifier,**kwarg)
        return self.schema.database.fetch(
          query,
          title=self.title,
          path=key,
          json_url="/%s/%s.json"%(self.path(),key),
          html_url="/%s/%s.html"%(self.path(),key),
          datetime_as_date_string=datetime_as_date_string)
    def get(self,identifier,datetime_as_date_string=True,**kwarg):
        key = self.key(identifier=identifier,**kwarg)
        if not datetime_as_date_string or not self.cached or self.cache() is None or key is None:
            print("Not cached %s"%self.path()+"/"+key)
            return self.get_(identifier,datetime_as_date_string=datetime_as_date_string,**kwarg)
        return QueryResult.from_json(
            self.cache().get_string(self.path()+"/"+str(key)+".json",
                lambda s=self:s.get_(identifier,datetime_as_date_string=datetime_as_date_string,**kwarg).to_json()
            )
        )
    def resolve_key(self,key):
        if key==self.path():
            return dict(identifier=None)
        prefix=self.path()+"/"
        if key.startswith(prefix):            
            return dict(identifier = key[len(prefix):])
    
class Query(AbstractQuery):
    def __init__(self, name, query, database, parameters=None, title=None, cached=False, tags=None, separator="__", description="", cache_dataframe_in_memory=False):
        AbstractQuery.__init__(self,name, title=title, cached=cached, tags=tags, description=description, cache_dataframe_in_memory=cache_dataframe_in_memory)
        self.database = database
        self.query=query
        self.separator=separator
        if parameters is None:
            parameters=[]
        names =  [p["name"] for p in parameters]
        names1=[]
        for n in names:
            if n in names1:
                raise Exception("Duplicate parameter %s in query %s"%(n,self.path()))
            names1.append(n)
        for p in parameters:
            p["label"]=p.get("label",field_to_label(p["name"]))
        for p in self.find_parameters(query):
            if p["name"] not in names:
                parameters.append(p)   
        self.parameters=parameters
    
    @classmethod
    def find_parameters(self,query):
        return [dict(name=n,label=field_to_label(n)) for n in re.findall("%\(([a-zA-Z0-9_]+)\)s",query)]

    def parameters_html_form(self, action="#", method="get"):
        s='''
<div class="container">
  <div class="row">
    <div class="col-sm">
      <h2>%s</h2>
      %s
    </div>
  </div>
  <div class="row">
    <div class="col-sm">
      <form action="%s" method="%s">
'''%(self.title, self.description, action,method)
        for p in self.parameters:
            s+="""
            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="%(name)s">%(label)s:</label>
              <div class="col-sm-10">
                <input type="text" id="%(name)s" name="%(name)s" class="form-control">
              </div>
            </div>
            """%p
        s+="""
        <button type="submit" class="btn btn-primary" id="submit" value=" Query">Query</button>
      </form>
    </div>
  </div>
</div>
"""
        return s
        
    def path(self):        
        return self.database.path()+"/queries/"+self.name

    def cache(self):
        return self.database.cache

    def arg_dict(self,*arg,**kwarg):
        d={p["name"]:p.get("default") for p in self.parameters}
        d.update(kwarg)
        d.update(dict(zip([p["name"] for p in self.parameters],arg)))
        return d

    def key(self,*arg,**kwarg):
        d=self.arg_dict(*arg,**kwarg)
        values = [str(d[p["name"]]) for p in self.parameters]
        for k,v in d.items():
            if v is None:
                raise Exception("Query %s excepts parameter %s"%(self.path(),k))
        return self.separator.join(values)

    def get_(self,*arg,**kwarg):
        d=self.arg_dict(*arg,**kwarg)
        query = self.query%d
        key = self.key(*arg,**kwarg)
        return self.database.fetch(
          query,
          title=self.title,
          path=self.path()+"/"+key,
          json_url=self.path()+"/%s.json"%key,
          html_url=self.path()+"/%s.html"%key,
          datetime_as_date_string=kwarg.get("datetime_as_date_string",True))

    def get(self,*arg,**kwarg):
        key = self.key(*arg,**kwarg)
        datetime_as_date_string = kwarg.get("datetime_as_date_string",True)
        if not datetime_as_date_string or not self.cached or self.cache() is None or key is None:
            print("Not cached %s"%key)
            return self.get_(*arg,**kwarg)
        return QueryResult.from_json(
            self.cache().get_string(self.path()+"/"+key+".json",
                lambda s=self:s.get_(*arg,**kwarg).to_json()
            )
        )

    def resolve_key(self,key):
        if key.startswith(self.path()):
            prefix=self.path()+"/"
            if key.startswith(prefix):
                subkey = key[len(prefix):]            
                d={p["name"]:p.get("default") for p in self.parameters}
                values=subkey.split(self.separator)
                d.update({p["name"]:value for p,value in zip(self.parameters,values)})
                return d
            else:
                return {}
        
class Schema:
    def __init__(self,name,database,cached_tables=None):
        self.name = name
        self.database=database
        self.table_accesses={}
        if cached_tables is None:
            cached_tables=[]
        self.cached_tables=cached_tables[:]
        if name == "MARSP":
            self.cached_tables.extend([
            "INTEREST","CURRENCY","PRODUCT"
        ])
            
    def path(self):
        return self.database.path()+"/schemas/"+self.name
    def table_access(self,name):
        if name not in self.table_accesses:
            cached = name in self.cached_tables
            self.table_accesses[name]=TableAccess(name,self,cached=cached)
        return self.table_accesses[name]
    def resolve_key(self,key):
        prefix=self.path()+"/"
        if key.startswith(prefix):
            try:
                subkey = key[len(prefix):]
                parts = subkey.split("/")
                access_type=parts[0]
                part=parts[1]
                return access_type,part
            except:
                logging.error("Key %s not recognized by schema %s"%(key,self.path()))
                print("Key %s not recognized by schema %s"%(key,self.path()))
                return None
    def from_key(self,key):
        d=self.resolve_key(key)
        if d is not None:
            access_type,part = d
            if access_type == "tables":
                return self.table_access(part).from_key(key)
            else:
                logging.error("Access part of the key %s not recognized by schema %s"%(key,self.path()))
                raise Exception("Access part of the key %s not recognized by schema %s"%(key,self.path()))
        else:
            raise Exception("Key %s not recognized by %s"%(key,str(self)))
    def subsystem_from_key(self,key):
        if key==self.path():
            return self
        d=self.resolve_key(key)
        if d is not None:
            access_type,part = d
            if access_type == "tables":
                return self.table_access(part).subsystem_from_key(key)
            else:
                logging.error("Access part of the key %s not recognized by schema %s (S)"%(key,self.path()))
                raise Exception("Access part of the key %s not recognized by schema %s (S)"%(key,self.path()))
        else:
            raise Exception("Key %s not recognized by %s (S)"%(key,str(self)))
                
    def __getattr__(self,name):
        if name.upper() == name:
            name = name.upper()
            return self.table_access(name)
    def __repr__(self):
        return "%s(%s)"%(self.__class__.__name__,self.path())
    __str__=__repr__
        
class Database:
    url_prefix=""
    def __init__(self,name, connection=None, connection_factory=None, cache=None,):
        """Construct a database from a name and connection.
        Connection can be provided in two ways - as a connection object or as a method that creates a connection
        (a connection_factory). Connection factory (if specified) takes precedence."""
        self.name=name
        self._connection=connection
        if connection_factory is None:
            connection_factory=lambda:Registry.connection()
        self.connection_factory=connection_factory
        self.schemas={}
        self.cache = cache
        self.queries={}

    @property    
    def connection(self):
        if self.connection_factory is None:
            return self._connection
        else:
            
            return self.connection_factory()
            
    def register_query_object(self,query_object):
        self.queries[query_object.name]=query_object
        return self
    def register_query(self, name, query, parameters=None, title=None, cached=False, tags=None, separator="__", description="", cache_dataframe_in_memory=False):
        return self.register_query_object(
            Query(name,query,self,
                parameters=parameters,
                title=title,
                cached=cached,
                tags=tags,
                separator=separator,
                description=description,
                cache_dataframe_in_memory=cache_dataframe_in_memory
            )
        )
    def path(self):
        return "dbapi/"+self.name
    def field_to_label(self,field):
        return field_to_label(field)
    def field_link(self,field):
        return field_logical_link(self.path(),field)
    def fetch(self,query,title="",path=None,json_url=None,html_url=None,datetime_as_date_string=True):
        logging.debug("Fetch from %s"%self.name)
        logging.debug("Query: %s"%query)
        if json_url is None:
            json_url=self.url_prefix+self.path()+"query_result.json?"+urlencode({"sql":query})
        if html_url is None:
            html_url=self.url_prefix+self.path()+"query_result.html?"+urlencode({"sql":query})
        
        try:
            cursor = self.connection.cursor()            
            cursor.execute(query)
            data = [convert_decimal(row) for row in cursor.fetchall()]
            if datetime_as_date_string:
                data = [[(dateutils.date_format(x) if type(x) is datetime.datetime else x) for x in row] for row in data]
            columns=[dict(
              name=c[0].upper(),
              type_code=getattr(c[1],"__name__",None),
              label=self.field_to_label(c[0]),
              link=self.field_link(c[0]),
              from_query=True) for c in cursor.description]
            return QueryResult(
                success=True,
                message="OK",
                columns=columns,
                data=data,
                sql=query,
                title=title,
                database=self.name,
                path=path,
                json_url=json_url,
                html_url=html_url,
            )
        except:
            logging.exception("Error querying %s with %s:"%(self.name,query))
            return QueryResult(
                success=False,
                message=traceback.format_exc(),
                columns=[],
                data=[],
                sql=query,
                title=title,
                database=self.name,
                path=path,
                json_url=json_url,
                html_url=html_url,
            )
    def schema(self,name):
        if name not in self.schemas:
            self.schemas[name]=Schema(name,self)
        return self.schemas[name]

    def resolve_key(self,key):
        prefix=self.path()+"/"
        if key.startswith(prefix):
            try:
                subkey = key[len(prefix):]
                parts = subkey.split("/")
                access_type=parts[0]
                part=parts[1]
                return access_type,part
            except:
                logging.error("Key %s not recognized by database %s"%(key,self.path()))
                print("Key %s not recognized by database %s"%(key,self.path()))
        else:
            raise Exception("Key %s not recognized by %s"%(key,str(self)))

    def from_key(self,key):
        d=self.resolve_key(key)
        if d is not None:
            access_type,part = d
            if access_type == "schemas":
                return self.schema(part).from_key(key)
            if access_type == "queries":
                if part in self.queries:
                    return self.queries[part].from_key(key)
                else:
                    logging.error("Query %s not registered by database %s"%(key,self.path()))
                    raise Exception("Query %s not registered by database %s"%(part,self.path()))
            else:
                logging.error("Access part of the key %s not recognized by database %s"%(key,self.path()))
                raise Exception("Access part of the key %s not recognized by database %s"%(key,self.path()))

    def subsystem_from_key(self,key):
        if key==self.path():
            return self
        d=self.resolve_key(key)
        if d is not None:
            access_type,part = d
            if access_type == "schemas":
                return self.schema(part).subsystem_from_key(key)
            if access_type == "queries":
                if part in self.queries:
                    return self.queries[part].subsystem_from_key(key)
                else:
                    logging.error("Query %s not registered by database %s (S)"%(key,self.path()))
                    raise Exception("Query %s not registered by database %s (S)"%(part,self.path()))
            else:
                logging.error("Access part of the key %s not recognized by database %s (S)"%(key,self.path()))
                raise Exception("Access part of the key %s not recognized by database %s (S)"%(key,self.path()))
        
    def __getattr__(self,name):
        if name in self.queries:
            return self.queries[name]
        if name.upper() == name:
            return self.schema(name)
        
    def __repr__(self):
        return "%s(%s)"%(self.__class__.__name__,self.path())
    __str__=__repr__

class PageRegistryMixin:
    pub_register=[]
    def page(self,f):
        import inspect
        name = f.__name__
        module = f.__module__
        path = "%(module)s/%(name)s"%locals()
        label = table_label(name)
        args = inspect.getargspec(f).args
        if args is None:
            args=[]
        defaults = inspect.getargspec(f).defaults
        if defaults is None:
            defaults=[]
        defaults =[None]*(len(args)-len(defaults)) + defaults
        arguments = [dict(name=arg,default=default,label=field_to_label(arg)) for arg,default in zip(args,defaults)]
        wf_route="/pub/%(path)s.html"%locals()
        qf_route="/pub-qui/%(path)s.html"%locals()
        self.pub_register.append(dict(path=path, label=label, f=f, arguments = arguments,url=wf_route,query_url=qf_route,pass_app=False))
        return f

    def app_page(self,f):
        import inspect
        name = f.__name__
        module = f.__module__
        path = "%(module)s/%(name)s"%locals()
        label = table_label(name)
        args = inspect.getargspec(f).args
        if args is None:
            args=[]
        defaults = inspect.getargspec(f).defaults
        if defaults is None:
            defaults=[]
        defaults =[None]*(len(args)-len(defaults)) + defaults
        arguments = [dict(name=arg,default=default,label=field_to_label(arg)) for arg,default in zip(args,defaults)]
        arguments=arguments[1:]
        wf_route="/pub/%(path)s.html"%locals()
        qf_route="/pub-qui/%(path)s.html"%locals()
        self.pub_register.append(dict(path=path, label=label, f=f, arguments = arguments,url=wf_route,query_url=qf_route,pass_app=True))
        return f

class Registry(PageRegistryMixin):
    _connection=None
    connection_factory=None
    @classmethod
    def connection(cls):
        if cls.connection_factory is None:
            return cls._connection
        else:
            return cls.connection_factory()
        raise Exception("Registry does not have a connection set. Mount registry into DBApp.")
    database=Database("default")
        
class DBApp(ParameterSet,PageRegistryMixin):
    def __init__(self, name, description, *parameters):
        parameters=list(parameters)
        parameters.extend([
            Parameter("config", "config.yaml", "Path to the config file",hide_in=["yaml","json"]),
            Parameter("cache_dir",    "cache",       "Directory to store cache files"),
            Parameter("cache_expiry", "1",           "Number of days after which cache will be refreshed."),
            Parameter("database",     "infop",       "Database"),
            Parameter("user",         "MARS_TEST",   "Database user"),
            Password("password",  Password.decode('IFMUINCZLJIFIMBQKVNFUMCYIM======'), "Password for the database (encoded)"),
            Parameter("port",8086,"Port number for the web application"),
            FlagParameter("nogui","Do not start a web GUI, command line only",hide_in=["form","yaml","json"]),
        ])
        ParameterSet.__init__(self,description,*parameters)
        self.name = name
        self._connection = None
        self.database = Registry.database
        
        Registry.connection_factory=self.connection
        self.databases={Registry.database.name:Registry.database}
        self._blueprint=None
        self.pub_register=Registry.pub_register
        self.in_shutdown=False
        
    def run(self,path=None):
        """Start the DBApp in library mode.
        This will initialize the parameters and configure parameter dependent services, e.g. db connection.
        """
        if not self.init(path):
            print("Config file created, please review and restart.")
            exit(0)
        self.configure()
        return self
    def run_with_gui(self,path=None):
        """Initialize and start the webapp GUI (i.e. start in "framework mode")"""
        self.run(path)
        if not self.data["nogui"]:
            self.run_gui()
    def run_gui(self,always=False):
        """Start the webapp GUI
        All the initialization tasks like parameter loading and connection opening should be done before this call.
        """
        import webbrowser
        #import socket
        if not self.in_shutdown and (not self.data["nogui"] or always):
            app=Flask(__name__)
            self.flask = app
            app.register_blueprint(self.blueprint())
            #server = socket.gethostbyname(socket.gethostname())
            port = self.data["port"]
            server = "127.0.0.1"
            webbrowser.open("http://%(server)s:%(port)s"%locals())
            app.run(debug=True,threaded=False,port=port)
    def connection(self):
        database = self.data["database"]
        user     = self.data["user"]
        password = self.data["password"]
        if self._connection is None:
            try:
                connection_string = "Driver={Oracle in OraHome11gR2_64Bit_1}; Dbq=%(database)s; Uid=%(user)s; Pwd=%(password)s"%locals()
                logging.debug("TRY "+connection_string)
                self._connection=pyodbc.connect(connection_string)
                self.databases[database]=Database(database,self._connection, cache=self.cache)
            except:
                logging.exception("Failed to connect to database, retrying with an alternative connection string.")
                connection_string = "Driver={Oracle in OraClient11Home_x64_1}; Dbq=%(database)s; Uid=%(user)s; Pwd=%(password)s"%locals()
                logging.debug("TRY "+connection_string)
                self._connection=pyodbc.connect(connection_string)
                self.databases[database]=Database(database,self._connection, cache=self.cache)
        return self._connection
    def configure(self):
        "Run whenever parameters change."
        self.cache = Cache(self.data["cache_dir"],float(self.data["cache_expiry"]))
        for db in self.databases.values():
            db.cache=self.cache
        self._connection=None
        self.connection()
    def resolve_key(self,key):
            try:            
                subkey = key
                parts = subkey.split("/")
                access_type=parts[0]
                part=parts[1]
                return access_type,part
            except:
                logging.error("Key %s not recognized"%(key))
                print("Key %s not recognized"%(key))
    def from_key(self,key):
        d=self.resolve_key(key)
        if d is not None:
            access_type,part = d
            if access_type == "dbapi":
                if part not in self.databases:
                    logging.error("Database %s (part of key %s) not registered"%(part,key))
                    raise Exception("Database %s (part of key %s) not registered"%(part,key))                    
                return self.databases[part].from_key(key)
            else:
                logging.error("Access part of the key %s not recognized"%(key))
                raise Exception("Access part of the key %s not recognized"%(key))

    def subsystem_from_key(self,key):
        if key=="dbapi":
            return self
        d=self.resolve_key(key)
        if d is not None:
            access_type,part = d
            if access_type == "dbapi":
                if part not in self.databases:
                    logging.error("Database %s (part of key %s) not registered (S)"%(part,key))
                    raise Exception("Database %s (part of key %s) not registered (S)"%(part,key))                    
                return self.databases[part].subsystem_from_key(key)
            else:
                logging.error("Access part of the key %s not recognized (S)"%(key))
                raise Exception("Access part of the key %s not recognized (S)"%(key))

    def web_json(self,subkey):
        key = "dbapi/"+subkey
        try:
            o=self.from_key(key)
        except:
            return jsonify(dict(success=False,path=key,message=traceback.format_exc()))
        if o is None:
            return jsonify(dict(success=False,path=key,message="Not found"))
        return Response(o.to_json(),mimetype='application/json')

    def web_csv(self,subkey):
        key = "dbapi/"+subkey
        try:
            o=self.from_key(key)
            if o is None:
                df=pd.DataFrame([dict(success=False,path=key,message="Not found")])
            else:
                df=o.df()
        except:
            df=pd.DataFrame([dict(success=False,path=key,message=traceback.format_exc())])
        stream = io.BytesIO()
        df.to_csv(stream,index=False,sep=";")
        return Response(stream.getvalue(),mimetype='text/csv')

    def web_xlsx(self,subkey):
        key = "dbapi/"+subkey
        output = io.BytesIO()
        writer = pd.ExcelWriter(output)
    
        
        try:
            o=self.from_key(key)
            if o is None:
                df=pd.DataFrame([dict(success=False,path=key,message="Not found")])
                df.to_excel(writer,"ERROR",index=False)
            else:
                df=o.df()
                df.to_excel(writer,"Data",index=False)
                cdf=pd.DataFrame(o.columns)
                cdf.to_excel(writer,"Columns",index=False)
                d=dict(vars(o))
                del d["data"]
                del d["columns"]
                mdf=pd.DataFrame([d])
                mdf.to_excel(writer,"Meta",index=False)
        except:
            df=pd.DataFrame([dict(success=False,path=key,message=traceback.format_exc())])
            df.to_excel(writer,"ERROR",index=False)

        writer.close()
        resp = make_response(output.getvalue())
        filename=subkey.split("/")[-1]
        resp.headers['Content-Disposition'] = 'attachment; filename=%s.xlsx'%filename
        resp.headers["Content-type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        return resp

    def web_config_form(self):
        d=request.values
        s=self.web_headder(title="Config")
        
        s+='<div class="container"><div class="row"><div class="col">\n'
        s+="<h2>Configuration</h2>\n"
        if len(d):
            s+="""<b-alert show variant="warning">Most parameters need a restart to take effect.</b-alert>"""
        
        for x in self.parameters:
            if x.id in d:
                self.data[x.id] = x.decode_form(d[x.id])

        path = self.data.get("config","config.yaml")
        with open(path,"w") as f:
            f.write(self.to_yaml())
        
        s+=self.to_html_form(action="/config/form.html")
        s+="</div></div></div>"
        s+='<a href="/shutdown" class="btn btn-danger btn-sm">Shutdown</a>'

        s+=self.web_footer()
        return s

    def web_query_ui(self,subkey):
        key = "dbapi/"+subkey        
        o=self.subsystem_from_key(key)
        s=self.web_headder("Query")
        if o is None:
            s+="""<div class="alert alert-danger" role="alert">Query subsystem %s not found</div>"""%key
        else:
            s+=o.parameters_html_form(action="/dbapi-quir/"+subkey)
        s+=self.web_footer()
        return s

    def web_query_ui_result(self,subkey):
        key = "dbapi/"+subkey       
        o=self.subsystem_from_key(key)
        s=self.web_headder("Query result")
        if o is None:
            s+="""<div class="alert alert-danger" role="alert">Query subsystem %s not found</div>"""%key
            s+=self.web_footer()
            return s
        else:
            return redirect("/"+o.path()+"/"+o.key(**dict(request.values.items()))+".html")
    
    def web_navbar(self):
        d=vars(self)
        qmenu=""
        for db in self.databases.values():
            for q in db.queries.values():
                title=q.title
                url = q.path().replace("dbapi/","/dbapi-qui/")+".html"          
                qmenu+='          <b-dropdown-item href="%(url)s">%(title)s</b-dropdown-item>\n'%locals()
        d["qmenu"]=qmenu

        qtables=""
        for db in self.databases.values():
            for s in db.schemas.values():
                for t in s.table_accesses.values():
                    title=t.title
                    url = t.path().replace("dbapi/","/dbapi-qui/")+".html"          
                    qtables+='          <b-dropdown-item href="%(url)s">%(title)s</b-dropdown-item>\n'%locals()        
        d["qtables"]=qtables

        pages=""
        for r in self.pub_register:
            pages+='          <b-dropdown-item href="%(query_url)s">%(label)s</b-dropdown-item>\n'%r
        d["pages"]=pages

        return """<b-navbar toggleable="md" type="dark" variant="info">

  <b-navbar-toggle target="nav_collapse"></b-navbar-toggle>

  <b-navbar-brand href="/index.html">%(name)s</b-navbar-brand>

  <b-collapse is-nav id="nav_collapse">

    <b-navbar-nav>
        <b-nav-item-dropdown text="Queries" left>
%(qmenu)s
        </b-nav-item-dropdown>    
        <b-nav-item-dropdown text="Tables" left>
%(qtables)s
        </b-nav-item-dropdown>    
        <b-nav-item-dropdown text="Pages" left>
%(pages)s
        </b-nav-item-dropdown>    
        <b-nav-item href="/config/form.html">Config</b-nav-item>
    </b-navbar-nav>

  </b-collapse>
</b-navbar>"""%d

    def web_html(self,subkey):
        key = "dbapi/"+subkey
        o=self.from_key(key)
            
        s=self.web_headder(title=o.title)
        d=vars(o)    
        if o.success:
            d["cachebadge"]="<b-badge pill variant='info'>cached</b-badge>" if o.cached else ""
            dc =""
            if len(o.data)==0:
                dc='<div class="alert alert-danger" role="alert">No data</div>'
            elif len(o.data)==1:
                dc='<table class="table table-hover">\n'
                for field,value in zip(o.columns,o.data[0]):
                    try:
                        value=unidecode(str(value))
                    except:
                        value=repr(value)[1:-1]
                    if field.get("link") is not None:
                        value = '<a href="/%s/%s.html">%s</a>'%(field["link"],value,value)
                    dd=dict(value=value,**field)
                    dc+='<tr><th>%(label)s</th><td>%(value)s</td></tr>\n'%dd
                dc+="</table>\n"
            else:
                dc='<table class="table table-hover">\n'
                dc+="  <thead>\n"
                dc+="    <tr>"+"".join("<th>%s</th>"%field["label"] for field in o.columns)+"</tr>\n"
                dc+="    <tr>"+"".join("<th><small>%s</small></th>"%field["name"] for field in o.columns)+"</tr>\n"
                dc+="  </thead>\n"
                dc+="  <tbody>\n"
                for row in o.data:
                    dc+="    <tr>"
                    for field,value in zip(o.columns,row):
                        try:
                            value=unidecode(str(value))
                        except:
                            value=repr(value)[1:-1]
                        if field.get("link") is not None:
                            value = '<a href="/%s/%s.html">%s</a>'%(field["link"],value,str(value))
                        dc+='<td>%s</td>'%value
                    dc+="</tr>\n"
                dc+="  <tbody>\n"
                dc+="</table>\n"
            d["data_content"]=str(dc)
            s+=u"""
<div class="container">
  <h2>%(title)s</h2>
  <p/>
  <div class="row">
    <div class="col-sm">
    <b-card>
      <div class="container">
        <div class="row">
          <div class="col-sm">Timestamp:</div>
          <div class="col-sm">%(timestamp)s  %(cachebadge)s</div>
          <div class="col-sm">
            <a href="%(json_url)s">(json)</a>
            <a href="/%(path)s.csv">(csv)</a>
            <a href="/%(path)s.xlsx">(xlsx)</a>
          </div>
        </div>
      </div>
    </b-card>
    </div>
  </div>
  <p/>
  <p/>
  <div class="row">
    <div class="col-sm">%(data_content)s</div>
  </div>
  <div class="row">
    <div class="col-sm">
    <b-card>
      <div class="container">
      <div class="row">
        <div class="col-sm">Database:</div> <div class="col-sm">%(database)s</div>
      </div>
      <div class="row">
        <div class="col-sm">Path:</div> <div class="col-sm">%(path)s</div>
      </div>
      <div class="row">
        <div class="col-sm">Message:</div> <div class="col-sm"><pre>%(message)s</pre></div>
      </div>
      <div class="row">
        <div class="col-sm">SQL:</div> <div class="col-sm"><pre>%(sql)s</pre></div>
      </div>
      </div>
    </b-card>
    </div>
</div>            
     """%d
        else:
            s+="""<p/>
<div class="container">
  <h2>Error</h2>
  <div class="row">
    <div class="col-sm">
      <div class="alert alert-danger" role="alert">
<pre>
%(message)s
</pre>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm">
    SQL:
    </div>
    <div class="col-sm">
      <b-card>
<pre>
%(sql)s
</pre>
      </b-card>
    </div>
  </div>
</div>
"""%d
            
        s+=self.web_footer()
           
        return s

    def web_headder(self,title=None):
        if title is None:
            title=self.name
        else:
            if title!=self.name:
                title = self.name+": "+title
        return """<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <title>%(title)s</title>

    <!-- Required Stylesheets -->
    <link type="text/css" rel="stylesheet" href="https://unpkg.com/bootstrap/dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="https://unpkg.com/bootstrap-vue@latest/dist/bootstrap-vue.css" />

    <!-- Required scripts -->
    <script src="https://unpkg.com/vue"></script>
    <script src="https://unpkg.com/babel-polyfill@latest/dist/polyfill.min.js"></script>
    <script src="https://unpkg.com/bootstrap-vue@latest/dist/bootstrap-vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue-resource@1.5.1"></script>
</head>

<body>
    <!-- Our application root element -->
    <div id="app">
"""%locals()+self.web_navbar()
    def web_footer(self):
        return """</div>
  <script>
    window.app = new Vue({
        el: "#app",
        data: {
            appname: '%s'
        }
    });
  </script>        
</body>"""%self.name
    def web_index(self):
        s=self.web_headder(self.name)
        
        s+=u"""
<br/>
<div class="container">
  <h2>%(name)s</h2>
  <p/>
  <div class="row">
    <div class="col-sm">
    <b-card>
%(description)s
    </b-card>
    </div>
  </div>
</div>
 """%vars(self)
        s+=self.web_footer()
        return s
    def create_blueprint(self,name=None):
        if name is None:
            name=self.name
        blueprint = Blueprint(name, __name__)
        blueprint.route("/dbapi/<path:subkey>.json")(self.web_json)
        blueprint.route("/dbapi/<path:subkey>.html")(self.web_html)
        blueprint.route("/dbapi-qui/<path:subkey>.html")(self.web_query_ui)
        blueprint.route("/dbapi-quir/<path:subkey>")(self.web_query_ui_result)
        blueprint.route("/dbapi/<path:subkey>.csv")(self.web_csv)
        blueprint.route("/dbapi/<path:subkey>.xlsx")(self.web_xlsx)
        blueprint.route("/config/form.html",methods=['POST','GET'])(self.web_config_form)
        blueprint.route("/")(self.web_index)
        blueprint.route("/index.html")(self.web_index)
        blueprint.route("/pub/<path:subkey>.html")(self.web_wf)
        blueprint.route("/pub-qui/<path:subkey>.html")(self.web_qf)
        blueprint.route("/shutdown",methods=["GET","POST"])(self.shutdown)
        self._blueprint=blueprint
        return blueprint
    def blueprint(self):
        if self._blueprint is not None:
            return self._blueprint
        return self.create_blueprint()
    
    def web_wf(self,subkey):
        pub = {v["path"]:v for v in self.pub_register}.get(subkey)
        if pub is None:
            s=self.web_headder(subkey)
            s+="""<div class="alert alert-danger" role="alert">Published function %s not found</div>"""%subkey
            s+=self.web_footer()
            return s

        d=request.values
        argvalues = [d.get(a["name"],a.get("default")) for a in pub["arguments"]]
        s=self.web_headder(pub["label"])
        if pub.get("pass_app",False):
            s+=str(pub["f"](self,*argvalues))
        else:
            s+=str(pub["f"](*argvalues))
        s+=self.web_footer()
        return s

    def web_qf(self,subkey):
        pub = {v["path"]:v for v in self.pub_register}.get(subkey)
        if pub is None:
            s=self.web_headder(subkey)
            s+="""<div class="alert alert-danger" role="alert">Published function %s not found</div>"""%subkey
            s+=self.web_footer()
            return s
        arguments = pub["arguments"]
        if not len(arguments):
            return redirect(pub["url"])
        d=request.values
        s=self.web_headder(pub["label"])
        s+='''
<div class="container">
  <div class="row">
    <div class="col-sm">
      <h2>%(label)s</h2>
    </div>
  </div>
  <div class="row">
    <div class="col-sm">
      <form action="%(url)s" method="GET">
'''%pub
        for a in arguments:
            value = d.get(a["name"],a.get("default"))
            dd=dict(**a)
            dd["value"]="" if value is None else ' value="%s" '%value
            s+="""
            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="%(name)s">%(label)s:</label>
              <div class="col-sm-10">
                <input type="text" id="%(name)s" name="%(name)s" %(value)s class="form-control">
              </div>
            </div>
            """%dd
        s+="""
        <button type="submit" class="btn btn-primary" id="submit" value=" Run">Run</button>
      </form>
    </div>
  </div>
</div>
"""
        s+=self.web_footer()
        return s
                
    def shutdown_server(self):
        func = request.environ.get('werkzeug.server.shutdown')
        if func is None:
            raise RuntimeError('Not running with the Werkzeug Server')
        exit()
    def shutdown(self):
        self.in_shutdown=True
        self.shutdown_server()
        return 'Server shutting down...'
        
    def register_database(self,name,connection=None,connection_factory=None):
        self.databases[name]=Database(name,connection=connection,connection_factory=connection_factory,cache=self.cache)
    def __getattr__(self,name):
        return self.databases[name]
    def __repr__(self):
        return "%s('%s')"%(self.__class__.__name__,self.name)
    __str__=__repr__

if False:# __name__=="__main__":
    app = DBApp("Test application")
    app.run()
    
    #app.run()
    #app.run_with_gui()
    
    #res = app.database.fetch("SELECT * FROM MARSP.INTEREST WHERE INTEREST_ID=53")
    #print(res.to_json())
    #print(res.df())
    #res = app.database.MARSP.INTEREST.get(53)
    #print(res.to_json())
    #print(res.df())
    #print(app.database.MARSP.INTEREST(53))
    #print("------------------------")
    #print(app.from_key("dbapi/infop/schemas/MARSP/tables/INTEREST/53").to_json())
    app.database.register_query("interest_by_name","SELECT * FROM MARSP.INTEREST WHERE NAME='%(name)s'")
    app.database.register_query("interest_by_market","SELECT * FROM MARSP.INTEREST WHERE interest_market_id='%(interest_market_id)s'")
    app.database.register_query("interest_all","SELECT * FROM MARSP.INTEREST")
    print(app.database.interest_by_name("EUR-SWAP"))
    print(app.from_key("dbapi/infop/queries/interest_by_name/EUR-SWAP").to_json())
    app.run_gui()