def read_query(file: str, param: dict = {}, path: str=None) -> str:
    """
    Reads a SQL-query from an external file, inserts the parameters and returns it as an string

    param:  file    :   file name including the extension of the file type (e.g. '.txt' or '.sql')
    param:  param   :   Dictionary where the keys are replaced by the corresponding values in the query
    param:  path    :   Path of the SQL-file ('./' is the current folder)
    """
    return open(path + file, 'r').read().format(**param)
