"""
Utility module for dictionaries.

Notes:
    Author: g50444 (JBrandt)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       15feb2018   JBrandt     Initial documentation - deleting merge_two_dicts, added merge_dicts.
    ======= =========   =========   ========================================================================================
"""

import ast
from core.utils import version_independent
from core.utils import list_helper


def merge_dicts(*args):
    """
    Merging of several (limitless and optional number of) dicts into a new dict as a DEEP copy.

    If the same key occurs in several input dicts, the value from the LAST dict is used.

    The function accepts None as first n of N arguments (where n < N). But once first dict is read,
    rest of the elements must be dicts. Example:

        - Accepted input type sequence: (None, None, dict, dict)
        - Illegal input type sequence: (None, dict, None, dict)

    Args:
        *args   (number of dicts):  A number of dicts that should be merged.

    Returns:
        (dict):   Merged dicts.

    Example:
        The module is called (from python) like this::

            from mr.utils import dict_helper
            x = {'a':'This','b':'is'}
            y = {'c':'a','d':'unit'}
            z = {'e':'test.','f':'Hope','g': 'that', 'h':'it','i':'passes!'}

            dict_helper.merge_dicts(x,y,z)

            # Example with input of None

            x = None
            y = {'c':'A','d':'unit'}
            z = {'e':'test.','f':'Hope','g': 'that', 'h':'it','i':'passes!'}
            dict_helper.merge_dicts(x,y,z)

    Test:

        >>> from core.utils import dict_helper
        >>> d = dict_helper.merge_dicts({'dict_one': 1},{'dict_two': 2})
        >>> d.pop('dict_one')
        1
        >>> d.pop('dict_two')
        2

    Warning:
        If the same key occurs in several input dicts, the value from the LAST dict is used.

    Notes:
        Author: g50444 (JBrandt)
    """

    # ===================================================================================
    # This function allows for first n elements to be None.
    # We therefore do an initial search through the input dictionaries in order to
    # determine the first "real" dictionary.
    # ===================================================================================
    for idx,current_dict in enumerate(args):
        if current_dict is None:
            # This is not a dictionary. We will skip this object.
            pass
        else:
            if not type(current_dict) == dict:
                raise KeyError("Function only takes dicts and None types. Current object type is: " + str(type(current_dict)))
            # ===================================================================================
            # First "real" dictionary found. We will deep copy this, making this the basis which
            # rest of the dicts are merged into.
            #
            # Done here - exiting loop!
            # ===================================================================================
            merged_dict = args[idx].copy()
            next_unread_dict_element = idx + 1
            break

    if len(args) >= next_unread_dict_element:
        # ===================================================================================
        # At least one "real" dictionary in input.
        # Looping through the dictionaries, adding them to the merged object.
        # ===================================================================================
        for current_dict in args[next_unread_dict_element:]:
            if not type(current_dict) == dict:
                raise KeyError("Expecting a dicts as input. Current object type is: " + str(type(current_dict)))
            merged_dict.update(current_dict)

    return merged_dict


def object_to_dict(obj):
    """
    Translates various objects (which has dicts as their string representation) into dicts.

    This function should be used for objects when transformed to string has a dict structure.
    E.g. str(my_object) returns {'var1':value1,'var2':value2}

    Args:
        obj     (object or list of objects):    Object(s) that should be transformed to dicts.

    Returns:
        (dict or list of dicts):    All objects resulved as dictionaries.

    Example:
        The module is called (from python) like this::

            from core.utils import dict_helper

            class MySpecialClassOnlyForTest(object):
                def __init__(self, value_a, value_b):
                    self.value_a = value_a
                    self.value_b = value_b

                def __str__(self):
                    return str(dict(value_a=self.value_a, value_b=self.value_b))

            input = [
                MySpecialClassOnlyForTest(value_a = 7, value_b = 9),
                MySpecialClassOnlyForTest(value_a = 13, value_b = 3),
                MySpecialClassOnlyForTest(value_a = 14, value_b = 159),
                MySpecialClassOnlyForTest(value_a = 26, value_b = 5),
                MySpecialClassOnlyForTest(value_a = 35, value_b = 89),
                MySpecialClassOnlyForTest(value_a = 'some', value_b = 'text'),
            ]

            actual = dict_helper.object_to_dict(input)

            expected = [{'value_a': 7, 'value_b': 9},
                        {'value_a': 13, 'value_b': 3},
                        {'value_a': 14, 'value_b': 159},
                        {'value_a': 26, 'value_b': 5},
                        {'value_a': 35, 'value_b': 89},
                        {'value_a': 'some', 'value_b': 'text'}
                        ]

    Warning:
        This function only works for objects that returns a dict syntax when it is translated into str.

    Notes:
        Author: JBrandt
    """
    def one_obj_to_one_dict(one_obj):
        return ast.literal_eval(str(one_obj))

    if type(obj) == list:
        # Input is a list. This function also supports list of dicts-type objects.
        all_dicts = []
        for single_obj in obj:
            all_dicts.append(ast.literal_eval(str(single_obj)))
    else:
        # Input is not a list.
        all_dicts = ast.literal_eval(str(obj))
    return all_dicts


def dict_to_tuples(inp):
    """
    Takes a dictionary and converts it to a list of tuples. If the input is already a list of tuples, return. If the
    input is a single tuple, converts to a list of tuples (with 1 entry).

    This function is useful when handling trade identifier couples of trade_id and source system. While it might be
    easier to input a dictionary with source system as key, and trade_ids as values, the programs can much better handle
    iterating over a list of tuples instead.

    Example:
        Input: {'INFINITY': ['12345', '23456'], 'WALLSTREET': ['34567', '45678']}
        Output: [('12345', 'INFINITY'), ('23456', 'INFINITY'), ('34567', 'WALLSTREET'), ('45678', 'WALLSTREET')]

    Notes:
        Author: g48606 (OskRos)
    """
    if not isinstance(inp, dict):
        inp = inp if isinstance(inp, list) else [inp]
        return inp
    out = []
    for key in inp:
        inp[key] = inp[key] if isinstance(inp[key], list) else [inp[key]]
        for elem in inp[key]:
            out.append((elem, key))
    return out


class DictToObject(dict):
    """
    Generates an object from a dict - enabling my_dict.my_key access (instead of my_dict['my_key'])

    This can be a helpful tool for mocking more complex objects when making small examples and tests.

    The class has been "stolen" from stackoverflow.

    Args:
        **kargs     (dict):     Dict that should be transformed into a simple object
                                Sub dictionaries should be translated separately (see example).

    Returns:
        (DictToObject):     Object representation of the input dictionary.

    Example:
        The module is called (from python) like this::

            my_object = DictToObject(
                                        {
                                        'first_key': 456,
                                        'second_key':
                                                DictToObject(
                                                                {
                                                                'sub_key_1':'some text',
                                                                'sub_key_2': 7913
                                                                }
                                                            )
                                        }
                                    )
            first           = my_object.first_key
            second          = my_object.first_key
            second_first    = my_object.second_key.sub_key_1
            second_second   = my_object.second_key.sub_key_2


    Notes:
        Author: JBrandt (g50444)
    """

    def __init__(self, *args, **kwargs):
        super(DictToObject, self).__init__(*args, **kwargs)
        for arg in args:
            if isinstance(arg, dict):
                for k, v in arg.items():
                    self[k] = v

        if kwargs:
            for k, v in kwargs.items():
                self[k] = v

    def __getattr__(self, attr):
        return self.get(attr)

    def __setattr__(self, key, value):
        self.__setitem__(key, value)

    def __setitem__(self, key, value):
        super(DictToObject, self).__setitem__(key, value)
        self.__dict__.update({key: value})

    def __delattr__(self, item):
        self.__delitem__(item)

    def __delitem__(self, key):
        super(DictToObject, self).__delitem__(key)
        del self.__dict__[key]


def strings_to_dicts(input):
    """
    Transforms (list of) dictionaries represented as strings into "real" dictionaries.

    Function can both be used for list of strings and single strings.

    It is important that the input string(s) has the exact same syntax as dictionaries.

    Args:
        input   (list of str):  Strings exactly matching the syntax for dictionaries. Single str or list of str.

    Returns:
        (list of dict): Str inputs transformed to real dictionaries.

    Example:
        Testable example for list as input:

            >>> from core.utils import dict_helper
            >>> l = ["{'var1': 7, 'var2': 9, 'var3': 13, 'text_var': 'some text'}",
            ...     "{'var13': 13, 'var4': 9, 'var1': 7, 'text_var': 'some other text'}"
            ...     ]
            >>> my_list_of_dicts = dict_helper.strings_to_dicts(l)
            >>> my_list_of_dicts[0]['var3']
            13
            >>> my_list_of_dicts[1]['text_var']
            'some other text'

        Testable example for single str as input:

            >>> from core.utils import dict_helper
            >>> s = "{'var1': 7, 'var2': 9, 'var3': 13, 'text_var': 'some text'}"
            >>> my_dict = dict_helper.strings_to_dicts(s)
            >>> type(my_dict)
            <type 'dict'>
            >>> my_dict['var2']
            9
            >>> my_dict['text_var']
            'some text'

    Notes:
        Author: JBrandt (g50444)
    """

    out_list_of_dicts = []
    # ===================================================================================
    # Using the to_list() function in order to use the same code for both str and lists
    # as input. Special handling of different input types is at end of function.
    # ===================================================================================
    for d_str in list_helper.to_list(input):
        try:
            # Translating the string dict representation to "real" dict
            d_unicode = ast.literal_eval(d_str)
        except SyntaxError:
            raise SyntaxError("The following string could not be transformed to dict. Check syntax: " + str(d_str))

        if not isinstance(d_unicode, dict):
            raise SyntaxError("The following string was not recognised as dict. Check syntax: " + str(d_str))

        # Translating all dictionary elements from unicode to str.
        # This is typically needed when getting JSON objects from various services.
        d = version_independent.uni_to_str(d_unicode)
        out_list_of_dicts.append(d)

    # ===================================================================================
    # If input was a str (only one element), we only return the single element (as dict).
    # Else - we return a list of dicts.
    # ===================================================================================
    if isinstance(input, str):
        return out_list_of_dicts[0]
    else:
        return out_list_of_dicts


if __name__ == '__main__':
    my_object = DictToObject(
        {
            'first_key': 456,
            'second_key':
                DictToObject(
                    {
                        'sub_key_1': 'some text',
                        'sub_key_2': 7913
                    }
                )
        }
    )
    first = my_object.first_key
    second = my_object.first_key
    second_first = my_object.second_key.sub_key_1
    second_second = my_object.second_key.sub_key_2
