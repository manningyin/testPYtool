'''
This module performs various Git tasks

Warning:
    <This section is optional. Please remove this comment line when you use the template>
    Please be aware that this modules DOES SOME IRREVERSIBLE STUFF or that is

Notes:
    Author: G48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       15JAN2017   g48454      Initial creation
    2       31JAN2017   g50444      Changed git_version function so it returns a string (in Python 2) instead of unicode
                                    This to ensure module returns same type in both Python 2 and 3
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''
import sys

def git_version():
    import subprocess
    import os
    def _minimal_ext_cmd(cmd):
        # construct minimal environment
        env = {}
        for k in ['SYSTEMROOT', 'PATH']:
            v = os.environ.get(k)
            if v is not None:
                env[k] = v
        # LANGUAGE is used on win32
        env['LANGUAGE'] = 'C'
        env['LANG'] = 'C'
        env['LC_ALL'] = 'C'
        out = subprocess.Popen(cmd, stdout = subprocess.PIPE, env=env).communicate()[0]
        return out

    try:
        # ===================================================================================
        # The "str" ensures that the returned git revision is both a string in Python 2 and 3
        # (in Python 2 the data type will otherwise be unicode)
        # ===================================================================================
        out = _minimal_ext_cmd(['git', 'rev-parse', 'HEAD'])
        git_revision = str(out.strip().decode('ascii'))
    except OSError:
        git_revision = "Unknown"

    return git_revision