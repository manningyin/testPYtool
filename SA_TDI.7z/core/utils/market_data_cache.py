import datetime
import pandas as pd
from pandas.tseries.offsets import BDay


'''
A simple cache functionality handle the following:

1) load item into cache
2) get item into cache
3) handle common dates issues from different caches.

Notes:
    Author: g48454 (Shengyao Zhu)
    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       03012017     G48454     Initial creation
    ======= =========   =========   ========================================================================================
'''

#TODO: check whether the above header is still compliant with new code standard

# ======== Standard Code to add code-lib to PYTHONPATH ========
class marketDataCacheSet():
    def __init__(self, name):
        self.name = name
        self.cacheList=[]

    def append(self, obj):
        self.cacheList.append(obj)

    def commonDateList(self):
        for x in range(0, len(self.cacheList) - 1):
            item = self.cacheList[x]
            if x == 0:
                master_date_list = item.cacheDate
            else:
                master_date_list = list(set(master_date_list) & set(item.cacheDate))

        master_date_list = sorted(master_date_list)
        return master_date_list

    def lastAllAvaliableDate(self):
        # get the last avaliable day from the market data cache.
        common_date_list=self.commonDateList()
        return common_date_list[-1] +BDay(0)

    def getObjectFromCacheSet(self, name):
        for item in self.cacheList:
            if item.name == name:
                return item

class DataCache():
    def __init__(self, name):
        self.name = name
        self.cacheValue = []
        self.cacheDate = []

    def getvalue(self, d1):
        d1 = self.convert_date(d1)
        return self.cacheValue[self.cacheDate.index(d1)]

    def addItem(self, obj, d1):
        d1=self.convert_date(d1)
        self.cacheValue.append(obj)
        self.cacheDate.append(d1)

    def convert_date(self,d1):
        if type(d1) is datetime.datetime:
            d1 = d1.date()
        if type(d1) is pd.Timestamp:
            d1 = d1.date()

        return d1


    def append_another_cache(self,right):
        for d in right.cacheDate:
            if d not in self.cacheDate:
                item = right.getvalue(d)
                self.addItem(item, d)


