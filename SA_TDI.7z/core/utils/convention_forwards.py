import pandas as pd

def fwd_pips(ccy='EUR'):
    '''
    Function returning common pip-convensions for forward contracts.
    Source: https://en.wikipedia.org/wiki/Percentage_in_point#Table_of_pip_values
    NOTE: Only USD convensions are listed in the source. For EUR these has been assumed to be the same as for USD.

    RETURNS
        Dataframe with pip conventions
    '''
    if ccy == 'EUR':
        d = {
            'EURUSD': 0.0001,
            'GBPEUR': 0.0001,
            'EURJPY': 0.01,
            'EURCAD': 0.0001,
            'AUDEUR': 0.0001,
            'EURCHF': 0.0001,
            'NZDEUR': 0.0001,
            'EURDKK': 0.0001,
            'EURSEK': 0.0001,
            'EURNOK': 0.0001,
            'EURHKD': 0.0001,
            'EURBRL': 0.0001,
            'EURCNH': 0.0001,
            'EURCZK': 0.0001,
            'EURHUF': 0.01,
            'EURILS': 0.0001,
            'EURIDR': 1,
            'EURINR': 0.01,
            'EURKRW': 0.01,
            'EURMXN': 0.0001,
            'EURMYR': 0.0001,
            'EURNGN': 0.01,
            'EURPLN': 0.0001,
            'EURRON': 0.0001,
            'EURRUB': 0.0001,
            'EURSGD': 0.0001,
            'EURTRY': 0.0001,
            'EURZAR': 0.0001,
            'EURNZD': 0.0001, # https://www.google.com/search?q=pip+size+NZDEUR&rlz=1C1GCEB_enDK982DK982&sxsrf=ALiCzsayZwJFybEJgKZ-0K3K2FbiRD5Duw%3A1657106311815&ei=h2_FYtKjMc-Hxc8Pr7Cp2Ac&ved=0ahUKEwiSg8iIkuT4AhXPQ_EDHS9YCnsQ4dUDCA4&uact=5&oq=pip+size+NZDEUR&gs_lcp=Cgdnd3Mtd2l6EAMyBwghEAoQoAEyBwghEAoQoAEyBwghEAoQoAE6BwgAEEcQsAM6BwgAELADEEM6BQgAEMsBOgYIABAeEBY6CAgAEB4QFhAKOgUIIRCgAUoECEEYAEoECEYYAFCMCljDFmDqGGgBcAF4AIABpAGIAfwFkgEDNC4zmAEAoAEByAEJwAEB&sclient=gws-wiz
            'EURAUD': 0.0001, # https://www.google.com/search?q=pip+size+EURAUD&rlz=1C1GCEB_enDK982DK982&sxsrf=ALiCzsajwfFjXsrWZdg_popMWUZOjjFwkQ%3A1657106330345&ei=mm_FYrDLFI2Mxc8P7bOy6AY&ved=0ahUKEwiwgLORkuT4AhUNRvEDHe2ZDG0Q4dUDCA4&uact=5&oq=pip+size+EURAUD&gs_lcp=Cgdnd3Mtd2l6EAMyCAgAEB4QCBANOgcIABBHELADOgUIABDLAToGCAAQHhAWOggIABAeEBYQCjoHCCEQChCgAToICCEQHhAWEB06BAghEBVKBAhBGABKBAhGGABQ-AJYtgtg_w1oAXABeACAAYwBiAGpBJIBAzUuMZgBAKABAcgBCMABAQ&sclient=gws-wiz
            'EURISK': 0.01  # Guessed
        }

    elif ccy == 'USD':
        d = {
            'USDEUR': 0.0001,
            'GBPUSD': 0.0001,
            'USDJPY': 0.01,
            'USDCAD': 0.0001,
            'AUDUSD': 0.0001,
            'USDCHF': 0.0001,
            'NZDUSD': 0.0001,
            'USDDKK': 0.0001,
            'USDSEK': 0.0001,
            'USDNOK': 0.0001,
            'USDHKD': 0.0001,
            'USDBRL': 0.0001,
            'USDCNH': 0.0001,
            'USDCZK': 0.0001,
            'USDHUF': 0.01,
            'USDILS': 0.0001,
            'USDIDR': 1,
            'USDINR': 0.01,
            'USDKRW': 0.01,
            'USDMXN': 0.0001,
            'USDMYR': 0.0001,
            'USDNGN': 0.01,
            'USDPLN': 0.0001,
            'USDRON': 0.0001,
            'USDRUB': 0.0001,
            'USDSGD': 0.0001,
            'USDTRY': 0.0001,
            'USDZAR': 0.0001
        }

    else:
        d = dict()

    df = pd.DataFrame.from_dict(d, orient='index', columns=['PIP_SIZE'])
    df['BASE_CCY'] = df.index.str[:3]
    df['CCY_ID'] = df.index.str[3:]
    return df


    