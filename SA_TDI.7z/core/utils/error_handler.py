"""
Module for handling errors throughout code. The intended use of the module is to be able to handle errors without
breaking the code by raising exceptions, but rather have the code continue and logging the error to a file. This could
for example be relevant if going through a loop where an error is encountered for one item in the loop - rather than
raising the exception, the code can simply just log the error and continue with the next item in the loop.

Works as follows: when an error is experienced in the code, it can be logged using the "track_error" function. The
track_error calls the ErrorHandler class, which utilizes the singleton pattern to generate a DataFrame to which errors
are appended.
At code termination the log_errors() function is called automatically (using the atexit module), storing the DataFrame
in a logging file where the path depends on the environment in which the code is run (DEV, PROD, TEST). In case no
errors were experienced during code execution, the log_errors() function will just return immediately

Warning:
    When importing this module, the function log_errors() will automatically run at code termination. This generates
    a logging file in the respective logging path (environment dependable)

Notes:
    Author: g48606

"""
from core.utils import singleton, date_helper, dataframe_helper
from core.system import envir
import datetime as dt
import pandas as pd
import traceback
import atexit
import os
import sys
import time


class ErrorHandler(singleton.Singleton):
    """
    ErrorHandler class utilizing the singleton pattern. At first instantiation an empty DataFrame is generated, to
    which errors are appended as they appear throughout the code

    Notes:
        Author: g48606
    """
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.error_df = pd.DataFrame()

    def error_recorder(self, module_name, error_message='', identifier='', date='', comments=''):
        """
        Function that appends new errors to the error DataFrame with columns 'Module', 'System error', 'Identifier',
        'Date' and 'Comments', where everything except module_name is optional

        Notes:
            Author: g48606
        """
        if date != '':
            date = date_helper.to_date_str(date)
        new_error = pd.DataFrame([[module_name, str(error_message), str(identifier), date, comments]],
                                 columns=['Module', 'System error', 'Identifier', 'Date', 'Comments'])
        self.error_df = self.error_df.append(new_error)
        if self.verbose:
            print("Error raised: %(error_message)s_%(comments)s" % locals())

    def group_duplicate_errors(self):
        """
        This function uses the pandas "groupby" function, which works similarly to the SQL group by equivalent. It
        groups by ['Module', 'System error', 'Date', 'Comments'], outputting a single row where the identifier for each
        duplicate is concatenated

        An example could be::

            Input:
                    Module      System error        Identifier      Comments
            0       test        some_error          id1             None
            1       test        some_error          id2             None
            2       test        another_error       id3             None

            Output:
                    Module      System error        Identifier      Comments
            0       test        some_error          id1, id2        None
            1       test        another_error       id3             None

        Note:
            Author: g48606
        """
        df = self.error_df
        df2 = df.groupby(['Module', 'System error', 'Date', 'Comments']).agg({'Identifier': lambda x: ', '.join(x)})
        df2.reset_index(inplace=True)
        df2.insert(2, 'Identifier', df2.pop('Identifier'))
        self.error_df = df2

    def count_duplicates(self):
        """
        Checks whether there are any duplicate rows (logging of the exact same error more than once), and counts the
        amount of duplicate rows for each unique row -- if there is no duplicates, then count = 1.

        Notes:
            Author: g48606
        """
        df = self.error_df
        relevant_columns = list(df.columns)
        df['Count'] = 1
        df = df.groupby(relevant_columns).count().reset_index()
        self.error_df = df

    def keep_first_identifier_error(self):
        df = self.error_df
        count_identifiers = df.groupby('Identifier', as_index=False).aggregate(sum)
        count_identifiers = count_identifiers[['Identifier', 'Count']]

        first_identifiers = df.groupby('Identifier', as_index=False).first()
        first_identifiers.update(count_identifiers)
        first_identifiers.insert(2, 'Identifier', first_identifiers.pop('Identifier'))
        self.error_df = first_identifiers


def track_error(error_message='', identifier='', date='', comments='', module_name=None):
    """
    This function is the one actually called when logging an error. It generates an instance of the ErrorHandler class,
    and then appends the recorded error to the DataFrame. The 'traceback' package is used to extract the name of the
    function generating the error

     Example:
        The module is called (from python) like this::

            try:
                1/0
            except Exception as e:
                track_error(error_message=str(e), identifier='', date='', comments='Cannot divide by zero')

    Notes:
        Author: g48606
    """
    if module_name is None:
        module_name = traceback.extract_stack(None, 2)[0][2]  # Get the function name
    error_obj = ErrorHandler.get_instance()
    error_obj.error_recorder(module_name=module_name,
                             error_message=error_message,
                             identifier=identifier,
                             date=date,
                             comments=comments)


@atexit.register
def log_errors(path=None):
    """
    This function runs automatically at code termination. First, we check whether any errors are recorded - if not,
    the function returns immediately. If any errors are recorded during the code, the error DataFrame is stored as an
    .xlsx file in the envir.logging_path() and the storing path is printed to console.

    Notes:
        Author: g48606
    """
    error_obj = ErrorHandler.get_instance()

    if error_obj.error_df.empty:
        return

    # FIXME: there is bug on this function right now...
    # error_obj.group_duplicate_errors()
    error_obj.count_duplicates()
    # error_obj.keep_first_identifier_error()

    if path is None:
        path = envir.logging_path()
    if not os.path.exists(path):
        os.makedirs(path)

    module_name = os.path.basename(sys.argv[0]).split('.')[0]  # Get the module name
    name = r'\%s_%s_%s.xlsx' % (module_name, os.environ['username'], dt.datetime.now().strftime('%Y%m%d_%H%M%S'))

    writerObj = pd.ExcelWriter(os.path.normpath(path + name), engine='xlsxwriter')
    dataframe_helper.writeToExcel_autoAdj(writerObj, sheetname="error", df=error_obj.error_df)
    writerObj.close()

    print(str(len(error_obj.error_df)) + " errors are logged in: " + os.path.normpath(path + name))


def clean_errors(path=None, save=True):
    """
    In case we want to clean the error_df and save any tracked errors immediately rather than at code termination,
    this function can be called

    Notes:
        Author: g48606
    """

    if save:
        print("Outputting errors to logging folder and cleaning the error DataFrame")
        log_errors(path)
    else:
        print("Error log flushed without saving")
    error_obj = ErrorHandler.get_instance()
    error_obj.error_df = pd.DataFrame()


def return_and_clean_errors():
    """
    Function can be used in case the user wishes to report any tracked errors through other means, such as including
    them in an output excel sheet. Errors are flushed when calling this function, as they would otherwise be saved twice

    Notes:
        Author: g48606
    """
    error_obj = ErrorHandler.get_instance()
    if not error_obj.error_df.empty:
        error_obj.count_duplicates()
    out = error_obj.error_df
    print(str(len(out)) + " errors are logged and returned. ErrorHandler flushed")
    error_obj.error_df = pd.DataFrame()
    return out
