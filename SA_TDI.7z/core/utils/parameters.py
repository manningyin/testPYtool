# -*- coding: utf-8 -*-
import json
import yaml
import base64
import argparse
import logging

class Parameter:
    """Generic parameter description class"""
    def __init__(self, id, default=None, description="", label=None, cli_id=None, cli_shortcut=None,hide_in=None):
        self.id=id
        self.default = default
        self.description = description
        self.label = id if label is None else label
        self.cli_id = "--"+id.replace("_","-") if cli_id is None else cli_id
        assert(len(self.cli_id)>2)
        assert(self.cli_id[:2]=="--")
        if cli_shortcut is not None:
            assert(len(cli_shortcut)==2)
            assert(cli_shortcut[0]=="-")
        self.cli_shortcut = cli_shortcut
        if hide_in is None:
            hide_in=[]
        self.hide_in=hide_in

    @classmethod
    def encode(cls,value):
        "Encode value to a string representation."
        return value
    
    @classmethod
    def decode(cls,value):
        "Decode value represented as a string."
        return value

    def decode_form(self,value):
        "Decode value represented as a string."
        return self.decode(value)
            
    def to_json_entry(self, value):
        "Represent value as a key-value pair in json format"
        if "json" in self.hide_in:
            return ""
        else:
            return '  %-16s : %s'%('"'+self.id+'"',json.dumps(self.encode(value)))

    def to_yaml_entry(self, value):
        if "yaml" in self.hide_in:
            return ""
        else:
            value=str(self.encode(value))
            if len(set(":{}[]&*#?|-<>=!%@\).'\"").intersection(value)) or len(value)==0:
                value=repr(value)
            d=dict(value=value)
            d.update(vars(self))
            
            return "%(id)-20s : %(value)-20s # %(description)s\n"%d

    def to_html_form_element(self, value):
        if "form" in self.hide_in:
            return ""
        else:
            d=dict(value=self.encode(value),**vars(self))        
            return """
  <div class="form-group row">
    <label class="col-sm-2 col-form-label" for="%(id)s">%(label)s</label>
    <div class="col-sm-10">
      <input type="text" id="%(id)s" name="%(id)s" class="form-control" value="%(value)s">
      <small class="text-muted">%(description)s</small>
    </div>
  </div>        
    """%d
    
    def to_html_table(self, value):
        if "table" in self.hide_in:
            return ""
        else:
            d=dict(value=str(value))
            d.update(vars(self))        
            return "  <tr><th>%(label)-16s</th><td>%(value)s</td><td>%(description)s</td></tr>\n"%d
    
    def configure_argparser(self,parser):
        if "cli" in self.hide_in:
            return ""
        else:
            if self.cli_shortcut is None:
                parser.add_argument(self.cli_id, help=self.description)
            else:
                parser.add_argument(self.cli_shortcut, self.cli_id, help=self.description)
    
class FlagParameter(Parameter):
    """Boolean parameter"""
    def __init__(self, id, description="", label=None, cli_id=None, cli_shortcut=None, hide_in=None):
        Parameter.__init__(self,id=id, default=False, description=description, label=label, cli_id=cli_id, cli_shortcut=cli_shortcut,hide_in=hide_in)
    
    def configure_argparser(self,parser):
        if self.cli_shortcut is None:
            parser.add_argument(self.cli_id, action='store_true', help=self.description)
        else:
            parser.add_argument(self.cli_shortcut, self.cli_id, action='store_true', help=self.description)

    def decode(self,value):
        "Decode value represented as a string."
        if type(value) is bool:
            return value
        return value.lower() in ["y","yes","true","1",self.id.lower()]

    def to_yaml_entry(self, value):
        d=dict(value=json.dumps(value))
        d.update(vars(self))
        return "%(id)-20s : %(value)-20s # %(description)s\n"%d

    def to_html_form_element(self, value):        
        if "form" in self.hide_in:
            return ""
        else:
            d=dict(value=self.encode(value),checked="checked" if value else "",**vars(self))
            return """
  <div class="form-group form-check">
    <input type="checkbox" id="%(id)s" name="%(id)s" value="%(id)s" class="form-check-input" %(checked)s>
    <label class="col-sm-2 form-check-label" for="%(id)s">%(label)s</label>
    <small class="text-muted">
      %(description)s
    </small>
  </div>        
"""%d


class Password(Parameter):
    def __init__(self, id="password", default=None, description="", label=None, cli_id=None, cli_shortcut=None):
        Parameter.__init__(self, id=id, default=default, description=description, label=label, cli_id=cli_id, cli_shortcut=cli_shortcut)
    
    @classmethod
    def encode(cls, value):
        return base64.b32encode(str(value).encode("utf-8")).decode("utf-8")
    
    @classmethod
    def decode(cls, value):
        return base64.b32decode(str(value).encode("utf-8")).decode("utf-8")
    def decode_form(cls,value):
        "Decode value represented as a string."
        return value
            
    def to_html_table(self, value):
        if "table" in self.hide_in:
            return ""
        else:
            d=dict(value=len(str(value))*"&#xb7;")
            d.update(vars(self))
            return "  <tr><th>%(label)-16s</th><td>%(value)s</td><td>%(description)s</td></tr>\n"%d

    def to_html_form_element(self, value):
        if "form" in self.hide_in:
            return ""
        else:
            d=dict(value=value,**vars(self))        
            return """
  <div class="form-group row">
    <label class="col-sm-2 col-form-label" for="%(id)s">%(label)s</label>
    <div class="col-sm-10">
      <input type="password" id="%(id)s" name="%(id)s" class="form-control" value="%(value)s">
      <small class="text-muted">%(description)s</small>
    </div>
  </div>        
"""%d

    
class ParameterSet:
    def __init__(self, description, *parameters):
        self.parameters = parameters
        self.description = description
        self.reset_to_defaults()

    def check_ids(self):
        ids = []        
        for p in self.parameters:
            if p.id in ids:
                raise Exception("Parameter %s used more than once"%p.id)
            ids.append(p.id)
        
    def to_json(self, value=None):
        if value is None:
            value = self.data
        return "{\n"+",\n".join(p.to_json_entry(value.get(p.id,p.default)) for p in self.parameters)+"\n}"

    def to_yaml(self, value=None):        
        if value is None:
            value = self.data
        return "".join(p.to_yaml_entry(value.get(p.id,p.default)) for p in self.parameters)
    
    def to_html_table(self, value=None):
        if value is None:
            value = self.data
        return "<table class='table'>\n"+"".join(p.to_html_table(value.get(p.id,p.default)) for p in self.parameters)+"</table>\n"

    def to_html_form(self, value=None, action="#", method="post"):
        if value is None:
            value = self.data
        s='<form action="%s" method="%s">\n'%(action,method)
        s+="".join(p.to_html_form_element(value.get(p.id,p.default)) for p in self.parameters)
        s+='<button type="submit" class="btn btn-primary" id="submit" value=" Send">Submit</button>'
        s+="</form>\n"
        return s
    
    def configure_argparser(self,parser):
        for p in self.parameters:
            p.configure_argparser(parser)
        return parser

    def create_argparser(self):
        parser = argparse.ArgumentParser(description=self.description)
        return self.configure_argparser(parser)

    def reset_to_defaults(self):
        self.data={p.id:p.default for p in self.parameters}
        return self
        
    def load(self, path="config.yaml"):
        """Load config from yaml file
        """
        from os.path import exists
        if exists(path):
            with open(path) as f:
                try:
                    d=yaml.load(f,Loader=yaml.Loader)
                except:
                    logging.exception("Error reading config file: "+path)
                    raise
                if d is None:
                    logging.warning("Empty or damaged config file: "+path)
                else:
                    for p in self.parameters:
                        if p.id in d:
                            self.data[p.id] = p.decode(d[p.id])
            return True
        else:
            with open(path,"w") as f:
                f.write(self.to_yaml())
            return False
    
    def parse_command_line_arguments(self):
        parser = self.create_argparser()
        parser.parse_args()
        flag_keys = [p.id for p in self.parameters if isinstance(p,FlagParameter)]

        self.data.update({key:value for key,value in vars(parser.parse_args()).items() if value is not None and key not in flag_keys})
        self.data.update({key:value for key,value in vars(parser.parse_args()).items() if value and key in flag_keys})
        
        return self

    def fill_missing_data(self):
        for x in self.parameters:
            if x.id not in self.data:
                self.data[x.id] = x.default
        return self
        
    def init(self, path=None):
        self.check_ids()
        if path is None:
            self.parse_command_line_arguments().fill_missing_data()
            path = self.data.get("config","config.yaml")
        if not self.load(path):
            return False
        self.parse_command_line_arguments().fill_missing_data()
        return True
