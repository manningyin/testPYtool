
def month_code_to_month_count(month_code):
    '''
    Source: https://www.cmegroup.com/month-codes.html
    '''
    d = {'F': '01',
         'G': '02',
         'H': '03',
         'J': '04',
         'K': '05',
         'M': '06',
         'N': '07',
         'Q': '08',
         'U': '09',
         'V': '10',
         'X': '11',
         'Z': '12'}

    return d[month_code]
