"""
Basic util module which performs various string operations and returns a string

Module is indented for use when creating sql strings or similar, where a specific format is required.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       21dec2016   G50444      Initial creation
    ======= =========   =========   ========================================================================================

"""

import re
import inspect
from core.utils import version_independent


def commasep_quoted(x):
    """
    Returns a quoted and comma-separated string in the format: 'Element','AnotherElement','ThirdElement'

    The function is indented to be used for generating strings which can be used in sql "in" statements, e.g.

    Args:
        x   (str or list):              Level of information printed.

    Returns:
        (str):   Comma-separated string of elements in quotation marks

    Raises:
        ValueError: Input is not a string or list of strings

    Example:

        >>> from core.utils import string
        >>> # List as input
        >>> string.commasep_quoted(['USD','DKK','JPY'])
        "'USD', 'DKK', 'JPY'"

        >>> from core.utils import string
        >>> # String as input
        >>> string.commasep_quoted(' USD     DKK  JPY   ')
        "'USD','DKK','JPY'"

        >>> from core.utils import string
        >>> # List of int as input
        >>> string.commasep_quoted([1,2,3,4,5,6])
        "'1', '2', '3', '4', '5', '6'"

    Warning:
    Notes:
        Author: g50444
    """

    if type(x) is list:
        if type(x[0]) is int:
            list_of_str = [str(list_element) for list_element in x]
        else:
            list_of_str = x
        quoted_string = ', '.join("'{0}'".format(w) for w in list_of_str)
    elif type(x) is str:
        quoted_string = "'" + re.sub(' +', "','", x.lstrip().rstrip()) + "'"
    else:
        # Only the two datatypes are supported
        raise ValueError('Input is not a string or list of strings')
    return quoted_string


def ordered_dict_string(variables_for_dict=[], info=0):
    """
    Converting a list of function values into a dict-syntax string, in same variable order as input list.

    The function is indented to be used when user wants a static order of dictionary, that will not be used directly
    as a dictionary - e.g. when writing dictionaries to a text file.

    See the example section...

    Args:
        variables_for_dict      (list of strings):  List of variable names known in calling function namespace
        info                    (int):              Level of information printed.
                                                    The higher, the more information is printed

    Returns:
        (str):  String in "dict syntax" of variable names and variable values - in the same order as in the input list

    Raises:

    Example:
        Imagine that you on each call of a function, would like to add one row containing specific data to a file.
        The data-structure of this file, should be one dictionary per line.

        If we use the standard dict format, the order of the variables in the text file will be mixed on each row.
        Data will be fine - but it will be hard for humans to interpret the data without any further processing.

        Using this function, each row can be populated as a dict, but in the same variable order.

        The module is called (from python) like this::

            first_name      = 'Sherlock'
            last_name       = 'Holmes'
            street_name     = 'Baker Street'
            street_number   = '221B'
            city            = 'London'
            year_of_birth   = 1854

            personal_info_dict_str = ordered_dict_string(variables_for_dict = ['first_name','last_name','street_name','street_number','city','year_of_birth'])

    Warning:
        This function is accessing the locals() from the calling function to get the content of the variable names.
        This is in general discouraged, but accepted in this function to ease usability.
        One alternative is to increase the number of input arguments so it either contain the callers scope, ot the
        content of the variables.

    Notes:
        Author: g50444
    """

    # ===================================================================================
    # We need to access the content of the variables in the caller function.
    # Thereby we get the locals() definition from the calling function
    # ===================================================================================
    try:
        callers_local_scope = inspect.currentframe().f_back.f_locals
    except:
        print('Not able to get access to the calling functions local variables')
        raise

    concat_dict_list = []

    # ===================================================================================
    # Looping through all variables, adding dict element ('variable': value) as string
    # to a temporary list.
    # Special handling of string and non-string variable types.
    # ===================================================================================

    for name in variables_for_dict:
        # Finding the variable content in the caller function.
        try:
            eval_name = callers_local_scope[name]
        except KeyError:
            raise ('The variable content of variable: ', name, 'can NOT be found among callers local variables')
        if info >= 10:
            # Information used for debugging
            print('name:', name)
            print('eval(name):', eval_name)
        if type(eval_name) == str:
            # Strings will be quoted
            dict_element = "'" + name + "': '" + eval_name + "'"
        else:
            # Non-strings will not be quoted
            dict_element = "'" + name + "': " + str(eval_name)

        if info > 5:
            # Information used for debugging
            print('dict_element:', dict_element)

        concat_dict_list.append(dict_element)

    # Finishing the dictionary syntax
    total_dict_str = '{' + ', '.join(concat_dict_list) + '}'

    return total_dict_str


def dict_to_ordered_string(input):
    """
    Translates a dictionary into a string representation alphabetically sorted.

    Args:
        d    (dict or list): Dictionary that you want represented as a string. Also supports list if dicts.

    Returns:
        (str or list): Sting matching dictionary structure. If input is list of dicts, output is list of str.

    Example:
        Testable example of single dict:

            >>> from core.utils import string
            >>> d = {'z': 45, 'k': 'hey', 'a': 'A', 'b': 'B'}
            >>> my_str = string.dict_to_ordered_string(d)
            >>> my_str
            "{'a': 'A', 'b': 'B', 'k': 'hey', 'z': '45'}"
            >>> # Converting string back to dictionary
            >>> import ast
            >>> my_dict_again = ast.literal_eval(my_str)
            >>> my_dict_again['k']
            'hey'

        Testable example of single list of dicts:
            >>> from core.utils import string
            >>> d = {'z': 45, 'k': 'hey', 'a': 'A', 'b': 'B'}
            >>> l = [d, d]
            >>> my_list_of_str = string.dict_to_ordered_string(l)
            >>> my_list_of_str
            ["{'a': 'A', 'b': 'B', 'k': 'hey', 'z': '45'}", "{'a': 'A', 'b': 'B', 'k': 'hey', 'z': '45'}"]

    Notes:
        Author: JBrandt (g50444)
    """

    if isinstance(input, list):
        # If input is a list, we run this function (self) for each element - and outputting list of strings
        dict_str = []
        for d in input:
            row_str = dict_to_ordered_string(d)
            dict_str.append(row_str)
    else:
        # Starting dictionary with curly bracket
        dict_str = '{'
        # Looping through each element in the dictionary in alphabetically order.
        for key, value in sorted(input.items()):
            if not dict_str == '{':
                # Adding comma separator for all but the first element.
                dict_str += ', '
            if isinstance(value, dict):
                # If the value is itself a (sub) dictionary, we run this same function (self) for that dictionary.
                dict_str += "'" + str(key) + "': " + dict_to_ordered_string(value)
            else:
                # Simple dictionary element - as string
                dict_str += "'" + str(key) + "': '" + str(value) + "'"

        # Adding closing curly bracket to end the dictionary
        dict_str += '}'

    return dict_str


def add_infop_ro(sql_str):
    """
        Returns the original string (meant to contain a query) with all tables marsp.TABLE_NAME enriched with @infop_ro
        marsp.TABLE_NAME --> marsp.TABLE_NAME@infop_ro

        The function is meant to be used when there is the need to access infop via VPN. The workaround consists of
        connecting to INFOT and then call the same table in the schema INFOP (read-only). This code helps to transform
        the query thought for INFOP into the version to be used in INFOT.

        Args:
            sql_str   (str):              Query for INFOP

        Returns:
            (str):   Query for INFOT

        Raises:
            ValueError: Input is not a string

        Author: G02188
    """
    if type(sql_str) is str:
        sql_str = sql_str.replace('\n', ' ')
        tmp = sql_str
        for count, m in enumerate(re.finditer('marsp.', sql_str)):
            marsp_loc = m.start() + 9 * count
            space_loc = tmp[marsp_loc + 6:].find(' ')
            tmp = tmp[:marsp_loc + 6 + space_loc] + '@infop_ro' + tmp[marsp_loc + 6 + space_loc:]
    else:
        raise ValueError('Input is not a string')
    return tmp


if __name__ == '__main__':
    a = commasep_quoted([1, 2, 3, 4])
    print("(" + a + ")")
    b = commasep_quoted(['1', '2', '3', '4'])
    print(b)

