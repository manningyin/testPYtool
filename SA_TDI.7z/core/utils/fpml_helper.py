import xml.etree.ElementTree as ET
import uuid


def nested_dict_fpml_parser(fpml_string):
    """
    This function parses an FPML string into an object using the xml package. Then, using a recursive tree search
    approach, the xml object is transformed into a nested dictionary. For ease on eyes, it is recommended that the
    nested dictionary is printed using the pprint function (from pprint import pprint)

    Args:
        fpml_string     (str):  FPML payload string returned from TradeHub

    Returns:
        (dict): Nested dictionary with the same number of layers as the FPML

    Notes:
        Author: g48606
    """

    def nested_dict(root):
        # The attribute name contains a reference to FPML web page (that ends with '}') which is discarded here
        tag = root.tag.split('}')[-1]
        children = root.getchildren()
        # If root has no children, we reached the final node of the branch and thus we return the value (root.text)
        if len(children) == 0:
            return {tag: root.text}

        # Instantiate the nested dictionary with the attribute name of the current node
        out = {tag: dict()}
        for child in children:
            # Find all nodes on the next layer of the branch using recursion
            next_layer = nested_dict(child)

            # This part exists to ensure we don't override any dictionary keys. If there exists several several nodes
            # with the same name on the same branch, we concatenate them in a list
            for key in next_layer:
                # If the key doesn't already exist in output dict, we just add it
                if key not in out[tag]:
                    out[tag].update({key: next_layer[key]})
                else:
                    # Check if the value in output dict is already a list (it must be in order to use '.append()'). If
                    # it is a list, we do nothing. If it isn't a list, we convert it to a list (with 1 element)
                    value_list = out[tag][key] if isinstance(out[tag][key], list) else [out[tag][key]]

                    # Now append the new value to the list and add it to the output dictionary
                    value_list.append(next_layer[key])
                    out[tag].update({key: value_list})
        return out

    root = ET.fromstring(fpml_string)
    return nested_dict(root)


def flat_dict_fpml_parser(fpml_string, separator=': '):
    """
    This function parses an FPML string into an object using the xml package. Then, using recursion, the xml object is
    transformed into a flattened dictionary, where the keys are appended onto one another. The default separator is ': '
    but this can be changed as the user desires.

    Args:
        fpml_string     (str):  FPML payload string returned from TradeHub
        separator       (str):  The separator string used when concatenating dictionary keys

    Returns:
        (dict): Flattened dictionary where keys are concatenated using the separator

    Notes:
        Author: g48606
    """

    def flattened_dict(root, parent_key='', sep=separator):
        tag = root.tag.split('}')[-1]
        pk = parent_key + sep + tag if parent_key else tag
        if not root._children:
            return {pk: root.text}
        out = dict()
        for child in root._children:
            next_layer = flattened_dict(child, parent_key=pk)
            for key in next_layer:
                if key not in out:
                    out.update({key: next_layer[key]})
                else:
                    val = out[key] if isinstance(out[key], list) else [out[key]]
                    val.append(next_layer[key])
                    out.update({key: val})
        return out

    root = ET.fromstring(fpml_string)
    return flattened_dict(root)


def naive_fpml_parser(fpml_string):
    """
    Very simple fpml parser, used to parse the returned payload string.

    First we use the xml.etree.ElementTree package to parse the returned string into an object. This object will have
    several layers with attributes. The idea is we start at the highest layer (corresponding to '*'), and find all
    attributes. If the attribute has any text, we add the attribute name together with text to the output dictionary.
    We then move on to the next layer (corresponding to '*/*') and repeat. This process is repeated until we encounter
    a layer with no attributes - in that case we know the payload object is exhausted, and we can break the while loop.

    NB: In case attributes across layers share the same name, a random suffix is added to the attribute names to
    distinguish them. This is a weak design and can be improved by parsing the fpml as a tree structure rather than a
    flat structure. This does however require a bit more work to be done.

    Args:
        fpml_string     (string): fpml string returned from TradeHub

    Returns:
        (dict):  Dictionary with keys matching elements in the fpml object

    Notes:
        Author: g48606
    """
    root = ET.fromstring(fpml_string)
    find_str = '*'
    out = dict()
    while True:
        finds = root.findall(find_str)
        # If no attributes are found the object is exhausted and we can break the while loop
        if not finds:
            break
        for attr in finds:
            # Find the text associated with the attribute. If the text is empty, we skip the attribute
            text = attr.text
            text = text.strip() if text is not None else text
            if text:
                # Attribute name string will contain some rubbish html page affix that we discard here
                attr_name = attr.tag.split('}')[-1]

                # If attribute already exists in output dict, add a random string suffix to the attribute name
                if attr_name in out:
                    attr_name += ' + ' + str(uuid.uuid4())
                out[attr_name] = text
        # Continue with the next layer
        find_str += '/*'
    return out