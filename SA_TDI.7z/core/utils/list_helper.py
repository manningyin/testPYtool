"""
Various utilities for handling lists

Notes:
    Author: JBrandt (g50444)

"""


def distinct(in_list):
    """
    Removing duplicates from a list

    Function attempts to use the simple method (transforming to "set" and then beck to list).
    For complex object structures this will not always work.
    Therefore a backup iterative solution has been been implemented.

    Notes:
        Author: JBrandt (g50444)
    """

    try:
        distinct_list = in_list(set(in_list))
    except:
        distinct_list = distinct_objects(in_list)['distinct']
    return distinct_list


def distinct_objects(in_list):
    """
    Removing duplicates from a list, returning both unique list and duplicates

    Function attempts to use the simple method (transforming to "set" and then beck to list).
    For complex object structures this will not always work.
    Therefore a backup iterative solution has been been implemented.

    Returns:
        (dict):
            - key: 'distinct' has list of unique elements in list
            - key: 'duplicates' has dict of duplicates and frequency count

    Notes:
        Author: JBrandt (g50444)
    """

    distinct_list = []
    duplicate_list = []
    chosen_repr = []
    for element in in_list:
        element_repr = element.__repr__()
        if element_repr in chosen_repr:
            duplicate_list.append(element_repr)
        else:
            distinct_list.append(element)
            chosen_repr.append(element_repr)

    duplicate_frequency = {i: duplicate_list.count(i) for i in duplicate_list}
    out = dict(distinct = distinct_list, duplicates = duplicate_frequency)

    return out

def to_list(x):
    """
    Makes sure that output is a list. Wraps input element in list if not.

    Should be used on single elements and similar.

    Args:
        x       (str, int or other object):     Single element that you want to ensure can be used as string.

    Returns:
        (list):   Input wrapped as a list (if input was not already a list)

    Example:
        The module is called (from python) like this:

            >>> from core.utils import list_helper
            >>> y = None
            >>> list_helper.to_list(y)
            [None]

            >>> z = 'Some String'
            >>> list_helper.to_list(z)
            ['Some String']

            >>> x = [1,2,3,4]
            >>> list_helper.to_list(x)
            [1, 2, 3, 4]

    Notes:
        Author: g50444 (Jonas Brandt)
    """
    if isinstance(x, set):
        return list(x)
    elif x is None or type(x) != list:
        return [x]
    else:
        return x


def remove_element(base_list, pop_element):
    """
    Removing element matching exact specific criteria from a list.

    Args:
        base_list   (list): List of unique elements, from where an element must be removed.
        pop_element (str):  Element for which matching row(s) should be removed from the list.

    Returns:
        (list): List of UNIQUE elements, without the "popped" element

    Example:
        Test-able example with integers:

        >>> from core.utils import list_helper
        >>> in_list = [1, 2, 3, 4, 5]
        >>> list_helper.remove_element(base_list = in_list, pop_element = 4)
        [1, 2, 3, 5]

        Test-able example with strings:

        >>> from core.utils import list_helper
        >>> in_list = ['1', '1', '2', '3', '4', '5', '1', '1', '2', '3', '4', '5', '1', '1', '2', '3', '4', '5']
        >>> list_helper.remove_element(base_list = in_list, pop_element = '4')
        ['1', '3', '2', '5']

    Notes:
        Author: JBrandt (g50444)
    """

    remaining_list_elements = list(set(base_list) - set([pop_element]))

    return remaining_list_elements