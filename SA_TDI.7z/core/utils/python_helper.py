"""
The module contain a few python helper functions


Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       ddmonyyyy   G12345      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""


def update_first_sys_path_to_code_lib():
    """
    This function will direct the first item of the sys.path to code-lib folder

    According to the python documentation , as initialized upon program startup,
    the first item of this list, path[0], is the directory containing the script that was used to invoke the Python interpreter.

    The python documentation can be found here
    python -2 https://docs.python.org/2/library/sys.html#module-sys
    python -3 https://docs.python.org/3/library/sys.html#module-sys

    This behaviour will create some un-intended frature, for example, if there is a file inside the directory where your script located,
    and the file has the same name as a module you want to import(for example, orca). Then python will think you want to import this file
    rather than the modules.

    This function will override the path[0] to the code-lib folder, since we will never put .py file on that folder, that will be safer.


    Args:

    Returns:

    Warning:
        <This section is optional. Please remove this comment line when you use the template>
        Please be aware that this function DOES SOME IRREVERSIBLE STUFF or something else that user needs to be aware of...

    Notes:
        Author: g48454
    """
    import sys
    import os
    sys.path[0] = os.getcwd()[:os.getcwd().rfind("code-lib") + 8]