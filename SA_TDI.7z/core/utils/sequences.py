"""Manipulating sequences.

Notes:
    Author: g46474 (Joerg Wegener)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01dec2017   G46474      Initial creation
    ======= =========   =========   ========================================================================================
"""

def emap(function, item):
    """
    Element-by-element map() when *item* is a scalar or sequence (i.e. unknown at 'interpreting' time).

    Unlike *map()*, *emap()* works for:

        - *item*: sequence or
        - *item*: single element, i.e. not a sequence

    TODO:
        - Expand to nested sequences.
        - Python 3: improve efficiency by returning iterator instead of list, i.e. avoid list(map(...)).

    Args:
        function        (function):     fct in *map(fct, x)*.
        item            (flexible):     Sequence or single element

    Returns:
        (list or single element):   same type as input

    Examples:

        >>> from core.utils import sequences
        >>> sequences.emap(str, 5)
        '5'
        >>> sequences.emap(str, [4, 5, 6])
        ['4', '5', '6']

    Notes:
        Author: g46474 (Joerg Wegener)
    """

    # TODO: step deeper into all dimensions (= nested sequences), i.e. unitl hasattr(item[0], ....) is False.
    # Something like: dummy = item[0]  # first dimension
    #                if  hasattr(dummy[0], ....)  # second dimension
    if hasattr(item, '__len__'):
        result = list(map(function, item))
    else:
        result = function(item)
    return result
