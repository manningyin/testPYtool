"""
The module contain a decorator that make sure the class is in singleton pattern

For what is singleton pattern, see below wiki page
https://en.wikipedia.org/wiki/Singleton_pattern

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       09jul2017   G48454      Initial creation
    ======= =========   =========   ========================================================================================
"""


class Singleton:
    """
    A mixin class for singleton pattern

    Example:
        The module is called (from python) like this::

            class temp_class(Singleton):
                def __init__(self):
                    self.x = 1
            obj1 = temp_class.get_instance()
            obj2 = temp_class.get_instance()
            obj2.x = 3
            print(obj1.x)
            print(obj2.x)

    Notes:
        Author: g48454
    """
    _singleton = None

    @classmethod
    def get_instance(cls, *args, **kwargs):
        if cls._singleton is None:
            cls._singleton = cls(*args, **kwargs)
        return cls._singleton


if __name__ == "__main__":
    class TempClass(Singleton):
        def __init__(self):
            self.x = 1

    obj1 = TempClass.get_instance()
    print(obj1.x)
    print(id(obj1))

    obj3=TempClass()
    print(id(obj3))

    obj2 = TempClass.get_instance()
    print(id(obj2))
    obj2.x = 3
    print(obj1.x)
    print(obj2.x)
    print(obj3.x)
