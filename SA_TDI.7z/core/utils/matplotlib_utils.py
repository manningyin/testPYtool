import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as dates


def plot_daily_timeseries(data, *plot_args, **kwargs):

    """
       Plot vector indexed by dates -- refined control of date-ticks' format and location.


           - Finest grid of x-ticks is 1 tick per day (default) -- data grid may be less than 1 datapoint per day.
           - Assumes dates on x- and values on y-axis.



    :param data: (:class:`pandas.DataFrame` or :class:`pandas.Series`)
                 Date(time)-indexed data to plot.
    :param plot_args: (:class:`str`)
                      Arguments passed to :func:`matplotlib.pyplot.plot()`.
    :param kwargs: (:class:`str`) Mix of keyword-arguments to control date-ticks, or passed to :func:`matplotlib.pyplot.plot()`.


    \t *Control tick format & location:*
        :param fmt: (:class:`str`, as in :func:`datetime.strftime`) Format of date tick-labels. Default: '%Y-%m-%d'. See :mod:`~utils.datetime_helper` for examples.
        :param bymonthday: (:class:`int` or list of  :class:`int`) Day of month. Default: `range(1,32)`, i.e. daily ticks.
        :param interval: (:class:`int`) Example: `interval=2` every other date-tick printed.


    :return: (:class:`matplotlib.axes.Axes`) Axes handle for use in :func:`matplotlib.pyplot.axes()`.


    Author:
                G46474 (Joerg Wegener)


    Examples:
    -------

    >>> import pandas as pd; import numpy as np; import matplotlib.pyplot as plt
    >>> from core.utils.matplotlib_utils import plot_daily_timeseries

        # create dummy data
    >>> df = pd.DataFrame(np.random.uniform(size=100).reshape(50, 2), columns=['Col_1', 'Col_2'], index=pd.date_range(start='20180101', periods=50))

        # 1. Example (basic usage -- pandas.DataFrame): plot each column against index. All defaults apply: daily ticks, Y-m-d format.
    >>> ax = plot_daily_timeseries(df); plt.show(); # ax.legend(['Column 1', 'Column 2'])

        # 2. Example (advanced usage -- pandas.Series): plot first column, only + more refined tick-control.
    >>> plot_daily_timeseries(df.Col_1, 'c', fmt='%d%b%Y', bymonthday=[1, 15, 25], marker='$Bla$', markersize=30); plt.show()

    """


    # Set defaults and single out parameters that are passed to different methods than 'plt.plot(...)'.
    fmt = kwargs.pop('fmt', '%Y-%m-%d')
    bymonthday = kwargs.pop('bymonthday', None)
    interval = kwargs.pop('interval', 1)


    return _plot_daily_timeseries(data, fmt, bymonthday, interval, *plot_args, **kwargs )


def _plot_daily_timeseries(data, fmt, bymonthday, interval, *plot_args, **plot_kwargs):

    """
     Same as :func:`plot_daily_timeseries`, but with explicit parameters and default values.
    """

    ax = plt.gca()

    ax.xaxis.set_major_formatter(dates.DateFormatter(fmt)) # 'strftime_format' in core/utils/datetime_helper.py
    ax.xaxis.set_major_locator(dates.DayLocator(bymonthday=bymonthday, interval=interval))

    plt.plot(data.index, data.values, *plot_args, **plot_kwargs)
    plt.gcf().autofmt_xdate()

    return ax

