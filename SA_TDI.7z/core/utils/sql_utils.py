"""
  Embedding Python into SQL queries.

  Author: G46474 (Joerg Wegener)
"""
from numbers import Number

def in_operator_format(items) -> str:
    """
      Formats `items` to be used in sql " ... IN (`item_1`, `item_2`, ...)"-statement.

    :param items: (:class:`str` or :class:`Number` or :class:`container(str|Number)`)
    :return: (:class:`str`) "(item_1, item_2, item_3)"-format (format of "item_x" differs by " ' " for numbers vs strings) to use in: SELECT * FROM my_table WHERE items IN ('item_1', 'item_2', 'item_3')

    >>> from core.utils.sql_utils import in_operator_format
    >>> in_operator_format([1,2,3])
    '(1, 2, 3)'
    >>> in_operator_format([1])
    '(1)'
    >>> in_operator_format(1)
    '(1)'
    >>> in_operator_format(('a','b','c'))
    "('a', 'b', 'c')"
    >>> in_operator_format(('a'))
    "('a')"
    >>> in_operator_format('a')
    "('a')"
    >>> in_operator_format([])
    '()'

    """
    if isinstance(items, str):  # non-container string
        result = "('{items}')".format(items=items)
    elif isinstance(items, Number):  # non-container number
        result = '({items})'.format(items=items)
    else:
        r = str(tuple(items))  # containers of > 1 elements
        result = r.replace(",)", ')') if r[-2]==',' else r # containers of <= 1 element
    return result