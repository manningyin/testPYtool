"""
The module contain a few functions that used to calculate shocks in FRTB IMA model


The logic can be found below
https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks

Notes:
    Author: G48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       31AUG2017   G48454      Initial creation
    ======= =========   =========   ========================================================================================
"""
import six
from core.utils.python_helper import update_first_sys_path_to_code_lib
update_first_sys_path_to_code_lib()
import datetime as dt
from core.utils import date_helper
from distutils.version import StrictVersion
import pandas as pd
import quantum as qt
from core.caching.cache_driver import easy_cache, memory_cache, MemoizeMutable
from core.system import guestbook


def attach_shock_days_to_data(df,ccy,shock_horizon):
    """
    This function try to attach the shock days (shock start date, shock end date) to the dataframe generated

    Args:
        df                  (panda dataframe):  A panda dataframe that contain scenario dates, at lesast contain the following attributes : market_data_id (str) , eod_date (datetime.date), value (numerical)
        ccy                 (currnecy):         The currency of calendar for the specific market data id
        shock_horizon       (int):              shock_horizon

    Returns:
        (dataframe):   Scenario start date and scenario end date and corresponding start value/end value and ready to feed to DAMDS

    Warning:
        1) The functions support multiple market data ids, but just make sure all these market data ids have same local ccy.
        2) The dataframe can have more description fields, this function will just attach these description fields to the end of the result dataframe.
        3) The function will use orca/qtoolkit, so make sure you have installed them...

    Notes:
        Author: g48454 (Shengyao)
    """

    guestbook.checkin()
    import orca

    # ===================================================================================
    # check orca versions
    # ===================================================================================
    if not StrictVersion(orca.__version__) >= StrictVersion('0.15.0'):
        raise Exception('Your orca version has to be at least 0.15.0')

    # ===================================================================================
    # check the data format and make necessary adjustments
    # ===================================================================================
    df = change_column_names_to_lower_case(df)
    df = change_eod_date_to_date(df)
    # ===================================================================================
    # get all eod_dates from the data dataframe and then calculate the start dates, end dates for these date list
    # ===================================================================================
    unique_date_list = list(set(df["eod_date"].tolist()))

    scenario_dates_df = fetch_scenario_date_and_shock_dates_to_df(  end_date        = max(unique_date_list),
                                                                    start_date      = min(unique_date_list),
                                                                    ccy             = ccy,
                                                                    shock_horizon   = shock_horizon
                                                                    )
    market_data_ids = set(df['market_data_id'].tolist())

    # ===================================================================================
    # extend the DataFrame to include market data id
    # ===================================================================================
    scenario_dates_df_with_market_data_id = attach_market_data_id_to_scenario_date_df(scenario_dates_df,market_data_ids)

    # ===================================================================================
    # use merge the get the start value for certain market data id and scenario date
    # ===================================================================================
    df["eod_date"] = [date_helper.to_datetime(x).date() for x in df["eod_date"].tolist()]
    new_df = scenario_dates_df_with_market_data_id.merge(df, left_on=["market_data_id", "start_date"], right_on=["market_data_id", "eod_date"])
    cols_to_use = ["market_data_id" , "eod_date", "value"]
    # ===================================================================================
    # use merge the get the end value for certain market data id and scenario date
    # ===================================================================================
    new_df = new_df.merge(df[cols_to_use], left_on=["market_data_id", "end_date"], right_on=["market_data_id", "eod_date"])
    new_df = new_df.rename(columns = {'value_x':'start_value' , 'value_y': 'end_value'})

    # ===================================================================================
    # fetch other infos like shock_horizon and scalling method
    # ===================================================================================
    new_df["shock_horizon"] = shock_horizon
    new_df["HORIZON_SCALING_METHOD"] = "None"
    new_df.drop(['eod_date_x', 'eod_date_y'],axis = 1 , inplace = True)

    # ===================================================================================
    # attach any additional description fields.
    # ===================================================================================
    cols = ["market_data_id" , "scenario_date", "start_date",	"end_date" ,"start_value" , "end_value" , "shock_horizon", "HORIZON_SCALING_METHOD"]
    additional_names = list(set(list(new_df)) - set(cols)) # get additional names
    return new_df[cols + additional_names]


def change_column_names_to_lower_case(df):
    df.columns = [x.lower() for x in df.columns]
    return df


def change_eod_date_to_date(df):
    new_df = df.copy()
    temp_list = df['eod_date'].tolist()
    new_df['eod_date'] = [date_helper.to_datetime(x).date() for x in temp_list]
    return new_df


def attach_market_data_id_to_scenario_date_df(scenario_dates_df,market_data_ids):
    out = pd.DataFrame()
    for market_data_id in market_data_ids:
        temp_df = scenario_dates_df
        temp_df["market_data_id"] = market_data_id
        out = out.append(temp_df)
    return out


@memory_cache
def shock_days(eod_date, ccy, shock_horizon):
    """
    The function will calculate the shock begin and end dates based on a local ccy calendar

    Args:
        eod_date              (datetime):           calculation dates
        ccy                   (str):                local ccy
        shock_horizon         (int):      shock horizon (1 means 1day)

    Returns:
        (tuple):   scenario start date, scenario end_date

    Raises:
        <Example - Please remove this comment line when you use the template>
        <IOError: An error occurred accessing the bigtable.Table object.>

    Example:
        The module is called (from python) like this::

            from core.utils import shock_days
            eod_date = dt.date(year=2017, month=4, day=13)
            print(shock_days.shock_days(eod_date, 'EUR', 10))

    Notes:
        Author: g48454 (Shengyao Zhu)
    """

    global_holidays = get_global_holidays()
    currency = qt.Currency(ccy)
    local_holiday = ORCA_holidays([currency])[currency]
    shock_end_date = qt.adjustDate(eod_date, qt.BusinessDayConvention.PRECEDING, local_holiday)
    # Here we first ensure 10 days has passed in the TARGET calendar, and afterwards ensure that the date is not a
    # holiday for the local currency
    shock_start_date = qt.addBusinessDays(shock_end_date, qt.BusinessDays.make(-shock_horizon, global_holidays))
    shock_start_date = qt.adjustDate(shock_start_date, qt.BusinessDayConvention.PRECEDING, local_holiday)
    return shock_start_date, shock_end_date


# TODO: Consider renaming to shock_days.rtpl()
def workout_rtpl_scenario_dates(eod_date):
    """
    Determine scenario dates needed for RTPL calculation for a specific reporting/eod date.

    Args:
        eod_date    (date):     Last "shock to" date, typically the date for which you are doing the reporting.

    Returns:
        (list of date): All dates for which we need scenarios in order to do a RTPL calculation.

    Example:
        The module is called (from python) like this::

            >>> from core.utils import shock_days
            >>> import datetime

            >>> shock_days.workout_rtpl_scenario_dates(datetime.date(2018,4,5))
            [datetime.date(2018, 4, 6)]

    Notes:
        Author: Shengyao (documented by JBrandt)
    """
    global_holidays = get_global_holidays()
    return [qt.addBusinessDays(eod_date, qt.BusinessDays.make(1, global_holidays))]


# TODO: Consider renaming to shock_days.one_year()
def workout_1y_scenario_dates(eod_date):
    """
    Workout all end dates that need generate scenario for one year time horizon

    The definition of one year is given by the below page
    https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks

    A year is a period a fixed number of shocks - which covers at least a year, matching the TARGET calendar.

    Args:
        eod_date          (datetime.date):    the eod date used to generate scenario
    Returns:
        scenario_dates      (a list of dataframe):   a list of scenario dates

    Raises:
        If eod_date itself is a holiday, the code will return nothing and raise an error

    Example:
        The module is called (from python) like this::

            print(workout_1y_scenario_dates(dt.date(year=2017, month=4, day=2)))

    Notes:
        Author: g48454
    """
    global_holiday = get_global_holidays()
    scenario_date_list = []
    eod_date = date_helper.to_datetime(eod_date).date()

    # ===================================================================================
    # check whether the eod_date is holiday defined in global calendar, if not, raise error
    # ===================================================================================
    end_date = qt.adjustDate(eod_date, qt.BusinessDayConvention.PRECEEDING, global_holiday)
    if eod_date != end_date:
        raise Exception("eod_date is a holiday in global calendar, no scenario should be generated")
    else:
        no_of_scenarios = 0
        curr_date = eod_date
        while no_of_scenarios < 259:
            scenario_date_list.append(curr_date)
            curr_date = qt.addTenorAdjust(curr_date, '-1B', 'p', global_holiday)
            no_of_scenarios += 1
        return scenario_date_list

# TODO: make it more object oriented at some point
def workout_var_scenario_dates(eod_date):
    """
    Workout all end dates that need generate scenario for one year time horizon

    The definition of one year is given by the below page
    https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks

    A year is a period a fixed number of shocks - which covers at least a year, matching the TARGET calendar.

    Args:
        eod_date          (datetime.date):    the eod date used to generate scenario
    Returns:
        scenario_dates      (a list of dataframe):   a list of scenario dates

    Raises:
        If eod_date itself is a holiday, the code will return nothing and raise an error

    Example:
        The module is called (from python) like this::

            print(workout_1y_scenario_dates(dt.date(year=2017, month=4, day=2)))

    Notes:
        Author: g48454
    """
    global_holiday = get_global_holidays()
    scenario_date_list = []
    eod_date = date_helper.to_datetime(eod_date).date()

    # ===================================================================================
    # check whether the eod_date is holiday defined in global calendar, if not, raise error
    # ===================================================================================
    end_date = qt.adjustDate(eod_date, qt.BusinessDayConvention.PRECEEDING, global_holiday)
    if eod_date != end_date:
        raise Exception("eod_date is a holiday in global calendar, no scenario should be generated")
    else:
        no_of_scenarios = 0
        curr_date = eod_date
        while no_of_scenarios < 500:
            scenario_date_list.append(curr_date)
            curr_date = qt.addTenorAdjust(curr_date, '-1B', 'p', global_holiday)
            no_of_scenarios += 1
        return scenario_date_list


def return_scenario_and_shock_dates_for_local_ccy_in_1y_period(eod_date,ccy,shock_horizon):
    """
    The function will work out the scenario dates as well as the shock dates follow the logic given by below
    https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks


    Args:
        eod_date          (datetime.date):    the eod date used to generate scenario
        ccy               (str):         currency
        shock_horizon     (int):         shock horizon
    Returns:
         (dict):   a dict with scenario dates as key and corresponding shock dates (start and end) as value.

    Raises:
        If eod_date itself is a holiday, the code will return nothing and raise an error

    Example:
        The module is called (from python) like this::
            print(return_scenario_and_shock_dates_for_local_ccy_in_1y_period(eod_date,'DKK',1))

    Notes:
        Author: g48454
    """
    out = dict()
    scenario_dates = workout_1y_scenario_dates(eod_date)
    for date in scenario_dates:
        out[date] = shock_days(eod_date = date,
                               ccy = ccy,
                               shock_horizon=shock_horizon)
    return out

def workout_scenario_dates(end_date, start_date):
    """
    Workout all end dates that need generate scenario between a range specified by end_date and start_date

    The definition of one year is given by the below page
    https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks

    A year is a period a fixed number of shocks - which covers at least a year, matching the TARGET calendar.

    Args:
        end_date          (datetime.date):    the end date for the scenario dates you want
        start_date         (datetime.date):   the start date for the scenario dates you want
    Returns:
        scenario_dates      (a list of datatime):   a list of scenario dates

    Notes:
        Author: g48454
    """
    global_holiday = get_global_holidays()
    scenario_date_list = []
    currdate = qt.adjustDate(end_date, qt.BusinessDayConvention.PRECEDING, global_holiday)
    while currdate > start_date:
        scenario_date_list.append(currdate)
        currdate = qt.addBusinessDays(currdate, qt.BusinessDays.make(-1, global_holiday))
    return scenario_date_list


def return_scenario_and_shock_dates_for_local_ccy_in_given_period(end_date,start_date,ccy,shock_horizon):
    """
    The function will work out the scenario dates as well as the shock dates follow the logic given by below
    https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks

    Args:
        end_date          (datetime.date):    the end date for the scenario dates you want
        start_date         (datetime.date):   the start date for the scenario dates you want
        ccy               (str):         currency
        shock_horizon     (int):         shock horizon
    Returns:
         (dict):   a dict with scenario dates as key and corresponding shock dates (start and end) as value.

    Notes:
        Author: g48454
    """

    out = dict()
    scenario_dates = workout_scenario_dates(end_date,start_date)
    for date in scenario_dates:
        out[date] = shock_days(eod_date=date, ccy=ccy, shock_horizon=shock_horizon)
    return out


def fetch_scenario_date_and_shock_dates_to_df(end_date, start_date, ccy, shock_horizon):
    """
    This function will generate a dataframe that contain three columns, scenario date,  and shock date

    The function will work out the scenario dates as well as the shock dates follow the logic given by below
    https://confluence.itcm.oneadr.net/display/RPF/Calendar+definition+for+x-day+shocks


    Args:
        end_date        datetime.date):    the end date for the scenario dates you want
        start_date      (datetime.date):   the start date for the scenario dates you want
        ccy             (str):              the local currency ( it is not the global currency, here we assume the global currency is EUR)
        shock_horizon   (int):              shock horizon
    Returns:
        (dataframe):   a dataframe that contain three columns, scenario date and shock date

    Example:
        The module is called (from python) like this::

            from core.utils import shock_days
            shock_days.fetch_scenario_date_and_shock_dates_to_df(eod_date,'DKK',1)

    Notes:
        Author: g48454
    """
    df = pd.DataFrame()
    scenario_day_and_shock_days = return_scenario_and_shock_dates_for_local_ccy_in_given_period(end_date, start_date, ccy, shock_horizon)
    for scenario_date in scenario_day_and_shock_days.keys():
        shock_start_date, shock_end_date = scenario_day_and_shock_days[scenario_date]
        temp_df = pd.DataFrame([[scenario_date , shock_start_date , shock_end_date]], columns=['scenario_date','start_date','end_date'])
        df = df.append(temp_df)
    return df


@MemoizeMutable
@easy_cache()
def get_global_holidays():
    """
    get global holiday calendar for scenario calculation, use ECB target calendar
    """
    return ORCA_holidays([qt.Currency.EUR])[qt.Currency.EUR]


@MemoizeMutable
@easy_cache()
def ORCA_holidays(currencies):
    from core.connection import orca_connect

    date0 = orca_connect.yesterday()
    _service_requests = orca_connect.get_orca_request()
    _holiday_factory = _service_requests.get_holiday_factory_for_all_centers().result()
    liborconv = _service_requests.get_libor_convention(currencies=currencies,
                                                       timestamp=orca_connect.get_orca_timestamp(date0),
                                                       holiday_factory=_holiday_factory).result()
    if six.PY2:
        return dict((ccy, liborconv[ccy].fixedHolidays()) for ccy in currencies)
    else:
        return dict((ccy, liborconv[next(x for x in liborconv.keys() if x.value == ccy.value)].fixedHolidays) for ccy in currencies)


if __name__ == '__main__':
    # testing script
    get_global_holidays()
    eod_date = dt.date(year=2018, month=1, day=10)
    print(shock_days(eod_date, 'EUR', 10))
    # print(workout_1y_scenario_dates(eod_date))
