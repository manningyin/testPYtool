import atexit
import timeit
@atexit.register
def end_time():
    final_time = timeit.default_timer() - start_time
    if final_time > 60:
        print('Time elapsed: %s min, %.2f sec' % (int(final_time//60), final_time % 60))
    elif final_time > 2:
        print('Time elapsed: %.3f sec' % final_time)
    elif final_time > 0.002:
        print('Time elapsed: %.3f ms' % (final_time*1e3))
    elif final_time > 2e-6:
        print('Time elapsed: %.3f µs' % (final_time*1e6))
    else:
        print('Time elapsed: %.3f ns' % (final_time*1e9))


start_time = timeit.default_timer()
