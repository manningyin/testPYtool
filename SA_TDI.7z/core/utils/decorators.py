""" Collection of useful decorators. """

import pickle as pc
import time

def w_cache(path_filename=None):
    """ Write-only cache

    Author: G46474
    """

    if path_filename is None:
        path_filename = './default_out.pickle'

    def decorator(func):
        def wrapper(*args, **kwargs):
            with open(path_filename, 'wb') as pfile:
                value = func(*args, **kwargs)
                pc.dump(value, pfile)
            return value
        return wrapper
    return decorator


def rw_cache(path_filename=None, overwrite=False):
    """ Read-Write cache with option to enforce overwriting.

       Logic (Example: reading data from database):
         1) If overwrite==True -> call database and write file (overwrites file if exists)
         2) If file exists, read from it (do *not* call database).
         3) If file does not exist, call database and write file.

    Author: G46474
    """

    if path_filename is None:
        path_filename = './default_out.pickle'

    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                if overwrite:  # read & over-write
                    raise IOError("Overwrite == True in decorator argument.")
                with open(path_filename, 'rb') as infile:  # read-only
                    result = pc.load(infile, encoding='latin-1') # read into Python 3 files pickled in Python 2.
                    # result = pc.load(infile) # Python 2.
                    print("CAREFUL. Reading data from cache: {file}".format(file= path_filename))
            except IOError or overwrite:  # read & write
                with open(path_filename, 'wb') as outfile:
                    result = func(*args, **kwargs)
                    pc.dump(result, outfile)
            return result
        return wrapper
    return decorator


def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'timeit_log' in kw:
            name = kw.get('timeit_log_name', method.__name__.upper())
            kw['timeit_log'][name] = int((te - ts) * 1000)
        else:
            print("Function: {function}, running time: {run_time:2.2f} ms".format(function=method.__name__,
                                                                                  run_time=(te - ts) * 1000))
        return result
    return timed
