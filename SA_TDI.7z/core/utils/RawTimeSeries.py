from core.utils.market_data_cache import DataCache
import pandas as pd
import quantum as qt
import core.graphics.scatter as scatter

'''
Raw Time Series Object



Warning:
    <This section is optional. Please remove this comment line when you use the template>
    Please be aware that this modules DOES SOME IRREVERSIBLE STUFF or that is

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01Mar2017   G48454      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''


class RawTimeSeries(DataCache):
    def __int__(self,name):
        DataCache.__int__(self,name)

    def bump_data_cache_to_raw_time_series(self,data):
        self.cacheDate=data.cacheDate
        self.cacheValue=data.cacheValue

    def to_pd_DataFrame(self, buckets=[]):
        # transfer the curve object to series
        import quantum as qt
        import pandas as pd
        dateList = self.cacheDate
        dateList = sorted(dateList)
        df = pd.DataFrame()
        for d in dateList:
            obj = self.getvalue(d)
            try:
                if type(obj) in [qt.CurveCatrom,qt.CurveFlat]:
                    tempValueList = []
                    for bucket in buckets:
                        tempD = qt.addTenor(d, bucket)
                        tempValue = obj.getVal(tempD)
                        tempValueList.append(tempValue)
                    df = df.append(pd.DataFrame(data=[[d] + tempValueList], columns=['date'] + buckets))
                elif type(obj) is list:
                    tempValue = obj[0]['clean_price']
                else:
                    return
            except:
                continue
        return df


    def plot_dynamic(self, startd, endd, bucket=''):
        # transfer the curve object to series
        ts = self.to_pdSeries(bucket=bucket)
        ts2 = ts[startd:endd]
        return ts2.plot()

    def plot_all_buckets(self, folder, buckets):
        '''
        Plot all buckets in a specifc folder

        Warning:
            <This section is optional. Please remove this comment line when you use the template>
            Please be aware that this function DOES SOME IRREVERSIBLE STUFF or something else that user needs to be ware of...

        Notes:
            Author: g48454
        '''

        df = self.to_pd_DataFrame(buckets=buckets)
        scatter.plot(dataframe=df,
                     x_axis_var='date',
                     y_axis_vars=buckets,
                     dest_html_file=folder + '/' + 'time_series_' + self.name + '.html',
                     plot_title=self.name,
                     plot_types='lines',
                     auto_open=False,
                     info=0
                     )


    def plot_compare_dynamic(self, folder, rightobj, bucket):
        '''
        The function compare the dynamic with another object for the same bucket


        Args:
            folder                   (str):             The folder you want the plot be placed
                                                        The higher, the more information is printed
            rightobj                (market_data_obj):  The right obj you want to compare with
            bucket                  (str):              Bucket you want to compare

        Returns:
            return nothing, but a plot will be generated in the folder you specified


        Example:
            from core.market_data.market_data_obj import bond_curve
            # plot mortgage bond from one source
            obj=bond_curve(name='DKKMTGNYKSOFTBLT',source='marsp',startd=datetime.datetime(2016,1,4),endd=datetime.datetime(2016,9,1))
            obj2=bond_curve(name='DKKMTGNYKSOFTBLT',source='web_service',startd=datetime.datetime(2015,1,4),endd=datetime.datetime(2016,9,1))
            obj.plot_compare_dynamic(rightobj=obj2, bucket='3M',folder='H:/Temp/')

        Notes:
            Author: g48454
        '''

        import core.graphics.scatter as scatter
        df1 = self.to_pd_DataFrame(buckets=[bucket])
        df2 = rightobj.to_pd_DataFrame(buckets=[bucket])
        colname1 = self.name + '_' + bucket
        colname2 = rightobj.name + '_' + bucket
        # df1.rename(columns={bucket: colname1})
        # df2.rename(columns={bucket: colname2})
        final_df = pd.merge(df1, df2, on='date')

        scatter.plot(dataframe=final_df,
                     x_axis_var='date',
                     y_axis_vars=[bucket + '_x', bucket + '_y'],
                     y_axis_labels=None,
                     dest_html_file=folder + '/' + 'compare_' + colname1 + '_' + colname2 + '.html',
                     plot_title='compare_' + colname1 + '(x)_with_' + colname2 + '(y)',
                     plot_types='lines',
                     auto_open=False,
                     info=0
                     )
