"""
This module contain some functions used for time outs...


Notes:
    Author: G48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01feb2017   G48454      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================

"""

import sys
import traceback
import unittest



import functools
def timeout(max_timeout = None):
    """
    Return the decorator of timeout function

    Args:
        max_timeout (int):   the maximum running time (expressed in seconds)

    Returns:
        a decorator...

    Raises:

    Example:
        Example 1::
        
            save_something_to_network_drive_with_timeout = timeout(10)(save_something_to_network_drive)
            save_something_to_network_drive_with_timeout(data='Some Text',location='c:/file.txt')

        Example 2::
        
            timeout(10)(save_something_to_network_drive)(data='Some Text',location='c:/file.txt')

    Notes:
        Author: g48454
        
    """

    if max_timeout is None:
        max_timeout = return_max_time_allowed_in_unit_test()
    
    def timeout_decorator(item):
        """
            Wrap the original function.
            
        """
        
        @functools.wraps(item)
        def func_wrapper(*args, **kwargs):
            """
                Closure for function.
                
            """
            
            return run_function_with_timeout(func=item, args=args, kwargs=kwargs, timeout_duration=max_timeout)
        return func_wrapper
    return timeout_decorator


class SpecialError(Exception):
    """
        Raise for something wrong inside the function
    """


## G48015
class TimeoutError(Exception):
    """
        Raise for timeout
    """

def run_function_catch_exceptions(func, *args, **kwargs):
    out = ["exception", NotImplementedError("Something wrong inside your function!")]
    try:
        result = func(*args, **kwargs)
        out = ["RESULT", result]
    except Exception as e:
        out = ["exception", e]
    # Could be that within function it raise a special exception which is not under Exception class
    except:
        out = ["exception", SpecialError()]
    return out


import threading
def run_function_with_timeout(func, args=(), kwargs=None, timeout_duration=10, default=None):
    class InterruptableThread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result = default

        def run(self):
            self.result = run_function_catch_exceptions(func, *args, **kwargs)

    if kwargs is None:
        kwargs = {}
    it = InterruptableThread()
    it.start()
    it.join(timeout_duration)
    if it.isAlive():
        raise TimeoutError('Timeout {} secs'.format(timeout_duration))

    if it.result[0] == "exception":
        # g48454: the implementation here is try to solve that sometimes in the function, it raise a not standard error.
        # An example can be find here:
        # @timeout(1)
        # def fun1():
        #    a = 3
        #   try:
        #       print(b)
        #   except:
        #        raise b
        try:
            raise it.result[1]
        except TypeError:
            raise SpecialError("The exception within func is not standard Exception")

    return it.result[1]

def return_max_time_allowed_in_unit_test():
    return 1.0


if __name__ == '__main__':

    @timeout(1)
    def fun1():
        a = 3
        try:
            print(a)
        except:
            raise BaseException()

    fun1()