"""
Python version independent simple functions, which handles the different syntax and methods in Python 2 and 3.

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       07feb2017   G50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import six
import sys
if six.PY2:
    string_types = (str, unicode)
else:
    string_types = (str, bytes)

if six.PY2:
    num_types = (int, float, long)
else:
    num_types = (int, float)


def uni_to_str(string):
    if six.PY2 and isinstance(string, unicode):
        return string.encode()
    return string


def get_input(display_text):
    """
    Python version independent wrapper around basic "input" function, where input is retried from user.

    Args:
        display_text            (str):              Text that will be displayed to user. Typically a question or similar.

    Returns:
        (str):   Users input

    Raises:

    Example:
        The module is called (from python) like this::

            users_age = get_input('How old are you?')

    Warning:

    Notes:
        Author: g50444
    """

    if sys.version_info.major > 2:
        user_input   = input(display_text)
    else:
        user_input   = raw_input(display_text)
    return user_input

def return_main_qt_version():
    import quantum as qt
    return int(qt.__version__.encode().split(".")[1])

def return_main_orca_version():
    import orca
    return int(orca.__version__.encode().split(".")[1])


if __name__ == '__main__':
    print(return_main_orca_version())
