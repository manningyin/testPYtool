import pandas as pd
pd.set_option('display.max_rows', 200)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
# raise RuntimeError('core is deprecated, use risklib')