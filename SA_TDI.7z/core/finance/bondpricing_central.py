import quantum as qt
import core.utils.version_independent as version_indp

def bond_pricing_with_empty_curve(t,cashFlowCache):
    qt_main_version = version_indp.return_main_qt_version()
    ###############################
    # construct an empty curve
    ###############################
    d = [qt.datetime.datetime(2017, 11, 18), qt.datetime.datetime(2050, 11, 28)]
    h = [0, 0]  # input, empty hazard rate
    hc = qt.CurveFlat.make(d, h)
    empty_credit_curve = qt.CreditCurveInterpolated.make('emptyCurve', 'EUR', t, hc, 0.4)
    empty_disc_curve = qt.DiscCurveZeroCoupon.make(t, 'EUR', hc)

    bond_cash_flow_obj = cashFlowCache.getvalue(t)
    if qt_main_version == 9:
        return qt.bondCashFlowPvCc(empty_disc_curve, empty_credit_curve
                                       , bond_cash_flow_obj)
    elif qt_main_version == 11:
        return qt.bondCashFlowPV_CC(empty_disc_curve, empty_credit_curve
                                       , bond_cash_flow_obj)
    elif qt_main_version>12:
        return qt.bondCashFlowPvCc(empty_disc_curve, empty_credit_curve
                                       , bond_cash_flow_obj)
    else:
        return qt.BondCashFlowPV(empty_disc_curve, empty_credit_curve
                                    , bond_cash_flow_obj)