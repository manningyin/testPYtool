"""
The extension of the most basic Black Scholes option pricer for American put and call options.

Can be used for Fx and Equity, but is build in the FX terminology.
Is made to follow the convention in the black_scholes.py functions. 

Interest rates are always continuous compounding on act/365

Warning:
    

Notes:
    Author: g46541

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       05Feb2020   G46541      05 February 2020
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import math
from scipy import stats

# loading the black-scholes pricers in code lib
import os, sys

sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])
# from core.finance import black_scholes as bs
from risklib.finance import black_scholes as bs


def price(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          inf=0
          ):
    """   
    The function prices American call and put options with continuous dividend yield/foreign currency interest rate. 
    The code is based on Barone-Adesi and Whaley (BAW) "Efficient Analytic Approximation of American Options Values" from 1987 and
    is modified to handle zero and negative interest rates. Call options are also handled for negative dividends
    Put options just defaults to the European price if dividend negative. THIS NOT CORRECT; BUT IT IS CURRENTLY NOT KNOW TO 
    HAPPEN.
    The implementation is similar to the implementation of American options in MARS.
    The main building block is to check for the posibility of an possible early exercise. If no possible early exercise 
    is found the option is priced as a European equivalent, otherwise the BAW method is used.
    
    Can be used for Fx and Equity, but is build in the FX terminology. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
                                         In BAW paper there is defined:  b = r_d - r_f -> r_f = r_d - b
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed
        Example:
        The module is called (from python) like this::

            something_returned = price(   spot = 120,
                                          strike = 115,
                                          time_to_maturity = 30/365,
                                          vol = 0.20,
                                          r_d = -0.02,
                                          r_f = -0.01,
                                          call_put = 'p' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        Put options just defaults to the European price if dividend negative and r_d below r_f. 
        THIS NOT CORRECT; BUT IT IS CURRENTLY NOT KNOW TO HAVE HAPPEN, SO SOUTION NOT DEEMED RELEVANT.

    Notes:
        Author: g46541
    """

    # Check whether to price put or call option
    if call_put[0].lower() == 'c':
        # In the case of a call option we check if the European call option could fall below the intrinsic value for a
        # high spot value (10 standard deviations above strike)
        high_spot = strike * (1 + vol * 10 * math.sqrt(time_to_maturity))
        if (high_spot * math.exp(-r_f * time_to_maturity) - strike * math.exp(-r_d * time_to_maturity)) < (
                high_spot - strike):
            # There exist a posibility of an early exercise. Use BAW method to find the American value.
            # chack r_d different from zero, r_d equal needs 0 special handling. To make function stable, the cutoff is 0.1bp
            if math.fabs(r_d) > 0.00001:
                american_add_on = get_american_call_add_on(spot=spot, strike=strike, time_to_maturity=time_to_maturity,
                                                           vol=vol, r_d=r_d, r_f=r_f)
            else:
                # for r_d equal to zero, r_d is moved 0.1bp up and down to the add-on on each side of r_d = 0
                american_add_on_up = get_american_call_add_on(spot=spot, strike=strike,
                                                              time_to_maturity=time_to_maturity, vol=vol,
                                                              r_d=(r_d + 0.00001), r_f=r_f)
                american_add_on_down = get_american_call_add_on(spot=spot, strike=strike,
                                                                time_to_maturity=time_to_maturity, vol=vol,
                                                                r_d=(r_d - 0.00001), r_f=r_f)
                american_add_on = (american_add_on_up + american_add_on_down) / 2
            # The found add_on is added to the European price.
            output = bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='c') + american_add_on
        else:
            # There is no early exercise the price is thus the European price
            output = bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='c')
    else:
        # In the case of a put option we check the relationship between r_d and r_f for whether there is an early exercise opportunity
        if r_f >= 0:
            # dividend yield is non-negative.
            if r_d > 0:
                # interest rates are positive, the limit will be below intrinsic value
                american_add_on = get_american_put_add_on(spot=spot, strike=strike, time_to_maturity=time_to_maturity,
                                                          vol=vol, r_d=r_d, r_f=r_f)
                output = bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='p') + american_add_on
            else:
                # interest rate are negative -> always European price.
                output = bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='p')
        else:
            # dividend yield is negative. weird case!!! real condition should be r_f >= r_d, but solution unstable
            if r_f >= (r_d - 0.01):
                # if the dividend yield is higher than the interest rate we have European solution.
                output = bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='p')
            else:
                # American solution,
                american_add_on = get_american_put_add_on(spot=spot, strike=strike, time_to_maturity=time_to_maturity,
                                                          vol=vol, r_d=r_d, r_f=r_f)
                output = bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='p') + american_add_on

    return output


def get_american_call_add_on(spot,
                             strike,
                             time_to_maturity,
                             vol,
                             r_d,
                             r_f,
                             tolerance=0.00001,
                             info=0
                             ):
    """   
    The function gets the Barone-Adesi and Whaley (BAW) add on for the american call option.
    
    Can be used for Fx and Equity, but is build in the FX terminology. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield.
                                         In BAW paper there is defined:  b = r_d - r_f -> r_f = r_d - b
        tolerance            (double):   tolerance in Newton convergence
        info                    (int):   Level of information printed. The higher, the more information is printed
        Example:
        The module is called (from python) like this::

            something_returned = get_american_call_add_on(   spot = 120,
                                          strike = 115,
                                          time_to_maturity = 30/365,
                                          vol = 0.20,
                                          r_d = 0.01,
                                          r_f = 0.01,
                                          tolerance = 0.00001 ,
                                          info    = 0)
           print(something_returned)

    Warning:
        Do not set r_d = 0
        function is designed for the conditions in price function, so if there is no american solution the functions breaks.
    Notes:
        Author: g46541
    """
    # input in BAW
    M = 2 * r_d / (vol * vol)
    N = 2 * (r_d - r_f) / (vol * vol)
    gamma = 1 - math.exp(-r_d * time_to_maturity)
    q_2 = (-(N - 1) + math.sqrt((N - 1) ** 2 + 4 * M / gamma)) / 2

    # Finding the optimal exercise strike s_star
    # Finding a start value of s_star.
    s_star_inf = strike / (1 - 1 / q_2)
    h_2 = -((r_d - r_f) * time_to_maturity + 2 * vol * math.sqrt(time_to_maturity)) * (strike / (s_star_inf - strike))
    s_star = strike + (s_star_inf - strike) * (1 - math.exp(h_2))

    # Making iterations towards the s_star solution
    lhs = 0
    rhs = 2 * strike * tolerance
    # print("Here:" + str(s_star) +" ,lhs: " + str(lhs) +" ,rhs: " + str(rhs)  )
    while math.fabs((lhs - rhs) / strike) > tolerance:
        d1 = (math.log(s_star / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
                vol * math.sqrt(time_to_maturity))
        # slope of right hand side of equation 19 in Barone-Adesi & Whaley (1987):
        RHSSlope = math.exp(-r_f * time_to_maturity) * stats.norm.cdf(d1) * (1 - 1 / q_2) + (
                1 - math.exp(-r_f * time_to_maturity) * stats.norm.pdf(d1) / (
                vol * math.sqrt(time_to_maturity))) / q_2
        # BS price at s_star
        bs_price_s_star = bs.price(s_star, strike, time_to_maturity, vol, r_d, r_f, call_put='c')
        rhs = bs_price_s_star + (1 - math.exp(-r_f * time_to_maturity) * stats.norm.cdf(d1)) * s_star / q_2
        lhs = s_star - strike
        # new s_star
        s_star = (rhs + strike - RHSSlope * s_star) / (1 - RHSSlope)
        # print("Here:" + str(s_star) +" ,lhs: " + str(lhs) +" ,rhs: " + str(rhs)  )

    # A_2 =(s_star/q_2)*(1-exp((b-r)*T)*norm.cdf(d1))
    d1 = (math.log(s_star / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    A_2 = (s_star / q_2) * (1 - math.exp(-r_f * time_to_maturity) * stats.norm.cdf(d1))
    # print("A_2: ", A_2, "d_1: ", d1)
    # Finding the add_on to be returned
    if spot < s_star:
        output = A_2 * (spot / s_star) ** q_2
    else:
        # if above s_star bs_price is under intrinsic value so the add-on is bringing the price up to intrinsic.
        output = spot - strike - bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='c')

    return output


def get_american_put_add_on(spot,
                            strike,
                            time_to_maturity,
                            vol,
                            r_d,
                            r_f,
                            tolerance=0.00001,
                            info=0
                            ):
    """   
    The function gets the Barone-Adesi and Whaley (BAW) add on for the american put option.
    
    Can be used for Fx and Equity, but is build in the FX terminology. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield.
                                         In BAW paper there is defined:  b = r_d - r_f -> r_f = r_d - b
        tolerance            (double):   tolerance in Newton convergence
        info                    (int):   Level of information printed. The higher, the more information is printed
        Example:
        The module is called (from python) like this::

            something_returned = get_american_put_add_on(   spot = 120,
                                          strike = 115,
                                          time_to_maturity = 30/365,
                                          vol = 0.20,
                                          r_d = 0.01,
                                          r_f = 0.01,
                                          tolerance = 0.00001 ,
                                          info    = 0)
           print(something_returned)

    Warning:
        Do not set r_d = 0
        function is designed for the conditions in price function, so if there is no american solution the functions breaks.
        for unrounded rates the program sometimes break down, reason unknown, example putting r_d = 0.01900000000000006
        instead of r_d = 0.019
        Function breaks if r_f < 0 and r_d <= r_f
    Notes:
        Author: g46541
    """
    # input in BAW
    M = 2 * r_d / (vol * vol)
    N = 2 * (r_d - r_f) / (vol * vol)
    gamma = 1 - math.exp(-r_d * time_to_maturity)
    q_1 = (-(N - 1) - math.sqrt((N - 1) ** 2 + 4 * M / gamma)) / 2

    # Finding the optimal exercise strike s_star
    # Finding a start value of s_star.
    s_star_inf = strike / (1 - 1 / q_1)
    h_1 = ((r_d - r_f) * time_to_maturity - 2 * vol * math.sqrt(time_to_maturity)) * (strike / (strike - s_star_inf))
    s_star = s_star_inf + (strike - s_star_inf) * math.exp(h_1)

    # Making iterations towards the s_star solution
    lhs = 0
    rhs = 2 * strike * tolerance
    while math.fabs((lhs - rhs) / strike) > tolerance:
        # print(s_star)
        d1 = (math.log(s_star / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
                vol * math.sqrt(time_to_maturity))
        # slope of right hand side of equation 24 in Barone-Adesi & Whaley (1987):
        RHSSlope = math.exp(-r_f * time_to_maturity) * stats.norm.cdf(d1) - math.exp(-r_f * time_to_maturity) - (
                1 - math.exp(-r_f * time_to_maturity) * stats.norm.cdf(-d1)) / q_1 - math.exp(
            -r_f * time_to_maturity) * stats.norm.pdf(-d1) / (q_1 * vol * math.sqrt(time_to_maturity))
        # BS price at s_star
        bs_price_s_star = bs.price(s_star, strike, time_to_maturity, vol, r_d, r_f, call_put='p')
        # The slope of the pricing function right hand side and left hand side (the intrinsic value function). at s_star they should converges.
        rhs = bs_price_s_star - (1 - math.exp(-r_f * time_to_maturity) * stats.norm.cdf(-d1)) * s_star / q_1
        lhs = strike - s_star
        # new s_star
        s_star = (strike + RHSSlope * s_star - rhs) / (1 + RHSSlope)

    # Based on s_star
    d1 = (math.log(s_star / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    A_1 = -(s_star / q_1) * (1 - math.exp(-r_f * time_to_maturity) * stats.norm.cdf(-d1))
    # print("A_1: ", A_1)
    # Finding the add_on to be returned
    if spot > s_star:
        output = A_1 * (spot / s_star) ** q_1
    else:
        # if above s_star bs_price is under intrinsic value so the add-on is bringing the price up to intrinsic.
        output = strike - spot - bs.price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put='p')

    return output


if __name__ == '__main__':
    # Unit tests in documentation Call
    print('3_01: ',
          price(spot=110, strike=100, time_to_maturity=0.25, vol=0.20, r_d=-0.005, r_f=-0.005 + 0.02, call_put='c'),
          "Test against 10.619568470861264")
    print('3_02: ', price(spot=105, strike=100, time_to_maturity=1, vol=0.20, r_d=0.06, r_f=0.06 + 0.01, call_put='c'),
          "Test against 10.010986544118555")
    print('3_03: ',
          price(spot=100, strike=100, time_to_maturity=0.5, vol=0.20, r_d=-0.005, r_f=-0.005 + 0.1, call_put='c'),
          "Test against 3.9197402028095545")
    print('3_04: ',
          price(spot=90, strike=100, time_to_maturity=2, vol=0.20, r_d=-0.005, r_f=-0.005 + 0.01, call_put='c'),
          "Test against 5.827811862425981")
    print('3_05: ', price(spot=80, strike=100, time_to_maturity=5, vol=0.40, r_d=0.04, r_f=0.04 + 0.01, call_put='c'),
          "Test against 18.17083738115273")

    # Unit tests in documentation Put
    # b = r_d - r_f -> r_f = r_d - b
    print('3_06: ',
          price(spot=90, strike=100, time_to_maturity=0.25, vol=0.20, r_d=0.01, r_f=0.01 + 0.02, call_put='p'),
          "Test against 11.065392037642107")
    print('3_07: ',
          price(spot=105, strike=100, time_to_maturity=1.0, vol=0.20, r_d=0.03, r_f=0.03 + 0.04, call_put='p'),
          "Test against 7.344441822159587")
    print('3_08: ',
          price(spot=100, strike=100, time_to_maturity=0.5, vol=0.20, r_d=0.01, r_f=0.01 + 0.02, call_put='p'),
          "Test against 6.090128176610465")
    print('3_09: ',
          price(spot=110, strike=100, time_to_maturity=2.0, vol=0.20, r_d=0.01, r_f=0.01 - 0.02, call_put='p'),
          "Test against 6.227919340338877")
    print('3_10: ',
          price(spot=120, strike=100, time_to_maturity=5.0, vol=0.40, r_d=0.04, r_f=0.04 + 0.02, call_put='p'),
          "Test against 27.958100295297236")

    ##The bloew it to check more outcomes of r_d and r_f levels.
    # import numpy as np
    # import matplotlib.pyplot as plt
    #
    ##Call options
    # r_d_vector = np.arange(-0.05, 0.05, 0.001)
    # r_f_vector = np.arange(-0.05, 0.05, 0.01)
    #
    # for i in r_f_vector:
    #    func_am = lambda x : price(spot = 120, strike = 115,time_to_maturity = 30/365,vol = 0.20,r_d = x, r_f = i,call_put = 'c')
    #    func_eu = lambda x : bs.price(spot = 120, strike = 115,time_to_maturity = 30/365,vol = 0.20,r_d = x, r_f = i,call_put = 'c')
    #    print(i)
    #    plt.plot(r_d_vector,list(map(func_eu,r_d_vector)))
    #    plt.plot(r_d_vector,list(map(func_am,r_d_vector)))
    #    plt.show()
    #    #output_am = price(spot = 120, strike = 115,time_to_maturity = 30/365,vol = 0.20,r_d = 0.00, r_f = i,call_put = 'c')
    #    #output_eu = bs.price(spot = 120, strike = 115,time_to_maturity = 30/365,vol = 0.20,r_d = 0.00, r_f = i ,call_put = 'c' ) 
    #    #print(output_am,output_eu)
#    
#    #Put options
#    r_d_vector = np.round(np.arange(-0.05, 0.05, 0.001), 3)
#    r_f_vector = np.round(np.arange(-0.05, 0.05, 0.01), 3)
#    
#    for i in r_f_vector:
#        func_am = lambda x : price(spot = 90, strike = 100,time_to_maturity = 30/365,vol = 0.20,r_d = x, r_f = i,call_put = 'p')
#        func_eu = lambda x : bs.price(spot = 90, strike = 100,time_to_maturity = 30/365,vol = 0.20,r_d = x, r_f = i,call_put = 'p')
#        print(i)
#        plt.plot(r_d_vector,list(map(func_eu,r_d_vector)))
#        plt.plot(r_d_vector,list(map(func_am,r_d_vector)))
#        plt.show()
#        #output_am = price(spot = 120, strike = 115,time_to_maturity = 30/365,vol = 0.20,r_d = 0.00, r_f = i,call_put = 'c')
#        #output_eu = bs.price(spot = 120, strike = 115,time_to_maturity = 30/365,vol = 0.20,r_d = 0.00, r_f = i ,call_put = 'c' ) 
#        #print(output_am,output_eu)
#    print(price(spot = 90, strike = 100,time_to_maturity = 30/365,vol = 0.20,r_d = -0.05, r_f = -0.05,call_put = 'p'))
#    print(bs.price(spot = 90, strike = 100,time_to_maturity = 30/365,vol = 0.20,r_d = -0.04, r_f = -0.05,call_put = 'p'))
