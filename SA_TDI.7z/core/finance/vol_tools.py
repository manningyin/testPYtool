
"""
Different tools to work with implied volatility.

Finding implied voaltility
Finding strike for delta volatility
Interpolating in Delta

Can be used for Fx and Equity, but is build in the FX terminology.
The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 

Interest rates are always continuous compounding on act/365

Warning:
    

Notes:
    Author: g46541

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       25Jul2017   G46541      25 July 2017
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

import math

try:
    from scipy import stats
except:
    pass
    
from core.finance import black_scholes as bs


def imp_vol(spot  ,
          strike   ,
          time_to_maturity ,
          price ,
          r_d ,
          r_f ,
          call_put = 'c' ,
          info    = 0
          ):
    """
    The function returns implied volatility for the price of a given option.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        price                (double):   The price of the option in the domestic currency
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The pure volatility number, that is 15% vol is returned as 0.15

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = imp_vol(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          price = 0.0036356552768788963,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)
           
           #Testing together with black scholes pricer vol should match return:
           spot = 1.1 
           strike = 1.15  
           time_to_maturity = 30/365
           vol = 0.15
           r_d = 0.01
           r_f = 0.02
           call_put = 'c' 
           info    = 0
           bs_value = bs.price(spot,strike,time_to_maturity ,vol ,r_d ,r_f ,call_put)
           something_returned = imp_vol(spot,strike,time_to_maturity ,bs_value ,r_d ,r_f ,call_put)
           print(something_returned)

    Warning:
        Returns 0 if data input not useable and prints error explain

    Notes:
        Author: g46541
    """
    #setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1
        
    #Check if input value makes sens
    if price <  max(0,cp*(spot*math.exp(-r_f*time_to_maturity)-strike*math.exp(-r_d*time_to_maturity))):
        print("Invalid price, error 1")
        return_value = 0
    elif cp == 1 and price > spot*math.exp(-r_f*time_to_maturity):
        print("Invalid price, price of call more than spot, error 2")
        return_value = 0
    elif cp == -1 and price > strike*math.exp(-r_d*time_to_maturity):
        print("Invalid price, price of put more than max payout, error 3")
        return_value = 0
    else:
        #doing newton methods to find implied vol
        saddle = math.sqrt(2/time_to_maturity*abs(math.log(1.1/1.15)+(r_d-r_f)*time_to_maturity))
        if saddle > 0:
            return_value = saddle * 0.9
        else:
            return_value = 0.1
        max_iter = 100
        for i in range(0,max_iter):
            bs_value = bs.price(spot,strike,time_to_maturity ,return_value ,r_d ,r_f ,call_put)-price
            bs_vega = bs.vega(spot,strike,time_to_maturity ,return_value ,r_d ,r_f ,call_put)
            return_value = return_value -bs_value/bs_vega
            if return_value <= 0:
                return_value=0.01
            if abs(bs_value/bs_vega) <= 0.000001:
                break
        
    return return_value


def strike_from_delta(spot  ,
          delta   ,
          time_to_maturity ,
          vol ,
          r_d ,
          r_f ,
          call_put = 'c' ,
          lhs_rhs = 'l',
          spot_forward = 's',
          info    = 0
          ):
    """
    The function returns the strike for a given delta quote.
    The delta quotes are distinctioned between, put or call side, lhs or rhs Delta, and spot or Forward Delta.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        delta                (double):   The delta of the option, 25 Delta is given as 0.25. Note oput delta should be positive value
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The implied volatility for the given delta
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        lhs_rhs                 (str):   Right hand side or left hand side Delta. EURUSD is usually quoted on lhs, 
                                         that is Delta in EUR, USDJPY is quoted rhs that is Delta in JPY.
        spot_forward            (str):   Is is a spot or forward delta, usually spot for maturity < 1 y
                                         and forward for the rest. But this is currency specific.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   Returns a strike level.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = strike_from_delta(   spot = 1.1 ,
                                          delta = 0.25  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          lhs_rhs = 'l',
                                          spot_forward = 's',
                                          info    = 0)
           print(something_returned)
           
           #Testing together with black scholes pricer strike should match return:
           spot = 1.1 
           strike = 1.15  
           time_to_maturity = 30/365
           vol = 0.15
           r_d = 0.01
           r_f = 0.02
           call_put = 'c' 
           info    = 0
           bs_delta = bs.delta(spot,strike,time_to_maturity ,vol ,r_d ,r_f ,call_put)
           something_returned = strike_from_delta(spot,bs_delta,time_to_maturity ,vol,r_d ,r_f ,call_put)
           print(something_returned)
           
           #Testing the Delta is correct
           spot = 1.1 
           delta = 0.25  
           time_to_maturity = 30/365
           vol = 0.15
           r_d = 0.01
           r_f = 0.02
           call_put = 'p'
           lhs_rhs = 'l'
           spot_forward = 'f'
           info    = 0
           strike = strike_from_delta(spot, delta ,time_to_maturity ,vol ,r_d ,r_f ,call_put ,lhs_rhs ,spot_forward ,info  )
           bs_delta = bs.delta(spot,strike,time_to_maturity ,vol ,r_d ,r_f ,call_put)
           if lhs_rhs[0].lower() == 'r':
               bs_delta = bs_delta * spot/ strike
           if spot_forward[0].lower() == 'f':
               bs_delta = math.exp((r_d-r_f)*time_to_maturity)*bs_delta 
           print(bs_delta)
           print(strike)
    Warning:
        Only right hand side spot delta is correctly checked. The three other types should be used carefully, 
        especially the rhs forward delta

    Notes:
        Author: g46541
        
    """
    
    #theta functions
    theta_1 = (r_d-r_f)/vol +  vol/2
    
    #setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1
        delta = -delta
    
    #changing the delta number to the spot delta
    if spot_forward[0].lower() == 'f':
        delta = math.exp(-(r_d-r_f)*time_to_maturity)*delta
            
    #setting the rhs lhs  #page 10 in wystub
    if lhs_rhs[0].lower() == 'l':
        return_value = spot*math.exp(-cp*stats.norm.ppf(cp*delta*math.exp(r_f*time_to_maturity))*vol*math.sqrt(time_to_maturity)+vol*theta_1*time_to_maturity)
    else:
        #initial guess
        return_value = spot*math.exp(-cp*stats.norm.ppf(cp*delta*math.exp(r_f*time_to_maturity))*vol*math.sqrt(time_to_maturity)+vol*theta_1*time_to_maturity)
        #using Newthons metod for calculating the strike
        max_iter = 100
        for i in range(0,max_iter):
            delta_diff = bs.delta(spot,return_value,time_to_maturity ,vol ,r_d ,r_f ,call_put)*spot/return_value-delta
            derivative_delta = (bs.delta(spot,return_value*1.0001,time_to_maturity ,vol ,r_d ,r_f ,call_put)*spot/(return_value*1.0001)
                               -bs.delta(spot,return_value,time_to_maturity ,vol ,r_d ,r_f ,call_put)*spot/return_value)/(return_value*0.0001)
            return_value = return_value -delta_diff/derivative_delta
    return return_value



def strike_from_atm(spot  ,
          time_to_maturity ,
          vol ,
          r_d ,
          r_f ,
          info    = 0
          ):
    """
    The function returns strike of the ATM quote.
    The function assumes that the ATM is quoted as the 0 Straddle strategy.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The implied volatility for the given delta
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   Returns a strike level.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = strike_from_atm(   spot = 1.1 ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          info    = 0)
           print(something_returned)
           
           #Testing together with black scholes pricer strike should match return:
           spot = 1.1  
           time_to_maturity = 30/365
           vol = 0.15
           r_d = 0.01
           r_f = 0.02
           something_returned = strike_from_atm(spot,time_to_maturity ,vol,r_d ,r_f )
           bs_delta_call = bs.delta(spot,something_returned,time_to_maturity ,vol ,r_d ,r_f ,'c')
           bs_delta_put = bs.delta(spot,something_returned,time_to_maturity ,vol ,r_d ,r_f ,'p')
           print(something_returned)
           print(bs_delta_call)
           print(bs_delta_put)
           
           
    Warning:
        

    Notes:
        Author: g46541
        
    """
    
    return_value = spot*math.exp((r_d - r_f + 0.5*vol*vol)*time_to_maturity)
    
    return return_value


def vanna_volga_interpolater( spot  ,
          time_to_maturity ,
          strike ,
          vol_atm ,
          vol_rr,
          vol_fly,
          r_d ,
          r_f ,
          delta = 0.25,
          lhs_rhs = 'l',
          spot_forward = 's',
          info    = 0
          ):
    """
    The function returns a strike based on the ATM, RR and FLY quotes.
    The function assumes that the ATM is quoted as the 0 Straddle strategy.
    The delta quotes are distinctioned between, put or call side, lhs or rhs Delta, and spot or Forward Delta.
    It is assumed that RR and FLY are quoted on a fixed Delta.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "Consistent Pricing of FX Options" by Castagna and Mercurio, 
    http://www.fabiomercurio.it/consistentfxsmile.pdf. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        strike               (double):   The strike value being interpolated
        vol_atm              (double):   The ATM quoted volatility
        vol_rr               (double):   The RR quoted volatility
        vol_fly              (double):   The FLY quoted volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield.
        lhs_rhs                 (str):   Right hand side or left hand side Delta. EURUSD is usually quoted on lhs, 
                                         that is Delta in EUR, USDJPY is quoted rhs that is Delta in JPY.
        spot_forward            (str):   Is is a spot or forward delta, usually spot for maturity < 1 y
                                         and forward for the rest. But this is currency specific.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   Returns the interpolated implied volatility for a given strike level.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = vanna_volga_interpolater(   spot = 1.1 ,
                                          time_to_maturity = 30/365,
                                          strike = 1.1001130195043272,
                                          vol_atm = 0.15,
                                          vol_rr = -0.01,
                                          vol_fly = 0.003,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          delta = 0.25,
                                          lhs_rhs = 'l',
                                          spot_forward = 's',
                                          info    = 0)
           print(something_returned)
           
           #print the smile
           import matplotlib.pyplot as plt
           import numpy as np
           
           spot = 1.1 
           time_to_maturity = 30/365
           vol_atm = 0.15
           vol_rr = -0.01
           vol_fly = 0.003
           r_d = 0.01
           r_f = 0.02
           delta = 0.25
           lhs_rhs = 'l'
           spot_forward = 's'
           
           strike_vector = np.arange(1,1.2,0.001)
           implied_vol_vector = []
           implied_vol_rhs_vector = []
           for strike in strike_vector:
               implied_vol_vector.append(vanna_volga_interpolater(spot,time_to_maturity ,strike ,vol_atm ,vol_rr,vol_fly,r_d ,r_f ,delta ,lhs_rhs ,spot_forward ))
               implied_vol_rhs_vector.append(vanna_volga_interpolater(spot,time_to_maturity ,strike ,vol_atm ,vol_rr,vol_fly,r_d ,r_f ,delta ,'rhs' ,spot_forward ))
           plt.plot(strike_vector,implied_vol_vector)
           plt.plot(strike_vector,implied_vol_rhs_vector)
    Warning:
        

    Notes:
        Author: g46541
        
    """
    #Calculate the XX Delta put and call
    vol_put = vol_atm + vol_fly - 0.5*vol_rr
    vol_call = vol_atm + vol_fly + 0.5*vol_rr
    
    #find strikes
    strike_atm = strike_from_atm(spot,time_to_maturity ,vol_atm,r_d ,r_f )
    strike_put = strike_from_delta(spot,delta,time_to_maturity ,vol_put,r_d ,r_f ,call_put='p',lhs_rhs = lhs_rhs,spot_forward=spot_forward)
    strike_call = strike_from_delta(spot,delta,time_to_maturity ,vol_call,r_d ,r_f ,call_put='c',lhs_rhs = lhs_rhs,spot_forward=spot_forward)
    
    
    #find prices of options
    price_put = bs.price(spot, strike_put, time_to_maturity, vol_put, r_d, r_f, call_put = 'c')
    price_put_atm = bs.price(spot, strike_put, time_to_maturity, vol_atm, r_d, r_f, call_put = 'c')
    vega_put_atm = bs.vega(spot, strike_put, time_to_maturity, vol_atm, r_d, r_f, call_put = 'c')
    price_call =  bs.price(spot, strike_call, time_to_maturity, vol_call, r_d, r_f, call_put = 'c')
    price_call_atm =  bs.price(spot, strike_call, time_to_maturity, vol_atm, r_d, r_f, call_put = 'c')
    vega_call_atm =  bs.vega(spot, strike_call, time_to_maturity, vol_atm, r_d, r_f, call_put = 'c')
    
    price_strike_atm = bs.price(spot, strike, time_to_maturity, vol_atm, r_d, r_f, call_put = 'c')
    vega_strike = bs.vega(spot, strike, time_to_maturity, vol_atm, r_d, r_f, call_put = 'c')
    
    #Finding hedge amounts, see p.5 in mentioned article
    x_1 = vega_strike/vega_put_atm*math.log(strike_atm/strike)*math.log(strike_call/strike)/math.log(strike_atm/strike_put)/math.log(strike_call/strike_put)
    x_3 = vega_strike/vega_call_atm*math.log(strike/strike_put)*math.log(strike/strike_atm)/math.log(strike_call/strike_put)/math.log(strike_call/strike_atm)
    
    #Finding the price of the given strike
    price_strike = price_strike_atm + x_1 * (price_put-price_put_atm) + x_3 * (price_call - price_call_atm)
    
    #Finding the implied vol
    return_value = imp_vol(spot,strike,time_to_maturity ,price_strike ,r_d ,r_f ,call_put='c')
    
    return return_value


def vanna_volga_10delta_extrapolation( spot  ,
          time_to_maturity ,
          vol_atm ,
          vol_rr,
          vol_fly,
          r_d ,
          r_f ,
          lhs_rhs = 'l',
          spot_forward = 's',
          info    = 0
          ):
    """
    The function returns 10 Delta RR and FLY quotes based on the ATM, 25 Delta RR and FLY quotes.
    The function assumes that the ATM is quoted as the 0 Straddle strategy.
    The delta quotes are distinctioned between, put or call side, lhs or rhs Delta, and spot or Forward Delta.
    It is assumed that RR and FLY are quoted on 25 Delta.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "Consistent Pricing of FX Options" by Castagna and Mercurio, 
    http://www.fabiomercurio.it/consistentfxsmile.pdf. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol_atm              (double):   The ATM quoted volatility
        vol_rr               (double):   The RR quoted volatility
        vol_fly              (double):   The FLY quoted volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield.
        lhs_rhs                 (str):   Right hand side or left hand side Delta. EURUSD is usually quoted on lhs, 
                                         that is Delta in EUR, USDJPY is quoted rhs that is Delta in JPY.
        spot_forward            (str):   Is is a spot or forward delta, usually spot for maturity < 1 y
                                         and forward for the rest. But this is currency specific.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   Returns the 10 Delta RR and Fly Quote given 25 Delta RR an FLY + ATM quotes.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = vanna_volga_10delta_extrapolation(spot = 1.1 ,
                                          time_to_maturity = 30/365,
                                          vol_atm = 0.15,
                                          vol_rr = -0.01,
                                          vol_fly = 0.003,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          lhs_rhs = 'l',
                                          spot_forward = 's',
                                          info    = 0)
           print(something_returned)
           
           
    Warning:
        

    Notes:
        Author: g46541
        
    """
    #Calculate the 25 Delta put and call
    vol_25_put = vol_atm + vol_fly - 0.5*vol_rr
    vol_25_call = vol_atm + vol_fly + 0.5*vol_rr
    
    #Initial guess of the 10 Delta strikes
    vol_10_put = vol_25_put
    vol_10_call = vol_25_call
    
    #applying Newthons method
    max_iter = 100
    for i in range(0,max_iter):
        #Put side
        strike_10_put = strike_from_delta(spot ,0.10,time_to_maturity,vol_10_put ,r_d ,r_f ,'p' , lhs_rhs ,spot_forward)
        vol_10_put = vanna_volga_interpolater(spot,time_to_maturity ,strike_10_put ,vol_atm ,vol_rr,vol_fly,r_d ,r_f ,0.25,lhs_rhs ,spot_forward )
        delta_10_put = bs.delta(spot,strike_10_put,time_to_maturity ,vol_10_put ,r_d ,r_f ,'p')
        
        #differentiating
        strike_10_put_diff = strike_from_delta(spot ,0.10,time_to_maturity,vol_10_put*1.0001 ,r_d ,r_f ,'p' , lhs_rhs ,spot_forward )
        vol_10_put_diff = vanna_volga_interpolater(spot,time_to_maturity ,strike_10_put_diff ,vol_atm ,vol_rr,vol_fly,r_d ,r_f ,0.25,lhs_rhs ,spot_forward )
        diff_delta_10_put = ((bs.delta(spot,strike_10_put_diff,time_to_maturity ,vol_10_put_diff ,r_d ,r_f ,'p')-delta_10_put)/(vol_10_put*0.0001))
        
        vol_10_put = vol_10_put -(delta_10_put+0.1)/diff_delta_10_put
        
        #Call side
        strike_10_call = strike_from_delta(spot ,0.10,time_to_maturity,vol_10_call ,r_d ,r_f ,'c' , lhs_rhs ,spot_forward )
        vol_10_call = vanna_volga_interpolater(spot,time_to_maturity ,strike_10_call ,vol_atm ,vol_rr,vol_fly,r_d ,r_f ,0.25,lhs_rhs ,spot_forward )
        delta_10_call = bs.delta(spot,strike_10_call,time_to_maturity ,vol_10_call ,r_d ,r_f ,'c')
        
        #differentiating
        strike_10_call_diff = strike_from_delta(spot ,0.10,time_to_maturity,vol_10_call*1.0001 ,r_d ,r_f ,'c' , lhs_rhs ,spot_forward )
        vol_10_call_diff = vanna_volga_interpolater(spot,time_to_maturity ,strike_10_call_diff ,vol_atm ,vol_rr,vol_fly,r_d ,r_f ,0.25,lhs_rhs ,spot_forward )
        diff_delta_10_call = ((bs.delta(spot,strike_10_call_diff,time_to_maturity ,vol_10_call_diff ,r_d ,r_f ,'p')-delta_10_call)/(vol_10_call*0.0001))
        
        vol_10_call = vol_10_call -(delta_10_call-0.1)/diff_delta_10_call
        
    vol_10_rr = vol_10_call - vol_10_put
    vol_10_fly = (vol_10_call + vol_10_put)/2 - vol_atm
    
    print("10 Delta RR")
    print(vol_10_rr)
    print("10 Delta FLY")
    print(vol_10_fly)
    
    return_value = 0

    return return_value
