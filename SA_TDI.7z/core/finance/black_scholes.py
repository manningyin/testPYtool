"""
The most basic Black Scholes option pricer and Greeks for standard put and call options.

Can be used for Fx and Equity, but is build in the FX terminology.
The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 

Interest rates are always continuous compounding on act/365

Warning:
    

Notes:
    Author: g46541

    ======= =========   =========   ====================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ====================================================================================
    1       25Jul2017   G46541      25 July 2017
    ======= =========   =========   ====================================================================================

Review:
    ======= =========   ========    =========   ========================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ========================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ========================================================================
"""

import math
from scipy import stats


def price_risk(spot,
               strike,
               time_to_maturity,
               vol,
               r_d,
               r_f,
               call_put='c',
               info=0
               ):
    """
    The function gives the most basic Black Scholes option price risk numbers for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in
                                         30 days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2%
                                         interest rate should be given as 0.012. The domestic currency in a currency
                                         pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2%
                                         interest rate should be given as 0.012. The foreign currency in a currency pair
                                         XXXYYY is XXX.
                                         In equities this is the continuous dividend yield.
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (list of dicts):   The Black Scholes price of the option plus risk numbers in pure Black Scholes format

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = price_risk(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)
           print(something_returned['delta'])

    Warning:
        

    Notes:
        Author: g46541
    """

    # calling price and risk functions
    price_val = price(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    delta_val = delta(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    gamma_val = gamma(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    vega_val = vega(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    volga_val = volga(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    vanna_val = vanna(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    theta_val = theta(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    rho_d_val = rho_d(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)
    rho_f_val = rho_f(spot, strike, time_to_maturity, vol, r_d, r_f, call_put)

    # The price
    return_value = {'price': price_val, 'delta': delta_val, 'gamma': gamma_val,
                    'vega': vega_val, 'vanna': vanna_val, 'volga': volga_val,
                    'theta': theta_val, 'rho_d': rho_d_val, 'rho_f': rho_f_val}

    return return_value


def price(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option pricer for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006. 
    
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in
                                         30 days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2%
                                         interest rate should be given as 0.012. The domestic currency in a currency
                                         pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2%
                                         interest rate should be given as 0.012. The foreign currency in a currency pair
                                         XXXYYY is XXX.
                                         In equities this is the continuous dividend yield.
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes price of the option in the domestic currency.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = price(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = cp * (spot * math.exp(-r_f * time_to_maturity) * stats.norm.cdf(cp * d_1) - strike * math.exp(
        -r_d * time_to_maturity) * stats.norm.cdf(cp * d_2))

    return return_value


def delta(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Delta for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    Note: The Delta is the pure Black Scholes Delta, that is the mathematical derivative of the price wrt spot.
    This is the number of foreign currency/stocks equivalent that the position in the option is equal to. 
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in
                                         30 days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes delta of the given option in the foreign  currency.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = delta(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = cp * math.exp(-r_f * time_to_maturity) * stats.norm.cdf(cp * d_1)

    return return_value


def gamma(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Gamma for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    Note: The Gamma is the pure Black Scholes Gamma, not per percentage move in spot or otherwise
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous dividend yield.
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes Gamma of the given option.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = gamma(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = math.exp(-r_f * time_to_maturity) * stats.norm.pdf(d_1) / (spot * vol * math.sqrt(time_to_maturity))

    return return_value


def vega(spot,
         strike,
         time_to_maturity,
         vol,
         r_d,
         r_f,
         call_put='c',
         info=0
         ):
    """
    The most basic Black Scholes option price Vega for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    Note: The Vega is the pure Black Scholes Vega, not per percentage point move in volatility or otherwise
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes vega of the given option in the domestic  currency.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = vega(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = spot * math.sqrt(time_to_maturity) * math.exp(-r_f * time_to_maturity) * stats.norm.pdf(d_1)

    return return_value


def volga(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Volga for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    The Volga is the double derivative of the option price wrt. volatility.
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes volga of the given option in the domestic  currency.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = volga(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = spot * math.sqrt(time_to_maturity) * math.exp(-r_f * time_to_maturity) * stats.norm.pdf(
        d_1) * d_1 * d_2 / vol

    return return_value


def vanna(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Vanna for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    The Vanna is the derivative of the option price wrt. volatility and spot.
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes vanna of the given option in the foreign currency.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = vanna(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = -math.exp(-r_f * time_to_maturity) * stats.norm.pdf(d_1) * d_2 / vol

    return return_value


def theta(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Theta for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    The Theta is given as the pure Black Scholes Theta in years, that is it needs to be multiplied
    by 1/365 to give the 1 day theta
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes theta of the given option in the domestic currency.
                    Needs to be multiplied by 1/365 to give the 1 day Theta.

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = theta(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = (-math.exp(-r_f * time_to_maturity) * stats.norm.pdf(d_1) * spot * vol / (
            2 * math.sqrt(time_to_maturity))
                    + cp * (r_f * spot * math.exp(-r_f * time_to_maturity) * stats.norm.cdf(
                cp * d_1) - r_d * strike * math.exp(-r_d * time_to_maturity) * stats.norm.cdf(cp * d_2)))

    return return_value


def rho_d(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Rho for the domestic/risk free interest rate for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    The Rho is given as the pure Black Scholes Rho, to get the /bp number multiply by 0.0001
    to get the /pp number multiply by 0.01
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes Rho for the domestic/risk free interest rate of the given option in the domestic currency.
                    To get the /bp number multiply by 0.0001
                    To get the /pp number multiply by 0.01

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = rho_d(     spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = cp * time_to_maturity * strike * math.exp(-r_d * time_to_maturity) * stats.norm.cdf(cp * d_2)

    return return_value


def rho_f(spot,
          strike,
          time_to_maturity,
          vol,
          r_d,
          r_f,
          call_put='c',
          info=0
          ):
    """
    The most basic Black Scholes option price Rho for the foreign currency/dividend yield for standard put and call options.
    Can be used for Fx and Equity, but is build in the FX terminology.
    The code is based on "FX Options and structured products" by Uwe Wystub, Wiley 2006.
    The Rho is given as the pure Black Scholes Rho, to get the /bp number multiply by 0.0001
    to get the /pp number multiply by 0.01
     
    
    Args:
        spot                 (double):   The spot value of the underlying asset
        strike               (double):   The strike of the option
        time_to_maturity     (double):   The time to the maturity of the options in years, so an option that expiries in 30
                                         days should be feed the value 30/365.
        vol                  (double):   The Black Scholes volatility given as actual value that is 10% is 0.1
        r_d                  (double):   The interest rate level in domestic currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The domestic currency in a currency pair XXXYYY is YYY.
                                         In equities this is the risk free interest rate level. 
        r_f                  (double):   The interest rate level in foreign currency as the actual value that is 1.2% interest
                                         rate should be given as 0.012. The foreign currency in a currency pair XXXYYY is XXX.
                                         In equities this is the continuous divedend yield. 
        call_put                (str):   Input 'c' or 'p', Also takes 'Put' or 'Call' etc. 
                                         Selection of whether to price a put or a call option.
        info                    (int):   Level of information printed. The higher, the more information is printed

    Returns:
        (double):   The Black Scholes Rho for the foreign currency/dividend yield of the given option in the domestic currency.
                    To get the /bp number multiply by 0.0001
                    To get the /pp number multiply by 0.01

    Raises:
        

    Example:
        The module is called (from python) like this::

            something_returned = rho_f(   spot = 1.1 ,
                                          strike = 1.15  ,
                                          time_to_maturity = 30/365,
                                          vol = 0.15,
                                          r_d = 0.01,
                                          r_f = 0.02,
                                          call_put = 'c' ,
                                          info    = 0)
           print(something_returned)

    Warning:
        

    Notes:
        Author: g46541
    """

    # d functions
    d_1 = (math.log(spot / strike) + (r_d - r_f + 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))
    d_2 = (math.log(spot / strike) + (r_d - r_f - 0.5 * vol * vol) * time_to_maturity) / (
            vol * math.sqrt(time_to_maturity))

    # setting the put call
    if call_put[0].lower() == 'c':
        cp = 1
    else:
        cp = -1

    # The price
    return_value = -cp * time_to_maturity * spot * math.exp(-r_f * time_to_maturity) * stats.norm.cdf(cp * d_1)

    return return_value
