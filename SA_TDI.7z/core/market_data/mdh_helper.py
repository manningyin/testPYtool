"""
Helper module containing various functions needed for integration with Market Data Hub


Warning:
    This should be refactored when it is more clear what is needed.

Notes:
    Author: JBrandt

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       08mar2018   JBrandt     Initial creation
    ======= =========   =========   ========================================================================================
"""
from core.utils import directory
from core.file import csv_IO
from core.utils import dict_helper, date_helper
from core.caching.cache_driver import easy_cache
import os
import re
import requests
import json
import pandas as pd
import copy
_codelib_path = directory.codelib_path()
_md_hub_mapping_folder = os.path.join(_codelib_path, "core\\time_series\\mapping")


def mapping_file_path(risk_factor_type):
    """
    Maps an Avro risk factor type to a csv MD Hub mapping csv file.

    Function needs mapping csv files located in the folder as specified by the "_md_hub_mapping_folder"-variable.
    The names of the csv files must match the following:

        - prefix: as stated by the mapping_file_prefix-variable ("mdhub_<>")
        - suffix: file extension as stated by the mapping_file_type-variable (".csv")
        - stem/main: matching the risk factor name (without version numbering).
            - e.g. "RfCcyPair", "RfInterestRate"
        - Full file name example: 'mdhub_RfCcyPair.csv'

    Args:
        risk_factor_type    (str):      Risk factor type name ("internal" code-lib name). Will in "most" cases
                                        also support avro schema names.

    Returns:
        (str):   Full path of a csv file containing risk factor mapping to MD Hub instrument/time series ids

    Example:
        The module is called (from python) like this::

            from core.market_data import mdh_helper

            my_path = mdh_helper.mapping_file_path('com.nordea.riskfactor.domain.fx.RfCcyPair20')

    Notes:
        Author: JBrandt
    """

    mapping_file_folder = _md_hub_mapping_folder
    mapping_file_prefix = 'mdhub_'
    mapping_file_type = '.csv'

    # ===================================================================================
    # Finding all files in the mapping folder, with the expected pre- and suffix
    # ===================================================================================
    all_mapping_files = directory.dir_with_filter(  folder      = mapping_file_folder,
                                                    starts_with = mapping_file_prefix,
                                                    end_swith   = mapping_file_type,
                                                    )

    # ===================================================================================
    # Stripping file name from expected pre- and suffix. Remaining part of the file-name
    # (supported_type) should now match the name of the risk factor type.
    # Using the "find" method (instead of direct comparision using "==") makes the
    # function a bit more dynmic, and will in most cases also support risk factor
    # avro schema names as input.
    #
    # File-name is initialised to None - which it will remain if no matching mapping file is found.
    # ===================================================================================
    file_name = None
    for mapping_file in all_mapping_files:
        supported_type = mapping_file.strip(mapping_file_prefix).strip(mapping_file_type)
        if risk_factor_type.find(supported_type) >= 0:
            file_name = mapping_file
            break
    if file_name is None:
        raise NotImplementedError('Non-supported risk factor type: ' + risk_factor_type)

    # Constructing full path for the mapping file
    mapping_file_path = mapping_file_folder + '\\' + file_name
    return mapping_file_path


def get_rf_instrument_id(risk_factor, mdhub_envir):
    """
    Translates risk factor avro-definition into a environment specific Market Data Hub Instrument Id

    Args:
        risk_factor     (dict:) Risk factor as dictionary matching the AVRO definition.
                                E.g. {'domestic': 'EUR', 'rfType': 'com.nordea.riskfactor.domain.fx.RfCcyPair20', 'foreign': 'AED'}
        mdhub_envir     (str):  Name of market data hub environment e.g. (dev,uat).
                                Note that the integer ID's are environment specific

    Returns:
        (int):  Market Data Hub Instrument ID (corresponding to an ID of a time series)

    Raises:
        KeyError: (If not one - and only one - unique match is found)

    Example:
        The module is called (from python) like this::

            rf = {'domestic': 'EUR', 'rfType': 'com.nordea.riskfactor.domain.fx.RfCcyPair20', 'foreign': 'USD'}
            my_id = get_rf_instrument_id(risk_factor = rf, mdhub_envir = 'dev')

    Warning:

    Notes:
        Author: JBrandt
    """
    # Making "local" deep copy so we can "pop" elements from the dict, without changing the original object
    local_risk_factor = copy.deepcopy(risk_factor)

    # ===================================================================================
    # Risk factor AVRO schemas all have a rfType field corresponding to different
    # risk factor types.
    #
    # These have different mappings (files). We find the proper one.
    # ===================================================================================
    try:
        rf_type = local_risk_factor.pop('rfType')
    except:
        raise KeyError('Expecting a "rfType" key in the risk factor input dict. - Received: ' + str(risk_factor))
    if type(rf_type) == str:
        # Making it easier to call function directly, without defining risk factor type objects etc.
        rf_type_name = rf_type
    else:
        # Assuming that risk factor type is an RiskFactorType object
        rf_type_name = rf_type.name

    mapping_path = mapping_file_path(risk_factor_type = rf_type_name)

    # ===================================================================================
    # Combining remaining (not rfType) elements in risk factor with the environment
    # key in order to create one dictionary with all filter variables (and values)
    # ===================================================================================
    filter = dict_helper.merge_dicts(local_risk_factor, {'envir': mdhub_envir})

    # ===================================================================================
    # Reading csv file with applied filter.
    # Expecting only one row in output list. Raising exception if more (or less)
    # is returned.
    # ===================================================================================
    mapping_match = csv_IO.read_with_filters(   file            = mapping_path,
                                                filters         = filter,
                                                case_sensitive  = False,
                                            )
    if len(mapping_match) == 1:
        # As expected - one match found.
        md_hub_instrument_id = mapping_match[0]['mdh_instrument_id']
    else:
        raise KeyError('Expected to find one MD Hub ID with ' + str(filter) +
                       '. Found: ' + str(len(mapping_match)) + '. Check file: ' + mapping_path)

    return md_hub_instrument_id


def mdhub_from_webservice(instrument_ids, date, no_of_days, shock_horizon=10, calendar='EUR'):
    """
    Function description

    Args:
        instrument_ids        (int or list of int): Instrument ids represented by integers to load market data for
        date                                (date): The end date to load data for

    Returns:
        (type): Description

    Notes:
        Author:
    """
    instrument_ids = instrument_ids if isinstance(instrument_ids, list) else [instrument_ids]
    dt_date = date_helper.to_datetime(date)
    iso_date = dt_date.date().isoformat()

    out = {}
    for instrument_id in instrument_ids:
        url = ("http://vda1cs5325:8000/RiskFactorScenarios" 
               "?instrumentid=%(instrument_id)s" 
               "&EndDate=%(iso_date)s"
               "&businessdays=%(no_of_days)s"
               "&shockhorizon=%(shock_horizon)s"
               "&calendar=%(calendar)s&format=json&All=True" % locals())
        response = requests.get(url=url)
        dat = json.loads(response.content)
        dat = pd.DataFrame(dat['Results'])
        if not dat.empty:
            dat.columns = ['_'.join(re.findall('[A-Z][^A-Z]*', x)).lower() for x in dat.columns]
            dat['end_date'] = pd.to_datetime(dat['end_date'], format='%Y-%m-%dT%H:%M:%S.%f0')
            dat['price_end_date'] = pd.to_datetime(dat['price_end_date'], format='%Y-%m-%dT%H:%M:%S.%f0')
            dat['price_start_date'] = pd.to_datetime(dat['price_start_date'], format='%Y-%m-%dT%H:%M:%S.%f0')
            dat.set_index('end_date', inplace=True, drop=False)
        out.update({(dt_date, instrument_id): dat})
    return out


if __name__ == '__main__':
    import datetime as dt
    instrument_id = get_rf_instrument_id({'foreign':'SEK','domestic':'EUR','rfType':'RfCcyPair'}, 'int')
    # print(mapping_file_path('RfCcyPair'))
    # print(mapping_file_path('RfInterestRate'))
    a = mdhub_from_webservice(instrument_id, dt.datetime(2017, 4, 10), 1)
    print(a)