import datetime as dt
import shutil

import pandas as pd
from enum import Enum

import core.system.envir as env
from core.caching.cache_driver import easy_cache
from core.connection import database_extract
from core.utils import date_helper
from core.utils import error_handler

_cache_folder = env.data_path() + "\\easy_cache\\damds_mapping\\" + dt.date.today().isoformat() + "\\"


class TimeSeriesType(Enum):
    SHOCK = 'SHOCK'
    RAW = 'RAW'


def all_market_data_ids_for_object(object_id, timeseries_type=TimeSeriesType.SHOCK):
    mapping = build_mapping(timeseries_type=timeseries_type)
    market_data_ids = [key for key in mapping.keys() if object_id in key]
    return market_data_ids


def load_from_damds(market_data_ids, start_date, end_date, timeseries_type=TimeSeriesType.SHOCK, shock_horizon=1):
    mapping = build_mapping(timeseries_type=timeseries_type)
    # If code is interrupted while cache is generated, the .pickle file becomes corrupt. The below code first
    # checks if the mapping is a dictionary, and if not the cache file is deleted and recreated
    if not isinstance(mapping, dict):
        clear_mapping_cache()
        mapping = build_mapping(timeseries_type=timeseries_type)

    market_data_ids = market_data_ids if hasattr(market_data_ids, '__iter__') else [market_data_ids]
    table_name_dict = {}
    for identifier in market_data_ids:
        # Find first appearance of the market_data_id
        try:
            table_name = next(value for key, value in mapping.items() if identifier == key)
            table_name_dict.setdefault(table_name, []).append(identifier)
        except Exception as e:
            error_handler.track_error(error_message=e,
                                      identifier=identifier,
                                      date = start_date,
                                      comments="Cannot fetch table name from market data id")

    out = []
    for table_name, identifiers in table_name_dict.items():
        chunk_size = 1000  # sql language has a limit of 1000 for the list size of a "where X in (...)" clause
        for i in range(0, len(identifiers), chunk_size):
            batch_identifiers = identifiers[i:i+chunk_size]
            tmp_data = extract_data_from_damds_table(market_data_ids    = batch_identifiers,
                                                     start_date         = start_date,
                                                     end_date           = end_date,
                                                     table_name         = table_name,
                                                     timeseries_type    = timeseries_type,
                                                     shock_horizon      = shock_horizon
                                                     )
            out.extend(tmp_data)
    return out


def output_to_df(data, timeseries_type):
    df = pd.DataFrame.from_dict(data=data)
    if len(df) > 0:
        if timeseries_type == TimeSeriesType.SHOCK:
            df['Date'] = df['scenario_date']
        elif timeseries_type == TimeSeriesType.RAW:
            df['Date'] = df['eod_date']
        else:
            raise NotImplementedError
        df.set_index('Date', drop=True, inplace=True)

    return df

def output_to_dict(data, timeseries_type):
    out = dict()
    if timeseries_type == TimeSeriesType.SHOCK:
        date_name = 'scenario_date'
    elif timeseries_type == TimeSeriesType.RAW:
        date_name = 'eod_date'
    else:
        raise NotImplementedError
    for tmp_data in data:
        date_and_id = (tmp_data[date_name], tmp_data['market_data_id'])
        out.update({date_and_id: tmp_data})
    return out


def extract_data_from_damds_table(market_data_ids, start_date, end_date, table_name, timeseries_type, shock_horizon=None):
    sdate = date_helper.oracle_to_date(start_date)
    edate = date_helper.oracle_to_date(end_date)
    if timeseries_type == TimeSeriesType.RAW:
        date_name = 'eod_date'
    elif timeseries_type == TimeSeriesType.SHOCK:
        date_name = 'scenario_date'
    else:
        raise NotImplementedError

    whereclause = "trunc(%(date_name)s) >= %(sdate)s and trunc(%(date_name)s) <= %(edate)s" % locals()
    md_id_string = "('" + "', '".join(market_data_ids) + "')"
    whereclause += " and market_data_id in %(md_id_string)s" % locals()
    if shock_horizon is not None:
        whereclause += "and shock_horizon = %(shock_horizon)s" % locals()
    sql_query = " select * from GMCCR_TIMESERIES." + table_name + " where " + whereclause

    return database_extract.select_from_query(database='DAMDS', query=sql_query)


@easy_cache(cachepath=_cache_folder)
def return_the_final_table_names_from_damds(timeseries_type):
    if timeseries_type == TimeSeriesType.RAW:
        table_type = 'Raw Table'
    elif timeseries_type == TimeSeriesType.SHOCK:
        table_type = 'Shock Table'
    else:
        raise NotImplementedError
    sql = "SELECT table_name FROM GMCCR_TIMESERIES.FRTB_FINAL_TABLE_LIST where table_type = '%s'" % table_type
    data = database_extract.select_from_query(database="DAMDS", query=sql)
    return [x['table_name'] for x in data]


def clear_mapping_cache():
    shutil.rmtree(_cache_folder)


@easy_cache(cachepath=_cache_folder)
def build_mapping(timeseries_type):
    out = dict()
    for table_name in return_the_final_table_names_from_damds(timeseries_type=timeseries_type):
        temp = build_mapping_for_the_table(table_name=table_name)
        market_data_id_list = [x['market_data_id'] for x in temp]
        d = {el: table_name for el in market_data_id_list}
        out.update(d)
    return out


def build_mapping_for_the_table(table_name):
    sql = "select distinct(market_data_id) as market_data_id from GMCCR_TIMESERIES.%(table_name)s" % locals()
    try:
        out_dict = database_extract.select_from_query(database="DAMDS", query=sql)
    except:
        out_dict = [{u'market_data_id': u'not defined'}]
    return out_dict


