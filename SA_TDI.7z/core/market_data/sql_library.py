from core.utils import date_helper
import datetime as dt


def scenario_engine_returns(asset_class, eod_date, sc_grp, pos_type):
    table = 'holding_sc_%s_return' % asset_class if pos_type.lower() == 'effect' else 'trans_sc_%s_return' % asset_class
    if asset_class.lower() == 'interest':
        table += '_1'
    oracle_date = date_helper.oracle_to_date(eod_date)
    pgm_id = 'BOND_HS_SE' if sc_grp == 2000 else 'BOND_ST_SE'
    excl = '--' if pos_type.lower() == 'effect' else ''
    return """
select a.eod_date, a.%(pos_type)s_id, a.sc_id, a.%(asset_class)s_id data_id, product_id, sum(a.return_base) sc_return
from marsp.%(table)s a%(excl)s join marsp.trade b on a.trade_id = b.trade_id
where a.eod_date = %(oracle_date)s
and a.update_pgm_id = '%(pgm_id)s'
group by a.eod_date, a.%(pos_type)s_id, a.sc_id, a.%(asset_class)s_id, product_id
""" % locals()


def rtm_shifts(eod_date, sc_grp, interest_ids, rm_interest_supergrp=3):
    id_lst = ', '.join(map(str, interest_ids))
    oracle_date = date_helper.oracle_to_date(eod_date)
    return """
with interest_projection_interest as (
   select --+ ordered use_nl(rigm rig) use_nl(rig pim)
          rigm.interest_id, 
          pim.projection_interest_id
     from marsp.rm_interest_grp_mapping        rigm
        , marsp.rm_interest_grp                rig
        , marsp.projection_interest_mapping    pim
    where rigm.eod_date                 =  %(oracle_date)s
      and rigm.rm_interest_supergrp_id  =  %(rm_interest_supergrp)s
      and rig.rm_interest_grp_id        =  rigm.rm_interest_grp_id
      and pim.eod_date                  =  rigm.eod_date
      and pim.projection_id             =  rig.projection_id
      and pim.interest_id               =  rigm.interest_id
      and exists (select 1 
                    from marsp.interest_sens
                    where eod_date = %(oracle_date)s
                    and position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp where position_supergrp_id = 'FC') 
                    and interest_id = rigm.interest_id
                  )
)
select a.EOD_DATE, a.SC_ID, b.END_DATE SCENARIO_DATE, c.TERM_ID, p.INTEREST_ID SHIFT_ID, p.PROJECTION_INTEREST_ID proxy_id, c.SHIFT mars_shift
from marsp.sc_grp_sc_dyn a, marsp.timeinterval b, MARSP.RT_INTEREST_SHIFT c, interest_projection_interest p
where a.EOD_DATE = %(oracle_date)s
and a.SC_GRP_ID = %(sc_grp)s
and c.INTEREST_ID = p.PROJECTION_INTEREST_ID
and p.INTEREST_ID in (%(id_lst)s)
and a.SC_ID = b.TIMEINTERVAL_ID
and a.EOD_DATE = c.EOD_DATE
and a.SC_ID = c.SC_ID""" % locals()


def absolute_manual_interest_shifts(eod_date, sc_grp, interest_ids, rm_interest_supergrp=3):
    id_lst = ', '.join(map(str, interest_ids))
    oracle_date = date_helper.oracle_to_date(eod_date)
    return """
with interest_projection_interest as (
   select --+ ordered use_nl(rigm rig) use_nl(rig pim)
          rigm.interest_id, 
          pim.projection_interest_id
     from marsp.rm_interest_grp_mapping        rigm
        , marsp.rm_interest_grp                rig
        , marsp.projection_interest_mapping    pim
    where rigm.eod_date                 =  %(oracle_date)s
      and rigm.rm_interest_supergrp_id  =  %(rm_interest_supergrp)s
      and rig.rm_interest_grp_id        =  rigm.rm_interest_grp_id
      and pim.eod_date                  =  rigm.eod_date
      and pim.projection_id             =  rig.projection_id
      and pim.interest_id               =  rigm.interest_id
      and exists (select 1 
                    from marsp.interest_sens
                   where eod_date = %(oracle_date)s
                     and position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp where position_supergrp_id = 'FC') 
                     and interest_id = rigm.interest_id
                  )
)
select a.EOD_DATE, a.SC_ID, b.END_DATE SCENARIO_DATE, c.TERM_ID, p.INTEREST_ID SHIFT_ID, p.PROJECTION_INTEREST_ID proxy_id, d.INTEREST_PCT-c.INTEREST_PCT mars_shift
from marsp.sc_grp_sc_dyn a, marsp.timeinterval b, marsp.hs_interest_rate c, marsp.hs_interest_rate d, interest_projection_interest p
where a.EOD_DATE = %(oracle_date)s
and a.SC_GRP_ID = %(sc_grp)s
and c.INTEREST_ID = p.PROJECTION_INTEREST_ID
and p.INTEREST_ID in (%(id_lst)s)
and a.SC_ID = b.TIMEINTERVAL_ID
and b.START_DATE = c.EOD_DATE
and b.END_DATE = d.EOD_DATE
and c.INTEREST_ID = d.INTEREST_ID
and c.TERM_ID = d.TERM_ID""" % locals()


def scaled_interest_shifts(eod_date, sc_grp, interest_ids, rm_interest_supergrp=3):
    id_lst = ', '.join(map(str, interest_ids))
    oracle_date = date_helper.oracle_to_date(eod_date)
    return """
with interest_projection_interest as (
   select --+ ordered use_nl(rigm rig) use_nl(rig pim)
          rigm.interest_id, 
          pim.projection_interest_id
     from marsp.rm_interest_grp_mapping        rigm
        , marsp.rm_interest_grp                rig
        , marsp.projection_interest_mapping    pim
    where rigm.eod_date                 =  %(oracle_date)s
      and rigm.rm_interest_supergrp_id  =  %(rm_interest_supergrp)s
      and rig.rm_interest_grp_id        =  rigm.rm_interest_grp_id
      and pim.eod_date                  =  rigm.eod_date
      and pim.projection_id             =  rig.projection_id
      and pim.interest_id               =  rigm.interest_id
      and exists (select 1 
                    from marsp.interest_sens
                   where eod_date = %(oracle_date)s
                     and position_grp_id in (select position_grp_id from marsp.position_supergrp_position_grp where position_supergrp_id = 'FC') 
                     and interest_id = rigm.interest_id
                  )
)
select a.EOD_DATE,
       a.SC_ID,
       Y.END_DATE SCENARIO_DATE,
       a.term_id,
       p.interest_id shift_id,
       p.projection_interest_id proxy_id,
       a.shift*MARSP.INTEREST_FUNCTION_PKG.GET_VALUE(%(oracle_date)s,a.interest_function_id,p.projection_interest_id,b.term_date,
          MARSP.ZEROCOUPON.GET_RATE(%(oracle_date)s,B.TERM_DATE,P.INTEREST_ID,'MID')) mars_shift
  from interest_projection_interest       p,
       marsp.sc_normalized_interest_shift a,
       marsp.term_date                    b,
       marsp.sc_timeinterval              c,
       marsp.hs_interest_rate             d,
       marsp.sc_normalized_interest_shift e,
       marsp.sc_grp_sc_dyn                f,
       marsp.interest_quotient_max_term   x,
       MARSP.LADDER_TERM                  T,
       marsp.timeinterval                 y
 where a.eod_date = %(oracle_date)s
   and a.interest_function_id = 1
   and a.INTEREST_ID = P.PROJECTION_INTEREST_ID
   and b.eod_date = %(oracle_date)s
   and b.term_id = a.term_id
   and c.sc_id = a.sc_id
   and d.eod_date = c.start_eod_date
   and d.interest_id = a.interest_id
   and d.term_id = a.term_id
   and e.eod_date     (+)= a.eod_date
   and e.interest_function_id (+) = 3
   and e.interest_id  (+) = a.interest_id
   and e.term_id      (+) = a.term_id
   and e.sc_id        (+) = a.sc_id
   and f.eod_date = %(oracle_date)s
   and F.SC_GRP_ID = %(sc_grp)s
   and P.INTEREST_ID in (%(id_lst)s)
   and f.sc_id    = a.sc_id
   and x.ladder_id = 68
   and x.interest_id = a.interest_id
   and t.ladder_id = x.ladder_id
   and t.term_id = a.term_id
   and T.TERM_NO <= X.MAX_TERM_NO
   and a.sc_id = y.timeinterval_id
""" % locals()


def absolute_spread_shifts(eod_date, sc_grp, spread_ids):
    oracle_date = date_helper.oracle_to_date(eod_date)
    id_lst = ', '.join(map(str, spread_ids))
    return """
select a.eod_date, a.sc_id, b.end_date scenario_date, c.spread_id shift_id, e.bond_interest_id, c.term_id, d.spread_pct-c.spread_pct mars_shift
from marsp.sc_grp_sc_dyn a, marsp.timeinterval b, marsp.spread_rate c, marsp.spread_rate d, marsp.bond_swap_basis_mapping e
where a.eod_date = %(oracle_date)s
and a.sc_grp_id = %(sc_grp)s
and a.sc_id = b.timeinterval_id
and c.spread_id = d.spread_id
and c.term_id = d.term_id
and c.eod_date = b.start_date
and d.eod_date = b.end_date
and c.spread_id in (%(id_lst)s)
and c.spread_id = e.spread_id
""" % locals()


def relative_fx_shifts(eod_date, sc_grp, ccy_ids):
    oracle_date = date_helper.oracle_to_date(eod_date)
    id_lst = "', '".join(map(str, ccy_ids))
    return """
select a.EOD_DATE, a.SC_ID, b.END_DATE scenario_date, c.CURRENCY_ID shift_id, d.PRICE/c.PRICE-1 mars_shift
from marsp.sc_grp_sc_dyn a, marsp.timeinterval b, marsp.currency_price c, marsp.currency_price d
where a.eod_date = %(oracle_date)s
and a.SC_GRP_ID = %(sc_grp)s
and a.SC_ID = b.TIMEINTERVAL_ID
and c.CURRENCY_ID = d.CURRENCY_ID
and c.EOD_DATE = b.START_DATE
and d.EOD_DATE = b.END_DATE
and c.CURRENCY_ID in ('%(id_lst)s')
""" % locals()


def holding_sens(eod_date, asset_class, data_ids, product_ids, orca_sens=False):
    t_add = '_1' if orca_sens else ''
    asset_class = 'interest' if asset_class == 'spread' else asset_class
    excl = '--' if asset_class == 'currency' else ''
    incl = '' if asset_class == 'currency' else '--'
    schema = 'g48606' if eod_date == dt.datetime(2018, 11, 22) else 'marsp'
    oracle_date = date_helper.oracle_to_date(eod_date)
    id_lst = "', '".join(map(str, data_ids))
    pr_lst = ', '.join(map(str, product_ids))
    return """
select a.eod_date, a.product_id, a.effect_id, b.isin, a.%(asset_class)s_id sens_id,%(excl)s d.to_term_id term_id, sum(d.wgt*a.sens_base) sens_base
%(incl)ssum(a.sens_base) sens_base 
from %(schema)s.holding_%(asset_class)s_sens%(t_add)s a, g48606.isins b, marsp.cons_org_structure_std_hist c%(excl)s, marsp.ladder_term_wgt d
where a.eod_date = %(oracle_date)s
and a.effect_id = b.effect_id
and a.%(asset_class)s_id in ('%(id_lst)s')
and a.product_id in (%(pr_lst)s)
and a.eod_date = c.eod_date
and a.org_id = c.org_id
and c.cons_org_id = 50004
%(excl)sand a.eod_date = d.eod_date and a.term_id = d.term_id and d.to_ladder_id = 68
group by a.eod_date, a.product_id, a.effect_id, a.%(asset_class)s_id, b.isin%(excl)s, d.to_term_id
""" % locals()


def trans_sens(eod_date, asset_class, sens_ids, product_ids, orca_sens=False):
    t_add = '_1' if orca_sens else ''
    asset_class = 'interest' if asset_class == 'spread' else asset_class
    excl = '--' if asset_class == 'currency' else ''
    incl = '' if asset_class == 'currency' else '--'
    schema = 'g48606' if eod_date == dt.datetime(2018, 11, 22) else 'marsp'
    oracle_date = date_helper.oracle_to_date(eod_date)
    id_lst = "', '".join(map(str, sens_ids))
    pr_lst = ', '.join(map(str, product_ids))
    return """
select b.*, a.isin from g48606.isins a, (
select /*+ parallel */ a.EOD_DATE, b.PRODUCT_ID, a.TRADE_ID, max(c.EFFECT_ID) EFFECT_ID, a.%(asset_class)s_id sens_id,%(excl)s e.TO_TERM_ID TERM_ID, sum(e.WGT*a.SENS_BASE) SENS_BASE
%(incl)ssum(a.SENS_BASE) SENS_BASE
from %(schema)s.trans_%(asset_class)s_sens%(t_add)s a, MARSP.TRADE b, MARSP.TRANS c, MARSP.CONS_ORG_STRUCTURE_STD_HIST f%(excl)s, MARSP.LADDER_TERM_WGT e
where a.EOD_DATE = %(oracle_date)s
and a.%(asset_class)s_ID in ('%(id_lst)s')
and a.TRADE_ID = b.TRADE_ID
and b.PRODUCT_ID in (%(pr_lst)s)
and a.TRADE_ID = c.TRADE_ID
and a.TRANS_ID = c.TRANS_ID
and c.ORG_ID = f.ORG_ID
and a.EOD_DATE = f.EOD_DATE
and f.CONS_ORG_ID = 50004
%(excl)sand a.TERM_ID = e.TERM_ID and e.TO_LADDER_ID = 68 and a.EOD_DATE = e.EOD_DATE
group by a.EOD_DATE, b.PRODUCT_ID, a.TRADE_ID, a.%(asset_class)s_ID%(excl)s, e.TO_TERM_ID
) b where a.EFFECT_ID = b.EFFECT_ID
""" % locals()


def isin_holding_quantity(eod_date, isins):
    oracle_date = date_helper.oracle_to_date(eod_date)
    isin_lst = "', '".join(isins)
    return """
select a.ISIN, sum(b.quantity) quantity, sum(b.QUANTITY*d.price/100) quantity_base
from G48606.ISINS a, marsp.holding b, marsp.effect c, marsp.currency_price d, marsp.cons_org_structure_std_hist e
where a.EFFECT_ID = b.EFFECT_ID
and b.EOD_DATE = %(oracle_date)s
and a.ISIN in ('%(isin_lst)s')
and a.EFFECT_ID = c.EFFECT_ID
and c.CURRENCY_ID = d.CURRENCY_ID
and b.EOD_DATE = d.EOD_DATE
and b.EOD_DATE = e.EOD_DATE
and b.ORG_ID = e.ORG_ID
and e.CONS_ORG_ID = 50004
group by a.isin
""" % locals()


def isin_trans_quantity(eod_date, isins):
    trans_schema = 'g48606' if eod_date == dt.datetime(2018, 11, 22) else 'marsp'
    oracle_date = date_helper.oracle_to_date(eod_date)
    isin_lst = "', '".join(isins)
    return """
select /*+ parallel */ f.ISIN, sum(a.QUANTITY) quantity, sum(a.QUANTITY*e.PRICE/100) quantity_base
from MARSP.TRANS a, %(trans_schema)s.TRANS_STATUS b, MARSP.CONS_ORG_STRUCTURE_STD_HIST c, MARSP.EFFECT d, MARSP.CURRENCY_PRICE e, G48606.ISINS f
where a.TRADE_ID = b.TRADE_ID
and a.TRANS_ID = b.TRANS_ID
and b.EOD_DATE = %(oracle_date)s
and b.TRANS_STATUS_TYPE_ID = 'BOOK'
and b.EOD_DATE = c.EOD_DATE
and a.ORG_ID = c.ORG_ID
and c.CONS_ORG_ID = 50004
and a.EFFECT_ID = d.EFFECT_ID
and d.CURRENCY_ID = e.CURRENCY_ID
and b.EOD_DATE = e.EOD_DATE
and a.EFFECT_ID = f.EFFECT_ID
and f.ISIN in ('%(isin_lst)s')
group by f.ISIN
""" % locals()


def bond_to_swap():
    return """
select a.INTEREST_ID BOND_ID, B.INTEREST_ID SWAP_ID, a.CURRENCY_ID
from marsp.interest a, marsp.interest b
where a.CURRENCY_ID = B.CURRENCY_ID
and b.INTEREST_MARKET_ID = 'SWAP'
and a.INTEREST_MARKET_ID in ('GOVM', 'MORTG')
"""


def spread_to_bond():
    return """
select a.SPREAD_ID, b.INTEREST_ID
from marsp.spread a, marsp.interest b
where a.SPREAD_MARKET_ID = 'BOND-SWAP_BASIS'
and a.CURRENCY_ID = b.CURRENCY_ID
and case when a.NAME like '%GOV%' then 'GOVM' else 'MORTG' end = b.INTEREST_MARKET_ID
and case when (a.CURRENCY_ID != 'EUR' or a.name='EUR-MORTG_SWAP_BASIS') then 'BENCH' else substr(a.name, 1, 2) end = b.INTEREST_ISSUER_ID
"""


def shift_type_comparison(eod_date, interest_id, term_id, sc_grp):
    oracle_date = date_helper.oracle_to_date(eod_date)
    return f"""
select a.SC_ID, 
       c.START_DATE, 
       c.END_DATE, 
       a.INTEREST_ID, 
       g.NAME,
       a.TERM_ID, 
       a.SHIFT abs_shift_quotients, 
       e.INTEREST_PCT - d.INTEREST_PCT abs_shift_raw,
       f.SHIFT rtm_shift,
       h.shift*MARSP.INTEREST_FUNCTION_PKG.GET_VALUE({oracle_date},h.interest_function_id,h.interest_id,i.term_date,
          MARSP.ZEROCOUPON.GET_RATE({oracle_date},i.TERM_DATE,a.INTEREST_ID,'MID')) ls_shift,
       case when round(a.shift, 3) = round(e.interest_pct - d.interest_pct, 3) then 'TRUE' else 'FALSE' end quot_equals_raw
from MARSP.SC_NORMALIZED_INTEREST_SHIFT a, 
     MARSP.SC_GRP_SC_DYN b, 
     MARSP.TIMEINTERVAL c, 
     MARSP.HS_INTEREST_RATE d, 
     MARSP.HS_INTEREST_RATE e,
     MARSP.RT_INTEREST_SHIFT f,
     MARSP.INTEREST g,
     MARSP.SC_NORMALIZED_INTEREST_SHIFT h,
     MARSP.TERM_DATE i
where a.EOD_DATE = {oracle_date}
and a.INTEREST_ID = {interest_id}
and a.INTEREST_FUNCTION_ID = 3
and a.EOD_DATE = b.EOD_DATE
and a.SC_ID = b.SC_ID
and b.SC_GRP_ID = {sc_grp}
and a.TERM_ID = {term_id}
and a.sc_id = c.TIMEINTERVAL_ID
and a.INTEREST_ID = d.INTEREST_ID
and a.TERM_ID = d.TERM_ID
and c.START_DATE = d.EOD_DATE
and a.INTEREST_ID = e.INTEREST_ID
and a.TERM_ID = e.TERM_ID
and c.END_DATE = e.EOD_DATE
and a.EOD_DATE = f.EOD_DATE
and a.INTEREST_ID = f.INTEREST_ID
and a.TERM_ID = f.TERM_ID
and a.SC_ID = f.SC_ID
and a.INTEREST_ID = g.INTEREST_ID
and a.INTEREST_ID = h.INTEREST_ID
and a.EOD_DATE = h.EOD_DATE
and a.TERM_ID = h.TERM_ID
and a.SC_ID = h.SC_ID
and h.INTEREST_FUNCTION_ID = 1
and a.EOD_DATE = i.EOD_DATE
and a.TERM_ID = i.TERM_ID
"""