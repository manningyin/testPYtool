""" Retrieving surfaces (vol, model-parameters etc) from Orca. + Related functionality.

TODO (Future work):
  - immutable Surface objects
  - implement hash functionality (for cashing, test for equality) -- requires immutability.
  - interpolation of surface data
  - output to QT surface object or scenario object.

"""

import numpy as np
from core.market_data.datatype.x import InterpolationType, Units
from core.utils.sequences import emap


## decorator
def to_pickle(path_filename=None):
    import pickle as pc

    if path_filename is None:
        path_filename = './default_out.pickle'

    def decorator(func):
        def wrapper(cls, *args, **kwargs):
            with open(path_filename, 'wb') as pfile:
                    pc.dump(func(cls, *args, **kwargs), pfile)
            return func(cls, *args, **kwargs)
        return wrapper
    return decorator


def orca_wrapper():
    """ Hiding all ORCA related setup."""

    import application.ir_options.freia.setup.set_up_orca as su

    service = su.get_service_request()  # initialise Orca services
    context_time_stamp = timestamp.ContextTimeStamp(dt.date(2017, 8, 14), dt.date(2017, 8, 14))  # (valuation_date, database_date)

    qt_lambda_surfaces = service.get_surfaces(context_time_stamp, [InfinityMarketDataName('EURLAM_REV', Currency.EUR, InfinityMarketDataInstance.CLOSE),
                                                                   InfinityMarketDataName('USDLAM_REV', Currency.USD, InfinityMarketDataInstance.CLOSE)])
    lambda_surfaces = Surface.from_qtoolkit(qt_lambda_surfaces, context_time_stamp=context_time_stamp)   # wrap into MRA object
    lambda_surfaces[0].plot(export_to_pdf=False)

    print('Surface name: {}.'.format(lambda_surfaces[0].identifier.get('name')))


class Surface():
    def __init__(self, data, valuation_datetime=None, db_datetime=None, units=None, maturities=None, tenors=None,
                 tenor_interpolation=None, maturity_interpolation=None, identifier=None):

        msize, tsize = data.shape
        self.data = data

        self.valuation_datetime = None if valuation_datetime is None else valuation_datetime
        self.db_datetime = None if db_datetime is None else db_datetime
        self.units = Units.NONE if units is None else units
        self.maturities = range(msize) if maturities is None else maturities
        self.tenors = range(tsize) if tenors is None else tenors
        self.tenor_interpolation = InterpolationType.NONE if tenor_interpolation is None else tenor_interpolation
        self.maturity_interpolation = InterpolationType.NONE if maturity_interpolation is None else maturity_interpolation

        # Covers three cases: Related to name-concatenation in __sum__() via str() method etc.
        # 1)   'name' is None (if-case) OR 'name' == 'None' (else-case)
        # 2)   'name' not a key (else-case)
        # 3)   'name' as provided by method call (else-case)
        if identifier is None:
            name = 'None'
            currency = None
        else:
            name = str(identifier.get('name', None))
            currency = identifier.get('currency', None)

        self.identifier = {'name':name, 'currency':currency}
        self.__array_priority__ = 100  # Magic number to enforce usage of overwriting methods from this "Surface" class, i.e. 1 + surface1 will call surface1 __radd__().

#    def __new__(cls, data, valuation_datetime, db_datetime, units, maturities, tenors,
#                tenor_interpolation, maturity_interpolation, identifier):
#        cls.data = data
#        cls.valuation_datetime = valuation_datetime
#        cls.db_datetime = db_datetime
#        cls.units = units
#        cls.maturities = maturities
#        cls.tenors = tenors
#        cls.tenor_interpolation = tenor_interpolation
#        cls.maturity_interpolation = maturity_interpolation
#        cls.identifier = identifier
#        self.__array_priority__ = 100  # Magic number to enforce usage of overwriting methods from this "Surface" class, i.e. 1 + surface1 will call surface1 __radd__().
#        return cls

    # For pickeling -- probably not needed. TODO: Check.
    # TODO: Check "fractions.py" for pickling, method "__reduce__()
    def __reduce__(self):
        return (self.__class__, (self.data, self.valuation_datetime, self.db_datetime, self.units, self.maturities, self.tenors,
        self.tenor_interpolation, self.maturity_interpolation, self.identifier,))

    @classmethod
    @to_pickle("./make_one.pickle")
    def make_one(cls):
        return Surface(data=np.ones(shape=(4,4)), valuation_datetime=dt.date(2017, 8, 18), db_datetime=None, units=Units.NONE,
                   maturities=range(4), tenors=range(4), tenor_interpolation=None, maturity_interpolation=None,
                   identifier={'name': 'EUR.FREIA.LAM', 'currency': 'EUR'})


    def datestr(self):
        """Return data or [dates] as pretty-print string."""
        return str(emap(str, self.valuation_datetime))

    def __str__(self):
        return self.get_name() + ' :: ' + self.datestr()

    def get_name(self):
        return self.identifier.get('name')

    def __add__(self, other, reverse_name=False):
        """
          See: Surface.__sub__
        """

        if isinstance(other, Surface):
            _data = self.data + other.data
            if reverse_name:
                _name = '(' + other.get_name() + ' + ' + self.get_name() + ')'
            else:
                _name = '(' + self.get_name() + ' + ' + other.get_name() + ')'
            _valuation_datetime = (self.valuation_datetime, other.valuation_datetime)
        elif isinstance(other, (int, float, complex, np.ndarray)):
            _data = self.data + other
            if reverse_name:
                _name = '(' + str(other) + ' + ' + self.get_name() + ')'
            else:
                _name = '(' + self.get_name() + ' + ' + str(other) + ')'
            _valuation_datetime = self.valuation_datetime
        else:
            return NotImplementedError

        _identifier = {'name': _name, 'currency': self.identifier.get('currency'),
                       'instance_code': self.identifier.get('instance_code')}


        return Surface(data=_data, valuation_datetime=_valuation_datetime, db_datetime=None, units=self.units, maturities=self.maturities,
                       tenors=self.tenors, tenor_interpolation=self.tenor_interpolation, maturity_interpolation=self.maturity_interpolation,
                       identifier=_identifier)


    def __radd__(self, other):
        """
                  See: Surface.__sub__
        """
        return self.__add__(other, reverse_name=True)


    def __sub__(self, other):
        """
            Class operator for subtraction "-" (minus)

            surface - x,
            where x is {Surface instance, numpy.array, int, float, complex). \n
            Does *not* check for coherency of:
                     - tenor or maturity grids
                     - units (e.g. percent vs basis points)

            Default: unchecked attributes are populated by attributes of the *first* item in the substraction.

            Notes:
                Author: G46474 (Joerg Wegener)
         """

        if isinstance(other, Surface):
            _data = self.data - other.data
            _name = '(' + self.get_name() + ' - ' + other.get_name() + ')'
            _valuation_datetime = (self.valuation_datetime, other.valuation_datetime)
        elif isinstance(other, (int, float, complex, np.ndarray)):
            _data = self.data - other
            _name = '(' + self.get_name() + ' - ' + str(other) + ')'
            _valuation_datetime = self.valuation_datetime
        else:
            return NotImplemented

        _identifier = {'name': _name, 'currency': self.identifier.get('currency'),
                       'instance_code': self.identifier.get('instance_code')}

        return Surface(data=_data, valuation_datetime=_valuation_datetime, db_datetime=None, units=self.units,
                       maturities=self.maturities,
                       tenors=self.tenors, tenor_interpolation=self.tenor_interpolation,
                       maturity_interpolation=self.maturity_interpolation,
                       identifier=_identifier)

    def __rsub__(self, other):
        """
                  See: Surface.__sub__
        """

        if isinstance(other, Surface):
            _data = other.data - self.data
            _name = '(' + other.get_name() + ' - ' + self.get_name() + ')'
            _valuation_datetime = (other.valuation_datetime, self.valuation_datetime)
        elif isinstance(other, (int, float, complex, np.ndarray)):
            _data = other - self.data
            _name = '(' + str(other) + ' - ' + self.get_name() + ')'
            _valuation_datetime = self.valuation_datetime
        else:
            return NotImplemented

        _identifier = {'name': _name, 'currency': self.identifier.get('currency'),
                       'instance_code': self.identifier.get('instance_code')}

        return Surface(data=_data, valuation_datetime=self.valuation_datetime, db_datetime=None, units=self.units,
                       maturities=self.maturities,
                       tenors=self.tenors, tenor_interpolation=self.tenor_interpolation,
                       maturity_interpolation=self.maturity_interpolation,
                       identifier=_identifier)

    def __mul__(self, other, reverse_name=False):
        """
                  See: Surface.__sub__
        """


        if isinstance(other, Surface):
            _data = self.data * other.data
            if reverse_name:
                _name = other.identifier.get('name') + ' * ' + self.identifier.get('name')
            else:
                _name = self.identifier.get('name') + ' * ' + other.identifier.get('name')
            _valuation_datetime = (self.valuation_datetime, other.valuation_datetime)
        elif isinstance(other, (int, float, complex, np.ndarray)):
            _data = self.data * other
            if reverse_name:
                _name = str(other) + '*' + self.identifier.get('name')
            else:
                _name = self.identifier.get('name') + ' * ' + str(other)
            _valuation_datetime = self.valuation_datetime
        else:
            return NotImplemented

        _identifier = {'name': _name, 'currency': self.identifier.get('currency'),
                       'instance_code': self.identifier.get('instance_code')}

        return Surface(data=_data, valuation_datetime=_valuation_datetime, db_datetime=None, units=self.units,
                       maturities=self.maturities,
                       tenors=self.tenors, tenor_interpolation=self.tenor_interpolation,
                       maturity_interpolation=self.maturity_interpolation,
                       identifier=_identifier)


    def __rmul__(self, other):
        """
                  See: Surface.__sub__
        """
        return self.__mul__(other, reverse_name=True)


    @classmethod
    @to_pickle("./surface_data.pickle")
    def from_qtoolkit(cls, qt_surfaces, context_time_stamp = None):
        """
           Create surface from Orca service **qt_surfaces=get_surfaces(...)**.
           'qt_surfaces' is of type 'orca.mq.async_result_wrapper.AsyncResultWrapper' and may represent multiple surfaces.
           In that case, a list of Surface objects is returned.
        """

        _valuation_datetime = None
        _db_datetime = None

        if context_time_stamp:
            _valuation_datetime = context_time_stamp[0]
            _db_datetime = context_time_stamp[1]

        # unpack QToolkit surface object
        result = []
        for s in qt_surfaces.result().items():

            # shortcuts
            y = s[0]  # meta-data
            x = s[1]  # surface-values/matrix

            # transform surface-values to numpy.array
            _data = np.array([i.data for i in x.surfaceValues.data])  # 'data' has dimensions (len(maturities), len(tenors)).

            # meta-data
            _maturities = x.surfaceDates # TODO: turn into tuples
            _tenors = x.surfaceTenors  # TODO: turn into tuples
            _identifier = {'name': y.name, 'currency' : y.currency, 'instance_code' : y.instance_code}

            # construct custom-made surface
            result.append(cls(data=_data, valuation_datetime=_valuation_datetime, db_datetime=_db_datetime, units=Units.NONE, maturities=_maturities, tenors=_tenors,
                        tenor_interpolation=InterpolationType.NONE, maturity_interpolation=InterpolationType.NONE, identifier=_identifier))

        return result


    @classmethod
    @to_pickle("./surface_data.pickle")
    def from_damds(cls, currency, valuation_date):
        """
           Constructs Surface instance sourcing database DAMDS.
        
           :param Enum currency: -- A currency
           :param datetime.date valuation_date: -- A valuation date
           :return: -- A Surface instance

           Warning: The DB connection part of this code should be refactored to be more transparent.
        """

        import pandas as pd
        import core.utils.date_helper as dt_utils
#        import core.connection.database_extract as database_extract
        import core.connection.database_connect as database_connect
        import pyodbc
        import datetime as dt
#        import time



        def add_days(anchordate, days):
            """
             Add integer day(s) to a datetime.date.
               :param datetime.date or datetime.datetime anchordate:
               :param integer or list(integer) days:
            """
            dates = []
            for day in days:
                dates.append(anchordate + dt.timedelta(days=day))

            return dates


        def get_sql():
            vdate = dt_utils.oracle_to_date(valuation_date)

            # ESSENTIAL: sql returns are ordered such that option expiry (aka maturity) changes
            # slowest and maturity of the underlying (aka tenor) quickest. If that is not ensured,
            # below np.array "data" is not ordered, i.e. gridded correctly.

            # Beware, single quotation marks (') in second-to-last SQL line.

            ## TODO: ensure that MATURITY are integers, use some SQL to_int(...)
            sql = """select
                       EOD_DATE as VALUATION_DATE,
                       UPDATE_DATETIME as DB_DATETIME,
                       INTEREST_PCT as DATA,
                       'PERCENT' as UNITS,
                       EXPIRY_OPTION_DAYS as MATURITY,
                       MATURITY_UNDERLYING as TENOR,
                       substr(MARKET_DATA_ID, 1, 3) as CURRENCY,
                       SURFACE_NAME as NAME
                   from GMCCR_TIMESERIES.FRTB_RAW_INTEREST_RATE_VOL
                   where trunc(EOD_DATE) = """ + vdate + """
                   and substr(MARKET_DATA_ID, 1, 3) = '""" + currency.name + """'       
                   order by EXPIRY_OPTION_DAYS, MATURITY_UNDERLYING_DAYS asc"""
            return sql

        sql = get_sql()
        connector = database_connect.get_string('damds')
        connection = pyodbc.connect(connector)
        table = pd.read_sql(sql, connection)

        distinct_maturities = tuple(sorted(table.MATURITY.drop_duplicates())) #ascending order
        distinct_tenors = tuple(table.TENOR[table.MATURITY == distinct_maturities[0]]) # TODO: make water proof & make sure that order is preserved (ascending).

        # Single out surface values.
        # The boolean indexing (while looping over each unique maturity and tenor) returns an empty element when there does *not* exist ...
        # ... a surface element for given maturity-tenor pair. "Missing data"/deviating tenors or maturities are therefore easy to spot.
        _data = np.ones( shape=(len(distinct_maturities),len(distinct_tenors)) )
        for mi, m in enumerate(distinct_maturities):
            for ti, t in enumerate(distinct_tenors):
                bol = (table.MATURITY == m) & (table.TENOR == t)
                _data[mi][ti] = table.DATA[bol].values # pick out the value corresponding to maturity m and tenor t.
                # TODO: make function that picks out key-value pairs of pd.DataFrame.
                #get(return_column=None, column=column_value) parameters as kwargs and column_value possible as tuple for multiple values (corresponding to SQL blablabla in (...), strict equality otherwise. If return_column is None, return whole sub-matrix.
                # Issue of data[bool_vector1((len_data))][bool_vector2((len_data))]  is that first index reduces size of 'data' already, so bool_vector should have different size.
                # Poor man's solution:
                #            dummy = data[bool_vector ((len_data))]
                #            result = dummy([dummy == value])


        surface_name = table.NAME.drop_duplicates()[0]
        currency = table.CURRENCY.drop_duplicates()[0]  # TODO: make Enum
        units = Units[table.UNITS.drop_duplicates()[0]]  # make Enum
        _db_datetime = table.DB_DATETIME.drop_duplicates().dt.to_pydatetime()[0]   # TODO: test if table.DB_DATETIME is *one* single unique date.
        vdate = table.VALUATION_DATE.drop_duplicates().dt.to_pydatetime()[0]       # TODO: test if table.VALUATION_DATE is *one* single unique date.

        # meta-data
        _maturities = tuple(add_days(vdate.date(), distinct_maturities)) # transform offset (-days) into dates
        _identifier = {'name': surface_name, 'currency' : currency, 'instance_code' : None}

        # construct surface
        return cls(data=_data, valuation_datetime=vdate, db_datetime=_db_datetime, units=units, maturities=_maturities, tenors=distinct_tenors,
                   tenor_interpolation=InterpolationType.NONE, maturity_interpolation=InterpolationType.NONE, identifier=_identifier)

        # TODO: put conversion from pd.datetime64[ns] to dt.datetime into datetime_helpers.
        # TODO: If time allows, write a maturity-string ordering function.



    def plot(self, export_to_pdf = False):
        """
           Plot surface as 3D plot. \n
           Plots raw (i.e. not interpolated) data with same number of plotted vertices as data values. \n
           Default behaviour: \n
                   - show figure on screen, do *not* export to PDF.
                   - show figure until closed manually (click in GUI), even when 'export_to_pdf == True'.
                   - when exporting to PDF: file name is SURFACE-NAME_VALUATION-DATETIME.pdf.
                   - attempts to populate all axes- and colorbar-annotations etc from class attributes.
                   - reduce number of labels on the x-axis (=maturity) for better readability. (_X_LEAP_FROG controls that)
                   - linear spacing on axes, i.e. same distance between 3M and 6M vs 15Y and 20Y, due to gridding of data-values vs array-index. May want to change that.

           TODO: Move away from asset-specific notation, i.e. 'maturity' and 'tenor'. Use baseclass which provides these labels via a 'name' attribute.
        """

        # TODO: Linear spacing, same space between 3M and 6M vs 15Y and 20Y.

        # control number of labels on x-axis (= maturity)
        _X_LEAP_FROG = 3  # just put every 3rd label on the y-axis (because of lack of space).
                          # tools, e.g. IndexLocator, from 'matplotlib.ticker' do not work because ax.xticks() overrides them or work on indices, only.

        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D
        from matplotlib import cm
        from core.utils.sequences import emap

        # create plotting canvas, a "figure" in 3D.
        fig = plt.figure()
        ax = fig.gca(projection='3d')

        # mapping tenor-strings and datetime.dates to integers (for axis tick labelling)
        label_from_idx = lambda x: dict(zip(range(len(x)), x))
        maturities_from_idx = label_from_idx(self.maturities)
        tenors_from_idx = label_from_idx(self.tenors)

        # plotting
        # 'data' has dimensions (len(maturities), len(tenors)).
        x = maturities_from_idx.keys()
        y = tenors_from_idx.keys()
        x,y = np.meshgrid(x,y, indexing='ij')  # 'ij' is matrix indexing with (0,0) denoting top-left corner.
        surf = ax.plot_surface(x,y,self.data, cmap=cm.coolwarm, rstride=1, cstride=1, linewidth=0) # in matplotlib version >= 2.0.0, the new arguments 'rcount' & 'ccount' supersede 'rstride' & 'cstride'.
        # plt.axis('tight')

        # annotating figure, axes, adding colorbar
        date_str = self.datestr()
        #vdate_title = '\n Valuation date: ' + date_str if self.valuation_datetime is not None else ''  # omits "valuation date" in title altogether if it is empty (None). Saves printing area.
        vdate_title = '\n Valuation date: ' + date_str
        title_str = self.identifier.get('name')
        plt.title(title_str +  vdate_title, fontsize='medium')

        plt.xlabel('Maturity', labelpad=45, weight='heavy') # 'labelpad' controls distance from axis
        plt.ylabel('Tenor', weight='heavy')
        # colorbar
        cbarn = plt.colorbar(surf, shrink=0.5)
        cbarn.set_label(self.units.name.capitalize())
        # cbarn.set_clim(vmin=0)   # Enabling additional colorbar properties.

        # axis ticks configuration
        _fewer_maturity_keys = maturities_from_idx.keys()[::_X_LEAP_FROG]
        plt.xticks(_fewer_maturity_keys, (maturities_from_idx.get(i) for i in _fewer_maturity_keys),)
        fig.autofmt_xdate()  # rotate and align axes-labels which consist of dates. Note, introduces some absolute positions that might not scale.
        plt.yticks(tenors_from_idx.keys(), tenors_from_idx.values(), rotation="horizontal")

        # export to PDF
        if export_to_pdf:
            plt.savefig(self.identifier.get('name') + '_' + date_str.replace(' ','_').replace(':','-') + '.pdf', format='pdf')#, bbox_inches="tight")

        # show figure on screen. Note: If "plt.show()" is called before "plt.savefig()" print-output will be blank.
        plt.show()  # no-argument version will pause execution of script until figure is closed manually (click in GUI).
        # Use: "block=False" (not very useful: closes figure immediately) to change behaviour.
        # plt.close(fig)


if __name__ == '__main__':
    from orca.types._constants import InfinityMarketDataInstance
    from orca.types._market_data_name  import InfinityMarketDataName
    from orca.utilities import timestamp
    import datetime as dt

    import pickle as pc


    # Commented stuff works

    # s1=Surface(np.ones(shape=(3,3)), identifier={'name':'S1'})
    # s2=Surface(2*np.ones(shape=(3,3)), identifier={'name':'S2'})
    #
    # s3 = (s1 + 2) * s2
    # print s3
    #
    # s31 = (s2 - 4) * s1
    # print s31
    #
    #
    # s4 = s1 * (s2 - s1)
    # print s4
    #
    # s41 = (4 - s1) * s1
    # print s41

#    ----------------------
#    Surface.make_one()
#    f = open('make_one.pickle','rb')
#    s=pc.load(f)
#    print(s)
#    f.close()
#    --------------


#    --------------
    orca_wrapper()
#   ---------------

#    surface = Surface.from_damds(Currency.GBP, dt.date(2017, 8, 18))
#    surface.plot()

#   ---------------
#    surf = Surface(data=np.random.uniform(0, 1, size=(40, 40)), valuation_datetime=dt.date(2017, 8, 18), db_datetime=None, units=Units.NONE,
#                   maturities=range(40), tenors=range(40), tenor_interpolation=None, maturity_interpolation=None,
#                   identifier={'name': 'EUR.FREI.LAM', 'currency': 'EUR'})

#    surf1 = Surface(data=np.random.uniform(0, 1, size=(40, 40)), valuation_datetime=None, db_datetime=None, units=Units.NONE,
#               maturities=range(40), tenors=range(40), tenor_interpolation=None, maturity_interpolation=None,
#               identifier={'name': 'EUR.FREI.LAM', 'currency': 'EUR'})
#    print(str(surf1))
#    print(surf1.datestr())
#    surf1.plot()
#    (surf-surf1).plot()
#------------------