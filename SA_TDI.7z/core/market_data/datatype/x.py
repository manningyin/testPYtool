""" Multi-purpose X-Coordinate. """

from enum import Enum


class Units(Enum):

    SECONDS = 1
    MINUTES = 2
    HOURS   = 3
    DAYS    = 4
    MONTHS  = 5
    YEARS   = 6
    PERCENT = 7
    BASISPOINTS = 8
    PERCENT_div_by_100 = 9
    NA      = -1
    NONE    = -2


class Representation(Enum):

    STRING = 1
    DATE   = 2
    TIME   = 3
    DATETIME = 4
    NA       = -1


class InterpolationType(Enum):

    FLAT = 1
    LINEAR = 2
    NONE   = -1   # not interpolated


class X:

    def __init__(self, name, units, values, interpolation_type, representation, description, association):
        self.name = name
        self.units = units
        self.values = values
      #  self.interpolation_type = interpolation_type
        self.representation = representation
        self.description = description
        self.association = association

