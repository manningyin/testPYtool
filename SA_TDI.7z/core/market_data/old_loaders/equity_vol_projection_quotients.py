"""
Imports equity vol projection quotients.

Imports equity vol projection quotients based on a list of vol_id's and a minimum and a maximum date for the period (both days will be included).
It returns equity vol projection quotient data as a list of dictionarys.
The current version of the module only support extract from database infop (mars), but could be extended to other databases with same data structure.

Warning:


Notes:
    Author: G35294

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       24oct2017   G35294      Initial creation
    ======= =========   =========   ========================================================================================
"""

import core.connection.database_extract as database_extract


def extract(vol_id,
            min_date,
            max_date,            
            source_db = 'INFOP'
            ):
    """
    This function will return the Equity vol projection quotients (relative shifts) based on the vol_id and dates


    Args:
        vol_id                  (list of int):          The list of mars equity vol_id's (the specific vol's, not the projection vol_id's!)
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set        
        source_db               (str):                  The database to extract from

    Returns:
        (list of dicts):   Extracted equity vol projection quotients in tabular like list of dictionaries

    Raises:


    Example:
        The module is called (from python) like this::
            
            from core.market_data import equity_vol_projection_quotients
            
            equity_vol_1day_shifts = equity_vol_projection_quotients.extract(vol_id       = [1,2,3],
                                                          min_date        = datetime.date(2017, 2, 13),
                                                          max_date        = datetime.date(2017, 2, 20)
                                                          )

    Warning:
        

    Notes:
        Author: Leon Hartmann (G35294)
    """
        
    chunksize=900
    result=[]


    for i in range(0,len(vol_id),chunksize):
        
        select_query = mars_extract_string(vol_id           = vol_id[i:i+chunksize],
                                           min_date         = min_date,
                                           max_date         = max_date
                                           )

        
        return database_extract.select_from_query(database   = source_db,
                                                  query      = select_query
                                                  )


        
import core.utils.date_helper as dateutils

def mars_extract_string(vol_id,
                        min_date,
                        max_date
                        ):
    """
    Creates sql extract string used for retrieving equity vol projection quotients from MARS

    Args:
        vol_id                  (list of int):          List of the equity vol_id'sThe list of mars equity vol_id's (the specific vol's, not the projection vol_id's!)
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set

    Returns:
        (str):   Sql extract string

    Raises:

    Example:                                                 )

    Warning:

    Notes:
        Author: 
    """


    min_sql_date = dateutils.oracle_to_date(min_date)
    max_sql_date = dateutils.oracle_to_date(max_date)

    date_where_clause = 'b.end_date between ' + min_sql_date + ' and '  + max_sql_date


    if type(vol_id) is list:
        equity_where_clause = 'rm_vgm.vol_id in (' + (", ".join(str(x) for x in vol_id)) + ')'
    else:
        equity_where_clause = "rm_vgm.vol_id = '" + str(vol_id) + "'"




    select_query = '''with choose_proj as (
                        select rm_vgm.vol_id, v.name, max(proj.projection_vol_id) proj_vol_id  -- some vols will have more than one mapping during the period, we therefore need to choose one. Generic proxies have low vol_id's, we therefore choose high vol_id.
                        from  marsp.timeinterval a1,
                              marsp.timeinterval b1,
                              marsp.rm_vol_grp_mapping    rm_vgm,
                              marsp.rm_vol_grp            rm_volgrp,
                              marsp.projection_vol_mapping   proj,
                              marsp.vol v
                        where  a1.end_date = ''' + max_sql_date + '''
                        and    a1.timeinterval_id - 255 = b1.timeinterval_id   -- must cover the period of month-ends used for nmrf ses estimate 
                        and    rm_vgm.eod_date >= b1.end_date
                        and    rm_vgm.rm_vol_supergrp_id = 5
                        and    rm_vgm.rm_vol_grp_id = rm_volgrp.rm_vol_grp_id
                        and    proj.eod_date = rm_vgm.eod_date
                        and    proj.projection_id = rm_volgrp.projection_id
                        and    rm_vgm.vol_id = proj.vol_id
                        and    ''' + equity_where_clause + '''    
                        and    rm_vgm.vol_id = v.vol_id
                        group by rm_vgm.vol_id, v.name
                        )
                        select c.vol_id, c.name, a.timeinterval_id sc_id, b.end_date, a.quotient
                        from marsp.vol_quotient a
                        , marsp.timeinterval b
                        , choose_proj d
                        , marsp.vol c
                        where
                           ''' + date_where_clause + '''
                        and a.timeinterval_id = b.timeinterval_id
                        and d.proj_vol_id = a.vol_id    
                        and d.vol_id = c.vol_id
                        order by c.vol_id, a.timeinterval_id
                    '''
            
    return select_query

    


# ======== Standard Code to add code-lib to PYTHONPATH ========
if __name__ == '__main__':
    import os, sys
    sys.path = list((x for x in sys.path if x.find('code-lib') == -1))  # Remove existing code-lib paths
    sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])    # Add current code-lib path
    
    import datetime
# =============================================================


    import core.utils.date_helper as dateutils
    
    equity_vol_1day_shifts = extract([750], datetime.date(2007, 01, 01), datetime.date(2017, 10, 25))
    
    print(equity_vol_1day_shifts)
    
