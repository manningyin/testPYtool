"""
Imports equity vol large cap booleans 

Imports equity vol large cap booleans based on a list of vol_id's (returns Y if underlying is a large cap according to FRTB criteria, N if not).
It returns equity vol large cap booleans data as a list of dictionaries.
The current version of the module only support extract from database infop (mars), but could be extended to other databases with same data structure.

Warning:

Notes:
    Author: g35294

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01nov2017   G35294      Initial creation
    ======= =========   =========   ========================================================================================
"""


import core.connection.database_extract as database_extract


def extract(vol_id, source_db='INFOP'):
    '''
    This function will return equity vol large cap booleans based on a list of vol_id's.

    Args:
        vol_id                  (list of int):          The list of mars vol_id's       
        source_db               (str):                  The database to extract from       

    Returns:
        (list of dicts):   Extracted equity vol large cap booleans in tabular like list of dictionaries

    Example:
        The module is called (from python) like this::
            
            from core.market_data import equity_vol_large_cap
            equity_large_caps = equity_vol_large_cap.extract(vol_id = [1,2,3] )

    Notes:
        Author: Leon Hartmann (G35294)
    '''
    chunksize=900
    result=[]

    for i in range(0,len(vol_id),chunksize):
        
        select_query = mars_extract_string(vol_id = vol_id[i:i+chunksize] )
        
        result.extend(database_extract.select_from_query(database   = source_db,
                                                         query      = select_query
                                                          ))
    return result


def mars_extract_string(vol_id):
    if type(vol_id) is list:
        equity_where_clause = 'c.vol_id in (' + (", ".join(str(x) for x in vol_id)) + ')'
    else:
        equity_where_clause = "c.vol_id = '" + str(vol_id) + "'"

    combined_where_clause = ' and ' + equity_where_clause

    select_query = (''' select c.vol_id, nvl2(a.effect_id,'Y','N') large_cap_b
                        from marsp.lmc_equity_h a
                        , marsp.equity b
                        , marsp.vol c
                        where
                            a.effect_id (+) = b.effect_id
                        and b.effect_id (+) = c.undl_effect_id
                    ''' + combined_where_clause + '''
                        order by c.vol_id
                    ''')

    return select_query
