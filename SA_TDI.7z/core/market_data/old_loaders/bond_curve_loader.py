"""
This module include a few extract and transformation functions to load bond curve from different data sources

In general, two types of functions have been implemented:
1) load_curve_from_xxx, extract function to get data from the database
2) make_curve_from_xxx, transformation function that transform the curves to qt functions...


Warning:
    Please never call this function directly from your application/module, all data extracting should be performed through loader object.

Notes:
    Author: g48454

"""
import json
import math
from datetime import datetime

import pandas as pd
import quantum as qt
import requests
from pandas.tseries.offsets import BDay

from core.connection import credentials, database_extract
from core.connection import database_extract
from core.utils.RawTimeSeries import RawTimeSeries


def make_curve_from_webservice(curvename):
    # ===================================================================================
    # The code here make a data cache which contain all curves
    # ===================================================================================
    data = load_curve_from_webservice(curvename)
    datacache = RawTimeSeries(name='mortgagebondcurve')
    for item in data['Result'][0]['Data']:
        base_date = item['DataSourceTimestamp']
        base_datetime = datetime.strptime(base_date, '%Y-%m-%d')
        temp_date_list = []
        temp_rate_list = []
        for timepoint in item['TimeSeries']:
            temp_date_list.append(qt.addTenor(base_datetime, timepoint + 'Y'))
            temp_rate_list.append(item['TimeSeries'][timepoint])
            # add a short end rate by linear extrapolation (Tactical solution before market data service is ready)
        temp_date_list.append(qt.addTenor(base_datetime, '1D'))
        interpolated_rate = item['TimeSeries']['1'] - (item['TimeSeries']['2'] - item['TimeSeries']['1'])
        temp_rate_list.append(interpolated_rate)
        tempCurve = qt.CurveCatrom.make(temp_date_list, temp_rate_list)
        datacache.addItem(tempCurve, base_datetime)
    return datacache


def make_curve_from_xls(curvename):
    # ===================================================================================
    # The code here make a data cahce which contain all curves from xls worksheet
    # ===================================================================================
    df = load_curve_from_xls(curvename)
    rowlist = list(df.columns.values)
    N = len(df.columns)
    datacache = RawTimeSeries(name='mortgagebondcurve')
    for index, row in df.iterrows():
        base_date = row['Date']
        base_datetime = base_date.to_datetime()
        temp_date_list = []
        temp_rate_list = []
        # ===================================================================================
        # load columns by step 2, the code assume that the column name can directly be used by qToolkit :(
        # ===================================================================================
        for item in rowlist[1:N:2]:
            temp_date_list.append(qt.addTenor(base_datetime, item))
            temp_rate_list.append(row[item])
        # ===================================================================================
        # make qt curve
        # ===================================================================================
        try:
            tempCurve = qt.CurveCatrom.make(temp_date_list, temp_rate_list)
        except Exception as e:
            print(e)
        # ===================================================================================
        # add the curve to data cache
        # ===================================================================================
        datacache.addItem(tempCurve, base_datetime)
    return datacache


def load_curve_from_webservice(curvename):
    # load the curve from REST service and transfer to json format
    auth = credentials.get_HttpNtlmAuth()
    webservice = 'http://mds.oneadr.net/v1/marketdata/datacurves/mortgagebonds'
    service_arg = webservice + '?CurveIds=' + curvename + '&format=json&All=True'
    print('--- loading the curve from below web service: ' + service_arg)
    print('... it will take approx 20 min...')
    response = requests.get(url=service_arg, auth=auth)
    data = json.loads(response.content)
    return data


def extract_eu_gov_curve_from_marsp(curvename, startdate, enddate):
    # get the personal connection string from MARSP.
    date0_str = startdate.strftime('%Y%m%d')
    date1_str = enddate.strftime('%Y%m%d')

    # parse the sql
    SQL = ''' select A.EOD_DATE as info_date , A.TERM_ID as time,  A.INTEREST_PCT/100 as rate
            from MARSP.HS_INTEREST_RATE a, MARSP.INTEREST b, MARSP.LADDER_TERM c
            where A.EOD_DATE between
            to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
            and A.INTEREST_ID = B.INTEREST_ID
            and A.INTEREST_ID = '%(curvename)s'
            and B.INTEREST_MARKET_ID = 'GOVM'
            and A.TERM_ID = C.TERM_ID
            and C.LADDER_ID = 0
            order by C.TERM_NO

        ''' % locals()
    #
    return database_extract.select_from_query(database='INFOP_G', query=SQL)


def load_curve_from_xls(curvename):
    # load the curve from manually downloaded service
    xls_path = get_xls_file_location(curvename)
    return pd.read_excel(open(xls_path, 'rb'), sheetname='data')


def get_xls_file_location(curvename):
    xls_folder_path = '//dcd00cb-evs02/ABD/Market Risk Models & Measures/20 Data/FRTB Credit/TestingWork/simpleBondProtoType/mort_curve_manual_download/'
    return xls_folder_path + curvename + '.xlsx'


def extract_curve_from_marsp(curvename,startdate,enddate):
    '''
    The code below load the table from marsp database, now the table direct to the bond curve table created by Johan in market data management team

    Warning:
        before run this code, ask Johan to make sure you have access to his table...

    Example:
        A testing script can be found below
        import core.market_data.bond_curve_loader as bond_curve
        import datetime
        curvename='DKKMTGNYKSOFTBLT'
        d1=datetime.datetime(2016,1,1)
        d2=datetime.datetime(2016,3,1)
        data=bond_curve.extract_curve_from_marsp(curvename,d1,d2)

    Notes:
        Author: g48454
    '''

    # get the personal connection string from MARSP.
    date0_str = startdate.strftime('%Y%m%d')
    date1_str = enddate.strftime('%Y%m%d')

    # parse the sql
    SQL= ''' select a.info_date as info_date, a.Tenor as time, a.data_point as rate, a.Time_Convention
    from G47193.ANALYTICS_CURVES a
    where
    a.curve = (select curve_id from G47193.BOND_CURVE_CONTEXT
    where
    ROWNUM <=1
    and
    short_name like
    '%(curvename)s' )
    and a.info_date
    between
    to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
    order by info_date,time
    ''' % locals()

    # run the sql
    return database_extract.select_from_query(database='INFOP_G',query=SQL)


def load_curve_from_various_db(curvename, startdate, enddate, type="bond_curve"):
    '''
    make the qt curve into data cache, now the table direct to the bond curve table created by Johan in market data management team

    Returns:
        a data cache that contain all qt curves

    Example:
        Function can be used like this::

            import core.market_data.bond_curve_loader as bond_curve
            import datetime
            curvename='DKKMTGNYKSOFTBLT'
            d1=datetime.datetime(2016,1,1)
            d2=datetime.datetime(2016,3,1)
            curve_data=bond_curve.load_curve_from_various_db(curvename,d1,d2)
            print(curve_data.cacheDate)
                                                  )
    Warning:
        before run this code, ask Johan to make sure you have access to his table...

    Notes:
        Author: g48454
    '''


    # ===================================================================================
    # Extract the bond curve
    # ===================================================================================
    if type == "bond_curve":
        bond_curve=extract_curve_from_marsp(curvename,startdate,enddate)
    elif type == "bond_curve_damds":
        bond_curve = extract_curve_from_damds(curvename, startdate, enddate)
    elif type == "eu_gov":
        bond_curve = extract_eu_gov_curve_from_marsp(curvename,startdate,enddate)
    else:
        raise  Exception("the type is not defined")
    # ===================================================================================
    # create an empty cache
    # ===================================================================================
    tempDataCache=RawTimeSeries(name='bondcurve_' + curvename)

    # ===================================================================================
    # convert the date range
    # ===================================================================================
    date_range=pd.date_range(startdate, enddate, freq=BDay(1))
    loadDateTimeRangeList = [datetime.combine(currt, datetime.min.time())
                             for currt in date_range]

    # ===================================================================================
    # make qt curve day by day and return
    # if not succeed in one day, the curve will not be added to the data cache
    # ===================================================================================
    for currDateTime in loadDateTimeRangeList:
        try:
            if type in ['bond_curve','bond_curve_damds']:
                qt_curve=make_qt_curve_from_db(bond_curve,currDateTime)
            elif type =="eu_gov":
                qt_curve=make_qt_curve_from_db_eu_gov(bond_curve,currDateTime)
            else:
                raise Exception("the type is not defined")
            tempDataCache.addItem(qt_curve,currDateTime)
        except:
            continue

    return tempDataCache


def make_qt_curve_from_db_eu_gov(bond_curve,currDateTime):
    # make qt curve for eu govt bond
    tempRateList = []  # the list of rates
    tempDateList = []  # the list of time
    for x in range(0, len(bond_curve)):
        if bond_curve[x].get('info_date') == currDateTime:
            finalRate = bond_curve[x].get('rate')
            tempRateList.append(finalRate)
            tempTenorStr = bond_curve[x].get('time')
            tempDate = qt.addTenor(date=currDateTime, tenor=tempTenorStr)
            tempDateList.append(tempDate)

        else:
            continue

    try:
        qt_bond_curve = qt.CurveCatrom.make(tempDateList, tempRateList)
        return qt_bond_curve
    except:
        raise Exception


def make_qt_curve_from_db(bond_curve,currDateTime):
    # make qt curve for normal bond curve
    tempRateList = []  # the list of rates
    tempDateList = []  # the list of time
    for x in range(0, len(bond_curve)):
        if bond_curve[x].get('info_date') == currDateTime:
            tempRate = bond_curve[x].get('rate')
            tempT = bond_curve[x].get('time')
            if tempT>0:
                finalRate = math.log(math.pow(1 + tempRate, -tempT)) / (-float(tempT))
                tempTenorStr = yearfrac_to_qt_tenor(tempT)
                tempDate = qt.addTenor(date=currDateTime, tenor=tempTenorStr)
                tempDateList.append(tempDate)
                tempRateList.append(finalRate)
        else:
            continue
    try:
        qt_bond_curve = qt.CurveCatrom.make(tempDateList, tempRateList)
        return qt_bond_curve
    except:
        raise Exception


def yearfrac_to_qt_tenor(argument):
    try:
        if argument < 0.083:
            # if within 1m, return xD
            return str(int(round(argument * 365))) + 'D'
        elif argument < 1:
            # if within 1m, return xM
            return str(int(round(argument * 12))) + 'M'
        elif argument >= 1:
            i, d = divmod(argument, 1)
            if d > 0.0001:
                # if larger than 1Y but have decimal part, return xM
                # example 1.5 -> 18M
                return str(int(round(argument * 12))) + 'M'
            if d == 0:
                return str(int(round(argument))) + 'Y'
        else:
            return str(int(round(argument))) + 'Y'
    except:
        print('--error in convertion')


if __name__ == '__main__':
    d1 = load_curve_from_various_db(curvename="DKKGOV",
                                    startdate=datetime(2017, 3, 2),
                                    enddate=datetime(2017, 3, 10),
                                    type="bond_curve_damds")
    print(d1.cacheDate)


def extract_curve_from_damds(curve_name, start_date, end_date):
    """
    The code below load the table from marsp database, now the table direct to the bond curve table created by Johan in market data management team

    Warning:
        before run this code, ask Johan to make sure you have access to his table...

    Example:
        A testing script can be found below
        import core.market_data.bond_curve_loader as bond_curve
        import datetime
        curve_name = 'DKKMTGNYKSOFTBLT'
        d1 = datetime.datetime(2016,1,1)
        d2 = datetime.datetime(2016,3,1)
        data = bond_curve.extract_curve_from_marsp(curve_name,d1,d2)

    Notes:
        Author: g48454
    """

    # get the personal connection string from MARSP.
    date0_str = start_date.strftime('%Y%m%d')
    date1_str = end_date.strftime('%Y%m%d')

    # parse the sql
    SQL = '''select a.info_date as info_date, a.Tenor as time, a.data_point as rate, a.Time_Convention
        from GMCCR_TIMESERIES.ANALYTICS_CURVES a
        where
        a.curve = (select curve_id from GMCCR_TIMESERIES.BOND_CURVE_CONTEXT
        where
        ROWNUM <=1
        and
        short_name like
        '%(curve_name)s' )
        and a.info_date
        between
        to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
        order by info_date,time
        ''' % locals()

    # run the sql
    return database_extract.select_from_query(database='DAMDS', query=SQL)