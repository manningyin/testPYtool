# -*- coding: utf-8 -*-
'''
Module to extract interest rates

The module aims to handle everything that has something to do with extracting interest rates

Warning:

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       06JAN2017   g50444      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''

import core.connection.database_extract as database_extract
import core.connection.database_connect as database_connect
import pandas as pd

def extract(currency,
            eod_date,
            interest_type = 'SWAP',
            source        = 'MARS',
            source_envir  = 'PROD',
            info          = 0
            ):
    '''
    This function will return the FX Rate based on the currency and date


    Args:
        currency                (list of str or str):   The currencies you want to
        eod_date                (datetime.date):        EoD Date of list of eod_dates
        info                    (int):                  Level of information printed. The higher, the more information is printed

    Returns:
        (list of dicts):   Extracted interest rates in tabular like list of dictionaries

    Raises:


    Example:
        The module is called (from python) like this::
        
            import datetime
            interest_rates = extract(   currency        = ['DKK','EUR'],
                                        eod_date        = datetime.date(2017, 2, 13),
                                        interest_type   = 'FX',
                                        source          = 'MARS',
                                        source_envir    = 'PROD'
                                    )

    Warning:
        When inputting a list of dates in eod_date variable, the module will return all dates in the interval
        between the first- and last date (not only the dates specified.

    Notes:
        Author: g50444
    '''
    if source.upper() == 'MARS':

        if source_envir.upper() in ('PROD','PRODUCTION'):
            source_db = 'INFOP'
        elif source_envir.upper() in ('DEV','DEVELOPMENT'):
            source_db = 'INFOD'
        else:
            source_db = 'NA'

        select_query = mars_extract_string(currency         = currency,
                                           interest_type    = interest_type,
                                           eod_date         = eod_date,
                                           info             = info
                                           )


    if info > 0:
        print(select_query)
        print(source_db)

    return database_extract.select_from_query(info       = info,
                                              database   = source_db,
                                              query      = select_query
                                              )


import core.utils.date_helper as dateutils
import core.utils.string as string
def mars_extract_string(currency,
                        interest_type,
                        eod_date,
                        info        = 0
                        ):
    '''
    Creates sql extract string used for retrieving interest rates from MARS

    Args:
        currency                (list of str):  List of the currency codes
        interest_type           (str):          Matching the Interest_Market_ID in marsp.interest (SWAP, FX etc.)
        eod_date                (datetime):     End of Day date
        info                    (int):          OPTIONAL. Level of information printed. The higher, the more information is printed

    Returns:
        (str):   Sql extract string

    Raises:

    Example:                                                 )

    Warning:

    Notes:
        Author: g50444
    '''

    if type(eod_date) is list:
        # If eod_date input is a list, we assume the user wants all dates within a period
        # Therefore we determine the first and last date in the period
        min_date = min(eod_date)
        max_date = max(eod_date)

        min_sql_date = dateutils.oracle_to_date(min_date)
        max_sql_date = dateutils.oracle_to_date(max_date)

        date_where_clause = '(' + min_sql_date + ' < = ir.eod_date and ir.eod_date <= ' + max_sql_date + ')'
    else:
        date_where_clause = 'ir.eod_date = ' + dateutils.oracle_to_date(eod_date)

    if type(currency) is list:
        currency_where_clause = 'i.currency_id in (' + string.commasep_quoted(currency) + ')'
    else:
        currency_where_clause = "i.currency_id = '" + currency.upper() + "'"

    interest_type_where_clause = "i.interest_market_id = '" + interest_type.upper() +"'"

    combined_where_clause = date_where_clause + ' and ' + currency_where_clause + ' and ' + interest_type_where_clause
    if info>0:
        print('date_where_clause',date_where_clause)
        print('currency_where_clause', currency_where_clause)
        print('interest_type_where_clause', interest_type_where_clause)
        print('combined_where_clause', combined_where_clause)

    select_query = ('''
                        select ir.eod_date,
                          ir.interest_id,
                          i.name as interest_name,
                          i.currency_id as currency_id,
                          ir.term_id,
                          trm.term_360_days,
                          ir.interest_pct
                        from marsp.hs_interest_rate ir
                        inner join marsp.interest i
                        on ir.interest_id = i.interest_id
                        left join marsp.term trm
                        on ir.term_id = trm.term_id
                        where
                    '''
                        + combined_where_clause +
                    '''
                        order by ir.eod_date,ir.interest_id,trm.term_360_days
                    '''
                  )

    return select_query


# ===================================================================================
# get the ir curve from the FRTB_HS_INTEREST_RATE table
# ===================================================================================
def return_ir_curve_from_marsp(name,date):
    whereclause  = 'eod_date = ' + dateutils.oracle_to_date(date) + ' and interest_id = ' + name
    select_query = '''
            select term_id, interest_pct/100 as interest_pct from MARSP.FRTB_HS_INTEREST_RATE where
            ''' + whereclause

    dict_data = database_extract.select_from_query("INFOP", select_query)
    df = pd.DataFrame.from_dict(dict_data)
    return df


def return_ir_curve_from_damds(name,date):
    whereclause  = 'scenario_date = ' + dateutils.oracle_to_date(date) + " and curve_name = '"+ name + "'"
    select_query = '''
            select term_id, interest_pct/100 as interest_pct from GMCCR_TIMESERIES.FRTB_INTEREST_RATE where
            ''' + whereclause

    dict_data = database_extract.select_from_query("DAMDS", select_query)
    df = pd.DataFrame.from_dict(dict_data)
    return df






if __name__ == "__main__":
    import datetime
    a = extract(currency        = 'DKK',
            eod_date        = datetime.date(2017, 2, 13),
            interest_type   = 'SWAP',
            source          = 'MARS',
            source_envir    = 'PROD',
            info            = 1
            )

    print(return_ir_curve_from_damds(name = "SEK.DISC.LIBOR.CURVE" , date        = datetime.date(2017, 2, 13)))