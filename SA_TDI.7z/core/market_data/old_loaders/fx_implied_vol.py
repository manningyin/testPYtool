# -*- coding: utf-8 -*-
"""
Module for extracting FX Volatility from different Nordea systems

For now the purpose of this module is to have a tools for getting FX volatility data into python.

Warning:


Notes:
    Author: g46541

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       08Sep2017   G46541      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import core.utils.date_helper as dateutils
import core.utils.string_utils as string
import core.connection.database_extract as database_extract


def extract(currency_pair,
            eod_date,
            tenor         = 'ALL',
            smile         = 'ALL',
            source        = 'MARS',
            source_envir  = 'PROD',
            info          = 0
            ):

    """
    Extract function for FX Volatility

    This is the main function returning FX volatility data from different sources in Nordea.

    Args:
        currency_pair           (list of str or str):   The currency pairs you want to import like EURUSD
        eod_date                (datetime.date):        EoD Date of list of eod_dates
        tenor                   (list of str or str):   The list of Tenors you want, if ALL, the function returns every
                                                        tenor available for the given eod_date
        smile                   (list of str or str):   The list of smile quotes you want, if ALL, the function returns
                                                        every smile quote available for the given eod_date
        info                    (int):                  Level of information printed. The higher, the more information is printed
        source                  (str):                  The data base to use (MARS, CRD, etc)
        source_envir            (str):                  The data base environment (PROD, TEST)

    Returns:
        (list of dicts):   Extracted implied volatilities in tabular like list of dictionaries

    Example:
        The module is called (from python) like this::

            import datetime
            data_extract1 = extract(currency_pair = ['EUR/USD','USDJPY'],
                                    eod_date = [datetime.date(2016, 1, 1),datetime.date(2016, 1, 4)],
                                    tenor         = 'ALL',
                                    smile         = 'ALL',
                                    source        = 'MARS',
                                    source_envir  = 'PROD',
                                    info          = 0
                                    )
            data_extract2 = extract(currency_pair = ['EUR/USD','USDJPY'],
                                    eod_date = [datetime.date(2016, 1, 1),datetime.date(2016, 1, 4)],
                                    tenor         = 'ALL',
                                    smile         = 'ALL',
                                    source        = 'CRD',
                                    source_envir  = 'PROD',
                                    data_source   = 'REVAL',
                                    info          = 0
                                    )

    Warning:
        When inputting a list of dates in eod_date variable, the module will return all dates in the interval
        between the first- and last date (not only the dates specified.

    Notes:
        Author: g46541
    """

    if source.upper() == 'MARS':

        if source_envir.upper() in ('PROD', 'PRODUCTION'):
            source_db = 'INFOP'
        elif source_envir.upper() in ('DEV', 'DEVELOPMENT'):
            source_db = 'INFOD'
        else:
            source_db = 'NA'
        select_query = mars_extract_string(currency_pair=currency_pair, eod_date=eod_date, tenor=tenor, info=info)
    elif source.upper() == 'CRD':
        source_db = 'TWP'
        select_query = crd_extract_string(currency_pair=currency_pair, eod_date=eod_date, tenor=tenor, smile=smile, info=info)
    else:
        raise NotImplementedError
        
    return database_extract.select_from_query(info=info, database=source_db, query=select_query)


def mars_extract_string(currency_pair, eod_date, tenor='ALL', info=0):
    """
    Creates sql extract string used for retrieving FX Volatilities quotes from MARS

    Args:
        currency_pair           (list of str):  List of the currency pairs, MARS wants something like 'EUR/USD' if a
                                                string is 6 characters like 'EURUSD' it is turned into 'EUR/USD'
        tenor                   (list of str):  The tenor for which data should be extracted, if set to 'ALL' all tenors
                                                are extracted
        eod_date                (datetime/list):End of Day date, if list it we assume the user wants all dates within a
                                                period
        info                    (int):          OPTIONAL. Level of information printed. The higher, the more information
                                                is printed

    Returns:
        (str):   Sql extract string

    Example:
        The module is called (from python) like this::

            extract_string = mars_extract_string(currency_pair= ['EUR/USD','USDJPY'],
                        eod_date = [datetime.date(2016, 1, 1),datetime.date(2017, 1, 1)],
                        tenor = 'ALL',
                        info        = 0
                        )
             print(extract_string)

    Notes:
        Author: g46541
    """
    if type(eod_date) is list:
        # If eod_date input is a list, we assume the user wants all dates within a period
        # Therefore we determine the first and last date in the period
        min_date = min(eod_date)
        max_date = max(eod_date)

        min_sql_date = dateutils.oracle_to_date(min_date)
        max_sql_date = dateutils.oracle_to_date(max_date)

        date_where_clause = '(' + min_sql_date + ' < = vr.eod_date and vr.eod_date <= ' + max_sql_date + ')'
    else:
        date_where_clause = 'vr.eod_date = ' + dateutils.oracle_to_date(eod_date)

    if type(currency_pair) is list:
        for ccy in range(0,len(currency_pair)):
            if len(currency_pair[ccy]) == 6:
                currency_pair[ccy] = currency_pair[ccy][:3] + '/' + currency_pair[ccy][-3:]
        currency_where_clause = 'v.name in (' + string.commasep_quoted(currency_pair) + ')'
    else:
        currency_where_clause = "v.name = '" + currency_pair.upper() + "'"

    #making condition clause
    combined_where_clause = ' and ' + date_where_clause + ' and ' + currency_where_clause
    
    #adding tenor clause if necessary
    if type(tenor) is list:
        tenor_where_clause = 'vr.maturity_term_id in (' + string.commasep_quoted(tenor) + ')'
    elif tenor.upper() == 'ALL' :
        tenor_where_clause = ''
    else:
        tenor_where_clause = "vr.maturity_term_id = '" + tenor + "'"
    
    if  tenor_where_clause != '':
        combined_where_clause = combined_where_clause + ' and ' + tenor_where_clause

    select_query = (''' select
                          vr.eod_date
                          ,v.name
                          ,vr.maturity_term_id
                          ,vr.vol_pct
                        from      marsp.vol_rate vr
                        left join marsp.vol v on v.vol_id = vr.vol_id
                        where     v.vol_market_id = 'FX'
                    '''
                        + combined_where_clause +
                    '''
                        order by v.name,
                        vr.eod_date,
                        vr.maturity_no
                    '''
                  )

    return select_query

'''Function mars_extract_string has ended'''


def crd_extract_string(currency_pair,
                       eod_date,
                       tenor       = 'ALL',
                       smile       = 'ALL',
                       info        = 0
                       ):
    """
    Creates sql extract string used for retrieving interest rates from CRD



    Args:
        currency_pair           (str/list of str): Single currency pair or list of currency pairs. CRD wants something
                                                   like 'EURUSD' if a
                                                   string is 7 characters like 'EUR/USD' it is turned into 'EURUSD'
        tenor                   (str/list of str): The tenor for which data should be extracted, if set to 'ALL' all tenors
                                                   are extracted
        smile                   (str/list of str): Whether to include only ATM or also smile quotes, if set to 'ALL' both
                                                   atm and smile is included. If set to ATM, then atm quotes if SMILE then smile
                                                   is extracted.
        eod_date                (datetime/list fo datetime):     End of Day date
        info                    (int):          OPTIONAL. Level of information printed. The higher, the more information is printed

    Returns:
        (str):   Sql extract string

    Raises:

    Example:
        The module is called (from python) like this::

            extract_string = crd_extract_string(currency_pair= ['EUR/USD','USDJPY'],
                        eod_date = [datetime.date(2016, 1, 1),datetime.date(2017, 1, 1)],
                        tenor = '1M',
                        smile = 'ALL',
                        info        = 0
                        )
            print(extract_string)
            extract_string = crd_extract_string(currency_pair= ['EUR/USD','USDJPY'],
                                    eod_date = [datetime.date(2016, 1, 1),datetime.date(2017, 1, 1)],
                                    tenor = ['1M','2M'],
                                    smile = 'ATM',
                                    info        = 0
                                    )
            print(extract_string)

    Warning:

    Notes:
        Author: g46541
    """

    if type(eod_date) is list:
        # If eod_date input is a list, we assume the user wants all dates within a period
        # Therefore we determine the first and last date in the period
        min_date = min(eod_date)
        max_date = max(eod_date)

        min_sql_date = dateutils.oracle_to_date(min_date)
        max_sql_date = dateutils.oracle_to_date(max_date)

        date_where_clause = '(' + min_sql_date + ' < = b.report_date and b.report_date <= ' + max_sql_date + ')'
    else:
        date_where_clause = 'b.report_date = ' + dateutils.oracle_to_date(eod_date)

    if type(currency_pair) is list:
        for ccy in range(0,len(currency_pair)):
            if len(currency_pair[ccy]) == 7:
                currency_pair[ccy] = currency_pair[ccy][:3] + currency_pair[ccy][-3:]
        currency_where_clause = 'a.currency in (' + string.commasep_quoted(currency_pair) + ')'
    else:
        currency_where_clause = "a.currency = '" + currency_pair.upper() + "'"

    # making condition clause
    combined_where_clause = ' and ' + date_where_clause + ' and ' + currency_where_clause

    # adding tenor clause if necessary
    if type(tenor) is list:
        tenor_where_clause = 'a.ladderpoint in (' + string.commasep_quoted(tenor) + ')'
    elif tenor.upper() == 'ALL':
        tenor_where_clause = ''
    else:
        tenor_where_clause = "a.ladderpoint = '" + tenor + "'"

    if tenor_where_clause != '':
        combined_where_clause = combined_where_clause + ' and ' + tenor_where_clause

    # adding smile clause if necessary
    if smile.upper() == 'ALL':
        smile_where_clause = "a.instrument in ('FXOP','FXSML')"
    elif smile.upper() == 'ATM':
        smile_where_clause = "a.instrument in ('FXOP')"
    elif smile.upper() == 'SMILE':
        smile_where_clause = "a.instrument in ('FXSML')"
    else:
        smile_where_clause = ''

    if smile_where_clause != '':
        combined_where_clause = combined_where_clause + ' and ' + smile_where_clause
    
    select_query = (''' SELECT 
                                 b.report_date,
                                 a.currency,
                                 a.instrument,
                                 a.field_1,
                                 b.purpose,
                                 b.data_value_time,
                                 a.ladderpoint,
                                 b.data_value
                        FROM     prices.rr_securities  a,
                                 prices.rr_output_data b
                        WHERE    a.security_id = b.security_id
                        AND   a.market = 'FX'
                    '''
                        + combined_where_clause +
                    '''
                        AND   b.purpose in ('REVAL')
                        order by  a.currency
                                  ,b.report_date
                                  ,a.field_1
                                  ,a.ladderpoint
                    '''
                  )
    
    
    return select_query


'''Function crd_extract_string has ended'''