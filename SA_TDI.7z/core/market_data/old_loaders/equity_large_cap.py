"""
Imports equity large cap booleans

Imports equity large cap booleans based on a list of equity_id's.
It returns equity large cap booleans data as a list of dictionaries.
The current version of the module only support extract from database infop (mars), but could be extended to other databases with same data structure.

Warning:

Notes:
    Author: g35294

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       17oct2017   G35294      Initial creation
    ======= =========   =========   ========================================================================================
"""


import core.connection.database_extract as database_extract


def extract(equity_id,         
            source_db = 'INFOP'
            ):
    '''
    This function will return equity large cap booleans based on a list of equity_id's.


    Args:
        equity_id               (list of int):          The list of mars equity_id's       
        source_db               (str):                  The database to extract from       

    Returns:
        (list of dicts):   Extracted equity large cap booleans in tabular like list of dictionaries

    Raises:


    Example:
        The module is called (from python) like this::
            
            from core.market_data import equity_large_cap
            
            equity_large_caps = equity_large_cap.extract(equity_id = [1,2,3] )

    Warning:
        

    Notes:
        Author: Leon Hartmann (G35294)
    '''
       
    chunksize=900
    result=[]


    for i in range(0,len(equity_id),chunksize):
        
        select_query = mars_extract_string(equity_id = equity_id[i:i+chunksize] )
        
        result.extend(database_extract.select_from_query(database   = source_db,
                                                         query      = select_query
                                                          ))
        
    return result



def mars_extract_string(equity_id):
    '''
    Creates sql extract string used for retrieving equity equity large cap from MARS

    Args:
        equity_id               (list of int):          List of the equity_id's

    Returns:
        (str):   Sql extract string

    Raises:

    Example:                                                 )

    Warning:

    Notes:
        Author: 
    '''


    if type(equity_id) is list:
        equity_where_clause = 'b.equity_id in (' + (", ".join(str(x) for x in equity_id)) + ')'
    else:
        equity_where_clause = "b.equity_id = '" + str(equity_id) + "'"

    #making condition clause
    combined_where_clause = ' and ' + equity_where_clause


    select_query = (''' select b.equity_id, nvl2(a.effect_id,'Y','N') large_cap_b
                        from marsp.lmc_equity_h a
                        , marsp.equity b
                        where
                            a.effect_id (+) = b.effect_id
                        '''
                        + combined_where_clause +
                    '''
                        order by b.equity_id
                    '''
                  )

    return select_query
      



# ======== Standard Code to add code-lib to PYTHONPATH ========
if __name__ == '__main__':
    import os, sys
    sys.path = list((x for x in sys.path if x.find('code-lib') == -1))  # Remove existing code-lib paths
    sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])    # Add current code-lib path
# =============================================================
   

   
    df = extract([1,2,28,95,96])

    print(df)
