
"""
This module calculates overlapping equity vol quotients based on one-day quotients imported from Mars.

The tenday function will calculate tenday overlapping equity vol quotients.

Notes:
    Author: g35294

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       24oct2017   G35294      Initial creation
    ======= =========   =========   ========================================================================================
"""

import numpy as np
import pandas as pd
from tqdm import tqdm


def tenday(vol_id, start_date, end_date):
    
    '''
    This function will return the 10 day overlapping equity vol quotients (relative shifts) based on the vol_id and start/end dates.
    
    The input end_date will be the last day of the last 10-day quotient and the input start_date will be the first day of the first 10-day quotient.

    Args:
        vol_id                  (list of int):          The list of mars vol_id's
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set             

    Returns:
        (Pandas DataFrame): Format: equity_id, name, sc_id, shift

    Raises:

    Example:
        The module is called (from python) like this::
            
            from core.market_data import equity_quotient_calc
            tenday_timeserie_df = equity_quotient_calc.tenday( vol_id          = [1,2,3],
                                                               min_date        = datetime.date(2017, 2, 13),
                                                               max_date        = datetime.date(2017, 2, 20)
                                                               )

    Warning:
        
    Notes:
        Author: (G35294) Leon Hartmann
    '''    


    # Extract equity vol data based on vol_id's

    from core.market_data.old_loaders import equity_vol_quotients

    equity_vol_1day_shifts = equity_vol_quotients.extract(vol_id, start_date, end_date)
    df = pd.DataFrame(equity_vol_1day_shifts)
    
    df_path="equity_vol_quotients.csv" 

    print("Saving dataframe")
    df.to_csv(df_path)
    print("OK, Saved dataframe as "+df_path)        
    df = pd.read_csv(df_path)   #added for massive performance improvement!


    df["log_quotient"]=(df.quotient).apply(np.log)    #Equity vol quotients are measured as v(t)/v(t-1)
    df["log_q_sum"]=0
    df["tenday_log_quotient"]=0

    quotient_vector = pd.DataFrame(columns=["vol_id","tenday_quotient"])
    
    for eqt_vol_id in tqdm(vol_id):
        index = df.vol_id == eqt_vol_id        
        df.loc[index,"log_q_sum"] = df.loc[index,"log_quotient"].cumsum()
        v = df.loc[index,"log_q_sum"].as_matrix() 
        #print(v)
        if len(v)==0:
            print("No data for equity vol %x"%eqt_vol_id)
        else:
            n=10
            dv = v[n:]-v[:-n]
            w = np.concatenate((np.zeros(n),dv))
            w[n-1] = v[n-1]
            df.loc[index,"tenday_log_quotient"] = w
            df.loc[index,"tenday_quotient"] = np.exp(w)-1

            quotient_vector = quotient_vector.append(df.loc[index,("vol_id","tenday_quotient")])
                        
    return quotient_vector
      

# ======== Standard Code to add code-lib to PYTHONPATH ========
if __name__ == '__main__':
    import os, sys
    sys.path = list((x for x in sys.path if x.find('code-lib') == -1))  # Remove existing code-lib paths
    sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])    # Add current code-lib path
# =============================================================
   

    from core.utils import date_helper
    
    volIDs = [1387]
    
    result = tenday(volIDs, date_helper.to_datetime('2007-01-01'), date_helper.to_datetime('2017-10-24'))
    result.to_csv('vol_result_test.csv')
    print(result)
