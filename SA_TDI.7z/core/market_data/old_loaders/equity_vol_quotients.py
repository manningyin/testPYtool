"""
Imports equity vol quotients.

Imports equity vol quotients based on a list of vol_id's and a minimum and a maximum date for the period (both days will be included). 
It returns equity vol quotient data as a list of dictionarys.
The current version of the module only support extract from database infop (mars), but could be extended to other databases with same data structure.

Warning:


Notes:
    Author: G35294

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       24oct2017   G35294      Initial creation
    ======= =========   =========   ========================================================================================
"""

import core.connection.database_extract as database_extract


def extract(vol_id,
            min_date,
            max_date,            
            source_db = 'INFOP'
            ):
    '''
    This function will return the Equity quotients (relative shifts) based on the equity_id and dates


    Args:
        vol_id                  (list of int):          The list of mars equity vol_id's
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set        
        source_db               (str):                  The database to extract from

    Returns:
        (list of dicts):   Extracted equity vol quotients in tabular like list of dictionaries

    Raises:


    Example:
        The module is called (from python) like this::
            
            from core.market_data import equity_vol_quotients
            
            equity_vol_1day_shifts = equity_vol_quotients.extract(vol_id       = [1,2,3],
                                                          min_date        = datetime.date(2017, 2, 13),
                                                          max_date        = datetime.date(2017, 2, 20)
                                                          )

    Warning:
        

    Notes:
        Author: Leon Hartmann (G35294)
    '''
        
    chunksize=900
    result=[]


    for i in range(0,len(vol_id),chunksize):
        
        select_query = mars_extract_string(vol_id           = vol_id[i:i+chunksize],
                                           min_date         = min_date,
                                           max_date         = max_date
                                           )

        
        return database_extract.select_from_query(database   = source_db,
                                                  query      = select_query
                                                  )
'''Function extract has ended'''

        
import core.utils.date_helper as dateutils

def mars_extract_string(vol_id,
                        min_date,
                        max_date
                        ):
    '''
    Creates sql extract string used for retrieving equity quotients from MARS

    Args:
        vol_id                  (list of int):          List of the equity vol_id's
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set

    Returns:
        (str):   Sql extract string

    Raises:

    Example:                                                 )

    Warning:

    Notes:
        Author: 
    '''


    min_sql_date = dateutils.oracle_to_date(min_date)
    max_sql_date = dateutils.oracle_to_date(max_date)

    date_where_clause = 'b.end_date between ' + min_sql_date + ' and '  + max_sql_date


    if type(vol_id) is list:
        equity_where_clause = 'c.vol_id in (' + (", ".join(str(x) for x in vol_id)) + ')'
    else:
        equity_where_clause = "c.vol_id = '" + str(vol_id) + "'"

    #making condition clause
    combined_where_clause = date_where_clause + ' and ' + equity_where_clause



    select_query = (''' select c.vol_id, c.name, a.timeinterval_id sc_id, b.end_date, a.quotient
                    from marsp.vol_quotient a
                    , marsp.timeinterval b
                    , marsp.vol c
                    where
                    '''
                        + combined_where_clause +
                    '''
                    and c.vol_id = a.vol_id
                    and a.timeinterval_id = b.timeinterval_id
                    order by c.vol_id, a.timeinterval_id
                    '''
                  )

    return select_query




# ======== Standard Code to add code-lib to PYTHONPATH ========
if __name__ == '__main__':
    import os, sys
    sys.path = list((x for x in sys.path if x.find('code-lib') == -1))  # Remove existing code-lib paths
    sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])    # Add current code-lib path
    
    import datetime
# =============================================================


    import core.utils.date_helper as dateutils
    
    equity_vol_1day_shifts = extract([1387], datetime.date(2007, 2, 13), datetime.date(2017, 2, 20))
    
    print(equity_vol_1day_shifts)
