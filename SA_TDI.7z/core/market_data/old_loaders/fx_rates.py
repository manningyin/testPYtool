"""
Module to extract FX rates

The module aims to handle everything that has something to do with extracting FX market data

Warning:

    Please try not call this extract function directly in your application ,instead using loader functions.
    For example, FxSpotLoader which you can find in core.market_data.market_data_loader.py

Notes:
    Author: g50444

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       20OCT2016   g50444      Initial creation
    2       30Nov2016   g48454      Make it work for single day and single currency only
    2       15dec2016   g48454      vector
    ======= =========   =========   ========================================================================================
"""
from core.connection import database_extract
from core.utils import date_helper
from core.utils import string


def extract(currency, eod_date, source='MARS', source_envir='PROD'):
    """
    This function will return the FX Rate based on the currency and date

    Args:
        info                    int             Level of information printed. The higher, the more information is printed
        currency                str             The currencies you want to 
        eod_date                datetime        EoD Date

    Returns:
        fx price               double    FX rate

    Notes:
        Author: g50444
    """
    if source.upper() == 'MARS':
        if source_envir.upper() in ('PROD', 'PRODUCTION'):
            source_db = 'INFOP'
        elif source_envir.upper() in ('DEV', 'DEVELOPMENT'):
            source_db = 'INFOD'
        else:
            source_db = 'NA'

        select_query = mars_extract_string(currency=currency, eod_date=eod_date)
    else:
        raise NotImplementedError

    return database_extract.select_from_query(database=source_db, query=select_query)


def mars_extract_string(currency, eod_date):
    """
    Creates sql extract string used for retrieving FX spot prices from MARS

    Args:
        currency                (list of str)   List of the currency codes
        eod_date                (datetime)      End of Day date

    Returns:
        (str):   Sql extract string

    Notes:
        Author: g50444
    """
    if type(eod_date) is list:
        # If eod_date input is a list, we assume the user wants all dates within a period
        # Therefore we determine the first and last date in the period
        min_date = min(eod_date)
        max_date = max(eod_date)

        min_sql_date = date_helper.oracle_to_date(min_date)
        max_sql_date = date_helper.oracle_to_date(max_date)

        date_where_clause = '(' + min_sql_date + ' < = eod_date and eod_date <= ' + max_sql_date + ')'
    else:
        date_where_clause = 'eod_date = ' + date_helper.oracle_to_date(eod_date)

    if type(currency) is list:
        currency_where_clause = 'currency_id in (' + string.commasep_quoted(currency) + ')'
    else:
        currency_where_clause = "currency_id = '" + currency + "'"

    combined_where_clause = date_where_clause + ' and ' + currency_where_clause

    select_query = """select eod_date,currency_id as cur ,(price/100) as price
                      from marsp.currency_price
                      where %s""" % combined_where_clause

    return select_query
