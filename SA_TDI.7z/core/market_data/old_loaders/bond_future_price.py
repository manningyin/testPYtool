import core.connection.database_extract as external
from datetime import datetime
import pandas as pd
import requests
import core.connection.credentials as credential
import json


def extract_bond_future_price_from_mds_service(su_key,asofdate, auth):
    price_service = 'http://mds.oneadr.net/v1/marketdata/prices/reval'
    datestr = datetime.strftime(asofdate, '%Y-%m-%d')
    service_arg = price_service + '?SuKeys=' + su_key + '&TradeDate=' + datestr + '&format=json'
    response = requests.get(url=service_arg
                            , auth=auth)
    try:
        data = json.loads(response.content)
        price = data['Result'][0]['Price']
        return price
    except:
        print('no bond future price for date: %s and su_key %s ' %(datestr,su_key))
        print(service_arg)


def transform_bond_future_price_from_mds_to_df(su_key, startdate, enddate):
    auth = credential.get_HttpNtlmAuth()
    df = pd.DataFrame()
    for d in pd.date_range(startdate,enddate):
        try:
            price = extract_bond_future_price_from_mds_service(su_key,d,auth)
            single_pd = pd.DataFrame(data=[[su_key,d,price]],
                                     columns = ["su_key","date","price"]
                                     )
            df = df.append(single_pd)
        except:
            continue
    df = df.set_index(keys=['date'])
    return df





def extractBondFuturePrice(su_keys, asofdates, source ="TWP_RO"):
    """
    The extract function to get extract bond future price from the CRD table

    Read the CRD prices from the database for product bond future

    Args:
        su_keys           (list of str):            list of su keys
        asofdates          (list of dates):                   datetime
        source             (database schema):       default is TWP_RO

    Returns:
        (dict):  All rows

    Example:
        <This section is optional. Please remove these comment lines when you use the template.>
        <NOTE! Please keep the "::" followed by a blank line to indicate start of the code section>
        The module is called (from python) like this::

            something_returned = my_function_name(info      = 0,
                                                  var_a     = 9,
                                                  var_b     = {'some_dict_variable': 9, 'some_other_dict_variable': 'Ok - Got the point'}
                                                  )

    Warning:
        There is a bug in the query, if you put something else in the su_keys which not looks like a number, then the database will complain the date type.
        I did not manager to fix it right now....

    Notes:
        Author: g48454
    """
    datestr = [asofdates[i].strftime('%Y%m%d') for i in range(0, len(asofdates))]
    minDate = min(datestr)
    maxDate = max(datestr)

    list_su_key = ""
    for i in range(0, len(su_keys)):
        list_su_key = su_keys[i] + ", " + list_su_key

    list_su_key = list_su_key[:-2]

    tmp = ""
    for i, m in enumerate(list_su_key.replace(' ', '').split(',')):
        tmp = tmp + m + "','"

    list_su_key = tmp[:-3]
    list_su_key = "'" + list_su_key + "'"

    tSQL = '''
        select
         to_char(rs.instrument_su_key) as su_key,
         ii.instrument_name,
         ii.description,
         ii.issue_ccy,
         ift.future_type,
         rod.DATA_VALUE as price,
         rod.REPORT_DATE,
         rs.EXPIRY_DATE,
         rs.REG_DATE
         from mcdm.in_instrument ii
         left join prices.rr_securities rs on ii.SU_KEY=rs.INSTRUMENT_SU_KEY
         left join prices.rr_output_data rod on rs.SECURITY_ID=rod.SECURITY_ID
         left join mcdm.in_future inf on rs.instrument_su_key=inf.instrument_su_key
         left join mcdm.in_future_type ift on inf.FUTURE_TYPE_SU_KEY=ift.su_key
         where 1=1
         and rod.PURPOSE='REVAL'
         and ift.FUTURE_TYPE in ('BOND_FUTURE')
         and rs.instrument_su_key in (''' + list_su_key + ''')
         and rod.REPORT_DATE > = to_date('''+ minDate+''','yyyymmdd')
         and rod.REPORT_DATE < = to_date('''+maxDate+''','yyyymmdd')
         order by rod.REPORT_DATE asc
        '''
    tSQL = tSQL.replace('"', "")
    tSQL = tSQL.replace("\n", "")
    temp = external.select_from_query(info=0,
                                          database= source,
                                          query=tSQL)

    return temp


def transform_bond_future_price_to_dataframe(su_key, startdate, enddate):
    """
    Call extract functions for bond future and then transform the data to panda dataframe.

    Args:
        su_key              (str):                   su_key
        startdate          (date):                   start date
        enddate            (date):                   end date

    Returns:
        (dataframe):  data frame result


    Example:
        print(transform_bond_future_price_to_dataframe(su_key = '154832927',
                           startdate = datetime(2017,3,2),
                           enddate = datetime(2017,3,10)))
    Warning:
        There is a bug in the query, if you put something else in the su_keys which not looks like a number, then the database will complain the date type.
        I did not manager to fix it right now....

    Notes:
        Author: g48454
    """
    dict_prices = extractBondFuturePrice(su_keys = [su_key],
                           asofdates = [startdate,enddate])

    df = pd.DataFrame.from_dict(dict_prices)
    df = df.rename(columns={"report_date":"date"})
    df = df.set_index(keys = ['date'])
    return df



if __name__ == '__main__':
    df = transform_bond_future_price_from_mds_to_df(su_key='154832927',
                                             startdate=datetime(2017, 4, 2),
                                             enddate=datetime(2017, 4, 10))
    print(df)
    #print(transform_bond_future_price_to_dataframe(su_key = '154832927',
    #                       startdate = datetime(2017,3,2),
    #                       enddate = datetime(2017,3,10)))