'''
Extract functions for CDS spread curves
'''



import json
import warnings
from datetime import datetime

import pandas as pd
import quantum as qt
import requests
from pandas.tseries.offsets import BDay
from requests.auth import HTTPBasicAuth

from core.market_data.old_loaders.bond_curve_loader import yearfrac_to_qt_tenor
from core.utils.RawTimeSeries import RawTimeSeries


def extract_cds_spread_data_from_allCurveJsonData(all_curves_data,name):
    if all_curves_data[u'getSpreadDate'] == None:
        print('not loaded')
        return
    else:
        data_vec = all_curves_data['proxyCurve']['Proxy_'+name]['points']
        return data_vec

def get_json_from_service(date,info):
    # ===================================================================================
    # parse the web service
    # ===================================================================================
    date_str = datetime.strptime(str(date.date()), "%Y-%m-%d").strftime("%d%b%Y")
    service_arg = 'https://critweb.oneadr.net:8443/proxy-curve-service/spreadCurve/?report_date=' + date_str
    if info > 0:
        print(service_arg)
    # ===================================================================================
    # use get method from request package to get the data
    # The SSL certificate in server seems expired, so set verify to false to skip the verification step...
    # ===================================================================================
    warnings.filterwarnings("ignore")
    response=requests.get(url=service_arg, verify=False, auth=HTTPBasicAuth('user', '123'))
    # ===================================================================================
    # convert request to json data frame.
    # ===================================================================================
    return json.loads(response.content)


def transform_json_curve_from_web_service(date,data_vec):
    d=[]
    h=[]
    for i in range(len(data_vec)):
        yearfrac=data_vec[i]['tenor']
        qtTenor=yearfrac_to_qt_tenor(yearfrac)
        d.append(qt.addTenor(date,qtTenor))
        h.append(data_vec[i]['point'])
    credit_curve = qt.CurveLinear.make(d, h)
    return credit_curve


def extract_cds_curve_from_infop(curvename,startdate,enddate):
    from core.connection.database_extract import select_from_query
    # get the personal connection string from MARSP.
    date0_str = startdate.strftime('%Y%m%d')
    date1_str = enddate.strftime('%Y%m%d')
    # parse the sql
    SQL= ''' select contributiondate,ccy,spread6m,spread1Y,spread2Y,spread5Y,spread7Y,spread10y
    from tw_markit_net.markit_comp_convention
    where spread5y IS NOT NULL
    and shortname='%(curvename)s'
    and contributiondate
    between
    to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
    and tier='SNRFOR' ''' % locals()
    # run the sql
    return select_from_query(database='INFOP_G',query=SQL)

def make_qt_curve(curves, currDateTime):
    for x in range(0, len(curves)):
        if curves[x]['contributiondate'] == currDateTime:
            data=curves[x]
            tenorlist = ['6M', '1Y', '2Y', '5Y', '7Y', '10Y']
            ratelist = [data[x] for x in ['spread6m', 'spread1y', 'spread2y', 'spread5y', 'spread7y', 'spread10y']]
            datelist = [qt.addTenor(currDateTime, x) for x in tenorlist]
            qt_bond_curve = qt.CurveLinear.make(datelist, ratelist)
    return qt_bond_curve

def extract_cds_curve_from_gotc(curvename,startdate,enddate):
    from core.connection.database_extract import select_from_query
    date0_str = startdate.strftime('%Y%m%d')
    date1_str = enddate.strftime('%Y%m%d')
    # parse the sql
    SQL = ''' select *
        from gotc.gotc_curve_data
        where 1 =1
        and  curve_id = %(curvename)s
        and curve_datetime
        between
        to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
        ''' % locals()
    # run the sql
    return select_from_query(database='TWP_RO', query=SQL)

def make_qt_curve_from_gotc_curves(curves, currDateTime):
    # ===================================================================================
    # try make a qtoolkit curve based on the curves got from the gotc database
    # ===================================================================================
    datelist = []
    ratelist = []
    for x in range(0, len(curves)):
        if curves[x]['curve_datetime'].date() == currDateTime.date():
            data=curves[x]
            datelist.append(qt.addTenor(currDateTime,str(data['curve_offset_day']) + 'D'))
            ratelist.append((data['bid_value'] + data['offer_value'])/2)
    if len(datelist)>0:
        qt_credit_curve = qt.CurveLinear.make(datelist, ratelist)
        return qt_credit_curve
    else:
        return None


def load_cds_curve_from_gotc(curvename,startdate,enddate):
    # ===================================================================================
    # Extract the bond curves
    # ===================================================================================
    curves = extract_cds_curve_from_gotc(curvename, startdate, enddate)

    # =================================================================================
    # create an empty cache
    # ===================================================================================
    tempDataCache = RawTimeSeries(name='cdscurve_' + curvename)

    # ===================================================================================
    # convert the date range
    # ===================================================================================
    date_range = pd.date_range(startdate, enddate, freq=BDay(1))
    loadDateTimeRangeList = [datetime.combine(currt, datetime.min.time())
                             for currt in date_range]

    # ===================================================================================
    # make qt curve day by day and return
    # if not succeed in one day, the curve will not be added to the data cache
    # ===================================================================================
    for currDateTime in loadDateTimeRangeList:
        qt_curve = make_qt_curve_from_gotc_curves(curves, currDateTime)
        if qt_curve is not None:
            tempDataCache.addItem(qt_curve, currDateTime)
    return tempDataCache



def load_cds_curve_from_marsp(curvename,startdate,enddate):
    # ===================================================================================
    # Extract the bond curves
    # ===================================================================================
    curves=extract_cds_curve_from_infop(curvename,startdate,enddate)
    # =================================================================================
    # create an empty cache
    # ===================================================================================
    tempDataCache=RawTimeSeries(name='cdscurve_' + curvename)
    # ===================================================================================
    # convert the date range
    # ===================================================================================
    date_range=pd.date_range(startdate, enddate, freq=BDay(1))
    loadDateTimeRangeList = [datetime.combine(currt, datetime.min.time())
                             for currt in date_range]
    # ===================================================================================
    # make qt curve day by day and return
    # if not succeed in one day, the curve will not be added to the data cache
    # ===================================================================================
    for currDateTime in loadDateTimeRangeList:
        try:
            qt_curve=make_qt_curve(curves, currDateTime)
            tempDataCache.addItem(qt_curve,currDateTime)
        except:
            continue
    return tempDataCache

def extract_single_name_cds_from_markit(ticker, startdate, enddate):
    from core.connection.database_extract import select_from_query
    # parse the sql
    date0_str = startdate.strftime('%Y%m%d')
    date1_str = enddate.strftime('%Y%m%d')

    SQL = ''' select CONTRIBUTIONDATE, spread6m, spread1y,spread2y,spread3y,spread4y,spread5y,spread7y,spread10y
        from markit.markit_comp_convention
        where ticker ='%(ticker)s'
        and contributiondate
        between
        to_date('%(date0_str)s','yyyymmdd') and to_date('%(date1_str)s','yyyymmdd')
        ''' % locals()
    # run the sql
    return select_from_query(database='TWP_RO', query=SQL)

def load_cds_curve_from_markit(ticker, startdate, enddate):
    curves = extract_single_name_cds_from_markit(ticker, startdate, enddate)
    # =================================================================================
    # create an empty cache
    # ===================================================================================
    tempDataCache = RawTimeSeries(name='cdscurve_markit_' + ticker)
    # ===================================================================================
    # convert the date range
    # ===================================================================================
    date_range = pd.date_range(startdate, enddate, freq=BDay(1))
    loadDateTimeRangeList = [datetime.combine(currt, datetime.min.time())
                             for currt in date_range]
    # ===================================================================================
    # make qt curve day by day and return
    # if not succeed in one day, the curve will not be added to the data cache
    # ===================================================================================
    for currDateTime in loadDateTimeRangeList:
        try:
            qt_curve = make_qt_curve(curves, currDateTime)
            tempDataCache.addItem(qt_curve, currDateTime)
        except:
            continue
    return tempDataCache

if __name__ == '__main__':
    print(load_cds_curve_from_gotc(curvename='88585',startdate = datetime(2014,8,1), enddate = datetime(2014,12,1)).cacheDate)