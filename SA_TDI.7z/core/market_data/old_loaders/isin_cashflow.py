import datetime
from core.utils.RawTimeSeries import RawTimeSeries
from pandas.tseries.offsets import BDay
import pandas as pd
import orca
from core.utils.timeout import timeout
from core.connection.orca_connect import get_orca_request
req = get_orca_request()


def load_all_cashflow(isin,startD=datetime.datetime(2015,1,1),endD=datetime.datetime.now()):
    # load the cash flow from orca service

    service_req = get_orca_request()
    datacache = RawTimeSeries(name=isin + '_cashflow')
    try:
        specs_reply = service_req.request_bond_specs([isin]).result()
    except Exception as e:
        print('Orca not responed ')
        return datacache
    for tempT in pd.date_range(startD, endD, freq=BDay()):
        try:
            bond_cash_flow_obj = load_single_date_cach_flow(service_req,specs_reply, isin, tempT)
            datacache.addItem(bond_cash_flow_obj, tempT)
        except Exception as e:
            print('no cash flow loaded for ISIN: ' + isin + ' and date: '  )
            print(tempT)
            continue

    return datacache



@timeout(max_timeout=1)
def get_request(service_req,isin):
    specs_reply = service_req.request_bond_specs([isin]).result()
    return specs_reply

#@timeout(max_timeout=1)
def load_single_date_cach_flow(service_req,specs_reply, isin, tempT):
    excoupons = {isin: "%dB" % specs_reply.results[isin].excoupon_days for isin in specs_reply.results}
    bond_cash_flow_for_currISIN = service_req.request_bond_cashflows_from_date(isins=[isin],
                                                                               ex_coupon_periods=excoupons,
                                                                               date = tempT).result().results
    return bond_cash_flow_for_currISIN.itervalues().next()


if __name__ == '__main__':
    print(orca.__version__)

    from core.connection.orca_connect import get_orca_request

    cashflows = load_all_cashflow(isin = "XS1048657800",
                                  startD = datetime.datetime(2017,1,14) ,
                                  endD = datetime.datetime(2017,7,19) )
    print(cashflows.cacheDate)