"""
The module handle the bond pricing loading functionalities from different sources

The module used to have a cache functionality, that functionality has been moved to market data object so that all loader can get benefit of it.
Now we have two sources of the bond price:

    1) DAMDP, price is got from DAMDP database.
    2) web service, price is got from a web service, the web servcie is intended to use for production usage.

The module should get back both clean price and accured interest for each ISINs

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       27Feb2017   g48454      Initial creation
    ======= =========   =========   ========================================================================================


"""
import datetime as dt
import json
import pandas as pd
import requests
from pandas.tseries.offsets import BDay
from core.connection import credentials, orca_connect
from core.utils import error_handler
from core.utils.RawTimeSeries import RawTimeSeries


class BondPrice:
    def __init__(self):
        self.pricewebservice = 'http://mds.oneadr.net/v1/marketdata/prices/reval'
        self.keyfigwebservice = 'http://mds.oneadr.net:80/v1/marketdata/keyfigures/bonds'
        self.pricewebservice_test = 'http://vda1cs1527/v1/marketdata/prices/reval'
        self.keyfigwebservice_test = 'http://vda1cs1527:80/v1/marketdata/keyfigures/bonds'
        self.auth = credentials.get_HttpNtlmAuth()

    @staticmethod
    def supported_source():
        return ['DAMDP', 'MDS', 'orca']

    def get_bond_price(self, ISIN, source):
        data = self.make_price_into_datacache(ISIN, source)
        return data

    def make_price_into_datacache(self, ISIN, source, startd=dt.datetime(2015, 7, 1), endd=dt.datetime.now()):
        data_cache = RawTimeSeries(name=ISIN + '_marketPrice')
        auth = credentials.get_HttpNtlmAuth()
        print ('loading price for ISIN: ' + ISIN + ' now with the source:' + source)
        for tempT in pd.date_range(startd, endd, freq=BDay()):
            tmp_date = tempT + BDay(0)
            if source == 'MDS':
                price_obj = self.load_price_from_webservice(isin=ISIN, date=tmp_date.to_pydatetime(), auth=auth)
                if price_obj is not []:
                    data_cache.addItem(price_obj, tempT)
            elif source == 'MDS_test':
                price_obj = self.load_price_from_webservice(isin=ISIN, date=tmp_date.to_pydatetime(), auth=auth, test_env=True)
                if price_obj is not []:
                    data_cache.addItem(price_obj, tempT)
            elif source == 'orca':
                price_obj = self.load_price_from_orca(isin=ISIN, date=tmp_date.to_pydatetime())
                if price_obj is not []:
                    data_cache.addItem(price_obj, tempT)
            else:
                raise NotImplementedError

        return data_cache

    @staticmethod
    def load_price_from_orca(isin, date):
        req = orca_connect.get_orca_request()
        temp = req.request_bond_reval_price_on_date(isins=[isin], date=date).result()
        temp2 = req.request_bond_accrued_interest_from_date(isins=['DK0009288524'], date=date).result()

        try:
            price_obj = {"accrued_interest": temp2.results[isin][date.date()], 'clean_price': temp.results[isin].price}
        except:
            error_handler.track_error(error_message="NA", identifier=isin, date=date, comments="Cannot load from orca")
            price_obj = []
        return price_obj

    def load_price_from_webservice(self, isin, date, auth, test_env=False):
        # load the curve from REST service and transfer to json format
        this_load_is_success = True
        date_str = dt.datetime.strftime(date, '%Y-%m-%d')
        # ===================================================================================
        # load the clean price from market data service
        # ===================================================================================
        pricewebservice = self.pricewebservice if not test_env else self.pricewebservice_test
        keyfigwebservice = self.keyfigwebservice if not test_env else self.keyfigwebservice_test
        service_arg = pricewebservice + '?Isins=' + isin + '&TradeDate=' + date_str + '&format=json'
        response = requests.get(url=service_arg, auth=auth)
        data = json.loads(response.content)

        try:
            clean_price = data['Result'][0]['Price']
        except:
            this_load_is_success = False
            print ('no price for today: ' + date_str)

        # ===================================================================================
        # load the accrued interest from market data service
        # ===================================================================================
        if this_load_is_success:
            service_arg = keyfigwebservice + '?Isins=' + isin + '&TradeDate=' + date_str + '&format=json'
            response = requests.get(url=service_arg, auth=auth)
            data = json.loads(response.content)
            try:
                accrued_int = data['Result'][0]['Items'][0]['AccruedInterest']
            except:
                accrued_int = 0
                this_load_is_success = True
                print ('no accrued int for today: ' + date_str)

        # ===================================================================================
        # aggregate all information to dict
        # ===================================================================================
        if this_load_is_success:
            price_obj_temp = {"accrued_interest": accrued_int, 'clean_price': clean_price}
            price_obj = price_obj_temp
        else:
            price_obj = []
        return price_obj

    def load_price_from_web_service_v(self, isins, date, test_env=False):
        isins_str = ",".join(isins)
        date_str = dt.datetime.strftime(date, '%Y-%m-%d')
        pricewebservice = self.pricewebservice if not test_env else self.pricewebservice_test
        service_arg = pricewebservice + '?Isins=' + isins_str + '&TradeDate=' + date_str + '&format=json'

        response = requests.get(url=service_arg, auth=self.auth)
        return json.loads(response.content)

    def load_accrued_int_from_web_service_v(self, isins, date, test_env=False):
        isins_str = ",".join(isins)
        datestr = dt.datetime.strftime(date, '%Y-%m-%d')
        keyfigwebservice = self.keyfigwebservice if not test_env else self.keyfigwebservice_test
        service_arg = keyfigwebservice + '?Isins=' + isins_str + '&TradeDate=' + datestr + '&format=json'

        response = requests.get(url=service_arg, auth=self.auth)
        return json.loads(response.content)

    def get_cache_file_location(self, ISIN, source):
        return self.path+'bond_price_'+ISIN+'_'+source+'.pickle'

    def load_price_and_int(self, isins, date, test_env=False):
        prices = self.load_price_from_web_service_v(isins=isins, date=date, test_env=test_env)

        ints = self.load_accrued_int_from_web_service_v(isins=isins, date=date, test_env=test_env)
        out = {}
        price_dict = {}
        int_dict = {}
        for x in prices['Result']:
            try:
                price_dict[x['Isin']] = x['Price']
            except:
                error_handler.track_error(error_message="NA",
                                          identifier="",
                                          date=date,
                                          comments="Not able to parse %s" % (str(x)))

        for x in ints['Result']:
            try:
                int_dict[x['Isin']] = x['Items'][0]['AccruedInterest']
            except:
                error_handler.track_error(error_message="NA",
                                          identifier="",
                                          date=date,
                                          comments="Not able to parse %s" % (str(x)))

        for isin in isins:
            try:
                float(price_dict[isin])
            except:
                error_handler.track_error(error_message="NA",
                                          identifier=isin,
                                          date=date,
                                          comments="Not able to load price")
                continue

            try:
                a_int = float(int_dict[isin])
            except:
                error_handler.track_error(error_message="NA",
                                          identifier=isin,
                                          date=date,
                                          comments="Not able to accrued int, use 0 instead")
                a_int = 0.0
            out[date, isin] = float(price_dict[isin]) + a_int
        return out
