"""
Imports equity quotients.

Imports equity quotients based on a list of equity_id's and a minimum and a maximum date for the period (both days will be included). 
It returns equity quotient data as a list of dictionarys.
The current version of the module only support extract from database infop (mars), but could be extended to other databases with same data structure.

Warning:

    Equity quotients could come from proxies (replacement quotinets) when prices have been missing for some reason. We have applyed
    a noise filter on 1day quotients between -0.5 and 1.

Notes:
    Author: G35294

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       20sep2017   G35294      Initial creation
    ======= =========   =========   ========================================================================================
"""


import core.connection.database_extract as database_extract


def extract(equity_id,
            min_date,
            max_date,            
            source_db = 'INFOP'
            ):
    '''
    This function will return the Equity quotients (relative shifts) based on the equity_id and dates


    Args:
        equity_id               (list of int):          The list of mars equity_id's
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set        
        source_db               (str):                  The database to extract from       

    Returns:
        (list of dicts):   Extracted equity quotients in tabular like list of dictionaries

    Raises:


    Example:
        The module is called (from python) like this::
            
            from core.market_data import equity_quotients
            
            equity_1day_shifts = equity_quotients.extract(equity_id       = [1,2,3],
                                                          min_date        = datetime.date(2017, 2, 13),
                                                          max_date        = datetime.date(2017, 2, 20)
                                                          )

    Warning:
        

    Notes:
        Author: Leon Hartmann (G35294)
    '''
       
    chunksize=900
    result=[]


    for i in range(0,len(equity_id),chunksize):
        
        select_query = mars_extract_string(equity_id        = equity_id[i:i+chunksize],
                                           min_date         = min_date,
                                           max_date         = max_date
                                           )
        
        result.extend(database_extract.select_from_query(database   = source_db,
                                                         query      = select_query
                                                          ))
        
    return result

        
import core.utils.date_helper as dateutils

def mars_extract_string(equity_id,
                        min_date,
                        max_date
                        ):
    '''
    Creates sql extract string used for retrieving equity quotients from MARS

    Args:
        equity_id               (list of int):          List of the equity_id's
        min_date                (datetime.date):        The first EoD Date in the required data set
        max_date                (datetime.date):        The last EoD Date in the required data set

    Returns:
        (str):   Sql extract string

    Raises:

    Example:                                                 )

    Warning:

    Notes:
        Author: 
    '''


    min_sql_date = dateutils.oracle_to_date(min_date)
    max_sql_date = dateutils.oracle_to_date(max_date)

    date_where_clause = 'b.end_date between ' + min_sql_date + ' and '  + max_sql_date


    if type(equity_id) is list:
        equity_where_clause = 'c.equity_id in (' + (", ".join(str(x) for x in equity_id)) + ')'
    else:
        equity_where_clause = "c.equity_id = '" + str(equity_id) + "'"

    #making condition clause
    combined_where_clause = date_where_clause + ' and ' + equity_where_clause

    # Noise filter on 1day quotients between -0.5 and 1

    select_query = (''' select c.equity_id, c.name, a.timeinterval_id sc_id, b.end_date
                    , case when a.quotient < -0.5 then -0.5
                       when a.quotient > 1 then 1
                       else a.quotient
                       end  quotient
                    from marsp.equity_quotient a
                    , marsp.timeinterval b
                    , marsp.equity c
                    where
                    '''
                        + combined_where_clause +
                    '''
                    and b.timeinterval_id = a.timeinterval_id
                    and a.effect_id = c.effect_id
                        order by a.effect_id, a.timeinterval_id
                    '''
                  )

    return select_query


# ======== Standard Code to add code-lib to PYTHONPATH ========
if __name__ == '__main__':
    import os, sys

    sys.path = list((x for x in sys.path if x.find('code-lib') == -1))  # Remove existing code-lib paths
    sys.path.append(os.getcwd()[:os.getcwd().rfind("code-lib") + 8])  # Add current code-lib path
    # =============================================================

    import pandas as pd
    from core.utils import date_helper

    equityIDs = [58923]
    result = extract(equityIDs, date_helper.to_datetime('2017-10-26'), date_helper.to_datetime('2017-11-08'))
    result_df = pd.DataFrame(result)
    result_df.to_csv('eq_test.csv')