"""
Helper module containing various functions needed for easily fetching data from MARS


Warning:
    This should be refactored when it is more clear what is needed.

Notes:
    Author: ABaglan

    ======= =========   =========   ====================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ====================================================================================
    1       08mar2019   ABaglan     Initial creation
    ======= =========   =========   ====================================================================================
    """

from core.connection import database_connect
from core.utils import date_helper
import pandas as pd
import pyodbc
from core.types._scenarios import ObservationPeriod
import itertools
from core.utils import dataframe_helper
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.market_data import proxy_helper
from core.market_data.sql_library import scaled_interest_shifts
import datetime as dt


def get_sc_grp_id(observation_period):
    """
    Given the ObservationPeriod from core.types.scenario_types returns mars scenario group id

    Args:
        observation_period    (scenario_types.ObservationPeriod:): Description

    Returns:
        (type): mars scenario group id

    Notes:
        Author: g01571(ABaglan)
    """

    if observation_period == ObservationPeriod.STRESSED:
        out = 102
    elif observation_period == ObservationPeriod.VAR:
        out = 2000
    else:
        raise NotImplementedError("The Observation Period have not been implemented for " + str(observation_period))
    return out


def get_mars_dates_between(start_date, end_date, conn):
    """
    Returns mars dates between given 2 days

    Args:
        start_date    (date format): starting date
        end_date      (date format): ending date
        conn          (pyodbc.connection):  connection

    Returns:
        (type): a list of dates included in mars

    Notes:
        Author: g0171 (ABaglan)
    """

    sdat = date_helper.oracle_to_date(start_date)
    edat = date_helper.oracle_to_date(end_date)
    sql_str = """select a.eod_date as dates
                    from marsp.history_date a, marsp.history_type b
                    where a.eod_date between %s and %s
                    and a.history_type_id = b.history_type_id
                    and a.history_type_id = 'B'
                    order by 1
                """%(sdat,edat)
    df = pd.read_sql(sql_str, conn)
    return df.DATES


def get_mars_sc_start_end_days(scenario_type, eod_date, conn):
    """
    Gets scenario dates dataframe in the following format

    START_DATE   END_DATE
    1 DAY1       DAY2
    2 DAY2       DAY3
    ..
    Args:
        scenario_type    (scenario_types.ObservationPeriod): VAR, STR
        eod_date        (date type): EOD
        conn            (pyodbc.connection): Connection

    Returns:
        (DataFrame): A dataframe with start and end dates

    Notes:
        Author: g01571(ABaglan)
    """


    sc_grp_id = get_sc_grp_id(scenario_type)
    if eod_date > dt.datetime(2019, 9, 16) and sc_grp_id==102:
        eod_date=dt.datetime(2019, 9, 16)

    eod_date = date_helper.oracle_to_date(eod_date)
    sql_str = """ select b.start_date, b.end_date
                from marsp.sc_grp_sc_dyn a, marsp.timeinterval b
                where a.eod_date = %s
                and a.sc_grp_id = %s 
                and a.sc_id = b.timeinterval_id
                order by 2"""%(eod_date,sc_grp_id)
    df = pd.read_sql(sql_str, conn)
    return df


def get_rtpl_start_end_day(eod_date, conn):
    eod_date_str = date_helper.oracle_to_date(eod_date)
    sql_str = """select B.* from MARSP.HISTORY_DATE a, MARSP.HISTORY_DATE B
                where a.EOD_DATE = %s
                and B.DATE_NO = a.DATE_NO+1 """ % eod_date_str
    next_day = pd.read_sql(sql_str, conn)['EOD_DATE'][0]

    return pd.DataFrame([[eod_date, next_day]], columns=['START_DATE', 'END_DATE'])


def do_local_scaling_for_risk_factor(rf_list, conn):
    """
    A function that returns wheter local scaling should be applied for the riks factor
    :param rf_list: A list of risk factors
    :return: A list of booleans
    """
    sql_str = """select distinct interest_id
                 from 
                    (
                    select interest_id 
                    from marsp.interest_function_value#2
                    where interest_function_id < 4
                    union
                   select interest_id
                    from marsp.interest_function_value#3
                    ) 
"""
    interest_ids_to_scale = list(pd.read_sql(sql_str, conn)['INTEREST_ID'])

    out = [(str(rf.RISK_FACTOR_TYPE) == str(RiskFactorType.RfInterestRate)) and
           rf.mdmapping['mars_risk_factor_id'] in interest_ids_to_scale for rf in rf_list]
    return out


def get_list_of_risk_factor_data_for_sc(risk_factors, valuation_date, sc_days, conn, local_scaling=False):
    """
    One line description. Then an empty line - followed by multi-line detailed description.

    Args:
        risk_factors    (list)              : ist of risk factors
        sc_days          (DataFrame)        : df with start_day and day
        conn            (pyodbc.connection) : connection
        local_scaling                       : boolean to check if local scaling for interest risk

    Returns:
        (list): List of DataFrames with data

    Notes:
        Author: g01571(ABaglan)
    """

    if len(risk_factors) == 0 or len(sc_days) == 0:
        return []

    # Output columns
    out_columns = ['start_date', 'start_value', 'end_date', 'end_value', 'risk_factor']
    start_date = sc_days.START_DATE.iloc[0]
    end_date = sc_days.END_DATE.iloc[-1]
    all_df = {}  # A dataframe for each risk factor
    risk_factors = pd.Series(risk_factors)
    risk_factors_df = pd.DataFrame()
    # risk_factors_df['rf_id'] = risk_factors.apply(lambda x: x.mdmapping['mars_risk_factor_id'])
    risk_factors_df['risk_factor'] = risk_factors
    risk_factors_df['risk_factor_index'] = risk_factors.index
    risk_factors_df['risk_type'] = risk_factors.apply(lambda x: str(x.RISK_FACTOR_TYPE))
    if local_scaling:
        risk_factors_df['do_local_scaling'] = do_local_scaling_for_risk_factor(risk_factors, conn)
    else:
        risk_factors_df['do_local_scaling'] = False
    rf_groups = risk_factors_df.groupby(['risk_type', 'do_local_scaling'])

    for (risk_type, do_local_scaling), group in rf_groups:
        print("loading market data for", risk_type)
        # Get a copy
        group_df = group.copy()
        group_risk_factors = list(group_df['risk_factor'])
        group_risk_factors_index = list(group_df['risk_factor_index'])

        if risk_type == str(RiskFactorType.RfCcyPair):
            # Get market data
            now_dfs = get_ccy_pair_data(group_risk_factors, start_date, end_date, conn=conn)

        elif risk_type in [str(RiskFactorType.RfInterestRate)] and do_local_scaling:
            print('Loading with Local Scaling')
            stress_period = ObservationPeriod.STRESSED.stressed_period()
            stress_start = date_helper.to_datetime(stress_period['start_date']) - dt.timedelta(3)
            stress_end = date_helper.to_datetime(stress_period['end_date']) + dt.timedelta(3)

            print(stress_start, stress_end)
            print(start_date, end_date)
            if end_date<=stress_end and start_date>=stress_start:
                sc_grp_id = get_sc_grp_id(ObservationPeriod.STRESSED)
                query_date = valuation_date
                print('here')
            else:
                sc_grp_id = get_sc_grp_id(ObservationPeriod.VAR)
                query_date = end_date
            now_dfs = get_interest_rf_data_local_scaled(group_risk_factors, sc_grp_id, query_date, conn=conn)

        elif risk_type in [str(RiskFactorType.RfInterestRate), str(RiskFactorType.RfRefinanceRate)]:
            now_dfs = get_interest_rf_data(group_risk_factors, start_date, end_date, conn=conn)

        elif risk_type == str(RiskFactorType.RfBondSwapBasis):
            now_dfs = get_bond_swap_basis_data(group_risk_factors, start_date, end_date, conn=conn)

        elif risk_type == str(RiskFactorType.RfInterestAtmVolatility):
            now_dfs = get_ir_vol_data( group_risk_factors,start_date, end_date, use_proxy=False)

        else:
            raise NotImplementedError("Can't get the market data for this id yet")

        # Fit to sc dates
        now_dfs = [fit_to_scenario_days(df, sc_days, group_risk_factors_index[i])
                   for i, df in enumerate(now_dfs) if len(df) > 0]

        now_dfs = [df.merge(group_df, on=['risk_factor_index']) for df in now_dfs]
        # Update dict
        now_dfs = {df.risk_factor_index.iloc[0]: df[out_columns] for df in now_dfs}
        all_df.update(now_dfs)

    # Return data frames in the same order with risk factors
    return [all_df.get(i, pd.DataFrame(columns=out_columns)) for i in range(len(risk_factors))]


def get_ir_vol_id(ccy, vol_interest_market):
    """
    Some combinations of currency and interest market returns several vol_ids. This functions finds the correct one

    Specifically, for EUR swaption vol we have two different ids. This function simply chooses the ID corresponding to
    the other currencies using very simple logic (i.e. prone to bugs)

    Args:
        ccy                 (str): Currency
        vol_interest_market (str): Interest market ('SWPTN' or 'LAMDA')

    Returns:
        (int): the vol_id

    Notes:
        Author: g48606
    """
    sens_date = dt.date(2022, 1, 19)
    oracle_date = date_helper.oracle_to_date(sens_date)
    sql_string = f"""select distinct a.vol_id, b.name from MARSP.VOL_SENS a, MARSP.VOL B
                    where a.eod_date = {oracle_date}
                    and a.VOL_ID = B.VOL_ID
                    and B.UNDL_TYPE_ID = 'INTEREST'
                    and B.VOL_MARKET_ID = '{vol_interest_market}'
                    and b.currency_id = '{ccy}'"""
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if data.empty:
        raise NameError(f"No data returned for date: {sens_date}, ccy: {ccy}, vol_market: {vol_interest_market}")
    elif len(data) > 1:
        tmp = data[['SV_VOL' in x for x in data['NAME']]].reset_index(drop=True)
        if len(tmp) == 1:
            return int(tmp['VOL_ID'][0])
        else:
            raise NameError(f"Cannot identify vol_id for {ccy}, {vol_interest_market}")
    return int(data['VOL_ID'][0])


def get_ir_vol_data(risk_factors, start_date=None, end_date=None, use_proxy=False):
    vol_ids = tuple(set([int(rf.mdmapping['mars_risk_factor_id']) for rf in risk_factors]))
    if use_proxy:
        vol_ids = [proxy_helper.get_vol_proxies(vol_id, 'IR')['PROJECTION_VOL_ID'][0] for vol_id in vol_ids]
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    vol_ids_sql = "(" + ",".join(["'%s'" % i for i in vol_ids]) + ")"
    sql_string = """select a.EOD_DATE, a.VOL_ID as MARKET_DATA_ID, a.MATURITY_TERM_ID as MATURITY_ID, a.TENOR_TERM_ID AS TENOR_ID, a.VOL_PCT/100 VALUE
                    from MARSP.VOL_RATE a, marsp.ladder_term b, marsp.ladder_term c
                    where a.VOL_ID in {vol_ids}
                    {date_req}
                    and a.MATURITY_TERM_ID = B.TERM_ID
                    and B.LADDER_ID = 26
                    and a.TENOR_TERM_ID = c.TERM_ID
                    and C.LADDER_ID = 25
                    and A.VOL_PCT > 0
                    order by a.EOD_DATE""".format(date_req=date_req, vol_ids=vol_ids_sql)
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql=sql_string, con=conn)
    df = dataframe_helper.transform_id_columns(df)
    out = []
    for r_i in range(len(risk_factors)):
        risk_factor = risk_factors[r_i]
        market_id = risk_factor.mdmapping['mars_risk_factor_id']
        maturity_id = risk_factor.mdmapping['maturity_tenor']
        tenor = risk_factor.mdmapping['underlying_maturity_tenor']

        now_df = df.copy()[(df.TENOR_ID == tenor) & (df.MARKET_DATA_ID == market_id) & (df.MATURITY_ID == maturity_id)]
        now_df = now_df.sort_values('EOD_DATE')
        out.append(now_df)
    return out


def get_ccy_pair_data(risk_factors, start_date, end_date, conn):
    """
    Returns market data for currency between given days

    Args:
        currency_id_list    (type): Currency
        start_date          : start date
        end_date            : end date

    Returns:
        (type): Description

    Example:
        The module is called (from python) like this::

            # Code Example Here...

    Notes:
        Author: g01571 (ABaglan)
    """

    currency_id_list = tuple(set([r.mdmapping['mars_risk_factor_id'] for r in risk_factors]))

    sdat = date_helper.oracle_to_date(start_date)
    edat = date_helper.oracle_to_date(end_date)
    # currency_id_list = tuple(currency_id_list)
    currency_id_list_str = "(" + ",".join(["'%s'" % i for i in currency_id_list]) + ")"
    sql_str = """select CURRENCY_ID as MARKET_DATA_ID, EOD_DATE, PRICE/100 AS VALUE from marsp.currency_price a
                 where a.currency_id in %s
                 and a.eod_date between %s and %s""" % (currency_id_list_str, sdat, edat)
    df = pd.read_sql(sql_str, conn)

    out = []
    for r_i in range(len(risk_factors)):
        risk_factor = risk_factors[r_i]
        market_id = risk_factor.mdmapping['mars_risk_factor_id']
        now_df = df.copy()[(df.MARKET_DATA_ID == market_id)]
        now_df = now_df.sort_values('EOD_DATE')
        out.append(now_df)
    return out


def get_dkk_bond_basis(start_date, end_date, conn):
    s = date_helper.oracle_to_date(start_date)
    e = date_helper.oracle_to_date(end_date)
    sql = """select 'DMB_BondSwapBasis' as MARKET_DATA_ID, a.eod_date, a.TERM_ID, a.SPREAD_PCT/100 value
from G48606.SPREAD_RATE a, g48606.spread b, marsp.ladder_term c
where a.EOD_DATE between %s and %s
and a.SPREAD_ID = b.SPREAD_ID
and b.SPREAD_MARKET_ID = 'BOND-SWAP_BASIS'
and b.CURRENCY_ID = 'DKK'
and b.NAME like '%%MORTG%%'
and b.NAME like '%%SWAP%%'
and a.TERM_ID = c.TERM_ID
and c.LADDER_ID = 68""" % (s, e)
    df = pd.read_sql(sql, conn)
    mars_ids = ('DMB_BondSwapBasis',)
    tenors = tuple(df.TERM_ID.unique())
    gb = df.groupby(['MARKET_DATA_ID', 'TERM_ID'])
    df_dict = {x: (gb.get_group(x).reset_index(drop=True) if x in gb.groups else pd.DataFrame(columns=df.columns))
               for x in itertools.product(mars_ids, tenors)}
    return df_dict


def get_interest_rf_data_local_scaled(risk_factors, sc_grp_id, valuation_date, conn):
    interest_ids = tuple(set([rf.mdmapping['mars_risk_factor_id'] for rf in risk_factors]))
    sql = scaled_interest_shifts(valuation_date, sc_grp_id, interest_ids)
    print(valuation_date)
    df = pd.read_sql(sql, conn)
    df = df.rename(columns={'SHIFT_ID': 'MARKET_DATA_ID',
                            'MARS_SHIFT': 'VALUE',
                            'EOD_DATE': 'not',
                            'SCENARIO_DATE': 'EOD_DATE'})
    df.VALUE = df.VALUE / 100
    out_shifts = []
    for r_i in range(len(risk_factors)):
        risk_factor = risk_factors[r_i]
        market_id = risk_factor.mdmapping['mars_risk_factor_id']
        tenor = risk_factor.mdmapping['maturity_tenor']
        now_df = df.copy()[(df.TERM_ID == tenor) & (df.MARKET_DATA_ID.astype(int) == market_id)]
        now_df = now_df.sort_values('EOD_DATE')
        out_shifts.append(now_df)

    out = []
    for df in out_shifts:
        df = df.sort_values('EOD_DATE')
        df['VALUE'] = df['VALUE'].cumsum()
        out.append(df)

    return out


def get_interest_rf_data(risk_factors, start_date, end_date, conn):
    tenors = tuple(set(risk_factor.mdmapping['maturity_tenor'] for risk_factor in risk_factors))
    mars_ids = tuple(set(risk_factor.mdmapping['mars_risk_factor_id'] for risk_factor in risk_factors))
    sdat = date_helper.oracle_to_date(start_date)
    edat = date_helper.oracle_to_date(end_date)
    tenors_sql = "(" + ",".join(["'%s'" % i for i in tenors]) + ")"
    mars_ids_sql = "(" + ",".join(["'%s'" % i for i in mars_ids]) + ")"
    sql_str = """select INTEREST_ID as MARKET_DATA_ID, TERM_ID, EOD_DATE, INTEREST_PCT/100 AS VALUE from marsp.interest_rate a
    where a.interest_id in %s
    and a.eod_date between %s and %s
    and a.term_id in %s
    """ % (mars_ids_sql, sdat, edat, tenors_sql)
    df = pd.read_sql(sql_str, conn)
    df = dataframe_helper.transform_id_columns(df)
    out = []

    for r_i in range(len(risk_factors)):
        risk_factor = risk_factors[r_i]
        market_id = risk_factor.mdmapping['mars_risk_factor_id']
        tenor = risk_factor.mdmapping['maturity_tenor']
        now_df = df.copy()[(df.TERM_ID == tenor) & (df.MARKET_DATA_ID == market_id)]
        now_df = now_df.sort_values('EOD_DATE')
        out.append(now_df)
    return out


def get_bond_swap_basis_data(risk_factors, start_date, end_date, conn, pivot_on_tenors=False):
    tenors = tuple(set([rf.mdmapping['maturity_tenor'] for rf in risk_factors]))
    mars_ids = tuple(set([int(rf.mdmapping['mars_risk_factor_id']) for rf in risk_factors
                         if rf.mdmapping['mars_risk_factor_id'] != 'ZERO']))

    sdat = date_helper.oracle_to_date(start_date)
    edat = date_helper.oracle_to_date(end_date)
    tenors_sql = "(" + ",".join(["'%s'" % i for i in tenors]) + ")"
    mars_ids_sql = "(" + ",".join(["'%s'" % i for i in mars_ids]) + ")"
    sql_str = """select SPREAD_ID as MARKET_DATA_ID, TERM_ID, EOD_DATE, SPREAD_PCT/100 AS VALUE  from g48606.spread_rate a
                    where spread_id in %s 
                    and term_id in %s
                    and a.eod_date between %s and %s"""%(mars_ids_sql, tenors_sql, sdat, edat)
    df = pd.read_sql(sql_str, conn)
    df = dataframe_helper.transform_id_columns(df)
    out = []
    for r_i in range(len(risk_factors)):
        risk_factor = risk_factors[r_i]
        market_id = risk_factor.mdmapping['mars_risk_factor_id']
        if market_id == 'ZERO':
            market_id = -1
        tenor = risk_factor.mdmapping['maturity_tenor']
        now_df = df.copy()[(df.TERM_ID == tenor) & (df.MARKET_DATA_ID.astype(int) == market_id)]
        now_df = now_df.sort_values('EOD_DATE')
        out.append(now_df)
    return out


def fit_to_scenario_days(df, sc_dates, rf_index=None):
    """
    For a df of the format
    df:
    EOD_DATE    VALUE
    day1        val1
    day2        val2

    sc dates
    START_DATE  END_DATE
    day1        day2
    day2        day3

    returns
    START_DATE  START_VALUE     END_DATE    END_VALUE
    day1        val1            day2        val2
    day2        val2            day3        val3
    Args:
        df    (type): dataframe including values
        sc_dates    :  start and end days
    Returns:
        (type): Description


    Notes:
        Author: g01571(ABaglan)
    """
    df.index = df.EOD_DATE
    df.index.name = ''
    sc_dates.index = sc_dates.START_DATE
    sc_dates.index.name = ''
    temp_df = pd.merge(df, sc_dates, left_on='EOD_DATE', right_on='START_DATE', how='right')
    temp_df = pd.merge(temp_df, df[['EOD_DATE', 'VALUE']], left_on='END_DATE', right_on='EOD_DATE', suffixes=('_left',
                                                                                                              '_right'))
    temp_df['START_VALUE'] = temp_df['VALUE_left']
    temp_df['END_VALUE'] = temp_df['VALUE_right']
    temp_df['SCENARIO_DATE'] = temp_df.START_DATE
    temp_df.MARKET_DATA_ID = df.MARKET_DATA_ID.iloc[0]
    if 'TERM_ID' in temp_df.columns:
        temp_df.TERM_ID = df.TERM_ID.iloc[0]
    temp_df.columns = [i.lower() for i in temp_df.columns]
    temp_df = temp_df[temp_df.columns.difference(['eod_date_left', 'value_left',
                                                    'eod_date_right', 'value_right'])]
    temp_df.index=temp_df.start_date
    temp_df = temp_df.dropna()
    temp_df = temp_df.sort_values('scenario_date')
    if rf_index is not None:
        temp_df['risk_factor_index'] = rf_index
    return temp_df


def get_isins_from_mars(date, effect_grp_ids, conn):
    oracle_date = date_helper.oracle_to_date(date)
    effect_str = ', '.join(map(str, effect_grp_ids))
    query = """
    with isins as (
    select distinct effect_id , isin from marsp . isin_effect union
    select distinct effect_id , isin from marsp . effect_woc_link
    where isin is not null union
    select distinct effect_id , isin from marsp . effect_ufo_link union
    select distinct effect_id , isin from marsp . effect_ifo_link union
    select distinct effect_id , isin from marsp . effect_ana_link ),
    bonds as (
    select distinct product_id from marsp . product_mapping
    where effect_grp_id in (%(effect_str)s)
    and trade_type_id in ('HOLD','SPOT','FWD','REPO_S','REPO_F')),
    markets as (
    select distinct org_id , 1 as mkts
    from marsp . cons_org_structure_std
    where cons_org_id = 50004)
    select distinct isin from 
    (
    select isin
    from marsp . holding 
    join bonds using ( product_id )
    join isins using (effect_id)
    join markets using (org_id)
    where eod_date = %(oracle_date)s
    union
    select isin
    from marsp . trans
    join marsp . trans_status using ( trade_id , trans_id , org_id )
    join bonds using ( product_id )
    join isins using (effect_id)
    join markets using (org_id)
    where eod_date =  %(oracle_date)s)
    """ % locals()
    df = pd.read_sql(query, conn)
    return list(df['ISIN'])


if __name__ == "__main__":
    connection = pyodbc.connect(database_connect.get_string('INFOP'))
    today = date_helper.yesterday_as_date()
    import datetime
    today = datetime.datetime(2019, 4, 16)
    a = get_mars_sc_start_end_days(ObservationPeriod.VAR, today, connection)
    a = 5
    a = get_rtpl_start_end_day(today, connection)

