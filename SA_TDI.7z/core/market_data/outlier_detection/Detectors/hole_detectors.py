import pandas as pd
from core.market_data.outlier_detection.Detectors.detector_interface import Detector


class HoleDetector(Detector):
    def get_mask(self, data):
        self.output_mask = data.isna()
        return self.output_mask
