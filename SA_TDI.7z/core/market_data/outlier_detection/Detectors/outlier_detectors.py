"""
This is a data checker. It finds the stale and outlier defects.

A point is detected as outlier if it is n rolling std bigger or lower than the rolling mean
A point is detected as stale if the rolling variance at that point is smaller than epsilon

Notes:
    Author: g01571

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       10jan2019   G01571      Initial creation
    ======= =========   =========   ========================================================================================

"""
import pandas as pd
from core.market_data.outlier_detection.Detectors.detector_interface import Detector


class OutlierDetectorSTD(Detector):
    def __init__(self, window_size=30, std_multiplier=3):
        """
        :param data:
        :param window_size: window size to calculate std and mean
        :param std_multiplier: the multiplicator to decide if a point[ is outlier
        :param stale_std_lim: the limit std to decide if a point is stale (if the rolling std at that point is lower)
        """
        self.window_size = window_size
        self.std_multiplier = std_multiplier
        self.outlier_lims = None
        super().__init__()

    def get_mask(self, data):

        if self.outlier_calculated:
            return self.output_mask

        outlier_lims = pd.DataFrame().reindex_like(data)
        now_filter = pd.DataFrame().reindex_like(data)
        self.output_mask = pd.DataFrame().reindex_like(data)
        self.output_mask.loc[:, :] = False


        for col in data.columns:

            #Calculate upper and lower limits
            outlier_lims[col+"_std"] = data[col].rolling(self.window_size).std()
            outlier_lims[col + "_mean"] = data[col].rolling(self.window_size).mean()

            outlier_lims[col + "_up"] = \
                outlier_lims[col + "_mean"] \
                + self.std_multiplier * outlier_lims[col + "_std"]

            outlier_lims[col + "_down"] = \
                outlier_lims[col + "_mean"] \
                - self.std_multiplier * outlier_lims[col + "_std"]

            # Get the filter
            now_filter[col] = (outlier_lims[col + "_down"] > data[col]) | (outlier_lims[col + "_up"] < data[col])

        self.outlier_calculated = True
        # Mark those points as outlier
        self.output_mask[now_filter] = True

        return self.output_mask


