import pandas as pd
import numpy as np
from core.market_data.outlier_detection.Detectors.detector_interface import Detector


class StaleDetectorSTD(Detector):
    def __init__(self, stale_window_size, stale_std_lim):
        self.stale_window_size = stale_window_size
        self.stale_std_lim = stale_std_lim
        super().__init__()

    def get_mask(self, data):
        self.output_mask = pd.DataFrame().reindex_like(data)
        self.output_mask.loc[:, :] = False
        now_filter = pd.DataFrame().reindex_like(self.output_mask)
        outlier_lims = pd.DataFrame().reindex_like(data)
        data_mean = data.mean()

        for col in data.columns:
            outlier_lims[col + "_std"] = data[col].rolling(self.stale_window_size).std()
            now_filter[col] = (outlier_lims[col + "_std"] < self.stale_std_lim * data_mean[col])
            now_filter[col] = now_filter[col][::-1].rolling(5).apply(np.any).iloc[::-1].fillna(False).astype('bool')

        self.output_mask[now_filter] = True
        return self.output_mask
