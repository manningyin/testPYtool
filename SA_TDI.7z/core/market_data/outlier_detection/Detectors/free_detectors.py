import pandas as pd
from core.market_data.outlier_detection.Detectors.detector_interface import Detector


class FreeDetector(Detector):
    def get_mask(self, data):
        self.output_mask = pd.DataFrame().reindex_like(data)
        self.output_mask.loc[:, :] = True
        return self.output_mask
