class Detector:
    def __init__(self):
        self.output_mask = None
        self.outlier_calculated = False

    def get_mask(self, data):
        raise NotImplementedError

    def reset(self):
        self.output_mask = None
        self.outlier_calculated=False
