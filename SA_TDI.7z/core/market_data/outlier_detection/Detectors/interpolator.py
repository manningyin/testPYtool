import numpy as np
import pandas as pd


class Interpolator:
    def __init__(self):
        self.methods = ['linear', 'cubic', 'remove', 'level correction', 'extrapolate']

    @staticmethod
    def my_interpolate(df, method):
        if method == 'extrapolate':
            df = df.fillna(method='ffill')
        else:
            df = df.interpolate(method=method)
        return df

    def interpolate_data_frame(self, df, method, col, selected_indexes):
        """
        :param df:  the dataframe to interpolate
        :param method:  the method of interpolation
        :return: interpolated dataframe
        """
        if method not in self.methods:
            raise  Exception('Unknown interpolation type')

        if method == 'remove':
            df.loc[selected_indexes, col] = np.nan
        elif method == 'level correction':
            temp_df = df.copy()
            first_point = selected_indexes[selected_indexes == True].first_valid_index()
            last_point = selected_indexes[selected_indexes == True].last_valid_index()
            first_diff = temp_df.diff().loc[first_point, col]
            last_diff = (temp_df - temp_df.shift(-1)).loc[last_point, col]
            temp_df.loc[first_point:last_point, col] = np.nan
            temp_df.loc[first_point, col] = first_diff
            temp_df.loc[last_point, col] = last_diff
            temp_df = temp_df.interpolate(method='linear')
            temp_df = df - temp_df
            df.loc[selected_indexes, col] \
                = temp_df[selected_indexes][col]
        else:
            temp_df = df.copy()
            temp_df.loc[selected_indexes, col] = np.nan
            temp_df = self.my_interpolate(temp_df, method)
            df.loc[selected_indexes, col] \
                = temp_df[selected_indexes][col]
        return df

