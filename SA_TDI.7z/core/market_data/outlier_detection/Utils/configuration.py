from core.market_data.outlier_detection.Detectors.outlier_detectors import OutlierDetectorSTD
from core.market_data.outlier_detection.Detectors.stale_detectors import StaleDetectorSTD
from core.market_data.outlier_detection.Detectors.free_detectors import FreeDetector
from core.market_data.outlier_detection.Detectors.hole_detectors import HoleDetector
from core.market_data.outlier_detection.Detectors.interpolator import Interpolator
from core.market_data.outlier_detection.Utils.types import Calendars,DataBases,DefectTypes, InterpolationMethods

detectors = {"outlier" : {"Standard Deviation": OutlierDetectorSTD(window_size=65, std_multiplier=3)},
             "stale"   : {"Stale Finder": StaleDetectorSTD(stale_window_size=5, stale_std_lim=0.005)},
             "free"    : {"Free Finder": FreeDetector()},
             "hole"    : {"Hole Finder": HoleDetector()}}
interpolator = Interpolator()

calendars = [i.value for i in Calendars]
databases = [i.value for i in DataBases]
defects = [i.value for i in DefectTypes]
interpolation = [i.value for i in InterpolationMethods]


title_graph1 = " Defects Detected"
title_graph2 = " Defects Selected To Interpolate"
title_graph3 = " Interpolated Data"


feed_back_shutdown = "Connection Closed "
feed_back_selected = "New Selection Saved"
feed_back_cleared = "Cleared"
feed_back_interpolated = 'Interpolated'
feed_back_fetching = 'Fetching'
feed_back_nice_file = 'The file is alright for  outlier check'
feed_back_file_format = "Please select a xlsx or csv"
feed_back_not_pivotable = "Could not pivot data make sure that there is only one categorical data"
feed_back_detected = 'Outliers Detected'


place_holder_user_name = 'user name here'
place_holder_text_area = "Please input an sql, please make sure " \
                                      "that the first column is the dates for time series"
place_holder_password = 'password here'

stat_text_input_data = 'Please Input Some Data'
calendar_text = 'Calendar'

tab_text_login = 'login'
tab_text_outliers = "outliers"

doc_text = "Defects Detector"


button_text = 'Submit'
button_text_sql = "Upload from SQL"
button_text_file = "Upload from .csv / .xlsx"
button_text_pivot = "Pivot Table"
button_text_detect_out = 'Detect Outliers'
button_text_update = "Update"
button_text_close = "Close"
button_text_clear = "Clear"
button_text_interpolate = "Apply Correction"
button_text_save = "Save"
button_text_undo = "Undo"
output_date_format = "%Y-%m-%d"

default_file_name = 'output_file.csv'
default_file_name_ext = '_corrected'

short_cut_text = """
            Right Arrow : Next column / ticker
            Left Arrow  : Previous column / ticker
            Enter       : Triggers update button
            """
short_cut_tab_text = "short cuts"

