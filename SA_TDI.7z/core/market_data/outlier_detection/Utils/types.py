from enum import Enum


class DefectTypes(Enum):
    outlier = 'outlier'
    stale = 'stale'
    hole = 'hole'
    free = 'free'
    not_processed = 'not_processed'


class InterpolationMethods(Enum):
    linear = 'linear'
    cubic = 'cubic'
    remove = 'remove'
    level_correction = 'level correction'
    extrapolate = 'extrapolate'


class DataBases(Enum):
    infop = 'INFOP'
    info3d = 'INFO3D'
    default = infop


class Calendars(Enum):
    original = 'Original Calendar'
    mars = 'Mars Calendar'

