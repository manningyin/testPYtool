from core.utils import date_helper
from core.market_data.mars_helper import get_mars_dates_between
import pandas as pd
import numpy as np
from core.market_data.outlier_detection.Utils.types import Calendars


def pivot_df(df):
    index_c = df.columns[0]
    value_c = df._get_numeric_data().columns
    column_c = df.columns[1:].difference(value_c)[0]
    value_c = value_c[0]
    df = df.drop_duplicates()
    df = df.pivot(index=index_c, columns=column_c, values=value_c)
    df.insert(loc=0, column='Date', value=df.index.values)
    df = pd.DataFrame(df, columns=['Date']+date_helper.sort_tenors(list(df.columns.difference(['Date']))))
    return df


def process_df(df, calendar=None, conn=None):
    """
    This function makes sure that loaded dataframe is in the format we want
    i.e  -  index is dates
         -  columns are value
         -  dates are set according to the calendar
    :param df:
    :param calendar:
    :return:
    """
    first_column = df.columns[0]
    df.index = df[first_column]
    df.index = [date_helper.to_datetime(x) for x in df.index]
    df = df.drop(first_column, axis=1)

    if calendar is not None:
        if calendar == Calendars.mars.value:
            mars_dates = get_mars_dates_between(df.index[0], df.index[-1], conn)
            all_dates = df.index.union(mars_dates)
            df = df.reindex(all_dates)
        elif calendar == Calendars.original.value:
            pass
        else:
            raise Exception('Not known calendar')
    df.index.name = 'date'
    return df


def check_data_frame_in_format(df):
    df = df.copy()
    try:
        df = process_df(df)
        assert (df.columns == df._get_numeric_data().columns).all()
        return True
    except:
        return False


def fetch_excel(file_io):
    return pd.read_excel(file_io)


def fetch_csv(file_io):
    return pd.read_csv(file_io)


def fetch_sql(sql, conn):
    df = pd.read_sql(sql, conn)
    return df


def fetch_file(file_io, file_extension):
    if file_extension == '.xlsx':
        return fetch_excel(file_io)
    elif file_extension == '.csv':
        return fetch_csv(file_io)
    else:
        raise TypeError
