import pyodbc
from core.market_data.outlier_detection.Utils.types import DataBases
from core.connection import database_connect
import io
import sys


class as_stdin:
    def __init__(self, buffer):
        self.buffer = buffer
        self.original_stdin = sys.stdin

    def __enter__(self):
        sys.stdin = self.buffer

    def __exit__(self, *exc):
        sys.stdin = self.original_stdin


def connect_database():
    try:
        conn = pyodbc.connect(database_connect.get_string(DataBases.default.value))
        connection_status = True
        database = DataBases.default.default.value
    except:
        conn = None
        connection_status = False
        database = None

    return conn,connection_status, database


def credentials_to_database_connect(username, password, database='INFOP'):
    try:
        with as_stdin(io.StringIO(username + '\n' + password)):
            string = database_connect.get_string(database, manual_input=True)
        return string
    except:
        return None


def connect_database_with_password(database, user_name, password):
    string = credentials_to_database_connect(user_name, password, database)
    try:
        conn = pyodbc.connect(string)
        database = database
        connection_status = True
        print('connection success')
    except:
        print('connection failed')
        conn=None
        connection_status = False
        database = None
    return conn, database, connection_status


