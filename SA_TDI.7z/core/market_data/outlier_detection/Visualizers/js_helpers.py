from bokeh.models import  CustomJS
from os.path import join, dirname
from jinja2 import Environment, FileSystemLoader

html_js_files_path = join(dirname(__file__),"html_js_files")

def uploader_js(file_source):
    upload_js_code = open(join(html_js_files_path, "upload.js")).read()
    return CustomJS(args=dict(file_source=file_source), code=upload_js_code)


def downloader_js(source, filename, log=''):
    print('Ahmet yazio', log)
    download_js_code = open(join(html_js_files_path, "download.js")).read()
    return CustomJS(args=dict(source=source, filename=filename, logtext=str(log)), code=download_js_code)


def get_template_html():
    env = Environment(loader=FileSystemLoader(html_js_files_path))
    return env.get_template('template_html.txt')


def get_spinner_code():
    return open(join(html_js_files_path, "spinner_html.txt")).read()


def get_checkmark_code():
    return open(join(html_js_files_path, "checkmark.txt")).read()


def get_crossmark_code():
    return open(join(html_js_files_path, "crossmark.txt")).read()

