function table_to_csv(source) {
    c_list = source.data.column_sort[0]
    c_list = c_list.split(',')
    delete source.data.index
    delete source.data.column_sort
    console.log(source)
    console.log(c_list)
    const columns = c_list
    const nrows = source.get_length()
    const lines = [columns.join(',')]

    for (let i = 0; i < nrows; i++) {
        let row = [];
        for (let j = 0; j < columns.length; j++) {
            const column = columns[j]
            row.push(source.data[column][i].toString())
        }
        lines.push(row.join(','))
    }
    var out = lines.join('\n').concat('\n')
    return out
}

console.log(logtext)

// const filename = 'data_result.csv'
filetext = table_to_csv(source)

console.log("Ahmet here", filename)
const blob = new Blob([filetext], { type: 'text/csv;charset=utf-8;' })

//addresses IE
if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob, filename)
} else {
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = filename
    link.target = '_blank'
    link.style.visibility = 'hidden'
    link.dispatchEvent(new MouseEvent('click'))
}

const blob_log = new Blob([logtext], { type: 'text/csv;charset=utf-8;' })

//addresses IE
if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob_log, "log.txt")
} else {
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob_log)
    link.download = 'log.txt'
    link.target = '_blank'
    link.style.visibility = 'hidden'
    link.dispatchEvent(new MouseEvent('click'))
}



