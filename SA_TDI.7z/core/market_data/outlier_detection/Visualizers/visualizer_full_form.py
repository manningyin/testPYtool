from bokeh.layouts import row, column
from bokeh.models.widgets import PreText, Select
from bokeh.plotting import figure
from bokeh.models.widgets import Button
import tornado.ioloop
from tornado.ioloop import IOLoop
from bokeh.application.handlers import FunctionHandler
from bokeh.application import Application
from bokeh.server.server import Server
from bokeh.models import HoverTool
import pandas as pd
from bokeh.models.widgets.inputs import TextAreaInput, PasswordInput, TextInput
from bokeh.models.widgets import Panel, Tabs
from bokeh.models.widgets import DataTable, DateFormatter, TableColumn
import base64
from io import BytesIO
from core.market_data.outlier_detection.Visualizers import js_helpers
import os.path
from bokeh.models import ColumnDataSource, CustomJS
from bokeh.models.widgets import Div
from core.market_data.outlier_detection.Utils.types import DefectTypes
from core.market_data.outlier_detection.Utils import connection_helper,  data_utils
from core.market_data.outlier_detection.Utils import configuration


class VisualizerFullForm:
    """
        Implements all the features on the web browser for ui
    """
    def __init__(self):
        self.log = {}
        self.raw_data = pd.DataFrame()
        self.action_count_df = pd.DataFrame()
        self.action_index = 0
        # Outliers: Data frame that carries info about data (output of automatic detectors)
        self.outliers = pd.DataFrame()
        self.cols = list()

        # SQL string that will be submitted to the form
        self.sql_str = ""

        # the sql connection
        self.conn, self.connection_status, self.database = connection_helper.connect_database()

        # All the detectors available (add here for more)
        self.detectors_dict = configuration.detectors
        self.defect_types = list(self.detectors_dict.keys())

        # Available calendars
        self.calendars = configuration.calendars
        self.databases = configuration.databases
        self.interpolator = configuration.interpolator
        self.interpolation_methods = self.interpolator.methods

        self.data = pd.DataFrame()
        self.interpolated_data = self.data.copy()
        self.output_mask = pd.DataFrame().reindex_like(self.data).fillna(False)
        self.selected_outliers = []

        self.file_name = configuration.default_file_name

    def load_data_from_df(self, df, calendar):
        self.data = data_utils.process_df(df, calendar, self.conn)
        self.interpolated_data = self.data.copy()
        self.output_mask = pd.DataFrame().reindex_like(self.data).fillna(False)
        self.outliers = pd.DataFrame().reindex_like(self.data).fillna(False)
        self.action_index = pd.Series([0]*len(self.data.columns), index=self.data.columns)
        self.action_count_df = pd.DataFrame().reindex_like(self.data).fillna(0)
        self.log = {col:[] for col in self.data.columns}

    def get_automatic_defects(self, defect_str, detector_str, col=None):
        detector = self.detectors_dict[defect_str][detector_str]
        if col is None:
            self.outliers = detector.get_mask(self.data)
        else:
            self.outliers.loc[:,col] = detector.get_mask(self.data.iloc[:, col])

    def get_defect_filter(self, col):
        """
        Returns the filtering dataframe (true/false) given the type of the defect using self.outlier
        :param col: the column to get the filter
        :param outlier_type: the type of the defect to get (outlier, stale of free) (free selects all)
        :return: returns a boolean pandas series showing if the point is an outlier
        """
        outliers = (self.outliers[col] == True)
        return outliers

    def get_filtered_data(self, col, outlier_type):
        """
        Retunrs the values for given defects
        :param col:
        :param outlier_type:
        :return:
        """
        data = self.get_data(col)  # get data of that column
        if outlier_type == DefectTypes.hole.value:
            my_min = self.data[col].min()
            data = data[self.get_defect_filter(col) == True].copy().fillna(my_min)
            return data
        return data[self.get_defect_filter(col) == True].copy()

    def get_data(self, t1):
        """
        Given column name retunrn the data
        :param t1:
        :return:
        """
        data = self.data[[t1]].copy()
        data['t1'] = self.data[t1]
        data['t2'] = self.data[t1]
        data['t3'] = self.interpolated_data[t1]
        return data

    def reset_object(self):
        for detection_type in self.defect_types:
            for detector in self.detectors_dict[detection_type].values():
                detector.reset()

    def visualize_doc(self, doc):
        """
        Creates the form to be shown on the browser
        :param doc:
        """
        # Some constants that decide the layout
        plot_width = 1000
        plot_height = 250

        def detect_defect(**kwargs):
            print('getting outliers')
            defect = defect_ticker.value
            detector = detector_ticker.value
            self.get_automatic_defects(defect, detector, **kwargs)

        def show_spinner():
            print('spinning')
            div_spinner.text = js_helpers.get_spinner_code()

        def hide_spinner():
            print('spinning done')
            div_spinner.text = ""

        def check():
            print('check mark')
            div_check_cros.text = js_helpers.get_checkmark_code()

        def cross():
            print('cross mark')
            div_check_cros.text = js_helpers.get_crossmark_code()

        def set_all_visibility(val=True):
            """
            Sets the visibilitity of
            :param val:
            :return:
            """
            for i in all_gl:
                i.visible = val

        def update_in_selected(selected_indices):
            """
            Updates when selection changes
            :param selected_indices:
            :return:
            """
            col = column_ticker.value
            defect_type = defect_ticker.value
            data = self.get_data(col)
            selected = selected_indices
            already_selected = list((self.output_mask[self.output_mask[col] == True]).index)
            data_outliers = data[(self.get_defect_filter(col) == True)]
            if (len(selected+already_selected) > 0):
                selected_data = data.loc[list(data_outliers.index[selected]) + already_selected, :]
            else:
                selected_data = data.iloc[:0, :]
            source_outlier_chosen.data = source_outlier_chosen.from_df(selected_data[['t1', 't2', 't3']])

        def column_ticker_change(attrname, old, new):
            update()
            update_in_selected([])

        def defect_ticker_change(attrname, old, new):
            options = list(self.detectors_dict[defect_ticker.value].keys())
            detector_ticker.options = options
            detector_ticker.value = options[0]
            detect_defect()
            update()
            update_in_selected([])

        def update(selected=None):
            """
            Updates all graphs
            :param selected:
            :return:
            """
            columns_name = column_ticker.value
            outlier_type = defect_ticker.value
            if columns_name == "":
                return

            # Get the data
            data = self.get_data(columns_name)
            data_outliers = self.get_filtered_data(columns_name, outlier_type)  # get data which is set as defect

            # Update First and Second graph
            source_static_outlier.data = source_static_outlier.from_df(data_outliers[['t1', 't2', 't3']])
            source_static.data = source_static.from_df(data[['t1', 't2', 't3']])

            # Change titles of figures
            ts1.title.text = columns_name + configuration.title_graph1
            ts2.title.text = columns_name + configuration.title_graph2
            ts3.title.text = columns_name + configuration.title_graph3

            # Change statistics text and give update
            # stats.text = str(data[[columns_name, columns_name]].describe())
            feedback.text = "updated"


            set_all_visibility(True)

        def selection_change(attr, old, new):
            # pass
            s = source_static_outlier.selected.indices
            # update_in_selected(s)
            self.selected_outliers = s

        def button_close_clicked():
            """
            Stops the loop when close button clicked and the main code where the Visualizer object is called goes on
            :return:
            """
            tornado.ioloop.IOLoop.instance().stop()
            feedback.text = configuration.feed_back_shutdown

        def button_update_clicked(**kwargs):
            """
            Writes selection on output_mask
            :return:
            """
            t1 = column_ticker.value
            self.output_mask[t1].loc[source_static_outlier.data['date'][self.selected_outliers]] = True
            self.action_index[t1] += 1
            self.action_count_df[t1].loc[source_static_outlier.data['date'][self.selected_outliers]] = self.action_index[t1]
            feedback.text = configuration.feed_back_selected
            update_in_selected(self.selected_outliers)

        def button_undo_clicked():
            t1 = column_ticker.value
            self.output_mask[t1].loc[self.action_count_df[t1] == self.action_index[t1]] = False
            self.action_index[t1] -= 1
            update_in_selected([])
            # self.action_count_df.loc[source_static_outlier.data['date'][self.selected_outliers]] = self.action_index

        def button_clear_clicked():
            """
            Clears selection and output mask
            :return:
            """
            t1 = column_ticker.value
            self.output_mask[t1] = False
            self.interpolated_data[t1] = self.data[t1]
            update()
            feedback.text = configuration.feed_back_cleared
            # Clear selection
            update_in_selected([])
            self.log[t1] = []
            button_save.callback = js_helpers.downloader_js(interpolated_source, self.file_name, self.log)

        def button_interpolate_clicked():
            """
            Creates interpolation
            :return:
            """
            method = interpolation_ticker.value
            col = column_ticker.value

            selected_indexes = (self.output_mask == True)[col]
            self.interpolated_data = \
                self.interpolator.interpolate_data_frame(self.interpolated_data, method, col, selected_indexes)

            to_download = self.interpolated_data.copy()
            to_download['Date'] = self.interpolated_data.index.strftime(configuration.output_date_format)
            columns_sort_str = "Date," + ",".join(self.interpolated_data.columns)
            to_download['column_sort'] = columns_sort_str
            interpolated_source.data = interpolated_source.from_df(to_download)
            update()
            feedback.text = configuration.feed_back_interpolated
            self.log[col].append({'method':method, 'indexes': selected_indexes[selected_indexes==True].index})
            button_save.callback = js_helpers.downloader_js(interpolated_source, self.file_name, self.log)

        def button_load_sql_data_clicked():
            self.reset_object()
            self.output_mask = pd.DataFrame().reindex_like(self.data).fillna(False)

            loading_text.text = configuration.feed_back_fetching
            show_spinner()
            sql_str = text_area.value
            calendar = calendar_ticker.value

            try:
                data = data_utils.fetch_sql(sql_str, self.conn)
            except Exception as e:
                data = pd.DataFrame()
                loading_text.text = str(e)

            hide_spinner()
            self.raw_data = data
            update_table(data)

            if data_utils.check_data_frame_in_format(data):
                print('The file is alright for  outlier check')
                loading_text.text = configuration.feed_back_nice_file
                self.load_data_from_df(data, calendar)
                defect_type = self.defect_types[0]
                defect_ticker.value = defect_type
                detector_ticker.options = list(self.detectors_dict[defect_type].keys())
                detector_ticker.value = list(self.detectors_dict[defect_type].keys())[0]
                update_loaded_data()
            else:
                cross()
            self.file_name = configuration.default_file_name
            button_save.callback = js_helpers.downloader_js(interpolated_source, self.file_name, self.log)

        def get_file_io_from_file_source():
            file_name = file_source.data['file_name'][0]
            print('filename:', file_name)
            file_extension = os.path.splitext(file_name)[1]
            raw_contents = file_source.data['file_contents'][0]

            # remove the prefix that JS adds
            prefix, b64_contents = raw_contents.split(",", 1)
            file_contents = base64.b64decode(b64_contents)
            file_io = BytesIO(file_contents)
            return file_extension, file_io, file_name

        def button_file_upload_clicked(attr, old, new):
            self.reset_object()
            loading_text.text = configuration.feed_back_fetching
            calendar = calendar_ticker.value
            file_extension, file_io, file_name = get_file_io_from_file_source()

            try:
                data = data_utils.fetch_file(file_io, file_extension)

            except TypeError:
                loading_text.text = configuration.feed_back_file_format
                data = None

            self.raw_data = data
            if data_utils.check_data_frame_in_format(data):
                print('The file is alright for  outlier check')
                loading_text.text = configuration.feed_back_nice_file
                self.load_data_from_df(data, calendar)
                defect_type = self.defect_types[0]
                defect_ticker.value = defect_type
                detector_options = list(self.detectors_dict[defect_type].keys())
                detector_ticker.options = detector_options
                detector_ticker.value = detector_options[0]
                update_loaded_data()
            else:
                update_table(data)
                cross()



            self.file_name = "{0}{1}{2}".format(file_name, configuration.default_file_name_ext, file_extension)
            button_save.callback = js_helpers.downloader_js(interpolated_source, self.file_name, self.log)

        def button_pivot_clicked():
            try:
                data = data_utils.pivot_df(self.raw_data)
                self.raw_data = data
                calendar = calendar_ticker.value
                if data_utils.check_data_frame_in_format(data):
                    print('The file is alright for  outlier check')
                    loading_text.text = configuration.feed_back_nice_file
                    self.load_data_from_df(data, calendar)
                    update_loaded_data()
                else:
                    cross()
            except:
                loading_text.text = configuration.feed_back_not_pivotable

        def update_table(df):
            source_all_data.data = ColumnDataSource(df.head()).data
            changed_column_on_table = [TableColumn(field=name, title=name) for name in source_all_data.column_names]
            data_table.columns = changed_column_on_table

        def update_loaded_data():
            source_all_data.data = ColumnDataSource(self.data.head()).data
            changed_columns_date = [TableColumn(field="date", title="Date", formatter=DateFormatter())]
            changed_column_on_table = changed_columns_date + \
                                      [TableColumn(field=name, title=name) for name in source_all_data.column_names[1:]]
            data_table.columns = changed_column_on_table
            loading_text.text = configuration.feed_back_fetching
            detect_defect()
            self.cols = list(self.data.columns)
            loading_text.text = configuration.feed_back_detected
            column_ticker.options = self.cols
            column_ticker.value = self.cols[0]
            update()
            hide_spinner()
            check()

        def button_activate_clicked():
            col = column_ticker.value
            detect_defect(col=col)

        def button_login_clicked():
            database = databases_ticker.value
            user_name = user_name_text.value
            password = password_text.value

            self.conn, self.database, self.connection_status = connection_helper\
                .connect_database_with_password(database,user_name,password)

            connection_success_text.text = "Connection Status : %s, Database: %s" %\
                                           (self.connection_status, self.database)

        file_source = ColumnDataSource({'file_contents': [], 'file_name': []})
        file_source.on_change('data', button_file_upload_clicked)

        interpolated_source = ColumnDataSource(self.interpolated_data)  # This is only used for downloading

        all_gl = []  # List of all the glyphs to set all visibility later
        source_static_outlier = ColumnDataSource(data=dict(date=[], t1=[], t2=[], t3=[]))  # Defects data
        source_static = ColumnDataSource(data=dict(date=[], t1=[], t2=[], t3=[]))  # All the data
        source_outlier_chosen = ColumnDataSource(data=dict(date=[], t1=[], t2=[], t3=[]))  # Selected data
        source_all_data = ColumnDataSource(self.data.head())

        # Login TAB

        databases_ticker = Select(value=self.databases[0], options=self.databases)
        user_name_text = TextInput(placeholder=configuration.place_holder_user_name)
        password_text = PasswordInput(placeholder=configuration.place_holder_password)
        submit_cred_button = Button(label=configuration.button_text, button_type='primary')
        submit_cred_button.on_click(button_login_clicked)
        connection_success_text = PreText(text="Connection Status : %s, Database: %s" %
                                                (self.connection_status, self.database))
        login_tab = Panel(child=row(column(user_name_text,password_text,submit_cred_button), databases_ticker,
                                    connection_success_text), title=configuration.tab_text_login, name='login_tab')

        # Input TAB

        loading_text = PreText(text=configuration.stat_text_input_data, width=500)
        text_area = TextAreaInput(rows=20, cols=150, value=self.sql_str, max_length=10 ** 5,
                                  placeholder=configuration.place_holder_text_area)
        button_load_sql_data = Button(label=configuration.button_text_sql, button_type="success")
        button_load_sql_data.on_click(button_load_sql_data_clicked)

        button_from_file_upload = Button(label=configuration.button_text_file, button_type="success")
        button_from_file_upload.callback = js_helpers.uploader_js(file_source)

        button_pivot_data = Button(label=configuration.button_text_pivot)
        button_pivot_data.on_click(button_pivot_clicked)

        calendar_ticker = Select(value=self.calendars[0], options=self.calendars)

        columns_on_table_date = [TableColumn(field="date", title="Date", formatter=DateFormatter())]
        columns_on_table = columns_on_table_date + \
                           [TableColumn(field=name, title=name) for name in source_all_data.column_names[1:]]
        data_table = DataTable(source=source_all_data, columns=columns_on_table, width=1100, height=280, id='helloo')
        div_spinner = Div(text="", width=5, height=1)
        div_check_cros = Div(text="", width=100, height=100)

        # EVERYTHING IN THE SECOND TAB

        # Statistics text
        stats = PreText(text='', width=500)
        # Feedback text
        feedback = PreText(text='abc', width=500)
        # Ticker to choose which column is shown
        # column_ticker = Select(value=self.cols[0], options=self.cols)
        column_ticker = Select(name='column_ticker')
        # Ticker to choose the interpolation method
        interpolation_ticker = Select(value=self.interpolation_methods[0], options=self.interpolation_methods)
        # Ticker to choose different defects to show
        defect_ticker = Select(value=self.defect_types[0], options=self.defect_types)

        # Ticker to choose automatic detector
        detector_ticker = Select(value=list(self.detectors_dict[self.defect_types[0]])[0], options=list(self.detectors_dict[self.defect_types[0]].keys()))



        # Selection on change
        source_static_outlier.selected.on_change('indices', selection_change)

        # Buttons

        button_activate_detection = Button(label=configuration.button_text_detect_out, button_type='danger')
        button_activate_detection.on_click(button_activate_clicked)

        button_update_filtered = Button(label=configuration.button_text_update, button_type="success", name="update_button")
        button_update_filtered.on_click(lambda: button_update_clicked(lol=5))

        button_close = Button(label=configuration.button_text_close, button_type="success")
        button_close.on_click(button_close_clicked)

        button_clear = Button(label=configuration.button_text_clear, button_type="success")
        button_clear.on_click(button_clear_clicked)

        button_interpolator = Button(label=configuration.button_text_interpolate, button_type="success")
        button_interpolator.on_click(button_interpolate_clicked)

        button_save = Button(label=configuration.button_text_save, button_type="success")
        button_save.callback = js_helpers.downloader_js(interpolated_source, self.file_name, self.log)

        button_undo = Button(label=configuration.button_text_undo, button_type="success", name="undo_button")
        button_undo.on_click(button_undo_clicked)

        # Figures
        # Tools on the graphs
        tools = 'pan,wheel_zoom,box_select,reset'
        ts1 = figure(plot_width=plot_width, plot_height=plot_height, tools=tools, x_axis_type='datetime',
                     active_drag="box_select", active_scroll='wheel_zoom')
        ts1.toolbar.logo = None
        all_gl.append(ts1.line('date', 't1', source=source_static))
        all_gl.append(ts1.circle('date', 't1', size=5, source=source_static_outlier, color='red'))

        ts1.add_tools(HoverTool(
            tooltips=[
                ('date', '@date{%F}'),
                ('value', '@t1'),
            ],
            formatters={
                'date': 'datetime',  # use 'datetime' formatter for 'date' field
            },

            # display a tooltip whenever the cursor is vertically in line with a glyph
            mode='mouse'
        ))
        tools = 'pan,box_zoom,reset'
        ts2 = figure(plot_width=plot_width, plot_height=plot_height, tools=tools, x_axis_type='datetime', active_drag="box_zoom")
        ts2.toolbar.logo = None
        ts2.x_range = ts1.x_range
        ts2.y_range = ts1.y_range
        all_gl.append(ts2.line('date', 't2', source=source_static))
        all_gl.append(ts2.circle('date', 't2', size=5, source=source_outlier_chosen, color='red'))

        tools = 'pan,wheel_zoom,box_select,reset'
        ts3 = figure(plot_width=plot_width, plot_height=plot_height, tools=tools, x_axis_type='datetime', active_drag="box_select")
        ts3.toolbar.logo = None
        ts3.x_range = ts1.x_range
        ts3.y_range = ts1.y_range
        all_gl.append(ts3.line('date', 't3', source=source_static))

        # ticker change funcs
        defect_ticker.on_change('value', defect_ticker_change)
        defect_ticker.js_on_change('value', CustomJS(args=dict(p=ts1), code="""
                                                                        p.reset.emit()
                                                                """))
        column_ticker.on_change('value', column_ticker_change)
        column_ticker.js_on_change('value', CustomJS(args=dict(p=ts1), code="""
                                                                p.reset.emit()
                                                        """))
        # set up layout TAB1

        row_tab1 = row(column(text_area, row(button_load_sql_data, PreText(), button_from_file_upload), row(loading_text, div_spinner)), row(PreText()),
                       column(calendar_ticker, div_check_cros))
        tab1 = Panel(child=column(row_tab1, data_table, button_pivot_data), title="input", name='input_tab')

        # set up layout TAB2

        widgets = column(column_ticker, stats, button_save, button_close)
        buttom_row = row(widgets, button_clear, button_undo)
        row1 = row(ts1, column(button_update_filtered, defect_ticker),column(PreText(width=100), PreText(width=100)), column(button_activate_detection, detector_ticker))
        row2 = row(ts2, feedback)
        row3 = row(ts3, column(button_interpolator, interpolation_ticker))
        tab2 = Panel(child=column(row1, row2, row3, buttom_row), title=configuration.tab_text_outliers, name='outlier_tab')

        # Short Keys Tab

        short_text = PreText(text=configuration.short_cut_text, width=1000)
        tab_short = Panel(child=column(short_text), title=configuration.short_cut_tab_text)

        tabs = Tabs(tabs=[tab1, tab2, login_tab, tab_short], name='my_tabs')
        doc.template = js_helpers.get_template_html()
        doc.add_root(tabs)
        doc.title = configuration.doc_text

        if len(self.raw_data) > 0 and data_utils.check_data_frame_in_format(self.raw_data):
            print('The file is alright for  outlier check')
            loading_text.text = configuration.feed_back_nice_file
            self.load_data_from_df(self.raw_data, calendar=None)
            defect_type = self.defect_types[0]
            defect_ticker.value = defect_type
            detector_ticker.options = list(self.detectors_dict[defect_type].keys())
            detector_ticker.value = list(self.detectors_dict[defect_type].keys())[0]
            update_loaded_data()
        update()

        # I set all visibility to False before getting input from the user
        set_all_visibility(False)

    def visualize(self):
        """
        Creates the loop of visualization
        :return:
        """
        io_loop = IOLoop.current()
        bokeh_app = Application(FunctionHandler(self.visualize_doc))
        server = Server({'/': bokeh_app}, io_loop=io_loop)
        server.start()
        print('Opening Bokeh application on http://localhost:5006/')
        io_loop.add_callback(server.show, "/")
        io_loop.start()
        io_loop.close()
        server.stop()