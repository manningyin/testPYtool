from core.system import dependency
dependency.outlier_detection_dependency_test()  # Test if user has required packages installed
from core.market_data.outlier_detection.Visualizers import visualizer_full_form

my_vis = visualizer_full_form.VisualizerFullForm()
my_vis.visualize()
interpolated_df = my_vis.interpolated_data

