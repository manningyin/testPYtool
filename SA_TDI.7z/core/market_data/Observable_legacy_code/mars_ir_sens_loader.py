# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 18:00:07 2017

@author: g46987
"""
import re
from copy import deepcopy

import core.connection.sqltool as sqltool
import core.utils.date_helper as dateutils
from core.market_data.Observable_legacy_code.loader import IndexedDemultiplexerSeries, Loader, \
    CachedObservableDefinitionProvider

interest_info = sqltool.query_single(
"""
SELECT
  i.INTEREST_ID         INTEREST_ID,
  i.NAME                INTEREST_NAME,
  i.CURRENCY_ID         CURRENCY_ID,
  c.DESCRIPTION         CURRENCY_DESCRIPTION,
  i.INTEREST_MARKET_ID  INTEREST_MARKET_ID,
  m.NAME                INTEREST_MARKET_NAME,
  i.INTEREST_ISSUER_ID  INTEREST_ISSUER_ID,
  i.UPDATE_PGM_ID       INTEREST_UPDATE_PGM_ID,
  i.UPDATE_DATETIME     INTEREST_UPDATE_DATETIME
FROM
  MARSP.INTEREST i
  JOIN MARSP.CURRENCY        c ON c.CURRENCY_ID        = i.CURRENCY_ID
  JOIN MARSP.INTEREST_MARKET m ON m.INTEREST_MARKET_ID = i.INTEREST_MARKET_ID
WHERE
  i.INTEREST_ID = %(interest_id)d
  ;
""",datetime_as_date_string=True)

term_info = sqltool.query_single(
"""
SELECT
  TERM_ID,
  NAME TERM_NAME,
  TERM_360_DAYS
FROM
  MARSP.TERM
WHERE
  TERM_ID='%(term_id)s'
  ;
""")

ladder_info = sqltool.query_single(
"""
SELECT
  LADDER_ID,
  NAME LADDER_NAME,
  DESCRIPTION LADDER_DESCRIPTION
FROM MARSP.LADDER
WHERE LADDER_ID = %(ladder_id)d
;
""")

ladder_terms_raw = sqltool.query_iterator(
"""
SELECT
  TERM_ID
FROM MARSP.LADDER_TERM
WHERE LADDER_ID = %(ladder_id)d
ORDER BY TERM_NO
;
""")

def ladder_terms(cursor,ladder_id):
  return [d["term_id"] for d in ladder_terms_raw(cursor=cursor,ladder_id=ladder_id)]


class MarsIRSensObservableDefinitionProvider(CachedObservableDefinitionProvider):
    pattern = re.compile(r"MARS_(?P<hs>HS)?IR_sens_(?P<name>[A-Z0-9-]+)(#(?P<variant>[ABC]))?(__(?P<ladder>[0-9.]+))?(_(?P<term>[0-9.]+[DMY]))?")
    variants={None:0,"A":0,"B":1,"C":2}
    
    def __init__(self,connection,hs_interest=None):
        CachedObservableDefinitionProvider.__init__(self)
        self.connection=connection
        self.interest_info_cache={}
        self.ladder_info_cache={}
        self.term_info_cache={}
        self.hs_interest=hs_interest
    
    def to_interest_id(self,interest_name,variant=None):
        try:
            return int(interest_name)
        except:
            cursor = self.connection.cursor()
            cursor.execute("SELECT INTEREST_ID FROM MARSP.INTEREST WHERE upper(NAME) = ? ORDER BY INTEREST_ID;",interest_name)
            rows = cursor.fetchall()
            if len(rows)==0:
                return None
            try:
                return rows[self.variants[variant]][0]
            except:
                return None
    def interest_info(self,interest_id):
        if interest_id in self.interest_info_cache:
            return deepcopy(self.interest_info_cache[interest_id])
        info = interest_info(cursor = self.connection.cursor(),interest_id=interest_id)
        if info is not None:
            d=dict(info.items())
            d["sql"]=["""SELECT
  i.INTEREST_ID         INTEREST_ID,
  i.NAME                INTEREST_NAME,
  i.CURRENCY_ID         CURRENCY_ID,
  c.DESCRIPTION         CURRENCY_DESCRIPTION,
  i.INTEREST_MARKET_ID  INTEREST_MARKET_ID,
  m.NAME                INTEREST_MARKET_NAME,
  i.INTEREST_ISSUER_ID  INTEREST_ISSUER_ID,
  i.UPDATE_PGM_ID       INTEREST_UPDATE_PGM_ID,
  i.UPDATE_DATETIME     INTEREST_UPDATE_DATETIME
FROM
  MARSP.INTEREST i
  JOIN MARSP.CURRENCY        c ON c.CURRENCY_ID        = i.CURRENCY_ID
  JOIN MARSP.INTEREST_MARKET m ON m.INTEREST_MARKET_ID = i.INTEREST_MARKET_ID
WHERE
  i.INTEREST_ID = %(interest_id)d
  ;"""%locals()]
            self.interest_info_cache[interest_id]=d
            return d
        return None
    
    def term_info(self,term_id):
        if term_id in self.term_info_cache:
            return self.term_info_cache[term_id]
        info = term_info(cursor = self.connection.cursor(),term_id=term_id)
        self.term_info_cache[term_id]=info
        return info
        
    def ladder_info(self,ladder_id):
        if ladder_id in self.ladder_info_cache:
            return self.ladder_info_cache[ladder_id]
        cursor = self.connection.cursor()
        info = dict(ladder_info(cursor=cursor,ladder_id=ladder_id).items())
        info["ladder_terms"]=ladder_terms(cursor,ladder_id)
        self.ladder_info_cache[ladder_id]=info
        return info
        
    def observable_definition(self,observable):
        if observable in self.cache:
            return deepcopy(self.cache[observable])
        m=self.pattern.match(observable)
        if m is None:
            return None
        interest_name=m.group("name")
        variant=m.group("variant")
        ladder=m.group("ladder")
        interest_id = self.to_interest_id(interest_name,variant)
        term=m.group("term")
        ladder_id=int(ladder)

        name = interest_name
        if term is not None:
            name+=" "+term
        info = self.new_definition(observable,name,"")
        info.update(dict(self.interest_info(interest_id).items()))
        
        curve_name = interest_name

        info["curve_name"]=curve_name
        info.update(self.ladder_info(ladder_id))
        info["sql"].append("""
        SELECT
          LADDER_ID,
          NAME LADDER_NAME,
          DESCRIPTION LADDER_DESCRIPTION
        FROM MARSP.LADDER
        WHERE LADDER_ID = %(ladder_id)d
        ;
        """ % locals())
        if term is None:
            v="" if variant is None else "__"+variant
            info["children_refs"]=["MARS_IR_sens_%s%s__%d_%s"%(interest_name,v,ladder_id,t) for t in info["ladder_terms"]]
            
        if term is not None:
            info["sql"].append("""
SELECT
  TERM_ID,
  NAME TERM_NAME,
  TERM_360_DAYS
FROM
  MARSP.TERM
WHERE
  TERM_ID='%(term)s'
;
"""%locals())
            info.update(self.term_info(term))
        ladder = " on %(ladder_name)s ladder"%info if "ladder_name" in info else ""
        info["description"]="%(interest_name)s %(term)s interest rates%(ladder)s"%locals()
        self.cache[observable]=info
        return deepcopy(info)
#            d=dict(name=observable,source_system="MARS",observable_class="Interest rate")
#            return d



# class ExtendedMarsIRSensObservableDefinitionProvider(MarsIRSensObservableDefinitionProvider):
#     pattern = re.compile(r"MARS_(?P<hs>HS)?IR(?P<as>AS)?_(?P<name>[A-Z0-9-]+)(__(?P<variant>[ABC]))?(__(?P<term>[0-9.]+[DMY]?))?")
#     variants={None:0,"A":0,"B":1,"C":2}
#
#     def __init__(self,connection,hs_interest=None):
#         CachedObservableDefinitionProvider.__init__(self)
#         self.connection=connection
#         self.interest_info_cache={}
#         self.ladder_info_cache={}
#         self.term_info_cache={}
#         self.hs_interest=hs_interest
#
#         od = self.new_definition("SC_ID","Scenario ID","MARS Scenario identifier")
#         od.update({"index_ref":"SC_ID","is_index":True})
#         self.define("SC_ID",od)
#
#         od = self.new_definition("START_DATE","Start date","MARS start date of a scenario")
#         od.update({"index_ref":"START_DATE","is_index":True})
#         self.define("START_DATE",od)
#
#         od = self.new_definition("END_DATE","End date","MARS end date of a scenario; identical to date observable")
#         od.update({"index_ref":"END_DATE","is_index":True})
#         self.define("END_DATE",od)
#
#     def observable_definition(self,observable):
#         if observable in self.cache:
#             return deepcopy(self.cache[observable])
#         m=self.pattern.match(observable)
#         if m is None:
#             return None
#         interest_name=m.group("name")
#         variant=m.group("variant")
#         interest_id = self.to_interest_id(interest_name,variant)
#         term=m.group("term")
#         if term is None:
#             ladder_id=None
#         else:
#             try:
#                 ladder_id=int(term)
#                 term=None
#             except ValueError:
#                 ladder_id=None
#
#         hs=m.group("hs")
#         hs = "" if hs is None else hs
#         if self.hs_interest is not None:
#             if self.hs_interest and hs=="":
#                 return None
#             if not self.hs_interest and hs!="":
#                 return None
#         name = interest_name
#         if term is not None:
#             name+=" "+term
#         if hs!="":
#             name+=" (Hs.)"
#         ashock=m.group("as")
#         ashock = "" if ashock is None else ashock
#         if ashock!="":
#             name = "Abs. shocks "+name
#
#         info = self.new_definition(observable,name,"")
#         info.update(dict(self.interest_info(interest_id).items()))
#
#         curve_name = interest_name
#         if hs!="":
#             name+=" Hs."
#         if ashock!="":
#             curve_name = "Abs. shocks "+curve_name
#         info["curve_name"]=curve_name
#
#         if ladder_id is not None:
#             info.update(self.ladder_info(ladder_id))
#             info["sql"].append("""
# SELECT
#   LADDER_ID,
#   NAME LADDER_NAME,
#   DESCRIPTION LADDER_DESCRIPTION
# FROM MARSP.LADDER
# WHERE LADDER_ID = %(ladder_id)d
# ;
# """%locals())
#             v="" if variant is None else "__"+variant
#             info["children_refs"]=["MARS_%sIR%s_%s%s__%s"%(hs,ashock,interest_name,v,t) for t in info["ladder_terms"]]
#
#         if term is not None:
#             info["sql"].append("""
# SELECT
#   TERM_ID,
#   NAME TERM_NAME,
#   TERM_360_DAYS
# FROM
#   MARSP.TERM
# WHERE
#   TERM_ID='%(term)s'
# ;
# """%locals())
#             info.update(self.term_info(term))
#         ladder = " on %(ladder_name)s ladder"%info if "ladder_name" in info else ""
#         historical = "Historical " if hs == "HS" else ""
#         info["is_hs_interest"]=hs == "HS"
#         info["description"]="%(historical)s%(interest_name)s %(term)s interest rates%(ladder)s"%locals()
#         if ashock!="":
#             info["description"] = "One day absolute shocks of "+info["description"]
#         if ashock!="":
#             v="" if variant is None else "__"+variant
#             t=m.group("term")
#             info["original_ref"] = "MARS_%(hs)sIR_%(interest_name)s%(v)s__%(t)s"%locals()
#             info["is_shock"]=True
#         else:
#             v="" if variant is None else "__"+variant
#             t=m.group("term")
#             info["shock_ref"] = "MARS_%(hs)sIRAS_%(interest_name)s%(v)s__%(t)s"%locals()
#             info["is_shock"]=False
#
#         self.cache[observable]=info
#         return deepcopy(info)


class MarsIRSensSeries(IndexedDemultiplexerSeries):
    def __init__(self,observables,connection,from_date=None,to_date=None,observable_definition_provider=None,table="INTEREST_RATE",database=None):
        self._observables = observables[:]
        self._observable_definition_provider = MarsIRSensObservableDefinitionProvider(connection) if observable_definition_provider is None else observable_definition_provider
        self.connection=connection
        self.database=database
        self.observable_definitions = [self._observable_definition_provider.observable_definition(o) for o in observables]
        self.interest_ids = sorted(list(set(od["interest_id"] for od in self.observable_definitions if od is not None and "interest_id" in od)))
        self.term_ids = list(set(od["term_id"] for od in self.observable_definitions if od is not None and "term_id" in od))
        self.ladder_id = list(set(od["ladder_id"] for od in self.observable_definitions if od is not None and "ladder_id" in od))
        term_list = ", ".join(map(repr,self.term_ids))
        interest_list=", ".join(map(repr,self.interest_ids))
        date_condition=sqltool.date_between_condition(from_date=from_date,to_date=to_date,and_prefix=True, field="a.EOD_DATE")
        assert("date" in observables)
        self.date_index = observables.index("date")
        #ladder_id = self.ladder_id
        def get_key(od):
            try:
                return (int(od["interest_id"]),od["term_id"])
            except:
                return None
        self.column_index=dict((get_key(od),i) for i,od in enumerate(self.observable_definitions))
        self.table=table
        ladder_id = self.ladder_id[0]
        cons_org_id = 241471
        self.sql="""
SELECT   a.eod_date
        , f.term_id
        , a.interest_id
        , sum(a.sens_base * e.wgt) AS sens_base
           FROM marsp.interest_sens a
        JOIN marsp.cons_org_structure_std b
             ON a.org_id      = b.org_id
          AND b.cons_org_id = %(cons_org_id)d
        JOIN marsp.position_supergrp_position_grp c
             ON c.position_grp_id    = a.position_grp_id
          AND c.position_supergrp_id = 'FC'
        JOIN marsp.interest d
             ON d.interest_id = a.interest_id
        JOIN marsp.ladder_term_wgt e
             ON e.eod_date   = a.eod_date
          AND e.term_id      = a.term_id
          AND e.to_ladder_id = %(ladder_id)d
        JOIN marsp.ladder_term f
             ON e.to_ladder_id = f.ladder_id
          AND f.term_id        = e.to_term_id
          AND f.term_id in (%(term_list)s)
      WHERE  a.INTEREST_ID IN (%(interest_list)s)
        %(date_condition)s
        GROUP BY a.EOD_DATE, a.interest_id, f.term_id, f.term_no
      ORDER BY a.EOD_DATE, a.interest_id, f.term_no
"""%locals()
        self.source = {
          "loader_class":"MarsIRSensLoader",
          "loader_description":"mars interest rates sens",
          "from_date":from_date,
          "to_date":to_date,
          "observables":observables,
          "sources":[],
          "sql":self.sql,
          "sql_table":None
        }
    def get_index(self,raw_data_element):
        return raw_data_element[0]
    def process_raw_data(self,raw_data_element,row):
        date,term_id,interest_id, sens_base = raw_data_element
        date = dateutils.date_format(date)
        interest_id=int(interest_id)
        sens_base=float(sens_base)
        
        modified=False
        row[self.date_index]=date
        
        index=self.column_index.get((interest_id,term_id))
        if index is not None:
            row[index]=sens_base
            modified=True
        return row,modified
    def raw_data(self):
        cursor = self.connection.cursor()
        cursor.execute(self.sql)
        while True:
            row = cursor.fetchone()
            if row is None:
                break
            yield row
#
# class ExtendedMarsIRSeries(IndexedDemultiplexerSeries):
#     def __init__(self,observables,connection,from_date=None,to_date=None,observable_definition_provider=None,table="INTEREST_RATE",database=None):
#         self._observables = observables[:]
#         self._observable_definition_provider = MarsIRObservableDefinitionProvider(connection) if observable_definition_provider is None else observable_definition_provider
#         self.connection=connection
#         self.database=database
#         self.observable_definitions = [self._observable_definition_provider.observable_definition(o) for o in observables]
#         self.interest_ids = sorted(list(set(od["interest_id"] for od in self.observable_definitions if od is not None and "interest_id" in od)))
#         self.term_ids = list(set(od["term_id"] for od in self.observable_definitions if od is not None and "term_id" in od))
#         term_list = ", ".join(map(repr,self.term_ids))
#         interest_list=", ".join(map(repr,self.interest_ids))
#         date_condition=sqltool.date_between_condition(from_date=from_date,to_date=to_date,and_prefix=True,field="e.EOD_DATE")
#         assert("date" in observables or "START_DATE" in observables or "END_DATE" in observables or "SC_ID" in observables)
#
#         def get_key(od):
#             try:
#                 return (int(od["interest_id"]),od["term_id"])
#             except:
#                 return None
#         self.column_index=dict((get_key(od),i) for i,od in enumerate(self.observable_definitions) if not od.get("is_shock",False))
#         self.shock_column_index=dict((get_key(od),i) for i,od in enumerate(self.observable_definitions)  if od.get("is_shock",False))
#         self.table=table
#         self.sql="""
# SELECT
#   TIMEINTERVAL_ID SC_ID,
#   START_DATE,
#   END_DATE,
#   e.INTEREST_ID   INTEREST_ID,
#   e.TERM_ID       TERM_ID,
#   s.INTEREST_PCT  START_INTEREST_PCT,
#   e.INTEREST_PCT  END_INTEREST_PCT
# FROM
#   MARSP.%(table)s e,
#   MARSP.%(table)s s,
#   MARSP.TIMEINTERVAL t
# WHERE
#   e.TERM_ID IN (%(term_list)s)
#   AND e.INTEREST_ID IN (%(interest_list)s)
#   %(date_condition)s
#   AND t.START_DATE  = s.EOD_DATE
#   AND t.END_DATE    = e.EOD_DATE
#   AND s.INTEREST_ID = e.INTEREST_ID
#   AND s.TERM_ID     = e.TERM_ID
# ORDER BY END_DATE
# """%locals()
#         self.source = {
#           "loader_class":"ExtendedMarsIRLoader",
#           "loader_description":"extended mars interest rates - with scenario id and shocks",
#           "from_date":from_date,
#           "to_date":to_date,
#           "observables":observables,
#           "sources":[],
#           "sql":self.sql,
#           "sql_table":self.table
#         }
#     def get_index(self,raw_data_element):
#         return raw_data_element[0]
#     def process_raw_data(self,raw_data_element,row):
#         scid,start_date,date,interest_id,term_id,start_rate,end_rate = raw_data_element
#         date = dateutils.date_format(date)
#         start_date = dateutils.date_format(start_date)
#         interest_id=int(interest_id)
#         start_rate=float(start_rate)
#         end_rate=float(end_rate)
#         observables = self._observables
#         if "date" in observables:
#             row[observables.index("date")]=date
#         if "START_DATE" in observables:
#             row[observables.index("START_DATE")]=start_date
#         if "END_DATE" in observables:
#             row[observables.index("END_DATE")]=date
#         if "SC_ID" in observables:
#             row[observables.index("SC_ID")]=scid
#
#         modified=False
#
#         index=self.column_index.get((interest_id,term_id))
#         if index is not None:
#             try:
#                 row[index]=end_rate
#                 modified=True
#             except:
#                 pass
#         index=self.shock_column_index.get((interest_id,term_id))
#         if index is not None:
#             try:
#                 row[index]=end_rate-start_rate
#                 modified=True
#             except:
#                 pass
#         return row,modified
#     def raw_data(self):
#         cursor = self.connection.cursor()
#         cursor.execute(self.sql)
#         while True:
#             row = cursor.fetchone()
#             if row is None:
#                 break
#             yield row
            
class MarsIRSensLoader(Loader):
    def __init__(self,connection,database=None,hs_interest=False):
        print connection
        self.connection=connection
        self.database=database
        self.is_hs_interest = hs_interest
        self._observable_definition_provider=MarsIRSensObservableDefinitionProvider(connection,hs_interest=hs_interest)
    def get(self,from_date=None,to_date=None,observables=[]):        
        return MarsIRSensSeries(observables,self.connection,from_date=from_date,to_date=to_date,database=self.database,table=None,observable_definition_provider=self.observable_definition_provider())
    def get_inter(self,from_date=None,to_date=None,observables=[]):
        for row in self.get(observables=observables,from_date=from_date,to_date=to_date).data():
            yield row    
    def observable_definition_provider(self):
        return self._observable_definition_provider
    def supports(self,observable):
        od = self._observable_definition_provider.observable_definition(observable)
        if od is not None and "is_hs_interest" in od:
            return od["is_hs_interest"] == self.is_hs_interest
        return False        
    def __str__(self):
        return "MARS Historical Interest Rate Sens Loader" if self.is_hs_interest else "MARS Interest Rate Loader"
    def __repr__(self):
        return "MarsIRSensLoader(database=%s)"%(repr(self.database),repr(self.is_hs_interest))
    def source(self,from_date=None,to_date=None,observables=[]):
        return self.get(observables=observables,from_date=from_date,to_date=to_date).source
#
# class ExtendedMarsIRLoader(Loader):
#     def __init__(self,connection,database=None,hs_interest=False):
#         self.connection=connection
#         self.database=database
#         self.is_hs_interest = hs_interest
#         self.table = "HS_INTEREST_RATE" if hs_interest else "INTEREST_RATE"
#         self._observable_definition_provider=ExtendedMarsIRObservableDefinitionProvider(connection,hs_interest=hs_interest)
#     def get(self,from_date=None,to_date=None,observables=[]):
#         return ExtendedMarsIRSeries(observables,self.connection,from_date=from_date,to_date=to_date,database=self.database,table=self.table,observable_definition_provider=self.observable_definition_provider())
#     def get_inter(self,from_date=None,to_date=None,observables=[]):
#         for row in self.get(observables=observables,from_date=from_date,to_date=to_date).data():
#             yield row
#     def observable_definition_provider(self):
#         return self._observable_definition_provider
#     def supports(self,observable):
#         od = self._observable_definition_provider.observable_definition(observable)
#         if od is not None and "is_hs_interest" in od:
#             return od["is_hs_interest"] == self.is_hs_interest
#         return False
#     def __str__(self):
#         return "Extended MARS Historical Interest Rate Loader" if self.is_hs_interest else "Extended MARS Interest Rate Loader"
#     def __repr__(self):
#         return "ExtendedMarsIRLoader(database=%s,hs_interest=%s)"%(repr(self.database),repr(self.is_hs_interest))
#     def source(self,from_date=None,to_date=None,observables=[]):
#         return self.get(observables=observables,from_date=from_date,to_date=to_date).source