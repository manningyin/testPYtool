# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 16:22:22 2017

@author: g46987
"""
import numpy as np
import json
import traceback
import pandas as pd
from copy import deepcopy

class ObservableDefinition:
    def __init__(self,data):
        self.data = data
    def json(self):
        return json.dumps(self.data)
        
class ObservableDefinitionProvider:
    date_observable_definition={
          "observable_ref":"date",
          "name":"Date",
          "description":"Date index (EOD date)",
          "index_ref":"date",
          "is_index":True
    }    
    def new_definition(self,observable,name=None,description=None):
        name = observable if name is None else name
        description = observable if description is None else description
        
        return {
          "observable_ref":observable,
          "name":name,
          "description":description,
          "index_ref":"date",
          "is_index":False
          }

    def expand_query(self,query, full_expansion=True):
        observables=[]
        has_index=False
        for q in query.split():
            for o in q.split("~"):
                if full_expansion:
                    for observable in self.expand_iter(o):
                        if observable not in observables:
                            has_index = has_index or self.is_index(observable)
                            observables.append(observable)
                else:
                    observables.append(o)
        if len(observables) and not has_index:
            observables = [self.default_index(observables)]+observables
        return observables
        
    def is_index(self,observable):
        od = self.observable_definition(observable)
        if od is None:
            return False        
        return od.get("is_index",False)

    def default_index(self,observables=None):
        if observables is None:
            return "date"            
        for o in observables:
            od = self.observable_definition(o)
            if "index_ref" in od:
                return od["index_ref"]
        return "date"            
        
    def expand_iter(self,observable):
        od = self.observable_definition(observable)
        if od is not None:
            if "children_refs" in od:
                for c in od["children_refs"]:
                    for o in self.expand(c):
                        yield o
            else:
                yield observable
    def expand(self,observable):
        observables=[]
        for o in self.expand_iter(observable):
            if o not in observables:
                observables.append(o)
        return observables
    def define(self,observable,data):
        raise NotImplementedError

    def observable_definition(self,observable):
        return None

    def __add__(self,odp):
        return JoinObservableDefinitionProvider(self,odp)
        
class CachedObservableDefinitionProvider(ObservableDefinitionProvider):
    def __init__(self):
        self.cache={"date":self.date_observable_definition}

    def define(self,observable,data):
        self.cache[observable]=data

    def observable_definition(self,observable):
        if observable in self.cache:
            return deepcopy(self.cache[observable])
        return None

        
class JoinObservableDefinitionProvider(ObservableDefinitionProvider):
    def __init__(self,odp1,odp2):
        self.odp1=odp1
        self.odp2=odp2
    def observable_definition(self,observable):
        od = self.odp1.observable_definition(observable)
        if od is None:
            return self.odp2.observable_definition(observable)
        else:
            return od
        
_default_observable_definition_provider=None
def default_observable_definition_provider():
    global _default_observable_definition_provider
    if _default_observable_definition_provider is None:
        _default_observable_definition_provider = ObservableDefinitionProvider()
    return _default_observable_definition_provider
    
class Loader:
    def __init__(self):
        pass
    def query(self,query,from_date=None,to_date=None):
        observables = self.observable_definition_provider().expand_query(query)
        return self.get(from_date=from_date,to_date=to_date,observables=observables)
    def get(self,from_date=None,to_date=None,observables=[]):
        return LoaderSeries(self,from_date=from_date,to_date=to_date,observables=observables)
    def get_inter(self,from_date=None,to_date=None,observables=[]):
        return iter([])
    def observable_definition_provider(self):
        return default_observable_definition_provider()
    def supports(self,observable):
        return False
    def __str__(self):
        return ""
    def join(self,loader):
        return JoinLoader(self,loader)
    def __add__(self,loader):
        return self.join(loader)
    def source(self,from_date=None,to_date=None,observables=[]):
        return {
          "loader_class":self.__class__.__name__,
          "loader_description":str(self),
          "from_date":from_date,
          "to_date":to_date,
          "observables":observables,
          "sources":[]
        }
class JoinLoader(Loader):
    def __init__(self,loader1,loader2):
        Loader.__init__(self)
        self.loader1=loader1
        self.loader2=loader2
        odp = JoinObservableDefinitionProvider(loader1.observable_definition_provider(), loader2.observable_definition_provider())
        self._observable_definition_provider= odp
    def supports(self,observable):
        return self.loader1.supports(observable) or self.loader2.supports(observable)
    def get(self,from_date=None,to_date=None,observables=[]):
        index=observables[0]
        observables1=[index]+[o for o in observables if o!=index and self.loader1.supports(o)]
        observables2=[index]+[o for o in observables if o!=index and self.loader2.supports(o)]
        if len(observables1)>1 and len(observables2)>1:
            series1=self.loader1.get(from_date=from_date,to_date=to_date,observables=observables1)
            series2=self.loader2.get(from_date=from_date,to_date=to_date,observables=observables2)
            return JoinSeries(series1,series2,index=index,observables=observables, observable_definition_provider=self._observable_definition_provider)
        elif len(observables2)<=1:
            return self.loader1.get(from_date=from_date,to_date=to_date,observables=observables)
        else:
            return self.loader2.get(from_date=from_date,to_date=to_date,observables=observables)            
    def get_iter(self,from_date=None,to_date=None,observables=[]):
        for row in self.get(observables=observables,from_date=from_date,to_date=to_date).data():
            yield row    
    def observable_definition_provider(self):
        return self._observable_definition_provider
#    def supports(self,observable):
#        return self._observable_definition_provider.observable_definition(observable) is not None
    def __str__(self):
        return "Join loader of (%s) and (%s)"%(str(self.loader1),str(self.loader2))
    def __repr__(self):
        return "JoinLoader(%s,%s)"%(repr(self.loader1),repr(self.loader2))
    def source(self,from_date=None,to_date=None,observables=[]):
        return {
          "loader_class":self.__class__.__name__,
          "loader_description":str(self),
          "from_date":from_date,
          "to_date":to_date,
          "observables":observables,
          "sources":[self.get(from_date=from_date,to_date=to_date,observables=observables).source]
        }
        
class FilterLoader(Loader):
    def __init__(self,series):
        self.series=series
    def get(self,from_date=None,to_date=None,observables=[]):
        return FilterSeries(self.series,observables,from_date=from_date,to_date=to_date)
    def get_iter(self,from_date=None,to_date=None,observables=[]):
        for row in self.get(observables=observables,from_date=from_date,to_date=to_date).data():
            yield row    
    def observable_definition_provider(self):
        return self.series.observable_definition_provider()
    def supports(self,observable):
        return observable in self.series.observables()
    def source(self,from_date=None,to_date=None,observables=[]):
        return {
          "loader_class":self.__class__.__name__,
          "loader_description":str(self),
          "from_date":from_date,
          "to_date":to_date,
          "observables":observables,
          "sources":[self.series.source]
        }
        
class CsvLoader(FilterLoader):
    def __init__(self,f,observable_definition_provider=None):
        series = CsvSeries(f,observable_definition_provider=observable_definition_provider)
        FilterLoader.__init__(self,series)


class CachingLoader(Loader):
    def __init__(self,loader,observable_definition_provider=None):
        self.loader = loader
        self.cache  = DataFrameSeries()
    def get(self,from_date=None,to_date=None,observables=[]):
        all_observables_in_cache = self.cache.observables()
        requested_observables_in_cache = [o for o in observables if o in all_observables_in_cache]
        missing_observables = [o for o in observables if o not in all_observables_in_cache]
        for i,row in enumerate(self.loader.get_iter(from_date=from_date,to_date=to_date,observables=missing_observables)):
            if i < len(self.cache.df):
                for column,value in zip(missing_observables,row):
                    self.cache.df[column][i]=value
            else:
                rowdf = pd.DataFrame([row],columns=missing_observables)
                self.cache.df=self.cache.df.append(rowdf)
        df = pd.DataFrame(columns=observables)
        all_observables_in_cache = self.cache.observables()
        requested_observables_in_cache = [o for o in observables if o in all_observables_in_cache]
        for o in requested_observables_in_cache:
            df[o]=self.cache.df[o]
                
        series=DataFrameSeries(df,self.loader.observable_definition_provider())
        series.source=self.source(from_date=from_date,to_date=to_date,observables=observables)
        return series
    def get_iter(self,from_date=None,to_date=None,observables=[]):
        for row in self.get(observables=observables,from_date=from_date,to_date=to_date).data():
            yield row    
    def observable_definition_provider(self):
        return self.series.observable_definition_provider()
    def supports(self,observable):
        return observable in self.series.observables()
    def source(self,from_date=None,to_date=None,observables=[]):
        subsource=self.loader.source(from_date=from_date,to_date=to_date,observables=observables)
        return {
          "loader_class":self.__class__.__name__,
          "loader_description":"Cache of %s"%subsource["loader_description"],
          "from_date":from_date,
          "to_date":to_date,
          "observables":observables,
          "sources":[subsource]
        }
        
class SeriesMixin:
    def to_csv(self,f):
        f.write("date"+"".join(';%s'%str(name) for name in self.observables())+"\n")
        for row in self.data():
            f.write(";".join('"%s"'%str(value) for value in row)+"\n")
            
class Series(SeriesMixin):
    source=None
    def observables(self):
        return []
    def observable_definition_provider(self):
        return default_observable_definition_provider()
    def data(self):
        return []
    def df(self):
        d = list(map(tuple,self.data()))
        return pd.DataFrame.from_records(data=d,columns=self.observables())
    def __len__(self):
        return sum(1 for _ in self.data())

class LoaderSeries(SeriesMixin):
    def __init__(self,loader,observables,from_date=None,to_date=None):
        self.loader=loader
        self._observables = observables        
        self.from_date = from_date
        self.to_date = to_date
        self.source=loader.source(from_date=from_date,to_date=to_date,observables=observables)
    def observables(self):
        return self._observables[:]
    def observable_definition_provider(self):
        return self.loader.observable_definition_provider()
    def data(self):
        for row in self.loader.get_iter(observables=self._observables,from_date=self.from_date,to_date=self.to_date):
            yield row
    def __len__(self):
        return sum(1 for _ in self.data())
        
class FilterSeries(Series):
    def __init__(self,series,observables,from_date=None,to_date=None):
        self.series=series
        underlying_observables=series.observables()
        self._observables = observables        
        self.from_date =from_date
        self.to_date = to_date
        self.indices = [(i,underlying_observables.index(x)) for i,x in enumerate(self._observables) if x in underlying_observables]
    def observables(self):
        return self._observables[:]
    def observable_definition_provider(self):
        return self.series.observable_definition_provider()
    def data(self):
        indices = self.indices
        if "date" in self.series.observables():
            filter_dates = ((self.from_date is not None ) or (self.to_date is not None ))
            date_index = self.series.observables().index("date")
        else:
            filter_dates = False
        for original_row in self.series.data():
            if filter_dates:
                if self.from_date is not None:
                    if original_row[date_index] <self.from_date:
                        continue
                if self.to_date is not None:
                    if original_row[date_index] >self.to_date:
                        continue
            row = [None]*len(self._observables)
            for i,j in indices:
                row[i]=original_row[j]
            yield row
            
class MemorySeries(Series):
    def __init__(self,observables,data,observable_definition_provider=None):
        self._observables = observables[:]
        self._observable_definition_provider = default_observable_definition_provider() if observable_definition_provider is None else observable_definition_provider        
        self._data = data
        self.source = {
          "loader_class":"SeriesInMemory",
          "loader_description":"series in memory",
          "from_date":None,
          "to_date":None,
          "observables":observables,
          "sources":[]
        }
    def add_observable(self,observable):
        if observable not in self._observables:
            self._observables.append(observable)
            for i in range(len(self._data)):
                self._data[i].append(None)
        self.source["observables"]=self._observables[:]
    def observables(self):
        return self._observables
    def observable_definition_provider(self):
        return self._observable_definition_provider
    def data(self):
        return iter(self._data)
    def __len__(self):
        return len(self._data)

class CsvSeries(MemorySeries):
    def __init__(self,f,observable_definition_provider=None):
        headder=[h.strip() for h in f.readline().split(";")]
        data =[]
        while True:
            row = f.readline()
            if row =="":
                break
            try:
                v = [(None if x.strip() == "" else float(x.strip())) for x in row.split(";")]
                assert(len(v)==len(headder))
                data.append(v)
            except:
                pass
#                traceback.print_exc()
                
        observables = headder
        MemorySeries.__init__(self,observables,data=data,observable_definition_provider=observable_definition_provider)
        self.source = {
          "loader_class":"CsvSeries",
          "loader_description":"CSV series",
          "from_date":None,
          "to_date":None,
          "observables":observables,
          "file":str(f),
          "sources":[]
        }

class DataFrameSeries(Series):
    def __init__(self,df=None,observable_definition_provider=None):
        if df is None:
            df = pd.DataFrame()
        self._observable_definition_provider = default_observable_definition_provider() if observable_definition_provider is None else observable_definition_provider
        self.df=df
        self.source = {
          "loader_class":"DataFrameSeries",
          "loader_description":"Data-frame series",
          "from_date":None,
          "to_date":None,
          "observables":self.observables(),
          "sources":[]
        }

    def observables(self):
        return list(self.df.columns)
    
    def data(self):
        for row in self.df.iterrows():
            yield list(row[1].values)

class IndexedDemultiplexerSeries(Series):
    def __init__(self,observables,observable_definition_provider=None):
        self._observables = observables[:]
        self._observable_definition_provider = default_observable_definition_provider() if observable_definition_provider is None else observable_definition_provider        
        self.source = {
          "loader_class":"DemultiplexerSeries",
          "loader_description":"demultiplexer series - abstract source",
          "from_date":None,
          "to_date":None,
          "observables":observables,
          "sources":[]
        }
    def observables(self):
        return self._observables
    def observable_definition_provider(self):
        return self._observable_definition_provider
    def new_row(self):
        return [None]*len(self.observables())
    def get_index(self,raw_data_element):
        raise NotImplementedError
    def process_raw_data(self,raw_data_element,row):
        raise NotImplementedError
    def raw_data(self):
        raise NotImplementedError
    def data(self):
        empty = True
        initialized = False
        empty=True
        for raw_data_element in self.raw_data():
            if not initialized:
                row = self.new_row()
                empty=True
                index = self.get_index(raw_data_element)
                initialized=True

            new_index = self.get_index(raw_data_element)

            if new_index!=index:                
                yield row
                row = self.new_row()
                empty=True
                index=new_index
            row,modified = self.process_raw_data(raw_data_element,row)
            empty=not modified and empty
        if not empty:
            yield row

class IndexedDemultiplexer:
    def __init__(self):
        pass
    def new_output_object(self):
        return {}
    def get_index(self,raw_data_element):
        raise NotImplementedError
    def process_raw_data(self,raw_data_element,row):
        raise NotImplementedError
    def raw_data(self):
        raise NotImplementedError
    def data(self):
        initialized = False
        for raw_data_element in self.raw_data():
            if not initialized:
                row = self.new_output_object()
                empty=True
                index = self.get_index(raw_data_element)
                initialized=True

            new_index = self.get_index(raw_data_element)

            if new_index!=index:                
                yield row
                row = self.new_output_object()
                empty=True
                index=new_index
            row,modified = self.process_raw_data(raw_data_element,row)
            empty=not modified and empty
        if not empty:
            yield row
            
class JoinSeries(Series):
    def __init__(self,series1,series2,index=None,observables=None,observable_definition_provider=None):
        self.series1=series1
        self.series2=series2
        if observable_definition_provider is None:
            odp1=series1.observable_definition_provider()
            odp2=series2.observable_definition_provider()
            self._observable_definition_provider = JoinObservableDefinitionProvider(odp1,odp2)
        else:
            self._observable_definition_provider = observable_definition_provider
        observables1=self.series1.observables()
        observables2=self.series2.observables()

        if observables is None:
            observables = observables1[:]
            for i,o in enumerate(observables2):
                if i>0 and o not in observables:#first observable is expected to be an index
                    observables.append(o)
        self._observables=observables
        if index is None:
            index=series1.observables()[0]
        self.index1=observables1.index(index)
        self.index2=observables2.index(index)
        
        self.indices1=[(i,observables1.index(o)) for i,o in enumerate(observables) if o in observables1]
        self.indices2=[(i,observables2.index(o)) for i,o in enumerate(observables) if o in observables2]

        self.row1len  = len(observables1)
        self.row2len  = len(observables2)
        self.rowlen   = len(observables)
                       
        self.source = {
          "loader_class":"JoinSeries",
          "loader_description":"Joint series",
          "from_date":None,
          "to_date":None,
          "observables":self.observables(),
          "sources":[deepcopy(series1.source),deepcopy(series2.source)]
        }

    def observable_definition_provider(self):
        return self._observable_definition_provider

    def observables(self):
        return self._observables

    def row1only(self,row1):
        row=[None]*self.rowlen
        for i,j in self.indices1:
            row[i]=row1[j]
        return row

    def row2only(self,row2):
        row=[None]*self.rowlen
        for i,j in self.indices2:
            row[i]=row2[j]
        return row

    def row1and2(self,row1, row2):
        row=[None]*self.rowlen
        for i,j in self.indices2:
            row[i]=row2[j]
        for i,j in self.indices1: 
            if row1[j] is not None: # if both series 1 and 2 value is available, series 1 value should be used
                row[i]=row1[j]
        return row
        
    def advance1(self):
        if self.end1:
            return None,[None]*self.row1len
        try:
            row1=next(self.data1)
            return row1[self.index1],row1
        except StopIteration:
            self.end1=True
            return None,[None]*self.row1len

    def advance2(self):
        if self.end2:
            return None,[None]*self.row2len
        try:
            row2=next(self.data2)
            return row2[self.index2],row2
        except StopIteration:
            self.end2=True
            return None,[None]*self.row2len
        
    def data(self):
        self.end1=False
        self.end2=False
        self.data1  = self.series1.data()
        self.data2  = self.series2.data()
        
        i1,row1=self.advance1()
        i2,row2=self.advance2()
        while not (self.end1 and self.end2):
            if i1 == i2:
                yield self.row1and2(row1,row2)
                i1,row1=self.advance1()
                i2,row2=self.advance2()
            elif i1 is None or i1>i2:                
                yield self.row2only(row2)
                i2,row2=self.advance2()
            elif i2 is None or i2>i1:
                yield self.row1only(row1)
                i1,row1=self.advance1()
            else:
                assert(False) # This should not happen
                