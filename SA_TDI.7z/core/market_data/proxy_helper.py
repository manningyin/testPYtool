from core.connection import database_connect
from core.utils import dataframe_helper
import pandas as pd
import pyodbc
import datetime as dt
from pandas.tseries.offsets import BDay
from core.utils import date_helper


def get_interest_proxies(interest_ids, eod_date=dt.date.today()-BDay(1)):
    oracle_date = date_helper.oracle_to_date(eod_date)
    interest_id_list = ', '.join(map(str, interest_ids if isinstance(interest_ids, list) else [interest_ids]))
    sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.INTEREST_ID SPECIFIC_INTEREST_ID, E.name SPECIFIC_NAME, C.PROJECTION_INTEREST_ID, D.name PROJECTION_NAME
                    from MARSP.RM_INTEREST_GRP_MAPPING a, MARSP.RM_INTEREST_GRP B, MARSP.PROJECTION_INTEREST_MAPPING C, MARSP.INTEREST D, MARSP.INTEREST E
                    where RM_INTEREST_SUPERGRP_ID = 2
                    and a.INTEREST_ID in (%(interest_id_list)s)
                    and a.EOD_DATE = %(oracle_date)s
                    and a.RM_INTEREST_GRP_ID = B.RM_INTEREST_GRP_ID
                    and B.PROJECTION_ID = C.PROJECTION_ID
                    and a.INTEREST_ID = C.INTEREST_ID
                    and a.EOD_DATE = C.EOD_DATE
                    and C.PROJECTION_INTEREST_ID = D.INTEREST_ID
                    and C.INTEREST_ID = E.INTEREST_ID""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    df = dataframe_helper.transform_id_columns(df)
    return df


def get_equity_proxies(equity_ids, eod_date=dt.date.today()-BDay(1)):
    oracle_date = date_helper.oracle_to_date(eod_date)
    equity_id_list = ', '.join(map(str, equity_ids))
    sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.EQUITY_ID SPECIFIC_EQUITY_ID, E.name SPECIFIC_NAME, C.PROJECTION_EQUITY_ID, D.name PROJECTION_NAME
                    from MARSP.RM_EQUITY_GRP_MAPPING a, MARSP.RM_EQUITY_GRP B, MARSP.PROJECTION_EQUITY_MAPPING C, MARSP.EQUITY D, MARSP.EQUITY E
                    where RM_EQUITY_SUPERGRP_ID = 1
                    and a.EQUITY_ID in (%(equity_id_list)s)
                    and a.EOD_DATE = %(oracle_date)s
                    and a.RM_EQUITY_GRP_ID = B.RM_EQUITY_GRP_ID
                    and B.PROJECTION_ID = C.PROJECTION_ID
                    and a.EQUITY_ID = C.EQUITY_ID
                    and a.EOD_DATE = C.EOD_DATE
                    and C.PROJECTION_EQUITY_ID = D.EQUITY_ID
                    and C.EQUITY_ID = E.EQUITY_ID""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    df = dataframe_helper.transform_id_columns(df)
    return df


def get_spread_proxies(spreads, eod_date=dt.date.today()-BDay(1)):
    oracle_date = date_helper.oracle_to_date(eod_date)
    spread_id_list = ', '.join(map(str, spreads))
    sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.SPREAD_ID SPECIFIC_SPREAD_ID, E.name SPECIFIC_NAME, C.PROJECTION_SPREAD_ID, D.name PROJECTION_NAME
                    from MARSP.RM_SPREAD_GRP_MAPPING a, MARSP.RM_SPREAD_GRP B, MARSP.PROJECTION_SPREAD_MAPPING C, MARSP.SPREAD D, MARSP.SPREAD E
                    where RM_SPREAD_SUPERGRP_ID = 1
                    and a.SPREAD_ID in (%(spread_id_list)s)
                    and a.EOD_DATE = %(oracle_date)s
                    and a.RM_SPREAD_GRP_ID = B.RM_SPREAD_GRP_ID
                    and B.PROJECTION_ID = C.PROJECTION_ID
                    and a.SPREAD_ID = C.SPREAD_ID
                    and a.EOD_DATE = C.EOD_DATE
                    and C.PROJECTION_SPREAD_ID = D.SPREAD_ID
                    and C.SPREAD_ID = E.SPREAD_ID""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql_string, conn)
    df = dataframe_helper.transform_id_columns(df)
    return df


def get_vol_proxies(ids, vol_type, eod_date=dt.date.today()-BDay(1)):
    ids = ", ".join([str(i) for i in ids])
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    if vol_type == 'EQT':
        rm_supergrp = 5
        #names_str = "', '".join(map(str, ids if isinstance(ids, list) else [ids]))
        #tmp_sql = "select vol_id from MARSP.VOL a where a.name in ('%(names_str)s')" % locals()
        #ids = [int(x) for x in pd.read_sql(tmp_sql, conn)['VOL_ID'].tolist()]
        #ids = ', '.join(map(str, ids))
    elif vol_type == 'IR':
        rm_supergrp = 2
    elif vol_type == 'FX':
        rm_supergrp = 1
    else:
        raise NameError("Provided vol_type not recognized: %s" % vol_type)
    oracle_date = date_helper.oracle_to_date(eod_date)
    sql_string = """select C.EOD_DATE, C.PROJECTION_ID, C.VOL_ID SPECIFIC_VOL_ID, E.name SPECIFIC_NAME, C.PROJECTION_VOL_ID, D.name PROJECTION_NAME
                    from MARSP.RM_VOL_GRP_MAPPING a, MARSP.RM_VOL_GRP B, MARSP.PROJECTION_VOL_MAPPING C, MARSP.VOL D, MARSP.VOL E
                    where RM_VOL_SUPERGRP_ID = %(rm_supergrp)s
                    and a.VOL_ID in (%(ids)s)
                    and a.EOD_DATE = %(oracle_date)s
                    and a.RM_VOL_GRP_ID = B.RM_VOL_GRP_ID
                    and B.PROJECTION_ID = C.PROJECTION_ID
                    and a.VOL_ID = C.VOL_ID
                    and a.EOD_DATE = C.EOD_DATE
                    and C.PROJECTION_VOL_ID = D.VOL_ID
                    and C.VOL_ID = E.VOL_ID""" % locals()
    df = pd.read_sql(sql=sql_string, con=conn)
    df = dataframe_helper.transform_id_columns(df)
    return df


if __name__ == '__main__':
    # x = get_vol_proxies(["5555"], 'EQT')
    print(get_interest_proxies([8230,8231,8232,8233,8234,8236]))