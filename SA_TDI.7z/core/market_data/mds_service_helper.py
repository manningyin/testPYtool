"""
Some help function to get market data from market data service

Warning:
    <This section is optional. Please remove this comment line when you use the template>
    Please be aware that this modules DOES SOME IRREVERSIBLE STUFF or that is


Notes:
    Author: Johan
    Reviewer: Shengyao
"""


#TODO: define test on this module
#TODO: align with env handler

import requests  # required for POST request
from requests_ntlm import HttpNtlmAuth  # required for authentication
import getpass  # optional
from core.connection.credentials import get_HttpNtlmAuth


class MarketDataService(object):
    def __init__(self, env=None):
        if env is None:
            self.env = "http://mds.oneadr.net/v1"
        elif env == "prod":
            self.env = "http://mds.oneadr.net/v1"
        elif env == "test":
            self.env = "http://vda1cs1527/v1"
        else:
            print ("environment doesn't exist")

        self.auth = get_HttpNtlmAuth(())

    def getBondStatic(self, isin=None):
        server = self.env

        if isin is None:
            isin = []
        self.isin = isin

        serviceStaticBond = "instrument/coreinformation/bonds"
        payload = {'isins': self.isin}
        url = server + "/" + serviceStaticBond
        headers = {'content-type': 'application/json'}
        postreq = requests.post(url, headers=headers, json=payload,
                                auth=self.auth).json()
        return postreq

    def getBondKeyFigures(self, isin=None, TradeDate=None):
        if TradeDate is None:
            TradeDate = ""
        self.TradeDate = TradeDate

        if isin is None:
            isin = []
        self.isin = isin

        server = self.env
        serviceKeyFigures = "/marketdata/keyfigures/bonds"
        payload = {'isins': self.isin, 'TradeDate': self.TradeDate}
        url = server + "/" + serviceKeyFigures
        headers = {'content-type': 'application/json'}
        postreq = requests.post(url, headers=headers, json=payload,
                                auth = self.auth).json()
        return postreq

    def getCashFlow(self, isin=None):
        server = self.env

        if isin is None:
            isin = []
        self.isin = isin

        serviceCashFlow = "instrument/cashflow"
        payload = {'isins': self.isin}
        url = server + "/" + serviceCashFlow
        headers = {'content-type': 'application/json'}
        postreq = requests.post(url, headers=headers, json=payload,
                                auth=self.auth).json()
        return postreq

    def getRevalPrice(self, isin=None, TradeDate=None):
        server = self.env

        if isin is None:
            isin = []
        self.isin = isin

        if TradeDate is None:
            TradeDate = ""
        self.TradeDate = TradeDate

        serviceRevalPrice = "marketdata/prices/reval"
        payload = {'isins': self.isin, 'TradeDate': self.TradeDate}
        url = server + "/" + serviceRevalPrice
        headers = {'content-type': 'application/json'}
        postreq = requests.post(url, headers=headers, json=payload,
                                auth= self.auth).json()
        return postreq

    def getBondCurve(self, curveids=None, est_meth=None, tenors=None, all=None, FromDate=None, ToDate=None):
        server = self.env

        if curveids is None:
            curveids = []
        self.curveids = curveids

        if tenors is None:
            tenors = []
        self.tenors = tenors

        if all is None:
            all = False
        self.all = all

        if FromDate is None:
            FromDate = ""
        self.FromDate = FromDate

        if ToDate is None:
            ToDate = ""
        self.ToDate = ToDate

        if est_meth is None:
            self.est_meth = "nelsonsiegel"
        else:
            self.est_meth = est_meth

        self.est_meth = est_meth
        serviceBondCurve = "marketdata/datacurves/mortgagebonds"
        payload = {'curveids': self.curveids, 'tenors': self.tenors, 'all': self.all, 'FromDate': self.FromDate,
                   'ToDate': self.ToDate}
        estimationmethod = self.est_meth
        url = server + "/" + serviceBondCurve + "?" + estimationmethod
        headers = {'content-type': 'application/json'}
        postreq = requests.post(url, headers=headers, json=payload,
                                auth= self.auth).json()
        return postreq


    def getDayCountConvention(self, curveids=None):
        server = self.env

        if curveids is None:
            curveids = []
        self.curveids = curveids

        serviceDayCountConvention = "marketdata/datacurves/mortgagebonds/daycountconventions"
        payload = {'curveids': self.curveids}
        url = server + "/" + serviceDayCountConvention
        headers = {'content-type': 'application/json'}
        postreq = requests.post(url, headers=headers, json=payload,
                                auth=self.auth).json()
        return postreq


if __name__ == "__main__":
    environment = "prod"
    estimation_method = "nelsonsiegel"
    curve_list = ['DKKMTGNORDEA', 'DKKMTGNYKSOFTBLT','NOKGOV',
                  'DKKGOV', 'DKKMTGNYKREDIT', 'DKKMTGRD',
                  'DKKMTGNORDEA', 'DKKMTGNDASOFTBLT',
                  'DKKMTGNYKSOFTBLT']

    callMDS = MarketDataService(env=environment)
    for x in curve_list:
        getDCC = callMDS.getDayCountConvention(x)
        print(getDCC)

    #get_curves = callMDS.getBondCurve(curveids=curve_list, est_meth=estimation_method)
    #for i in range(0, len(get_curves['Result'])):
    #    print get_curves['Result'][i]['CurveId'], get_curves['Result'][i]['CurveRetrievalTimestamp'], \
    #    get_curves['Result'][i]['Data'][0]['DataSourceTimestamp']

    #getReval = callMDS.getRevalPrice(['SE0005965746'])
    #print getReval['Result'][0]['Price']

