"""
This module provides the user with the ability to load market data either for a specific asset class or specific source.

A general caching functionality is built into each loader found in the module, using the cache loader classes defined in
core.caching.abstract_loader_classes

Notes:
    Author: g48606

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       16mar2017   G48606      Initial creation
    ======= =========   =========   ========================================================================================
"""
from core.caching.abstract_loader_classes import MatrixLoader, SeriesLoader
from core.caching import cache_strategy, cache_format, cache_method
from core.market_data import mdh_helper, damd_helper
import pandas as pd
import mdh.lib


class BondCurve(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, curve_names, startd, endd, source):
        MatrixLoader.__init__(self, names=curve_names, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class BondPrice(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, isins, startd, endd, source):
        MatrixLoader.__init__(self, names=isins, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class BondFuturePrice(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, isins, startd, endd, source):
        MatrixLoader.__init__(self, names=isins, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class BondCashFlow(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, isins, startd, endd, source):
        MatrixLoader.__init__(self, names=isins, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class CDSSpread(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, curve_names, startd, endd, source):
        MatrixLoader.__init__(self, names=curve_names, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class IRCurve(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, curve_names, startd, endd, source):
        MatrixLoader.__init__(self, names=curve_names, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class FXSpot(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, currencies, startd, endd, source):
        MatrixLoader.__init__(self, names=currencies, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class BondStaticData(MatrixLoader):
    """
    Placeholder
    """
    def __init__(self, isins, startd, endd, source):
        MatrixLoader.__init__(self, names=isins, startd=startd, endd=endd, source=source)

    def source_loading_function(self, names, date):
        if self.source == 'DAMD':
            raise NotImplementedError
        elif self.source == 'MARS':
            raise NotImplementedError
        elif self.source == 'MDH':
            raise NotImplementedError
        elif self.source == 'MDS':
            raise NotImplementedError
        else:
            raise NotImplementedError


class FromDAMD(MatrixLoader):
    """
    Class for loading market data from DAMD (currently only able to load from DAMDS).

    It utilizes the MatrixLoader, to be able to determine whether data has been cached for each pair of market_data_id
    and date. The provided start and end date is included in the date range for loading.

    Args:
        market_data_ids  (str or list of str): Market data ids to load data for
        startd                         (date): Start scenario date for loading
        endd                           (date): End scenario date for loading
        shock_horizon                   (int): Which shock horizon to load for

    Returns:
        (pd.DataFrame):  DataFrame containing loaded market data

    Notes:
        Author: g48606
    """
    def __init__(self, market_data_ids, startd, endd, shock_horizon=1):
        self.shock_horizon = shock_horizon
        self.timeseries_type = damd_helper.TimeSeriesType.SHOCK
        self.unique_params = shock_horizon
        MatrixLoader.__init__(self, names=market_data_ids, startd=startd, endd=endd)
        self.data = damd_helper.output_to_df(self.data.values(), self.timeseries_type).sort_index()

    def source_loading_function(self, names, date):
        raw_out = damd_helper.load_from_damds(market_data_ids=names,
                                              start_date=date,
                                              end_date=date,
                                              timeseries_type=damd_helper.TimeSeriesType.SHOCK,
                                              shock_horizon=self.shock_horizon)
        return damd_helper.output_to_dict(raw_out, self.timeseries_type)


class FromMDH(MatrixLoader):
    """
    Class for loading market data from MDH

    Args:
        integers         (int or list of int): Integers (identifiers) to load market data for
        startd                         (date): Start date for loading
        endd                           (date): End date for loading
        shock_horizon                   (int): Which shock horizon to load for

    Returns:
        (pd.DataFrame):  DataFrame containing loaded market data

    Notes:
        Author: g48606
    """
    def __init__(self, integers, startd, endd, shock_horizon=1, calendar='EUR'):
        self.shock_horizon = shock_horizon
        self.calendar = calendar
        self.unique_params = [shock_horizon, calendar]
        MatrixLoader.__init__(self, names=integers, source='MDH', startd=startd, endd=endd, load_from_source=False)
        self.data = pd.concat(self.data.values())

    def source_loading_function(self, names, date):
        print(date)
        return mdh_helper.mdhub_from_webservice(instrument_ids=names,
                                                date=date,
                                                no_of_days=1,
                                                shock_horizon=self.shock_horizon,
                                                calendar=self.calendar)


if __name__ == '__main__':
    import datetime as dt
    s_date = dt.datetime(2017, 4, 10)
    e_date = dt.datetime(2017, 4, 30)

    dat1 = FromDAMD(market_data_ids='USD.EUR', startd=s_date, endd=e_date).data
    print(dat1)

    # nok_id = mdh_helper.get_rf_instrument_id({'foreign': 'NOK', 'domestic': 'EUR', 'rfType': 'RfCcyPair'}, 'int')
    # usd_id = mdh_helper.get_rf_instrument_id({'foreign': 'USD', 'domestic': 'EUR', 'rfType': 'RfCcyPair'}, 'int')
    # gbp_id = mdh_helper.get_rf_instrument_id({'foreign': 'GBP', 'domestic': 'EUR', 'rfType': 'RfCcyPair'}, 'int')
    #
    # dat2 = FromMDH(integers=[gbp_id, nok_id, usd_id], startd=dt.datetime(2018, 3, 7), endd=dt.datetime(2018, 3, 12)).data
    # print(dat2)
