'''
The module include all loaders that load the various market datas

All these loaders should be a sub class for the general loader setup.
The unit tests functions can be find in code-lib/test/market_data/test_various_loaders..

Example about how to use these loaders can be found in below confluence page:

https://confluence.itcm.oneadr.net/display/MRIA/Example+scripts


Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       ddmonyyyy   G12345      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''



# ===================================================================================
# Import functions
# ===================================================================================

try:
    import cPickle as pickle
except:
    import pickle
import datetime
import hashlib
import os
import sys
from datetime import timedelta

from orca_model_core.models import factory
import pandas as pd
import quantum as qt
from orca.types import ModelSpecification
from pandas.tseries.offsets import BDay

import core.market_data.old_loaders.bond_future_price as bond_future_price
from core.caching.abstract_loader_classes import SeriesLoader, DailyLoader, CurveSeriesLoader, MatrixLoader
from core.caching.cache_format import DictCacheFormat, DataFrameCacheFormat, RawTimeSeriesCacheFormat, AnyCacheFormat
from core.caching.cache_method import PickleCacheMethod, JSONCacheMethod
from core.caching.cache_strategy import NameDateStrategy, TimeCacheStrategy, FileNameCacheStrategy
from core.market_data import damd_helper
from core.market_data.old_loaders import damd_interest_rates
from core.system import envir
from core.utils import error_handler, date_helper
from core.utils.dict_helper import dict_to_tuples
from core.connection.orca_connect import get_orca_request, to_eod
from core.market_data.old_loaders.cds_spread import extract_cds_spread_data_from_allCurveJsonData
from core.market_data.old_loaders.cds_spread import transform_json_curve_from_web_service
from core.utils.RawTimeSeries import RawTimeSeries


class CDSSpreadLoader(CurveSeriesLoader):
    # ===================================================================================
    # Loader for CDS spread dynamics
    # example
    # obj=CDSSpreadLoader(name='INDUST_N. America_B',
    #                 source='proxy_service_fast',
    #                 startd=datetime.datetime(2008,3,17),
    #                 endd=datetime.datetime(2017,2,28))
    # ===================================================================================
    def __init__(self, name, source, startd, endd,load_from_source=False):
        self.cache_method=PickleCacheMethod()
        self.cache_strategy=TimeCacheStrategy()
        self.cache_format=RawTimeSeriesCacheFormat()
        CurveSeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def load_data_from_source(self):
        if self.source in ['proxy_service','proxy_service_fast']:
            tempData=self.load_data_from_source_proxy_service()
        elif self.source == 'INFOP':
            from core.market_data.old_loaders.cds_spread import load_cds_curve_from_marsp
            tempData=load_cds_curve_from_marsp(curvename=self.name,
                                               startdate=self.startd_for_loading,
                                               enddate=self.endd_for_loading)
        elif self.source == 'MARKIT':
            # ===================================================================================
            # load the single name CDS curve from the markit raw file located in TWP database
            # ===================================================================================
            from core.market_data.old_loaders.cds_spread import load_cds_curve_from_markit
            tempData = load_cds_curve_from_markit(ticker=self.name,
                                                 startdate=self.startd_for_loading,
                                                 enddate=self.endd_for_loading)

        elif self.source == 'GOTC':
            # ===================================================================================
            # load the CDS curve from GOTC table(infinity)
            # ===================================================================================
            from core.market_data.old_loaders.cds_spread import load_cds_curve_from_gotc
            tempData = load_cds_curve_from_gotc(curvename=self.name,
                                                  startdate=self.startd_for_loading,
                                                  enddate=self.endd_for_loading)
        elif self.source == 'ORCA':
            tempData = self.load_data_from_source_orca()
        else:
            raise NotImplementedError("Please Implement this source :" + self.source)
        return tempData

    def load_data_from_source_orca(self):
        # ===================================================================================
        # Load the CDS curve from the ORCA
        # ===================================================================================

        orca_curve_name,ccy = self.parse_curves_for_orca()
        tempData = RawTimeSeries(name='credit_spread_proxy' + self.name)
        from core.connection import orca_connect
        req = orca_connect.get_orca_request()
        currt = self.startd_for_loading
        while currt <= self.endd_for_loading:
            db_time_stamp = datetime.datetime.today()
            context_time_stamp = (currt, db_time_stamp)
            curve_names = [
                (orca_curve_name , getattr(qt.Currency, ccy), qt.MarketDataInstanceCode.OPEN)
            ]
            curves = req.get_credit_curves(context_time_stamp, curve_names).result()
            curve = curves[curves.keys()[0]]
            if type(curve) is qt.CreditCurveInterpolated:
                tempData.addItem(curve, currt)
            currt = currt + timedelta(days=1)
        return tempData

    def parse_curves_for_orca(self):
        return self.name.split(".")

    def load_data_from_source_proxy_service(self):
        currt = self.startd_for_loading - timedelta(days=1)
        tempData = RawTimeSeries(name='credit_spread_proxy' + self.name)
        while currt <= self.endd_for_loading:
            currt = currt + timedelta(days=1)
            if self.source == 'proxy_service':
                try:
                    credit_curve = self.load_daily_curve_from_proxy_webservice(currt)
                except:
                    continue
            elif self.source == 'proxy_service_fast':
                try:
                    credit_curve = self.return_credit_curve(currt)
                except:
                    print("error in loading credit curve " + self.name + " and date :" + currt.strftime("%B %d, %Y"))
                    continue
            else:
                raise NotImplementedError("Please Implement this source")
            tempData.addItem(credit_curve, currt)
        return tempData

    def return_credit_curve(self,currt):
        daily_pickle_file_path = self.get_daily_pickle_file(self.name, currt)
        if not os.path.exists(daily_pickle_file_path):
            obj = AllCDSSpreadLoader(source='proxy_service', currt=currt)
            obj.fetch_curves_to_pickle(names=AllCDSSpreadLoader.return_all_possibles_names())
        with open(daily_pickle_file_path, 'r') as f:
            credit_curve = pickle.load(f)
            return credit_curve



    def return_std_buckets(self):
        return ['1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y']

    def transfer_curve_to_cdscurve(self):
        # ===================================================================================
        # The code here transfer the qt curve to standard buckets
        # ===================================================================================
        temp_data=RawTimeSeries(name='cds_curves')
        for d in self.data.cacheDate:
            tempCurve=self.data.getvalue(d)
            tempDate=[]
            tempRate=[]
            for bucket in self.return_std_buckets():
                 tempT = qt.addTenor(d, bucket)
                 tempDate.append(tempT)
                 tempRate.append(tempCurve.getVal(tempT))
            hc = qt.CurveFlat.make(tempDate, tempRate)
            credit_curve=qt.CreditCurveInterpolated.make('cdscurve', 'USD', date_helper.to_datetime(d), hc, 0.4)
            temp_data.addItem(credit_curve,d)
        return temp_data

    def load_daily_curve_from_proxy_webservice(self,currt):
        allCDSData = AllCDSSpreadLoader(source=self.source, currt=currt).data
        data_vec = extract_cds_spread_data_from_allCurveJsonData(all_curves_data=allCDSData,
                                                                 name=self.name)
        credit_curve = transform_json_curve_from_web_service(currt, data_vec)

        print('Curve has been made for name: ' + self.name + ' and Date :' + datetime.strptime(str(currt.date()),
                                                                                               "%Y-%m-%d").strftime(
            "%d%b%Y"))
        return credit_curve


    def return_unique_name(self):
        return self.__class__.__name__ + '_' + self.name +'_' + self.source

    def get_single_name_cache_folder(self,name):
        from core.system.envir import data_path
        single_cache_folder_name =data_path()
        if not os.path.exists(single_cache_folder_name):
            os.makedirs(single_cache_folder_name)
        return single_cache_folder_name

    def get_daily_pickle_file(self,name,currt):
        from core.utils.date_helper import date_format
        date_str = date_format(currt, 'YYYYMMDD')
        return self.get_single_name_cache_folder (name) +'data_'+date_str+'.pickle'



class FxSpotLoader(SeriesLoader):
    """
    Extract FX spot prices from a specific source

    Extract function returns a list of dictionaries.
    That is transformed into a dataframe.
    The dataframe is transposed so the different currencies are columns in the returned dataframe.

    Structure:

    Date        EUR     DKK
    01-01-2007  1       0.1340
    02-01-2007  1       0.1342
    03-01-2007  1       0.1341

    Args:
        self.name               (list of str):      Name of the currencies that should be extracted
        self.source             (str):              Name of the data source (e.g. MARS)
        self.startd_for_loading (datetime.date):    First date that should be extracted
        self.endd_for_loading   (datetime.date):    First date that should NOT be extracted (date is not included)
        self.load_from_source   (bool):             (default = False) When True, no cashing is done.

    Returns:
        (dataframe):   "Transposed" dataframe, with currencies as columns

    Raises:

    Example:
        The module is called (from python) like this::

            cur = ['EUR','GBP','DKK']
            import core.market_data.market_data_loader as market_data_loader
            import datetime

            my_fx_data = market_data_loader.FxSpotLoader(name   = cur,
                                                        source  = 'INFOP',
                                                        startd  = datetime.datetime(2006,12,20),
                                                        endd    = datetime.datetime(2009,1,15),
                                                        ).data

    Warning:

    Notes:
        Author: g50444
    """
    def __init__(self, name, source, startd, endd, load_from_source=False, cache_path = None):
        if cache_path is not None:
            self.cache_path = cache_path
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = DataFrameCacheFormat()

        SeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def load_data_from_source(self):
        import core.market_data.old_loaders.fx_rates as fx_rates
        df = pd.DataFrame(
                            fx_rates.extract(currency       = self.name,
                                             eod_date       = [self.startd_for_loading,self.endd_for_loading],
                                             source         = 'MARS',
                                             source_envir   = 'PROD',
                                             )
                            ).pivot(index   = 'eod_date',
                                    columns = 'cur',
                                    values  = 'price',
                                    )
        df.index.name = 'date'
        return df

    def return_unique_name(self):
        return self.__class__.__name__ + '_' + '_'.join(self.name) + '_' + self.source


class BondPriceLoader(SeriesLoader):
    # ===================================================================================
    # Load the bond pricing from source service
    # priceseries = BondPriceLoader(name='NO0010664428',
    #                              source='MDS',
    #                              startd=datetime.datetime(2016, 12, 3),
    #                              endd=datetime.datetime(2016, 12, 25))
    # ===================================================================================
    def __init__(self, name, source, startd, endd,load_from_source=False):
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = RawTimeSeriesCacheFormat()
        SeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def return_unique_name(self):
        return self.__class__.__name__ + '_' + self.name +  '_' + self.source

    def load_data_from_source(self):
        from core.market_data.old_loaders.bond_price import BondPrice
        priceobj=BondPrice()
        if self.source in priceobj.supported_source():
            return priceobj.make_price_into_datacache(ISIN=self.name,
                                                      source=self.source,
                                                      startd=self.startd_for_loading,
                                                      endd=self.endd_for_loading)
        else:
            raise NotImplementedError("Please Implement this source")


class BondFuturePriceLoader(SeriesLoader):
    def __init__(self, name, source, startd, endd,load_from_source=False):
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = DataFrameCacheFormat()
        SeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def return_unique_name(self):
        return self.__class__.__name__ + '_' + self.name +  '_' + self.source

    def load_data_from_source(self):

        if self.source is "CRD":
            return bond_future_price.transform_bond_future_price_to_dataframe(su_key = self.name,
                                                                              startdate = self.startd_for_loading,
                                                                              enddate = self.endd_for_loading)
        elif self.source is "MDS":
            return bond_future_price.transform_bond_future_price_from_mds_to_df(su_key = self.name,
                                                                                startdate = self.startd_for_loading,
                                                                                enddate = self.endd_for_loading)
        else:
            raise NotImplementedError("Please Implement this source")


class DamdsLoader(SeriesLoader):
    def __init__(self, market_data_ids, startd, endd, load_from_source=False,
                 timeseries_type=damd_helper.TimeSeriesType.SHOCK, shock_horizon=1):
        market_data_ids = market_data_ids if isinstance(market_data_ids, list) else [market_data_ids]
        self.shock_horizon = shock_horizon
        self.timeseries_type = timeseries_type
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = DataFrameCacheFormat()
        SeriesLoader.__init__(self, market_data_ids, "DAMDS", startd, endd, load_from_source)

    def return_unique_name(self):
        p = pickle.dumps(self.name, -1)
        key = hashlib.md5(p).hexdigest()
        return self.__class__.__name__ + '_' + key + '_' + self.source

    def load_data_from_source(self):
        raw_out = damd_helper.load_from_damds(market_data_ids=self.name,
                                              start_date=self.startd_for_loading,
                                              end_date=self.endd_for_loading,
                                              timeseries_type=self.timeseries_type,
                                              shock_horizon=self.shock_horizon)
        return damd_helper.output_to_df(raw_out, self.timeseries_type)



class CashFlowLoader(SeriesLoader):
    # ===================================================================================
    # Load the cash flow from source service for bonds :)
    # Example: cashflowdynamic = CashFlowLoader(name='NO0010673726', source='orca', startd=datetime(2017, 2, 1),
    #                                     endd=datetime(2017, 2, 6))
    # ===================================================================================
    def __init__(self, name, source, startd, endd,load_from_source=False):
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = RawTimeSeriesCacheFormat()
        SeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def return_unique_name(self):
        return self.__class__.__name__ + '_' + self.name +  '_' + self.source

    def load_data_from_source(self):
        from core.market_data.old_loaders.isin_cashflow import load_all_cashflow
        if self.source == 'orca':
            return load_all_cashflow(isin=self.name,
                                     startD=self.startd_for_loading,
                                     endD=self.endd_for_loading)
        else:
            raise NotImplementedError("Please Implement this source")


class IrCurveMarsLoader(CurveSeriesLoader):
    def __init__(self, name, source, startd, endd, interest_rate_type , currencies,load_from_source=False):
        self.currencies = currencies
        self.interest_rate_type = interest_rate_type
        self.cache_format = AnyCacheFormat()
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = FileNameCacheStrategy()
        CurveSeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def return_unique_name(self):
        return '_'.join(self.currencies) + '_' + self.interest_rate_type + \
               date_helper.date_format(self.startd, 'DDMMYYYY') + '_' + date_helper.date_format(self.endd, 'DDMMYYYY')

    def load_data_from_source(self):
        if self.source == 'MARS':
            tempdata = damd_interest_rates.extract(currency = self.currencies,
                                                   eod_date = [self.startd_for_loading , self.endd_for_loading],
                                                   interest_type = self.interest_rate_type,
                                                   info = 0)
            return pd.DataFrame.from_dict(tempdata)
        else:
            raise NotImplementedError("Please Implement this source")


class IrCurveLoader(CurveSeriesLoader):
    # ===================================================================================
    # load interest rate curve
    # IRCurveSeries=IrCurveLoader(name='NKNI_REV',
    #           ccy='NOK',
    #           source='orca',
    #           startd=datetime.datetime(2016,12,3),
    #           endd=datetime.datetime(2016,12,25))
    # ===================================================================================
    def __init__(self, name, source, startd, endd, ccy = "EUR",load_from_source=False):
        self.ccy=ccy
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = RawTimeSeriesCacheFormat()
        CurveSeriesLoader.__init__(self, name, source, startd, endd, load_from_source)


    # ===================================================================================
    # Transformation script for orca
    # ===================================================================================

    def return_unique_name(self):
        return self.__class__.__name__ + '_' + self.name +'_' + self.ccy+'_' + self.source

    def load_data_from_source(self):
        if self.source == 'orca':
            return self.load_ir_curve_from_orca()
        elif self.source == 'INFOP_FRTB':
            return self.load_ir_curve_from_mars_frtb_table()
        elif self.source == 'DAMDS':
            return self.load_ir_curve_from_damds_frtb_table()
        else:
            raise NotImplementedError("Please Implement this source")

    def return_std_buckets(self):
        return ['7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '12Y',
                                '15Y', '20Y', '25Y', '30Y', '50Y']

    def load_ir_curve_from_orca(self):
        import quantum as qt
        import pandas as pd
        import orca.utilities.soap as soap
        login = soap.login_from_file()

        tempData=RawTimeSeries(name='ir_curve' + self.name)
        for currDateTime in pd.date_range(start=self.startd_for_loading,end=self.endd_for_loading,freq=BDay(1)):
            try:
                risk_free_curve = qt.LoadCurve(login,self.name, self.ccy, currDateTime.to_pydatetime(), 'ZERO', True)
                curve_sd=self.makeCurveInStdBucket(risk_free_curve,currDateTime.to_pydatetime())
                tempData.addItem(curve_sd,currDateTime)
            except:
                continue

        return tempData

    def load_ir_curve_from_orca_service(self):
        import quantum as qt
        import pandas as pd
        from core.connection.orca_connect import get_orca_request

        with get_orca_request('uat') as req:
            tempData = RawTimeSeries(name='ir_curve' + self.name)
            for currDateTime in pd.date_range(start=self.startd_for_loading, end=self.endd_for_loading, freq=BDay(1)):
                try:
                    risk_free_curve = qt.LoadCurve('login', self.name, self.ccy, currDateTime.to_pydatetime(), 'ZERO', True)
                    curve_sd = self.makeCurveInStdBucket(risk_free_curve, currDateTime.to_pydatetime())
                    tempData.addItem(curve_sd, currDateTime)
                except:
                    continue

        return tempData

    # ===================================================================================
    # Transformation script for frtb table in mars
    # ===================================================================================

    def load_ir_curve_from_mars_frtb_table(self):
        tempData = RawTimeSeries(name='ir_curve' + self.name)
        for currDateTime in pd.date_range(start=self.startd_for_loading,end=self.endd_for_loading,freq=BDay(1)):
            try:
                ir_curve = damd_interest_rates.return_ir_curve_from_marsp(self.name, currDateTime)
                curve_sd=self.make_qt_curve_from_db_ir(ir_curve,currDateTime.to_pydatetime())
                tempData.addItem(curve_sd,currDateTime)
            except:
                continue
        return tempData

    def load_ir_curve_from_damds_frtb_table(self):
        tempData = RawTimeSeries(name='ir_curve' + self.name)
        for currDateTime in pd.date_range(start=self.startd_for_loading,end=self.endd_for_loading,freq=BDay(1)):
            try:
                ir_curve = damd_interest_rates.return_ir_curve_from_damds(self.name, currDateTime)
                curve_sd=self.make_qt_curve_from_db_ir(ir_curve,currDateTime.to_pydatetime())
                tempData.addItem(curve_sd,currDateTime)
            except:
                continue
        return tempData

    def make_qt_curve_from_db_ir(self, ir_curve_df, currDateTime):
        tempRateList = ir_curve_df['interest_pct'].tolist()
        tempTenorList = ir_curve_df['term_id'].tolist()
        qtTenorList = [qt.addTenor(currDateTime, j) for j in tempTenorList]
        try:
            qt_bond_curve = qt.CurveCatrom.make(qtTenorList, tempRateList)
            return qt_bond_curve
        except:
            raise Exception

    def makeCurveInStdBucket(self, curve, asoft):
        import quantum as qt
        tempDate = []
        tempRate = []
        for bucket in self.return_std_buckets():
            tempT = qt.addTenor(asoft, bucket)
            tempDate.append(tempT)
            tempRate.append(curve.getVal(tempT))
        return qt.CurveCatrom.make(tempDate, tempRate)


class AllCDSSpreadLoader(DailyLoader):
    def __init__(self, source, currt ,load_from_source=False):
        self.cache_method = JSONCacheMethod()
        self.cache_strategy = FileNameCacheStrategy()
        self.cache_format = DictCacheFormat()
        DailyLoader.__init__(self, 'All', source, currt, load_from_source)

    def load_data_from_source(self):
        from core.market_data.old_loaders.cds_spread import get_json_from_service
        if self.source=='proxy_service':
            data= get_json_from_service(date=self.currt,info=1)
        else:
            raise NotImplementedError("Please Implement this source")
        return data

    def fetch_curves_to_pickle(self, names):
        allCDSData=self.data
        for name in names:
            data_vec = extract_cds_spread_data_from_allCurveJsonData(all_curves_data=allCDSData,
                                                                     name=name)
            credit_curve = transform_json_curve_from_web_service(self.currt, data_vec)
            print("dumping pickle to :" + self.get_daily_pickle_file(name,self.currt))
            with open(
                    self.get_daily_pickle_file(name,self.currt),
                    'wb') as f:
                pickle.dump(credit_curve, f)

    def get_single_name_cache_folder(self, name):
        single_cache_folder_name = self.cache_path + name+'/'
        if not os.path.exists(single_cache_folder_name):
            os.makedirs(single_cache_folder_name)
        return single_cache_folder_name

    def get_daily_pickle_file(self, name, currt):
        from core.utils.date_helper import date_format
        date_str = date_format(currt, 'YYYYMMDD')
        return self.get_single_name_cache_folder (name) +'data_'+date_str+'.pickle'

    @staticmethod
    def return_all_possibles_names():
        sectors = ['CONSDSC', 'CONSSTP', 'HEALTH', 'FINANCE', 'IT', 'TELECOM', 'UTILITY', 'ENERGY', 'MATERIAL',
                   'INDUST']
        regions = ['NORDIC', 'World', 'Europe', 'Asia', 'NAmerica']
        ratings = ['AAA', 'AA', 'A', 'BBB', 'BB', 'B']
        names = []
        for sector in sectors:
            for region in regions:
                for rating in ratings:
                    names.append(sector + "_" + region + "_" + rating)
        return names


class LinearRateModelLoader(SeriesLoader):
    VEM = "ORCA_REVAL"

    def __init__(self, name, source, startd, endd, load_from_source=False, cache_path=None):
        name = dict_to_tuples(name)
        if cache_path is not None:
            self.cache_path = cache_path
        else:
            self.cache_path = self.return_default_cache_path()
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = NameDateStrategy()
        self.cache_format = DictCacheFormat()
        self._req = get_orca_request('uat')
        self._holiday_factory = self._req.get_holiday_factory_for_all_centers().result()
        SeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def return_default_cache_path(self):
        """
        Returns the default cache path defined by the core.system.envir module. A specific folder named after the
        subclass is created to store cache files.
        """
        loader_name = self.__class__.__name__
        path = envir.data_path() + '\\' + loader_name + '\\'
        return path

    def return_unique_name(self):
        name_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for date in pd.bdate_range(self.startd, self.endd):
            for name in name_list:
                out[date, name] = self.__class__.__name__ + '_' + date.strftime('%Y-%m-%d') + '_' + '_'.join(
                    name.stringName) + '_' + self.source
        return out


    def load_data_from_source(self, names=None, start=None, end=None):
        if names is None: names = self.name
        if start is None: start = self.startd_for_loading
        if end is None: end = self.endd_for_loading
        out = {}
        if self.source.upper() == 'ORCA':
            date_range = [x.to_pydatetime() for x in pd.bdate_range(start, end)]
            for date in date_range:
                temp = self.source_loading_function(names, date)
                out.update(temp)
            return out
        else:
            raise NotImplementedError("The source '%s' has not been implemented" % self.source)

    @staticmethod
    def get_model_param(currencies):
        USD = qt.Currency.USD
        EUR = qt.Currency.EUR
        return {'model_name': qt.ModelName.LINEAR_RATE,
                'numeraire_currency': EUR,
                'discount_type': qt.DiscountType.OIS_DISC,
                'csa_currencies': [USD],
                #            'csaCurrencies': ["EUR"],
                'libor_currencies': currencies,
                'equity_names': [],
                'credit_names': [],
                'commodity_names': [],
                'fx_pairs': [],
                }

    def get_model_spec(self, currencies):
        return ModelSpecification(**self.get_model_param(currencies))

    def source_loading_function(self, *args):
        model_factory = factory.Factory(to_eod(args[1]), self._holiday_factory, self._req)

        return {(args[1], args[0][0]):model_factory.create(self.VEM, self.get_model_spec(args[0]))}


class StaticDataLoader(MatrixLoader):
    # This is a loader without time dimension
    def __init__(self, names, load_from_source=False, cache_path=None):
        MatrixLoader.__init__(self, names=names,
                              startd=datetime.datetime(1985, 5, 31),
                              endd=datetime.datetime(1985, 5, 31),
                              load_from_source=load_from_source,
                              cache_path=cache_path)

        temp = {}
        for key in self.data.keys():
            new_key = key[1] # drop the date
            temp[new_key] = self.data[key]
        self.data = temp


class ORCABondCashFlowLoader(MatrixLoader):
    def __init__(self, names, startd, endd, load_from_source=False, cache_path=None):
        MatrixLoader.__init__(self, names=names, startd=startd, endd=endd)

    def source_loading_function(self, names, date):
        return self.load_all_cashflows_from_orca_v(names, date)

    def load_all_cashflows_from_orca_v(self, isins, date):

        """
        The function below try to load all cash flow in a batch from orca

        Since currently orca cash flow service will crash if some special ISIN included in the list
        So that the function keep trying the cashflow service and remove the failed ISIN.
        """

        result_dict={"results":{}, "errors":{}}
        load_success = False
        while len(isins)>0 and not load_success :
            try:
                result_dict = self.load_all_cashflows_from_orca_one_time(isins,date)
                load_success = True
            except KeyError as e:
                failed_isin = e.message
                isins.remove(failed_isin)
                error_handler.track_error(error_message="",identifier=failed_isin,
                                          date = date, comments="ORCA cash flow service crash with this isin")

        out = {}
        for isin, cashflow in result_dict.results.items():
            out[date, isin] = cashflow

        for isin,error in result_dict.errors.items():
            error_handler.track_error(error_message="", identifier=isin,
                                      date=date, comments=str(error))

        return out


    def load_all_cashflows_from_orca_one_time(self, isins, date):
        service_req = get_orca_request()
        specs_reply = service_req.request_bond_specs(isins).result()
        excoupons = {isin: "%dB" % specs_reply.results[isin].excoupon_days for isin in specs_reply.results}
        return service_req.request_bond_cashflows_from_date(isins=isins,
                                                                   ex_coupon_periods=excoupons,
                                                                   anchor=date).result()


class BondPriceMatrixLoader(MatrixLoader):
    def __init__(self, names, startd, endd, load_from_source=False, cache_path=None):
        MatrixLoader.__init__(self, names=names, startd=startd, endd=endd, load_from_source=load_from_source, cache_path=cache_path)

    def source_loading_function(self, names, date):
        from core.market_data.old_loaders.bond_price import BondPrice
        priceobj = BondPrice()
        return priceobj.load_price_and_int(names,date)


class BondCurveLoader(CurveSeriesLoader):

    # ===================================================================================
    # bond curve object implemented for market data
    # Example
    # obj2 = BondCurveLoader(name='DKKMTGNYKSOFTBLT',
    #                       source='web_service',
    #                       startd=datetime.datetime(2016, 2, 3),
    #                       endd=datetime.datetime(2016, 2, 10))
    # ===================================================================================
    def __init__(self, name, source, startd, endd,load_from_source=False):
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = TimeCacheStrategy()
        self.cache_format = RawTimeSeriesCacheFormat()
        CurveSeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def return_unique_name(self):
        return self.__class__.__name__ + '_' + self.name + '_' + self.source

    def load_data_from_source(self):
        # the market_data_loader function below load the bond curve from different places...
        from core.market_data.old_loaders import bond_curve_loader
        # ===================================================================================
        # Loader wrapper for source web service
        # ===================================================================================
        if self.source=='web_service':
            cache_data= bond_curve_loader.make_curve_from_webservice(self.name)
            temp_data = self.load_data_from_cache(cache_data)
        elif self.source=='excel_sheet':
            cache_data = bond_curve_loader.make_curve_from_xls(self.name)
            temp_data=self.load_data_from_cache(cache_data)
        elif self.source=='marsp':
            temp_data= bond_curve_loader.load_curve_from_various_db(self.name, self.startd_for_loading, self.endd_for_loading)
        elif self.source=='marsp_eu_gov':
            temp_data = bond_curve_loader.load_curve_from_various_db(self.name, self.startd_for_loading,
                                                                     self.endd_for_loading, type = 'eu_gov')
        elif self.source == 'DAMDS':
            temp_data = bond_curve_loader.load_curve_from_various_db(self.name, self.startd_for_loading,
                                                                     self.endd_for_loading, type='bond_curve_damds')
        else:
            raise NotImplementedError("Please Implement this source :" + self.source)
        return temp_data

    def return_std_buckets(self):
        return ['7D', '1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '12Y',
                '15Y', '20Y', '25Y', '30Y', '50Y']


if __name__ == '__main__':
    isins = ['XS1368469570', 'DK0008919913']
    a = BondPriceMatrixLoader(names=isins, startd=datetime.datetime(2017, 12, 10),
                              endd=datetime.datetime(2017, 12, 27))
    print(a.data)


    isins = ['XS1368469570','DK0008919913']
    a = ORCABondCashFlowLoader(names=isins, startd=datetime.datetime(2017, 12, 27), endd=datetime.datetime(2017, 12, 27))
    print(a.data)


    lm = LinearRateModelLoader(name=[qt.Currency.EUR],
                               source='ORCA',
                               startd=datetime.date(2017, 4, 10),
                               endd=datetime.date(2017, 4, 11))

    d3 = DamdsLoader(market_data_ids="CAD.EUR", startd=datetime.datetime(2016, 3, 2),
                     endd=datetime.datetime(2017, 1,12))

    d4 = DamdsLoader(market_data_ids="CAD.EUR", startd=datetime.datetime(2016, 3, 2),
                     endd=datetime.datetime(2017, 9, 25))


    d1 = DamdsLoader(market_data_ids="DKKGOV_BASIS_4Y",
                     startd=datetime.datetime(2017, 3, 2),
                     endd=datetime.datetime(2017, 6, 10))
    print(d1.data)


    d2 = DamdsLoader(market_data_ids="CAD.EUR",
                     startd=datetime.datetime(2017, 3, 2),
                     endd=datetime.datetime(2017, 6, 10),
                     load_from_source=True)

    print(d2.data)

    d1 = BondFuturePriceLoader(name="154832927",
                               source="MDS",
                               startd=datetime.datetime(2017, 3, 2),
                               endd=datetime.datetime(2017, 3, 10)
                               )
    print(d1.data)

    d1_crd = BondFuturePriceLoader(name="154832927",
                               source="CRD",
                               startd=datetime.datetime(2017, 3, 2),
                               endd=datetime.datetime(2017, 3, 10)
                               )
    print(d1_crd.data)

    d1 = IrCurveLoader(name="USD.DISC.OIS.CURVE",
                       source="DAMDS",
                       startd=datetime.datetime(2017, 7, 2),
                       endd=datetime.datetime(2017, 7, 10))

    print(d1.data.cacheDate)

    d1 = IrCurveLoader(name="SEK.DISC.LIBOR.CURVE",
                       source="DAMDS",
                       startd=datetime.datetime(2017, 9, 2),
                       endd=datetime.datetime(2017, 9, 10))
    # print(d1.data.cacheDate)

    d2 = CDSSpreadLoader(name="CDXHY_S26.USD",
                         source="ORCA",
                         startd=datetime.datetime(2017, 6, 2),
                         endd=datetime.datetime(2017, 6, 9))

    print(d2.data.cacheDate)


    d2 = CDSSpreadLoader(name="88585",
                         source="GOTC",
                         startd=datetime.datetime(2017, 3, 10),
                         endd=datetime.datetime(2017, 6, 9))

    print(d2.data.cacheDate)

    d1 = BondFuturePriceLoader(name = "154832927",
                               source = "CRD" ,
                               startd=datetime.datetime(2017, 3, 2),
                               endd=datetime.datetime(2017, 3, 10)
                               )
    print(d1.data)

    d3 = BondCurveLoader(name="DKKGOV",
                         source="DAMDS",
                         startd=datetime.datetime(2017, 3, 2),
                         endd=datetime.datetime(2017, 3, 10))

    print(d3.data.cacheDate)

    d1 = IrCurveLoader(name = "SEK.DISC.LIBOR.CURVE" ,
                         source = "DAMDS",
                         startd= datetime.datetime(2017,3,2),
                         endd = datetime.datetime(2017,3,10))
    #print(d1.data.cacheDate)

    d2 = CDSSpreadLoader(name = "FINANCE_Europe_BB" ,
                         source = "proxy_service_fast" ,
                         startd=datetime.datetime(2017, 6, 9),
                         endd = datetime.datetime(2017,6,10))
    print(d2.data.cacheDate)


    my_fx_data = FxSpotLoader(name   = ["EUR"],
                            source  = 'INFOP',
                            startd  = datetime.datetime(2004,12,20),
                            endd    = datetime.datetime(2016,1,15),
                              cache_path="C:/Temp/"
                                                        ).data

    print(my_fx_data)
