from core.market_data import mars_helper
from core.stress_testing import largest_exposures
from core.market_data import proxy_helper
from core.stress_testing import stress_helper
from core.utils import date_helper
from core.connection import database_connect
import pandas as pd
import pyodbc


def IR(ccy, interest_market, interest_issuer='BENCH', start_date=None, end_date=None, use_proxy=False, pivot_data=False):
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    get_id_sql = """select INTEREST_ID from MARSP.INTEREST 
                    where CURRENCY_ID = '%(ccy)s'  
                    and INTEREST_MARKET_ID = '%(interest_market)s' 
                    and INTEREST_ISSUER_ID = '%(interest_issuer)s'""" % locals()
    interest_id = int(pd.read_sql(sql=get_id_sql, con=conn)['INTEREST_ID'][0])
    if use_proxy:
        interest_id = proxy_helper.get_interest_proxies(interest_id)['PROJECTION_INTEREST_ID'][0]

    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select A.EOD_DATE, A.TERM_ID, A.INTEREST_PCT VALUE
                    from MARSP.INTEREST_RATE a, MARSP.LADDER_TERM b
                    where A.INTEREST_ID = %(interest_id)s
                    %(date_req)s
                    and A.PRICE_TYPE_ID = 'INT'
                    and A.TERM_ID = B.TERM_ID
                    and B.LADDER_ID = 68
                    and A.TERM_ID is not null
                    order by A.EOD_DATE, A.MATURITY_DATE""" % locals()

    data = pd.read_sql(sql=sql_string, con=conn)
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # save_path = stress_helper.create_save_path(ccy, interest_market, interest_issuer, 'proxied') if use_proxy else stress_helper.create_save_path(ccy, interest_market, interest_issuer)
    # dataframe_helper.add_sheet_to_excel(formatted, save_path)


def IR_VOL(ccy, vol_interest_market, start_date=None, end_date=None, use_proxy=False, pivot_data=False):
    vol_id = mars_helper.get_ir_vol_id(ccy=ccy, vol_interest_market=vol_interest_market)
    if use_proxy:
        vol_id = proxy_helper.get_vol_proxies(vol_id, 'IR')['PROJECTION_VOL_ID'][0]

    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select a.EOD_DATE, a.MATURITY_TERM_ID, a.TENOR_TERM_ID, a.VOL_PCT VALUE
                    from MARSP.VOL_RATE a, marsp.ladder_term b, marsp.ladder_term c
                    where a.VOL_ID = %(vol_id)s
                    %(date_req)s
                    and a.MATURITY_TERM_ID = B.TERM_ID
                    and B.LADDER_ID = 26
                    and a.TENOR_TERM_ID = c.TERM_ID
                    and C.LADDER_ID = 25
                    and A.VOL_PCT > 0
                    order by a.EOD_DATE""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if pivot_data:
        data = stress_helper.format_surface_data(data)
    return data
    # save_path = stress_helper.create_save_path(ccy, 'proxied') if use_proxy else stress_helper.create_save_path(ccy, vol_interest_market)
    # dataframe_helper.add_sheet_to_excel(formatted, save_path)


def XCCY(ccy, start_date=None, end_date=None, pivot_data=False):
    # NB: This returns xCCY basis with USD as domestic currency
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select a.EOD_DATE, a.TERM_ID, a.QUOTE_START_PCT+a.QUOTE_SHIFT_PCT VALUE
                    from MARSP.INTEREST_QUOTE_SHIFT a, MARSP.TIMEINTERVAL B, MARSP.INTEREST C, MARSP.LADDER_TERM d
                    where a.INTEREST_ID = C.INTEREST_ID
                    %(date_req)s
                    and C.INTEREST_MARKET_ID = 'CCSB_Q'
                    and C.CURRENCY_ID = '%(ccy)s'
                    and a.SC_ID = B.TIMEINTERVAL_ID
                    and B.END_DATE = a.EOD_DATE
                    and a.TERM_ID = d.TERM_ID
                    and d.LADDER_ID = 68
                    order by a.EOD_DATE""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if data.empty:
        print("Found no data for %s: returning nothing" % ccy)
        return
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(ccy))


def TENORBASIS(ccy, basis, start_date=None, end_date=None, pivot_data=False):
    allowed_basis = ['1M6M', '3M6M', '1Y6M']
    if basis not in allowed_basis:
        raise TypeError("Type of basis don't have data in MARS - breaking code...")
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select a.EOD_DATE, a.TERM_ID, a.QUOTE_START_PCT+a.QUOTE_SHIFT_PCT VALUE
                    from MARSP.INTEREST_QUOTE_SHIFT a, MARSP.TIMEINTERVAL B, MARSP.INTEREST C, MARSP.LADDER_TERM d
                    where a.INTEREST_ID = C.INTEREST_ID
                    %(date_req)s
                    and C.INTEREST_MARKET_ID = 'S_%(basis)s_Q'
                    and C.CURRENCY_ID = '%(ccy)s'
                    and a.SC_ID = B.TIMEINTERVAL_ID
                    and B.END_DATE = a.EOD_DATE
                    and a.TERM_ID = d.TERM_ID
                    and d.LADDER_ID = 68
                    order by a.EOD_DATE""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if data.empty:
        print("Found no data for (%s, %s): returning nothing" % (ccy, basis))
        return
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(ccy, basis))


def OISLIBOR(ccy, start_date=None, end_date=None, pivot_data=False):
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select X.EOD_DATE, X.TERM_ID, X.value - Y.value VALUE
                    from
                    (select a.EOD_DATE, a.TERM_ID, a.QUOTE_START_PCT+a.QUOTE_SHIFT_PCT VALUE
                    from MARSP.INTEREST_QUOTE_SHIFT a, MARSP.TIMEINTERVAL B, MARSP.INTEREST C, MARSP.LADDER_TERM d
                    where a.INTEREST_ID = C.INTEREST_ID
                    %(date_req)s
                    and C.INTEREST_MARKET_ID = 'DISC_O_Q'
                    and C.CURRENCY_ID = '%(ccy)s'
                    and a.SC_ID = B.TIMEINTERVAL_ID
                    and B.END_DATE = a.EOD_DATE
                    and a.TERM_ID = d.TERM_ID
                    and d.LADDER_ID = 68
                    order by a.EOD_DATE) X,
                    (select a.EOD_DATE, a.TERM_ID, a.QUOTE_START_PCT+a.QUOTE_SHIFT_PCT VALUE
                    from MARSP.INTEREST_QUOTE_SHIFT a, MARSP.TIMEINTERVAL B, MARSP.INTEREST C, MARSP.LADDER_TERM d
                    where a.INTEREST_ID = C.INTEREST_ID
                    %(date_req)s
                    and C.INTEREST_MARKET_ID = 'DISC_L_Q'
                    and C.CURRENCY_ID = '%(ccy)s'
                    and a.SC_ID = B.TIMEINTERVAL_ID
                    and B.END_DATE = a.EOD_DATE
                    and a.TERM_ID = d.TERM_ID
                    and d.LADDER_ID = 68
                    order by a.EOD_DATE) Y
                    where X.EOD_DATE = Y.EOD_DATE
                    and X.TERM_ID = Y.TERM_ID""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if data.empty:
        print("Found no data for %s: returning nothing" % ccy)
        return
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(ccy))


def FX_SPOT(ccy, start_date=None, end_date=None, pivot_data=False):
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select A.EOD_DATE, A.PRICE VALUE
                    from MARSP.CURRENCY_PRICE a
                    where A.CURRENCY_ID = '%(ccy)s'
                    %(date_req)s
                    and A.PRICE_SOURCE_ID in (8, 53)
                    order by A.EOD_DATE""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    data['EOD_DATE'] = [x.strftime('%d/%m/%Y') for x in data['EOD_DATE']]
    return data
    # dataframe_helper.add_sheet_to_excel(data, stress_helper.create_save_path(ccy))


def FX_VOL(ccypair, start_date=None, end_date=None, pivot_data=False):
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select A.EOD_DATE, A.MATURITY_TERM_ID TERM_ID, A.VOL_PCT VALUE
                    from MARSP.VOL_RATE a, MARSP.VOL b
                    where B.UNDL_TYPE_ID = 'CURR_PX'
                    %(date_req)s
                    and A.VOL_ID = B.VOL_ID
                    and B.NAME = '%(ccypair)s'
                    order by A.EOD_DATE, A.MATURITY_NO""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)

    if data.empty:
        print("Found no data for %s: returning nothing" % ccypair)
        return
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(ccypair.replace('/', '')))


def IFL(country_code, start_date=None, end_date=None, pivot_data=False):
    if country_code not in ['EU', 'DK', 'FI', 'US', 'NO', 'UK', 'SE', 'GE', 'ES', 'IT', 'PL']:
        raise TypeError("Country code not supported")
    if country_code == 'DK':
        name = 'MARS_ZC_DK_CPI'
    elif country_code == 'SE':
        name = 'MARS_ZC_S_KPI'
    else:
        name = 'MARS_ZC_%s%%' % country_code
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select A.EOD_DATE, A.TERM_ID, A.INFLATION_PCT VALUE
                    from MARSP.INFLATION_RATE a, MARSP.INFLATION b, MARSP.LADDER_TERM c
                    where A.INFLATION_ID = B.INFLATION_ID
                    %(date_req)s
                    and B.NAME like '%(name)s'
                    and a.TERM_ID = c.TERM_ID
                    and c.LADDER_ID = 68
                    order by A.EOD_DATE, A.MATURITY_DATE""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(country_code))


def EQUITY_LARGEST_EXPOSURES(no_of_exposures=25, start_date=None, end_date=None, use_proxy=False, nordic_region=True, financials=False, pivot_data=False):
    equity_ids = largest_exposures.largest_equity_exposures(no_of_exposures=no_of_exposures, nordic_region=nordic_region, financials=financials)['EQUITY_ID'].unique()
    if use_proxy:
        equity_ids = proxy_helper.get_equity_proxies(equity_ids)['PROJECTION_EQUITY_ID'].unique()
    equity_id_list = ', '.join(map(str, equity_ids))
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select A.EOD_DATE, B.NAME IDENTIFIER, A.PRICE*A.PRICE_QUOTE_FACTOR VALUE
                    from MARSP.PRICE a, MARSP.EQUITY b
                    where B.EQUITY_ID in (%(equity_id_list)s)
                    %(date_req)s
                    and A.EFFECT_ID = B.EFFECT_ID
                    and A.PRICE_TYPE_ID = 'INT'
                    and A.PRICE > 0.001
                    and A.PRICE_QUOTE_FACTOR != 0
                    order by A.EOD_DATE, B.EQUITY_ID""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)

    if pivot_data:
        data = stress_helper.format_singlename_data(data)
    return data
    # output_args = []
    # output_args.append('nordic_region') if nordic_region else 0
    # output_args.append('financials') if financials else output_args.append('non-financials')
    # output_args.append('proxied') if use_proxy else 0
    #
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(*output_args))


def EQUITY_VOL_LARGEST_EXPOSURES(no_of_exposures=30, start_date=None, end_date=None, sectors=None, not_sectors=None, pivot_data=False):
    vol_ids = largest_exposures.largest_equity_vol_exposures(no_of_exposures, sectors, not_sectors)['NAME'].tolist()
    proxies = proxy_helper.get_vol_proxies(vol_ids, 'EQT')['PROJECTION_VOL_ID'].unique().tolist()
    vol_id_str = ', '.join(map(str, proxies))
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select a.EOD_DATE, b.name IDENTIFIER, a.STRIKE, a.MATURITY_TERM_ID, a.TENOR_TERM_ID, a.VOL_PCT VALUE
                    from MARSP.VOL_RATE a, MARSP.VOL B
                    where a.VOL_ID in (%(vol_id_str)s)
                    %(date_req)s
                    and a.vol_id = b.vol_id
                    order by a.EOD_DATE, b.NAME""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)

    if pivot_data:
        data = stress_helper.format_singlename_data(data)
    return data
    # output_args = []
    # output_args.append('_'.join(sectors)) if sectors is not None else 0
    # output_args.append('_'.join(['NOT-' + x for x in not_sectors])) if not_sectors is not None else 0
    # dataframe_helper.add_sheet_to_excel(formatted, stress_helper.create_save_path(*output_args))


def SPREAD_LARGEST_EXPOSURES(term_id, countries, rating_groups, start_date=None, end_date=None, use_proxies=True, pivot_data=False):
    countries = countries if isinstance(countries, list) else [countries]
    spread_ids = largest_exposures.largest_spread_exposures(no_of_issuers=50, countries=countries, rating_groups=rating_groups)['SPREAD_ID'].tolist()
    if use_proxies:
        spread_ids = proxy_helper.get_spread_proxies(spread_ids)['PROJECTION_SPREAD_ID'].unique()

    spread_id_list = ', '.join(map(str, spread_ids))
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select A.EOD_DATE, B.NAME IDENTIFIER, A.SPREAD_PCT VALUE
                    from MARSP.SPREAD_RATE a, MARSP.SPREAD b
                    where A.SPREAD_ID in (%(spread_id_list)s)
                    %(date_req)s
                    and A.PRICE_TYPE_ID = 'INT'
                    and A.TERM_ID = '%(term_id)s'
                    and A.SPREAD_ID = B.SPREAD_ID
                    and A.SPREAD_PCT != 0
                    order by A.EOD_DATE""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if pivot_data:
        data = stress_helper.format_singlename_data(data)
    return data
    # country_string = '-'.join(countries)
    # rating_string = '-'.join(map(str, rating_groups))
    # save_path = stress_helper.create_save_path(term_id, country_string, rating_string, 'proxied') if use_proxies else stress_helper.create_save_path(term_id, country_string, rating_string)
    # dataframe_helper.add_sheet_to_excel(formatted, save_path)


def SPREAD_INDEX(index_spread_id, start_date=None, end_date=None, pivot_data=False):
    if start_date is not None and end_date is not None:
        sd, ed = date_helper.oracle_to_date(start_date), date_helper.oracle_to_date(end_date)
        date_req = "and a.EOD_DATE between %s and %s" % (sd, ed)
    else:
        date_req = "--"
    sql_string = """select EOD_DATE, TERM_ID, SPREAD_PCT VALUE from MARSP.SPREAD_RATE a
                    where a.spread_id = %(index_spread_id)s
                    %(date_req)s""" % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    data = pd.read_sql(sql=sql_string, con=conn)
    if pivot_data:
        data = stress_helper.format_term_data(data)
    return data
    # save_path = stress_helper.create_save_path(index_spread_id)
    # dataframe_helper.add_sheet_to_excel(formatted, save_path)


if __name__ == '__main__':
    for ccy in ('DKK', 'NOK', 'SEK', 'EUR', 'USD', 'JPY', 'GBP', 'AUD', 'NZD', 'HKD'):
        try:
            main_id = mars_helper.get_ir_vol_id(ccy=ccy, vol_interest_market='LAMDA')
            proxy_id = proxy_helper.get_vol_proxies(main_id, 'IR')['PROJECTION_VOL_ID'][0]
            print(ccy, main_id, proxy_id)
        except:
            continue
    # import datetime as dt
    # out = IR_VOL(ccy='DKK',
    #              vol_interest_market='LAMDA',
    #              start_date=dt.datetime(2018, 1, 1),
    #              end_date=dt.datetime(2018, 3, 1),
    #              use_proxy=True)
    # print(out.head())

