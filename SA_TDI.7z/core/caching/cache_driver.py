"""
The cache driver module contain some general functions for cache

Three classes have been designed :
cache_format, decide which format of cache should be used, can be a list of qt Curves (RawTimeSeries) or something else.
cache_method, decide which method of caching will be used
cache_strategy, decide when to use cache and when to use source data

Notes:
    Author: g48454
"""
import hashlib
import json
import logging
import os
import os.path
import pyodbc
import shelve
import pickle
from functools import wraps
from joblib import Memory
from core.caching.cache_format import AnyCacheFormat
from core.caching.cache_method import PickleCacheMethod
from core.caching.cache_strategy import FileNameCacheStrategy
ignored_types = [pyodbc.Connection, pyodbc.Cursor]

CACHE_OFF = 0
CACHE_ON = 1
CACHE_REFRESH = 2

_cache_mode = CACHE_REFRESH
_joblib_memory = None


def easy_cache(cachepath=None, info=0):
    """
    Easy cache decorator, return a decorator for the caching functionality.

    this provide an easy way of caching, it will cahce the output of the functions by using the function name and
    argument inputs as key. It provide an very easy and light way for user to get cache.
    The idea of implementation is create a loader object with default cache functions.

    Args:
        cachepath               (str):    A string contain cache path

    Returns:
        Method

    Example:
        Use the easy cache like this::

            from core.caching.cache_driver import easy_cache
            @easy_cache()
            def my_very_slow_functions(...):
                some slow calculations
                return

    Notes:
        Author: g48454
    """
    def cache_decorator(func):
        @wraps(func)
        def wrap(*args,**kwarg):
            from core.caching.abstract_loader_classes import MasterLoader
            # ===================================================================================
            # Define a temp loader that use the input func as wrapper, and use Pickle file as default cache method
            # ===================================================================================
            class EasyCacheLoader(MasterLoader):
                def __init__(self, name, source, load_from_source):
                    self.cache_format = AnyCacheFormat()
                    self.cache_method = PickleCacheMethod()
                    self.cache_strategy = FileNameCacheStrategy()
                    MasterLoader.__init__(self, 'MarketData', name, source, load_from_source, cache_path=cachepath)
                def return_unique_name(self):
                    return argument_string_key(args, kwarg, func.__name__, func.__module__)
                def load_data_from_source(self):
                    return func(*args, **kwarg)

            # ===================================================================================
            # Create a loader obj defined from the temp loader
            # ===================================================================================
            loader_obj = EasyCacheLoader(name=func.__name__,source='easycache',load_from_source=False)
            if info > 0:
                print(loader_obj.data_source)
            return loader_obj.data
        return wrap
    return cache_decorator


# ===================================================================================
# Lagacy code from Orest, can be integrated to the general setup later.
# ===================================================================================

def joblib_memory():
    "Returns joblib Memory object"
    global _joblib_memory
    if _joblib_memory is None:
        _joblib_memory = Memory(cachedir=cache_path())
    return _joblib_memory
def set_cache_mode(mode):
    """Set cache mode.
    CACHE_OFF      - cachce not used; function value is always recalculated and never written to cache
    CACHE_ON       - cache used; function value is returned from cache if available, otherwise recalculated and stored
    CACHE_REFRESH  - function is always recalculated and written to cache    
    """
    global _cache_mode
    _cache_mode = {
      "ON":CACHE_ON,
      "on":CACHE_ON,
      True:CACHE_ON,
      "OFF":CACHE_OFF,
      "off":CACHE_OFF,
      False:CACHE_OFF,
      "REFRESH":CACHE_REFRESH,
      "refresh":CACHE_REFRESH}.get(mode,mode)
    return _cache_mode

def cache_mode():
    """Return cache mode.
    """
    global _cache_mode
    return _cache_mode

_cache_path="cache"

def set_cache_path(path):
    """Set the directory where cache wiles will be stored.
    """
    global _cache_path
    global _joblib_memory
    _cache_path = path
    if not os.path.exists(path):
        try:
            os.makedirs(path)
            logging.info("Cache directory %s created."%path)
        except:
            logging.exception("Cache directory %s not created."%path)
    _joblib_memory = Memory(cachedir=_cache_path)
    return _cache_path

def cache_path():
    """Returns path to directory containing cache files."""
    global _cache_path
    return _cache_path

def cache(f):
    """Default cache decorator turns on caching on a function.
    Currently implemented using joblib.Memory.
    """
    if cache_mode() is CACHE_OFF:
        return f
    if cache_mode() is CACHE_ON:
        return joblib_memory().cache(f)
    if cache_mode() is CACHE_REFRESH:
        logging.error("Cache refresh not supported, joblib cache is off.")
    return f

def json_cache(f):
    """Function decorator to make a simple cache of function results.    
    Use this if you want to have human-readable cache files (in json format).
    """
    @wraps(f)
    def wrapper(*arg,**kwarg):
        if cache_mode() == CACHE_OFF:
            return f(*arg,**kwarg)
        key=argument_string_key(arg,kwarg,f.__name__,f.__module__)
        path = os.path.join(cache_path(),key+".json")

        if cache_mode() == CACHE_ON:
            if os.path.exists(path):
                try:
                    with open(path) as ff:
                        data = json.load(ff)
                        logging.debug("CAHCE HIT %s"%path)
                        return data
                except:
                    logging.exception("CACHE: Failed to load cache file %s"%path)
        with open(path,"w") as ff:
            logging.debug("CACHE MISS %s"%path)
            result = f(*arg,**kwarg)
            json.dump(result,ff)
            logging.debug("CACHE CREATED %s"%path)
            return result
    return wrapper

def json_cache_iterator(f):
    """Function decorator to make a simple cache of iterator results.
       Use this if you want to have human-readable cache files (in json format).
    """
    @wraps(f)
    def wrapper(*arg,**kwarg):
        if cache_mode() == CACHE_OFF:
            for x in f(*arg,**kwarg):
                yield x
        key=argument_string_key(arg,kwarg,f.__name__,f.__module__)
        path = os.path.join(cache_path(),key+".json")

        if cache_mode() == CACHE_ON:
            if os.path.exists(path):
                try:
                    with open(path) as ff:
                        data = json.load(ff)
                        logging.debug("CAHCE HIT %s"%path)
                        for x in data:
                            yield x
                        return
                except:
                    logging.exception("CACHE: Failed to load cache file %s"%path)
        with open(path,"w") as ff:
            logging.debug("CACHE MISS %s"%path)
            ff.write("[\n")
            sep=""
            for x in f(*arg,**kwarg):
                ff.write(sep)
                ff.write(json.dumps(x))
                sep=",\n"
                yield x
            ff.write("\n]")
            logging.debug("CACHE CREATED %s"%path)
    return wrapper

_memory_cache=None
_key_separator=("_key_separator", "09473e32-7f04-4ead-937e-3a05de86ffaa")

def argument_key(arg,kwarg,prefix=[]):
    """Creates a python hashable key from function arguments.    
    Function arguments should be specified as argument list (arg) and dictionary (kwarg).
    Prefix argument may contain a list of items that will become part of the key.
    """
    global _key_separator,ignored_types
    key=list(prefix)
    key+=[x for x in arg if type(x) not in ignored_types]
    if len(kwarg):
        key.append(_key_separator)
        key+=[(key,value) for key,value in sorted(kwarg.items()) if type(value) not in ignored_types]
    return tuple(key)

def argument_string_key(arg,kwarg,prefix="",extra=""):
    """Generate a unique string out of function arguments.
    Function arguments should be specified as argument list (arg) and dictionary (kwarg).
    Prefix argument may contain string prefix that will become part of the key.
    It will appear both as a prefix, but it will as well influence the hash value.
    Argument extra will not be a vissible part of the key, but it will influence the hash.
    """
    global ignored_types
    prefix=str(prefix)
    arghead = "_".join(str(x) for x in arg[:2] if type(x) not in ignored_types)
    arghead = arghead.replace("/","_")
    arghead = arghead.replace(":", "_")
    arghead = arghead.replace(" ","_").replace("(","_").replace(")","_")
    arghead = arghead.replace(";","_").replace("<","_").replace(">","_")
    arghead = arghead.replace("\n","_").replace(",","_")
    arghead = arghead.replace("__","_").replace("__","_").replace("__","_").replace("__","_")
    arghead = arghead[:20]
    if len(prefix):
        arghead=prefix+"_"+arghead
    m = hashlib.md5()
    m.update(prefix.encode('utf-8'))
    m.update(extra.encode('utf-8'))
    for x in arg:
        if type(x) in ignored_types:
            continue
        m.update(str(x).encode('utf-8'))
        m.update("|,| ".encode('utf-8')) #This can be arbitrary strings, just for hashing purposes it is better if they are unlikely
    m.update(";kwarg:".encode('utf-8'))
    for key,value in sorted(kwarg.items()):
        if type(key) in ignored_types:
            continue
        if type(value) in ignored_types:
            continue
        m.update(str(key).encode('utf-8'))
        m.update("| --->>> |".encode('utf-8'))
        m.update(str(value).encode('utf-8'))
        m.update("|,| ".encode('utf-8'))
    return arghead+"_"+m.hexdigest()

def memory_cache(f):
    """Function decorator to make a simple cache of function results in memory.    
    Use this if you want to have faster in-memory cache.
    Values will be lost when program exits.
    """
    global _memory_cache

    if _memory_cache is None:
        _memory_cache ={}

    @wraps(f)
    def wrapper(*arg,**kwarg):
        key = argument_key(arg,kwarg,[f.__name__,f.__module__])
        try:
            if key in _memory_cache:
                return _memory_cache[key]
        except TypeError:
            return f(*arg,**kwarg)

        result = f(*arg,**kwarg)
        _memory_cache[key] = result
        return result

    return wrapper

_shelve_cache = None

def shelve_cache(f):
    """Function decorator to make a simple persistent cache of function results.    
    Cached values will be stored using shelve in a 'shelve' file inside the cahce folder.
    This is an alternative to json_cache.
    Shelve is not human readable, but can store a more object types and is potentially faster than json_cache.
    """
    global _shelve_cache

    if _shelve_cache is None:
        _shelve_cache = shelve.open(os.path.join(cache_path(),"shelve"))

    @wraps(f)
    def wrapper(*arg,**kwarg):
        try:
            key = json.dumps(argument_key(arg,kwarg,[f.__name__,f.__module__]))
            if key in _shelve_cache:
                logging.debug("SHELVE CACHE HIT "+key)
                return _shelve_cache[key]
        except TypeError:
            logging.exception("Call to %s.%s not chached"%(f.__module__,f.__name__))
            return f(*arg,**kwarg)

        logging.debug("SHELVE CACHE MISS "+key)
        result = f(*arg,**kwarg)
        _shelve_cache[key] = result
        logging.debug("SHELVE CACHE CREATED "+key)
        return result
    return wrapper
            
    
def method_cache(f):
    """
    Cache results of a method inside an instance (or class for a class method).
    This caching method creates a new attribute by postfixing the method name with "_cache_",
    where the results are cached in a dictionary. (I.e. caching is only in memory, not on the disk.)
    
    Example:

        The function can be used like this::

            class A:
                @method_cache
                def f(self,x):
                    return x*x

            class A:
                @classmethod     # Note that classmethod needs to be the first decorator
                @method_cache
                def f(cls,x):
                    return x*x
    Notes:
        Author: g48454
    """
    @wraps(f)
    def wrapper(slf,*arg,**kwarg):
        key = argument_key(arg,kwarg)
        cache_name = f.__name__+"_cache_"
        try:
            cache = getattr(slf,cache_name)
        except AttributeError:
            cache = {}
            setattr(slf,cache_name,cache)
        if key in cache:
            return cache[key]
        result = f(slf,*arg,**kwarg)
        cache[key] = result
        return result

    return wrapper    
    
def method_cache_except_none(f):
    """Behaves like method_cache, but the result is not cached if it is None.
    This is to prevent cache from being flooded by records with invalid requests.
    """
    @wraps(f)
    def wrapper(slf,*arg,**kwarg):
        key = argument_key(arg,kwarg)
        cache_name = f.__name__+"_cache_"
        try:
            cache = getattr(slf,cache_name)
        except AttributeError:
            cache = {}
            setattr(slf,cache_name,cache)
        if key in cache:
            return cache[key]
        result = f(slf,*arg,**kwarg)
        if result is not None:
            cache[key] = result
        return result

    return wrapper
    

class Memoize:
    def __init__(self, func):
        self.func = func
        self.cache = {}

    def __call__(self, *args, **kwargs):
        key = (args, tuple(kwargs.items()))
        if key not in self.cache:
            self.cache[key] = self.func(*args, **kwargs)
        return self.cache[key]


class MemoizeMutable:
    def __init__(self, fn):
        self.func = fn
        self.cache = {}

    def __call__(self, *args, **kwargs):
        key = pickle.dumps(args, 1) + pickle.dumps(kwargs, 1)
        if key not in self.cache:
            self.cache[key] = self.func(*args, **kwargs)
        return self.cache[key]
