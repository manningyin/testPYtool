import json
import os
import pickle
import sys
import datetime as dt
from core.system import config

class FileChecker:
    """"
    A class that holds several functions that checks if the cache file is valid i.e expired or not

    Author: g01571
    """
    @staticmethod
    def valid_file_by_expiry(expiry_seconds=dt.timedelta(3)):
        return lambda x: FileChecker.__valid_file_by_expiry(path=x, expiry_seconds=expiry_seconds)

    @staticmethod
    def valid_always():
        return FileChecker.__always_valid

    @staticmethod
    def valid_never():
        return FileChecker.__never_valid

    @staticmethod
    def __valid_file_by_expiry(path, expiry_seconds):
        creation_date = dt.datetime.fromtimestamp(os.path.getctime(path))
        diff = dt.datetime.now() - creation_date
        return diff.total_seconds() < expiry_seconds.total_seconds()

    @staticmethod
    def __always_valid(path):
        return True

    @staticmethod
    def __never_valid(path):
        return False


class CacheMethod:
    def __init__(self):
        config_dict = config.get()
        expiry = config_dict[config.DefaultConfigurationOptions.caching_expiry_duration_in_days.name]
        self.valid_file = FileChecker.valid_file_by_expiry(expiry_seconds=dt.timedelta(float(expiry)))

    # ===================================================================================
    # Cache method to handle file I/O operation
    # ===================================================================================
    def extract_data_from_cache(self, cache_location):
        raise NotImplementedError

    def get_cache_file_location(self, loader):
        raise NotImplementedError

    def remove_old_cache_files(self, file_locations):
        # Removes if do_caching is on and cache time limit is exceeded for the given file
        for k, path in file_locations.items():
            if os.path.isfile(path) and not self.valid_file(path):
                os.remove(path)

    def get_valid_cached_files(self, file_locations):
        self.remove_old_cache_files(file_locations)
        existing_files = {key: value for key, value in file_locations.items() if os.path.isfile(value)}
        return existing_files

    def dump_data_to_cache(self, cache_file_location,data):
        raise NotImplementedError

    def work_out_loaded_range(self, cache_data, startd,endd):
        raise NotImplementedError


class PickleCacheMethod(CacheMethod):
    def extract_data_from_cache(self, cache_location):
        """
        Check whether the cache file already exists, if yes, check whether the date coverage is enough

        Args:
            cache_location  (str):  Reference to the cache folder (path)

        Returns:
            (DataFrame):  Cached data

        Notes:
            Author: Shengyao
        """
        # ===================================================================================
        #
        # ===================================================================================
        if sys.version_info.major > 2:
            with open(cache_location, 'rb') as f:
                cache_data = pickle.load(f)
        else:
            with open(cache_location, 'r') as f:
                try:
                    cache_data = pickle.load(f)
                except:
                    cache_data = []
        return cache_data

    def get_cache_file_location(self, loader):
        # ===================================================================================
        # A general method to return cache back
        # ===================================================================================
        unique_name = loader.return_unique_name()
        if isinstance(unique_name, dict):
            file_locations = {}
            for key in unique_name.keys():
                file_locations[key] = loader.cache_path + unique_name[key] + '_py' + str(sys.version_info.major) + '.pickle'
            return file_locations
        return loader.cache_path + unique_name + '_py' + str(sys.version_info.major) + '.pickle'

    def dump_data_to_cache(self, cache_file_location, data):
        with open(cache_file_location, 'wb') as f:
            pickle.dump(data, f)


class JSONCacheMethod(CacheMethod):
    def extract_data_from_cache(self,cache_location):
        with open(cache_location, 'r') as f:
            return json.load(f)

    def get_cache_file_location(self,loader):
        # ===================================================================================
        # A general method to return cache back
        # ===================================================================================
        folder_name=loader.cache_path+loader.__class__.__name__ + '_' + loader.source
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)
        unique_name=loader.return_unique_name()
        return folder_name+'/'+ unique_name+'.json'

    def dump_data_to_cache(self,cache_file_location,data):
        with open(cache_file_location, 'w') as f:
            json.dump(data, f)
