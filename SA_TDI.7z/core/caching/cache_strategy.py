import os
import datetime as dt
import pandas as pd
from core.caching.cache_format import DictCacheFormat, FormatError, SeriesCacheFormat


class CacheStrategy:
    def __init__(self):
        return

    def caching(self, loader):
        raise NotImplementedError


class MinDateRange(CacheStrategy):
    def __init__(self):
        CacheStrategy.__init__(self)

    def caching(self, loader):
        file_locations = loader.cache_method.get_cache_file_location(loader)
        cached_files = loader.cache_method.get_valid_cached_files(file_locations)

        if len(file_locations) > 0:
            date_range = list(set(list(zip(*file_locations.keys()))[0]))
            identifiers = list(set(list(zip(*file_locations.keys()))[1]))
        else:
            date_range = []
            identifiers = []

        cache_output = {}
        data_to_load_from_source = set()
        min_date, max_date = dt.datetime(2200, 1, 1), dt.datetime(1900, 1, 1)
        for date in date_range:
            for identifier in identifiers:
                if loader.cache_format.is_already_cached(cached_files, date, identifier):
                    path = file_locations[date, identifier]
                    # TODO: Left side of below equation depends on DictCacheFormat
                    cache_output[date, identifier] = loader.cache_method.extract_data_from_cache(path)
                    # print("File loaded: %s" % path)
                else:
                    min_date = min(min_date, date)
                    max_date = max(max_date, date)
                    data_to_load_from_source.add(identifier)

        # ================================================================================================= #
        # Loop over dates and load all names marked for loading from source
        # ================================================================================================= #
        source_output = loader.cache_format.empty_dataset()
        if len(data_to_load_from_source) > 0:
            temp_data = loader.load_data_from_source(name=data_to_load_from_source, start=min_date, end=max_date)
            loader.cache_format.update_dataset(source_output, temp_data)

        # ================================================================================================= #
        # Dump any data loaded from source to the cache dictionary
        # ================================================================================================= #
        if len(source_output) > 0:
            for key in source_output.keys():
                path = file_locations[key]
                loader.cache_method.dump_data_to_cache(path, source_output[key])
                # print("File cached: %s" % path)

        # ================================================================================================= #
        # Determine which source has been used for loading data - 'mixed', 'cache' or 'loader'
        # ================================================================================================= #
        data_source = {}
        for i in cache_output:
            data_source[i] = True
        for i in source_output:
            data_source[i] = False

        # ================================================================================================= #
        # Merge the results from cache and the results from loader into one variable and return
        # ================================================================================================= #
        data = cache_output.copy()
        loader.cache_format.update_dataset(data, source_output)
        return data, data_source


class NameDateStrategy(CacheStrategy):
    # ===================================================================================================== #
    # The NameDateStrategy in its current implementation relies on using the dictionary format for caching,
    # although this could be changed in the future. The basic idea is to generate a separate cache file for
    # each combination of name/identifier and date passed to the strategy. The strategy works as follows:
    # 1): Generate file locations for all combinations of name/identifier and date
    # 2): List which file locations already exist (determines which files are already caches)
    # 2): Loop through dates and identifiers and check whether these are already cached, if they are save
    #     to output, and if not, mark the date+identifier combination for loading
    # 3): For each date, identify which names must be loaded from source, batch-load these and save to output
    # 4): Dump any source loaded output to the cache
    # ===================================================================================================== #
    def __init__(self):
        CacheStrategy.__init__(self)
        return

    def caching(self, loader):
        # ================================================================================================= #
        # Current implementation of this strategy only supports dictionary format. Planning
        # on changing this in the future
        # ================================================================================================= #
        if not isinstance(loader.cache_format, DictCacheFormat):
            raise FormatError("Caching strategy only supports DictCacheFormat. Specified format is: %s" % loader.cache_format)

        # ================================================================================================= #
        # Generate file locations and determine which files are already cached
        # ================================================================================================= #
        file_locations = loader.cache_method.get_cache_file_location(loader)
        cached_files = loader.cache_method.get_valid_cached_files(file_locations)
        # ================================================================================================= #
        # Ensure date and identifier is in the correct format
        # ================================================================================================= #
        if len(file_locations) > 0:
            date_range = list(set(list(zip(*file_locations.keys()))[0]))
            identifiers = list(set(list(zip(*file_locations.keys()))[1]))
        else:
            date_range = []
            identifiers = []

        # ================================================================================================= #
        # Loop over dates and identifiers, loading any data already cached and marking the rest of the data
        # to be loaded from source later
        # ================================================================================================= #
        cache_output = {}
        data_to_load_from_source = {}
        for date in date_range:
            for identifier in identifiers:
                if loader.cache_format.is_already_cached(cached_files, date, identifier):
                    path = file_locations[date, identifier]
                    # TODO: Left side of below equation depends on DictCacheFormat
                    cache_output[date, identifier] = loader.cache_method.extract_data_from_cache(path)
                    # print("File loaded: %s" % path)
                else:
                    data_to_load_from_source.setdefault(date, []).append(identifier)

        # ================================================================================================= #
        # Loop over dates and load all names marked for loading from source
        # ================================================================================================= #
        source_output = loader.cache_format.empty_dataset()
        for date in data_to_load_from_source.keys():
            identifiers_to_load = data_to_load_from_source[date]
            if len(identifiers_to_load) > 0:
                temp_data = loader.load_data_from_source(identifiers=identifiers_to_load, start=date, end=date)
                loader.cache_format.update_dataset(source_output, temp_data)

        # ================================================================================================= #
        # Dump any data loaded from source to the cache dictionary
        # ================================================================================================= #
        if len(source_output) > 0:
            for key in source_output.keys():
                path = file_locations[key]
                loader.cache_method.dump_data_to_cache(path, source_output[key])
                # print("File cached: %s" % path)

        # ================================================================================================= #
        # Determine which source has been used for loading data - 'mixed', 'cache' or 'loader'
        # ================================================================================================= #
        data_source = {}
        for i in cache_output:
            data_source[i] = True
        for i in source_output:
            data_source[i] = False

        # ================================================================================================= #
        # Merge the results from cache and the results from loader into one variable and return
        # ================================================================================================= #
        data = cache_output.copy()
        data.update(source_output)
        loader.cache_format.update_dataset(data, source_output)

        return data, data_source


class TimeCacheStrategy(CacheStrategy):
    def __init__(self):
        # ===================================================================================
        # The cache strategy will load the  data, below logic has been implemented:
        #  1) the code will firstly check whether the data has already been loaded before.
        #  2) If the data has already been loaded before, change whether the time converge in cached data is enough.
        #  3) If date converge is enough, just load from cache.
        #  4) If not enough, or the data has never been loaded before, the code will workout how many dates are missing,
        #   and then just load the mssing dates and add these dates to cache.
        # ===================================================================================
        CacheStrategy.__init__(self)
        return

    def caching(self,loader):

        # ===================================================================================
        # The TimeCacheStrategy only support the cache format under series cache format class
        # ===================================================================================
        if not isinstance(loader.cache_format,SeriesCacheFormat):
            raise FormatError('cache method not supported by caching strategy! ')
        cache_path = loader.cache_method.get_cache_file_location(loader)
        cache_data = loader.cache_method.extract_data_from_cache(cache_path)
        # ===================================================================================
        # If the cache data got from the cache do not fulfill the requirement, then remove the cache, re-download again
        # ===================================================================================
        if not loader.cache_format.check_format(cache_data):
            os.remove(loader.cache_method.get_cache_file_location(loader))
            data = loader.load_data_from_source()
            data_source = 'loader'
            return data, data_source


        if loader.cache_format.is_already_cached_data_enough(cache_data, loader.startd, loader.endd):
            # ===================================================================================
            # If request time range is within the already loaded range, we just load the data from cache directly.
            # ===================================================================================
            data = loader.cache_format.get_data_from_given_range(cache_data, loader.startd, loader.endd)
            data_source = 'cache'
        else:
            # ===================================================================================
            # Work out the loaded range
            # ===================================================================================
            loader.startd_for_loading, loader.endd_for_loading \
                = self.work_out_loaded_range(loader,cache_data)
            # ===================================================================================
            # now load the data from the new range
            # ===================================================================================
            tempdata = loader.load_data_from_source()
            if not loader.cache_format.check_format(tempdata):
                raise FormatError('loader not align with the cache format! ')
            # ===================================================================================
            # marge the two data cache set
            # ===================================================================================
            cache_data=loader.cache_format.merge_cache_data(cache_data, tempdata)
            loader.cache_method.dump_data_to_cache(loader.cache_method.get_cache_file_location(loader),cache_data)
            data_source = 'mixed'
            # ===================================================================================
            # get the data from the cache_data
            # ===================================================================================
            data = loader.cache_format.get_data_from_given_range(cache_data, loader.startd, loader.endd)

        return data,data_source

    def work_out_loaded_range(self, loader, cache_data):
        from core.utils.date_helper import to_datetime
        startd=to_datetime(loader.startd)
        endd=to_datetime(loader.endd)
        try:
            d1,d2=loader.cache_format.return_range(cache_data)
        except:
            return startd,endd
        d1=to_datetime(d1)
        d2=to_datetime(d2)
        if startd < d1:
            new_startd = startd
            if endd >= d2:
                new_endd = endd
            else:
                new_endd = d1
        else:
            new_endd = endd
            if startd <= d1:
                new_startd = startd
            else:
                new_startd = d2
        return new_startd, new_endd


class FileNameCacheStrategy(CacheStrategy):
    def __init__(self):
        CacheStrategy.__init__(self)
        return

    def caching(self, loader):
        # ===================================================================================
        # if cache file exsisted, load it from there, otherwise load it from source
        # ===================================================================================
        cache_location = loader.cache_method.get_cache_file_location(loader)
        data=loader.cache_method.extract_data_from_cache(cache_location)
        #loader.cache_method.dump_data_to_cache(cache_location,data)
        data_source='cache'
        return data,data_source





