import pandas as pd
from pandas.tseries.offsets import BDay


class CacheFormat():
    '''
    CacheFormat is a special class used for decide which format should be stored in cache.

    For example, we can almost pickle everything, but as required by caching functions, cache strategy need know the format of the cache data.
    '''

    def __init__(self):
        return


class ObservationCacheFormat(CacheFormat):
    def __init__(self):
        CacheFormat.__init__(self)


class DictCacheFormat(ObservationCacheFormat):
    def __init__(self):
        ObservationCacheFormat.__init__(self)

    def check_format(self,data):
        return type(data) is dict

    @staticmethod
    def is_already_cached(cache_dict, *args):
        return args in cache_dict.keys()

    @staticmethod
    def empty_dataset():
        return dict()

    @staticmethod
    def update_dataset(old_dict, new_dict):
        old_dict.update(new_dict)


class FormatError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)


class SeriesCacheFormat(CacheFormat):
    def __init__(self):
        CacheFormat.__init__(self)

    def is_already_cached_data_enough(self, cache_data, startd, endd):
        raise NotImplementedError

    def get_data_from_given_range(self, cache_data,startd,endd):
        raise NotImplementedError

    def merge_cache_data(self,data1,data2):
        raise NotImplementedError


class DataFrameCacheFormat(SeriesCacheFormat):
    def __init__(self):
        SeriesCacheFormat.__init__(self)

    def check_format(self,data):
        import pandas
        answer=False
        if type(data) is pandas.core.frame.DataFrame:
            if data.empty:
                return False
            if data.index.dtype_str == 'datetime64[ns]' or 'date' in data.index.name:
                return True
        return answer

    def is_already_cached_data_enough(self,cache_data,startd,endd):
        answer=False
        try:
            d1,d2=self.return_range(cache_data)
        except:
            return False
        if startd >= d1 and endd <= d2:
            answer=True
        return answer

    def merge_cache_data(self,data1,data2):
        for currt in data1.index:
            if currt not in data2.index:
                data2=data2.append(data1[data1.index == currt])
        return data2

    def get_data_from_given_range(self, cache_data,startd,endd):
        return cache_data[(cache_data.index<=endd) & (cache_data.index>=startd)]

    def return_range(self,cache_data):
        if len(cache_data.index)>1:
            return sorted(cache_data.index)[0], sorted(cache_data.index)[-1]
        else:
            return cache_data.index[0],cache_data.index[0]


class RawTimeSeriesCacheFormat(SeriesCacheFormat):
    def __init__(self):
        SeriesCacheFormat.__init__(self)

    def check_format(self,data):
        return data.__class__.__name__ == 'RawTimeSeries'

    def is_already_cached_data_enough(self,cache_data,startd,endd):
        try:
            d1,d2=self.return_range(cache_data)
            if cache_data.convert_date(startd) >= d1 \
                    and cache_data.convert_date(endd) <= d2:
                answer=True
            else:
                answer=False
        except:
            answer=False
        return answer

    def get_data_from_given_range(self, cache_data,startd,endd):
        from core.utils.RawTimeSeries import RawTimeSeries
        final_data = RawTimeSeries(name='default')
        for d in pd.date_range(start=startd, end=endd, freq=BDay(1)):
            try:
                final_data.addItem(cache_data.getvalue(d), d)
            except:
                continue
        return final_data

    def merge_cache_data(self,data1,data2):
        for currt in data1.cacheDate:
            if currt not in data2.cacheDate:
                data2.addItem(data1.getvalue(currt), currt)
        return data2


    def return_range(self,cache_data):
        return sorted(cache_data.cacheDate)[0], sorted(cache_data.cacheDate)[-1]


class AnyCacheFormat(CacheFormat):
    # ===================================================================================
    # A cache format that can support any kinds of file format
    # ===================================================================================
    def __init__(self):
        CacheFormat.__init__(self)

    def check_format(self,data):
        return True


