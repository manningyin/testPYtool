"""
The module contain some general loader module

The module include cache functionalists as well as providing a way to manage different data sources.
The module contain a super class master_loader which contain all cache functionaries and source management.
User can implement various sub-classes under the super class.

Examples:
    Example 1::

        test_data = mort_bond_curve(name    = 'test1',
                                    startd  = datetime.datetime(2016,1,1),
                                    endd    = datetime.datetime(2016,11,1),
                                    source  = 'webservice',
                                    )

        # will load the bond curve dynamics by using mort bond curve from data source 'web service'

    More example can be find in
    https://confluence.itcm.oneadr.net/display/MRIA/Example+scripts

Notes:
    Author: g48454

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       14feb2017   G48454      Initial creation
    2       01apr2017   G48454      Second version, isolate cache part
    3       29dec2017   G48454      Add matrix loader on the module
    4       12mar2018   G48606      Review, refactoring and clean-up of the code
    ======= =========   =========   ========================================================================================
"""
import os
import pandas as pd
import core.utils.date_helper
from core.caching.cache_format import DictCacheFormat
from core.caching.cache_method import PickleCacheMethod
from core.caching.cache_strategy import NameDateStrategy
from core.system import envir, config
from core.utils import date_helper, shock_days


class MasterLoader:
    def __init__(self, loader_type, name, source, load_from_source, cache_path=None):
        self.type = loader_type
        self.name = name
        self.source = source
        # ===================================================================================
        # First try to see whether the cache_path has been assigned in the sub class, if not, direct to a default folder
        # If folder does not exist, make the cache folder
        # ===================================================================================
        self.cache_path = self.return_default_cache_path() if cache_path is None else cache_path
        if not os.path.exists(self.cache_path):
            os.makedirs(self.cache_path)

        self.do_caching = config.get()[config.DefaultConfigurationOptions.do_caching.name]

        # ===================================================================================
        # if user ask directly loading from source
        # ===================================================================================
        self.direct_load_from_source = load_from_source
        self.data = self.load()

        # If warning are set to be verbose from yaml config, warn for loaded from cache identifiers
        #TODO: what happens if data source is not dict then does not print warning take that into account
        if config.get()[config.DefaultConfigurationOptions.show_cache_warning.name] and isinstance(self.data_source, dict):
            loaded_from_cache_identifiers= [x[1] for x in self.data_source if self.data_source[x]]
            if len(loaded_from_cache_identifiers)>0:
                print("Loaded following identifiers from the cache {}".format(loaded_from_cache_identifiers))

    def return_default_cache_path(self):
        """
        Returns the default cache path defined by the core.system.envir module. A specific folder named after the
        subclass is created to store cache files.
        """
        loader_name = self.__class__.__name__
        path = envir.sub_cache_path(sub_path=loader_name)
        return path

    # ===================================================================================
    # abstract attributes
    # ===================================================================================
    def load_data_from_source(self, *args, **kwargs):
        raise NotImplementedError("Please Implement this method")

    def cache_format(self):
        raise NotImplementedError

    def cache_strategy(self):
        raise NotImplementedError

    def cache_method(self):
        raise NotImplementedError

    def return_unique_name(self):
        raise NotImplementedError

    def load(self):
        if not self.do_caching:
            data = self.load_data_from_source()
            self.data_source = 'loader'
            return data

        # ===================================================================================
        # load the data from either cache or market data loader
        # ===================================================================================

        cache_location = self.cache_method.get_cache_file_location(self)

        # ===================================================================================
        # If the cache file doesn't exist, load data from source directly and dump the data to cache
        # ===================================================================================
        if not isinstance(cache_location, dict):
            self.cache_method.get_valid_cached_files({0: cache_location})
            if not os.path.isfile(cache_location):
                data = self.load_data_from_source()
                self.data_source = 'loader'
                if not self.direct_load_from_source:
                    self.cache_method.dump_data_to_cache(cache_location,data)
                return data

        if self.direct_load_from_source:
            data = self.load_data_from_source()
            self.data_source = 'loader'
            return data

        # ===================================================================================
        # otherwise, get the data from cache which defined by the cache_strategy item
        # ===================================================================================
        data, self.data_source = self.cache_strategy.caching(loader=self)
        # print(self.data_source)
        return data

    def clean_cache_if_any(self):
        # ===================================================================================
        # check whether there is any cache files, if it is true, remove the cache file.
        # ===================================================================================
        cache_location = self.cache_method.get_cache_file_location(self)
        if not isinstance(cache_location, dict):
            if os.path.isfile(cache_location):
                os.remove(cache_location)
        else:
            for path in cache_location.values():
                if os.path.isfile(path):
                    os.remove(path)


class SeriesLoader(MasterLoader):
    def __init__(self, name, source, startd, endd, load_from_source, cache_path=None):
        # ===================================================================================
        # Loader for time series
        # ===================================================================================
        self.startd = date_helper.to_datetime(startd)
        self.endd = date_helper.to_datetime(endd)
        self.startd_for_loading = self.startd
        self.endd_for_loading = self.endd
        self.date_list = [x for x in pd.bdate_range(self.startd, self.endd) if x not in core.utils.date_helper.holidays_between(self.startd, self.endd)]
        MasterLoader.__init__(self, loader_type='Series', name=name, source=source, load_from_source=load_from_source, cache_path=cache_path)


class MatrixLoader(SeriesLoader):
    """
    An abstract class for loading data as a matrix, with dates along one dimension, and names along the other dimension.
    Examples of names could be tenor points, market_data_ids, trade_ids, etc. [use your imagination :)]

    It should be noted that currently the NameDateStrategy must be used for the MatrixLoader to work - these were built
    together. It is a project of the future to make these two components work separate from each other. Further, the
    NameDateStrategy only works for the dictionary cache format, another requirement that could be generalized. For this
    reason, we hard-code caching method, strategy and format in this abstract class.
    """

    def __init__(self, names, startd, endd, load_from_source=False, cache_path=None, source=None):
        self.cache_method = PickleCacheMethod()
        self.cache_strategy = NameDateStrategy()
        self.cache_format = DictCacheFormat()
        SeriesLoader.__init__(self, name=names, startd=startd, endd=endd, source=source,
                              load_from_source=load_from_source, cache_path=cache_path)

    def return_unique_name(self):
        """
        Creates a dictionary with unique names for each pair of date and identifier. The unique identifier is comprised
        of class name, date, and identifier (and any optional parameters saved under 'unique_params').
        """
        unique_params = getattr(self, 'unique_params', [])
        unique_params = unique_params if isinstance(unique_params, list) else [unique_params]
        unique_params_str = '_'.join(map(str, unique_params))
        unique_params_str = '_' + unique_params_str if unique_params_str else ''

        trade_id_list = self.name if isinstance(self.name, list) else [self.name]
        out = {}
        for date in self.date_list:
            for trade_identifier in trade_id_list:
                joined = '_'.join(map(str, trade_identifier)) if hasattr(trade_identifier, '__iter__') else str(trade_identifier)
                out[date, trade_identifier] = '_'.join([self.__class__.__name__, date.strftime('%Y%m%d'), joined]) + unique_params_str
        return out

    def load_data_from_source(self, identifiers=None, start=None, end=None):
        """
        For each input date, the source loading function is called to fetch the data. If load_from_source == True, this
        function is called with self.startd_for_loading and self.endd_for_loading.

        Otherwise, the function is called by the NameDateStrategy. The NameDateStrategy generates a lookup dictionary
        with not already cached data, with dates as key and list of names as value. The load_data_from_source is then
        called for each key in this lookup dictionary
        """
        if identifiers is None: identifiers = self.name
        if start is None: start = self.startd_for_loading
        if end is None: end = self.endd_for_loading
        out = {}
        date_range = [x.to_pydatetime() for x in pd.bdate_range(start, end)]
        for date in date_range:
            # print("%s load data on date: %s" %(self.__class__.__name__ , date))
            temp = self.source_loading_function(identifiers, date)
            out.update(temp)
        return out

    def source_loading_function(self, names, date):
        raise NotImplementedError


class DailyLoader(MasterLoader):
    def __init__(self, name, source, currt, load_from_source, cache_path=None):
        """
        Create a market data object

        Warning:
           This is an abstract class, you should not call it directly.

        Notes:
            Author: g48454
        """
        self.currt = currt
        MasterLoader.__init__(self, 'Daily', name, source, load_from_source, cache_path=cache_path)

    def return_unique_name(self):
        date_str = date_helper.date_format(self.currt, 'DDMONYYYY')
        return 'data' + '_' + date_str


class CurveSeriesLoader(SeriesLoader):
    # ===================================================================================
    # general loader for any series that contain term structural information,
    # you should never call this loader directly since it is designed as an abstract class
    # ===================================================================================
    def __init__(self, name, source, startd, endd,load_from_source=False):
        SeriesLoader.__init__(self, name, source, startd, endd, load_from_source)

    def retunDataFrameSeries(self):
        # ===================================================================================
        # The method will return the DataFrameSeries implemented in loader object done by Orest
        # ===================================================================================
        from core.market_data.Observable_legacy_code.loader import DataFrameSeries

        # ===================================================================================
        # Call methods implemented in RawTimeSeries Object to transfer the data to dataframe
        # ===================================================================================
        df=self.data.to_pd_DataFrame(buckets=self.return_std_buckets())
        df=df.set_index(['date'])
        # ===================================================================================
        # Add name to the columns
        # ===================================================================================
        df.columns = [self.name+'_'+x for x in list(df.columns)]
        series = DataFrameSeries(df=df,observable_definition_provider=None)
        series.source = {
          "loader_class":self.__class__.__name__,
          "loader_description":"Series Loader",
          "from_date":self.startd,
          "to_date":self.endd,
          "observables":list(df.columns),
          "sources":self.source}
        return series

    def return_std_buckets(self):
        raise NotImplementedError("Shoule be implemented in subclass")
