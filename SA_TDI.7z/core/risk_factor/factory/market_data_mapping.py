from core.market_data import mdh_helper
from core.system import ext_envir


class MarketDataMapping(object):
    def get_source_mapping(self,md_map_hierarchy):
        """
        Get source specific market data mapping, based on a prioritized list of source systems.

        Args:
            md_map_hierarchy    (list of ext_envir.<SourceSystem>): Market data source systems in prioritized order.
                                                                    E.g. [ext_envir.RiskFactorRepository.dev,ext_envir.ScenarioEngine.uat]

        Returns:
            (int or str):   Identifier of market data in the chosen source system.


        Example:
            The module is called (from python) like this::

                my_risk_factor.new_map = my_risk_factor.get_source_mapping( [
                                                                            ext_envir.RiskFactorRepository.dev,
                                                                            ext_envir.ScenarioEngine.uat
                                                                            ])

        Notes:
            Author: JBrandt
        """
        for source in md_map_hierarchy:

            system = source.system
            envir = source.envir

            # ===================================================================================
            # We will try to find a market data mapping towards the highest prioritized market
            # data source. If not found, then the next highest prioritized and onwards until
            # we find a mapping to market data.
            #
            # We accept that mapping functions for the chosen source have not been implemented.
            # This is seen as a "non-event" corresponding to no mapping found.
            # ===================================================================================

            if system.lower() == 'mars':
                try:
                    md_mapping = self._mars_mapping(self.riskfactor, envir)
                    print(self.riskfactor)
                except NotImplementedError:
                    md_mapping = None
            elif system.lower() == 'damd':
                try:
                    md_mapping = self._damd_mapping(self.riskfactor)
                except NotImplementedError:
                    md_mapping = None
            elif system.lower() == 'mdhub':
                try:
                    md_mapping = self._mdhub_mapping(riskfactor     = self.riskfactor,
                                                     mdhub_envir    = envir,
                                                     )
                except NotImplementedError:
                    md_mapping = None
            else:
                raise KeyError('Unknown or unsupported source: ' + source)

            if md_mapping is not None:
                # ===================================================================================
                # Mapping has been found, we will exit the loop (no need for finding mapping
                # for lower prioritized market data sources.
                # ===================================================================================
                break
        if md_mapping is None:
            raise NotImplementedError(  'Not able to find mapping in any of the sources: ' + str(md_map_hierarchy) +
                                        ' for risk factor: ' + str(self.riskfactor))

        return md_mapping

    def _mars_mapping(self,riskfactor,mars_envir):
        """Defines MARS mapping for a risk factor"""
        raise NotImplementedError

    def _damd_mapping(self,riskfactor):
        """Defines DAMD mapping for a risk factor"""
        raise NotImplementedError

    def _mdhub_mapping(self,riskfactor,mdhub_envir):
        """Defines Market Data Hub mapping for a risk factor"""
        raise NotImplementedError

    def get_mapping(self, *args, **kwargs):
        """Defines default mapping for a risk factor"""
        raise NotImplementedError


class MarsMarketDataMapping(MarketDataMapping):
    _SCENARIOENGINE_MARS_NAME = '.MarsMarketDataId'

    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        raise NotImplementedError

    @staticmethod
    def _mars_maturity_tenor(riskfactor):
        return ''

    @staticmethod
    def _risk_type():
        raise NotImplementedError

    @staticmethod
    def _mars_underlying_maturity_tenor(riskfactor):
        return ''

    @classmethod
    def _mars_mapping(cls, riskfactor, environment=None):
        return {'mdType': cls._SCENARIOENGINE_MARS_NAME,
                'mars_risk_factor_id': cls._mars_risk_factor_id(riskfactor, environment),
                'maturity_tenor': cls._mars_maturity_tenor(riskfactor),
                'risk_type': cls._risk_type(),
                'underlying_maturity_tenor': cls._mars_underlying_maturity_tenor(riskfactor)}

    def get_mapping(self, *args):
        return self._mars_mapping(self.riskfactor, *args)


class DamdMarketDataMapping(MarketDataMapping):
    _SCENARIOENGINE_DAMD_NAME = '.DamdMarketDataId'

    @staticmethod
    def _market_data_id(riskfactor):
        raise NotImplementedError

    @staticmethod
    def _risk_type():
        raise NotImplementedError

    @classmethod
    def _damd_mapping(cls, riskfactor):
        return {"mdType": cls._SCENARIOENGINE_DAMD_NAME,
         "marketDataId": cls._market_data_id(riskfactor),
         "riskType": cls._risk_type()}

    def get_mapping(self):
        return self._damd_mapping(self.riskfactor)


class MdHubMarketDataMapping(MarketDataMapping):
    _SCENARIOENGINE_MDHUB_NAME = '.MdHubMarketDataId'

    @staticmethod
    def _instrument_id(riskfactor, mdh_envir):
        """
        Getting Market Data Hub Instrument Id for the risk factor.

        Args:
            riskfactor  (dict):     Risk Factor object matching the general defined structure.

        Returns:
            (dict):     Environment name and corresponding mdh instrument id e.g. {'envir': 'test', 'instrument_id': 231}

        Warning:
            Currently the method returns mapping element even though no mapping is found.
            In that case the id is set to None.

        Notes:
            Author: JBrandt
        """

        try:
            instrument_id = mdh_helper.get_rf_instrument_id(risk_factor=riskfactor,
                                                            mdhub_envir=mdh_envir,
                                                            )
        except:
            # No mapping available for this ccy pair. Ok and expected (for now)
            instrument_id = None

        return instrument_id

    @staticmethod
    def _envir(riskfactor):
        raise NotImplementedError

    @staticmethod
    def _risk_type():
        raise NotImplementedError

    @classmethod
    def _mdhub_mapping(cls, riskfactor, mdhub_envir):
        md_map = {"mdType"        : cls._SCENARIOENGINE_MDHUB_NAME,
                  "instrumentId"  : cls._instrument_id(riskfactor=riskfactor, mdh_envir=mdhub_envir),
                  "riskType"      : cls._risk_type(),
                 }
        return md_map

    def get_mapping(self):
        md_hub_envir = ext_envir.get()['MDHub']
        try:
            return self._mdhub_mapping(riskfactor = self.riskfactor, mdhub_envir = md_hub_envir)
        except Exception as e:
            raise Exception("Problem occurred when getting mapping to Market Data Hub. Message: " + str(e))