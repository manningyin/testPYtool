"""
Implements risk factor classes as they are defined in the risk factor repository.

Risk factor repository defines a number of risk factors, and each of them needs to be created here for use in
ScenarioEngine. Each risk factor should inherit from the Riskfactor class, with the specific riskfactor definition in
the .riskfactor attribute.


Notes:
    Author: Arnold Skimminge (G48015)

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01jun2017   g48015      Initial creation
    2       14feb2017   g50444      Adding support of new RFR API. Removing implicit functionality, where risk factors
                                    where added to RFR on time of creation.
    3       12nov2019   g01571      Added the support for RefinanceRiskFactor and Interest Rate Volatility
    ======= =========   =========   ========================================================================================

"""

import getpass
import json
import os.path
import inspect

import avro.io
import avro.schema
import six
from enum import Enum
from risk_factor_repository.models.market_data_mapping import MarketDataMapping
from risk_factor_repository.models.market_data_mapping_context import MarketDataMappingContext
from core.utils import list_helper

from core.connection import api
from core.types import market_data_object
from core.utils import dict_helper

this_path = os.path.abspath(__file__)

__SCHEMAS__ = {}


class RiskFactorType(Enum):
    """
    Class enum object for risk factor types. Main purpose is to hold the mapping between (internal) types and avro names.

    Properties:
        - "name" is the (internal) "name" of the risk factor. Typically matching the class names
          (but this is not required).
        - "avro_schema_name" is the name of the avro-schema object matching the risk factor type.

    Example:
        Testable example:
        >>> from core.risk_factor.factory import risk_factor_domain as rfd
        >>> rf_type = rfd.RiskFactorType.RfCcyPair
        >>> rf_type.avro_schema_name.replace('2', '').replace('0', '')
        'com.nordea.riskfactor.domain.fx.RfCcyPair'

    Notes:
        Author: JBrandt (g50444)
    """
    # ===================================================================================
    # This serves as mapping between internal risk factor types and avro schemas.
    # Structure is (name = value):
    #   - InternalRiskFactorName = AvroSchemaName
    # ===================================================================================

    # FX
    RfCcyPair = 'com.nordea.riskfactor.domain.fx.RfCcyPair20'

    # Interest Rate
    RfInterestRate = 'com.nordea.riskfactor.domain.rates.RfInterestRate'

    # Credit
    RfBondSwapBasis = 'com.nordea.riskfactor.domain.credit.RfBondCurveRate'
    RfBondResidualZspread = 'com.nordea.riskfactor.domain.credit.RfBondZspread'
    RfHazardRate = 'com.nordea.riskfactor.domain.credit.RfHazardRate'
    RfRecoveryRate = 'com.nordea.riskfactor.domain.credit.RfRecoveryRate'

    # DMB Refinance
    RfRefinanceRate = 'com.nordea.riskfactor.domain.rates.RfRefinanceRate'
    RfInterestAtmVolatility = 'com.nordea.riskfactor.domain.rates.RfInterestAtmVolatility'

    @property
    def avro_schema_name(self):
        """
        The enum "value" is the right side of the "=" sign. Renaming/copying to new more explanatory name.
        """
        return self.value

    @property
    def risk_factor_class(self):
        """
        Reference/mapping to the risk factor class type specific objects, thus linking type and object together.

        Returns:
            (Class): The risk factor object, which can then be used for generating risk factors of this specific type.

        Notes:
            Author: JBrandt (g50444)
        """
        if self == RiskFactorType.RfCcyPair:
            import core.risk_factor.factory.fx.domain
            return core.risk_factor.factory.fx.domain.RfCcyPair

        elif self == RiskFactorType.RfInterestRate:
            import core.risk_factor.factory.rates.domain
            return core.risk_factor.factory.rates.domain.RfInterestRate

        elif self == RiskFactorType.RfBondSwapBasis:
            import core.risk_factor.factory.credit.domain
            return core.risk_factor.factory.credit.domain.RfBondCurveRate

        elif self == RiskFactorType.RfBondResidualZspread:
            import core.risk_factor.factory.credit.domain
            return core.risk_factor.factory.credit.domain.RfBondZspread

        elif self == RiskFactorType.RfHazardRate:
            import core.risk_factor.factory.credit.domain
            return core.risk_factor.factory.credit.domain.RfHazardRate

        elif self == RiskFactorType.RfRecoveryRate:
            import core.risk_factor.factory.credit.domain
            return core.risk_factor.factory.credit.domain.RfRecoveryRate
        elif self == RiskFactorType.RfRefinanceRate:
            import core.risk_factor.factory.rates.domain
            return core.risk_factor.factory.rates.domain.RfRefinanceRate
        elif self == RiskFactorType.RfInterestAtmVolatility:
            import core.risk_factor.factory.rates.domain
            return  core.risk_factor.factory.rates.domain.RfInterestAtmVolatility
        else:
            raise NotImplementedError("Missing mapping between risk factor type: "
                                      + str(self.name) + " and corresponding risk factor class. Please add!")

    @property
    def risk_factor_factory(self):
        """
        Reference/mapping to the risk factor factory (function) used for creating risk factors of this type.

        This method works as a link from risk factor type to factories generating risk factors of this type.
        Since it is a property, it is referred to without ending (). And since it returns a function, adding the ending
        ()

        Returns:
            (function): Function that can be used for generating risk factors of this type.

        Example:
            The module is called (from python) like this::

                my_risk_factors = RiskFactorType.RfCcyPair.risk_factor_factory()

        Notes:
            Author: JBrandt (g50444)
        """

        if self == RiskFactorType.RfCcyPair:
            import core.risk_factor.factory.fx.factory
            return core.risk_factor.factory.fx.factory.fx_pair
        elif self == RiskFactorType.RfInterestRate:
            import core.risk_factor.factory.rates.factory
            return core.risk_factor.factory.rates.factory.interest_rate_risk_factors
        elif self in (RiskFactorType.RfBondSwapBasis, RiskFactorType.RfBondResidualZspread):
            import core.risk_factor.factory.credit.factory
            return core.risk_factor.factory.credit.factory.from_positions
        elif self == RiskFactorType.RfHazardRate:
            import core.risk_factor.factory.credit.factory
            return core.risk_factor.factory.credit.factory.hazard_rate
        elif self == RiskFactorType.RfRecoveryRate:
            import core.risk_factor.factory.credit.factory
            return core.risk_factor.factory.credit.factory.recovery_rate
        elif self == RiskFactorType.RfRefinanceRate:
            import core.risk_factor.factory.rates.factory
            return core.risk_factor.factory.rates.factory.dmb_refi_risk_factors
        elif self == RiskFactorType.RfInterestAtmVolatility:
            import core.risk_factor.factory.rates.factory
            return core.risk_factor.factory.rates.factory.interest_rate_atm_volatility
        else:
            raise NotImplementedError("Missing mapping between risk factor type: "
                                      + str(self.name) + " and corresponding risk factor class. Please add!")

    @property
    def risk_factor_class_args(self):
        """
        Returns the __init__ arguments for the specific risk factor type class.

        Returns:
            (list of str): Description

        Notes:
            Author: JBrandt (g50444)
        """
        if six.PY2:
            members = dict(inspect.getmembers(self.risk_factor_class.__init__.__func__.__code__))
        else:
            members = dict(inspect.getmembers(self.risk_factor_class.__init__.__code__))
        var_names = members['co_varnames']

        # Getting rid of the "self" argument, which is not specific to "this" risk factor class
        attributes = [arg for arg in var_names if arg != 'self']
        return attributes


class RiskFactor(object):
    """
    Riskfactor base class for all risk factors in ScenarioEngine

    Each risk factor type must implement these methods
         def __init__(self)
         def include(self)
         def group_by(self)
         def liquidity_horizon(self)
         def scope(self)
         def sub_category(self)


    Methods use @property so they can be invoked without empty '()'. eg. riskfactor.include instead of riskfactor.include().

    Methods are used by ContextFactory to build risk factor contexts and risk factor mapping contexts.

    Parameters:

        _RFTYPE: avro type of the risk factor

    Notes:
        Author: Arnold Skimminge (G48015)
    """

    _LIQUIDITY_HORIZONS = [10, 20, 40, 60, 120]

    _RFTYPE = None

    def __init__(self):
        self.metadata = self._rf_meta_data()
        self.mdmapping = self.get_mapping()

    @property
    def RISK_FACTOR_TYPE(self):
        return NotImplementedError

    @property
    def liquidity_horizon(self):
        """
        Liquidity horizon as prescribed in FRTB for a risk factor

        Used by ContextFactory to create riskfactor context and risk factor mapping context for liquidity scaled
        expected shortfall calculations.

        Returns:
            (float):   Liqidity horizon,
                       Prescribed values are 10, 20, 40, 60, 120

        Raises:
            NotImplementedError when not overloaded by child class

        Example:
            The method is overloaded in python like this::

                class RfCcyPair(RiskFactor):
                    _RFTYPE = 'com.nordea.riskfactor.domain.equity.RfCcyPair'
                    _liquid_currencies = ('USD', 'GBP', 'CHF', 'JPY')
                    _BASE_CURRENCY = 'EUR'
                    _RISK_CLASS = 'FX'

                    def __init__(self, ccy1, ccy2):
                        self.riskfactor = dict(
                            rfType=self._RFTYPE,
                            ccy1=ccy1,
                            ccy2=ccy2)

                    @property
                    def liquidity_horizon(self):
                        if self.riskfactor['ccy2'] in self._liquid_currencies:
                            return 10
                        else:
                            return 20

        Notes:
            Author: Arnold Skimminge (G48015)
        """

        raise NotImplementedError

    @property
    def sub_category(self):
        """
        FRTB risk factor sub category
        """
        raise NotImplementedError

    @property
    def shock_type(self):

        # TODO: I don't think shock_type should be part of the risk factor definition. Consider one day you want to test different shock type for same risk factor, you don't want to re-define all risk factor
        """
        Type of shock (ADDITION, MULTIPLICATION, ...) of object type: core.types.scenario_types.ShockType
        """
        raise NotImplementedError

    @property
    def time_series_structure(self):
        """
        Structure of time series (curve, point).
        """
        raise NotImplementedError

    @property
    def interpolation_type(self):
        """
        Determines interpolation type for a risk factor type. Default is linear.

        Notes:
            Author: JBrandt (g50444)
        """
        return market_data_object.CurveInterpolation.CurveLinear

    def atoms(self):
        """
        Trivial method to generate atomic risk factors for non-composite risk factors
        """
        yield self.riskfactor

    def description(self):
        """
        Shown in risk factor repository
        """
        return str(self.riskfactor)

    def long_name(self):
        """
        Shown in risk factor repository
        """
        return str(self.riskfactor)

    def short_name(self):
        """
        Shown in risk factor repository
        """
        return str(self.riskfactor)

    def __eq__(self, other):
        """Equality operator"""
        return self.riskfactor == other.riskfactor

    def __hash__(self):
        """Hash function for risk factors to be used as index in dictionary"""
        return hash(json.dumps(self.riskfactor, sort_keys=True))

    def rfr_hash(self):
        """
        Using Risk Factor Repository to calculate checksum in order to determine if factor should be inserted, updated or neither.



        Returns:
            (hash):   Risk Factor Repository checksum


        Warning:

        Notes:
            Author: Arnold Skimminge (documented by g50444 Jonas Brandt)
        """
        try:
            checksum = self.RF_API.riskfactor.calculate_checksum(self.rfr_dict())
        except Exception as e:
            raise KeyError('Not able for RFR API to calculate checksum for risk factor: ' + str(self.riskfactor))
        return checksum

    def add_label(self, name, value, group = 'master'):
        """
        Manually add (or replace) label to risk factors meta data.

        A label is key value pairs consisting of name (of the key) and its corresponding value.
        Each label has a "group" attribute, which adds the flexibility to have different values
        and labels in different "groups". Default label group is the 'master'.

        Args:
            name    (str):  Name of the label - will be put in the labels "name" variable.
            value   (str):  Value of the label
            group   (str):  Tag that will be put in the labels "group" variable.

        Returns:
            (None):     Nothing - but adds label to the "labels" dictionary in the metadata object.

        Example:
            The module is called (from python) like this::

                # After creating a risk factor - my_risk_factor

                my_risk_factor.add_label(group = 'master', name = 'LIQUIDITY_HORIZON', value = '10')

        Notes:
            Author: JBrandt (g50444)
        """

        # Deleting existing label with same name within same group
        self.delete_label(name = name, group = group)

        # Creating label
        label = dict(type  = 'LABEL',
                     group = group,
                     name  = name,
                     value = str(value),
                     )

        # Adding label
        self.metadata['labels'].append(label)

    def delete_label(self, name, group):
        """
        Method for deleting labels (if they exist).

        Args:
            name    (str):  Name of the label - will be put in the labels "name" variable.
            group   (str):  Tag that will be put in the labels "group" variable.

        Returns:
            (NA): Does not return anything. Deletes a label...

        Notes:
            Author: JBrandt (g50444)
        """

        # Deleting existing label with same name within same group
        for i in range(0, len(self.metadata['labels'])):
            existing_label = self.metadata['labels'][i]
            if existing_label['group'] == group and existing_label['name'] == name:
                # ===================================================================================
                # Found existing label.
                # - Deleting label
                # - Stop searching for other duplicated labels (break). Labels should already be
                #   uniquely defined.
                # ===================================================================================
                del self.metadata['labels'][i]
                break



    def has_label(self, name = None, value = None, group = 'master', label_as_obj = None):
        """
        Determines if risk factor has a specific label (with out without specific value).

        Args:
            name            (str):      Name of the label
            value           (str):      [default:None] Value of the label that you want to match.
                                        If set to None the value is not evaluated.
            group           (str):      [default:'master'] Name of the label group.
            label_as_obj    (Label):    List of labels either of the core.risk_factor.context.Label type
                                        or as a dictionary containing all the relevant keys.

        Returns:
            (bool): True if risk factor has the label (with specified value if chosen) False if not

        Raises:

        Example:
            The module is called (from python) like this::

                my_risk_factor.has_label(name = 'zero_coupon', value = 'True', group = 'master)

        Notes:
            Author: JBrandt (g50444)
        """
        if label_as_obj is None:
            if None in (group, name):
                # If input is not an object, at least group and name must contain values.
                raise KeyError('Both "label_as_obj" and (group,name) are None. Expecting one of these to hold values')
            _group = group
            _name = name
            _value = value
        else:
            try:
                # Support of input being of the "Label" object type
                _group = label_as_obj.group
                _name = label_as_obj.name
                _value = label_as_obj.value
            except:
                if 'hasLabel' in label_as_obj:
                    label_as_obj = label_as_obj['hasLabel']
                # Support of input being a plain dictionary
                _group = label_as_obj['group']
                _name = label_as_obj['name']
                _value = label_as_obj['value']

        for label in self.metadata['labels']:
            if (label['group'] == _group and label['name'] == _name):
                # Risk factor has the chosen label... Matching value if requested by user
                if _value == None:
                    # ===================================================================================
                    # Risk factor has this label, and no specific value was specified in the
                    # call of this method.
                    # ===================================================================================
                    return True
                elif label['value'] == str(_value):
                    # ===================================================================================
                    # Risk factor las this label, and value match.
                    # ===================================================================================
                    return True
                else:
                    # ===================================================================================
                    # Risk factor las this label, and value DOES NOT match.
                    # ===================================================================================
                    return False
        # ===================================================================================
        # Risk factor does not have this label.
        # ===================================================================================
        return False

    def has_labels(self, and_labels = None, or_labels = None):
        """
        Determines if the risk factor has a specific set of label (with out without specific value).

        When using the "and_labels" parameter, True is only returned if all labels are found.
        When using the "or_labels" parameter, True is returned if at least one of the labels is found.

        When combining use of "and" and or whey will be combined with "and", meaning
        (<and-criteria-1> and <and-criteria-2>) AND (<or-criteria-1> or <or-criteria-2>)

        Args:
            and_labels  (list of Label):    List of label criteria's that all needs to be fulfilled
            or_labels   (list of Label):    List of label criteria's were at least one should be fulfilled.

        Returns:
            (bool): True if risk factor has labels matching the criteria's. False if not.

        Raises:

        Example:
            The module is called (from python) like this::

                from core.risk_factor import context
                label1 = {'name':'model_coverage','value':True}}
                label2 = {'name':'risk_factor','value':'True'}

                my_risk_factor.has_labels(and_labels = [label1,label2])

        Notes:
            Author: JBrandt (g50444)
        """
        and_criteria = True
        or_criteria = False | (or_labels is None)

        if and_labels is not None:
            for current_label in list_helper.to_list(and_labels):
                and_criteria = and_criteria & self.has_label(label_as_obj = current_label)
        if or_labels is not None:
            for current_label in list_helper.to_list(or_labels):
                or_criteria = or_criteria | self.has_label(label_as_obj = current_label)

        if and_criteria == True and or_criteria == True:
            return True
        else:
            return False

    def _default_labels(self):
        """Two sets of labels: 'master', and 'MarketData'"""
        label_group = 'master'
        labels = list()
        labels.append(dict(type    = 'LABEL',
                           group   = label_group,
                           name    = 'imccRiskFactorCategory',
                           value   = self.RISK_CLASS.name))
        labels.append(dict(type    = 'LABEL',
                           group   = label_group,
                           name    = 'imccLiquidityHorizon',
                           value   = str(self.liquidity_horizon)))
        if 'tenor' in self.riskfactor:
            labels.append(dict(type  = 'PROPERTY',
                               group = 'creation_details',
                               name  = 'tenor',
                               value = self.riskfactor['tenor']))
        for key, value in six.iteritems(self.scope):
            if key != 'MarketData':
                labels.append(dict(type  = 'LABEL',
                                   group = label_group,
                                   name  = key,
                                   value = str(value)))
        return labels

    def _rf_meta_data(self):
        """
        Method that returns meta-data for the risk factor.

        Returns:
            (dict):   Meta data for the risk factor (labels, name, description etc.)

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        description = self.description()
        short_name = self.short_name()
        long_name = self.long_name()

        labels = self._default_labels()

        # Transforming list of labels (dicts) into list of UNIQUE labels (still dicts)
        unique_labels = [dict(y) for y in set(tuple(x.items()) for x in labels)]

        metadata = dict(short_name   = short_name,
                        long_name    = long_name,
                        description = description,
                        labels      = unique_labels,
                        )
        return metadata

    def upsert_rf_metadata_in_rfr(self,rf_api,info = 0):
        """
        Insert/Update (short: upsert) risk factor meta-data in Risk Factor Repository

        Risk factor meta-data is characterised as all non-core elements of the risk factors.
        That is, labels, names, descriptions etc.

        Args:
            rf_api      (api instance): Instance of the risk factor repository api
            info        (int):          Controls information written to the log. 0 = nothing written.

        Returns:
            (None):   Nothing. But upserts meta data in risk factor repository.


        Example:
            No example of how to use this yet!

        Warning:

        Notes:
            Author: Arnold Skimminge (documented by g50444 Jonas Brandt)
        """

        self.RF_API = rf_api # Used in the rfr_hash method
        self.rfr_id = self.rfr_hash()

        # Getting current meta-data for the risk factor (if already created in rfr)
        api_get_metadata = api.get_function_with_suffix(rf_api.metadata, 'get_one_risk_factor_meta_data')
        current_rfr_metadata = api_get_metadata(self.rfr_id)

        my_meta_data = self.metadata

        if not current_rfr_metadata or current_rfr_metadata.risk_factor_id is None:
            # ===================================================================================
            # There is not meta-data for the risk factor in Risk Factor Repository.
            # doUpdate is initialised to True - we will do an update.
            # ===================================================================================
            version = 1
            initial_creation = True
            doUpdate = True
        else:
            # ===================================================================================
            # There is already meta-data in Risk Factor Repository.
            # We will only insert data if any changes were made.
            # ===================================================================================
            version = current_rfr_metadata.version
            initial_creation = False
            doUpdate = False

        # ===================================================================================
        # Determining if any meta-data elements has changed compared to current content
        # of risk factor repository.
        # If so (for one of the elements), the doUpdate will be set to True - which it
        # will remain.
        #
        # First checking names, and doing an initial check of labels (just comparing length).
        # Then checking if any new labels have been defined.
        # ===================================================================================
        doUpdate = doUpdate or (current_rfr_metadata.short_name != my_meta_data['short_name'])
        doUpdate = doUpdate or (current_rfr_metadata.long_name != my_meta_data['long_name'])
        doUpdate = doUpdate or (current_rfr_metadata.description != my_meta_data['description'])
        doUpdate = doUpdate or (len(current_rfr_metadata.labels) != len(my_meta_data['labels']))

        # Translating RFR labels into list of dicts
        all_current_labels = dict_helper.object_to_dict(current_rfr_metadata.labels)

        if not doUpdate:
            # ===================================================================================
            # Checking if there is a label which is:
            # - in this prototype Risk Factor - but not in current version in RFR
            # - in the current version in RFR - but not in this prototype version
            # ===================================================================================
            for l in my_meta_data['labels']:
                if l not in all_current_labels:
                    doUpdate = True
                    break
            for l in all_current_labels:
                if l not in my_meta_data['labels']:
                    doUpdate = True
                    break

        if doUpdate:
            #FIXME: Add or remove this part based on which version RFR runs on...
            if initial_creation:
                # ===================================================================================
                # Due to a bug in RFR service, short_name can not be part of the object on initial creation
                # ... but NEEDS to be in the object on updates.
                # ===================================================================================
                my_meta_data.pop('short_name')
            meta_data_with_rf_id = dict_helper.merge_dicts(my_meta_data, {'riskFactorId': self.rfr_id},{'version': version})

            api_upsert_metadata = api.get_function_with_suffix(rf_api.metadata, 'upsert_risk_factor_meta_data')
            try:
                api_upsert_metadata(meta_data_with_rf_id, getpass.getuser())
            except Exception as e:
                raise Exception("Problem occurred when upserting risk factor meta data to RFR. Message: " + str(e))

        if info > 0:
            if doUpdate:
                print('Uploaded risk factor: ' + str(meta_data_with_rf_id))
            else:
                print('No meta-data updated for risk factor: ' + str(self.riskfactor))

    def upsert_rf_in_rfr(self, rf_api):
        """
        Insert/Update (short: upsert) "core" risk factor data in Risk Factor Repository

        "Core" Risk factor data is risk factor data, stripped from all meta data and market data mappings,
        and corresponding to the AVRO definition.

        For a currency pair that would be {foreign:'USD', domestic:'EUR',rfType: <risk factor avro type definition>}

        Returns:
            (None):   Nothing. But upserts risk factor into repository.

        Example:
            No example of how to use this yet!

        Warning:

        Notes:
            Author: Arnold Skimminge (documented by g50444 Jonas Brandt)
        """

        # ===================================================================================
        # We will try to insert the risk factor into risk factor repository.
        # If the insert fails, we try to determine if is due to the risk factor already
        # existing in risk factor repository.
        # If we can't insert, and it is NOT because it already exists, we will raise an
        # exception.
        #
        # This approach has proven to be better performing than first seeing if the
        # risk factor already exists.
        # ===================================================================================
        try:
            rf_dict = self.rfr_dict()
            rf_api.riskfactor.insert_risk_factor(rf_dict, getpass.getuser())
        except Exception as e:
            # The exception string returned from the RFR api has this text if risk factor already exists,
            try:
                if 'risk factor is already in the database' in e.body:
                    # Risk factor already exist - we are happy.
                    pass
                else:
                    # Unexplained issue...
                    raise BaseException('Not able to add risk factor to RFR. Message: ' + str(e))
            except:
                raise BaseException('Not able to add risk factor to RFR. Message: ' + str(e))

    def upsert_rf_market_data_mapping_in_rfr(self, context_name='test-jonas2'):
        """
        Method for uploading risk factor market data maping to RFR

        Args:
            rfr_db_tag              (str):      Consul tag for the RFR environment (e.g. 'uat')
            context_name            (str):      Name of the context that should be created, modified

        Returns:
            (None):   Nothing returned, but risk factor mapping context uploaded to RFR

        Example:
            No example - yet!

        Warning:
            Current version does NOT do a real upsert. It inserts everything.

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        market_data_mapping = self.get_mapping()
        risk_factor = self.riskfactor

        self.rf_api = api.risk_factor_repository_api()

        # Creating a mapping object that the API understands. Combining mapping and risk factors
        md_rf_mapping = MarketDataMapping(  risk_factor             = risk_factor,
                                            source_market_data_id   = market_data_mapping,
                                            )

        # The version is
        version = self.rf_api.marketdatacontext.get_one_using_get(id = context_name).version
        if version is None:
            version = 1

        # Doing the last wrapping of the market data context object, adding name and version.
        md_context = MarketDataMappingContext(  name        = context_name,
                                                version     = version,
                                                mappings    = [md_rf_mapping],
                                                )

        self.rf_api.marketdatacontext.upsert_using_put(md_context,getpass.getuser())

    def rfr_dict(self):
        """
        Translates risk factor into dictionary readable to Risk Factor Repository API.

        This is simply done by taking the avro_schema_name part of the risk factor type, and just copying
        everything else.

        Returns:
          (dict): Risk factor "instance" in RFR readable dictionary structure

        Notes:
            Author: JBrandt (g50444)
        """
        rf_as_dict = rfr_to_dict(self.riskfactor)

        return rf_as_dict

    def __str__(self):
        """Risk factor as string"""
        short_name = self.metadata['short_name'] + ': ' + str(self.riskfactor)
        return short_name

    def __repr__(self):
        params = ['='.join((key, repr(value))) for key, value in self.riskfactor.items() if key != 'rfType']
        params_comma_sep = ', '.join(params)
        representation = self.__class__.__name__  + '(' + params_comma_sep + ')'
        return representation

    def __getattr__(self, item):
        """Implements dict like usage of risk factors, ie. rf['ccy2']"""
        if item in self.riskfactor:
            return self.riskfactor[item]
        else:
            raise AttributeError(item)

    def __getitem__(self, item):
        """Implements object like usage of risk factors, ie. rf.ccy2"""
        if item in self.riskfactor:
            return self.riskfactor[item]
        else:
            raise KeyError(item)


class CompositeRiskFactor(RiskFactor):
    """
    Riskfactor base class for all composite risk factors in ScenarioEngine

    Composite risk factors are risk factors without direct reference to market data, but instead has multiple
    underlying. Inherits from RiskFactor.

    Methods are used by ContextFactory to build risk factor contexts and risk factor mapping contexts.

    Parameters:

        _RFTYPE: avro type of the risk factor

    Notes:
        Author: Arnold Skimminge (G48015)
    """

    def validate(self):
        """
        Validates instance of class using avro schema definitions used in risk factor repository...

        This ensures that this riskfactor definition corresponds to the riskfactor repository definition of the same.
        Args:
            None

        Returns:
            (boolean):   True when valid

        Raises:

            avro.io.AvroTypeException when type is invalid

        Notes:
            Author: Arnold Skimminge (G48015)
        """
        # TODO does not work for RfTenorbasisRate, which contains reference to RfInterestRate
        if self._RFTYPE in ['com.nordea.riskfactor.domain.rates.derived.RfTenorBasisRate',
                            'com.nordea.riskfactor.domain.credit.RfBondCurveRate' ]:
            return True
        if self._RFTYPE not in __SCHEMAS__:
            rf_schema = self._RFTYPE.split('.')[-1]
            schema_file = "../domain-risk-factors/src/main/avro/{}.avsc".format(rf_schema)
            __SCHEMAS__[self._RFTYPE] = avro.schema.parse(open(schema_file).read())
        if not avro.io.validate(expected_schema=__SCHEMAS__[self._RFTYPE],
                                datum=self.riskfactor):
            raise avro.io.AvroTypeException(expected_schema=__SCHEMAS__[self._RFTYPE],
                                            datum=self.riskfactor)
        return True

    def atoms(self):
        """
        Defines underlying risk factors

        Returns:
            RiskFactor: Underlying risk factors

        Raises:
            NotImplementedError when not overloaded by child class

        Example:
            See rates.RfTenorBasisRate for an example

        Notes:
            Author: Arnold Skimminge (G48015)
        """
        raise NotImplementedError

    def get_underlying(self):
        """
        Defines multiple underlying market data mappings

        Returns:
            ((RiskFactor, MarketDataMapping)):  risk factors with reference to market data

        Raises:
            NotImplementedError when not overloaded by child class

        Example:
            See rates.RfTenorBasisRate for an example

        Notes:
            Author: Arnold Skimminge (G48015)
        """
        raise NotImplementedError


def rfr_to_dict(risk_factor):
    """
    Translates a risk factor (instance) into a dictionary readable to Risk Factor Repository API.

    Main purpose is to replace risk factor type object with avro name (as string)

    Args:
        risk_factor (dict): Risk factor "instance", that is the elements matching the avro definitions.

    Returns:
        (dict): Risk factor instance with rfType as the avro name.

    Example:
        The module is called (from python) like this::

            rfr_to_dict

    Notes:
        Author: JBrandt (g50444)
    """

    sub_out = {}

    # ===================================================================================
    # Looping through elements in the risk factor.
    # - If the element is the risk factor type, we use the avro schema name.
    # - If the element (value) is a dict, it is a sub-risk factor. That is translated
    #   into a dict by calling this same function (circular call) for that risk factor.
    # - Otherwise the element is copied unchanged.
    # ===================================================================================

    for key, value in risk_factor.items():
        if type(value) == RiskFactorType:
            # Element is the risk factor type
            sub_out[key] = value.avro_schema_name
        elif type(value) == dict:
            # Element is a risk factor by it self
            sub_out[key] = rfr_to_dict(value)
        else:
            sub_out[key] = value
    return sub_out


if __name__ == '__main__':
    a = RiskFactorType.RfCcyPair
    b = a.risk_factor_class
    d = {}
    for t in RiskFactorType:
        args = t.risk_factor_class_args
        sorted_args = sorted(args)
        str_args = str(sorted_args)
        d[str_args] = t

    arg_to_rf_type_map = [{str(sorted(type.risk_factor_class_args)): type} for type in RiskFactorType]