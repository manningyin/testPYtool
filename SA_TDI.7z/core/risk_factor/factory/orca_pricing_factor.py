"""
Getting pricing factors from Orca for different risk classes.

This is the initial source of pricing factors for all risk classes, which are then translated into internal code-lib
risk factors in "other" modules.


Notes:
    Author: JBrandt

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       15jun2018   JBrandt     Initial creation
    ======= =========   =========   ========================================================================================

"""
import quantum as qt
from core.caching import cache_driver
from core.caching.cache_driver import easy_cache
from core.risk_factor.factory.fx import domain as fx_domain
from core.risk_factor import risk_factor_utils
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.types._transactions import SecurityIdentifier
from core.utils import list_helper
from core.connection import orca_connect


@cache_driver.memory_cache
def rate_curves(manual_currencies = None):
    """
    Get Orca interest rate curves

    Args:
        manual_currencies   (list): OPTIONAL! List of currencies. If not chosen, default currencies are chosen.

    Returns:
        (list of dicts): List of interest rate curves and currencies.

    Notes:
        Author: Arnold Skimminge (refactored and documented by JBrandt)
    """

    from core.connection import orca_connect
    import orca.exception

    _service_requests = orca_connect.get_orca_request()
    if manual_currencies is None:
        all_currencies = currencies()
    else:
        # Currencies chosen by user. These people tend to have fat fingers. Validating input currencies...
        risk_factor_utils.validate_currency(manual_currencies)
        all_currencies = manual_currencies

    rates = []
    for ccy in all_currencies:
        if ccy not in fx_domain.verified_ccy_names:
            continue
        try:
            qt_ccy = qt.Currency(ccy)
            for c in _service_requests.request_interest_rate_risk_factors(qt_ccy).result():
                specific_rate = dict(ccy = ccy, curve = c.name)
                rates.append(specific_rate)
        except orca.exception.OrcaError:
            pass
    return rates


def credit(securities):
    """
    Getting Orca pricing factors for securities

    Args:
        securities  (list of core.types.transaction_type.Securities): Security objects

    Returns:
        (list of str): Orca pricing factors as strings

    Example:
        The module is called (from python) like this::

            import datetime as dt
            from core.risk_factor.factory import factory
            from core.types.transaction_types import Securities
            securities = [
                Securities(ISIN='NO0010646813', security_type='GOVERMENT_BOND', currency='NOK'),
                Securities(ISIN='SE0005468030', security_type='GOVERMENT_BOND', currency='SEK'),
                ]

            pricing_factors = orca_pricing_factor.credit(securities = securities)

    Notes:
        Author: JBrandt (g50444)
    """

    # Getting Orca pricing factors for chosen securities
    req = orca_connect.get_orca_request()
    if isinstance(list_helper.to_list(securities)[0], str):
        # We assume that input is a list of ISIN's
        isins = list_helper.to_list(securities)
    else:
        # We assume that input is a list of securities objects (perhaps together with Trades objects)
        isins = [sec.ISIN for sec in securities if isinstance(sec, SecurityIdentifier)]

    pricing_factors = req.request_bond_risk_factors(isins).result()

    return pricing_factors


@easy_cache()
def currencies(source='mars'):
    """
    List of currencies used for creating various risk factors

    Args:
        source  (str):  Source of currency list. qt: q-toolkit function. mdhub: Mdhub mapping file.

    Returns:
        (list): List of currencies

    Notes:
        Author: JBrandt (g50444)
    """

    if source == 'qt':
        currencies = []
        currencies_raw = qt.getValidCcyNames()
        for ccy_raw in currencies_raw:
            # Using str to convert unicode type to string. Unicode can cause problems for API on upload.
            ccy = str(ccy_raw)
            if ccy in ('CCY_BEGIN', 'INVALID', 'CCY_END'):
                # Not relevant - loop to the next
                pass
            else:
                currencies.append(ccy)
    elif source == 'mars':
        return ['AUD', 'BRL', 'CAD', 'CHF', 'CZK', 'DKK', 'EUR', 'GBP', 'HKD', 'HUF', 'ISK', 'JPY', 'LTL', 'LVL', 'MXN',
                'NOK', 'NZD', 'PLN', 'RUB', 'SEK', 'SGD', 'TRY', 'USD', 'ZAR']

    elif source == 'mdhub':
        from core.system import ext_envir
        from core.market_data import mdh_helper
        from core.file import csv_IO

        # Getting configuration mdhub environment
        mdhub_envir = ext_envir.get()['MDHub']

        # Determining file used for mapping of currency pair risk factors to MD Hub integers
        csv_path = mdh_helper.mapping_file_path(risk_factor_type = RiskFactorType.RfCcyPair.name)

        # Reading currency pairs and their mapping to MD Hub instruments
        ccy_pairs = csv_IO.read_with_filters(file = csv_path,
                                             filters = {'envir': mdhub_envir},
                                             )

        # Converting list of currency pair dictionaries to list of foreign currencies
        currencies = [pair['foreign'] for pair in ccy_pairs]

        # Validating that currency is in expected format (checking for spelling errors in MD hub mapping)
        risk_factor_utils.validate_currency(currencies)

    else:
        raise KeyError('Source of currencies unknown. Supported: "qt" and "mdhub". Received: ' + source)

    return currencies


def fx_pair(*args):
    """
    Creates Orca risk label for chosen number of currencies.

    Args:
        *args (str): Currencies (e.g. 'USD', 'EUR')

    Returns:
        (str): Orca risk label name

    Notes:
        Author: JBrandt (g50444)
    """

    qt_currencies = [qt.Currency[cur] for cur in args]
    req = orca_connect.get_orca_request()
    try:
        orca_risk_label_obj = req.request_fx_spot_risk_factors(qt_currencies).result()
        orca_risk_label = orca_risk_label_obj[0].name
    except Exception as e:
        raise KeyError("Not able to create risk factors for currencies: " + str(args))

    return orca_risk_label


if __name__ == '__main__':
    # a = credit('SE0004869071')
    # print(a)
    # print('-'*10)
    from pprint import pprint
    b = rate_curves(['NOK'])
    pprint(b)
