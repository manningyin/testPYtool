"""
Implements risk factor classes as they are defined in the risk factor repository.

Risk factor repository defines a number of risk factors, and each of them needs to be created here for use in
ScenarioEngine. Each risk factor should inherit from the Riskfactor class, with the specific riskfactor definition in
the .riskfactor attribute.


Notes:
    Author: g48015

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01jun2017   g48015      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
from core.risk_factor.factory import risk_factor_domain
from core.risk_factor.factory.credit import mapping
from core.risk_factor.factory.credit.credit_helper import _test_credit_name
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.types._scenarios import RiskClass
from core.types._scenarios import ShockType
from core.types._scenarios import TimeSeriesStructure
from core.types.market_data_object import CurveInterpolation

_RISK_CLASS = RiskClass.CS
CDS_BUCKETS = ["2Y", "5Y", "7Y"]  # - As in Mars, with 7y instead of 10y to get a better model for current portfolio.



class RfBondCurveRate(risk_factor_domain.RiskFactor, mapping.BondSwapBasis_DAMDS, mapping.BondSwapBasis_MARS):
    """
    Bond-Swap basis curve risk factor.

    Notes:
        Author: Arnold
    """
    RISK_FACTOR_TYPE = RiskFactorType.RfBondSwapBasis

    RISK_CLASS = _RISK_CLASS
    _INTERPOLATION = 'LINEAR'

    def __init__(self, ccy, curve_name, tenor, main):

        # Class supports both main rate as being a dictionary or a risk factor itself.
        if isinstance(main, dict):
            main_dict = main
        else:
            main_dict = main.riskfactor

        self.riskfactor = dict( rf_type      = self.RISK_FACTOR_TYPE,
                                ccy         = str(ccy),
                                curve_name   = str(curve_name),
                                tenor       = str(tenor),
                                main        = main_dict,
                                )
        risk_factor_domain.RiskFactor.__init__(self)

        self._main = main

    @property
    def shock_type(self):
        return ShockType.ADDITION

    @property
    def time_series_structure(self):
        """
        Time series is a daily curve (not just a point)
        """
        return TimeSeriesStructure.CURVE

    @property
    def group_by(self):
        return ('Credit',)

    @property
    def liquidity_horizon(self):
        # TODO: the LH should be currency dependent
        return 10

    def short_name(self):
        """
        Defining the (short) name of the risk factor.

        Returns:
            (str):  (Unique) short name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        # term_specific_identifier = '.'.join([self.ccy, self.curve_name, self.tenor])  # OLD METHOD OF IDENTIFIER
        term_specific_identifier = '.'.join([self.curve_name, self.tenor])
        short_name = term_specific_identifier + "-BOND-SWAP-BASIS"
        return short_name

    def long_name(self):
        """
        Defining the "long name" of the risk factor.

        The long name should be in a "nice format" which could easily be used in a report.

        Returns:
            (str):  (Unique) Long name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        long_name = ("Bond Swap Basis for bond curve: " + self.curve_name
                     + " over IR curve: " + self.main['curve_name']
                     + " for term: " + self.tenor)
        return long_name

    def description(self):
        """
        Defining the descrription of the currency pair risk factor.

        Returns:
            (str):  (Unique) Description of the risk factor

        Notes:
            Author: G48015 (Arnold Skimminge)
        """
        description = ( "Bond Swap Basis between the " + self.curve_name
                        + " bond curve and the main " + self.ccy
                        + " interest rate curve for the " + self.tenor + " term.")
        return description

    @property
    def scope(self):
        return dict(
                    risk_factor         = True,
                    mars_risk_factor    = True,
                    create_in_factory   = False,
                    model_coverage      = True,
                    )

    def get_underlying(self):
        """Return original riskfactors from init"""
        return [self._main, self._basisSpread]


class RfBondZspread(risk_factor_domain.RiskFactor, mapping.ResidualZSpread_DAMDS):
    RISK_FACTOR_TYPE = RiskFactorType.RfBondResidualZspread

    RISK_CLASS = _RISK_CLASS

    def __init__(self, isin, curve_name):
        self.riskfactor = dict(
                                rfType      = self.RISK_FACTOR_TYPE,
                                isin        = str(isin),
                                curve_name   = str(curve_name)
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.ADDITION

    @property
    def time_series_structure(self):
        """
        Time series is a daily "point" (not a curve)
        """
        return TimeSeriesStructure.POINT

    @property
    def group_by(self):
        return self._RISK_CLASS, self.riskfactor['curve_name']

    @property
    def include(self):
        return True

    @property
    def liquidity_horizon(self):
        return 20

    def short_name(self):
        """
        Defining the (short) name of the risk factor

        Returns:
            (str):  (Unique) name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        term_specific_identifier = '.'.join([self.isin, self.curve_name])
        short_name = term_specific_identifier + "-RESIDUAL-ZSPREAD"
        return short_name

    def long_name(self):
        """
        Defining the "long name" of the risk factor

        The long name should be in a "nice format" which could easily be used in a report.

        Returns:
            (str):  (Unique) Long name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        long_name = ("Residual Z-Spread for ISIN: " + self.isin + " over Bond Curve curve: " + self.curve_name)
        return long_name


    def description(self):
        """
        Defining the descrription of the risk factor

        Returns:
            (str):  (Unique) Description of the risk factor

        Notes:
            Author: G48015 (Arnold Skimminge)
        """
        description = ( "Residual Z-Spread for the bond " + self.isin
                        + " over the bond curve " + self.curve_name
                        + ".")
        return description

    @property
    def scope(self):

        return dict(
                    risk_factor         = True,
                    mars_risk_factor    = False,
                    create_in_factory   = False, # Credit risk factors are not created using the "factory"
                    model_coverage      = True,

                    )


class RfHazardRate(risk_factor_domain.RiskFactor, mapping.HazardRate_DAMDS):
    RISK_FACTOR_TYPE = RiskFactorType.RfHazardRate

    RISK_CLASS = _RISK_CLASS

    def __init__(self, name , tenor ,ccy, seniority = 'NA'):
        self.riskfactor = dict(
                                rfType      = self.RISK_FACTOR_TYPE,
                                name        = name,
                                ccy         = ccy,
                                tenor       = tenor,
                                seniority   = seniority
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.MULTIPLICATION

    @property
    def time_series_structure(self):
        """
        Time series is a daily curve (not just a point)
        """
        return TimeSeriesStructure.CURVE

    @property
    def group_by(self):
        return (self._RISK_CLASS, self.riskfactor['name'])

    @property
    def include(self):
        return True

    @property
    def liquidity_horizon(self):
        return 20

    @property
    def scope(self):
        test_name = (self.name in _test_credit_name)

        return dict(
                    risk_factor = True,
                    mars_risk_factor = False,
                    test_cds = test_name
                    )

    @property
    def interpolation_type(self):
        """
        Determines interpolation type for a risk factor type.

        Notes:
            Author: JBrandt (g50444)
        """
        return CurveInterpolation.CurveFlat

    def short_name(self):
        """
        Defining the (short) name of the risk factor

        Returns:
            (str):  (Unique) name of the risk factor

        Notes:
            Author: Shengyao
        """
        term_specific_identifier = '.'.join([self.name,self.ccy,self.tenor,self.seniority])
        short_name = term_specific_identifier + "-HAZARD_RATE"
        return short_name

    def long_name(self):
        """
        Defining the "long name" of the risk factor

        The long name should be in a "nice format" which could easily be used in a report.

        Returns:
            (str):  (Unique) Long name of the risk factor

        Notes:
            Author: Shengyao
        """
        long_name = ("Hazard rate for name " + self.name + " currency " + self.ccy + " tenor " + self.tenor +" "
                                                                                                            "and seniority " + self.seniority)
        return long_name

    def description(self):
        """
        Defining the descrription of the risk factor

        Returns:
            (str):  (Unique) Description of the risk factor

        Notes:
            Author: Shengyao
        """
        description = ("Instantaneous hazard rate for name " + self.name
                       + " currency " + self.ccy + " tenor " + self.tenor
                       + " and seniority " + self.seniority)

        return description


class RfRecoveryRate(risk_factor_domain.RiskFactor , mapping.RecoveryRate_DAMDS):
    RISK_FACTOR_TYPE = RiskFactorType.RfRecoveryRate

    RISK_CLASS = _RISK_CLASS

    def __init__(self, name, ccy, seniority = "NA"):
        self.riskfactor = dict(
                                rfType      = self.RISK_FACTOR_TYPE,
                                name        = name,
                                ccy         = ccy,
                                seniority   = seniority
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.MULTIPLICATION

    @property
    def time_series_structure(self):
        """
        Time series is a daily "point" (not a curve)
        """
        return TimeSeriesStructure.POINT

    @property
    def group_by(self):
        return (self.RISK_CLASS,self.riskfactor['name'])

    @property
    def include(self):
        return True

    @property
    def liquidity_horizon(self):
        return 20

    @property
    def scope(self):
        test_name = (self.name in _test_credit_name)

        return dict(
            risk_factor=True,
            mars_risk_factor = False,
            test_cds=test_name
        )


    def short_name(self):
        """
        Defining the (short) name of the risk factor

        Returns:
            (str):  (Unique) name of the risk factor

        Notes:
            Author: Shengyao
        """
        term_specific_identifier = '.'.join([self.name,self.ccy,self.seniority])
        short_name = term_specific_identifier + "-RECOVERY_RATE"
        return short_name

    def long_name(self):
        """
        Defining the "long name" of the risk factor

        The long name should be in a "nice format" which could easily be used in a report.

        Returns:
            (str):  (Unique) Long name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        long_name = ("Recovery rate for name " + self.name +" currency " + self.ccy +
                        " and seniority " + self.seniority)
        return long_name


    def description(self):
        """
        Defining the descrription of the risk factor

        Returns:
            (str):  (Unique) Description of the risk factor

        Notes:
            Author: G48015 (Arnold Skimminge)
        """
        description = ("Recovery rate for name " + self.name +" currency " + self.ccy +
                        " and seniority " + self.seniority)

        return description


if __name__ == '__main__':
    y = RfHazardRate(name = 'BI_ROYCE', tenor = '6M' , ccy = "EUR")
    print(y.short_name())
    print(y.long_name())
    print(y.description())
    z = RfRecoveryRate(name='BI_NTLCAB' , ccy = "EUR")
    print(z.short_name())
    print(z.long_name())
    print(z.description())
