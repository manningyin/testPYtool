import itertools

import core.risk_factor.factory.credit.credit_helper
from core.risk_factor import risk_factor_utils, pricing_factor
from core.risk_factor.factory import orca_pricing_factor
from core.risk_factor.factory.credit import credit_helper
from core.risk_factor.factory.credit import domain
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.utils import date_helper, list_helper


def hazard_rate():
    """
    Creating risk factor objects for hazard rates.

    TODO: Should be changed to being based on Orca pricing factors when Orca risk factor service supports this.

    Returns:
        (list): Risk factors as risk factor objects

    Notes:
        Author: Shengyao - Refactored and documented by JBrandt (g50444)
    """

    mappings = credit_helper.small_mappings()
    all_risk_factors = []
    for [curve_name, ccy, instance_code, name] in mappings:
        for tenor in domain.CDS_BUCKETS:
            riskfactor = domain.RfHazardRate(name = name,
                                             tenor = tenor,
                                             ccy = ccy,
                                             )
            all_risk_factors.append(riskfactor)
    return all_risk_factors


def recovery_rate():
    """
    Creating risk factor objects for recovery rates.

    Returns:
        (list): Risk factors as risk factor objects

    Notes:
        Author: JBrandt (g50444)
    """

    all_mappings = credit_helper.get_all_bi_name_from_infinity()
    all_risk_factors = []
    for [curve_name, ccy, instance_code, name] in all_mappings:
        if name in core.risk_factor.factory.credit.credit_helper._test_credit_name:
            riskfactor = domain.RfRecoveryRate(name = name,
                                               ccy = ccy)
            all_risk_factors.append(riskfactor)
    return all_risk_factors


def from_positions(positions,
                   info = 0):
    """
    Returns risk factors associated with specific positions (trades and secutiries).

    The risk factors are created based on the pricing factors used by Orca to price the position.

    Args:
        positions   (list):     List of trades and secutiries that risk factors should be created based on.
                                Should be objects like:

                                    - core.types.transaction_types.Securities
                                    - core.types.transaction_types.Trades
        info        (int):      Level of information printed. The higher, the more information is printed

    Returns:
        (list):   List of risk factor objects

    Example:
        The module is called (from python) like this::

            from core.risk_factor.factory.credit import factory as credit_factory
            from core.types import transaction_types
            import datetime as dt

            security = transaction_types.Securities(ISIN = 'NO0010429913', currency = 'NOK')
            risk_factors = credit_factory.from_positions(security, dt.date(2018, 5, 18))

    Notes:
        Author: JBrandt (g50444)
    """

    # Getting Orca pricing factors for chosen securities
    pricing_factors = orca_pricing_factor.credit(securities = positions)

    skipped_pricing_factors = []
    pricing_factors_with_risk_factors = {}
    for pf in pricing_factors:
        # ===================================================================================
        # For each pricing factor we get the list of corresponding risk factors
        # ===================================================================================
        rf = pricing_factor.to_risk_factor(risk_label = pf)
        if rf is None:
            skipped_pricing_factors.append(pf.name)
        else:
            rf_for_current_pf = [single_rf for single_rf in rf]

            # ===================================================================================
            # - Adding pricing factor and corresponding risk factors to output dictionary
            # ===================================================================================
            pricing_factors_with_risk_factors[pf.name] = rf_for_current_pf

    if info > 0:
        for skipped_pf in list(set(skipped_pricing_factors)):
            print('Skipped label/pricing factor: ' + skipped_pf)

    # ===================================================================================
    # Converting dict of dicts to (distinct) list of risk factors
    # ===================================================================================
    rf_without_pf = pricing_factors_with_risk_factors.values()
    cleaned_risk_factors = list(itertools.chain.from_iterable(rf_without_pf))
    distinct_risk_factors = list_helper.distinct(cleaned_risk_factors)

    # ===================================================================================
    # In the development phase of adding new risk factors, we have seen bugs with
    # short names not being uniquely defined. That is not allowed.
    # ===================================================================================
    if risk_factor_utils.duplicate_shortnames(distinct_risk_factors) is True:
        raise Exception("Duplicate short names found. Aborting.")

    return distinct_risk_factors

if __name__ == '__main__':
    rf = hazard_rate()