from core.risk_factor.factory.market_data_mapping import DamdMarketDataMapping
from core.risk_factor.factory.market_data_mapping import MarsMarketDataMapping
from core.time_series.helper import get_bond_swap_basis_mapping_dict
from core.connection import database_connect
from core.utils import error_handler
import pandas as pd
import pyodbc
from core.utils import error_handler


class BondSwapBasis(object):
    @staticmethod
    def _risk_type():
        return "CS_BONDBASIS"


class BondSwapBasis_DAMDS(BondSwapBasis, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(riskfactor):
        if riskfactor['curve_name'] in ("NOTHING_RIGHT_NOW"):
            return riskfactor['curve_name'] + '_BASIS_' + riskfactor['tenor']
        else:
            return "ZERO"

    @staticmethod
    def _return_source_curve_name(curve_name):
        mapping_dict = get_bond_swap_basis_mapping_dict()
        return mapping_dict[curve_name]["Source Curve Name"]

    @staticmethod
    def _return_bond_curve_source(curve_name):
        mapping_dict = get_bond_swap_basis_mapping_dict()
        return mapping_dict[curve_name]["Source"]


class BondSwapBasis_MARS(BondSwapBasis, MarsMarketDataMapping):
    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        conn = pyodbc.connect(database_connect.get_string(environment))
        country = riskfactor['curve_name'][-2:]
        country_ccy = pd.read_sql("select currency_id from marsp.country where country_id = '%s'" % country, conn)
        country_ccy = str(country_ccy.values.squeeze())
        curve_type = 'GOVM' if 'GOV' in riskfactor['curve_name'] else 'MORTG'
        if country_ccy != riskfactor['ccy']:
            return 'ZERO'

        # if environment == 'INFO3D':
        data_source_identity = country if 'GOV' in riskfactor['curve_name'] else country_ccy
        sql_string = """select A.SPREAD_ID from MARSP.SPREAD a
                        where A.SPREAD_MARKET_ID = 'BOND-SWAP_BASIS'
                        and a.SPREAD_TYPE_ID = 'GENERIC'
                        and a.DATA_SOURCE_IDENTITY = '%s'""" % data_source_identity
        # else:
        #     sql_string = """select A.SPREAD_ID from G48606.SPREAD a
        #                     where A.SPREAD_MARKET_ID = 'BOND-SWAP_BASIS'
        #                     and name like '%%SWAP_BASIS'
        #                     and name like '%%%s%%'
        #                     and A.CURRENCY_ID = '%s'""" % (curve_type, country_ccy)
        #
        #     if country_ccy == 'EUR' and curve_type == 'GOVM':
        #         sql_string += " and A.NAME like '%s%%'" % country.upper()

        df = pd.read_sql(sql_string, conn)
        if df.empty:
            error_handler.track_error(error_message='No mapping retured for bond_swap_basis sql query',
                                      identifier='-'.join([country, riskfactor['ccy']]))
            err_msg = "Cannot find GOV_BASIS INTEREST_ID for provided market, country and currency (%s, %s, %s). Returning 'ZERO'" \
                      % (curve_type, country, riskfactor['ccy'])
            print(err_msg)
            return 'ZERO'
            # raise Exception(err_msg)
        assert len(df) == 1
        spread_id = int(df['SPREAD_ID'][0])
        # error_handler.track_error(error_message=spread_id, identifier=riskfactor['curve_name'])
        # print(riskfactor['curve_name'], riskfactor['tenor'], spread_id)
        return spread_id

    @staticmethod
    def _mars_maturity_tenor(riskfactor):
        t = riskfactor['tenor']
        if t.endswith('B'):
            out = t[:-1] + 'D'
        elif t.endswith('W'):
            out = str(int(t[:-1])*7) + 'D'
        else:
            out = t
        return out


class ResidualZspread(object):
    @staticmethod
    def _risk_type():
        return "CS_ZSPREAD"


class ResidualZSpread_DAMDS(ResidualZspread, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(riskfactor):
        return 'ZSPREAD.'+riskfactor['isin']


class HazardRate(object):
    @staticmethod
    def _risk_type():
        return "CS_HAZARD_RATE"


class HazardRate_DAMDS(HazardRate, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(riskfactor):
        return 'CREDIT.HAZARD.'+riskfactor['name'] + '.' + riskfactor['ccy'] + '.' + riskfactor['tenor']


class RecoveryRate(object):
    @staticmethod
    def _risk_type():
        return "CS_RECOVERY_RATE"


class RecoveryRate_DAMDS(RecoveryRate, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(riskfactor):
        return 'CREDIT.RECOVERY.'+riskfactor['name'] + '.' + riskfactor['ccy']


if __name__ == '__main__':
    print(BondSwapBasis_DAMDS._return_source_curve_name("RATE.ZSPREAD.NYK.CURVE"))