import csv
from core.system.envir import codelib_path

_test_credit_name = ["BI_ROYCE", "BI_CDXHY_S26", "BI_NTLCAB", "BI_CADBURY", "BI_UNILNV", "BI_KOMMINVS"]


def get_all_bi_name_from_infinity():
    path = codelib_path() + "/core/risk_factor/factory/credit/mapping.txt"
    with open(path) as f:
        reader = csv.reader(f, delimiter="\t")
        data = list(reader)
    return data


def small_mappings():
    out = []
    all_mappings = get_all_bi_name_from_infinity()
    for item in all_mappings:
        curve_name, ccy, instance_code, name = item
        if name in _test_credit_name:
            out.append(item)

    return out


if __name__ == '__main__':
    print(small_mappings())




