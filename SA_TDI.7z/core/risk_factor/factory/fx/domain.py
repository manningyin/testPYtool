"""
Implements risk factor classes as they are defined in the risk factor repository.

Risk factor repository defines a number of risk factors, and each of them needs to be created here for use in
ScenarioEngine. Each risk factor should inherit from the Riskfactor class, with the specific riskfactor definition in
the .riskfactor attribute.


Notes:
    Author: g48015

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01jun2017   g48015      Initial creation
    2       03Oct2017   g46541      FX Volatility risk factors included.
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""
import quantum as qt

from core.risk_factor.factory import risk_factor_domain
from core.risk_factor.factory.fx import mapping
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.types._scenarios import RiskClass
from core.types._scenarios import ShockType
from core.types._scenarios import TimeSeriesStructure
from core.risk_factor import risk_factor_utils

verified_ccy_names = (
'AUD', 'BRL', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'HUF', 'JPY', 'MXN', 'NOK', 'NZD', 'PLN', 'RUB', 'SEK',
'TRY', 'USD', 'ZAR')  # Out-commented 'HKD' and 'CZK' as they caused problems..
_LIQUID_CURRENCIES = ('USD', 'GBP', 'CHF', 'JPY')
CURRENT_COVERAGE_CCY_NAMES = [x for x in verified_ccy_names if x != 'EUR']

_RISK_CLASS = RiskClass.FX


class RfCcyPair(risk_factor_domain.RiskFactor, mapping.FXSpot_MDHub, mapping.FXSpot_DAMDS, mapping.FXSpot_MARS):
    RISK_FACTOR_TYPE = RiskFactorType.RfCcyPair
    TIMESERIES_TYPE = 'point'

    _BASE_CURRENCY = 'EUR'
    RISK_CLASS = _RISK_CLASS

    def __init__(self, domestic, foreign):
        # Validating input currencies
        risk_factor_utils.validate_currency([domestic, foreign])

        # Creating risk factor "avro" object.
        self.riskfactor = dict(
                                rf_type      = self.RISK_FACTOR_TYPE,
                                domestic    = str(domestic),
                                foreign     = str(foreign)
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.MULTIPLICATION

    @property
    def time_series_structure(self):
        """
        Time series is a daily "point" (not a curve)
        """
        return TimeSeriesStructure.POINT

    @property
    def liquidity_horizon(self):
        if self.foreign in _LIQUID_CURRENCIES:
            return 10
        else:
            return 20

    def short_name(self):
        """
        Defining the (short) name of the currency pair risk factor.

        Returns:
            (str):  (Unique) name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        return "{}.{}".format(self.foreign, self.domestic)

    def long_name(self):
        """
        Defining the "long name" of the currency pair risk factor.

        The long name should be in a "nice format" which could easily be used in a report.

        Returns:
            (str):  (Unique) Long name of the risk factor

        Notes:
            Author: g50444 (Jonas Brandt)
        """
        return "{}.{}".format(self.foreign, self.domestic)

    def description(self):
        """
        Defining the descrription of the currency pair risk factor.

        Returns:
            (str):  (Unique) Description of the risk factor

        Notes:
            Author: G48015 (Arnold Skimminge)
        """
        return ("FX spot {}.{}".format(self.foreign, self.domestic) + "."
                + "That is the price of one unit of " + str(self.foreign)
                + " measured in " + str(self.domestic) + " currency.")

    @property
    def scope(self):
        """
        Scopes are translated to labels
        """
        return dict(risk_factor         = True,
                    fx_spot             = True,
                    mars_risk_factor    = True,
                    liquid_currency     = (self.foreign in _LIQUID_CURRENCIES),

                    # This specific risk factor should be created when running the "factory"
                    create_in_factory   = (self.foreign in CURRENT_COVERAGE_CCY_NAMES),
                    model_coverage      = (self.foreign in CURRENT_COVERAGE_CCY_NAMES),
                    )

class RfCcyAtmVolatility(risk_factor_domain.RiskFactor, mapping.FXSpot_MARS):
    _RFTYPE = 'com.nordea.riskfactor.domain.fx.RfCcyAtmVolatility'
    RISK_CLASS = _RISK_CLASS

    def __init__(self, ccyPair, tenor):
        """RfCcyAtmVolatility class initialization"""
        self.riskfactor = dict(
                                rfType  = self._RFTYPE,
                                ccyPair = ccyPair,
                                tenor   = tenor
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    def validate(self):
        """This is done to avoid looking at the avro files"""
        return True

    @property
    def group_by(self):
        """RfCcyAtmVolatility is grouped by risk class"""
        return (self.RISK_CLASS, )

    @property
    def include(self):
        """All risk factors are included by default"""
        return True

    @property
    def liquidity_horizon(self):
        """Liquidity horizon on FX volatility is 40 by default"""
        return 40

    @property
    def scope(self):
        return dict(
                    fx_vol      = True,
                    risk_factor = True,
                    )

class RfCcyRrVolatility(risk_factor_domain.RiskFactor, mapping.FXSpot_MARS):
    _RFTYPE = 'com.nordea.riskfactor.domain.fx.RfCcyRrVolatility'
    RISK_CLASS = _RISK_CLASS

    def __init__(self, ccyPair, tenor, delta):
        """RfCcyRrVolatility class initialization"""
        self.riskfactor = dict(
                                rfType  = self._RFTYPE,
                                ccyPair = ccyPair,
                                tenor   = tenor,
                                delta   = delta
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    def validate(self):
        """This is done to avoid looking at the avro files"""
        return True

    @property
    def group_by(self):
        """RfCcyRrVolatility is grouped by risk class"""
        return (self._RISK_CLASS, 'vol')

    @property
    def include(self):
        """All risk factors are included by default"""
        return True

    @property
    def liquidity_horizon(self):
        """Liquidity horizon on FX volatility is 40 by default"""
        return 40

    @property
    def scope(self):
        return dict(
                    fx_vol      = True,
                    risk_factor = True,
                    )

class RfCcyFlyVolatility(risk_factor_domain.RiskFactor, mapping.FXSpot_MARS):
    _RFTYPE = 'com.nordea.riskfactor.domain.fx.RfCcyFlyVolatility'
    RISK_CLASS = _RISK_CLASS

    def __init__(self, ccyPair, tenor, delta):
        """RfCcyFlyVolatility class initialization"""
        self.riskfactor = dict(
                                rfType  = self._RFTYPE,
                                ccyPair = ccyPair,
                                tenor   = tenor,
                                delta   = delta
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    def validate(self):
        """This is done to avoid looking at the avro files"""
        return True

    @property
    def group_by(self):
        """RfCcyRrVolatility is grouped by risk class"""
        return (self._RISK_CLASS, )

    @property
    def include(self):
        """All risk factors are included by default"""
        return True

    @property
    def liquidity_horizon(self):
        """Liquidity horizon on FX volatility is 40 by default"""
        return 40

    @property
    def scope(self):
        return dict(
                    fx_vol = True,
                    risk_factor=True,
                    )

if __name__ == '__main__':
    import copy
    x = RfCcyPair(domestic ="EUR", foreign="NOK")
    y = copy.deepcopy(x)
