
from core.risk_factor.factory.market_data_mapping import MarsMarketDataMapping
from core.risk_factor.factory.market_data_mapping import DamdMarketDataMapping
from core.risk_factor.factory.market_data_mapping import MdHubMarketDataMapping
from core.risk_factor.factory.risk_factor_domain import RiskFactorType

class FXSpot(object):
    @staticmethod
    def _risk_type():
        return 'FX'


class FXSpot_MARS(FXSpot, MarsMarketDataMapping):
    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        if 'foreign' in riskfactor:
            return riskfactor['foreign']
        elif 'ccy2' in riskfactor:
            return riskfactor['ccy2']
        elif 'ccyPair' in riskfactor:
            return riskfactor['ccyPair']
        else:
            raise ValueError


class FXSpot_DAMDS(FXSpot, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(rf):
        riskfactor = rf
        rfType = riskfactor['rf_type']

        if rfType == RiskFactorType.RfCcyPair:
            return riskfactor['foreign'] + '.EUR'
        elif rfType.name  == 'RfCcyAtmVolatility':
            return riskfactor['ccyPair'] + '.VOL.ATM.' + riskfactor['tenor']
        elif rfType.name  == 'RfCcyRrVolatility':
            return riskfactor['ccyPair'] + '.VOL.RR.' + riskfactor['delta'] + '.' + riskfactor['tenor']
        elif rfType.name  == 'RfCcyFlyVolatility':
            return riskfactor['ccyPair'] + '.VOL.FLY.' + riskfactor['delta'] + '.' + riskfactor['tenor']
        else:
            raise ValueError


class FXSpot_MDHub(FXSpot, MdHubMarketDataMapping):
    """
    Specific class for mapping of risk factors to Market Data Hub.

    All logic for mapping to MD Hub is shared across risk classes, so this class serves only as combining
    methods from risk factor type specific mapping class and general MD Hub mapping class.
    """
    pass
