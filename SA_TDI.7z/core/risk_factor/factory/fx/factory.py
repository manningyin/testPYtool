"""
The module uploads FX risk factors to risk factor repository

The risk factors being made are FX spot, FX ATM volatility, FX RR and FLY volatility on 10 and
25 delta points

Warning:


Notes:
    Author: g46541

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       03Oct2017   G46541      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""


from core.risk_factor.factory import orca_pricing_factor
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.risk_factor.factory.fx import domain
from core.risk_factor import risk_factor_utils
from core.risk_factor import pricing_factor

_BASE_CURRENCY = 'EUR'

verified_ccypair_names = (
'EURUSD', 'USDNOK', 'EURDKK', 'USDDKK', 'CADSEK', 'CADNOK', 'GBPNOK', 'GBPUSD', 'NZDSEK', 'GBPDKK', 'GBPCHF', 'NOKSEK',
'EURCAD', 'EURJPY', 'USDCHF', 'DKKSEK', 'USDPLN', 'CNHSEK', 'USDCNH', 'CHFNOK', 'CHFDKK', 'USDTRY', 'CHFSEK', 'CHFJPY',
'USDSGD', 'USDRUB', 'CZKPLN', 'USDCAD', 'EURRUB', 'USDZAR', 'AUDUSD', 'DKKNOK', 'EURTRY', 'EURAUD', 'CADDKK', 'EURZAR',
'SGDDKK', 'EURMXN', 'NZDUSD', 'GBPSEK', 'PLNNOK', 'HKDNOK', 'EURPLN', 'EURCNH', 'EURCHF', 'USDJPY', 'ZARSEK', 'AUDNOK',
'EURNOK', 'USDINR', 'PLNDKK', 'USDMXN', 'EURGBP', 'GBPAUD', 'EURSEK', 'AUDCAD', 'GBPCAD', 'NZDDKK', 'AUDSEK', 'USDCZK',
'CADJPY', 'JPYNOK', 'CNHDKK', 'JPYDKK', 'JPYSEK', 'ZARDKK', 'DKKINR', 'TRYDKK', 'USDHKD')

tenor_set = ('ON', '1W', '2W', '1M', '2M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '10Y')

delta_set = (10.0, 25.0)


def fx_pair(currencies = None, source ='mars'):
    """
    Creating risk factor objects for fx pairs.

    Args:
        currencies  (list): OPTIONAL: FX Pairs will be generated based on input currencies, with fixed base/domestic.
        source      (str):  Source of currency list. qt: q-toolkit function. mdhub: Mdhub mapping file.

    Returns:
        (list): Risk factors matching avro structure (as risk factor objects)

    Notes:
        Author: JBrandt (g50444)
    """

    base_currency = _BASE_CURRENCY
    if currencies is None:
        all_currencies = orca_pricing_factor.currencies(source)
    else:
        # Currencies chosen by user. These people tend to have fat fingers. Validating input currencies...
        risk_factor_utils.validate_currency(currencies)
        all_currencies = currencies

    fx_pairs_rf_objects = []
    for cur in all_currencies:
        fx_pair_dict = dict(foreign = cur,
                            domestic = base_currency,
                            )
        fx_pair_obj = risk_factor_utils.dict_to_rf_object(risk_factor_dict = fx_pair_dict,
                                                          risk_factor_type = RiskFactorType.RfCcyPair,
                                                          )

        try:
            orca_risk_label = pricing_factor.from_risk_factor(fx_pair_obj.riskfactor)
            fx_pair_obj.add_label(group='creation_details', name='orca_pricing_factor', value = orca_risk_label)

        except KeyError:
            # Not able to find Orca risk label for this risk factor.
            pass

        fx_pairs_rf_objects.append(fx_pair_obj)

    return fx_pairs_rf_objects


def fx_atm_volatility():
    """
    Creating fx at-the-money volatility risk factor objects.

    Returns:
        (list): Risk factors risk factor objects

    Notes:
        Author: JBrandt (g50444)
    """

    all_risk_factors = []
    for ccy in verified_ccypair_names:
        for tenor in tenor_set:
            riskfactor = domain.RfCcyAtmVolatility(ccyPair=ccy, tenor=tenor)
            all_risk_factors.append(riskfactor)
    return all_risk_factors


def fx_rr_volatility():
    """
    Creating fx risk reversal volatility risk factor objects.

    Returns:
        (list): Risk factors risk factor objects

    Notes:
        Author: JBrandt (g50444)
    """

    all_risk_factors = []
    for ccy in verified_ccypair_names:
        for tenor in tenor_set:
            for delta in delta_set:
                riskfactor = domain.RfCcyRrVolatility(ccyPair=ccy, tenor=tenor, delta=delta)
                all_risk_factors.append(riskfactor)
    return all_risk_factors


def fx_fly_volatility():
    """
    Creating fx butterfly volatility risk factor objects.

    Returns:
        (list): Risk factors risk factor objects

    Notes:
        Author: JBrandt (g50444)
    """

    all_risk_factors = []
    for ccy in verified_ccypair_names:
        for tenor in tenor_set:
            for delta in delta_set:
                riskfactor = domain.RfCcyFlyVolatility(ccyPair=ccy, tenor=tenor, delta=delta)
                all_risk_factors.append(riskfactor)
    return all_risk_factors


if __name__ == '__main__':
    a = fx_pair()