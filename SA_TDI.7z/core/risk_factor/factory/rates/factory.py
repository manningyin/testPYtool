import core.risk_factor.factory.rates.domain
from core.caching.cache_driver import easy_cache
from core.risk_factor import risk_factor_utils
from core.risk_factor.factory.rates import domain
from core.risk_factor.factory.risk_factor_domain import RiskFactorType

_Standardized__Buckets = ('3M', '6M', '1Y', '2Y', '3Y', '5Y', '10Y', '15Y', '20Y', '30Y')

vol_currencies = ('EUR',)
vol_tenor = ('3M', '1Y', '2Y', '5Y', '10Y', '30Y')
vol_underlying_tenor = ('1Y', '2Y', '5Y', '10Y', '30Y')


def interest_rate_risk_factors(currencies=None):
    from core.risk_factor.factory import orca_pricing_factor
    curve_names = orca_pricing_factor.rate_curves(currencies)

    interest_rate_objects = []
    for d in curve_names:
        ccy = d['ccy']
        curve_name = d['curve']

        for tenor in core.risk_factor.factory.rates.domain.PRICING_FACTOR_IR_BUCKETS:
            interest_rate_dict = dict(
                                    ccy = ccy,
                                    curve_name = curve_name,
                                    tenor = tenor,
                                    )

            interest_rate_obj = risk_factor_utils.dict_to_rf_object(risk_factor_dict = interest_rate_dict,
                                                                    risk_factor_type = RiskFactorType.RfInterestRate)
            interest_rate_obj.add_label(group='creation_details', name='orca_pricing_factor', value = curve_name)
            interest_rate_objects.append(interest_rate_obj)

    return interest_rate_objects


def dmb_refi_risk_factors(currencies=None):

    curve_name_base = 'DMB.REFI_SPREAD.MTG_DK.'

    dmb_refi_risk_objects = []
    ccy='DKK'
    for tenor in core.risk_factor.factory.rates.domain.REFI_BUCKETS:
        curve_name = curve_name_base + tenor
        dmb_dict = dict(
                                ccy = ccy,
                                curve_name = curve_name,
                                tenor = tenor,
                                )

        dmb_refi_risk = risk_factor_utils.dict_to_rf_object(risk_factor_dict = dmb_dict,
                                                            risk_factor_type = RiskFactorType.RfRefinanceRate)
        dmb_refi_risk.add_label(group='creation_details', name='orca_pricing_factor', value=curve_name)
        dmb_refi_risk_objects.append(dmb_refi_risk)

    return dmb_refi_risk_objects


def interest_rate_atm_volatility():
    """
    Creating interest rate at-the-money volatility risk factor objects.

    Returns:
        (list): Risk factors risk factor objects

    Notes:
        Author: JBrandt (g50444) (based on Arnold Skimminges class implementation)
    """

    all_risk_factors = []
    _vol_currencies = vol_currencies
    _vol_tenor = vol_tenor
    _vol_underlying_tenor = vol_underlying_tenor

    for ccy in _vol_currencies:
        surface_name = 'FREIA.LAMBDA.' + ccy
        for tenor in _vol_tenor:
            for underlying_tenor in _vol_underlying_tenor:
                riskfactor = domain.RfInterestAtmVolatility(ccy = ccy,
                                                            surface_name = surface_name,
                                                            tenor = tenor,
                                                            underlying_tenor = underlying_tenor)
                all_risk_factors.append(riskfactor)
    return all_risk_factors


class RfTenorBasisRateFactory(object):
    """
    TODO: This does not work!
    TODO: Refactoring of old factory world into function based risk factor generation needed.
    Class to generate tenor basis interest rate risk factors

    Tenor basis interest rate risk factors is a composite risk factor defined by two underlying curves.

        A main curve which captures systemic dynamics

        A basis spread curve which captures specific curve dynamics relative to the main curve

    Args:
        bucketDefinition        (str):

    Public methds:
         get_riskfactors():   Risk factor generator

    Notes:
        Author: Arnold Skimminge (G48015)
    """
    rfType = 'com.nordea.riskfactor.domain.rates.derived.RfTenorBasisRate'
    RISK_CLASS = domain._RISK_CLASS

    class rf_tenor_basis_rate(domain.RfTenorBasisRate):
        """Local risk factor definition, can be skipped when everything works"""
        def include(self):
            if 'FUNDING' in self.curve_name:
                return False
            if self.ccy != 'EUR':
                return False
            return True

    @staticmethod
    def _main_curve(ccy):
        """Main curve name"""
        return ccy + '.DISC.LIBOR.CURVE'

    @staticmethod
    def _basis_spread_curve(curve_name):
        """Basis spread curve name"""
        x = curve_name.split('.')
        if curve_name.endswith('.DISC.FUNDING.CURVE'):
            raise ValueError
        x[1] = 'TENORBASIS'
        if x[2] == 'FWD':
            x[2] = 'ZCPN'
        return '.'.join(x)

    @classmethod
    def _riskfactor(cls, ccy, curve_name, tenor):
        """Switch between RfInterestRate for main curve and RfTenorBasisRate for other"""
        if curve_name == cls._main_curve(ccy):
            return cls.rf_interest_rate(
                ccy=ccy,
                curve_name=curve_name,
                tenor=tenor)
        elif curve_name.endswith('.DISC.FUNDING.CURVE'):
            return cls.rf_interest_rate(
                ccy=ccy,
                curve_name=curve_name,
                tenor=tenor)
        else:
            main = cls.rf_interest_rate(
                ccy=ccy,
                curve_name=cls._main_curve(ccy),
                tenor=tenor)
            basisSpread = cls.rf_interest_rate(
                ccy=ccy,
                curve_name=cls._basis_spread_curve(curve_name),
                tenor=tenor)
            return cls.rf_tenor_basis_rate(ccy=ccy,
                                           curve_name=curve_name,
                                           tenor=tenor,
                                           main=main,
                                           basisSpread=basisSpread)

