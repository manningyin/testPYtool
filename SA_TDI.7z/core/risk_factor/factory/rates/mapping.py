from core.risk_factor.factory.market_data_mapping import MarsMarketDataMapping
from core.risk_factor.factory.market_data_mapping import DamdMarketDataMapping
import pandas as pd
import pyodbc
from core.connection import database_connect
from core.market_data import mars_helper, proxy_helper

class IR(object):
    @staticmethod
    def _risk_type():
        return 'IR'


class MARS_liboronly(IR, MarsMarketDataMapping):
    @staticmethod
    def _interest_market_id(riskfactor):
        curve_name = riskfactor['curve_name']
        if '.REPO_' in curve_name:
            out = 'REPO'
        elif '.FWD.' in curve_name:
            idx = curve_name.find('.FWD.')
            term = curve_name[idx+5:]
            out = 'ZC_' + term
        elif 'XCCY_BASIS' in curve_name:
            out = 'CCSB_Q'
        elif 'DISC.OIS' in curve_name:
            out = 'OIS'
        else:
            out = 'SWAP'
        return out

    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        interest_market = __class__._interest_market_id(riskfactor)

        if interest_market not in ['SWAP', 'OIS', 'REPO'] and not interest_market.startswith('ZC_'):
            return 'ZERO'

        if interest_market == 'REPO':
            sql_string = f"""select A.INTEREST_ID from MARSP.INTEREST a
                            where A.INTEREST_MARKET_ID = 'REPO'
                            and A.INTEREST_ISSUER_ID = 'BENCH'
                            and A.CURRENCY_ID = '{riskfactor['ccy']}' """
        else:
            sql_string = f"""select A.INTEREST_ID from MARSP.INTEREST a
                            where A.INTEREST_MARKET_ID = 'SWAP'
                            and A.CURRENCY_ID = '{riskfactor['ccy']}'"""

        conn = pyodbc.connect(database_connect.get_string(environment))
        df = pd.read_sql(sql_string, conn)
        if df.empty:
            err_msg = 'Cannot find INTEREST_ID for provided currency (%s)' % riskfactor['ccy']
            raise Exception(err_msg)
        interest_id = int(df['INTEREST_ID'][0])
        return interest_id

    @staticmethod
    def _mars_maturity_tenor(riskfactor):
        t = riskfactor['tenor']
        if t.endswith('B'):
            out = t[:-1] + 'D'
        elif t.endswith('W'):
            out = str(int(t[:-1])*7) + 'D'
        else:
            out = t
        return out


class MARS_DMB_SPREAD_EMPTY_ID(IR, MarsMarketDataMapping):
    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        sql_string = """select A.INTEREST_ID from MARSP.INTEREST a
                                where A.INTEREST_MARKET_ID = 'REFI'
                                and A.CURRENCY_ID = '%s'""" % riskfactor['ccy']
        conn = pyodbc.connect(database_connect.get_string(environment))
        df = pd.read_sql(sql_string, conn)
        if df.empty:
            err_msg = 'Cannot find INTEREST_ID for provided currency (%s)' % riskfactor['ccy']
            raise Exception(err_msg)
        interest_id = int(df['INTEREST_ID'][0])
        return interest_id  # Queried from Marsp.Interest where interest_market_id= 'REFI'

    @staticmethod
    def _mars_maturity_tenor(riskfactor):
        return riskfactor['tenor']


class MARS_IR_VOL(IR, MarsMarketDataMapping):
    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        if riskfactor['ccy'] not in ['EUR', 'USD', 'SEK', 'NOK', 'DKK']:   # [GBP] should be there but we dont have market data
            return 'ZERO'

        vol_id = mars_helper.get_ir_vol_id(ccy=riskfactor['ccy'], vol_interest_market='LAMDA')
        id_proxy = proxy_helper.get_vol_proxies([vol_id], 'IR')['PROJECTION_VOL_ID']
        return int(id_proxy)

    @staticmethod
    def _mars_maturity_tenor(riskfactor):
        return riskfactor['tenor']

    @staticmethod
    def _mars_underlying_maturity_tenor(riskfactor):
        return riskfactor['underlying_tenor']


class MARS_tenorbasis(MARS_liboronly):
    # These mappings appear to be incorrect...
    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        name_map = {'CLP.DISC.LIBOR.CURVE': 35, 'LTL.DISC.LIBOR.CURVE': 107, 'XJP.DISC.LIBOR.CURVE': 194,
                    'ANG.DISC.LIBOR.CURVE': 5, 'USD.TENORBASIS.FWD.1M': 9184, 'GBP.RATE.BASISSPREAD': 8216,
                    'USD.TENORBASIS.FWD.1D': 9183, 'LUF.DISC.LIBOR.CURVE': 109, 'DKK.TENORBASIS.FWD.1M': 9194,
                    'DKK.TENORBASIS.FWD.1D': 9193, 'RUB.TENORBASIS.BASISSPREAD': 9108, 'BHD.DISC.LIBOR.CURVE': 20,
                    'DKK.RATE.FWD.3M': 9190, 'GHS.DISC.LIBOR.CURVE': 7839, 'DKK.TENORBASIS.BASISSPREAD': 9093,
                    'FRG.DISC.LIBOR.CURVE': 64, 'SKK.DISC.LIBOR.CURVE': 159, 'ZAL.DISC.LIBOR.CURVE': 203,
                    'GBP.RATE.FWD.3M': 9223, 'EUR.RATE.FWD.6M': 9171, 'PAB.DISC.LIBOR.CURVE': 138,
                    'USD.RATE.FWD.1M': 9180, 'EUR.RATE.BASISSPREAD': 8212, 'TMM.DISC.LIBOR.CURVE': 171,
                    'RWF.DISC.LIBOR.CURVE': 150, 'FJD.DISC.LIBOR.CURVE': 61, 'MXN.TENORBASIS.BASISSPREAD': 9102,
                    'INR.DISC.LIBOR.CURVE': 84, 'IPN.DISC.LIBOR.CURVE': 85, 'XSS.DISC.LIBOR.CURVE': 197,
                    'BYN.DISC.LIBOR.CURVE': 9164, 'TWD.DISC.LIBOR.CURVE': 176, 'KWD.DISC.LIBOR.CURVE': 99,
                    'DKX.DISC.LIBOR.CURVE': 49, 'CZK.DISC.LIBOR.CURVE': 43, 'DKK.TENORBASIS.FWD.1Y': 9197,
                    'SEK.TENORBASIS.FWD.1D': 9204, 'SEK.TENORBASIS.FWD.1M': 9205, 'MRO.DISC.LIBOR.CURVE': 119,
                    'SEK.TENORBASIS.FWD.1Y': 9208, 'SEK.TENORBASIS.OIS.CURVE': 9120, 'USD.RATE.FWD.6M': 9182,
                    'DKK.RATE.FWD.6M': 9191, 'JPY.TENORBASIS.FWD.3M': 9252, 'BND.DISC.LIBOR.CURVE': 23,
                    'BIF.DISC.LIBOR.CURVE': 21, 'CUP.DISC.LIBOR.CURVE': 40, 'GBP.TENORBASIS.FWD.1M': 9226,
                    'JPY.RATE.FWD.1M': 9247, 'GTQ.DISC.LIBOR.CURVE': 73, 'JPY.RATE.FWD.1D': 9246,
                    'PKR.DISC.LIBOR.CURVE': 143, 'KRW.DISC.LIBOR.CURVE': 98, 'BZD.DISC.LIBOR.CURVE': 32,
                    'PYG.DISC.LIBOR.CURVE': 146, 'CNH.DISC.LIBOR.CURVE': 1070, 'CNH.TENORBASIS.BASISSPREAD': 9090,
                    'MKD.DISC.LIBOR.CURVE': 114, 'PLN.TENORBASIS.FWD.6M': 9262, 'BMD.DISC.LIBOR.CURVE': 22,
                    'DKK.RATE.BASISSPREAD': 8213, 'SEK.DISC.FUNDING.CURVE': 8233, 'GMD.DISC.LIBOR.CURVE': 68,
                    'PLN.RATE.BASISSPREAD': 8218, 'AUD.DISC.LIBOR.CURVE': 11, 'KMF.DISC.LIBOR.CURVE': 96,
                    'CHF.RATE.FWD.3M': 9240, 'DEM.DISC.LIBOR.CURVE': 45, 'HUF.TENORBASIS.BASISSPREAD': 9097,
                    'YUM.DISC.LIBOR.CURVE': 202, 'YUD.DISC.LIBOR.CURVE': 201, 'KES.DISC.LIBOR.CURVE': 93,
                    'RUB.TENORBASIS.FWD.1M': 9235, 'JPY.TENORBASIS.BASISSPREAD': 9100, 'RUB.TENORBASIS.FWD.1D': 9234,
                    'BWP.DISC.LIBOR.CURVE': 30, 'AFA.DISC.LIBOR.CURVE': 3, 'EUR.DISC.FUNDING.CURVE': 8230,
                    'RUB.TENORBASIS.OIS.CURVE': 9119, 'ECS.DISC.LIBOR.CURVE': 53, 'SGD.TENORBASIS.BASISSPREAD': 9162,
                    'ARA.DISC.LIBOR.CURVE': 8, 'JPY.RATE.FWD.6M': 9249, 'MXV.DISC.LIBOR.CURVE': 125,
                    'YER.DISC.LIBOR.CURVE': 200, 'SEK.DISC.LIBOR.CURVE': 156, 'MVR.DISC.LIBOR.CURVE': 122,
                    'TRL.DISC.LIBOR.CURVE': 174, 'MLF.DISC.LIBOR.CURVE': 115, 'CRC.DISC.LIBOR.CURVE': 38,
                    'LSL.DISC.LIBOR.CURVE': 105, 'GBP.TENORBASIS.FWD.6M': 9228, 'TTD.DISC.LIBOR.CURVE': 175,
                    'CHF.TENORBASIS.FWD.6M': 9244, 'ADP.DISC.LIBOR.CURVE': 1, 'CZK.TENORBASIS.BASISSPREAD': 9092,
                    'NOK.TENORBASIS.OIS.CURVE': 9117, 'PLN.DISC.LIBOR.CURVE': 144, 'JMD.DISC.LIBOR.CURVE': 90,
                    'GNF.DISC.LIBOR.CURVE': 69, 'NOK.TENORBASIS.FWD.6M': 9218, 'SEK.RATE.BASISSPREAD': 8214,
                    'XPF.DISC.LIBOR.CURVE': 196, 'UAK.DISC.LIBOR.CURVE': 179, 'EUR.RATE.FWD.1M': 9169,
                    'IEP.DISC.LIBOR.CURVE': 82, 'SEK.RATE.FWD.1Y': 9203, 'TRY.TENORBASIS.BASISSPREAD': 9110,
                    'USD.DISC.OIS.CURVE': 1057, 'OMR.DISC.LIBOR.CURVE': 137, 'GQE.DISC.LIBOR.CURVE': 71,
                    'BGL.DISC.LIBOR.CURVE': 18, 'SEK.RATE.FWD.1D': 9199, 'VEB.DISC.LIBOR.CURVE': 185,
                    'SIT.DISC.LIBOR.CURVE': 158, 'RUB.RATE.FWD.3M': 9232, 'KHR.DISC.LIBOR.CURVE': 95,
                    'DDM.DISC.LIBOR.CURVE': 44, 'PLN.RATE.FWD.3M': 9257, 'CHF.TENORBASIS.FWD.1D': 9242,
                    'NOK.DISC.OIS.CURVE': 1046, 'SYP.DISC.LIBOR.CURVE': 168, 'CVE.DISC.LIBOR.CURVE': 41,
                    'ESP.DISC.LIBOR.CURVE': 57, 'LYD.DISC.LIBOR.CURVE': 111, 'NOK.RATE.FWD.6M': 9213,
                    'INR.TENORBASIS.BASISSPREAD': 9099, 'EEK.DISC.LIBOR.CURVE': 54, 'SOS.DISC.LIBOR.CURVE': 163,
                    'CSD.DISC.LIBOR.CURVE': 6345, 'USD.RATE.FWD.1D': 9179, 'STD.DISC.LIBOR.CURVE': 165,
                    'RON.DISC.LIBOR.CURVE': 4893, 'CNY.DISC.LIBOR.CURVE': 36, 'MWK.DISC.LIBOR.CURVE': 123,
                    'HRK.DISC.LIBOR.CURVE': 78, 'PHP.DISC.LIBOR.CURVE': 142, 'BOB.DISC.LIBOR.CURVE': 24,
                    'CHF.DISC.LIBOR.CURVE': 34, 'KGS.DISC.LIBOR.CURVE': 94, 'ERT.DISC.LIBOR.CURVE': 56,
                    'EUR.TENORBASIS.FWD.3M': 9175, 'SUR.DISC.LIBOR.CURVE': 166, 'XEU.DISC.LIBOR.CURVE': 193,
                    'ARS.DISC.LIBOR.CURVE': 9, 'EUR.DISC.OIS.CURVE': 1041, 'NPR.DISC.LIBOR.CURVE': 135,
                    'XDR.DISC.LIBOR.CURVE': 192, 'SLL.DISC.LIBOR.CURVE': 162, 'USD.TENORBASIS.OIS.CURVE': 9121,
                    'MOP.DISC.LIBOR.CURVE': 118, 'SSP.DISC.LIBOR.CURVE': 1073, 'IDR.DISC.LIBOR.CURVE': 81,
                    'PLN.TENORBASIS.OIS.CURVE': 9118, 'MUR.DISC.LIBOR.CURVE': 121, 'GYD.DISC.LIBOR.CURVE': 75,
                    'MMK.DISC.LIBOR.CURVE': 116, 'RUB.TENORBASIS.FWD.6M': 9237, 'MAD.DISC.LIBOR.CURVE': 112,
                    'CHF.TENORBASIS.BASISSPREAD': 9089, 'LRD.DISC.LIBOR.CURVE': 104, 'UAH.DISC.LIBOR.CURVE': 178,
                    'BRL.DISC.LIBOR.CURVE': 26, 'PEN.DISC.LIBOR.CURVE': 139, 'HKD.DISC.LIBOR.CURVE': 76,
                    'AED.DISC.LIBOR.CURVE': 2, 'DKY.DISC.LIBOR.CURVE': 50, 'BDT.DISC.LIBOR.CURVE': 15,
                    'DKK.TENORBASIS.FWD.3M': 9195, 'LAK.DISC.LIBOR.CURVE': 101, 'VEF.DISC.LIBOR.CURVE': 7708,
                    'BEL.DISC.LIBOR.CURVE': 17, 'DKK.RATE.FWD.1Y': 9192, 'NOK.RATE.FWD.3M': 9212,
                    'ROL.DISC.LIBOR.CURVE': 148, 'ZAR.TENORBASIS.BASISSPREAD': 9111, 'NZD.DISC.LIBOR.CURVE': 136,
                    'DKK.RATE.FWD.1M': 9189, 'SDD.DISC.LIBOR.CURVE': 154, 'PLN.RATE.FWD.1D': 9255,
                    'CHF.DISC.OIS.CURVE': 1031, 'PTE.DISC.LIBOR.CURVE': 145, 'NOK.TENORBASIS.FWD.3M': 9217,
                    'FRF.DISC.LIBOR.CURVE': 63, 'SCR.DISC.LIBOR.CURVE': 153, 'DOP.DISC.LIBOR.CURVE': 51,
                    'GBP.RATE.FWD.1M': 9222, 'UGS.DISC.LIBOR.CURVE': 180, 'NIO.DISC.LIBOR.CURVE': 131,
                    'GBP.RATE.FWD.1D': 9221, 'BYR.DISC.LIBOR.CURVE': 31, 'SEK.RATE.FWD.6M': 9202,
                    'UYP.DISC.LIBOR.CURVE': 183, 'GIP.DISC.LIBOR.CURVE': 67, 'KZT.DISC.LIBOR.CURVE': 6346,
                    'MZN.DISC.LIBOR.CURVE': 7013, 'SVC.DISC.LIBOR.CURVE': 167, 'PLN.TENORBASIS.FWD.1M': 9260,
                    'PLN.TENORBASIS.FWD.1D': 9259, 'COP.DISC.LIBOR.CURVE': 37, 'TRY.DISC.LIBOR.CURVE': 2890,
                    'UYU.DISC.LIBOR.CURVE': 184, 'KYD.DISC.LIBOR.CURVE': 100, 'CYP.DISC.LIBOR.CURVE': 42,
                    'NLG.DISC.LIBOR.CURVE': 133, 'SEK.TENORBASIS.FWD.6M': 9207, 'THB.DISC.LIBOR.CURVE': 170,
                    'EUR.RATE.FWD.1D': 9168, 'CAD.DISC.FUNDING.CURVE': 9163, 'EUR.RATE.FWD.1Y': 9172,
                    'BOP.DISC.LIBOR.CURVE': 25, 'CSK.DISC.LIBOR.CURVE': 39, 'SDP.DISC.LIBOR.CURVE': 155,
                    'SBD.DISC.LIBOR.CURVE': 152, 'JPY.TENORBASIS.FWD.1D': 9250, 'JPY.RATE.FWD.3M': 9248,
                    'JPY.TENORBASIS.FWD.1M': 9251, 'ZAR.DISC.LIBOR.CURVE': 204, 'PES.DISC.LIBOR.CURVE': 140,
                    'DZD.DISC.LIBOR.CURVE': 52, 'GBP.TENORBASIS.FWD.3M': 9227, 'GBP.DISC.LIBOR.CURVE': 65,
                    'IQD.DISC.LIBOR.CURVE': 86, 'XAF.DISC.LIBOR.CURVE': 190, 'LKR.DISC.LIBOR.CURVE': 103,
                    'MYR.TENORBASIS.BASISSPREAD': 9103, 'RSD.DISC.LIBOR.CURVE': 6846, 'MXN.DISC.LIBOR.CURVE': 124,
                    'VND.DISC.LIBOR.CURVE': 186, 'CNY.TENORBASIS.BASISSPREAD': 9091, 'CHF.RATE.FWD.1D': 9239,
                    'DKK.TENORBASIS.OIS.CURVE': 9113, 'GRD.DISC.LIBOR.CURVE': 72, 'FIM.DISC.LIBOR.CURVE': 60,
                    'DKK.DISC.OIS.CURVE': 1036, 'GWP.DISC.LIBOR.CURVE': 74, 'CHF.DISC.FUNDING.CURVE': 8235,
                    'GBP.RATE.FWD.6M': 9224, 'NOK.DISC.LIBOR.CURVE': 134, 'XOF.DISC.LIBOR.CURVE': 195,
                    'SGD.DISC.LIBOR.CURVE': 157, 'HUF.DISC.LIBOR.CURVE': 80, 'USD.DISC.FUNDING.CURVE': 8231,
                    'GBP.DISC.OIS.CURVE': 8200, 'USD.TENORBASIS.FWD.3M': 9185, 'SEK.TENORBASIS.FWD.3M': 9206,
                    'NHF.DISC.LIBOR.CURVE': 129, 'NIC.DISC.LIBOR.CURVE': 130, 'DKN.DISC.LIBOR.CURVE': 48,
                    'SRG.DISC.LIBOR.CURVE': 164, 'MTL.DISC.LIBOR.CURVE': 120, 'MNT.DISC.LIBOR.CURVE': 117,
                    'SEK.DISC.OIS.CURVE': 1051, 'ITL.DISC.LIBOR.CURVE': 89, 'XXX.DISC.LIBOR.CURVE': 198,
                    'KPW.DISC.LIBOR.CURVE': 97, 'AON.DISC.LIBOR.CURVE': 7, 'JPY.TENORBASIS.FWD.6M': 9253,
                    'FKP.DISC.LIBOR.CURVE': 62, 'CHF.RATE.FWD.6M': 9241, 'GNS.DISC.LIBOR.CURVE': 70,
                    'BRL.TENORBASIS.BASISSPREAD': 9087, 'PLN.RATE.FWD.6M': 9258, 'SEK.RATE.FWD.3M': 9201,
                    'TOP.DISC.LIBOR.CURVE': 173, 'ZWD.DISC.LIBOR.CURVE': 208, 'JPY.DISC.LIBOR.CURVE': 92,
                    'GBP.DISC.FUNDING.CURVE': 8236, 'NOK.TENORBASIS.BASISSPREAD': 9104, 'HTG.DISC.LIBOR.CURVE': 79,
                    'PLN.RATE.FWD.1M': 9256, 'SEK.RATE.FWD.1M': 9200, 'ETB.DISC.LIBOR.CURVE': 58,
                    'CHF.TENORBASIS.FWD.3M': 9243, 'EUR.DISC.LIBOR.CURVE': 59, 'CAD.TENORBASIS.BASISSPREAD': 9088,
                    'AUD.TENORBASIS.BASISSPREAD': 9086, 'SKP.DISC.LIBOR.CURVE': 161, 'BBD.DISC.LIBOR.CURVE': 14,
                    'USD.RATE.FWD.3M': 9181, 'RUR.DISC.LIBOR.CURVE': 149, 'BRN.DISC.LIBOR.CURVE': 27,
                    'IRR.DISC.LIBOR.CURVE': 87, 'SAR.DISC.LIBOR.CURVE': 151, 'LBP.DISC.LIBOR.CURVE': 102,
                    'QAR.DISC.LIBOR.CURVE': 147, 'USD.TENORBASIS.FWD.6M': 9186, 'AFN.DISC.LIBOR.CURVE': 7086,
                    'NOK.RATE.FWD.1Y': 9214, 'HNL.DISC.LIBOR.CURVE': 77, 'NOK.RATE.FWD.1D': 9210,
                    'LVL.DISC.LIBOR.CURVE': 110, 'IDR.TENORBASIS.BASISSPREAD': 9098, 'NOK.RATE.FWD.1M': 9211,
                    'BTN.DISC.LIBOR.CURVE': 29, 'GBP.TENORBASIS.OIS.CURVE': 9115, 'BAD.DISC.LIBOR.CURVE': 12,
                    'EUR.TENORBASIS.FWD.1Y': 9177, 'LSM.DISC.LIBOR.CURVE': 106, 'SEK.TENORBASIS.BASISSPREAD': 9109,
                    'YDD.DISC.LIBOR.CURVE': 199, 'EUR.TENORBASIS.FWD.1M': 9174, 'ILS.DISC.LIBOR.CURVE': 83,
                    'WST.DISC.LIBOR.CURVE': 188, 'EUR.TENORBASIS.FWD.1D': 9173, 'RUB.RATE.FWD.6M': 9233,
                    'XCD.DISC.LIBOR.CURVE': 191, 'TND.DISC.LIBOR.CURVE': 172, 'KRW.TENORBASIS.BASISSPREAD': 9101,
                    'ZRZ.DISC.LIBOR.CURVE': 207, 'ZRN.DISC.LIBOR.CURVE': 206, 'JOD.DISC.LIBOR.CURVE': 91,
                    'EUR.TENORBASIS.FWD.6M': 9176, 'BGN.DISC.LIBOR.CURVE': 19, 'NOK.RATE.BASISSPREAD': 8215,
                    'PLN.TENORBASIS.BASISSPREAD': 9106, 'RUB.TENORBASIS.FWD.3M': 9236, 'SZL.DISC.LIBOR.CURVE': 169,
                    'EUR.TENORBASIS.OIS.CURVE': 9114, 'RUB.RATE.FWD.1D': 9230, 'PLN.DISC.FUNDING.CURVE': 8237,
                    'RUB.RATE.FWD.1M': 9231, 'ISK.DISC.LIBOR.CURVE': 88, 'CAD.DISC.LIBOR.CURVE': 33,
                    'GBP.TENORBASIS.FWD.1D': 9225, 'MYR.DISC.LIBOR.CURVE': 126, 'SDG.DISC.LIBOR.CURVE': 7053,
                    'MZM.DISC.LIBOR.CURVE': 127, 'ATS.DISC.LIBOR.CURVE': 10, 'PLN.DISC.OIS.CURVE': 8201,
                    'RON.TENORBASIS.BASISSPREAD': 9107, 'CHF.TENORBASIS.OIS.CURVE': 9112, 'LUC.DISC.LIBOR.CURVE': 108,
                    'DKK.RATE.FWD.1D': 9188, 'USD.DISC.LIBOR.CURVE': 182, 'DJF.DISC.LIBOR.CURVE': 46,
                    'VUV.DISC.LIBOR.CURVE': 187, 'UGX.DISC.LIBOR.CURVE': 181, 'RUB.DISC.LIBOR.CURVE': 818,
                    'NIP.DISC.LIBOR.CURVE': 132, 'HKD.TENORBASIS.BASISSPREAD': 9096, 'NOK.TENORBASIS.FWD.1D': 9215,
                    'NOK.TENORBASIS.FWD.1M': 9216, 'EGP.DISC.LIBOR.CURVE': 55, 'DKK.TENORBASIS.FWD.6M': 9196,
                    'NZD.TENORBASIS.BASISSPREAD': 9105, 'NOK.TENORBASIS.FWD.1Y': 9219, 'ALL.DISC.LIBOR.CURVE': 4,
                    'BSD.DISC.LIBOR.CURVE': 28, 'MGF.DISC.LIBOR.CURVE': 113, 'GHC.DISC.LIBOR.CURVE': 66,
                    'PGK.DISC.LIBOR.CURVE': 141, 'SKN.DISC.LIBOR.CURVE': 160, 'BAM.DISC.LIBOR.CURVE': 13,
                    'DKK.DISC.LIBOR.CURVE': 47, 'GBP.TENORBASIS.BASISSPREAD': 9095, 'PLN.TENORBASIS.FWD.3M': 9261,
                    'TZS.DISC.LIBOR.CURVE': 177, 'NGN.DISC.LIBOR.CURVE': 128, 'BEF.DISC.LIBOR.CURVE': 16,
                    'EUR.RATE.FWD.3M': 9170, 'EUR.TENORBASIS.BASISSPREAD': 9094, 'DKK.DISC.FUNDING.CURVE': 8232,
                    'AOK.DISC.LIBOR.CURVE': 6, 'XAA.DISC.LIBOR.CURVE': 189, 'CHF.RATE.BASISSPREAD': 8217,
                    'NOK.DISC.FUNDING.CURVE': 8234, 'ZMK.DISC.LIBOR.CURVE': 205, 'JPY.TENORBASIS.OIS.CURVE': 9116}
        if 'FUNDING' in  riskfactor['curve_name']:
            return name_map[riskfactor['ccy']+'.DISC.LIBOR.CURVE']
        if 'BASISSPREAD' in  riskfactor['curve_name']:
            return name_map[riskfactor['ccy']+'.DISC.LIBOR.CURVE']
#        if 'FWD' not in riskfactor['curve_name']:
#            return name_map[riskfactor['ccy']+'.DISC.LIBOR.CURVE']
#        return name_map[riskfactor['ccy'] + '.DISC.LIBOR.CURVE']
        return name_map[riskfactor['curve_name']]


class IR_DAMDS(IR, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(riskfactor):
        if 'TENORBASIS' in riskfactor['curve_name']:
            return '.'.join((riskfactor['curve_name'], riskfactor['tenor']))
        elif 'FWD' in riskfactor['curve_name']:
            x = riskfactor['curve_name'].split('.')
            if x[2] == 'FWD':
                x[2] = 'ZCPN'
            return '.'.join(x + [riskfactor['tenor']])
        else:
            return '.'.join((riskfactor['ccy'], 'DISC.LIBOR.CURVE', riskfactor['tenor']))

    @staticmethod
    def _maturity_tenor(riskfactor):
        return riskfactor['tenor']


class IRVol(object):
    @staticmethod
    def _risk_type():
        return 'IR_VOL'


class IRVol_DAMDS(IRVol, DamdMarketDataMapping):
    @staticmethod
    def _market_data_id(riskfactor):
        return '.'.join((riskfactor['surface_name'], riskfactor['tenor'], riskfactor['underlying_tenor']))



