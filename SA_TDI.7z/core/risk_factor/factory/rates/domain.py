"""
Implements interest rate risk factor classes as they are defined in the risk factor repository.


Notes:
    Author: g48015

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01jun2017   g48015      Initial creation
    2       12nov2019   g01571      Updated for dmb risk factors (Added  RfRefinanceRate class)
    3       12nov2019   g01571      Updated RfInterestAtmVolatility class
    ======= =========   =========   ========================================================================================

Review:

"""
from core.caching.cache_driver import easy_cache
from collections import defaultdict
import six
from core.caching import cache_driver
from core.risk_factor.factory import risk_factor_domain
from core.risk_factor.factory.rates import mapping as rates_mapping
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.risk_factor.factory.fx import domain as fx_domain
from core.types.market_data_object import CurveInterpolation
from core.types._scenarios import RiskClass
from core.types._scenarios import ShockType
from core.types._scenarios import TimeSeriesStructure

_RISK_CLASS = RiskClass.IR

RISK_FACTOR_IR_BUCKETS = ('1M', '2M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y',
                          '12Y', '15Y', '20Y', '25Y', '30Y', '50Y')

PRICING_FACTOR_IR_BUCKETS = (
            '1D', '2D', '5D', '7D', '10D', '14D', '3W', '1M', '2M', '3M', '4M', '5M', '6M', '7M', '8M', '9M', '10M',
            '11M', '1Y', '18M', '2Y', '3Y', '4Y', '5Y', '6Y', '7Y', '8Y', '9Y', '10Y', '11Y', '12Y', '13Y', '14Y',
            '15Y', '16Y', '17Y', '18Y', '19Y', '20Y', '21Y', '22Y', '23Y', '24Y', '25Y', '26Y', '27Y', '28Y', '29Y',
            '30Y', '35Y', '40Y', '50Y')


REFI_BUCKETS = ('IO',
                '1Y',
                '2Y',
                '3Y',
                '4Y',
                '5Y',
                '6Y',
                '7Y',
                '8Y',
                '10Y',
                '15Y',
                '20Y',
                '30Y')


@cache_driver.memory_cache
def currencies_with_ois_rf():
    return ['DKK', 'EUR', 'GBP', 'NOK', 'SEK', 'USD']
    from risklib.connection import orca_connect
    import quantum as qt
    orca_req = orca_connect.get_orca_request()
    has_ois = []
    for ccy in fx_domain.verified_ccy_names:
        curve_names = [x.name for x in orca_req.request_interest_rate_risk_factors(getattr(qt.Currency, ccy)).result()]
        if any('OIS' in name for name in curve_names):
            has_ois.append(ccy)
    return has_ois


def currencies_with_repo_rf():
    return ['DKK', 'EUR', 'GBP', 'NOK', 'SEK', 'USD']



class RfRefinanceRate(risk_factor_domain.RiskFactor, rates_mapping.IR_DAMDS, rates_mapping.MARS_DMB_SPREAD_EMPTY_ID):
    """
    Refinance Risk Factor

    Args:
        ccy         (str): Currency
        curve_name   (str): ORCA curve name
        tenor       (str): Maturity tenor

    Notes:
        Author: Ahmet Baglan, G01571
    """
    RISK_FACTOR_TYPE = RiskFactorType.RfRefinanceRate

    _liquid_currencies = ('DKK')
    RISK_CLASS = _RISK_CLASS

    def __init__(self, curve_name, tenor, ccy='DKK', name=None):
        """RfRefinanceRate class initialization"""
        if name is None:
            name=curve_name
        self.riskfactor = dict(
                                rf_type      = self.RISK_FACTOR_TYPE,
                                ccy         = str(ccy),
                                curve_name   = str(curve_name),
                                tenor       = str(tenor),
                                name        = str(name)
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.ADDITION

    @property
    def time_series_structure(self):
        """
        Time series is a daily "point" (not a curve)
        """
        return TimeSeriesStructure.POINT

    @property
    def group_by(self):
        """Refinance is grouped by risk class and tenor"""
        return (self._RISK_CLASS, self.ccy, self.riskfactor['tenor'])

    @property
    def include(self):
        """All risk factors are included by default"""
        return True

    @property
    def liquidity_horizon(self):
        """FRTB liquidity scaled Expected Shortfall (lsES) default liguidity horizons"""
        if self.ccy in self._liquid_currencies:
            return 10
        else:
            return 20

    @property
    def risk_factor_refi_buckets(self):
        """Return REFI BUCKETS'"""
        return REFI_BUCKETS

    @property
    def verbose_curve_name(self):
        return "DMB Refinance Curve Tenor: {tenor}".format(tenor=self.riskfactor['tenor'])

    def description(self):
        return "{} DMB refinance rate risk factor for the {} point".format(self.ccy,  self.tenor)

    def long_name(self):
        return "{} {} @ {}".format(self.ccy, self.verbose_curve_name, self.tenor)

    def short_name(self):
        return "DMB.REFI_SPREAD.MTG_DK.{}-DMB-REFI-SPREAD".format(self.tenor)

    @property
    def scope(self):
        """Similar to 'group' in new API. In order to limit risk factors are ran."""
        return dict()


class RfInterestRate(risk_factor_domain.RiskFactor, rates_mapping.IR_DAMDS, rates_mapping.MARS_liboronly):
    """
    Linear rate risk factors

    Linear rate risk factors are the basic risk factors for all product with linear interest rate risk. All rates are
    by default zero coupon rates, which are converted to Forward rates when needed. RfInterestRate has the RfType
    'com.nordea.riskfactor.domain.rates.RfInterestRate' in risk factor repository within risk factor repository.

    Args:
        ccy         (str): Currency
        curve_name   (str): ORCA curve name
        tenor       (str): Maturity tenor

    Parameters:
        RISK_FACTOR_TYPE is the risk factor type in risk factor repository
        _liquid_currencies specifies currencies with a liquidity horizon of 10 days, all others are 20 days.
        RISK_CLASS is the FRTB risk class
        _INTERPOLATION specifies the interpolation scheme in ORCA.

    Examples:
        Euro LIBOR discounting 10Y rate risk factor::

            rf = RfInterestRate(ccy='EUR',
                                curve_name='EUR.DISC.LIBOR.CURVE',
                                tenor='10Y')

        Danish kroner OIS discounting 6M rate risk factor::

            rf = RfInterestRate(ccy='DKK',
                                curve_name='DKK.DISC.OIS.CURVE',
                                tenor='6M')

        Euro Funding curve discounting 30Y rate risk factor::

            rf = RfInterestRate(ccy='EUR',
                                curve_name='EUR.DISC.FUNDING.CURVE',
                                tenor='30Y')

        Swiss franc 6M Forward rate 1Y rate risk factor::

            rf = RfInterestRate(ccy='CHF',
                                curve_name='CHF.RATE.FWD.6M',
                                tenor='1Y')

        US Dollar 3M Forward rate 2Y rate risk factor::

            rf = RfInterestRate(ccy='USD',
                                curve_name='USD.RATE.FWD.3M',
                                tenor='2Y')

        Euro 1M Forward rate 3Y rate risk factor::

            rf = RfInterestRate(ccy='EUR',
                                curve_name='EUR.RATE.FWD.1M',
                                tenor='3Y')

        Euro 1D Forward rate 2D rate risk factor::

            rf = RfInterestRate(ccy='EUR',
                                curve_name='EUR.RATE.FWD.1M',
                                tenor='2D')

        Euro cross currency basis 3M rate risk factor::

            rf = RfInterestRate(ccy='EUR',
                                curve_name='EUR.RATE.BASISSPREAD',
                                tenor='3M')

    Notes:
        Author: Arnold Skimminge, G48015
    """
    RISK_FACTOR_TYPE = RiskFactorType.RfInterestRate

    _liquid_currencies = ('EUR', 'USD', 'GBP', 'AUD', 'JPY', 'SEK', 'CAD')
    RISK_CLASS = _RISK_CLASS
    _INTERPOLATION = 'SPLINE'

    def __init__(self, ccy, curve_name, tenor):
        """RfInterestRate class initialization"""
        self.riskfactor = dict(
                                rf_type      = self.RISK_FACTOR_TYPE,
                                ccy         = str(ccy),
                                curve_name   = str(curve_name),
                                tenor       = str(tenor)
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.ADDITION

    @property
    def time_series_structure(self):
        """
        Time series is a daily "point" (not a curve)
        """
        return TimeSeriesStructure.CURVE

    @property
    def interpolation_type(self):
        """
        Determines interpolation type for a risk factor type.

        Notes:
            Author: JBrandt (g50444)
        """
        return CurveInterpolation.CurveSpline

    @property
    def group_by(self):
        """RfInterestRate is grouped by risk class and currency"""
        return (self._RISK_CLASS, self.ccy)

    @property
    def include(self):
        """All risk factors are included by default"""
        return True

    def interpolation(self):
        """Curve interpolation method"""
        out = defaultdict(lambda: dict(curve_name=self.curve_name,
                               interpolation=self._INTERPOLATION))
        for key, value in six.iteritems(self.scope):
            if key in ('MarketData', 'miniMarketData'):
                out[key] = dict(curve_name=self.curve_name,
                                interpolation='CATROM')
        return out

    @property
    def liquidity_horizon(self):
        """FRTB liquidity scaled Expected Shortfall (lsES) default liguidity horizons"""
        if self.ccy in self._liquid_currencies:
            return 10
        else:
            return 20

    @property
    def risk_factor_ir_buckets(self):
        """Return 'IR'"""
        return RISK_FACTOR_IR_BUCKETS

    @property
    def verbose_curve_name(self):
        if '.DISC.OIS' in self.curve_name:
            return 'OIS discounting curve'
        elif '.DISC.LIBOR' in self.curve_name:
            return 'LIBOR discounting curve'
        elif '.DISC.FUNDING' in self.curve_name:
            return 'FUNDING discounting curve'
        elif '.RATE.FWD.' in self.curve_name:
            return '{} forward curve'.format(self.curve_name[-2:])
        elif 'RATE.' in self.curve_name and '.FWD' in self.curve_name:
            return '{} forward curve'.format(self.curve_name[-2:])
        elif '.BASISSPREAD' in self.curve_name and 'RATE.' in self.curve_name:
            return 'xCCY basis curve'
        elif '.TENORBASIS.ZCPN' in self.curve_name:
            return 'TENORBASIS curve'
        elif '.XCCY_BASIS' in self.curve_name:
            return 'XCCY basis curve'
        elif '.REPO_' in self.curve_name:
            return 'Repo discounting curve'
        elif '.DISC.EONIA' in self.curve_name:
            return 'EONIA discounting curve'
        elif '.DISC.EUROSTR' in self.curve_name:
            return 'EUROSTR discounting curve '
        elif '.DISC.FEDERAL_FUNDS' in self.curve_name:
            return 'FEDERAL FUNDS discounting curve'
        elif '.DISC.SOFR' in self.curve_name:
            return 'SOFR discounting curve'
        elif '.DISC.CITA' in self.curve_name:
            return 'CITA discounting curve'
        else:
            raise ValueError(self.curve_name)

    def description(self):
        return "{} interest rate risk factor for the {} point on the {}".format(self.ccy, self.tenor, self.verbose_curve_name)

    def long_name(self):
        return "{} {} @ {}".format(self.ccy, self.verbose_curve_name, self.tenor)

    def short_name(self):
        return "{}.{}".format(self.curve_name, self.tenor)

    @property
    def scope(self):
        """Similar to 'group' in new API. In order to limit risk factors are ran."""
        all_ccy = (self.ccy in fx_domain.verified_ccy_names)

        global_tenor = (self.tenor in PRICING_FACTOR_IR_BUCKETS)
        bucket_tenor = (self.tenor in RISK_FACTOR_IR_BUCKETS)
        liquid_ccy = (self.ccy in fx_domain._LIQUID_CURRENCIES)
        libor_curve = (self.verbose_curve_name == 'LIBOR discounting curve')
        funding_curve = (self.verbose_curve_name == 'FUNDING discounting curve')

        if 'TENORBASIS' in self.curve_name:
            return dict()

        zero_coupon = all_ccy & global_tenor
        risk_factor = all_ccy & bucket_tenor

        _has_ois = self.ccy in currencies_with_ois_rf()
        curve_type = (self.curve_name.endswith('DISC.OIS') or self.curve_name.endswith('OIS.CURVE')) if _has_ois \
            else (self.curve_name.endswith('DISC.LIBOR') or self.curve_name.endswith('LIBOR.CURVE'))
        coverage = curve_type and (risk_factor or zero_coupon) and (self.ccy in fx_domain.CURRENT_COVERAGE_CCY_NAMES)

        # Will be translated directly into labels in the _default_labels() method.
        return dict(zero_coupon         = zero_coupon,
                    risk_factor         = risk_factor,
                    tenor_basis_rate    = all_ccy & bucket_tenor & (libor_curve | funding_curve),
                    mars_risk_factor    = risk_factor,
                    liquid_ccy          = liquid_ccy,
                    # This specific risk factor should be created when running the "factory"
                    create_in_factory   = coverage,
                    model_coverage      = coverage,
                                        )


class RfTenorBasisRate(risk_factor_domain.CompositeRiskFactor):
    """
    Linear rate risk factors, with added tenor basis


    Args:
        ccy         (str): Currency
        curve_name   (str): ORCA curve name
        tenor       (str): Maturity tenor
        main        (domain.RfInterestRate): Main rate for the specified curve
        basisSpread (domain.RfInterestRate): basisSpread is an additive spread to the main rate
        Notes: curve_name in main and basisSpread need not correspond to an ORCA curve when used in conjunction with
               RfTenorBasisRate

    Parameters:
        _RFTYPE is the risk factor type in risk factor repository

    Examples:
        The libor curve DKK.DISC.LIBOR.CURVE is the main rate for DKK, which can be used in the RfTenorBasisRate:

        Danish kroner OIS discounting 6M rate risk factor::

            main = RfInterestRate(ccy='DKK',
                                  curve_name='DKK.DISC.LIBOR.CURVE',
                                  tenor='6M')
            basisSpread = RfInterestRate(ccy='DKK',
                                         curve_name='DKK.TENORBASIS.OIS.CURVE',
                                         tenor='6M')
            rf = RfTenorBasisRate(ccy='DKK',
                                  curve_name='DKK.DISC.OIS.CURVE',
                                  tenor='6M',
                                  main=main,
                                  basisSpread=basisSpread)

    Notes:
        Author: Arnold Skimminge, G48015
    """

    _RFTYPE = 'com.nordea.riskfactor.domain.rates.derived.RfTenorBasisRate'
    _INTERPOLATION = 'SPLINE'
    RISK_CLASS = _RISK_CLASS

    def __init__(self, ccy, curve_name, tenor, main, basisSpread):
        self.riskfactor = dict(
                                rfType      = self._RFTYPE,
                                ccy         = ccy,
                                curve_name   = curve_name,
                                tenor       = tenor,
                                main        = main.riskfactor,
                                basisSpread = basisSpread.riskfactor
                            )

        self._main = main
        self._basisSpread = basisSpread

        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def group_by(self):
        """Use main curve definition"""
        return self._main.group_by

    @property
    def include(self):
        """Use main curve definition"""
        return self._main.include

    #@property
    def interpolation(self):
        """Curve interpolation method"""
        out = defaultdict(lambda: dict(curve_name=self.curve_name,
                                       interpolation=self._INTERPOLATION))
        for key, value in six.iteritems(self.scope):
            if key in ('MarketData', 'miniMarketData'):
                out[key] = dict(curve_name=self.curve_name,
                                interpolation='CATROM')
        return out

    @property
    def liquidity_horizon(self):
        """Use main curve definition"""
        return self._main.liquidity_horizon

    @property
    def is_modellable(self):
        """Use main curve definition"""
        return self._main.is_modellable

    @property
    def observations(self):
        """Use main curve definition"""
        return self._main.observations

    @property
    def observed_liquidity_horizon(self):
        """Use main curve definition"""
        return self._main.observed_liquidity_horizon

    @property
    def code(self):
        """Use main curve definition"""
        return self._main.code

    @property
    def risk_factor_ir_buckets(self):
        """Return 'IR'. 18 buckets used in MARS (VaR)."""
        return RISK_FACTOR_IR_BUCKETS

    @property
    def scope(self):
        all_ccy = (self.ccy in fx_domain.verified_ccy_names)
        eur_ccy = (self.ccy == 'EUR')
        global_tenor = (self.tenor in PRICING_FACTOR_IR_BUCKETS)
        bucket_tenor = (self.tenor in RISK_FACTOR_IR_BUCKETS)
        one_tenor = (self.tenor == '10Y')
        libor_curve = (self.curve_name.endswith('.DISC.LIBOR.CURVE'))
        ois_curve = (self.curve_name.endswith('.DISC.OIS.CURVE'))
        fwd_curve = ('.RATE.FWD.' in self.curve_name)
        funding = (self.curve_name.endswith('.DISC.FUNDING.CURVE'))

        return dict(tenor_basis_rate = all_ccy & bucket_tenor & (ois_curve | fwd_curve),
                    )

    def get_underlying(self):
        """Return original riskfactors from init"""
        return [self._main, self._basisSpread]


class RfInterestAtmVolatility(risk_factor_domain.RiskFactor, rates_mapping.IRVol_DAMDS, rates_mapping.MARS_IR_VOL):
    RISK_FACTOR_TYPE = RiskFactorType.RfInterestAtmVolatility
    _RFTYPE = RiskFactorType.RfInterestAtmVolatility
    _liquid_currencies = ('EUR', 'USD', 'DKK', 'NOK', 'SEK')
    RISK_CLASS = _RISK_CLASS

    def __init__(self, ccy, surface_name, tenor, underlying_tenor):
        self.riskfactor = dict(
                                rf_type          = self._RFTYPE,
                                ccy              = ccy,
                                surface_name     = surface_name,
                                tenor            = tenor,
                                underlying_tenor = underlying_tenor
                                 )
        risk_factor_domain.RiskFactor.__init__(self)

    @property
    def shock_type(self):
        return ShockType.MULTIPLICATION

    @property
    def time_series_structure(self):
        """
        Time series is a daily "point" (not a curve)
        """
        return TimeSeriesStructure.SURFACE

    @property
    def group_by(self):
        """RfInterestAtmVolatility is grouped by risk class, currency and 'vol'"""
        return self._RISK_CLASS, self.ccy, 'vol'

    @property
    def include(self):
        """All risk factors are included by default"""
        return True

    @property
    def liquidity_horizon(self):
        """FRTB liquidity scaled Expected Shortfall (lsES) default liguidity horizons"""
        return 60

    def description(self):
        return "{} interest rate ATM volatility risk factor with maturity {} and underlying maturity {}".format(self.ccy, self.tenor, self.underlying_tenor)

    @property
    def scope(self):
#        all_ccy = (self.ccy in SWAP_curves)
        eur_ccy = (self.ccy == 'EUR')
#        global_tenor = (self.tenor in _Global__Buckets)
#        bucket_tenor = (self.tenor in self.buckets)
        mars_maturity_tenors = ('3M', '1Y', '2Y', '5Y', '10Y', '30Y')
        mars_underlying_tenors = ('1Y', '2Y', '5Y', '10Y', '30Y')
        mars_tenors = (self.tenor in mars_maturity_tenors) & (self.underlying_tenor in mars_underlying_tenors)
        min_tenor = (self.tenor in ('1Y', '5Y', '10Y'))
        min_underlying_tenor = (self.underlying_tenor in ('1Y', '2Y'))
#        libor_curve = (self.curve_name.endswith('.DISC.LIBOR.CURVE'))
#        tenorbasis = ('TENORBASIS' in self.curve_name)

        return dict(RfInterestAtmVolatility=mars_tenors)

    def short_name(self):
        surface_name = self.riskfactor['surface_name']
        tenor = self.riskfactor['tenor']
        underlying_tenor = self.riskfactor['underlying_tenor']
        return "{}.{}.{}-IR-VOLATILITY".format(surface_name, underlying_tenor, tenor)


if __name__ == '__main__':
    from core.risk_factor.collection import RiskFactorCollection
    col = RiskFactorCollection().default_PI_risk_factors()
    # x = RfInterestRate(ccy='EUR',
    #                    curve_name='EUR.DISC.LIBOR.CURVE',
    #                    tenor='20Y')
    # #y = RfInterestRate(ccy='EUR',
    # #                   curve_name='EUR.TENORBASIS.ZCPN.1D',
    # #                   tenor='10Y')
    # #z = RfTenorBasisRate(ccy='EUR',
    # #                     curve_name='EUR.RATE.FWD.1D',
    # #                    tenor='10Y',
    # #                     main=x,
    # #                     basisSpread=y)
    # x.validate()
    # x.rfr_store()
    #
