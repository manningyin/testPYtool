from core.risk_factor.factory.market_data_mapping import MarsMarketDataMapping

class Equity(object):
    @staticmethod
    def _risk_type():
        return 'FX'

class EQMarsMarketDataMapping(Equity, MarsMarketDataMapping):
    @staticmethod
    def _mars_risk_factor_id(riskfactor, environment):
        return riskfactor['equityId']# effect_id

    @staticmethod
    def _mars_risk_type(riskfactor):
        return 'EQ'