"""
Implements risk factor classes as they are defined in the risk factor repository.

Risk factor repository defines a number of risk factors, and each of them needs to be created here for use in
ScenarioEngine. Each risk factor should inherit from the Riskfactor class, with the specific riskfactor definition in
the .riskfactor attribute.


Notes:
    Author: g48015

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       01jun2017   g48015      Initial creation
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
"""

from enum import Enum

from core.risk_factor.factory import risk_factor_domain
from core.types._scenarios import RiskClass
from core.risk_factor.factory.equity import mapping

_RISK_CLASS = RiskClass.EQ

class EquityMarketCap(Enum):
    LARGE = 'LARGE'
    SMALL = 'SMALL'

class RfEquityPrice(risk_factor_domain.RiskFactor, mapping.EQMarsMarketDataMapping):
    _RFTYPE = 'com.nordea.riskfactor.domain.rates.RfTenorBasisRate'
    RISK_CLASS = _RISK_CLASS

    def __init__(self, equityId, equityIdType):
        self.riskfactor = dict(
                                rfType      = self._RFTYPE,
                                equityId    = dict(
                                                    equityId     = equityId,
                                                    equityIdType = equityIdType
                                                    )
                                )
        risk_factor_domain.RiskFactor.__init__(self)

    def _market_cap(self):
        if self.equityId['equityId'] == 'DK0060534915':
            return EquityMarketCap.LARGE
        else:
            return EquityMarketCap.SMALL

    def _equity_name(self):
        if self.equityId['equityId'] == 'DK0060534915':
            return "NOVO B, Novo Nordisk B"
        else:
            return "Unknown equity"

    @property
    def liquidity_horizon(self):
        if self._market_cap() == EquityMarketCap.LARGE:
            return 20
        else:
            return 40

    def short_name(self):
        """ Defining the (short) name of the equity risk factor. """
        return "{}".format(self.equityId['equityId'])

    def long_name(self):
        """ Defining the (long) name of the equity risk factor. """
        return "{} equity price".format(self._equity_name())

    def description(self):
        """ Defining the description of the equity risk factor. """
        return "Equity spot price of {}, ({})".format(self._equity_name(), self.equityId['equityId'])

    @property
    def scope(self):
        return dict(equitySpot=True,
                    LargeCapOnly=(self._market_cap() == EquityMarketCap.LARGE),
                    SmallCapOnly=(self._market_cap() == EquityMarketCap.SMALL))


if __name__ == '__main__':
    pass