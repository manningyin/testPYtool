from core.risk_factor.factory.equity import domain


def equity_name():
    # Equity spot risk factors
    all_risk_factors = []
    for ISIN in ['DK0060534915',]:
        riskfactor = domain.RfEquityPrice(equityId = ISIN, equityIdType = 'ISIN')
        all_risk_factors.append(riskfactor)
    return all_risk_factors


if __name__ == '__main__':
    x = RfEquityPriceFactory()
    y = [z for z in x]
    z = equity_name()
    pass
