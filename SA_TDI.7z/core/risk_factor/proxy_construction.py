"""
This module creates a python interface for generating proxy mapping in Groovy language.

Notes:
    Author: g01571
"""


class ProxyRule:
    def __init__(self, condition='rules()\n{children}', children=[], indent=0):
        self.condition = condition
        self.children = children
        self.proxy_str = None
        self.indent = indent

    def if_label(self, label, values):
        """
        If statement, adds an "if" child to the "self" rule it returns the child rule,
        implements "if label in values" in groovy

        :param label:   type label i.e issuerType, currency
        :param values: condition value ie, MORTGAGE, EUR  can be string or list
        :return:
        """
        if type(label) == tuple:
            label = "labelKey({}, {})".format(label[0], label[1])
        elif type(label) == str:
            pass
        else:
            label = label.name
        if len(self.children) == 0:
            s_key = ".then({cond}\n{children})"
        else:
            s_key = ".orElse({cond}\n{children})"
        if isinstance(values, str):
            inner_cond = "ifTrue(hasLabelWithValue({}, {}))".format(label, values)
        elif isinstance(values, (list, tuple)):
            values_str = ", ".join(values)
            inner_cond = "ifTrue(hasLabelWithOneOfValues({}, {}))".format(label, values_str)
        else:
            raise ValueError
        condition = s_key.format(cond=inner_cond, children="{children}")
        child = ProxyRule(condition=condition, children=[], indent=self.indent+1)
        self.children.append(child)
        return child

    def else_condition(self):
        """
        Add an "else" rule as child to the current rule. It gives an error if the current rule has no if child yet
        :return:
        """
        if len(self.children) == 0:
            raise AssertionError("No if condition is set yet")
        condition = ".orElse(withoutCondition()\n{children})"
        child = ProxyRule(condition=condition, children=[], indent=self.indent+1)
        self.children.append(child)
        return child

    def if_type(self, risk_type):
        """
        If statement, adds an "if" child to the "self" rule it returns the child rule,
        implements "if type == risk_type" in groovy

        :param risk_type:   i.e RfBondSwapBasis,
        :return:
         """
        if len(self.children) == 0:
            s_key = ".ruleOf(ifTrue(isOfType({risk_type}))\n{children})".format(risk_type=risk_type.name,
                                                                                children="{children}")
        else:
            s_key = ".orElse(ifTrue(isOfType({risk_type}))\n{children})".format(risk_type=risk_type.name,
                                                                                children="{children}")
        condition = s_key
        child = ProxyRule(condition=condition, children=[], indent=self.indent+1)
        self.children.append(child)
        return child

    def proxy(self, with_label_keys=(), with_label={}, with_key=[]):
        self.proxy_str = ".proxy(withLabelKeys({})".format(", ".join([i.name for i in with_label_keys]))
        for i in with_label:
            if type(i) == tuple:
                i_str = "labelKey({}, {})".format(i[0], i[1])
            else:
                i_str = i.name

            self.proxy_str += '.andWithLabel({}, {})'.format(i_str, with_label[i])

        for i in with_key:
            if type(i) == tuple:
                i_str = "labelKey({}, {})".format(i[0], i[1])
            else:
                i_str = i.name
            self.proxy_str += ".andWithKey({})".format(i_str)
        self.proxy_str += ')'

    def proxy_with_groovy(self, p):
        """
        Here you can directly set a proxy in groovy language as string
        example usage:
            proxy_with_groovy("withLabelKeys(bucket, riskFactorType, issuerCountry, issuerType)")
        :param p:
        :return:
        """
        self.proxy_str = ".proxy({})".format(p)

    def get_groovy(self):
        """
        This function recursively constructs the groovy script
        Note that all the rules are structures the following way => rule(condition, children) so here we construct
        children recursively
        :return:
        """
        if len(self.children) == 0:
            if self.proxy_str is None:
                # If no proxy is set for an open if statement than the structure by the user is wrong
                raise ValueError("proxy not set")
            else:
                # if there is a proxy do the necessary indentation and create the string
                proxy_str = (self.indent+1) * '    ' + self.proxy_str
                out = "    " * self.indent + self.condition.format(children=proxy_str)
                return out
        else:
            # If the rule has children append their script seperated with blank line
            from_children = "\n".join([child.get_groovy() for child in self.children])
            condition_str = "    "*self.indent + self.condition
            return condition_str.format(children=from_children)
