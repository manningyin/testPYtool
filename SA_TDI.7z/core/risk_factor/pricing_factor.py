"""
Functionality related to pricing factors (risk factors in Front Office pricing models)


Warning:

Notes:
    Author: JBrandt

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       23apr2018   JBrandt     Initial creation
    2       12nov2019   ABaglan     Updated for Refinance Risk
    ======= =========   =========   ========================================================================================

"""
from core.risk_factor import risk_factor_utils
from core.risk_factor.factory import orca_pricing_factor
from core.risk_factor.factory.rates import domain as rates_domain
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.utils import date_helper

missing_hazard_reported = False
missing_inflation_reported = False
missing_recovery_reported = False


def from_risk_factor(risk_factor):
    """
    Translates risk factor (matching "Avro structure") into Pricing Factor readable by Orca as scenario name.

    The use of "find()" in the elif statements is done in order to make the function immune to trivial renaming
    of the risk factor avro schemas (RfCcyPair20 -> RfCcyPair, RfBondResidualZspread2 -> RfBondResidualZspread)

    Args:
        risk_factor (dict): "Clean" risk factor object (without meta-data, md mapping etc) matching the Avro structure.

    Returns:
        (str):  String representation of the risk factor, which can be interpret by Orca as scenario name.

    Example:
        The module is called (from python) like this::

            from core.risk_factor.factory import risk_factor_domain as rfd

            my_risk_factor = {  'rfType'    : rfd.RiskFactorType.RfCcyPair,
                                'foreign'   : 'NOK',
                                'domestic'  : 'EUR',
                                }
            orca_pricing_factor = from_risk_factor(my_risk_factor)


    Notes:
        Author: Shengyao
    """
    # get orca scenario name for an element in risk factor mapping
    rf_type = risk_factor["rf_type"]

    # ===================================================================================
    # Interest Rate risk factors
    # ===================================================================================
    if rf_type == RiskFactorType.RfInterestRate:
        out = risk_factor["curve_name"]

    elif rf_type == RiskFactorType.RfRefinanceRate:
        out = risk_factor['name']

    # ===================================================================================
    # IR Volatility Risk Factor
    # ===================================================================================
    elif rf_type in [RiskFactorType.RfInterestAtmVolatility]:
        return risk_factor['surface_name']



    # ===================================================================================
    # Credit risk factors
    # ===================================================================================
    elif rf_type in [RiskFactorType.RfBondSwapBasis]:
        out = risk_factor["curve_name"]
    elif rf_type in [RiskFactorType.RfBondResidualZspread]:
        out = 'RATE.ZSPREAD.' + risk_factor['isin']
    elif rf_type in [RiskFactorType.RfHazardRate]:
        # CREDIT.BI_KOMMINVS.SEK.CREDIT.HAZARD.BI_KOMMINVS.SEK
        out = 'CREDIT.' + risk_factor['name'] + '.' + risk_factor['ccy'] + '.' + 'CREDIT.HAZARD.' + risk_factor['name'] + '.' + risk_factor['ccy']
    elif rf_type in [RiskFactorType.RfBondSwapBasis]:
        out = risk_factor['curve_name']
    # ===================================================================================
    # FX risk factors
    # ===================================================================================
    elif rf_type == RiskFactorType.RfCcyPair:
        out = orca_pricing_factor.fx_pair(risk_factor['foreign'], risk_factor['domestic'])
    else:
        raise NotImplementedError("The risk factor " + str(rf_type) + " is not implemented in scenario service")
    return out


def label_to_rf_type(risk_label):
    """
    Determines appropriate risk factor type for a pricing factor risk label

    Args:
        risk_label  (dict or str):  Risk label for Orca pricing factor, matching q-toolkit risk-label

    Returns:
        (RiskFactorType): Internal code-lib risk factor type (as internal object)

    Example:

        >>> from core.risk_factor import pricing_factor
        >>> code_lib_rf = pricing_factor.label_to_rf_type('NO.CURVE')
        >>> code_lib_rf.name
        'RfBondSwapBasis'

    Notes:
        Author: JBrandt (g50444)
    """

    global missing_hazard_reported
    global missing_recovery_reported

    try:
        rf_type = risk_label['rf_type']

    except (TypeError, KeyError):
        risk_label_name = str(risk_label.name)

        if risk_label_name.find('ZCPN_SPREAD') >= 0 or risk_label_name.find('DISC.REPO') >= 0:
            # Not a risk factor in our current risk models
            rf_type = None
        elif risk_label_name.endswith('DISC.OIS') or risk_label_name.endswith('DISC.LIBOR'):
            rf_type = RiskFactorType.RfInterestRate
        elif risk_label_name.find('.FWD.') >= 0:
            rf_type = RiskFactorType.RfInterestRate
        elif risk_label_name.endswith('.CURVE') or risk_label_name.find('DISC.GOV') > 0:
            rf_type = RiskFactorType.RfBondSwapBasis
        elif risk_label_name.startswith('RATE.ZSPREAD'):
            rf_type = RiskFactorType.RfBondResidualZspread
        elif risk_label_name.find('HAZARD') >= 0:
            rf_type = RiskFactorType.RfHazardRate
        elif risk_label_name.find('RECOVERY') >= 0:
            rf_type = RiskFactorType.RfRecoveryRate
        else:
            raise KeyError('Not able to determine risk factor type for risk label: ' + risk_label_name)

    except Exception as e:
        raise Exception("Not able to determine risk factor type. Got unexpected exception: " + str(e))

    return rf_type


def zspread_to_risk_factor(risk_label):
    """
    Converting Orca pricing factor to risk factor(s) - for a Z-spreads

    Args:
        risk_label  (Object):   Orca risk label object - As delivered by Orca risk factor service.

    Returns:
        (list of dicts): Risk Factor dictionaries matching avro definition

    Notes:
        Author: JBrandt
    """

    cur = risk_label.currency.name
    isin = risk_label.name.split('.')[-1]
    # FIXME: This is a hard-coding since ORCA does not provide curve_name
    curve = 'NA' # "RATE.%s.DISC.GOV_%s" % (cur, cur[0:2])

    rf_dict = dict(isin = isin, curve_name = curve)

    return [rf_dict]


def bond_swap_basis_to_risk_factor(risk_label):
    """
    Converting Orca pricing factor to risk factor(s) - for bond swap basis.

    Args:
        risk_label  (risk_label object):      As delivered by Orca. Typically corresponding to curve name

    Returns:
        (dict): Risk Factor dictionary matching avro definition

    Notes:
        Author: JBrandt
    """

    all_rf = []

    cur = risk_label.currency.name
    curve = risk_label.name
    # FIXME: This is a hard-coding as ORCA doesn't provide main IR curve name
    main_ir_curve = 'RATE.%s.DISC.OIS' % cur

    for term in rates_domain.RISK_FACTOR_IR_BUCKETS:
        main_dict = dict(ccy = cur,
                         curve_name = main_ir_curve,
                         tenor = term,
                         rfType = RiskFactorType.RfInterestRate.avro_schema_name,
                         )
        rf_dict = dict(ccy = cur, curve_name = curve, tenor = term, main = main_dict)
        all_rf.append(rf_dict)

    return all_rf


def ir_to_risk_factor(risk_label, instrument = None):
    """
    Converting Orca interest rate pricing factor to risk factor(s)

    Args:
        risk_label  (str or dict):  As delivered by Orca. Typically corresponding to curve name
        instrument  (list):         Orca instrument names - that is (short) text string concatenation of chosen
                                    characteristics.

    Returns:
        (list of dicts): Risk Factor dictionaries matching avro definition

    Notes:
        Author: JBrandt
    """

    all_rf = []

    if instrument is None:
        for term in rates_domain.RISK_FACTOR_IR_BUCKETS:
            curve = risk_label['curve']
            ccy = risk_label['ccy']

            rf_dict = dict(ccy = ccy, curve_name = curve, tenor = term)
            all_rf.append(rf_dict)

    else:
        from core.connection import orca_connect

        # ===================================================================================
        # Getting instrument conventions
        # ===================================================================================
        try:
            conventions = orca_connect.instrument_conventions(instrument = instrument,
                                                              valuation_timestamp = date_helper.yesterday_as_date()
                                                              )
        except Exception as e:
            raise Exception("Problem occurred when getting instrument conventions for instruments: " + str(instrument)
                            + " Exception: " + str(e))

        # ===================================================================================
        # Creating risk factors
        # ===================================================================================

        for key, value in conventions.items():
            try:
                term = str(value['Tenor'])
            except:
                term = str(value['FloatFixingTenor'])

            ccy = str(value['Currency'])

            rf_dict = dict(ccy = ccy, curve_name = risk_label, tenor = term)
            all_rf.append(rf_dict)

    return all_rf


def to_risk_factor(risk_label):
    """
    Converting (Orca) pricing factors into risk factors matching Risk Factor Repository structure

    Args:
        risk_label  (Object):   Risk Label object as delivered by Orca.
                                Holds information like currency, curve name etc.

    Returns:
        (RiskFactor): Risk Factor object matching the pricing factor

    Notes:
        Author: JBrandt
    """

    rf_type = label_to_rf_type(risk_label)

    if rf_type is None:
        all_rf_obj = None

    else:
        all_rf = []
        if rf_type == RiskFactorType.RfBondSwapBasis:
            all_rf = bond_swap_basis_to_risk_factor(risk_label)

        elif rf_type == RiskFactorType.RfBondResidualZspread:
            all_rf = zspread_to_risk_factor(risk_label)

        all_rf_obj = []
        for single_rf in all_rf:
            # ===================================================================================
            # Risk factors are created as dicts in the functions above.
            # Now we create code-lib risk factor objects from the dict (avro-style)
            # representations.
            # ===================================================================================
            single_rf_obj = risk_factor_utils.dict_to_rf_object(risk_factor_dict = single_rf,
                                                                risk_factor_type = rf_type)

            # ===================================================================================
            # Now risk factor object has been created. We add creation detail-labels
            # ===================================================================================
            single_rf_obj.add_label(group = 'creation_details',
                                    name = 'orca_pricing_factor',
                                    value = str(risk_label.name))

            single_rf_obj.add_label(group = 'creation_details',
                                    name = 'source',
                                    value = 'curator_prototype')

            all_rf_obj.append(single_rf_obj)

    return all_rf_obj


if __name__ == '__main__':

    scenarios = [
        u'NOK.DISC.OIS.CURVE', u'NOK.RATE.FWD.6M', u'NOK/NOK.FX.SPOT', u'NOK.RATE.ZCPN_SPREAD', u'RATE.ZSPREAD.NO0010429913', u'NOK.RATE.FWD.1D', u'NOK.RATE.FWD.3M', u'NOK.RATE.FWD.1M',
        u'NO.CURVE'
    ]
    for rf in scenarios:
        pf = to_risk_factor(risk_label = rf)

    # orca_message = [
    #     {"RiskLabel": "RATE.DISC.EUR.CURVE", "InstrumentNames": ["EUREONONDEP", "EUREONTNDEP", "EURIBOR1MD", "EURIBOR2MD", "EURIBOR3MD", "EURIBOR6MD", "EURAB6E1Y", "EURAB6E18M", "EURAB6E2Y", "EURAB6E3Y", "EURAB6E4Y", "EURAB6E5Y", "EURAB6E6Y"]
    #      },{"RiskLabel": "RATE.DISC.EUR.CURVE", "InstrumentNames": ["EUREONON", "EUREONTN", "EUREON2M", "EUREON3M", "EUREON4M", "EUREON5M", "EUREON6M", "EUREON7M", "EUREON8M", "EUREON9M", "EUREON10M", "EUREON11M", "EUREON1Y", "EUREON18M", "EUREON2Y", "EUREON3Y", "EUREON4Y", "EUREON5Y", "EUREON6Y", "EUREON7Y"]
    #         },{"RiskLabel": "RATE.DISC.EUR.CURVE", "InstrumentNames": ["EUREONONDEP", "EUREONTNDEP", "EURIBOR1MD", "EURIBOR2MD", "EURIBOR3MD", "EURIBOR6MD", "EURAB6E1Y", "EURAB6E18M", "EURAB6E2Y", "EURAB6E3Y", "EURAB6E4Y", "EURAB6E5Y", "EURAB6E6Y"]
    #            },{"RiskLabel": "RATE.RATE.FWD.FWD", "InstrumentNames": ["EURIBOR1YD", "EURAM3E12E_IMM_1", "EURAM3E12E_IMM_2", "EURAM3E12E_IMM_4", "EURAM3E12E_IMM_5", "EURAM3E12E_IMM_6", "EURAM3E12E_IMM_7", "EURAB6E12E3Y", "EURAB6E12E4Y", "EURAB6E12E5Y", "EURAB6E12E6Y", "EURAB6E12E7Y"]
    #               },{"RiskLabel": "RATE.RATE.FWD.FWD", "InstrumentNames": ["FEI1", "FEI2", "FEI3", "FEI4", "FEI5", "FEI6", "FEI7", "FEI8", "FEI9", "FEI10"]
    #                  },{"RiskLabel": "RATE.RATE.FWD.FWD", "InstrumentNames": ["EURAB6E3Y", "EURAB6E4Y", "EURAB6E5Y", "EURAB6E6Y", "EURAB6E7Y"]
    #                     },{"RiskLabel": "RATE.DISC.EUR.CURVE", "InstrumentNames": ["EUREONOinstrumentNDEP", "EUREONTNDEP", "EURIBORSWD", "EURIBOR2WD", "EURIBOR1MD", "EURIBOR2MD", "EURIBOR3MD", "EURIBOR6MD", "EURAB6E1Y", "EURAB6E18M", "EURAB6E2Y", "EURAB6E3Y", "EURAB6E4Y", "EURAB6E5Y", "EURAB6E6Y", "EURAB6E7Y", "EURAB6E8Y", "EURAB6E9Y", "EURAB6E10Y"]
    #                        },{"RiskLabel": "RATE.DISC.EUR.CURVE", "InstrumentNames": ["EUREONON", "EUREONTN", "EUREON3M", "EUREON6M", "EUREON9M", "EUREON11M", "EUREON1Y", "EUREON18M", "EUREON2Y", "EUREON3Y", "EUREON4Y", "EUREON5Y", "EUREON6Y", "EUREON7Y", "EUREON8Y", "EUREON9Y", "EUREON10Y", "EUREON11Y", "EUREON12Y", "EUREON13Y"]
    #                           },{"RiskLabel": "RATE.DISC.EUR.CURVE", "InstrumentNames": ["EUREONONDEP", "EUREONTNDEP", "EURIBORSWD", "EURIBOR2WD", "EURIBOR1MD", "EURIBOR2MD", "EURIBOR3MD", "EURIBOR6MD", "EURAB6E1Y", "EURAB6E18M", "EURAB6E2Y", "EURAB6E3Y", "EURAB6E4Y", "EURAB6E5Y", "EURAB6E6Y", "EURAB6E7Y", "EURAB6E8Y", "EURAB6E9Y", "EURAB6E10Y"]
    #                              },{"RiskLabel": "RATE.RATE.FWD.FWD", "InstrumentNames": ["EURIBOR3MD", "FEI1", "FEI2", "FEI3", "FEI4", "FEI5", "FEI6", "FEI7", "FEI8", "FEI9", "FEI10", "EURAB3E6E3Y", "EURAB3E6E4Y", "EURAB3E6E5Y", "EURAB3E6E6Y", "EURAB3E6E7Y", "EURAB3E6E8Y", "EURAB3E6E9Y", "EURAB3E6E10Y", "EURAB3E6E11Y", "EURAB3E6E12Y", "EURAB3E6E13Y", "EURAB3E6E14Y"]
    #                                 }]
    #
    # all_rf = []
    # for i in orca_message:
    #     risk_label = i['RiskLabel']
    #     rf = to_risk_factor(risk_label = risk_label,instrument = i["InstrumentNames"])
    #     all_rf.append(rf)
    #
    # pass

    # from core.risk_factor.factory import risk_factor_domain as rfd
    #
    # my_risk_factor = {  'rfType'    : rfd.RiskFactorType.RfCcyPair,
    #                     'foreign'   : 'NOK',
    #                     'domestic'  : 'EUR',
    #                     }
    #
    # orca_pricing_factor = from_risk_factor(my_risk_factor)
    #
