"""
Various small utility functions to handle code-lib risk factors.

Notes:
    Author: JBrandt (g50444)

"""
import copy
from core.risk_factor.factory.risk_factor_domain import RiskFactorType
from core.utils import list_helper
from risk_factor_repository.models import Predicate, PredicateLabel, RiskFactorsContext
from risk_factor_repository import RiskFactorControllerApi



def dict_to_rf_object(risk_factor_dict, risk_factor_type=None):
    """
    Transform dictionary with structure matching the risk factor avro schemas, into code-lib risk factor object.

    Args:
        risk_factor_dict    (dict):             Risk factor instance as dict exactly matching the avro structure
                                                e.g. {'domestic': 'EUR', 'foreign': 'USD'}
        risk_factor_type    (RiskFactorType):   Type of the risk factor, matching code-lib enum class

    Returns:
        (RiskFactor): Risk factor as code-lib risk factor object

    Example:
        Testable example:

            >>> from core.risk_factor import risk_factor_utils
            >>> from core.risk_factor.factory.risk_factor_domain import RiskFactorType
            >>> my_rf_obj = risk_factor_utils.dict_to_rf_object({'domestic': 'JPY', 'foreign': 'USD'},
            ...                                                 RiskFactorType.RfCcyPair)
            >>> my_rf_obj.metadata['short_name']
            'USD.JPY'

    Notes:
        Author: JBrandt (g50444)
    """

    local_risk_factor_dict = copy.deepcopy(risk_factor_dict)

    if risk_factor_type is None:
        rf_type = local_risk_factor_dict.pop('rf_type')
    else:
        rf_type = risk_factor_type

    try:
        rf_class = rf_type.risk_factor_class
        rf = rf_class(**local_risk_factor_dict)
    except TypeError as e:
        raise TypeError("Not able to to convert dictionary to risk factor object."
                        + " Risk Factor Type: " + rf_type.name + " Dict: " + str(local_risk_factor_dict)
                        + " Python error message: " + str(e))

    return rf


def rf_object_from_avro(avro_risk_factor):
    """
    Transforming dictionaries structures of risk factors into instances of the code-lib risk factor classes.

    Function supports that input is dicts with rfType as either avro name (as string), rfType as RiskFactorType object
    or dictionary WITHOUT rfType if the other keys in the dict matches the keys of a risk factor type (uniquely).

    Args:
        avro_risk_factor (dict or list of dict):  Dictionaries matching the "avro" structure of risk factors, as defined
                                                  in risk factor classes in mr.risk_factor.factor.<risk class>.domain

    Returns:
        (list of dicts): Risk factor instances of the code-lib risk factor classes.

    Example:
        Create FX currency pair risk factor instance:

            >>> from core.risk_factor import rfr_controller
            >>> from core.risk_factor import risk_factor_utils
            >>> from core.risk_factor.factory.risk_factor_domain import RiskFactorType
            >>> rf_dict = dict(domestic = 'EUR', foreign = 'USD', rfType = RiskFactorType.RfCcyPair.avro_schema_name)
            >>> rf_obj = risk_factor_utils.rf_object_from_avro(rf_dict)
            >>> rf_obj[0].riskfactor['foreign']
            'USD'

        Guessing risk factor type from dict keys:

            >>> from core.risk_factor import rfr_controller
            >>> from core.risk_factor import risk_factor_utils
            >>> from core.risk_factor.factory.risk_factor_domain import RiskFactorType
            >>> rf_dict = dict(domestic = 'EUR', foreign = 'USD')
            >>> rf_obj = risk_factor_utils.rf_object_from_avro(rf_dict)
            >>> rf_obj[0].riskfactor['foreign']
            'USD'


    Notes:
        Author: JBrandt (g50444)
    """

    # Creating dict with key: avro schema name value: rf type
    avro_rf_type_map = {rf_type.avro_schema_name: rf_type for rf_type in RiskFactorType}
    avro_risk_factor_as_list = copy.deepcopy(list_helper.to_list(avro_risk_factor))

    all_rf_obj = []
    for rf in avro_risk_factor_as_list:
        if rf is None:
            continue
        if 'rf_type' in rf:
            rf_type_raw = rf.pop('rf_type')  # Important that it is pop'ed (and removed)
            if isinstance(rf_type_raw, RiskFactorType):
                # Already of the right type. We just copy...
                rf_type = rf_type_raw
            else:
                # ===================================================================================
                # We assume that rf_type_raw is the avro risk factor type as a string.
                # We find the corresponding RiskFactorType.
                # ===================================================================================
                rf_type = avro_rf_type_map[rf_type_raw]

        else:
            # ===================================================================================
            # The rfType is not in the object. We will "guess" the type of the risk factor.
            # We do this by comparing dictionary keys with arguments to the __init__ methods of
            # the risk factor type specific classes (in the function below).
            # ===================================================================================
            rf_args_as_string = str(sorted(rf))
            try:
                rf_type = guess_risk_factor_type(rf_args_as_string)
            except KeyError:
                raise KeyError('Did not find any risk factor types with these elements: ' + rf_args_as_string)

        rf_obj = dict_to_rf_object(risk_factor_dict=rf,
                                   risk_factor_type=rf_type,
                                   )
        all_rf_obj.append(rf_obj)

    return all_rf_obj


def guess_risk_factor_type(risk_factor_arguments):
    """
    Finds risk factor type with specific class (__init__) arguments.

    Note that this functions uses "easy_cache" so it can be used in a loop over risk factors, without running it
    several times with same input. Usage of easy_cache has been chosen due to readability if calling code.

    Args:
        risk_factor_arguments   (str):  Risk factor arguments as sorted string: e.g. "'domestic', 'foreign'"

    Returns:
        (RiskFactorType): Risk factor type that has exactly these arguments in its corresponding class.

    Example:
        Testable example:

            >>> from core.risk_factor import risk_factor_utils
            >>> my_rf_args = "['domestic', 'foreign']"
            >>> rf_type = risk_factor_utils.guess_risk_factor_type(my_rf_args)
            >>> rf_type.name
            'RfCcyPair'

    Notes:
        Author: JBrandt (g50444)
    """

    matching_risk_factor_type = None
    rf_with_duplicating_arguments = []
    for rf_type in RiskFactorType:
        # ===================================================================================
        # Finding arguments for risk factor type (object) and converting to sorted string
        # ===================================================================================
        args = rf_type.risk_factor_class_args
        str_args = str(sorted(args))
        if str_args == risk_factor_arguments:
            # ===================================================================================
            # Risk factor type has the required arguments.
            # Checking that we have not already found a risk factor with these arguments
            # (non unique mapping)
            # ===================================================================================
            if matching_risk_factor_type is not None:
                # ===================================================================================
                # Gathering "problem" information, in order to raise one exception with all issues
                # ===================================================================================
                rf_with_duplicating_arguments.append(rf_type)
            else:
                matching_risk_factor_type = rf_type

    if len(rf_with_duplicating_arguments) > 0:
        # ===================================================================================
        # Raising exception with information about all non 1:1 mapping issues
        # ===================================================================================
        matching_rf_type_names = [rf_type.name for rf_type in rf_with_duplicating_arguments]
        raise KeyError("Found several risk factor types with same elements. "
                       + "Risk factor types: " + matching_rf_type_names
                       + " all has same arguments: " + risk_factor_arguments)

    if matching_risk_factor_type is None:
        raise KeyError("Could not find risk factor class with following arguments: " + risk_factor_arguments)

    return matching_risk_factor_type


def duplicate_shortnames(risk_factors):
    """
    Checking risk factor for duplicate shortnames. Raises an exception if duplicates are found.

    Args:
        risk_factors (list): List of risk factors, matching the general code-lib risk factor types

    Returns:
        (bool): False if short names are uniquely defined. Raises an exception if not!

    Example:
        The module is called (from python) like this::

            from core.risk_factor.factory import fx
            from core.risk_factor import curator


            rf = [fx.domain.RfCcyPair('EUR','USD'), fx.domain.RfCcyPair('EUR','USD')]
            unique_rf = curator.duplicate_shortnames(rf)


    Notes:
        Author: JBrandt (g50444)
    """

    rf_with_unique_shortnames = []
    short_names = []
    non_unique_shortnames = set()
    for single_rf in risk_factors:
        # ===================================================================================
        # Checking for uniqueness of short names. We do not want to create two risk factors
        # with the same short name.
        # ===================================================================================
        current_short_name = single_rf.metadata['short_name']

        if current_short_name in short_names:
            # ===================================================================================
            # We have already seen a risk factor with this short name -> duplicate!
            # ===================================================================================
            if current_short_name not in non_unique_shortnames:
                # ===================================================================================
                # This is first occurrence of this duplicate risk factor. We print a message.
                # ===================================================================================
                non_unique_shortnames.add(current_short_name)
        else:
            short_names.append(current_short_name)
            rf_with_unique_shortnames.append(single_rf)

    non_unique_shortname_count = len(non_unique_shortnames)
    if non_unique_shortname_count > 0:
        duplicate_shortnames_found = True
        if non_unique_shortname_count > 20:
            raise Exception(str(non_unique_shortname_count)
                            + ' non-unique Short Names found. Showing first 20: \n'
                            + '\n'.join(list(non_unique_shortnames)))
        else:
            raise Exception('Following Short Name(s) are non-unique: \n' + '\n'.join(list(non_unique_shortnames)))
    else:
        duplicate_shortnames_found = False

    return duplicate_shortnames_found


def validate_currency(currencies):
    """
    Validating that currencies in input list is in expected format (ISO 4217). Returns KeyError if validations fails.

    Args:
        currencies      (list): List of currencies to be validated

    Example:
        The module is called (from python) like this::

            validate_currency(['EUR', 'DKK', 'USD'])

    Notes:
        Author: JBrandt (g50444)
    """
    import quantum as qt

    qt_currencies = qt.getValidCcyNames()
    bad_currencies = []
    for cur in list_helper.to_list(currencies):
        if cur not in qt_currencies:
            bad_currencies.append(cur)

    for bad_currency in bad_currencies:
        raise KeyError("Currency of unexpected format found. Currency name: " + bad_currency)


class MyPredicate(Predicate):
    """
    Class for merging predicates and constructing them from labels and properties

    Args:
        _and=None                       (list[Predicate]): List of predicates where all must be true
        _or=None                        (list[Predicate]): List of predicates where at least one must be true
        has_label=None                   (PredicateLabel): Label for each predicate
        has_property=None                (PredicateLabel): Property for each predicate
        local_vars_configuration=None     (Configuration): Optional configuration that can be passed to OpenAPI

    Notes:
        Author: g48015
    """
    @classmethod
    def from_property(cls, group=None, name=None, value=None, _in=None, nin=None):
        return cls(has_property=PredicateLabel(group, name, value, _in, nin))

    @classmethod
    def from_label(cls, group=None, name=None, value=None, _in=None, nin=None):
        return cls(has_label=PredicateLabel(group, name, value, _in, nin))

    def to_context(self, name: str, interpolations: list or tuple = (),
                   extra_data: list or tuple = ()) -> RiskFactorsContext:
        return RiskFactorsContext(
            name=name,
            predicate=self,
            extra_data=extra_data,
            interpolations=interpolations)

    def query(self, client):
        if isinstance(client, RiskFactorControllerApi):
            return client.query_by_predicate_risk_factors(predicate=self)
        else:
            return client.risk_factor_repository.risk_factor.query_by_predicate_risk_factors(predicate=self)

    def __and__(self, other):
        if (self._and is not None) and (other._and is not None):
            _and = copy.deepcopy(self._and) + copy.deepcopy(other._and)
        elif (self._and is not None) and (other._and is None):
            _and = copy.deepcopy(self._and) + [copy.deepcopy(other)]
        elif (other._and is not None) and (self._and is None):
            _and = [copy.deepcopy(self)] + copy.deepcopy(other._and)
        else:
            _and = [copy.deepcopy(self), copy.deepcopy(other)]
        return MyPredicate(_and=_and)

    def __or__(self, other):
        if (self._or is not None) and (other._or is not None):
            _or = copy.deepcopy(self._or) + copy.deepcopy(other._or)
        elif (self._or is not None) and (other._or is None):
            _or = copy.deepcopy(self._or) + [copy.deepcopy(other)]
        elif (other._or is not None) and (self._or is None):
            _or = [copy.deepcopy(self)] + copy.deepcopy(other._or)
        else:
            _or = [copy.deepcopy(self), copy.deepcopy(other)]
        return MyPredicate(_or=_or)

    def __invert__(self):
        if self._or is not None:
            return MyPredicate(_and=[~x for x in self._or])
        if self._and is not None:
            return MyPredicate(_or=[~x for x in self._and])

        if self.has_property is not None:
            out = dict(group=self.has_property.group, name=self.has_property.name)
            if self.has_property._in is not None:
                out['nin'] = self.has_property._in
            elif self.has_property.nin is not None:
                out['_in'] = self.has_property.nin
            elif self.has_property.value is not None:
                if self.has_property.value == 'True':
                    out['value'] = 'False'
                elif self.has_property.value == 'False':
                    out['value'] = 'True'
                else:
                    out['nin'] = [self.has_property.value]

            return MyPredicate.from_property(**out)
        if self.has_label is not None:
            out = dict(group=self.has_label.group, name=self.has_label.name)
            if self.has_label._in is not None:
                out['nin'] = self.has_label._in
            elif self.has_label.nin is not None:
                out['_in'] = self.has_label.nin
            elif self.has_label.value is not None:
                if self.has_label.value == 'True':
                    out['value'] = 'False'
                elif self.has_label.value == 'False':
                    out['value'] = 'True'
                else:
                    out['nin'] = [self.has_label.value]

            return MyPredicate.from_label(**out)

        raise AttributeError('Predicate has no "_or", "_and", "has_property" or "has_label" attributes')


class Label(object):
    def __new__(cls, name, values=None, not_values=None, group='master'):
        if values is None and not_values is None:
            raise ValueError

        out = dict(group=group, name=name)
        if not_values is not None:
            out['nin'] = [str(x) for x in not_values]
        if isinstance(values, (list, tuple)):
            out['_in'] = [str(x) for x in values]
        elif values is not None:
            out['value'] = str(values)

        return MyPredicate.from_label(**out)


class Property(object):
    def __new__(cls, name, values=None, not_values=None, group='creation_details'):
        if values is None and not_values is None:
            raise ValueError

        out = dict(group=group, name=name)
        if not_values is not None:
            out['nin'] = [str(x) for x in not_values]
        if isinstance(values, (list, tuple)):
            out['_in'] = [str(x) for x in values]
        elif values is not None:
            out['value'] = str(values)

        return MyPredicate.from_property(**out)


def label_obj(label):
    """
    Ensures that label is of the label object type.

    Args:
        label    (dict or Label): If dict it must have the following keys: group, name and value (optional)

    Returns:
        (Label): Label object

    Example:
        The module is called (from python) like this::

            my_label_obj = label_obj(dict(group = master, name = current_coverage))

    Notes:
        Author: JBrandt (g50444)
    """

    if isinstance(label, Label):
        label_obj_out = label
    else:
        group = label['group']
        name = label['name']
        try:
            value = label['value']
        except KeyError:
            value = None

        label_obj_out = Label(group=group, name=name, values=value)

    return label_obj_out
