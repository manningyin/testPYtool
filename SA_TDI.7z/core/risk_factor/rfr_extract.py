"""
Module for various functions extracting information from Risk Factor Repository

Notes:
    Author: JBrandt (g50444)

"""
from core.connection import api
from core.utils import dict_helper
from risklib.connection.ripl import ext_envir
from ripl_core.authentication import create_sso_config
from ripl_core import RiplClient


def risk_factors_from_context(context_name='master'):
    """
    Returns all risk factors in Risk Factor Repository context. That is getting them from RFR

    Args:
        context_name (str): Name of the context in Risk Factor Repository

    Returns:
        (list): List of risk factor instances as dicts matching avro's

    Notes:
        Author: JBrandt (g50444)
    """

    # Getting the "raw" context from the RFR API
    #rf_api = api.risk_factor_repository_api()

    # NB: We must use only below function, as the rest are paged and thus don't work well with python integration...
    #risk_factors_in_context_raw = rf_api.riskfactorcontext.get_by_name_rf_context(context_name)
    config = create_sso_config("prod")
    ext_envir.RIPL.prod.activate()
    client = RiplClient(**config)
    risk_factors_in_context_raw = client.risk_factor_repository.risk_factors_context.get_by_name_rf_context(context_name)

    # Transforming API output to clean objects
    rf_in_context = risk_factors_in_context_raw.to_dict()['risk_factors']

    return rf_in_context


def rfr_load_all_metadata():
    meta_raw = api.risk_factor_repository_api().rf_with_metadata.get_all_risk_factor_with_meta_data()
    return meta_raw


def load_all_risk_factors():
    rf_api = api.risk_factor_repository_api()
    risk_factors_raw = rf_api.riskfactor.get_all_risk_factors(page_size=999999999)
    return [x.risk_factor.to_dict() for x in risk_factors_raw]


def risk_factors_in_market_data_context(context_name='master'):
    """
    Extract risk factors in a specific market data context from Risk Factor Repository

    Args:
        context_name (str): Name of the market data mapping context in Risk Factor Repository (case sensitive)

    Returns:
        (list): Risk factors in md mapping context as dictionaries (matching Avro schemas).

    Notes:
        Author: JBrandt
    """

    # Extracting risk factor mapping objects in chosen context
    rf_api = api.risk_factor_repository_api()
    risk_factors_and_mapping = rf_api.marketdatacontext.get_by_name_md_context(context_name)

    # ===================================================================================
    # Extracting risk factor elements from mapping objects
    # Converting risk factor string representations to "nice" dictionaries
    # ===================================================================================

    if risk_factors_and_mapping.mappings is None:
        risk_factors_in_context = []
    else:
        risk_factors_in_context = [x['risk_factor'] for x in risk_factors_and_mapping.to_dict()['mappings']]

    return risk_factors_in_context


def load_rf_metadata(short_name):
    metadata_api = api.risk_factor_repository_api().metadata
    return metadata_api.get_one_risk_factor_meta_data_by_short_name(short_name)


if __name__ == '__main__':
    rf = risk_factors_in_market_data_context('master_mars')
    pass