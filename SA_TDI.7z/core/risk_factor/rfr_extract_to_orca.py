from orca.types import ModelConfigurationContext,ContextTimeStamp
import orca
import quantum as qt
import pandas as pd
import logging
import datetime as dt
from risklib.types import ScenarioCategory, CurveInterpolation, TermStructure, Point, Surface
from risklib.connection import orca_connect, ext_envir, ripl
from risklib.connection.ripl import implicit_client as ripl_implicit_client
from risklib.connection.orca_connect import implicit_client as orca_implicit_client
from risklib.external.orca.risk_factor import risk_factors_from_isins
from risklib.utils import date_helper




@ripl_implicit_client
def construct_scenario_pack(client, scenario_name, scenario_type, value_date):
    """
    construct scenario pack from scenariotype(Historical or Determinsic), scenario_name and value_date
    :param client (<class 'risklib.external.ripl.utils.RiplClient'>) if nothing is passed, the wrapper generates a conn
    :param scenario_name: (str) e.g., "TRIM Bond CS - IRM" , "TRIM Bond ALL - Historic"
    :param scenario_type: (<enum 'ScenarioCategory'>) e.g., ScenarioCategory.Historical
    :param value_date: (datetime.date) e.g., datetime.date(2021, 1, 19)
    :return (str) pack_id

    eg: pack_id = construct_scenario_pack("TRIM Bond ALL - Historic",ScenarioCategory.Historical,dt.date(2021, 1, 19))
    """

    if scenario_type == ScenarioCategory.Historical:
        hls = client.scenario_definer.historical_scenario.get_historical_scenario_by_name(scenario_name)
        pack_id = client.scenario_generator.historic_scenario_generator.generate_pack1(
            eod_date=value_date.strftime('%Y-%m-%d'),
            high_level_scenario_id=hls.id
        )
    elif scenario_type == ScenarioCategory.Deterministic:
        hls = client.scenario_definer.deterministic_scenario.get_deterministic_scenario_by_name(scenario_name)
        pack_id = client.scenario_generator.deterministic_scenario_generator.generate_pack(
            eod_date=value_date.strftime('%Y-%m-%d'),
            high_level_scenario_id=hls.id
        )
    else:
        raise NotImplementedError

    return pack_id

@ripl_implicit_client
def extract_rf_from_scenario_pack(client, pack_id):
    """
    extract scenario spec from scenario pack
    :param client (<class 'risklib.external.ripl.utils.RiplClient'>) if nothing is passed, the wrapper generates a conn
    :param pack_id: (str) scenario pack id
    :return: (dict) a dict with scenario date as key, and a list of ) as value.

    #eg:
    sc_spec = extract_rf_from_scenario_pack(pack_id)  #pck_id = '764dea1f-5e1d-46a7-a297-1d4f6471e9e2'
    """
    sc_pack = client.scenario_generator.scenario_pack.find_scenario_pack(scenario_pack_id=pack_id)
    if len(sc_pack.scenario_specs) == 1:
        return sc_pack.scenario_specs[0]
    else:
        logging.error("more than 1 scenario spec, please check")
        raise NotImplementedError

def convert_rf_from_scenario_pack_to_df(sc_spec):
    """
    convert rf (extracted from scenario spec) to df
    :param sc_spec: (<class 'scenario_generator.models.scenario_spec.ScenarioSpec'>)
    :return (pd.DataFrame)  a df with rf as row, scenario date as col.
             Additional cols: 'RF':ripl rf name, 'ORCA_RF_NAME': ORCA rf name, 'RF_TYPE':ripl rf type

    #eg:
    sc_spec = extract_rf_from_scenario_pack(pack_id)  #'764dea1f-5e1d-46a7-a297-1d4f6471e9e2'
    rf_df = convert_rf_from_scenario_pack_to_df(sc_spec)
    """
    rf_name = []
    orca_rf_name = []
    rf_type = [x.rf_type.split('.')[-1] for x in sc_spec.risk_factors]
    for x in sc_spec.risk_factors:
        tmp_rf_type = x.rf_type.split('.')[-1]
        if tmp_rf_type in ('RfBondCurveRate','RfInterestRate'):
            rf_name.append(x.curve_name + '.' + x.tenor)
            orca_rf_name.append(x.curve_name)
        elif tmp_rf_type == 'RfRefinanceRate':  # e.g., 294
            if x.tenor == 'IO':
                rf_name.append(x.name)
                orca_rf_name.append('DMB.REFI_IO_SPREAD')
            else:
                rf_name.append(x.name)
                orca_rf_name.append(x.name)
        elif tmp_rf_type == 'RfCcyPair20':   #e.g., 120
            rf_name.append('FX.SPOT.'+x.domestic + '/' + x.foreign)
            orca_rf_name.append('FX.SPOT.' + x.domestic + '/' + x.foreign)
        elif tmp_rf_type == 'RfInterestAtmVolatility':  #e.g., 209
            rf_name.append(x.surface_name + '.' + x.tenor +'.'+ x.underlying_tenor)  # lambda name.maturity.tenor
            orca_rf_name.append(x.surface_name)
        else:
            raise NotImplementedError

    rf_df = pd.DataFrame()
    for sim in sc_spec.simulations:
        # for rf from 'TRIM BOND xxx'
        if 'scenarioDate' in sim.extra_data.keys():
            rf_df[sim.extra_data['scenarioDate']] = sim.shifts
        # for rf from 'IRM'
        elif 'scenarioName' in sim.extra_data.keys():
            rf_df[sim.extra_data['scenarioName']] = sim.shifts
        else:
            logging.error("can not extract scenarioDate or scenarioName")
            raise NotImplementedError

    rf_df['RF'] = rf_name
    rf_df['ORCA_RF_NAME'] = orca_rf_name
    rf_df['RF_TYPE'] = rf_type

    return rf_df

def convert_rf_from_scenario_pack_to_dict(sc_spec, value_date):
    """
    convert rf (extracted from scenario spec) to dict

    :param sc_spec: (<class 'scenario_generator.models.scenario_spec.ScenarioSpec'>)
    :return (dict)  key: rf date/id; value: a list of MDO with orca rf name as identifier attribute

    eg:
    sc_spec = extract_rf_from_scenario_pack(pack_id)  #'764dea1f-5e1d-46a7-a297-1d4f6471e9e2'
    rf_dict = convert_rf_from_scenario_pack_to_dict(sc_spec,dt.date(2021, 1, 19))
    """
    rf_df = convert_rf_from_scenario_pack_to_df(sc_spec)

    rf_df.set_index(['ORCA_RF_NAME','RF_TYPE','RF'],inplace=True)
    rf_df.sort_index(inplace= True)
    rf_df.sort_index(axis=1,inplace=True)

    rf_unique = list(set(rf_df.index.get_level_values(0)))
    sc_date_sorted = list(rf_df.columns)
    sc_date_sorted.sort()
    rf_mdo_dict = {k: [] for k in sc_date_sorted}

    for orca_rf_name in rf_unique:
        #orca_rf_name = rf_unique[30]  # test point
        #orca_rf_name = rf_unique[63]  # test surface
        rf_type = rf_df.xs(orca_rf_name, level=0).index.get_level_values(0)[0].split('.')[-1]
        if rf_type in ('RfBondCurveRate', 'RfInterestRate'):
            tenors = [x.split('.')[-1] for x in rf_df.xs(orca_rf_name, level=0).index.get_level_values(1)]
            for tmp_sc_date in sc_date_sorted:
                vals = list(rf_df.xs(orca_rf_name, level=0)[tmp_sc_date])
                tmp_mdo = TermStructure.make(vals=vals,
                                             tenors=tenors,
                                             valuation_date=value_date,
                                             identifier=orca_rf_name)
                rf_mdo_dict[tmp_sc_date].append(tmp_mdo)
        if rf_type in ('RfCcyPair20', 'RfRefinanceRate'):
            for tmp_sc_date in sc_date_sorted:
                vals = rf_df.xs(orca_rf_name, level=0)[tmp_sc_date][0]
                tmp_mdo = Point.make(vals=vals,
                                     valuation_date=value_date,
                                     identifier=orca_rf_name)
                rf_mdo_dict[tmp_sc_date].append(tmp_mdo)
        if rf_type == 'RfInterestAtmVolatility':
            maturities = [x.split('.')[-2] for x in rf_df.xs(orca_rf_name, level=0).index.get_level_values(1)]
            tenors = [x.split('.')[-1] for x in rf_df.xs(orca_rf_name, level=0).index.get_level_values(1)]
            #check = rf_df.xs(orca_rf_name, level=0)[tmp_sc_date]  # tmp_sc_date is '2021-01-18'
            for tmp_sc_date in sc_date_sorted:
                val_tmp = rf_df.xs(orca_rf_name, level=0)[tmp_sc_date]
                val_tmp.index = [maturities, tenors]
                val_tmp_df = val_tmp.unstack()
                tmp_mdo = Surface.make(vals=val_tmp_df,
                                       tenors=val_tmp_df.columns,
                                       maturities=val_tmp_df.index,
                                       valuation_date=value_date,
                                       identifier=orca_rf_name)
                rf_mdo_dict[tmp_sc_date].append(tmp_mdo)
    return rf_mdo_dict

@orca_implicit_client
def extract_rf_for_isin(client, rf, isin_list, value_date):
    """
    from the entire rf set (df or dict), extract a subset of rf which contributed by the bond isin list
    :param client: orca ServiceBundle if nothing is passed, the wrapper generates a conn
    :param rf: (DataFrame or Dict)
            df: rf as row, scenario date/id as col. Additional cols: 'RF':ripl rf name, 'ORCA_RF_NAME': ORCA rf name, 'RF_TYPE':ripl rf type
            can be constructed from convert_rf_from_scenario_pack_to_df
            dict: key: rf date/id; value: a list of MDO with orca rf name as identifier attribute
            can be constructed from convert_rf_from_scenario_pack_to_dict
    :param isin_list: (list)  list of bond isins e.g., ['DK0002044635','DE0001135085','GB0002404191']
    :param value_date: (datetime.date)
    :return (DataFrame or Dict)
            df: rf as row, scenario date as col, additional cols: 'RF':ripl rf name, 'ORCA_RF_NAME': ORCA rf name, 'RF_TYPE':ripl rf type
            dict: key: rf date/id; value: a list of orca scenarios
    e.g.,
    sc_spec = extract_rf_from_scenario_pack(pack_id)  #'764dea1f-5e1d-46a7-a297-1d4f6471e9e2'
    rf_df = convert_rf_from_scenario_pack_to_df(sc_spec)
    isin_list = ['DK0002044635','DE0001135085','GB0002404191','DK0004613262']
    rf_df_tst = extract_rf_for_isin(orca_client,rf_df, isin_list, dt.date(2021, 1, 19))
    rf_dict_tst = extract_rf_for_isin(orca_client,rf_dict, isin_list, dt.date(2021, 1, 19))

    """

    isin_rf_set = risk_factors_from_isins(client,isin_list,value_date, as_labels=True)

    if isinstance(rf, pd.DataFrame):
        rf_isins = rf[rf['ORCA_RF_NAME'].isin(isin_rf_set)]
        return rf_isins
    elif isinstance(rf, dict):
        rf_mdo_dict = {k: [] for k in rf.keys()}
        for key in rf.keys():
            for x in rf[key]:
                if x.identifier in isin_rf_set:
                    rf_mdo_dict[key].append(x)
        return rf_mdo_dict
    else:
        raise NotImplementedError

@orca_implicit_client
def convert_rf_to_orca(client, mdo_list):
    '''
    convert a list of risklib mod type(e.g., curve, point) to a list of orca scenario
    :param client: orca ServiceBundle if nothing is passed, the wrapper generates a conn
    :param mdo_list: list of market data object with orca rf name as identifier
    :return: list of orca scenarios

    eg:
    sc_spec = extract_rf_from_scenario_pack(pack_id)  #'764dea1f-5e1d-46a7-a297-1d4f6471e9e2'
    rf_dict = convert_rf_from_scenario_pack_to_dict(sc_spec,dt.date(2021, 1, 19))
    orca_scenario_ls = convert_rf_to_orca(orca_client,list(rf_dict.values())[0])
    '''
    orca_scenario_ls = []
    for mdo in mdo_list:
        orca_rf = client.request_risk_factor_info([mdo.identifier]).result()
        if any(orca_rf.results):
            if type(mdo) == TermStructure:
                term_dates = [qt.addTenor(mdo.valuation_date, x) for x in mdo.keys]
                curve_shock = qt.CurveLinear.make(dates=term_dates, vals=mdo.data)
                sc_orca = orca.types.Scenario(name=mdo.identifier,
                                              type=orca.types.ScenarioType.ADDITION,
                                              data=curve_shock)
            elif type(mdo) == Point:
                if orca_rf.results._d[mdo.identifier].info['ASSET_CLASS'] =='FX':
                    sc_orca = orca.types.Scenario(name=mdo.identifier,
                                                  type=orca.types.ScenarioType.MULTIPLICATION,
                                                  data=mdo.data)
                elif orca_rf.results._d[mdo.identifier].info['ASSET_CLASS'] == 'DMB':
                    sc_orca = orca.types.Scenario(name=mdo.identifier,
                                                  type=orca.types.ScenarioType.ADDITION,
                                                  data=mdo.data)
                else:
                    raise NotImplementedError
            elif type(mdo) == Surface:
                if orca_rf.results._d[mdo.identifier].info['RISK_TYPE'] == 'LAMBDA':
                    surface_shock = qt.SurfaceDateTenorLinear.make(
                        dates=[qt.addTenor(mdo.valuation_date, x) for x in mdo.data.index],
                        tenors=mdo.data.columns,
                        values=mdo.data.values.tolist())
                    sc_orca = orca.types.Scenario(name=mdo.identifier,
                                                  type=orca.types.ScenarioType.MULTIPLICATION,
                                                  data=surface_shock)
                else:
                    raise NotImplementedError
            else:
                raise NotImplementedError

            orca_scenario_ls.append(sc_orca)

    return orca_scenario_ls

def convert_scenarios_to_orca_df(rf_df,value_date,curve_shock_interpolation_type = CurveInterpolation.CurveLinear):
    """
    convert the rf df to a df
    :param rf_df: (DataFrame)  a df with rf as row, scenario date as col.
            Additional cols: 'RF':ripl rf name, 'ORCA_RF_NAME': ORCA rf name, 'RF_TYPE':ripl rf type
            can be constructed from convert_rf_from_scenario_pack_to_df/extract_rf_for_isin
    :param value_date: (datetime.date)
    :param curve_shock_interpolation_type: (enum.EnumMeta) e.g.,CurveInterpolation.CurveLinear
    :return (pandas.core.frame.DataFrame)  a df of ORCA scenario, with ORCA rf name as index, scenario date as col.
    e.g.,
    pack_id = construct_scenario_pack(ScenarioType.Historical,"TRIM Bond ALL - Historic",api,dt.date(2021, 1, 19))
    sc_spec = extract_rf_from_scenario_pack(pack_id)  #'764dea1f-5e1d-46a7-a297-1d4f6471e9e2'
    rf_df = convert_rf_from_scenario_pack_to_df(sc_spec)
    df_rf_all = convert_rf_to_orca(rf_df,dt.date(2021, 1, 19),CurveInterpolation.CurveLinear)
    """

    orca_value_date = ContextTimeStamp.end_of_day(value_date.year,value_date.month,value_date.day)
    eod = orca_value_date.value_time_stamp
    rf_df.sort_index(axis=1,inplace=True)
    non_date_col_ls = ['RF','ORCA_RF_NAME','RF_TYPE']
    sc_dates = [t for t in rf_df.columns if t not in non_date_col_ls]

    # handle curve rf
    rf_curve = rf_df[(rf_df['RF_TYPE'] == 'RfInterestRate')|(rf_df['RF_TYPE'] == 'RfBondCurveRate')]
    rf_curve['TERM_ID'] = rf_curve['RF'].apply(lambda x: x.split('.')[-1])
    rf_curve['DATE'] = rf_curve['TERM_ID'].apply(lambda x: qt.addTenor(eod, x))
    rf_curve.set_index(['ORCA_RF_NAME','DATE'],inplace=True)
    rf_curve.index.names = ['ORCA_RF_NAME','DATE']
    # to ensure rf shock ordered by curve tenor to be picked up when generating shock curve
    rf_curve.sort_index(inplace=True)


    df_rf_curve = pd.DataFrame(index = rf_curve.index.levels[0],columns=sc_dates)

    for cn in df_rf_curve.index:
        for date0 in df_rf_curve.columns:
            shift = rf_curve.xs(cn)[date0]
            curve_shock = getattr(qt, curve_shock_interpolation_type.name).make(dates=shift.index, vals=shift.values)
            sc_orca = orca.types.Scenario(name=cn,
                                         type=orca.types.ScenarioType.ADDITION,
                                         data=curve_shock)
            df_rf_curve.loc[cn,date0] = sc_orca

    # handle DMB rf
    rf_refi = rf_df[rf_df['RF_TYPE'] == 'RfRefinanceRate']
    rf_refi.set_index('ORCA_RF_NAME', inplace=True)
    df_rf_refi = pd.DataFrame(index = rf_refi.index,columns=sc_dates)

    for cn in df_rf_refi.index:
        for date0 in df_rf_refi.columns:
            shift = rf_refi.loc[cn,date0]
            sc_orca = orca.types.Scenario(name=cn,
                                         type=orca.types.ScenarioType.ADDITION,
                                         data=shift)
            df_rf_refi.loc[cn][date0] = sc_orca

    # handle fx rf
    rf_fx = rf_df[rf_df['RF_TYPE'] == 'RfCcyPair20']
    rf_fx.set_index('ORCA_RF_NAME', inplace=True)
    df_rf_fx = pd.DataFrame(index=rf_fx.index, columns=sc_dates)

    for cn in df_rf_fx.index:
        for date0 in df_rf_fx.columns:
            shift = rf_fx.loc[cn, date0]
            sc_orca = orca.types.Scenario(name=cn,
                                          type=orca.types.ScenarioType.MULTIPLICATION,
                                          data=shift)
            df_rf_fx.loc[cn][date0] = sc_orca

    # handle surface rf

    rf_surface = rf_df[(rf_df['RF_TYPE'] == 'RfInterestAtmVolatility')]
    rf_surface['MATURITY'] = rf_surface['RF'].apply(lambda x: x.split('.')[-2])
    rf_surface['TENOR'] = rf_surface['RF'].apply(lambda x: x.split('.')[-1])
    rf_surface['CURRENCY'] = rf_surface['RF'].apply(lambda x: x.split('.')[-3])

    rf_surface.set_index(['ORCA_RF_NAME', 'MATURITY', 'TENOR'], inplace=True)
    df_rf_surface = pd.DataFrame(index=rf_surface.index.levels[0], columns=sc_dates)
    tenors = date_helper.sort_tenors(set(rf_surface['TENOR']))
    maturities = date_helper.sort_tenors(set(rf_surface['MATURITY']))

    for cn in df_rf_surface.index:
        for date0 in sc_dates:
            tmp_df_date0 = rf_surface.xs(cn)[date0]
            tmp_ls = []
            for i in maturities:
                tmp_ls.append([tmp_df_date0.xs([i,j]) for j in tenors])

            surface_shock = qt.SurfaceDateTenorLinear.make(
                dates=[qt.addTenor(eod, x) for x in maturities],
                tenors=tenors,
                values=tmp_ls)

            sc_orca = orca.types.Scenario(name=cn,
                                          type=orca.types.ScenarioType.MULTIPLICATION,
                                          data=surface_shock)
            df_rf_surface.loc[cn, date0] = sc_orca

    df_rf_all = df_rf_curve.append(df_rf_refi).append(df_rf_surface).append(df_rf_fx)

    return df_rf_all

def convert_scenarios_to_orca_dict(client,rf_dict):
    '''

    :param rf_dict: a dict. Key: scenario date/id. Value: list of market data object with orca rf name as identifier
    :return: a dict. Key: scenario date/id. Value: list of orca with orca rf name as identifier
    e.g., orca_rf_dict = convert_scenarios_to_orca_dict(rf_dict)
    '''

    orca_rf_dict = {k: convert_rf_to_orca(client,rf_dict[k]) for k in rf_dict.keys()}
    return orca_rf_dict

if __name__ == '__main__':


    ext_envir.update(ext_envir.ORCA.uat)
    ext_envir.update(ext_envir.ScenarioEngine.prod)
    orca_client = orca_connect.client_factory()
    ripl_client = ripl.client_factory()

    # inputs
    isin_list = [
        'DE0001135085',
        'ES00000124C5',
        'PTPBTBGE0055',
        'GB0002404191']
    value_date = dt.date(2021, 1, 19)
    scenario_name = "TRIM Bond CS - IRM"  # TRIM Bond ALL - Stressed  or  TRIM Bond ALL - Historic
    scenario_type = ScenarioCategory.Deterministic

    # sc_pack extraction, rf extraction and converting to ORCA scenarios

    pack_id = construct_scenario_pack(client=ripl_client, scenario_name=scenario_name,scenario_type=scenario_type,
                                      value_date=value_date)
    sc_spec = extract_rf_from_scenario_pack(client=ripl_client, pack_id=pack_id)
    dict_test = convert_rf_from_scenario_pack_to_dict(sc_spec=sc_spec, value_date=value_date)
    dict_isin_test = extract_rf_for_isin(client=orca_client, rf=dict_test, isin_list=isin_list, value_date=value_date)
    dict_sc_test = convert_scenarios_to_orca_dict(client=orca_client, rf_dict=dict_isin_test)
    print(list[dict_sc_test.items()][:2])




