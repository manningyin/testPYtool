"""
Module for risk factor collection class.

Notes:
    Author: JBrandt (g50444)

"""
import copy
import inspect
from collections import defaultdict
import datetime as dt
import pandas as pd
from core.connection import api
from core.risk_factor import rfr_controller
from core.risk_factor import rfr_extract
from core.risk_factor import risk_factor_utils
from core.risk_factor.factory import risk_factor_domain
from core.system import ext_envir, dependency
from core.utils import date_helper
from core.utils import dict_helper
from core.utils import list_helper
from core.utils import string_utils as string

DEFAULT_MD_MAPPING_HIERARCHY = [
    ext_envir.MARS.INFOP,
    ext_envir.MARS.INFO3D,
    ext_envir.MARS.INFOBT,
    ext_envir.MARS.INFOT,
    ext_envir.MDHub.int,
    ext_envir.DAMD.DAMDS,
]


class RiskFactorCollection(object):
    """
    Container for risk factors with basic functionality.

    Individual risk factors are located in self.risk_factor_list

    Args:
        risk_factors    (list):     OPTIONAL. Instance can be initiated with manually added risk factors.
        as_of_date      (date):     Date used as as-of-date and eod_date in various connections to external databases
                                    and services.

    Notes:
        Author: JBrandt (g50444)
    """

    def __init__(self, risk_factors=None, as_of_date=None):
        """
        Initiating the risk factor collection instance. Can be created based on list of risk factors, or as empty.

        Notes:
            Author: JBrandt (g50444)
        """
        required_version = '1.5.dev5'
        if not dependency.rfr_dependency(required_version):
            err_str = "You must upgrade to RFR version %s or newer to run latest version of risk factor factory" % required_version
            raise ImportError(err_str)
        self.risk_factor_list = []
        self._label_criteria = []
        self._removed_duplicates = {}
        self._md_mapping_hierarchy = DEFAULT_MD_MAPPING_HIERARCHY

        # If no date is chosen, we use a default date
        self.as_of_date = as_of_date or date_helper.yesterday_as_bdate()

        if risk_factors is not None and len(risk_factors) > 0:
            # If initiated with risk factors, we add these.
            self.add_risk_factor_list(risk_factors)

    def __add__(self, other):
        """
        Overriding method for easy adding risk factors or risk factor collection to an existing collection.

        Args:
            other    (RiskFactorCollection or list):    Risk factors to add to existing risk factor collection

        Returns:
            (RiskFactorCollection): New instance of RiskFactorCollection

        Example:
            Testable example adding two collections together:

                >>> from core.risk_factor.collection import RiskFactorCollection
                >>> import datetime as dt
                >>> some_rf = [dict(foreign = 'USD', domestic = 'EUR'), dict(foreign = 'GBP', domestic = 'EUR')]
                >>> other_rf = [dict(foreign = 'DKK', domestic = 'EUR')]
                >>> collection_a = RiskFactorCollection(as_of_date = dt.date(1992, 6, 26), risk_factors = some_rf)
                Added 2 risk factors to collection.
                >>> collection_b = RiskFactorCollection(as_of_date = dt.date(2018, 6, 26), risk_factors = other_rf)
                Added 1 risk factor to collection.
                >>> my_new_collection = collection_a + collection_b
                Added 1 risk factor to collection.
                >>> # Making sure that dates are deep copied from left object (without changing the right object)
                >>> my_new_collection.as_of_date
                datetime.date(1992, 6, 26)
                >>> collection_a.as_of_date
                datetime.date(1992, 6, 26)
                >>> collection_b.as_of_date
                datetime.date(2018, 6, 26)
                >>> # Making sure that risk factors are added only in the new object, and not in any of the old objects
                >>> len(my_new_collection)
                3
                >>> len(collection_a)
                2
                >>> len(collection_b)
                1

            Testable example adding a list to a collection:

                >>> from core.risk_factor.collection import RiskFactorCollection
                >>> import datetime as dt
                >>> some_rf = [dict(foreign = 'USD', domestic = 'EUR'), dict(foreign = 'GBP', domestic = 'EUR')]
                >>> other_rf = [dict(foreign = 'DKK', domestic = 'EUR')]
                >>> collection_a = RiskFactorCollection(as_of_date = dt.date(1992, 6, 26), risk_factors = some_rf)
                Added 2 risk factors to collection.
                >>> my_new_collection = collection_a + other_rf
                Added 1 risk factor to collection.
                >>> len(my_new_collection)
                3
                >>> len(collection_a)
                2

        Notes:
            Author: JBrandt (g50444)
        """

        if isinstance(other, RiskFactorCollection):
            risk_factors_list_to_add = other.risk_factor_list
        elif isinstance(other, list):
            risk_factors_list_to_add = other
        else:
            raise NotImplementedError("Usage is not supported!")

        # ===================================================================================
        # We could use "copy.deepcopy(self)" below since __deepcopy__ has been overloaded,
        # but uses the operator method directory to make it easier to see what's going on.
        # ===================================================================================
        new_collection = self.__deepcopy__(self)
        new_collection.add_risk_factor_list(risk_factors_list_to_add)

        return new_collection

    def __deepcopy__(self, memodict = {}):
        """
        Overriding deepcopy method for copying instance.

        The method loop does a deep copy of elements in "this" instance to the new one.

        Using the copy.deepcopy() function directly causes problems due to use of __getattr__ in the RiskFactor objects.
        The use of deepcopy directly on self.__dict__ causes problems for Pycharm. This method works.

        Args:
            memodict    (dict):     Default parameter in the deepcopy function. Not used by overriding method.

        Returns:
            (RiskFactorCollection): Deep copy of self instance.

        Notes:
            Author: JBrandt (g50444)
        """

        new_collection = RiskFactorCollection()
        for key, value in self.__dict__.items():
            try:
                new_collection.__dict__[key] = value.copy()   # dicts, sets
            except AttributeError:
                try:
                    new_collection.__dict__[key] = value[:]   # lists, tuples, strings, unicode
                except TypeError:
                    new_collection.__dict__[key] = value      # ints, date
        return new_collection

    def __deep_copy_instance_without_risk_factors(self, risk_factors = []):
        """
        Makes a deep copy of class instance, WITHOUT risk factors from old collection.

        If risk factors are added as input argument, the new instance will contain these risk factors (ONLY)

        Args:
            risk_factors    (list):     OPTIONAL! Risk factors that should be added to the new instance.

        Returns:
            (RiskFactorCollection): New instance of the object - with all attributes, but no risk factors

        Notes:
            Author: JBrandt (g50444)
        """

        new_collection = copy.deepcopy(self)
        new_collection._clear_risk_factors()
        if risk_factors is not None and risk_factors is not []:
            new_collection.add_risk_factor_list(risk_factors)

        return new_collection

    def __eq__(self, other):
        """
        Operator for easy comparision. When comparing to list, only list part is compared.

        Notes:
            Author: JBrandt (g50444)
        """
        if isinstance(other, list):
            return self.risk_factor_list == other
        else:
            return self == other

    def __iter__(self):
        """
        Operator for iterating over class. Acts as if iterating over self.risk_factor_list

        Notes:
            Author: JBrandt (g50444)
        """
        for risk_factor in self.risk_factor_list:
            yield risk_factor

    def __label_filter_apply(self, label_criteria_and = None, label_criteria_or = None):
        """
        Removing risk factors from collection which does match specific label.

        Args:
            label_criteria_and  (list of Labels or dicts):  Risk factors which does not match all of these labels will
                                                            be deleted.
            label_criteria_or   (list of Labels or dicts):  Risk factors which does not match one of these labels will
                                                            be deleted.

        Returns:
            (RiskFactorCollection): New instance of the object - only containing selected risk factors.

        Notes:
            Author: JBrandt (g50444)
        """

        keep_risk_factors = []
        for risk_factor in self.risk_factor_list:
            if risk_factor.has_labels(and_labels=label_criteria_and, or_labels=label_criteria_or):
                keep_risk_factors.append(risk_factor)

        removed_count = self._risk_factor_count - len(keep_risk_factors)
        if removed_count == 0:
            print("All risk factors matches label filter. No risk factors removed.")
        else:
            print("By applying labels " + str(removed_count)
                  + " risk factors were removed. "
                  + str(len(keep_risk_factors)) + " risk factors remaining.")

        self.risk_factor_list = keep_risk_factors
        return self

    def __len__(self):
        """
        Overriding operator so len() statement can be used. It returns tne number  of risk factors in the collection.

        Returns:
            (int): Number of risk factors in the collection.

        Notes:
            Author: JBrandt (g50444)
        """
        return self._risk_factor_count

    def __md_mapping_apply(self, risk_factors):
        """
        Overwrite the risk factors market data mapping, based on the defined md mapping hieararhy in instance.

        The method does not "just" update the self.risk_factor_list, to make it possible to apply the changes
        only to risk factor added to a class instance (for performance reasons - which might just be theoretical)

        Args:
            risk_factors (list):    Risk factors for which md mapping should be updated.
                                    This can be self-risk_factor_list, but also other risk factors.

        Notes:
            Author: JBrandt (g50444)
        """

        for risk_factor in risk_factors:
            risk_factor.mdmapping = risk_factor.get_source_mapping(md_map_hierarchy=self._md_mapping_hierarchy)

    def __remove_duplicates(self):
        """
        Removes duplicate risk factors from risk factor collection list

        Notes:
            Author: JBrandt (g50444)
        """

        risk_factors_before_count = self._risk_factor_count
        distinct_and_duplicates = list_helper.distinct_objects(self.risk_factor_list)
        self.risk_factor_list = distinct_and_duplicates['distinct']

        duplicates_removed = risk_factors_before_count - self._risk_factor_count

        if duplicates_removed > 0:
            removed_risk_factors = distinct_and_duplicates['duplicates']

            for i in range(0, 5):
                # If method is run several times within same second, we need to add a "counter" to make the key unique.
                now_str = date_helper.now_as_str() + "-" + str(i)
                if now_str not in self._removed_duplicates.keys():
                    self._removed_duplicates[now_str] = removed_risk_factors
                    break

            if now_str not in self._removed_duplicates.keys():
                raise Exception("Not able to add information about removed duplicates to self._removed_duplicates."
                                + " Last key attempted: " + now_str)

            print("Removed " + str(duplicates_removed) + " duplicating risk factors. "
                  + "See self._removed_duplicates['" + now_str + "'] for details. \n"
                  + "Risk factors in collection are now (again) uniquely defined.")

        return self

    def __repr__(self):
        """
        Operator for representing object content.

        Notes:
            Author: JBrandt (g50444)
        """
        out_str = ''
        for risk_factor in self:
            out_str += str(risk_factor) + '\n'
        return out_str

    def __rsub__(self, other):
        """
        Operator for RIGHT side subtraction: <list or RiskFactorCollection> - self

        More information - see: _substraction

        Notes:
            Author: JBrandt (g50444)
        """

        new_collection = self.__subtraction(other = other, subtract_type = 'right')
        return new_collection

    def __str__(self):
        """
        Operator for string representation of object content.

        Notes:
            Author: JBrandt (g50444)
        """
        out_str = '['
        for risk_factor in self:
            out_str += str(risk_factor) + ','
        return out_str + ']'

    def __sub__(self, other):
        """
        Operator for left side subtraction: self - <list or RiskFactorCollection>

        More information - see: _substraction

        Notes:
            Author: JBrandt (g50444)
        """

        new_collection = self.__subtraction(other = other, subtract_type = 'left')
        return new_collection

    def __subtraction(self, other, subtract_type ='left'):
        """
        Performing subtraction between self and risk factor collection object OR list.

        This method should not be used directly. Use normal operates "-" which will direct to use
        of __sub__ or __rsub__.

        Args:
            other   (RiskFactorCollection or list): Risk factors that should be subtracted (from)

        Returns:
            (RiskFactorCollection): Collection containing risk factors which are in the "left" object, and not the right

        Notes:
            Author: JBrandt (g50444)
        """
        if isinstance(other, RiskFactorCollection):
            risk_factors_list_to_sub = other.risk_factor_list
        elif isinstance(other, list):
            # Putting list of risk factors "through" the RiskFactorCollection in order to get validations etc.
            risk_factors_list_to_sub = RiskFactorCollection(risk_factors = other).risk_factor_list
        else:
            raise NotImplementedError("Usage is not supported!")

        def rf_to_str(risk_factor_list):
            """
            Translating list of risk factor objects into list of dict of following structure:
                - key: risk factor dicts as string
                - value: risk factor object
            """
            rf_to_str_map = {}
            for own_risk_factor in risk_factor_list:
                rf_as_str = string.dict_to_ordered_string(own_risk_factor.riskfactor)
                rf_to_str_map[rf_as_str] = own_risk_factor
            return rf_to_str_map

        own_rf = rf_to_str(self.risk_factor_list)
        other_rf = rf_to_str(risk_factors_list_to_sub)

        if subtract_type == 'left':
            missing_rf_as_str = list(set(own_rf.keys()) - set(other_rf.keys()))
            missing_risk_factors = [rf_obj for rf_str, rf_obj in own_rf.items() if rf_str in missing_rf_as_str]

        elif subtract_type == 'right':
            missing_rf_as_str = list(set(other_rf.keys()) - set(own_rf.keys()))
            missing_risk_factors = [rf_obj for rf_str, rf_obj in other_rf.items() if rf_str in missing_rf_as_str]

        else:
            raise KeyError('Subtraction type ("' + str(subtract_type) + '") is not supported!')

        new_collection = self.__deep_copy_instance_without_risk_factors(risk_factors = missing_risk_factors)

        return new_collection

    def __validate_no_duplicating_shortnames(self):
        """
        Validating that risk factors as uniquely defined short names. Raises an exception if duplicates are found.

        Notes:
            Author: JBrandt (g50444)
        """

        risk_factor_utils.duplicate_shortnames(self.risk_factor_list)

    def _clear_risk_factors(self):
        """
        Clearing / removing all risk factors from instance.

        Notes:
            Author: JBrandt (g50444)
        """

        self.risk_factor_list = []

    def _default_PI(self, risk_factor_label_name):
        """
        Default risk factors and mappings

        Example:
            The module is called (from python) like this::

                my_rf_collection = RiskFactorCollection().default()

        Notes:
            Author: JBrandt (g50444)
        """

        risk_factor_criteria = [
            risk_factor_utils.Label(group = 'master', name = risk_factor_label_name, values=True),
            risk_factor_utils.Label(group = 'master', name = 'model_coverage', values=True),
        ]

        self.as_of_date = dt.date(2018, 5, 18)

        self.add_risk_factors_from_factories()
        self.filter_keep(label_criteria_and = risk_factor_criteria)

        return self

    @property
    def _risk_factor_count(self):
        """
        Returns the number of risk factors currently in the collection.

        Returns:
            (int): Number of risk factors currently in the collection.

        Notes:
            Author: JBrandt (g50444)
        """

        return len(self.risk_factor_list)

    def add_risk_factor_list(self, *args):
        """
        Add risk factor objects to the existing risk factor list.

        This method both updates the instance itself, and returns a new instance.

        Args:
            *args   (list): Lists of risk factor objects to be "manually" added

        Returns:
            (RiskFactorCollection): Returns a new instance of it self. Method can therefore be used as part of creation.

        Example:
            Since method returns a new instance it can be used like this::

                my_collection = RiskFactorCollection().add_risk_factors(<risk factors>)

        Notes:
            Author: JBrandt (g50444)
        """
        total_number_of_risk_factors_to_add = 0

        # ===================================================================================
        # Method supports several lists as input. We loop to handle them individually
        # ===================================================================================
        for risk_factors_raw in args:
            # ===================================================================================
            # We expect input to be a list of risk factors, or an individual risk factor (dict)
            # ===================================================================================
            if isinstance(risk_factors_raw, dict):
                risk_factors = list_helper.to_list(risk_factors_raw)
            else:
                if not isinstance(risk_factors_raw, list):
                    raise TypeError("Expected risk factors as list. Got: " + str(type(risk_factors)))

                risk_factors = risk_factors_raw

            # Just counting - how much are we inserting (in this loop and in total)...
            number_of_risk_factors_to_add = len(risk_factors)
            total_number_of_risk_factors_to_add += number_of_risk_factors_to_add

            if number_of_risk_factors_to_add > 0:
                # If list of risk factors is empty, there is nothing to do here...
                if isinstance(risk_factors[0], dict):
                    # ===================================================================================
                    # We support adding of avro (dict) type risk factors.
                    # We convert these to risk factor objects.
                    # ===================================================================================
                    #risk_factor_objects = risk_factors
                    risk_factor_objects = risk_factor_utils.rf_object_from_avro(risk_factors)
                else:
                    # We assume that (ALL) risk factors are already risk factor objects.
                    risk_factor_objects = risk_factors

                self.__md_mapping_apply(risk_factor_objects)
                self.risk_factor_list += risk_factor_objects

        if total_number_of_risk_factors_to_add == 1:
            print("Added " + str(total_number_of_risk_factors_to_add) + " risk factor to collection.")
        else:
            print("Added " + str(total_number_of_risk_factors_to_add) + " risk factors to collection.")

        self.__remove_duplicates()
        self.__validate_no_duplicating_shortnames()
        return self

    def add_risk_factors_from_factories(self, risk_factor_types = None):
        """
        Adding all "known" risk factors (no filtering on labels) for all or chosen risk factor types.

        Returns:
            (RiskFactorCollection): Returns a new instance of it self. Method can therefore be used as part of creation.

        Notes:
            Author: JBrandt (g50444)
        """

        from core.position import position_service
        as_of_date = self.as_of_date

        # ===================================================================================
        # Getting (unique) list of references to generating functions.
        # This is risk type specific functions that return risk factors.
        # Some of the factory functions takes input arguments. These should be very
        # standard, and are listed in the "supported_arguments" below.
        # ===================================================================================
        if risk_factor_types is None:
            factory_functions = list(set(
                                    [rf_type.risk_factor_factory for rf_type in risk_factor_domain.RiskFactorType]
                                    ))
        else:
            factory_functions = list(set(
                                    [rf_type.risk_factor_factory for rf_type in list_helper.to_list(risk_factor_types)]
                                    ))

        supported_arguments = ['positions', 'as_of_date']

        # ===================================================================================
        # Looping over the factory functions, calling them with input arguments and
        # collecting risk factors returned.
        # ===================================================================================
        factory_risk_factors = []
        print("Generating risk factors from factory functions...")
        for type_specific_factory in factory_functions:
            # ===================================================================================
            # Determining which input arguments the factory function takes.
            # - If they are "supported" in this function, we will use them in the call
            # ===================================================================================
            factory_arguments = list(inspect.signature(type_specific_factory).parameters.keys())
            factory_argument_dict = {}
            for arg in supported_arguments:
                if arg in factory_arguments:
                    if arg == 'positions' and arg not in locals():
                        # ===================================================================================
                        # We only want to get the positions once - and only if is required.
                        # We therefore only get the positions if there is not already a local "position"
                        # variable present.
                        # ===================================================================================
                        positions_as_dict = position_service.PI_coverage_positions(as_of_date)
                        positions = [pos for pos in positions_as_dict]

                    factory_argument_dict[arg] = eval(arg)

            # Actually calling risk factor factory function.
            type_specific_risk_factors = type_specific_factory(**factory_argument_dict)
            factory_risk_factors += type_specific_risk_factors

        # ===================================================================================
        # Some generating functions can return risk factors of different types.
        # We remove the ones not chosen by calling user / function
        # ===================================================================================
        if risk_factor_types is None:
            risk_factors_of_chosen_type = factory_risk_factors
        else:
            risk_factors_of_chosen_type = []
            for rf in factory_risk_factors:
                if rf.RISK_FACTOR_TYPE in list_helper.to_list(risk_factor_types):
                    risk_factors_of_chosen_type.append(rf)

        self.add_risk_factor_list(risk_factors_of_chosen_type)
        print('here without issue ')
        return self

    def default_PI_pricing_factors(self):
        """
        Default risk factors and mappings for PRICING FACTORS needed for current PI coverage

        Example:
            The module is called (from python) like this::

                my_rf_collection = RiskFactorCollection().PI_default_risk_factors()

        Notes:
            Author: JBrandt (g50444)
        """

        return self._default_PI('zero_coupon')

    def default_PI_risk_factors(self):
        """
        Default risk factors and mappings for RISK FACTORS needed for current PI coverage

        Example:
            The module is called (from python) like this::

                my_rf_collection = RiskFactorCollection().PI_default_risk_factors()

        Notes:
            Author: JBrandt (g50444)
        """

        return self._default_PI('risk_factor')

    def filter_keep(self, label_criteria_and = None, label_criteria_or = None):
        """
        Adding filter on risk factors, based on labels. Risk factors not matching filter will be deleted.

        Args:
            label_criteria_and  (list of Labels or dicts):  Risk factors which does not match all of these labels will
                                                            be deleted.
            label_criteria_or   (list of Labels or dicts):  Risk factors which does not match one of these labels will
                                                            be deleted.

        Returns:
            (RiskFactorCollection): New instance of the object - only containing selected risk factors.

        Notes:
            Author: JBrandt (g50444)
        """

        self._label_criteria += dict(label_criteria_and = label_criteria_and,
                                     label_criteria_or = label_criteria_or
                                     )
        self.__label_filter_apply(label_criteria_and = label_criteria_and,
                                  label_criteria_or = label_criteria_or)
        return self

    def filter_remove(self, label):
        """
        Removing risk factors that matches specific label.

        Args:
            label    (risk_factor_utils.Label or dict): Label criteria. Risk factor with this label will be deleted.

        Returns:
            (RiskFactorCollection): Returns a new instance of it self. Method can therefore be used as part of creation.

        Example:
            Since method returns a new instance it can be used like this::

                my_collection = RiskFactorCollection().filter_remove(
                                                                    dict(   group   = master,
                                                                            name    = model_coverage,
                                                                            )
                                                                    )

        Notes:
            Author: JBrandt (g50444)
        """
        label_obj = risk_factor_utils.label_obj(label)

        risk_factors_to_keep = []
        for risk_factor in self.risk_factor_list:
            if risk_factor.has_label(label_as_obj=label_obj) is False:
                risk_factors_to_keep.append(risk_factor)

        removed_count = self._risk_factor_count - len(risk_factors_to_keep)
        if removed_count == 0:
            print("No risk factors matches label filter. No risk factors removed.")
        else:
            print("By applying remove filter " + str(removed_count)
                  + " risk factors were removed. "
                  + str(len(risk_factors_to_keep)) + " risk factors remaining.")

        self.risk_factor_list = risk_factors_to_keep
        return self

    def filter_on_key_value_keep(self, key_value_pairs):
        """
        Returns a collection with all risk factors with specific key: value pair. That could be ISIN = SE0004869071

        Args:
            key_value_pairs (dict): Key-value pairs that risk factors (avro definition) need to match.

        Returns:
            (RiskFactorCollection): New collection with matching risk factors

        Example:
            Getting risk factors with specific ISIN:

                >>> from core.risk_factor.collection import RiskFactorCollection
                >>> initial_risk_factors = [
                ...     dict(foreign = 'USD', domestic = 'EUR'),
                ...     dict(foreign = 'JPY', domestic = 'EUR'),
                ...     dict(curve_name = 'NO.CURVE', ISIN = 'NO0010732555'),
                ...     dict(curve_name = 'NO.CURVE', ISIN = 'NO0010786288'),
                ...     dict(curve_name = 'SE.CURVE', ISIN = 'SE0004869071'),
                ... ]
                >>> initial_collection = RiskFactorCollection(risk_factors = initial_risk_factors)
                Added 5 risk factors to collection.
                >>> matching_col = initial_collection.filter_on_key_value_keep(dict(ISIN = 'SE0004869071'))
                Added 1 risk factor to collection.
                >>> len(matching_col)
                1
                >>> matching_col.risk_factor_list[0].riskfactor['ISIN']
                'SE0004869071'

        Notes:
            Author: JBrandt (g50444)
        """

        matching_rf = []
        for rf in self.risk_factor_list:
            for filter_key, filter_value in key_value_pairs.items():
                if filter_key in rf.riskfactor.keys():
                    if rf.riskfactor[filter_key] == filter_value:
                        matching_rf.append(rf)

        new_collection = self.__deep_copy_instance_without_risk_factors(risk_factors = matching_rf)

        return new_collection

    def grouped_by_types(self):
        """
        Getting risk factors in collection as a dictionary of collections where the key is the risk factor type.

        Returns:
            (dict): key: RiskFactorType, value: RiskFactorCollection

        Notes:
            Author: JBrandt
        """

        # Creating empty dictionary where values defaults to lists - so we can easily append elements to them.
        risk_factors_by_type = defaultdict(list)

        # ===================================================================================
        # Lopping over each risk factor, and adding it to the list (in the dictionary)
        # corresponding to it's type.
        # Then transforming all the lists to RiskFactorCollection objects.
        # ===================================================================================
        for rf in self.risk_factor_list:
            risk_factors_by_type[rf.RISK_FACTOR_TYPE].append(rf)

        collections_by_type = {}
        for rf_type, rf_list in risk_factors_by_type.items():
            collections_by_type[rf_type] = RiskFactorCollection(risk_factors = rf_list, as_of_date = self.as_of_date)

        return collections_by_type

    def label_add_to_risk_factors(self, label):
        """
        Adding label to ALL risk factors in collection.

        Args:
            label (list of Label):  Labels that should be added to all risk factors. As Label object or dicts with
                                    the keys: group, name, value.

        Returns:
            (RiskFactorCollection): New instance of RiskFactorCollection

        Notes:
            Author: JBrandt (g50444)
        """

        for lb in list_helper.to_list(label):
            # Looping over all labels, translating them into real label objects (if they are input as dicts)
            lb_obj = risk_factor_utils.label_obj(lb)
            for risk_factor in self.risk_factor_list:
                risk_factor.add_label(group = lb_obj.group,
                                      name = lb_obj.name,
                                      value = lb_obj.value,
                                      )
        return self

    def label_delete_from_risk_factors(self, label):
        """
        Deleting label from all risk factors in collection.

        Args:
            label (list of Label):  Labels that should be deleted from all risk factors. As Label object or dicts with
                                    the keys: group, name.

        Returns:
            (RiskFactorCollection): New instance of RiskFactorCollection

        Notes:
            Author: JBrandt (g50444)
        """

        for lb in list_helper.to_list(label):
            # Looping over all labels, translating them into real label objects (if they are input as dicts)
            lb_obj = risk_factor_utils.label_obj(lb)
            for risk_factor in self.risk_factor_list:
                risk_factor.delete_label(group = lb_obj.group, name = lb_obj.name)

        return self

    def md_mapping_update(self, md_mapping_hierarchy = None):
        """
        Update market data mapping for ALL risk factors in risk factor collection.

        This method both updates the instance itself, and returns a new instance.

        Args:
            md_mapping_hierarchy    (list): Prioritized list of market data source, as objects from core.system.ext_envir

        Returns:
            (RiskFactorCollection): New instance of RiskFactorCollection

        Notes:
            Author: JBrandt (g50444)
        """
        print("Market data mappings have been updated with provided hierarchy")
        if md_mapping_hierarchy is not None:
            self._md_mapping_hierarchy = md_mapping_hierarchy

        if self._md_mapping_hierarchy is None:
            raise Exception("No md mapping hierarchy chosen (nor now or previously). Please apply hierarchy.")

        self.__md_mapping_apply(self.risk_factor_list)
        return self

    def update_metadata(self):
        short_names = [x.metadata['short_name'] for x in self.risk_factor_list]
        #metadata = rfr_extract.rfr_load_all_metadata()
        from risklib.connection.ripl import ext_envir
        from ripl_core.authentication import create_sso_config
        from ripl_core import RiplClient
        config = create_sso_config("prod")
        client = RiplClient(**config)
        ext_envir.RIPL.prod.activate()
        metadata = client.risk_factor_repository.risk_factor_meta_data.get_all_risk_factor_meta_data()
        meta_filter = list(filter(lambda y: y.short_name in short_names, metadata))

        for rf in self.risk_factor_list:
            short_name = rf.metadata['short_name']
            try:
                rf.metadata = next(x for x in meta_filter if x.short_name == short_name).to_dict()
            except StopIteration:
                pass

    def rfr_load_all_rfs(self):
        risk_factors = rfr_extract.load_all_risk_factors()
        self.add_risk_factor_list(risk_factors)
        self.update_metadata()
        return self

    def rfr_load_from_context(self, context_name):
        """
        Adding all risk factors that exist in a specific context in risk factor repository.

        Note that only the risk factor definitions (avro) are loaded from RFR.
        Meta data and market data mapping is generated by code-lib risk factor objects.

        Args:
            context_name (str): Name of a context in Risk Factor Repository

        Returns:
            (RiskFactorCollection): New instance of RiskFactorCollection

        Notes:
            Author: JBrandt (g50444)
        """
        risk_factors = rfr_extract.risk_factors_from_context(context_name=context_name)
        self.add_risk_factor_list(risk_factors)
        self.update_metadata()
        print("Market data mappings have been created using default mappings in code-lib")
        return self

    def rfr_load_from_md_map_context(self, md_context_name):
        """
        Loading all risk factors from a specific MARKET DATA MAPPING context in risk factor repository

        Note that only the risk factor definitions (avro) are loaded from RFR.
        Meta data and market data mapping is generated by code-lib risk factor objects.

        Args:
            md_context_name (str): Name of a MARKET DATA MAPPING context in Risk Factor Repository

        Returns:
            (RiskFactorCollection): New instance of RiskFactorCollection

        Notes:
            Author: JBrandt (g50444)
        """
        md_context_raw = api.risk_factor_repository_api().marketdatacontext.get_by_name_md_context(md_context_name)
        md_context = md_context_raw.to_dict()['mappings']
        risk_factors_in_context = [x['risk_factor'] for x in md_context]
        self.add_risk_factor_list(risk_factors_in_context)
        self.update_metadata()

        for rf in self.risk_factor_list:
            short_name = rf.metadata['short_name']
            try:
                md_mapping = next(x['source_market_data_id'] for x in md_context if x['risk_factor_identifier']['short_name'] == short_name)
                rf.mdmapping = md_mapping
            except StopIteration:
                rf.mdmapping = dict()

        return self

    def rfr_upload_market_data_mappings(self, md_context_name, override=True):
        """
        Uploads risk factors market data mapping to risk factor repository - replacing existing context.

        Args:
            md_context_name     (str):      Name of the context that should be created, modified

        Notes:
            Author: JBrandt (g50444)
        """

        rfr_controller.replace_rf_market_data_mapping_in_rfr(risk_factors=self.risk_factor_list,
                                                             context_name=md_context_name,
                                                             override=override
                                                             )

    def rfr_upsert(self):
        """
        Upserts (inserts or updates) all risk factors in collection in Risk Factor Repository.

        This includes risk factor definition (dictionary matching avro definition) and meta data (names, description
        and labels).

        Notes:
            Author: JBrandt (g50444)
        """
        rfr_controller.upsert_risk_factors(self.risk_factor_list)
        print("Inserted " + str(self._risk_factor_count) + " risk factors to Risk Factor Repository "
              + ext_envir.get()['RiskFactorRepository'] + " environment.")

    def to_dataframe(self):
        """
        Transforms all risk factor + meta data + market data mapping in collection into a dataframe.

        Note that sub-structures such as labels will be written in the same cell.

        Returns:
            (dataframe):   Most relevant information about the collection's risk factors in a dataframe

        Notes:
            Author: JBrandt (g50444)
        """
        all_risk_factors = self.risk_factor_list
        list_of_merged_risk_factors = []
        for rf in all_risk_factors:
            # ===================================================================================
            # Creating dictionary containing both risk factor instance, meta-data and market
            # data mapping.
            # Including the avro specification as dictionary so the excel data can be used as
            # examples of object structure.
            # ===================================================================================
            avro_dict = {'avro': rf.rfr_dict()}
            merged_dict = dict_helper.merge_dicts(avro_dict,
                                                  risk_factor_domain.rfr_to_dict(rf.riskfactor),
                                                  risk_factor_domain.rfr_to_dict(rf.metadata),
                                                  risk_factor_domain.rfr_to_dict(rf.mdmapping),
                                                  )
            list_of_merged_risk_factors.append(merged_dict)

        df = pd.DataFrame(list_of_merged_risk_factors)
        return df

    def to_excel(self, path):
        """
        Outputs all risk factors + meta data + market data mapping to a sheet in an excel workbook.

        The sheets will take name after the risk factor types (Class).

        Workbook - not replaced:
        If excel workbook already exist, a sheet will be added to it (workbook not replaced).

        Sheet - replaced.
        If a sheet matching the name of the risk factor type already exists in the workbook, it WILL be replaced

        Args:
            path    (str):  Full path of the destination excel file (including file extension - .xlsx)

        Returns:
            (None):     Nothing is returned. Data is written to an excel file.

        Example:
            The module is called (from python) like this::

                my_risk_factor_collection.to_excel('h;/my_risk_factors.xlsx')


        Warning:
            Existing workbook is not replaced. But - existing sheets with same name ARE replaced.

        Notes:
            Author: JBrandt (g50444)
        """
        from core.utils import dataframe_helper

        grouped_by_types = self.grouped_by_types()

        for rf_type, rf_collection in grouped_by_types.items():
            sheet_name = rf_type.name

            dataframe_helper.add_sheet_to_excel(df = rf_collection.to_dataframe(),
                                                full_path = path,
                                                sheet_name = sheet_name,
                                                replace_sheet_if_exist = True,
                                                include_index = False,
                                                )


if __name__ == '__main__':
    col = RiskFactorCollection().rfr_load_from_context('cs_mars')
    a = 0

    # expected = [dict(domestic='EUR', foreign='USD'),
    #             dict(domestic='EUR', foreign='DKK')]
    # my_empty_collection = RiskFactorCollection(as_of_date=dt.date(2018, 1, 1))
    # my_empty_collection.add_risk_factor_list(expected + expected)
    #
    # RiskFactorCollection().rfr_load_from_md_map_context('master_mars')
    # pass
    # from core.risk_factor.collection import RiskFactorCollection
    # from core.risk_factor.factory.risk_factor_domain import RiskFactorType
    # some_rf = [dict(foreign = 'USD', domestic = 'EUR'), dict(foreign = 'GBP', domestic = 'EUR')]
    # other_rf = [dict(foreign = 'DKK', domestic = 'EUR')]
    # collection_a = (
    #                     RiskFactorCollection(as_of_date = dt.date(1992, 6, 26), risk_factors = some_rf)
    #                     .add_risk_factors_from_factories(RiskFactorType.RfBondResidualZspread)
    # )

    # my_new_collection = collection_a + other_rf
    # len(my_new_collection) == 3
    # len(collection_a) == 2
