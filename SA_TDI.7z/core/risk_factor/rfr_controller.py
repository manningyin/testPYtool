"""
Various functions used to perform various tasks in Risk Factor Repository, including inserting, deleting, changing, etc.

Functionality in this module includes:
    - Upserting risk factors
    - Inserting market data mapping contexts
    -


Notes:
    Author: JBrandt (g50444)

"""

import getpass
import collections
from risk_factor_repository import MarketDataMapping, MarketDataMappingContext, RiskFactorsContext
from risk_factor_repository.models import predicate
from risk_factor_repository import models

from core.connection import api


def upsert_risk_factors(risk_factors, info = 0):
    """
    Upserts (inserts or updates) risk factors in Risk Factor Repository.

    The function inserts and updates (if already exists) both "clean" risk factor instances, and their meta-data.
    The clean part is the more "mathematical" object type, e.g. for currency pairs: {'foreign': 'USD', 'domestic': 'EUR'}
    The meta-data contains a name, short name, description, labels etc. - but NOT the mapping to market data.

    Args:
        risk_factors    (list of risk_factor):      Risk factor instances that should be upserted to RFR
        info            (int):                      Controls information written to the log. 0 = nothing written.

    Returns:
        (None):   Nothing. But inserts and updates risk factors in risk factor repository.

    Raises:

    Example:
        The module is called (from python) like this::

            from core.risk_factor.factory import controller
            from core.system.envir import ScenarioEngineEnvir


            my_risk_factors = [
                            {'domestic': 'EUR', 'rfType': 'com.nordea.riskfactor.domain.fx.RfCcyPair20', 'foreign': 'BGN'},
                            {'domestic': 'EUR', 'rfType': 'com.nordea.riskfactor.domain.fx.RfCcyPair20', 'foreign': 'USD'}
                            ]

            controller.upsert_risk_factors( risk_factors    = my_risk_factors,
                                            info            = 0,
                                            )

    Warning:
        This function actually INSERTS AND CHANGES risk factors in Risk Factor Repository...!

    Notes:
        Author: JBrandt
    """
    rf_api = api.risk_factor_repository_api()

    for single_risk_factor in risk_factors:
        # ===================================================================================
        # Risk factors and their meta data is upserted one at a time.
        # ===================================================================================
        single_risk_factor.upsert_rf_in_rfr(rf_api = rf_api)
        single_risk_factor.upsert_rf_metadata_in_rfr(rf_api = rf_api,info = info)


def replace_rf_market_data_mapping_in_rfr(risk_factors,
                                          context_name,
                                          override=True):
    """
    Method for uploading risk factor market data mapping to RFR

    Args:
        risk_factors        (list):     Risk factor objects
        context_name        (str):      Name of the context that should be created, modified
        override            (bool):     A flag to update existing mapping in the context if false doesn't get updated

    Returns:
        (None):   Nothing returned, but risk factor mapping context uploaded to RFR

    Example:
        No example - yet!

    Warning:
        Current version does NOT do a real upsert. It inserts everything.

    Notes:
        Author: g50444 (Jonas Brandt)
    """

    rf_api = api.risk_factor_repository_api()
    from risklib.connection.ripl import ext_envir
    from ripl_core.authentication import create_sso_config
    from ripl_core import RiplClient
    config = create_sso_config("prod")
    client = RiplClient(**config)
    ext_envir.RIPL.prod.activate()

    try:
        contexts = rf_api.marketdatacontext.get_by_name_md_context_mappings(context_name)
        version_dict = collections.defaultdict(lambda: 1)
        version_dict.update({ctx.risk_factor_identifier.short_name: ctx.version for ctx in contexts})
        context_mappings = rf_api.marketdatacontext.get_by_name_md_context(context_name).mappings
        context_rf_ids = [x.risk_factor_identifier.risk_factor_id for x in context_mappings]
    except:
        version_dict = collections.defaultdict(lambda: 1)
        context_rf_ids = []

    for single_risk_factor in risk_factors:
        mdmapping = single_risk_factor.mdmapping
        if 'damd' in mdmapping['mdType'].lower():
            if mdmapping['marketDataId'] == 65:
                mdmapping['marketDataId'] = 8200
                print(single_risk_factor.metadata['short_name'])
            md_model = models.DamdMarketDataId(market_data_id=mdmapping['marketDataId'],
                                               md_type=mdmapping['mdType'],
                                               risk_type=mdmapping['riskType'])
            if mdmapping['marketDataid'] == 'ZERO':
                continue
        elif 'mars' in mdmapping['mdType'].lower():
            # 188 If Vol and GBP map to 188  - Generic zero return proxy
            if "MORT_NO" in single_risk_factor.riskfactor['curve_name']:
                mdmapping['mars_risk_factor_id'] = 1063
            else:
                continue
            #if mdmapping['mars_risk_factor_id'] == 65:
            #    mdmapping['mars_risk_factor_id'] = 8200
            #    print(single_risk_factor.metadata['short_name'])
            if 'surface_name' in single_risk_factor.riskfactor.keys():
                if single_risk_factor.riskfactor['ccy'] == 'GBP':
                    mdmapping['mars_risk_factor_id'] = 188

            if 'XCCY_BASIS' in single_risk_factor.metadata['short_name']:
                this_ccy = single_risk_factor.riskfactor['ccy']
                if this_ccy == 'EUR':
                    mdmapping['mars_risk_factor_id'] = 59  #"ZERO"   this is example to delete if needed.
                elif this_ccy == 'NOK':
                    mdmapping['mars_risk_factor_id'] = 134
                elif this_ccy == 'SEK':
                    mdmapping['mars_risk_factor_id'] = 156
                elif this_ccy == 'DKK':
                    mdmapping['mars_risk_factor_id'] = 47
                elif this_ccy == 'GBP':
                    mdmapping['mars_risk_factor_id'] = 65 #8200
                elif this_ccy == 'AUD':
                    mdmapping['mars_risk_factor_id'] = 11
                elif this_ccy == 'CAD':
                    mdmapping['mars_risk_factor_id'] = 33
                elif this_ccy == 'CHF':
                    mdmapping['mars_risk_factor_id'] = 34
                elif this_ccy == 'CNH':
                    mdmapping['mars_risk_factor_id'] = 36
                elif this_ccy == 'CZK':
                    mdmapping['mars_risk_factor_id'] = 43
                elif this_ccy == 'HKD':
                    mdmapping['mars_risk_factor_id'] = 76
                elif this_ccy == 'JPY':
                    mdmapping['mars_risk_factor_id'] = 92
                elif this_ccy == 'MXN':
                    mdmapping['mars_risk_factor_id'] = 124
                elif this_ccy == 'NZD':
                    mdmapping['mars_risk_factor_id'] = 136
                elif this_ccy == 'PLN':
                    mdmapping['mars_risk_factor_id'] = 144
                elif this_ccy == 'RUB':
                    mdmapping['mars_risk_factor_id'] = 818
                elif this_ccy == 'SGD':
                    mdmapping['mars_risk_factor_id'] = 157
                elif this_ccy == 'TRY':
                    mdmapping['mars_risk_factor_id'] = 2890
                elif this_ccy == 'ZAR':
                    mdmapping['mars_risk_factor_id'] = 204


            md_model = models.MarsMarketDataId(mars_risk_factor_id=mdmapping['mars_risk_factor_id'],
                                               maturity_tenor=mdmapping['maturity_tenor'],
                                               md_type=mdmapping['mdType'],
                                               risk_type=mdmapping['risk_type'],
                                               underlying_maturity_tenor=mdmapping['underlying_maturity_tenor'])
            if mdmapping['mars_risk_factor_id'] == 'ZERO':
                # or ('XCCY_BASIS' in single_risk_factor.metadata['short_name']):
                short_name = single_risk_factor.metadata['short_name']
                #rf_id = rf_api.metadata.get_one_risk_factor_meta_data_by_short_name(short_name).risk_factor_id
                try:
                    rf_id = client.risk_factor_repository.risk_factor_meta_data.get_one_risk_factor_meta_data_by_short_name(
                        short_name).risk_factor_id
                    rf_identifier = models.RiskFactorIdentifier(short_name=short_name, risk_factor_id=rf_id)
                    print(short_name)
                    rf_api.marketdatacontext.delete_md_mapping(market_data_mapping_context_name=context_name,
                                                           risk_factor_short_name=short_name,
                                                           version=version_dict[short_name],
                                                               client=client)
                except:
                    continue
                continue
        elif 'mdhub' in mdmapping['mdType'].lower():
            md_model = models.MdHubMarketDataId(instrument_id=mdmapping['instrumentId'],
                                                md_type=mdmapping['mdType'],
                                                risk_type=mdmapping['riskType'])
            if mdmapping['instrumentId'] == 'ZERO':
                continue
        else:
            raise Exception("Mapping source not recognized")
        short_name = single_risk_factor.metadata['short_name']
        # FIXME: Remove dependency of rf_id....
        try:
            rf_id = client.risk_factor_repository.risk_factor_meta_data.get_one_risk_factor_meta_data_by_short_name(
                                                                                        short_name).risk_factor_id
            #rf_id = rf_api.metadata.get_one_risk_factor_meta_data_by_short_name(short_name).risk_factor_id

            if override or (rf_id not in context_rf_ids):
                rf_identifier = models.RiskFactorIdentifier(short_name=short_name, risk_factor_id=rf_id)
                md_rf_mapping = models.MarketDataMappingAudited(risk_factor_identifier=rf_identifier,
                                                                market_data_mapping_context_name=context_name,
                                                                source_market_data_id=md_model,
                                                                version=version_dict[short_name])

                client.risk_factor_repository.market_data_mapping. \
                    upsert_md_mapping(market_data_mapping_audited=md_rf_mapping)
                #rf_api.marketdatacontext.upsert_md_mapping(market_data_mapping_audited=md_rf_mapping)
            else:
                print(f'Skipping for rf_id: {rf_id}, set override=True if you want to override existing market edata mapping ')
        except Exception as e:
            print(f'Risk factor failed: {short_name}, with error: {e}')
            continue


def upsert_context(name,
                   and_predicate            = None,
                   or_predicate             = None,
                   create_as_dynamic_filter = True,
                   ):
    """
    Creates or updates (creates new version) a risk factor context with predicate.

    This function is a multi-purpose tool, using different services in different cases.
    If the risk factor context already exists this function will create a new version - using one RFR service.
    if the context does NOT exist, it will be created from scratch - using another RFR service.
    This function uses different

    Args:
        name                        (str):              Name of the risk factor context (case sensitive)
        and_predicate       (none or list of dicts):    List of label conditions that will be combined using an "and"
                                                        logical operator.
        or_predicate        (none or list of dicts):    List of label conditions that will be combined using an "or"
                                                        logical operator.
        create_as_dynamic_filter   (bool):              If False the risk factors in the context will NOT change if
                                                        additional (or fewer) risk factor will match the criteria later
                                                        on. If True the context is a dynamic object, always returning
                                                        all risk factors that currently match the criteria.

    Returns:
        (None):     Nothing, but creates risk factor context.

    Example:
        The module is called (from python) like this::

            from core.risk_factor import context

            and_predicate = [
                                context.Label(name = "model_converage",
                                                    value = True,
                                                    group = "master"
                                                    ).to_predicate_dict(),
                                context.Label(name = "zero_coupon",
                                                    value = True,
                                                    group = "master"
                                                    ).to_predicate_dict(),
                            ]

            context.upsert_context( name                        = "my-test-context",
                            and_predicate               = and_predicate,
                            or_predicate                = None,
                            create_as_dynamic_filter    = True,
                            )

    Warning:

    Notes:
        Author: JBrandt (g50444)
    """

    if create_as_dynamic_filter is not True:
        raise NotImplementedError("Creation of context with static list of risk factors is currently not supported."
                                  "Choose create_as_dynamic_filter = True")
    # ===================================================================================
    # Getting risk factor repository API and handle for context related services
    # ===================================================================================
    rfr_api = api.risk_factor_repository_api()
    rfr_cntxt_api = rfr_api.riskfactorcontext

    # ===================================================================================
    # Translating the input list of dictionaries into predicate object
    # ===================================================================================
    new_predicate = predicate.Predicate(_and=and_predicate, _or=or_predicate)

    # ===================================================================================
    # Fetching the current version of the context (if it exists)
    # ===================================================================================
    existing_context = rfr_cntxt_api.get_by_name_rf_context(name)

    if existing_context.name is None:
        # ===================================================================================
        # If no current version of the context was fetched from RFR, it does not already exist.
        # We will create it from scratch
        # ===================================================================================
        rfr_cntxt_api.create_by_predicate_rf_context(
                                                    predicate               = new_predicate,
                                                    temp_current_user_param = getpass.getuser(),
                                                    is_auto_generated       = create_as_dynamic_filter,
                                                    property_group          = 'master',
                                                    name                    = name,
                                                    )

    else:
        # ===================================================================================
        # The risk factor context already exists.
        # We will update it's predicate - and keep everything else unchanged.
        # ===================================================================================

        new_risk_factor_context = RiskFactorsContext( activation        = existing_context._activation,
                                                      extra_data        = existing_context.extra_data,
                                                      include           = existing_context.include,
                                                      interpolations    = existing_context.interpolations,
                                                      name              = existing_context.name,
                                                      predicate         = new_predicate,
                                                      risk_factors      = None,
                                                      version           = existing_context.version,
                                                      )
        rfr_cntxt_api.upsert_rf_context(context                 = new_risk_factor_context,
                                        temp_current_user_param = getpass.getuser(),
                                        )


if __name__ == '__main__':
    # from core.system import ext_envir
    # ext_envir.update(ext_envir.RiskFactorRepository.uat, ext_envir.ScenarioEngine.uat)
    from core.risk_factor.risk_factor_utils import Label

    #
    # and_predicate = [Label(name="model_coverage", value=True, group="my-test").to_predicate_dict(),
    #                  Label(name="risk_factor", value=True, group="my-test").to_predicate_dict()]

    # upsert_context(name="my-test-context-jonas-1", and_predicate=and_predicate, create_as_dynamic_filter=False)

