from pandas import DataFrame
import pandas as pd


class RiskFactorData(DataFrame):
    """DataFrame with customised MultiIndex (Date, Currency, Tenor_string) and slicing capabilities.

       Author: g46474 (Joerg Wegener)
    """
    def __init__(self, data):
        super().__init__(data)
        self.name = data.name if hasattr(data, 'name') else None

    def get_currencies(self):
        # Return  pandas.Index of currencies.
        return self.index.get_level_values(1)

    def get_dates(self):
        # Return pandas.DatetimeIndex of dates.
        return self.index.get_level_values(0)

    def get_tenors(self):
        # Returns pandas.Index of tenors.
        return self.index.get_level_values(2)

    def by_date_range(self, startdate=None, enddate=None):
        """Slice DataFrame by datetime window.

            Parameters
            ----------

            startdate: string, datetime-like or None (default)
                       '2007-01-02'
            enddate:   string, datetime-like or None (default)
                       '2007-01-15'
            return:  RiskFactorData cropped to given date range.

            If one of the inputs is empty (default: None) -> startdate = enddate -> date range is one day.
        """

        # both inputs are unspecified, i.e. default to None.
        if (startdate is None) and  (enddate is None): raise TypeError('At least one of the inputs need to be non-None.')

        # one of inputs is unspecified, i.e. defaults to None.
        startdate = startdate or enddate
        enddate = enddate or startdate

        result = self.loc[(slice(pd.Timestamp(startdate), pd.Timestamp(enddate)),), :]
        return self.__class__(result)

    def by_currency(self, currency):
        """
             :param currency: currency string or list(tenor strings)
             :return: RiskFactorData cropped to given currency.
        """
        result = self.loc[(slice(None), currency, slice(None)), :]
        return self.__class__(result)

    def by_tenor(self, tenor=None):
        """
            :param tenor: tenor string or list(tenor strings)
            :return: RiskFactorData cropped to given tenor.
        """
        result = self.loc[(slice(None), slice(None), tenor), :]
        return self.__class__(result)

    def to_timeseries(self, column):
        """Transforms column RiskFactorData.'column' to pandas.Series -- finds datetime index automatically. Drops all other indices.

        Parameters:
        -----------
        :param column: string
               The column (name) containing timeseries values.
        :return: pandas.Series of 'column'.

        Note: Depending on dropped indices, remaining index can be non-unique.

        See also:
        ---------

        RiskFactorData.to_timeseries_slice()   --   additionally offers index slicing.
        """
        from pandas.core.dtypes.common import is_datetimelike

        df_slice = self[column]
        # func = lambda x: isinstance(x, pd.Int64Index) # all date, datetime and integer-based indeces
        return self.__class__._keep_index_level_by_type(df_slice, lambda x: is_datetimelike(x))


        # TODO: Merge to_timeseries_slice() with to_timeseries(). Something like to_timeseries(column) -> to_timeseries_slice(column, None, None)
    def to_timeseries_slice(self, column, currency=None, tenor=None):
        """
          Transform DataFrame to pandas.Series and enables slicing of index -- finds datetime index automatically.
            :param column: string
                   The column containing timeseries values
            :param currency: string
                   Part of the MultiIndex.
            :param tenor: string
                   Part of the MultiIndex.
            :return: pandas.Series of timeseries in `column`, optionally sliced to currency and tenor.

            The below are equal:
            by_tenor(tenor=['1M','6M']).by_currency('EUR').by_date_range('2007-01-02', '2007-01-05').to_timeseries('signedDiffRate')
                                                           by_date_range('2007-01-02', '2007-01-05').to_timeseries_slice('signedDiffRate','EUR',['1M','6M'])

        """
        from pandas.core.dtypes.common import is_datetimelike

        if (currency is None) or (tenor is None):
            raise TypeError("Both need to be defined in order to slice index: currency & tenor.")

        df_slice = self.loc[(slice(None), currency, tenor), :][column]
        # func = lambda x: isinstance(x, pd.Int64Index) # all date, datetime and integer-based indeces
        return self.__class__._keep_index_level_by_type(df_slice, lambda x: is_datetimelike(x))


    def write_json(self, jsonfile):
        # Write to JSON so that data is readable from MATLAB.
        with open(jsonfile, 'w') as f:
            self.to_json(f, date_format='iso', orient='split')

    def make_multiindex(self) -> 'RiskFactorData':

        # Multi-index: Date, Currency, Tenor_string
        df = self.set_index(['START_EOD_DATE', 'CURRENCY', 'TERM_ID'])
        try:
            df.name = self.name
        except:
            df.name = self.NAME

        # Lexsort multi-index to enable slicing.
        if not df.index.is_lexsorted():
            df.sort_index(inplace=True)

        return self.__class__(df)


    @staticmethod
    def _keep_index_level_by_type(series, func):
        """ Dropping indices from MultiIndexed pandas.Series whose type matches func == False.

            :param series: MultiIndexed pandas.Series
            :param func: lambda function returning True or False. Example: ``lambda x: is_datetimelike(x)``
                         All index columns/levels which evaluate to False are dropped.
            :return: pandas.Series with all but one index removed.
        """
        index = series.index

        # if number of index columns/levels is equal to 1, there is nothing to drop
        if index.nlevels > 1:
            levels_to_drop = []
            # find index (column/level) holding given type. Then, drop all others.
            for i, level in enumerate(index.levels):
                if not func(level):
                    levels_to_drop.append(i)
            result = series.reset_index(level=levels_to_drop, drop=True)
            # storing dropped index identifiers as tuple + concatenate with self's original name.
            result.name = series.name, tuple([series.index.names[i] for i in levels_to_drop])
        else:
            result = series

        return result

