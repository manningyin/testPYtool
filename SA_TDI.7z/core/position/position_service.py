"""
This module offers service for loading all positions for a given book / portfolio, which is identified by the MARS
org_id and a date.

We differ between OTC derivative trades and securities, such that for a security the eod position is found by grouping
positions by ISIN and summing up all trades on the given day. For OTC derivative trades we just return each trade_id
together with the source system (e.g. INFINITY) and a unit position of 1.

A logical structure is implemented using the effect_supergrp in MARS to determine which trades belong to derivatives
and which belong to securities. OTC derivatives are defined to be all trades NOT belonging to the following groups:
BOND, EQUITY, FUTURES, CURRENCY, COMMODITY, INDEX and EQUITY SWAP

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       16may2017   g48606      Initial creation
    1       16may2018   JBrandt     (g50444) Changed PositionServiceLoader into accepting multiple book id's
    ======= =========   =========   ========================================================================================

Notes:
    Author: g48606 (Oskar Rosendal)
"""
import datetime as dt
import pyodbc

import pandas as pd

from core.caching import abstract_loader_classes
from core.caching.cache_driver import easy_cache
from core.connection import database_connect
from core.connection import database_extract
from core.system import ext_envir
from core.types import _transactions
from core.utils import date_helper, error_handler
from core.utils import list_helper


def get_org_ids(book_id, date, info=0):
    """
    Getting Mars org-ids in specific Mars book(s) (on a specific date).

    Args:
        book_id     (int or list):  Mars identifier of the book(s). Can be a single book or a list of books.
        date        (date):         Matching mars EoD date
        info        (int):          Determines how much is printed to the console. 0 = Minimum ->  higher, more....

    Returns:
        (list): List of Mars org id's

    Notes:
        Author: g48606
    """

    book_id_list = list_helper.to_list(book_id)
    book_ids_commasep = ', '.join(map(str, book_id_list))

    oracle_date = date_helper.oracle_to_date(date)
    sql = """select A.ORG_ID
             from MARSP.CONS_ORG_STRUCTURE_STD_HIST a
             where A.EOD_DATE = %(oracle_date)s
             and A.CONS_ORG_ID in ( %(book_ids_commasep)s )""" % locals()

    if info > 0:
        print("Sql query: " + sql)

    df = database_extract.as_dataframe(database = 'INFOP', query = sql)

    out = [int(x) for x in df['ORG_ID'].tolist()]
    if not out:
        error_msg = "MARS didn't return any child org_ids for provided consolidated org_id. Perhaps the table " \
                    "CONS_ORG_STRUCTURE_STD_HIST has not yet been populated for provided date, or the provided " \
                    "org_id doesn't exist."
        raise Exception(error_msg)
    return out


def get_otc_trades(book_id, date):
    """
    Loading of all trades of OTC derivatives with quantity different from zero for a given book_id and date

    Args:
        book_id                      (int):   The MARS org_id for the book/portfolio
        date         (dt.date/dt.datetime):   The eod_date to fetch positions for

    Returns:
        (pd.DataFrame):   DataFrame with columns trade_id and source_system

    Notes:
        Author: g48606
    """
    oracle_date = date_helper.oracle_to_date(date)

    sql = """with trades as (
            select distinct c.data_source_identity trade_id, c.data_source_id source
            from marsp.trans_status a, marsp.cons_org_structure_std_hist b, marsp.trade c
            where a.eod_date = %(oracle_date)s
            and a.eod_date = b.eod_date
            and a.org_id = b.org_id
            and b.cons_org_id = %(book_id)s
            and a.trade_id = c.trade_id)
            select trade_id, source from trades where source != 'WSM'
            union all
            select y.wsm_wss_tid trade_id, x.source
            from trades x, marsp.trade_wsm_link y
            where x.source = 'WSM'
            and x.trade_id = y.wsm_deal_number""" % locals()

    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql, conn)
    conn.close()

    # ========================================================================================== #
    # For Infinity, MARS returns source_trans_id/source_trade_id, but we only want the trade_id,
    # thus we do following string manipulation to exclude the trans_id
    # ========================================================================================== #
    df['TRADE_ID'] = [item.split('/')[-1] for item in df['TRADE_ID']]

    # ========================================================================================== #
    # We use mapping function to translate mars source names to ORCA source names
    # ========================================================================================== #
    sources = []
    for mars_source in df['SOURCE']:
        source = _transactions.mars_source_name_mapping.get(mars_source)
        if source is None:
            error_handler.track_error(error_message="Missing mapping for MARS source in "
                                                    "core.types.transaction_types.mars_source_name_mapping",
                                      identifier=mars_source)
            sources.append(mars_source)
        else:
            sources.append(source)
    df['SOURCE'] = sources
    return df


def get_correct_trades_for_wsm(wsm_deal_nos):
    """
    TradeHub started identifying WALLSTREET trades by the trade_id rather than deal_no, this is not reflected in the
    source trade_id listed in MARSP.TRADE, thus we have to convert these...

    Notes:
         Author: g48606
    """
    str_deal_nos = '(' + ', '.join(map(str, wsm_deal_nos)) + ')'
    sql = """select WSM_WSS_TID TRADE_ID, 'WSM' SOURCE 
             from MARSP.TRADE_WSM_LINK
             where WSM_DEAL_NUMBER in %(str_deal_nos)s """ % locals()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    df = pd.read_sql(sql, conn)
    conn.close()
    return df


def get_security_isins(book_id, date, include_unsettled = True, info = 0):
    """
    Loading of all securities with holding/position different from zero for a given book_id and date

    Args:
        book_id               (int or list):    The MARS org_id(s) for the book/portfolios
        date          (dt.date/dt.datetime):    The eod_date to fetch positions for
        include_unsettled            (bool):    Whether to include unsettled positions or not
        info                          (int):    Level of information written to the console. Higher -> more information.
                                                info = 0 is minimum/no.

    Returns:
        (pd.DataFrame):   DataFrame with columns ISIN and position

    Notes:
        Author: g48606 (Oskar Rosendal)
    """
    # ===================================================================================
    # Constructing sql query by:
    # - Translating date to oracle-date format
    # - getting org-id's from book id's
    # - Creating content of the org_id "in" statement
    # ===================================================================================

    oracle_date = date_helper.oracle_to_date(date)
    org_ids = get_org_ids(book_id = book_id, date = date)

    isins_and_positions = pd.DataFrame()
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    chunk_size = 1000
    for i in range(0, len(org_ids), chunk_size):
        str_org_ids = '(' + ', '.join(map(str, org_ids[i:i+chunk_size])) + ')'
        sql = """
                  select ISIN, EFFECT_ID, CURRENCY, SUM(QUANTITY)/100 as POSITION, EFFECT_GRP_ID
                  from
                    (
                    select /*+ ordered */ A.EFFECT_ID, B.ISIN, C.CURRENCY_ID as CURRENCY, A.QUANTITY, c.EFFECT_GRP_ID
                    from MARSP.HOLDING a, MARSP.ISIN_EFFECT b, MARSP.EFFECT c
                    where A.EOD_DATE = %(oracle_date)s
                    and A.ORG_ID in %(str_org_ids)s
                    and A.EFFECT_ID = B.EFFECT_ID (+)
                    and A.QUANTITY != 0
                    and A.EFFECT_ID = C.EFFECT_ID (+)
              """ % locals()
        if include_unsettled:
            sql += " union all "
            sql += """select c.EFFECT_ID, D.ISIN, E.CURRENCY_ID as CURRENCY, C.QUANTITY, e.EFFECT_GRP_ID
                      from MARSP.TRADE a, MARSP.TRANS_STATUS b, MARSP.TRANS c, MARSP.ISIN_EFFECT d, MARSP.EFFECT e
                      where A.TRADE_ID = B.TRADE_ID
                          and B.EOD_DATE = %(oracle_date)s
                          and B.ORG_ID in %(str_org_ids)s
                          and B.TRANS_STATUS_TYPE_ID = 'BOOK'
                          and A.TRADE_ID = C.TRADE_ID
                          and B.TRANS_ID = C.TRANS_ID
                          and C.EFFECT_ID > 1000
                          and C.EFFECT_ID = D.EFFECT_ID (+)
                          and C.EFFECT_ID = E.EFFECT_ID
                          and C.QUANTITY != 0""" % locals()
        sql += ") group by ISIN, EFFECT_ID, CURRENCY, EFFECT_GRP_ID"

        if info > 0:
            print('Sql statement: ' + sql)

        isins_and_positions = isins_and_positions.append(pd.read_sql(sql, conn))

    # ===================================================================================
    # Some positions will not have ISIN's attached for historical dates using this
    # approach. We therefore extracts EFFECT_ID's with no ISIN attached, and attempt
    # to get these using alternative sources (in Mars).
    # ===================================================================================
    effects_with_no_isin = isins_and_positions[isins_and_positions['ISIN'].isnull()]['EFFECT_ID'].astype(int).tolist()

    if len(effects_with_no_isin) > 0:
        extra_isins = pd.DataFrame()
        chunk_size = 1000  # sql language has a limit of 1000 for the list size of a "where X in (...)" clause
        for i in range(0, len(effects_with_no_isin), chunk_size):
            batch_isins = effects_with_no_isin[i:i + chunk_size]
            temp_extra_isins = isins_from_alternative_tables(effect_ids=batch_isins)
            extra_isins = extra_isins.append(temp_extra_isins)

        if not extra_isins.empty:
            # ===================================================================================
            # Left joining the extra ISIN's to the extracted isin/position overview.
            # Since the "ISIN" column exist in both dataframes we perform rename:
            #   - ORIGINAL_ISIN the ISIN extracted from "normal" approach
            #   - ALTERNATIVE_ISIN the ISIN using alternative approach
            # Then replacing "ISIN" in the original dataframe with the alternative isin,
            # when missing.
            # ===================================================================================

            isins_merged = pd.merge(left=isins_and_positions.rename(columns={'ISIN':'ORIGINAL_ISIN'}),
                                    right=extra_isins.rename(columns={'ISIN':'EXTRA_ISIN'}),
                                    how='left',
                                    on='EFFECT_ID')

            isins_and_positions['ISIN'] = isins_merged.ORIGINAL_ISIN.combine_first(isins_merged.EXTRA_ISIN)

    # ========================================================================================== #
    # Exclude ISINs where the trades cancel out and results in a zero position
    # ========================================================================================== #
    out = isins_and_positions[isins_and_positions['POSITION'] != 0]
    missed_isins = out[out.isna()['ISIN']]['EFFECT_ID'].astype(int).tolist()
    if len(missed_isins) > 0:
        error_handler.track_error(error_message="Couldn't identify ISINs for some effect_ids",
                                  identifier=missed_isins,
                                  comments="Provided MARS tables does not hold mappings between effect_ids and ISINs")
        out = out.dropna().reset_index(drop=True)
    return out


def isins_from_alternative_tables(effect_ids):
    """
    Getting ISIN for Mars effect_ids with no isin-link in marsp.isin_effect

    Alternative sources for effect_id -> isin link is:
        - marsp.effect_ufo_link
        - marsp.EFFECT_WOC_LINK

    Args:
        effect_ids  (list):     Mars effect_id's with no ISIN mapping in marsp.isin_effect_table

    Returns:
        (dataframe): EFFECT_ID and ISIN mapping

    Notes:
        Author: JBrandt (g50444)
    """

    if len(effect_ids) == 0:
        raise Exception('List of effect ids provided as input is empty. This is not expected.')

    # ===================================================================================
    # Creating sql statement, extracting effect_id and ISIN link from all the
    # "alternative" tables. Combining through a "union" join - concatenating unique
    # combinations in one big select statement.
    # ===================================================================================

    mars_isin_effect_link_tables = ['EFFECT_UFO_LINK', 'EFFECT_WOC_LINK']

    null_effect_str = '(' + ', '.join(map(str, effect_ids)) + ')'
    all_table_sqls = []
    for table in mars_isin_effect_link_tables:
        table_sql = ("select distinct EFFECT_ID, ISIN from MARSP.%(table)s "
                     "where EFFECT_ID in %(null_effect_str)s "
                     "and ISIN is not null" % locals())
        all_table_sqls.append(table_sql)

    null_isin_sql = ' union '.join(all_table_sqls)

    # ===================================================================================
    # Extracting effect_id / ISIN links from Mars.
    # ===================================================================================
    extra_isins = database_extract.as_dataframe(database = 'INFOP', query = null_isin_sql)

    return extra_isins


def position_service(book_id, date, include_unsettled=True):
    """
    Calls "get_otc_trades" and "get_security_isins" to fetch all positions for a given book. Information is then parsed
    to a dictionary with identifier as key and position as value

    Args:
        book_id                      (int):   The MARS org_id for the book/portfolio
        date         (dt.date/dt.datetime):   The eod_date to fetch positions for
        include_unsettled           (bool):   Whether to include unsettled positions or not

    Returns:
        (dict):   dictionary with identifiers as key and position as value

    Notes:
        Author: g48606 (Oskar Rosendal)
    """
    trades = get_otc_trades(book_id, date)
    securities = get_security_isins(book_id, date, include_unsettled)

    out = {}
    for idx, (trade_id, source) in trades.iterrows():
        # =========================================================== #
        # For trades, we always set the position equal to one
        # =========================================================== #
        out[_transactions.TradeIdentifier(source_system=source, trade_id=trade_id)] = 1
    for idx, df_row in securities.iterrows():
        out[_transactions.SecurityIdentifier(ISIN=df_row['ISIN'], currency=df_row['CURRENCY'])] = df_row['POSITION']

    return out


class PositionServiceLoader(abstract_loader_classes.MatrixLoader):
    def __init__(self, book_id, date, include_unsettled=True, load_from_source=False, cache_path=None):
        self.include_unsettled = include_unsettled
        self.unique_params = include_unsettled

        abstract_loader_classes.MatrixLoader.__init__(self,
                                                      names=book_id,
                                                      startd=date,
                                                      endd=date,
                                                      load_from_source=load_from_source,
                                                      cache_path=cache_path)
        self.data = self._sum_across_books()

    def source_loading_function(self, book_ids, date):
        out = {}
        if type(book_ids) is list:
            for book_id in book_ids:
                if type(book_id) is int:
                    val = position_service(book_id=book_id, date=date, include_unsettled=self.include_unsettled)
                    out[date, book_id] = val
                else:
                    error_handler.track_error(error_message="The book id is not int", identifier=book_id,
                                              comments="Position service need int as input, will not continue")

        elif type(book_ids) is int:
            val = position_service(book_id=book_ids, date=date, include_unsettled=self.include_unsettled)
            out[date, book_ids] = val

        return out

    def _sum_across_books(self):
        """
        Aggregating positions across different books and currencies

        Uses Pandas (DataFrame) method:
        - Converting dict of dicts to DataFrame
        - Using dataframe "sum" method
        - Converting to list of dictionaries

        Returns:
            (list of dict): Keys: securities object, value: position

        Notes:
            Author: JBrandt (g50444)
        """

        values_as_list_of_dicts = list(self.data.values())
        df = pd.DataFrame(values_as_list_of_dicts)
        sum_df = df.sum()
        sum_dict = sum_df.to_dict()

        return sum_dict


def PI_coverage_positions(eod_date = dt.datetime(2018, 1, 31)):
    """
    Positions covered by the current Programme Increments

    Args:
        eod_date (date): Position "snap" end of day date.

    Returns:
        (dict): Security object as key, position (quantity) as value

    Notes:
        Author: Shengyao
    """

    mars_books = [7524,  # DK Scandi
                  6100100, 1093615,  # MMNORGE and MMSEFU13
                  # 70133, 70113, 70163, 1170378  # Descoped for PI-2 - SWSEKC, STKRED and MMSESPOT
                  ]
    date_books_with_positions = PositionServiceLoader(book_id = mars_books, date = eod_date)

    PI_book_positions = date_books_with_positions.data

    PI_positions = {}
    for key, value in PI_book_positions.items():
        PI_positions[key] = value

    return PI_positions


def isins_in_portfolio(book_ids, date):
    """
    Returns ISINS for securities in a portfolio.

    Returns:
        (list of str): List of ISINS

    Notes:
        Author: JBrandt (g50444)
    """

    positions = PositionServiceLoader(book_id = book_ids, date = date).data
    isins = [str(key.ISIN) for key, value in positions.items() if isinstance(key, _transactions.SecurityIdentifier)]
    return isins


@easy_cache()
def get_cash_positions(book_name, date):
    """
    This function connects to TWP to find cash positions for the given book in CALYPSO

    Args:
        book_name        (str): CALYPSO book name
        date            (date): Date for fetching cash positions

    Returns:
        (dataframe): Dataframe containing date, account type (COC/CASH), isin and the position

    Warning:
        These positions do not include any corrections made by FRC

    Notes:
        Author: g48606
    """
    oracle_date = date_helper.oracle_to_date(date)
    sql_string = """select /*+ PARALLEL(8) */ a.prod_date, c.account_type, a.currency, b.ISIN, sum(a.AMOUNT)
                    from tgl.cal_bal a
                    join tgl.global_accounts c on a.account_name=c.account_name
                    join tgl.cal_trade_incl_aggr b on a.tgl_tid=b.tgl_tid and a.prod_date between b.start_date and b.end_date
                    where  a.prod_date = %(oracle_date)s
                    and a.portfolio = '%(book_name)s'
                    and c.account_type in ('CASH','COC')
                    and c.account_cat = 'BAL'
                    group by a.prod_date, c.account_type, a.currency, b.isin
                    order by c.account_type, a.prod_date, a.currency, c.account_type""" % locals()

    conn = pyodbc.connect(database_connect.get_string('TWP'))
    df = pd.read_sql(sql_string, conn)
    conn.close()

    return df


if __name__ == '__main__':
    print(isins_in_portfolio(6100100, dt.datetime(2019,2,12)))
    # print(PI_coverage_positions())