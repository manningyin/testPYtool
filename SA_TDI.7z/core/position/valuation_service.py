import pandas as pd

import core.types
from core.position import position_service
from core.pricing import pricing


def portfolio_valuation(book_id, eod_date, engine, valuation_date=None, scenarios=None):
    positions = position_service.PositionServiceLoader(book_id=book_id, date=eod_date).data
    return position_valuation(positions=positions, eod_date=eod_date, engine=engine, valuation_date=valuation_date, scenarios=scenarios)


def position_valuation(positions, eod_date, engine, valuation_date=None, scenarios=None):
    trade_ids = list(positions.keys())
    price_output = pricing.pricing_service(trade_ids=trade_ids,
                                           eod_date=eod_date,
                                           engine=engine,
                                           scenarios=scenarios,
                                           valuation_date=valuation_date)
    prices, acc_interests = pricing.parse_pricing_output_base_ccy(price_output, include_acc_interest=True)

    for key in prices:
        prices[key] *= positions[key]
        acc_interests[key] *= positions[key]
    return prices, acc_interests


def scenario_pl(positions, scenarios, eod_date, engine=core.types.PricingEngine.ORCA, aggregate = True):
    """
    This function use core prototype to calculate and aggregate the scenario pl

    Args:
        positions (position info):   output from the core.position service
        scenarios      (scenario):   output from the core.scenario service
        eod_date           (date):   eod date
        engine    (PricingEngine):   enumerator specifying the pricing engine to be used

    Returns:
        (pd.Series):   a pandas series of pl

    Notes:
        Author: g48454
    """

    prices = {}
    for scenario in scenarios:
        valuation_day = position_valuation(positions=positions,
                                           eod_date=eod_date,
                                           engine=engine,
                                           scenarios=scenario['scenarios'])
        prices[scenario['scenario_date']] = valuation_day

    base_valuation = position_valuation(positions=positions,
                                        eod_date=eod_date,
                                        engine=engine)
    if aggregate:
        out = pd.Series()
        for scenario_day, scenario_valuation in prices.items():
            temp_pl = sum([scenario_valuation.get(x, 0) - base_valuation[x] for x in base_valuation.keys()])
            out = out.append(pd.Series(temp_pl, index=[scenario_day]))
        out.sort_index(inplace=True)

    else:
        out = pd.DataFrame()
        for scenario_day, scenario_valuation in prices.items():
            temp_df = pd.DataFrame()
            temp_df['Position'] = [str(x) for x in base_valuation.keys()]
            temp_df['Scenario PL'] = [scenario_valuation.get(x, 0) - base_valuation[x] for x in base_valuation.keys()]
            temp_df['scenario_date'] = scenario_day
            out = out.append(temp_df)
    return out


if __name__ == '__main__':
    import time
    import datetime as dt
    stime = time.time()
    out = portfolio_valuation(book_id=6100100, eod_date=dt.datetime(2017, 4, 10), engine=core.types.PricingEngine.ORCA)
    etime = time.time()

    from pprint import pprint
    pprint(out)

    print('Elapsed time: %s' % (etime - stime))
