from core.connection import api
import vip_definer
import os


def get_virtual_portfolio(name):
    vip = api.virtual_portfolio_api()
    return vip.find_by_name_using_get1(name)


def define_virtual_portfolio(name, position_criteria, trade_criteria, description=''):
    """
    Define a virtual portfolio in the Trade Identifier used by ScenarioEngine

    Args:
        position_criteria    (list of dicts): List of dictionaries with keys named source_system and portfolio_id
                                              Position criteria will be used to fetch holdings
        trade_criteria       (list of dicts): List of dictionaries with keys named source_system and portfolio_id
                                              Position criteria will be used to fetch trades
        name                           (str): Name of the virtual portfolio
        description                    (str): Description of the virtual portfolio

    Returns:
        (None): Nothing is returned, rather the virtual portfolio is uploaded to the VIP definer

    Notes:
        Author: g48606
    """
    position_identifiers = []
    for position in position_criteria:
        identifier = vip_definer.PortfolioIdentifier(portfolio_id=position['portfolio_id'],
                                                     source_system=position['source_system'])
        position_identifiers.append(vip_definer.PositionCriteria(book_element=identifier))
    pos_criteria = vip_definer.PositionCriteria(_or=position_identifiers)

    trade_identifiers = []
    for trade in trade_criteria:
        identifier = vip_definer.PortfolioIdentifier(portfolio_id=trade['portfolio_id'],
                                                     source_system=trade['source_system'])
        trade_identifiers.append(vip_definer.TradeCriteria(book_element=identifier))
    tra_criteria = vip_definer.TradeCriteria(_or=trade_identifiers)

    virtual_portfolio_config = vip_definer.VipCriteriaConfigurationInternal(description=description,
                                                                            name=name,
                                                                            owner=os.getenv('username'),
                                                                            position_criteria=pos_criteria,
                                                                            trade_criteria=tra_criteria)
    vip_api = api.virtual_portfolio_api()
    vip_api.save_using_post1(sc_entity=virtual_portfolio_config)


if __name__ == '__main__':
    define_virtual_portfolio(name='oskar_test_portfolio',
                             description='description_test',
                             trade_criteria=[dict(source_system='CALYPSO', portfolio_id='MMNORGE'),
                                             dict(source_system='INFINITY', portfolio_id='MMNORGE')],
                             position_criteria=[dict(source_system='CALYPSO', portfolio_id='MMNORGE'),
                                                dict(source_system='INFINITY', portfolio_id='MMNORGE')])
    print(get_virtual_portfolio('oskar_test_portfolio'))