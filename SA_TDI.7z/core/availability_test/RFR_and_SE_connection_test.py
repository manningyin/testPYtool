from core.connection import api
from core.system import ext_envir


def connection_tests(*args):
    ext_envir.update(*args)
    print("RFR connection status:")
    try:
        rf_api = api.risk_factor_repository_api().riskfactorcontext
        print("\t Risk Factor Repository '%s': https://%s/swagger-ui.html" % (ext_envir.RiskFactorRepository().envir, rf_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Risk Factor Repository '%s': FAILED" % ext_envir.RiskFactorRepository().envir)
    try:
        rc_api = api.risk_factor_curator_api()
        print("\t Risk Factor Curator    '%s': https://%s/swagger-ui.html" % (ext_envir.RiskFactorRepository().envir, rc_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Risk Factor Curator    '%s': FAILED" % ext_envir.RiskFactorRepository().envir)

    print("SE connection status:")
    try:
        sd_api = api.historical_scenario_definer_api()
        print("\t Scenario definer       '%s': https://%s/swagger-ui.html" % (ext_envir.ScenarioEngine().envir, sd_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Scenario definer       '%s': FAILED" % ext_envir.ScenarioEngine().envir)

    try:
        sg_api = api.scenario_generator_api().historical_scenario
        print("\t Scenario generator     '%s': https://%s/swagger-ui.html" % (ext_envir.ScenarioEngine().envir, sg_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Scenario generator     '%s': FAILED" % ext_envir.ScenarioEngine().envir)

    try:
        fr_api = api.se_full_reval_api()
        print("\t Scenario full reval    '%s': https://%s/swagger-ui.html" % (ext_envir.ScenarioEngine().envir, fr_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Scenario full reval    '%s': FAILED" % ext_envir.ScenarioEngine().envir)

    try:
        ro_api = api.report_orchestrator_api()
        print("\t Report orchestrator    '%s': https://%s/swagger-ui.html" % (ext_envir.ScenarioEngine().envir, ro_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Report orchestrator    '%s': FAILED" % ext_envir.ScenarioEngine().envir)

    print("Trade service connection status:")
    try:
        tp_api = api.trade_position_api().position_controller
        print("\t Trade information      '%s': https://%s/swagger-ui.html" % (ext_envir.TradePositionGateway().envir, tp_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Trade information      '%s': FAILED" % ext_envir.TradePositionGateway().envir)

    try:
        vp_api = api.virtual_portfolio_api()
        print("\t Virtual portfolio      '%s': https://%s/swagger-ui.html" % (ext_envir.TradePositionGateway().envir, vp_api.api_client.configuration.host[8:]))
    except Exception as e:
        print("\t", e)
        print("\t Virtual portfolio      '%s': FAILED" % ext_envir.TradePositionGateway().envir)


if __name__ == '__main__':
    connection_tests(ext_envir.RiskFactorRepository.uat,
                     ext_envir.ScenarioEngine.uat,
                     ext_envir.TradePositionGateway.uat)
