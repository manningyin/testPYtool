GateKeeper: Joerg


Availability tests verify the responsiveness of external components (e.g. databases, services, libraries etc.).
As such, they basically ping the component and send a brief "Are you up and running?"-request and verifying the response message. Availability tests should:
-	Test availability and responsiveness, only.
-	Return True or False and potentially a log-message.
-	Be callable by other programs.
