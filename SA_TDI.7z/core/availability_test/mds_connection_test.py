from core.connection import credentials
import requests


def mds_connection_test():
    service_arg = "http://mds.oneadr.net/v1/marketdata/prices/reval?Isins=DK0009792525&TradeDate=2017-04-28&format=json"
    auth = credentials.get_HttpNtlmAuth()
    headers = {'accept': 'application/json;odata=verbose'}
    response = requests.post(url=service_arg,
                             auth=auth,
                             headers=headers)

    status_code = response.status_code
    return 200 <= status_code < 300


if __name__ == '__main__':
    print(mds_connection_test())