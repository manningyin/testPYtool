from core.utils import timeout
from core.connection import orca_connect
from orca import types
import datetime as dt
import quantum as qt
req = orca_connect.get_orca_request()


@timeout.timeout(10)
def orca_rf_service_test():
    test1 = req.request_interest_rate_risk_factors(qt.Currency.USD).result()
    test2 = req.request_bond_risk_factors(['IT0000366655']).result()
    return test1, test2


@timeout.timeout(50)
def orca_pricing_test():
    trade_identifiers = [types.TradeIdentifier(trade_id='3042110', source_system=types.SourceSystem.INFINITY)]
    test = req.request_price(time_stamp=orca_connect.get_orca_timestamp(dt.datetime(2018, 6, 28, 23, 59)),
                             model_configuration_context=types.ModelConfigurationContext.make_eod_context(),
                             trade_identifiers=trade_identifiers,
                             scenarios=[]).result()
    return test


def orca_connection_test():
    try:
        orca_rf_service_test()
        print("Orca risk factor service is working")
    except Exception as e:
        print("Orca risk factor service failed. Likely Orca is down")
        print(e)
    try:
        orca_pricing_test()
        print("Orca pricing service is working")
    except Exception as e:
        print("Orca pricing service failed.")
        print(e)


if __name__ == '__main__':
    orca_connection_test()
