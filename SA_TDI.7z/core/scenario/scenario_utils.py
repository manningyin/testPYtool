import six
if six.PY2:
    import cPickle as pickle
else:
    import pickle
import enum
import datetime as dt
import hashlib
import quantum as qt
from core.utils import version_independent
from core.caching import cache_driver
from core.market_data import damd_helper
from core.market_data.market_data_loader import DamdsLoader
from core.types import market_data_object, _scenarios
from core.connection import orca_connect
from core.utils import error_handler
from core.utils import shock_days
import core.types
from copy import deepcopy
import orca.types

def empty_scenario(scenario):
    """
    Checks whether the scenario is empty, corresponding to no scenario AKA base valuation

    Notes:
        Author: g48454
    """
    if scenario in [None, [None], []]:
        return True
    return False


def is_disc_curve(rf_name):
    return '.DISC.' in rf_name and 'RATE.' in rf_name


def is_fwd_curve(rf_name):
    return '.FWD.' in rf_name and 'RATE.' in rf_name


def is_fx_spot(rf_name):
    return 'FX.SPOT.' in rf_name


def is_hazard_curve(rf_name):
    return 'CREDIT.HAZARD.' in rf_name


def valid_scenario(scenario):
    """
    Checks whether the input scenario is in a valid format for ORCA/qToolkit to interpret

    Notes:
        Author: g48454
    """
    accepted_datatypes = (int, float, qt.CurveCatrom, qt.CurveLinear, qt.CurveFlat, qt.SurfaceDateTenorLinear)
    if isinstance(scenario, orca.types.Scenario) and isinstance(scenario.type, orca.types.ScenarioType) and isinstance(scenario.data, accepted_datatypes) :
        return True
    else:
        return False


def format_scenarios(scenarios):
    """
    Formats scenario inputs from market data object to qt object and checks the validity of all scenario in a list.
    Only return valid scenario - invalid scenario will be thrown and an error is tracked

    Notes:
        Author: g48606
    Edited by:
        g01571
    """
    scenarios = deepcopy(scenarios)
    out = []
    for scenario in scenarios:
        if hasattr(scenario, 'data') and isinstance(scenario.data, core.types.MarketDataObject):
            scenario = orca.types.Scenario(name=scenario.name, type=scenario.type, data=scenario.data.qt_object)
        elif isinstance(scenario, dict):
            sc_data = scenario['data'].qt_object if isinstance(scenario['data'], core.types.MarketDataObject) else scenario['data']
            sc_type = getattr(orca.types.ScenarioType, scenario['type']) if isinstance(scenario['type'], str) else scenario['type']
            scenario = orca.types.Scenario(name=scenario['name'], type=sc_type, data=sc_data)

        if valid_scenario(scenario):
            out.append(scenario)
        else:
            error_handler.track_error(error_message='Invalid scenario', identifier=str(scenario),
                                      comments='Scenario is not a valid format')
    return out


def scenarios_unique_key(scenarios):
    """
    Generates a unique string from a list of scenarios with types that are either a qToolkit curve or a float

    Notes:
        Author: g48606
    """
    output = []
    for scenario in scenarios:
        sc_dict = scenario.__dict__ if isinstance(scenario, orca.types.Scenario) else scenario
        sc_type = sc_dict['type'].name if isinstance(sc_dict['type'], enum.Enum) else sc_dict['type']
        if hasattr(sc_dict['data'], 'typename') and hasattr(sc_dict['data'], 'vals') and hasattr(sc_dict['data'], 'dates'):
            name = sc_dict['data'].typename
            dates = sc_dict['data'].dates
            vals = sc_dict['data'].vals
            temp_dict = {'name': sc_dict['name'], 'type': sc_type, 'data': [name, dates, vals]}
        elif hasattr(sc_dict['data'], 'typename') and hasattr(sc_dict['data'], 'surfaceDates') and hasattr(
            sc_dict['data'], 'surfaceTenors') and hasattr(sc_dict['data'], 'surfaceValues'):
            name = sc_dict['data'].typename
            dates = sc_dict['data'].surfaceDates
            vals = sc_dict['data'].surfaceValues
            vals = [x.data for x in vals.data]
            tenors = sc_dict['data'].surfaceTenors
            temp_dict = {'name': sc_dict['name'], 'type': sc_type, 'data': [name, dates, tenors, vals]}
        elif isinstance(sc_dict['data'], version_independent.num_types):
            temp_dict = {'name': sc_dict['name'], 'type': sc_type, 'data': sc_dict['data']}
        else:
            raise NotImplementedError("Scenario data type not recognized for scenario: %s" % str(sc_dict))
        output.append(temp_dict)
    sorted_dict = sorted(output, key=lambda x: (x['name'], x['type'], x['data']))
    dict_string = str(sorted_dict)
    dump = pickle.dumps(dict_string, -1)
    unique_key = hashlib.md5(dump).hexdigest()
    return unique_key


@cache_driver.memory_cache
def scenario_dates(eod_date, observation_period):
    """
    Returns specific dates for which historical scenarios should be generated.

    This is done based on current reporting date (eod_date) and type of risk calculation (RTPL, stress, or current period).

    Args:
        eod_date            (datetime.date):                    Base date of the calculation corresponding to "today".
        observation_period  (scenario_types.ObservationPeriod): Type of calculation as object. That being RTPL,
                                                                stressed period or current period.

    Returns:
        (list of date): Dates for which we need scenario (shocks) to in order to do the required calculation.

    Example:
        The module is called (from python) like this:

            >>> from core.scenario import scenario_utils
            >>> from core.types import _scenarios
            >>> import datetime

            >>> scenario_utils.scenario_dates(datetime.date(2018,4,5), _scenarios.ObservationPeriod.RTPL)
            [datetime.date(2018, 4, 6)]

    Notes:
        Author: Shengyao (documented by JBrandt)
    """
    if observation_period == _scenarios.ObservationPeriod.RTPL:
        out = shock_days.workout_rtpl_scenario_dates(eod_date)
    elif observation_period == _scenarios.ObservationPeriod.VAR:
        out = shock_days.workout_var_scenario_dates(eod_date)
    elif observation_period in [_scenarios.ObservationPeriod.CURRENT,
                                _scenarios.ObservationPeriod.CURRENT_1d]:
        out = shock_days.workout_1y_scenario_dates(eod_date)
    elif observation_period == _scenarios.ObservationPeriod.STRESSED:
        out = shock_days.workout_1y_scenario_dates(dt.date(2010, 9, 30))
    else:
        raise NotImplementedError("The Observation Period have not been implemented" + str(observation_period))
    return out


def market_data_range(scenario_dates, observation_period, eod_date):
    """
    Determines the first and last scenario dates, thereby translating a list of dates into a min-max range.

    For FRTB historical scenarios the function subtracts 10 business days from the scenario dates, in order to
    determine the first date for which we need market data.

    Args:
        scenario_dates          (list of date):         All dates for which we will calculate a historical shock
        observation_period      (ObservationPeriod):    Usage of the historical scenarios, implicitly containing information
                                                        about how far scenarios should go back
        eod_date                (date):                 Date of the market data for which the scenarios (shocks)
                                                        will be applied to.

    Returns:
        (list of date):   First and last dates in the date range for which we need market data.

    Example:

        >>> import datetime
        >>> from core.types import _scenarios
        >>> from core.scenario import scenario_utils

        >>> min_max_dates = scenario_utils.market_data_range(
        ...                                 scenario_dates      = [datetime.date(2017,1,15), datetime.date(2017,1,16)],
        ...                                 observation_period  = _scenarios.ObservationPeriod.RTPL,
        ...                                 eod_date            = datetime.date(2017,1,20))
        >>> min_max_dates
        [datetime.date(2017, 1, 20), datetime.date(2017, 1, 15)]

    Notes:
        Author: Shengyao (documented by JBrandt)
    """
    if observation_period == _scenarios.ObservationPeriod.RTPL:
        out = [eod_date, scenario_dates[0]]
    elif observation_period in [_scenarios.ObservationPeriod.CURRENT,
                                _scenarios.ObservationPeriod.STRESSED,
                                _scenarios.ObservationPeriod.CURRENT_1d,
                                _scenarios.ObservationPeriod.VAR]:
        d_list = sorted(scenario_dates)
        global_holiday = shock_days.get_global_holidays()
        # TODO: Is it still required to substract 10 business days (after both DAMDS and MD Hub delivers the from-to shocks)?
        out = [qt.addBusinessDays(d_list[0], '-10B', global_holiday), d_list[-1]]
    else:
        raise NotImplementedError("The Observation Period have not been implemented" + str(observation_period))
        # TODO: Consider changing ouput to dictionay with keys: 'first','last' (min/max or similar) to avoid implicit dependency of order in list.
    return out


@cache_driver.easy_cache()
def convert_zero_coupon(eod_date, riskfactor, tenor_based_curve, tenor_based_zero_scenario):
    """
    Converts a zero coupon scenario to a forward rate scenario using Orca service.

    This is done using as input the market data for the ZC curve at d1, and the ZC scenario between d1 and d2.
    The output will have the same tenors as the ZC curve, and thus the scenario will be interpolated (linearly) to
    match this.

    Args:
        eod_date                    (date):
        riskfactor                  ():
        tenor_based_curve           ():
        tenor_based_zero_scenario   ():

    Returns:
        ():

    Notes:
        Author: g48454 (Shengyao Zhu)
    """

    req = orca_connect.get_orca_request()
    scenario = [(eod_date, riskfactor, tenor_based_curve, tenor_based_zero_scenario)]
    converted_scenario = req.convert_tenor_based_curve_scenarios(scenario).result()

    return converted_scenario


def convert_fx_spot(risk_factor_name, value_1, value_2):
    """
    Ensuring that market data has EUR as FOREIGN currency.

    DAMDS currently receives market data for FX spot with EUR always being the domestic currency.
    ORCA only accepts currency pairs corresponding to market standard, which dictates that EUR should always be foreign
    currency.

    NB: This function is a patching solution, and should be replaced with ORCAs FX spot scenario converter service

    Args:
        risk_factor_name    (str):      Name of the risk factor in (opposite) "Orca format" (FOREIGN/DOMESTIC)
        value_1             (float):    Shock "from" fx spot value
        value_2             (float):    Shock "to" fx spot value

    Returns:
        (tuple): Scenario name , "from" fx spot value w. EUR as foreign cur, "to" fx spot value w. EUR as foreign cur

    Notes:
        Author: g48606 (Oskar Rosendal - documented by JBrandt g50444)
    """

    if "FX.SPOT" not in risk_factor_name:
        raise Exception("This function is only supposed to be called for FX Spot risk factors")

    # RF name is on the form "FX.SPOT.FOREIGN/DOMESTIC", we convert to ['FOREIGN', 'DOMESTIC', 'FX', 'SPOT']
    split_string = risk_factor_name.replace('/', '.').split('.')

    # If the third element of list is already 'EUR', we don't make a conversion and return original input as output
    if split_string[2] == 'EUR':
        out = risk_factor_name, value_1, value_2
    else:
        # String is patched together as "FX.SPOT.DOMESTIC/FOREIGN"
        new_name = split_string[0] + '.' + split_string[1] + '.' + split_string[3] + '/' + split_string[2]
        out = new_name, 1.0 / value_1, 1.0 / value_2
    return out


@cache_driver.easy_cache()
def load_fwd_market_data(date, risk_factor):
    """
    This function loads zero coupon market data with the defined GLOBAL TENORS (52 buckets), to be used for generating
    forward rate scenarios

    Args:
        date_     (date):    date to load data for

    Returns:
        (TermStructure):   term structure object defined in core.types.market_data_object

    Notes:
        Author: g48606 (Oskar Rosendal)
    """

    # TODO: Not currently working...
    mdc = ContextFactory(scope='MarketData',
                         mapping='damds',
                         consulTag='uat',
                         id='marketData-HS')
    mdm = get_mapping_from_context(mdc)

    forward_md_mapping = [x for x in mdm if is_fwd_curve(x['riskfactor']['curveName'])]
    md_ids = [x['mdmapping']['marketDataId'] for x in forward_md_mapping]

    curve_mapping = {}
    for x in forward_md_mapping:
        curve_mapping.setdefault(x['riskfactor']['curveName'], []).append(x['mdmapping']['marketDataId'])

    dat = DamdsLoader(market_data_ids=md_ids, startd=date, endd=date, timeseries_type=damd_helper.TimeSeriesType.SHOCK).data
    dat = dat[dat['shock_horizon'] == 10]

    out = {}
    for key, values in curve_mapping.iteritems():
        tmp = market_data_object.TermStructure.from_shock_table(dat[dat['market_data_id'].isin(values)],
                                                                interpolation_type=market_data_object.CurveInterpolation.CurveSpline)
        # The market data is loaded as percentage points, thus we divide by 100
        out[key] = tmp/100
    return out


if __name__ == '__main__':
    # from core.scenario import scenario_utils
    # from core.types import scenario_types
    # import datetime
    #
    # dates = scenario_utils.work_out_scenario_dates( datetime.date(2018,4,5),
    #                                                 scenario_types.ObservationPeriod.RTPL
    #                                                 )
    # print(dates)
    # import datetime
    # min_max_dates = market_data_range(scenario_dates      = [datetime.date(2017, 1, 15), datetime.date(2017, 1, 16)],
    #                                   observation_period  = scenario_types.ObservationPeriod.RTPL,
    #                                   eod_date            = datetime.date(2017,1,20)
    #                                   )
    # print(min_max_dates)
    import quantum as qt
    uk = scenarios_unique_key([{'name': 'sc_name',
                                'type': 'MULT',
                                'data': qt.CurveCatrom.make(dates=[dt.datetime(2018,1,1), dt.datetime(2019,1,1)],
                                                            vals=[0.01, 0.02])}])
    print(uk)
    # [datetime.date(2017,1,15),datetime.date(2017,1,20)]
