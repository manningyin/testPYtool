import os
from core.connection import api
from core.system import ext_envir
from report_orchestrator.models import report_configuration, execution_method_configuration, scenario_execution_configuration, portfolio_config
_FIRST_RUN_ORCA = dict(define=True, generate=True, prepare=True)


def _is_first_run(name):
    # Global variable function to ensure swagger addresses are only printed once calling functions in a script
    global _FIRST_RUN_ORCA
    if _FIRST_RUN_ORCA[name]:
        _FIRST_RUN_ORCA[name] = False
        return True
    return False


class DefineReport:
    def __init__(
            self,
            name,
            description,
            scenario_type,
            virtual_pf_names,
            high_level_scenario_ids=None,
            high_level_scenario_names=None,
            execution_method='ORCA_FULL_REVAL_MESSAGE',
            sink='csv-incubator-cl',
            owner=os.getenv('username'),
            tags=None
    ):
        if high_level_scenario_ids is None and high_level_scenario_names is None:
            raise ValueError("You must provide either high level scenario ids or names")
        self.high_level_scenario_names = high_level_scenario_names if high_level_scenario_names is not None else []
        self.high_level_scenario_ids = high_level_scenario_ids if high_level_scenario_ids is not None else []
        self.high_level_scenario_ids.extend(self.get_scenario_ids())
        self.virtual_pf_names = [virtual_pf_names] if not isinstance(virtual_pf_names, list) else virtual_pf_names
        self.name = name
        self.description = description
        self.execution_method = execution_method
        self.scenario_type = scenario_type
        self.sink = sink
        self.owner = owner
        self.tags = tags if tags is not None else []

    def get_scenario_ids(self):
        sd_api = api.historical_scenario_definer_api()
        out = []
        for name in self.high_level_scenario_names:
            try:
                hls = sd_api.get_historical_scenario_by_name(name)
                out.append(hls.id)
            except:
                continue
        return out

    def scenario_configs(self):
        """
        Creates the scenario execution method configuration
        :return:
        """
        exec_config = execution_method_configuration.ExecutionMethodConfiguration(execution_method=self.execution_method, sink=self.sink)
        out = []
        for hls_id in self.high_level_scenario_ids:
            out.append(scenario_execution_configuration.ScenarioExecutionConfiguration(
                execution_method_configurations=[exec_config],
                high_level_scenario_id=hls_id,
                relative_eod_date=None,
                scenario_type=self.scenario_type))
        return out

    def report_configuration_json(self):
        """
        Creates a ReportConfiguration which can be passed to the Report-Orchestrator swagger-ui.
        :param version:
        :return:
        """
        ro_api = api.report_orchestrator_api()
        try:
            response = ro_api.get_report_configuration_by_name(self.name)
            cur_version = response.version
            # cur_version = 1 if cur_version is None else cur_version
            ro_id = response.id
        except Exception as e:
            cur_version = None
            ro_id = None

        pf_config = portfolio_config.PortfolioConfig(virtual_portfolio_names=self.virtual_pf_names)
        report_configuration_json = report_configuration.ReportConfiguration(
            description=self.description,
            id=ro_id,
            last_update_by=self.owner,
            last_update_on=None,
            portfolio_config=pf_config,
            name=self.name,
            owner=self.owner,
            scenario_execution_configurations=self.scenario_configs(),
            tags=self.tags,
            version=cur_version)
        return report_configuration_json

    def upsert_report_configuration(self):
        """
        Takes the created report configuration and uploads it to Report-Orchestrator MongoDB.
        :param info:
        :return:
        """
        ro_api = api.report_orchestrator_api()
        if _is_first_run('define'):
            print('Report orchestrator: %s/swagger-ui.html' % ro_api.api_client.configuration.host)
        json = self.report_configuration_json()
        if json.id is None:
            out = ro_api.save2(report_configuration=json)
            out_ver = 0
        else:
            out = ro_api.update1(id=json.id, report_configuration=json)
            out_ver = json.version + 1
        print("Version %s of report configuration with name '%s' has been upserted to Report-Orchestrator '%s' environment"
              % (out_ver, self.name, ext_envir.ScenarioEngine().envir))

        return out


if __name__ == '__main__':
    myReport = DefineReport(high_level_scenario_names=['TRIM Mortgage Bond IR - Historic'], name='test_report', description='oskar_tests_a_report', scenario_type='HISTORICAL')
    print(myReport.upsert_report_configuration())