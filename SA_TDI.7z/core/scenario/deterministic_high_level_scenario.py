import json
import os
import uuid
import quantum as qt
from scenario_definer.models import deterministic_scenario, time_series_config, portfolio_config, relative_interval, fixed_interval
from core.utils import version_independent
from core.connection import api
from core.types import _scenarios
from core.utils import date_helper
from core.system import ext_envir
from scenario_definer.rest import  ApiException


_FIRST_RUN_ORCA = dict(define=True, generate=True, prepare=True)


def _is_first_run(name):
    # Global variable function to ensure swagger addresses are only printed once when calling functions in a script
    global _FIRST_RUN_ORCA
    if _FIRST_RUN_ORCA[name]:
        _FIRST_RUN_ORCA[name] = False
        return True
    return False


class DefineDeterministiScenario:
    """
    Class used for defining a high_level_scenario that holds risk factors, mapping, scenario_dates, shock horizon and
    everything else that is required for generating scenarios.

    Args:
        rf_context_id                     (str): Context id for risk factors
        rf_mapping_id                     (str): Corresponding market data mapping for risk factors
        md_context_ids     (str or list of str): Context id for pricing factors (used for forward rate scenarios)
        md_mapping_ids     (str or list of str): Corresponding market data mapping for pricing factors
        portfolio_ids (tuple or list of tuples): Portfolios to be used in the high level scenario. Must be given as
                                                 tuples where index 0 is portfolio name and index 1 is source system
        name                              (str): High level scenario name
        observation period               (enum): Which observation period to use (eg. VaR / RTPL / Stressed). Must be
                                                 given using the core.types.scenario_types.ObservationPeriod enum
        owner                             (str): Owner of the high level scenario
        calendar_type                     (str): Which calendar type to use. Can be 'MARKET_RISK' (MARS) or 'EURO'

    Notes:
        Author: g48606
    """
    def __init__(self,
                 md_context_ids,
                 md_mapping_ids,
                 virtual_pf_names,
                 risk_class=None,
                 name=str(uuid.uuid4()),
                 owner=os.getenv('username')
                 ):
        # Input arguments which should be a list are converted to list if they are string types
        self.md_context_ids = [md_context_ids] if isinstance(md_context_ids, version_independent.string_types) else md_context_ids
        self.md_mapping_ids = [md_mapping_ids] if isinstance(md_mapping_ids, version_independent.string_types) else md_mapping_ids
        self.virtual_pf_names = [virtual_pf_names] if not isinstance(virtual_pf_names, list) else virtual_pf_names
        self.name = name
        self.owner = owner
        self.risk_class = risk_class

    def deterministic_scenario_json(self, version):
        """
        Creates a historical scenario which can be passed to the scenario-definer swagger-ui. While it is an instance
        of the scenario_definer.models.historical_scenario.HistoricalScenario, it essentially works just like a
        dictionary
        """
        pf_config = portfolio_config.PortfolioConfig(virtual_portfolio_names=self.virtual_pf_names)
        scenario_spec_shocks = self.get_scenario_spec_shocks()
        ds = deterministic_scenario.DeterministicScenario(
                                                          last_update_by=self.owner,
                                                          market_data_md_mapping_contexts_ids=self.md_mapping_ids,
                                                          market_data_risk_factors_contexts_ids=self.md_context_ids,
                                                          name=self.name,
                                                          owner=self.owner,
                                                          portfolio_config=pf_config,
                                                          risk_class=self.risk_class,
                                                          scenario_spec_shocks=scenario_spec_shocks,
                                                          version=version)

        return ds

    def upsert_scenario(self, info=1):
        """
        Takes the created historical and uploads it to the ScenarioEngine MongoDB. The uploaded scenario is then
        returned back, and the ID can be found by getting the 'id' key of the return
        """
        sd_api = api.deterministic_scenario_definer_api()
        if info > 0:
            if _is_first_run('define'):
                print("Scenario definer: %s/swagger-ui.html" % sd_api.api_client.configuration.host)
        try:
            fetched_scenario = sd_api.get_deterministic_scenario_by_name(self.name)
        except ApiException as e:
            fetched_scenario = deterministic_scenario.DeterministicScenario()

        version = fetched_scenario.version
        scenario_id = fetched_scenario.id

        json = self.deterministic_scenario_json(version=version)

        # Check if the scenario name already exists. If it does, replace it. Else, upload the scenario.
        if scenario_id is not None:
            out = sd_api.update_deterministic_scenario(id=scenario_id, sc_entity=json)
            uploaded_version = version + 1
        else:
            out = sd_api.save_deterministic_scenario(json)
            uploaded_version = version
        if info > 0:
            print("Version %s of high level scenario with name '%s' has been upserted to ScenarioEngine '%s' "
                  "environment." % (uploaded_version, self.name, ext_envir.ScenarioEngine().envir))
        return out

    #TODO: Think a way to write this
    def get_scenario_spec_shocks(self):

        out =[
        {
            "riskFactorsContextId" : "irm_cs_mars",
            "riskFactorMappingContextId" : "master_mars",
            "simulationShocks" : [
                {
                    "scenarioName" : "10000342",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 0,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 0,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 0,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020101",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : -0.99,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : -0.99,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : -0.99,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020102",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : -0.75,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : -0.75,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : -0.75,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020103",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : -0.5,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : -0.5,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : -0.5,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020104",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : -0.25,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : -0.25,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : -0.25,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020105",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 0.25,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 0.25,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 0.25,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020106",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 0.5,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 0.5,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 0.5,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020107",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 1,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 1,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 1,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020108",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 2,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 2,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 2,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020109",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 4,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 4,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 4,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020110",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 6,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 6,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 6,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020111",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 9,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 9,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 9,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020112",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 14,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 14,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 14,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020113",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 24,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 24,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 24,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                },
                {
                    "scenarioName" : "10020114",
                    "riskFactorTypeShocks" : [
                        {
                            "riskFactorType" : "RfBondSwapBasis",
                            "shockType" : "RELATIVE",
                            "scenarioShocks" : [
                                {
                                    "value" : 49,
                                    "term" : "5Y"
                                },
                                {
                                    "value" : 49,
                                    "term" : "10Y"
                                },
                                {
                                    "value" : 49,
                                    "term" : "2Y"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
        return out

