"""
This is a class that generates scenarios given risk factors and scenario days. This is done by taking
market data. One usage example can be seen at the main.

Notes:
    Author: g01571 (ABaglan)
"""
import core.types
from core.scenario.data_enricher_prototype import DataEnricher
from core.types._scenarios import MarketDataSourceType
from core.market_data import mars_helper as mars_helper
from core.utils import date_helper as date_helper
from core.types._scenarios import ObservationPeriod
import pyodbc
from core.connection import database_connect
from core.types._scenarios import ShockType
import pandas as pd
import time
from core.position import position_service, valuation_service
from core.risk import risk_measures
from core.risk_factor.collection import RiskFactorCollection
from core.risk_factor.pricing_factor import from_risk_factor
from core.connection import orca_connect
from core.types import market_data_object
from core.caching.cache_driver import easy_cache
from core.utils.date_helper import sort_tenors


class ScenarioGenerator(object):
    def __init__(self, valuation_date, dates, risk_factors, scenarios_as_market_data_object=False):
        """

        :param dates:   A dataframe with start_day, end_day columns
        :param risk_factors: A list of risk factors to compute scenarios
        """
        self.valuation_date = valuation_date
        self.dates = dates
        self.risk_factors = risk_factors
        self.output_cols = []
        self.scenarios_as_market_data_object = scenarios_as_market_data_object
        self.rf_to_md_id = {}
        for r in self.risk_factors:
            self.rf_to_md_id[from_risk_factor(r)] = r.mdmapping['mars_risk_factor_id']

    def conversion(self, sc_list, conn):
        @easy_cache()
        def get_market_data_zero(interest_id, date):
            sql = """
            select a.* 
            from marsp.hs_interest_rate a, marsp.ladder_term b
            where a.INTEREST_ID = {interest_id}
            and a.eod_date = {date}
            and a.TERM_ID = b.TERM_ID
            and b.LADDER_ID = 68
            order by 3 """.format(date=date_helper.oracle_to_date(date), interest_id=interest_id)

            out = pd.read_sql(sql, conn)
            out = out[out['TERM_ID'] != '1.5Y']
            return out

        req = orca_connect.get_orca_request()
        for sc_pack in sc_list:
            sc_date = sc_pack['scenario_date'].date()
            now_scenarios = []
            fwd_scenarios = []
            for sc in sc_pack['scenarios']:
                if 'FWD' not in sc['name']:
                    now_scenarios.append(sc)
                    continue
                rf_name = sc['name']
                zero_market_id = self.rf_to_md_id[rf_name]
                zero_curve_market_data = get_market_data_zero(zero_market_id, self.valuation_date)
                curve_tenors = list(zero_curve_market_data['TERM_ID'])
                curve_values = list(zero_curve_market_data['INTEREST_PCT'] / 100)
                zero_curve = {'interpolation': 'linear',
                              'tenors': curve_tenors,
                              'values': curve_values}

                shift = {'interpolation': 'linear',
                         'tenors': date_helper.sort_tenors(sc['data'].data.index.tolist()),
                         'values': sc['data'].qt_object.vals}
                fwd_scenarios.append((self.valuation_date, rf_name, zero_curve, shift))

            converted = req.convert_tenor_based_curve_scenarios(fwd_scenarios).result()
            converted_scenarios = [{'name': a.curve_name,
                                    'type': a.scenario_type,
                                    'data': market_data_object.TermStructure.make(vals=a.curve.vals,
                                                                                  tenors=sort_tenors(curve_tenors),
                                                                                  valuation_date=sc_date)}
                                   for a in converted]

            print("converted {} scenarios".format(len(converted_scenarios)))
            now_scenarios += converted_scenarios
            sc_pack['scenarios'] = now_scenarios
        return sc_list

    def get_shock(self, df):
        """
        Does the bulk operation of creating shock data

        :param df:
        :return:
        """

        shock_type = df['shock_type'].iloc[0]
        now_df = pd.DataFrame()
        now_df['scenario_date'] = df['end_date']
        now_df['sc_start_date'] = df['start_date']
        now_df['sc_end_date'] = df['end_date']
        now_df['name'] = df['gen_risk_factor_id']
        now_df['type'] = df['shock_type']
        if shock_type == ShockType.ADDITION.value:
            now_df['data'] = (df['end_value'] - df['start_value'])
        elif shock_type == ShockType.MULTIPLICATION.value:
            now_df['data'] = (df['end_value'] / df['start_value'])
        else:
            raise Exception('Unknown shock type')

        if not self.scenarios_as_market_data_object:
            now_df['data'] = now_df['data'].apply(lambda x: x.qt_object)

        return now_df

    def get_shock_df(self, data):
        """
                Creates a dataframe such as

        Input:

        # ===================================================================================
        # start_date    |   start_value |   end_date    |   end_value   |   *** shock_type
        # ===================================================================================
        # 05/01/2019        Point()         06/01/2019      Point()     ****    MULTIPLICATION
        # 05/01/2019        TermSt()         06/01/2019      TermSt()    ****    ADDITION
        # 06/01/2019        Point()         06/01/2019      Point()     ****    MULTIPLICATION
        # 06/01/2019        TermSt()         06/01/2019      TermSt()    ****    ADDITION
        # 07/01/2019        Point()         06/01/2019      Point()     ****    MULTIPLICATION
        # 07/01/2019        TermSt()         06/01/2019      TermSt()    ****    ADDITION
        # ===================================================================================

        Output:

        # ==================================================================================
        # scenario_date    |       data      |      name       |   type   |
        # ===================================================================================
        # 05/01/2019             Point()            ORCA_NAME    MULTIPLICATION
        # 05/01/2019             TermSt()           ORCA_NAME     ADDITION
        # 06/01/2019             Point()            ORCA_NAME     MULTIPLICATION
        # 06/01/2019             TermSt()           ORCA_NAME     ADDITION
        # 07/01/2019             Point()            ORCA_NAME     MULTIPLICATION
        # 07/01/2019             TermSt()           ORCA_NAME     ADDITION
        # ===================================================================================
        :param data:
        :return:
        """
        operation_group = data.groupby('shock_type')
        shock_df = operation_group.apply(self.get_shock)
        return shock_df


    def create_scenarios(self, data_source, conn, eliminate_threshold=-1, do_local_scaling=True, conversion=True):
        """
        One line description. Then an empty line - followed by multi-line detailed description.

        Args:
            data_source    (MarketDataSourceType): Data Source to get the data
            conn            (pyodbc.connection): Connection to the database
            eliminate_threshold (float) : the threshold that we fetch data.
                                        (i.e if eliminate_threshold=0.1 risk_factors that does not have %10 of all
                                        scenario days data, we eliminate that factor)
            do_local_scaling    : a boolean that sets doing local scaling

        Returns:
            (type): List of scenarios
                    i.e [ day1: [{sc_r1_d1}, {sc_r2_d1}], day2: [{sc_r1_d2}, {sc_r2_d2}]

        Example:
            The module is called (from python) like this::

                # Code Example Here...

        Notes:
            Author: g01571
        """

        # ===================================================================================
        # ENRICH THE DATA
        # ===================================================================================
        enricher = DataEnricher(data_source, conn)
        data = enricher.get_market_data(self.risk_factors, self.valuation_date, self.dates, eliminate_threshold,
                                        do_local_scaling=do_local_scaling)

        # ===================================================================================
        # GET THE SHOCK DATA
        # ===================================================================================
        shock_df = self.get_shock_df(data)

        # ===================================================================================
        # CREATE AS A LIST OF DICTS
        # ===================================================================================
        days_group = shock_df.groupby(['scenario_date', 'sc_start_date', 'sc_end_date'])
        sc_list = [{'scenario_date': day[0], 'sc_start_date':day[1], 'sc_end_date':day[2], 'scenarios': group[['name', 'type', 'data']].to_dict('records')}
                   for day,group in days_group]

        print('Doing conversion')
        if conversion:
            sc_list = self.conversion(sc_list, conn)

        return sc_list


if __name__ == "__main__":
    compute_pl = True

    t_start = time.time()

    connection = pyodbc.connect(database_connect.get_string('INFOP'))
    eod = date_helper.yesterday_as_date()
    sc_type = ObservationPeriod.VAR

    # ===================================================================================
    # Create Scenario Days
    # ===================================================================================
    sc_days = mars_helper.get_mars_sc_start_end_days(sc_type,eod, connection)

    print("Time elapsed for getting dates %s" % (time.time() - t_start))
    t_start = time.time()
    # ===================================================================================
    # Get risk factors
    # ===================================================================================

    rf_list = RiskFactorCollection().rfr_load_from_md_map_context('master_mars').risk_factor_list

    print("Time elapsed for getting risk factors %s" % (time.time() - t_start))
    t_start = time.time()
    # ===================================================================================
    # Create scenarios using database MARS
    # ===================================================================================
    source = MarketDataSourceType.MARS
    generator = ScenarioGenerator(dates=sc_days, risk_factors=rf_list)
    sc_list = generator.create_scenarios(source, connection, eliminate_threshold=0.1)

    # ===================================================================================
    # Compute PL
    # ===================================================================================
    if compute_pl:
        print("Time elapsed for getting scenarios %s" % (time.time() - t_start))
        t_start = time.time()

        # Portfolio
        # First we load positions. NB: Decide whether you want to include any unsettled positions for the calculation
        mars_book_id = [6100100]  # [70163, 6100100, 70133, 70113, 1093615, 1170378],
        pos = position_service.PositionServiceLoader(mars_book_id, eod, include_unsettled=False).data

        print("Time elapsed for getting portfolio %s" % (time.time() - t_start))
        t_start = time.time()

        # =================================================================================================================
        # CALCULATE PLs
        # =================================================================================================================

        # Then we create the PL vector by re-valuating each instrument individually in the provided mars book under the
        # total market data scenario and summing these for each scenario date.
        pricing_engine = core.types.PricingEngine.ORCA
        pl_vector = valuation_service.scenario_pl(positions=pos,
                                                  scenarios=sc_list,
                                                  eod_date=eod,
                                                  engine=pricing_engine,
                                                  aggregate=True)

        print("Time elapsed for getting PL %s" % (time.time() - t_start))
        t_start = time.time()

        # ==================================================================================================================
        # CALCULATE VAR
        # ==================================================================================================================
        # Finally we calculate the expected shortfall from the PL vector using the user provided quantile
        quantile = 0.01
        rm = risk_measures.RiskMeasures(pl_vector, quantile, risk_measures.PercentileOrientation.LOWER)
        print(rm)
        print(rm.expected_shortfall)

        print("Time elapsed for getting PL %s" % (time.time() - t_start))
        t_start = time.time()