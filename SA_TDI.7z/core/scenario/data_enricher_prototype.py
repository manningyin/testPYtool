"""
This is a class that attach and enrich information to the raw dataframe fetcheed from database

Notes:
    Author: g01571 (ABaglan)
"""

from core.risk_factor.collection import RiskFactorCollection
from core.types._scenarios import MarketDataSourceType
from core.market_data import mars_helper as mars_helper
from core.utils import date_helper as date_helper
from core.types._scenarios import ObservationPeriod
import pyodbc
from core.connection import database_connect
from core.risk_factor.pricing_factor import from_risk_factor
import pandas as pd
from core.types import market_data_object


class DataEnricher:
    def __init__(self, data_source, conn):
        self.data_source = data_source
        self.output_cols = ['start_date', 'start_value', 'end_date', 'end_value', 'gen_risk_factor_id', 'shock_type']
        self.conn = conn

    @classmethod
    def create_point_structure(cls, row):
        """
        input:
                # ===================================================================================
                # start_date    |   start_value |   end_date    |   end_value   |   *** shock_type
                # ===================================================================================
                # 05/01/2019        5               06/01/2019      6            ****    ADDITION
                # ===================================================================================

        output:
               # ===================================================================================
                # start_date    |   start_value |   end_date    |   end_value   |   *** shock_type
                # ===================================================================================
                # 05/01/2019        Point(5)         06/01/2019      Point(6)           ****    ADDITION
                # ===================================================================================

        :param row:
        :return:
        """
        start_date = row['start_date']
        start_val = row['start_value']
        start_val = market_data_object.Point.make(vals=start_val, valuation_date=start_date)
        end_date = row['end_date']
        end_val = row['end_value']
        end_val = market_data_object.Point.make(vals=end_val, valuation_date=end_date)
        row['start_value'] = start_val
        row['end_value'] = end_val
        return row

    def create_term_structure(self, df):
        """
        input:
                # ===================================================================================
                # start_date    |   start_value |   end_date    |   end_value   |   *** rf_with_tenor
                # ===================================================================================
                # 05/01/2019        5               06/01/2019      6            ****    rf(tenor=1M)
                # 05/01/2019        5               06/01/2019      6            ****    rf(tenor=2M)
                # 05/01/2019        5               06/01/2019      6            ****    rf(tenor=6M)
                # 05/01/2019        5               06/01/2019      6            ****    rf(tenor=1Y)
                # ===================================================================================

        output:
               # ===================================================================================
                # start_date    |   start_value         |   end_date    |   end_value   |   *** other info
                # ===================================================================================
                # 05/01/2019        TermStructure         06/01/2019      TermStructure  ****
                # ===================================================================================
        :param df:
        :return:
        """
        a = df.copy()
        a['risk_factor'] = a['risk_factor'].apply(str)
        a['md_mapping'] = a['md_mapping'].apply(str)
        a = a.drop_duplicates()
        df = df.loc[a.index]
        vals_start = list(df.start_value)
        tenors = list(df.risk_factor.apply(lambda x: x['tenor']))
        s_date = df.start_date.iloc[0]

        curve_start = market_data_object.TermStructure.make(vals=vals_start,
                                                            tenors=tenors,
                                                            valuation_date=s_date)
        vals_end = list(df.end_value)
        e_date = df.end_date.iloc[0]

        curve_end = market_data_object.TermStructure.make(vals=vals_end,
                                                          tenors=tenors,
                                                          valuation_date=e_date)

        id = df['gen_risk_factor_id'].iloc[0]
        shock_type = df['shock_type'].iloc[0]
        data = [[s_date, curve_start, e_date, curve_end, id, shock_type]]
        return pd.DataFrame(data,
                            columns=self.output_cols)

    def create_surface_structure(self, df):

        s_date = df.start_date.iloc[0]
        e_date = df.end_date.iloc[0]

        now_df = df.copy()
        now_df['tenor'] = df.risk_factor.apply(lambda x: x['tenor'])
        now_df['maturities'] = df.risk_factor.apply(lambda x: x['underlying_tenor'])

        start_df = now_df.pivot(index='maturities', columns='tenor', values='start_value')
        end_df = now_df.pivot(index='maturities', columns='tenor', values='end_value')
        surface_start = market_data_object.Surface.make(start_df.values, start_df.index, start_df.columns,
                                                        valuation_date= s_date)
        surface_end = market_data_object.Surface.make(end_df.values, end_df.index, end_df.columns,
                                                      valuation_date=e_date)

        id = df['gen_risk_factor_id'].iloc[0]
        shock_type = df['shock_type'].iloc[0]
        data = [[s_date, surface_start, e_date, surface_end, id, shock_type]]
        return pd.DataFrame(data,
                            columns=self.output_cols)

    def create_market_data_objects(self, data_processed):
        """
        Creates market data object (ie term structure, point structure for each risk factor)

        Args:
            data_processed    (DataFrame):

        Returns:
            (type): Description

        Notes:
            Author: g01571 (ABaglan)
        """

        risk_factor_group = data_processed.groupby(['gen_risk_factor_id', 'time_series_structure'])
        out = []
        for risk_type, group in risk_factor_group:
            if risk_type[1] == 'TimeSeriesStructure.POINT':
                df = group[self.output_cols]
                df = df.transform(DataEnricher.create_point_structure, axis=1)

            elif risk_type[1] == 'TimeSeriesStructure.CURVE':
                curve_group = group.groupby(['start_date'])
                df = curve_group.apply(self.create_term_structure)

            elif risk_type[1] == 'TimeSeriesStructure.SURFACE':
                surface_group = group.groupby(['start_date'])
                df = surface_group.apply(self.create_surface_structure)
            else:
                raise Exception('error')
            out.append(df)
        return pd.concat(out, axis=0).reset_index(drop=True)

    @classmethod
    def enrich_info(cls, data, risk_factors):
        """
        Attach information about the risk factor to the data frames in data using the risk factor list that was
        used to extract the data.
        Attaches:
                shock type to be used
                risk factor dict
                md_mapping dict
                gen_risk_factor_id (ORCA id )


        :param data:
        :param risk_factors:
        :return:

        Notes:
            Author: g01571 (ABaglan)
        """

        # Include this info to the dfs
        for i, df in enumerate(data):
            md_mapping = risk_factors[i].mdmapping
            risk_factor = risk_factors[i].riskfactor
            orca_id = from_risk_factor(risk_factor)
            ts_structure = risk_factors[i].time_series_structure
            df.loc[:, 'md_mapping'] = pd.Series([md_mapping] * len(df), index=df.index)
            df.loc[:, 'risk_factor'] = pd.Series([risk_factor] * len(df), index=df.index)
            df.loc[:, 'gen_risk_factor_id'] = pd.Series([orca_id] * len(df), index=df.index)
            df.loc[:, 'shock_type'] = pd.Series([risk_factors[i].shock_type.value] * len(df), index=df.index)
            df.loc[:, 'time_series_structure'] = pd.Series([str(ts_structure)] * len(df), index=df.index)

        data_processed = pd.concat(data, axis=0).reset_index(drop=True)
        return data_processed

    def get_market_data(self, risk_factors, valuation_date, dates, eliminate_threshold=-1, do_local_scaling=False):

        # ===================================================================================
        # FETCH DATA
        # ===================================================================================
        if self.data_source == MarketDataSourceType.MARS:
            print('fetching data')

            data = mars_helper.get_list_of_risk_factor_data_for_sc(risk_factors, valuation_date, dates, self.conn,
                                                                   local_scaling=do_local_scaling)

        elif self.data_source == MarketDataSourceType.DAMDS:
            raise Exception("No implementation for extracting data from DAMDS")
        elif self.data_source == MarketDataSourceType.MDHUB:
            raise Exception("No implementation for extracting data from MDHUB")
        else:
            raise Exception("Data Source %s not defined" % self.data_source)


        # ===================================================================================
        # ELIMINATE DATA
        # ===================================================================================
        if eliminate_threshold > 0:
            data = [df if len(df) > eliminate_threshold * len(dates) else pd.DataFrame(columns=df.columns) for df in data]

        # ===================================================================================
        # ENRICH DATA
        # ===================================================================================
        print('enriching data')
        data_processed = DataEnricher.enrich_info(data, risk_factors)

        # ===================================================================================
        # CREATE MARKET DATA OBJECT
        # ===================================================================================

        # Here we create market data object for each risk factor
        # One object for term structure type risk factors (One object for all terms)
        # i.e market_data_object.TermStructure
        # For other types
        # market_data_object.Point

        # The final df looks like

        # ===================================================================================
        # start_date    |   start_value |   end_date    |   end_value   |   *** shock_type
        # ===================================================================================
        # 05/01/2019        Point()         06/01/2019      Point()     ****    ADDITION
        # 05/01/2019        TermSt()         06/01/2019      TermSt()    ****    ADDITION
        # ===================================================================================

        print('creating market data objects')
        data_processed = self.create_market_data_objects(data_processed)
        return data_processed


if __name__ == '__main__':
    conn = pyodbc.connect(database_connect.get_string('INFOP'))
    eod = date_helper.yesterday_as_date()
    sc_type = ObservationPeriod.VAR
    sc_days = mars_helper.get_mars_sc_start_end_days(sc_type,eod, conn)
    source = MarketDataSourceType.MARS
    enricher = DataEnricher(source, conn)
    rf_list =  RiskFactorCollection().rfr_load_from_md_map_context('master_mars').risk_factor_list
    data = enricher.get_market_data(rf_list, sc_days, eliminate_threshold=0.1 )
    a = 5