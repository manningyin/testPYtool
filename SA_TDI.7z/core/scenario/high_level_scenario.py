import json
import os
import uuid
import quantum as qt
from scenario_definer.models import historical_scenario, time_series_config, relative_interval, fixed_interval
from core.utils import version_independent
from core.connection import api
from core.types import _scenarios
from core.utils import date_helper
from core.system import ext_envir
from scenario_definer.rest import  ApiException


_FIRST_RUN_ORCA = dict(define=True, generate=True, prepare=True)


def _is_first_run(name):
    # Global variable function to ensure swagger addresses are only printed once when calling functions in a script
    global _FIRST_RUN_ORCA
    if _FIRST_RUN_ORCA[name]:
        _FIRST_RUN_ORCA[name] = False
        return True
    return False


class DefineScenario:
    """
    Class used for defining a high_level_scenario that holds risk factors, mapping, scenario_dates, shock horizon and
    everything else that is required for generating scenarios.

    Args:
        rf_context_id                     (str): Context id for risk factors
        rf_mapping_id                     (str): Corresponding market data mapping for risk factors
        md_context_ids     (str or list of str): Context id for pricing factors (used for forward rate scenarios)
        md_mapping_ids     (str or list of str): Corresponding market data mapping for pricing factors
        name                              (str): High level scenario name
        observation period               (enum): Which observation period to use (eg. VaR / RTPL / Stressed). Must be
                                                 given using the core.types.scenario_types.ObservationPeriod enum
        owner                             (str): Owner of the high level scenario
        calendar_type                     (str): Which calendar type to use. Can be 'MARKET_RISK' (MARS) or 'EURO'

    Notes:
        Author: g48606
    """
    def __init__(self,
                 rf_context_id,
                 rf_mapping_id,
                 md_context_ids,
                 md_mapping_ids,
                 proxy_definition_name,
                 name=str(uuid.uuid4()),
                 observation_period=_scenarios.ObservationPeriod.VAR,
                 owner=os.getenv('username'),
                 calendar_type='MARKET_RISK'  # Can be 'EURO' and 'MARKET_RISK'
                 ):
        # Input arguments which should be a list are converted to list if they are string types
        self.rf_context_id = rf_context_id
        self.rf_mapping_id = rf_mapping_id
        self.md_context_ids = [md_context_ids] if isinstance(md_context_ids, version_independent.string_types) else md_context_ids
        self.md_mapping_ids = [md_mapping_ids] if isinstance(md_mapping_ids, version_independent.string_types) else md_mapping_ids

        self.proxy_definition_name = proxy_definition_name
        self.name = name
        self.owner = owner
        self.observation_period = observation_period
        self.calendar_type = calendar_type

    def ts_config(self):
        if self.observation_period == _scenarios.ObservationPeriod.STRESSED:
            stress_period = self.observation_period.stressed_period()
            fixed_config = fixed_interval.FixedInterval(calendar_type=self.calendar_type,
                                                        start_date=stress_period['start_date'],
                                                        end_date=stress_period['end_date'])
            ts_config = time_series_config.TimeSeriesConfig(fixed_interval=fixed_config)
        else:
            rel_int_config = relative_interval.RelativeInterval(
                end_date_relative_to_eod_date=self.observation_period.scenario_date_offset(),
                number_of_scenario_days=self.observation_period.scenario_days(),
                calendar_type=self.calendar_type)
            ts_config = time_series_config.TimeSeriesConfig(relative_interval=rel_int_config)
        return ts_config

    def historical_scenario_json(self, version):
        """
        Creates a historical scenario which can be passed to the scenario-definer swagger-ui. While it is an instance
        of the scenario_definer.models.historical_scenario.HistoricalScenario, it essentially works just like a
        dictionary
        """
        hs = historical_scenario.HistoricalScenario(risk_factors_context_id=self.rf_context_id,
                                                    risk_factor_mapping_context_id=self.rf_mapping_id,
                                                    market_data_risk_factors_contexts_ids=self.md_context_ids,
                                                    market_data_md_mapping_contexts_ids=self.md_mapping_ids,
                                                    proxy_definition_id=self.proxy_definition_name,
                                                    horizon_scaling_method=None,
                                                    last_update_by=self.owner,
                                                    name=self.name,
                                                    owner=self.owner,
                                                    time_series_config=self.ts_config(),
                                                    shock_horizon=self.observation_period.shock_horizon(),
                                                    version=version)
        return hs

    def upsert_scenario(self, info=1):
        """
        Takes the created historical and uploads it to the ScenarioEngine MongoDB. The uploaded scenario is then
        returned back, and the ID can be found by getting the 'id' key of the return
        """
        sd_api = api.historical_scenario_definer_api()
        if info > 0:
            if _is_first_run('define'):
                print("Scenario definer: %s/swagger-ui.html" % sd_api.api_client.configuration.host)
        try:
            fetched_scenario = sd_api.get_historical_scenario_by_name(self.name)
        except ApiException as e:
            fetched_scenario = historical_scenario.HistoricalScenario(name=self.name)

        version = fetched_scenario.version
        scenario_id = fetched_scenario.id

        json = self.historical_scenario_json(version=version)

        # Check if the scenario name already exists. If it does, replace it. Else, upload the scenario.
        if scenario_id is not None:
            out = sd_api.update_historical_scenario(id=scenario_id, historical_scenario=json)
            uploaded_version = version + 1
        else:
            out = sd_api.save_historical_scenario(historical_scenario=json)
            uploaded_version = version
        if info > 0:
            print("Version %s of high level scenario with name '%s' has been upserted to ScenarioEngine '%s' "
                  "environment." % (uploaded_version, self.name, ext_envir.ScenarioEngine().envir))
        return out


def generate_scenario(scenario_id, eod_date, info=1):
    """
    Calls scenario-generator to generate simulations and shifts for input high_level_scenario_id and eod_date.

    The function assumes that a high level scenario has already been created (identifier given as function input)

    Args:
        scenario_id     (str):      Scenario Engine id for the high level scenario
        eod_date        (date):     Scenario base date
        info            (int):      Information to be printed

    Returns:
        (unknown):   Meaningful description of data returned by function

    Notes:
        Author: g48606 (Oskar Rosendal)
    """
    iso_date = date_helper.to_datetime(eod_date).date().isoformat()
    sg_api = api.scenario_generator_api().historical_scenario

    if info > 0:
        if _is_first_run('generate'):
            print("Scenario generator: %s/swagger-ui.html" % sg_api.api_client.configuration.host)

    # "generate_scenario_pack_using_get" has a bug with the return, thus we load the last response with json package
    try:
        sg_api.generate_pack1(high_level_scenario_id = scenario_id, eod_date = iso_date)
        sg_spec = json.loads(sg_api.api_client.last_response.data)
    except Exception as e:
        raise Exception("Problem occurred when asking Scenario Generator to create scenario pack. Message: " + str(e))

    return sg_spec


def parse_result_to_dict(full_reval):
    results = full_reval[0].simulation_valuations[0].values
    out = dict()
    for res in results:
        out[res.position_ref.trade_id] = dict(npv=res.npv, zero_sc_npv=res.zero_scenario_npv, rtpl=res.npv-res.zero_scenario_npv)
    return out


def scenario_from_name(name):
    sd_api = api.historical_scenario_definer_api()
    return sd_api.get_historical_scenario_by_name(name=name)


def convert_to_orca_scenarios(scenario_list):
    """
    Translated "prepared" scenarios returned from the Scenario Engine Executor into a format readable by Orca.

    The function can take two kind of inputs:

        - Direct output of from the scenario engine "prepare" service. Function will slice the data, only using a subset
        - Pre-sliced output from the prepare service, or similar output from another service. No slicing is done.

    Args:
        scenario_list     (list of dict):   "Prepared" Scenario Engine scenario, appended in a list.

    Returns:
        (list of dict): Scenarios in a format that can be read by Orca

    Notes:
        Author: Oskar (g48606)
    """
    out = []
    for scenario in scenario_list:
        data = scenario['scenarioData']
        if 'curvePoints' in data.keys() and 'interpolation' in data.keys():
            # ===================================================================================
            # This is a curve (has points and interpolation).
            # We transform this into a "suitable" q-toolkit curve object by:
            # - Splitting curves and data in specific variables.
            # - Finding the proper q-Toolkit object for handling of a curve with this
            #   interpolation definition.
            # - Converting dates to datetime.datetime objects
            # - Creating q-toolkit curve using the converted dates and curve point values.
            # ===================================================================================
            curve_dates, curve_values = zip(*[x.values() for x in data['curvePoints']])
            curve = getattr(qt, 'Curve' + data['interpolation'].title())
            qt_data = curve.make(list(map(date_helper.to_datetime, curve_dates)), curve_values)
        else:
            # ===================================================================================
            # Not much transformation needed.
            # ===================================================================================
            qt_data = data['value']
        out.append(dict(name=scenario['name'], type=scenario['scenarioType'], data=qt_data))
    return out


if __name__ == '__main__':
    #import datetime as dt
    #import pandas as pd
    #date = dt.datetime(2017, 4, 10)

    #high_level_scenario_id = scenario_from_name('RTPL_MDHUB').id
    #print(high_level_scenario_id)

    #result = full_reval_of_scenario(scenario_id=high_level_scenario_id, eod_date=date)
    #parsed_result = parse_result_to_dict(result)

    #df = pd.DataFrame.from_dict(parsed_result).transpose()
    #print(df)
    myScenario = DefineScenario(rf_context_id='lala', rf_mapping_id='lalala',md_context_ids='lalalala',md_mapping_ids='lalalalala')
    print(myScenario.historical_scenario_json(1))

