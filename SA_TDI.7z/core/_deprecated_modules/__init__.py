import warnings

warnings.warn(
    'You are importing a deprecated module from the "_deprecated_modules" package. '
    + 'Please find the alternative "up-to-date" module and use that instead.')
