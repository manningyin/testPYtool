"""
Module for inserting and updating risk factors in Risk Factor Repository

Unlike the risk factor factory the curator matches the strategic flow, where risk factors are created
based on pricing factors.

Notes:
    Author: JBrandt (g50444)

"""
import core.risk_factor.factory.credit.factory
from core._deprecated_modules import factory_controller
from core.position import position_service
from core.risk_factor import risk_factor_utils
from core.risk_factor.collection import RiskFactorCollection
from core.utils import list_helper


def current_coverage_risk_factors(md_mapping_hierarchy, as_of_date):
    """
    Creates all risk factors in "current scope" as defined in the code-lib

    The function creates:
        - interest rate and fx risk factors using the risk factor "factory"
        - credit risk factors using the "curator" prototype

    The scope (and output of this function) can/should be changed using these approaches:
        - Credit risk factors - increase scope in core.position.position_service.PI_coverage_positions()
        - FX/interest rates - increase scope in the individual risk factor classes e.g.
          core.risk_factor.factory.rates.domain.RfInterestRate()

    Args:
        md_mapping_hierarchy    (list): Market data sources (as objects from core.system.ext_envir) in prioritized order
        as_of_date              (date): End of date snap for position coverage and system date for Orca

    Returns:
        (dict):
            - key: 'risk_factors', value: list of all risk factors
            - key: 'pricing_factors', value: list of all zero coupon "pricing factor" used for Orca ir conversion

    Example:
        The module is called (from python) like this::

            import datetime as dt
            from core.system import ext_envir
            from core.risk_factor import curator

            md_mapping_hierarchy = [
                                ext_envir.MDHub.int,
                                ext_envir.DAMD.DAMDS,
                                ]

            as_of_date = dt.date(2018, 5, 18)
            all_rf = curator.current_coverage_risk_factors(
                                                        md_mapping_hierarchy = md_mapping_hierarchy,
                                                        as_of_date = as_of_date,
                                                        )

    Notes:
        Author: JBrandt (g50444)
    """

    # ===================================================================================
    # Creating credit risk factors based on current position coverage
    # ===================================================================================

    if False:
        # TODO: This section should be first used (other section removed) - then function should be deleted.

        risk_factors = (
            RiskFactorCollection(as_of_date = as_of_date)
                .default_PI_risk_factors()
                .md_mapping_update(md_mapping_hierarchy)
        )
        pricing_factors = (
            RiskFactorCollection(as_of_date = as_of_date)
                .default_PI_pricing_factors()
                .md_mapping_update(md_mapping_hierarchy)
        )

        out = dict(risk_factors = risk_factors,
                   pricing_factors = pricing_factors,
                   )
    else:
        # TODO: This section should be removed - but is kept so it can be used in regression test!

        # Getting all positions in current PI coverage
        positions_as_dict = position_service.PI_coverage_positions(as_of_date)
        positions = [pos for pos in positions_as_dict]

        curator_risk_factors = core.risk_factor.factory.credit.factory.from_positions(positions = positions,
                                                                                      info = 1,
                                                                                      )
        # ===================================================================================
        # Creating FX and Interest RAte risk factors using the "factory"
        # (disregarding current chosen portfolio)
        # ===================================================================================

        covered_factories = [
                            'RfCcyPairFactory',
                            'RfInterestRateFactory',
                            ]

        and_label_criteria = [risk_factor_utils.Label(name    ='create_in_factory',
                                                      value   = True,
                                                      group   = 'master',
                                                      )]
        factory_risk_factors = factory_controller.generate_risk_factors(specific_factory = covered_factories,
                                                                        md_mapping_hierarchy = md_mapping_hierarchy,
                                                                        label_criteria_and = and_label_criteria,
                                                                        label_criteria_or = None,
                                                                        )


        # ===================================================================================
        # Combining risk factors created using the two approaches, making sure there are
        # no duplicates.
        # ===================================================================================
        all_risk_factors = list_helper.distinct(curator_risk_factors + factory_risk_factors)

        risk_factors = []
        pricing_factors = []
        for risk_factor in all_risk_factors:
            if risk_factor.has_label(name = 'risk_factor', value = True, group = 'master'):
                risk_factors.append(risk_factor)
            if risk_factor.has_label(name = 'zero_coupon', value = True, group = 'master'):
                pricing_factors.append(risk_factor)

        out = dict(risk_factors = risk_factors,
                   pricing_factors = pricing_factors,
                   )

    return out



