import unittest
import datetime as dt
import pandas as pd
import sys
from core.time_series.hs_market_data_factory import MarketDataFactory
from core.time_series.hs_market_data_factory import BondSwapBasisFactory, CDSHazardRateFactory,ZSpreadFactory
from core.utils import timeout


# ============================================================================================== #
# Below is a test factory that is used to test the functionality built in hs_market_data_factory.
# ============================================================================================== #
@unittest.skip
class TestMarketDataFactory(MarketDataFactory):
    def __init__(self, start_date, end_date):
        MarketDataFactory.__init__(self, start_date, end_date)

    @property
    def table_name(self):
        return 'FRTB_HS_CREDIT_CDS'

    @property
    def table_structural(self):
        return {}

    def calculate_raw_timeseries(self):
        final_df = pd.DataFrame()
        df = pd.DataFrame()
        # complete time series
        df['eod_date'] = [d for d in pd.bdate_range(self.start_date, self.end_date)]
        df['market_data_id'] = 'full'
        df['ccy'] = 'EUR'
        df['VALUE'] = 0.01
        final_df = final_df.append(df)

        df2 = pd.DataFrame()
        df2['eod_date'] = [self.start_date,self.end_date]
        df2['market_data_id'] = 'test1'
        df2['ccy'] = 'EUR'
        df2['VALUE'] = 0.021
        final_df = final_df.append(df2)

        return final_df


class TestCompleteSeries(unittest.TestCase):
    @timeout.timeout(50)
    def test_complete_series(self):
        ts = TestMarketDataFactory(dt.date(2017, 4, 1), dt.date(2017, 4, 20))
        ts.normalized_ts()
        self.assertGreater(len(ts.normalized_time_series),len(ts.raw_time_series))


class TestBondSwapBasisFactory(unittest.TestCase):
    @timeout.timeout(30)
    def test_bond_swap_basis_factory(self):
        ts = BondSwapBasisFactory(dt.date(2017, 4, 1), dt.date(2017, 4, 5))
        ts.raw_ts()
        self.assertGreater(len(ts.raw_time_series),0)


class TestCDSHazardRateFactory(unittest.TestCase):
    @timeout.timeout(20)
    def test_cds_hazard_rate(self):
        ts = CDSHazardRateFactory(dt.date(2017, 4, 1), dt.date(2017, 4, 5))
        ts.raw_ts()
        self.assertGreater(len(ts.raw_time_series), 0)


class TestBondZspreadFactory(unittest.TestCase):
    @timeout.timeout(300)
    def test_bond_zspread(self):
        ts = ZSpreadFactory(dt.date(2018, 5, 1), dt.date(2018, 5, 5))
        ts.raw_ts()
        print(ts.raw_time_series)
        self.assertGreater(len(ts.raw_time_series), 0)


if __name__ == '__main__':
    unittest.main()