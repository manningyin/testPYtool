import datetime
import unittest

from core.market_data import market_data_loader
from core.utils.timeout import timeout


class TestDamdsTimeSeriesLoader(unittest.TestCase):
    @timeout(50)
    def test_time_series_fx(self):
        d3 = market_data_loader.DamdsLoader(market_data_ids="CAD.EUR", startd=datetime.datetime(2017, 3, 2),
                                            endd=datetime.datetime(2017, 9, 30))

        self.assertGreater(d3.data.count,0)

    @timeout(50)
    def test_time_series_cr(self):
        d3 = market_data_loader.DamdsLoader(market_data_ids="RATE.ZSPREAD.DK.CURVE_BASIS_50Y", startd=datetime.datetime(2017, 3, 2),
                                            endd=datetime.datetime(2017, 9, 30))

        self.assertGreater(d3.data.count,0)

    @timeout(50)
    def test_time_series_ir(self):
        d3 = market_data_loader.DamdsLoader(market_data_ids="CHF.RATE.FWD.3M.19Y", startd=datetime.datetime(2017, 3, 2),
                                            endd=datetime.datetime(2017, 9, 30))

        self.assertGreater(d3.data.count,0)