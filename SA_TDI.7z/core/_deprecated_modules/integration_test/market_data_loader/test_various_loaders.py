import sys
import unittest
import datetime as dt
from core.utils.timeout import timeout


@unittest.skipIf(sys.version_info.major > 2, "ORCA do not support python 3.x")
class TestVariousLoader(unittest.TestCase):
    def setUp(self):
        from core.utils.version_independent import return_main_qt_version
        self.main_qt_version = return_main_qt_version()
        if self.main_qt_version < 11:
            self.skipTest(reason = "qtookit version is not high enough, at least 11")

    @timeout(10)
    def test_bond_curve_loader(self):

        from core.market_data.market_data_loader import BondCurveLoader
        obj2 = BondCurveLoader(name='DKKMTGNYKSOFTBLT',
                               source='DAMDS',
                               startd=dt.datetime(2016, 6, 3),
                               endd=dt.datetime(2016, 6, 6))

    # below does not work right now
    @timeout(10)
    def test_cds_curve_loader(self):
        pass

        #obj = CDSSpreadLoader(name='INDUST_N. America_B',
        #                      source='proxy_service_fast',
         #                     startd=datetime.datetime(2016, 3, 17),
         #                     endd=datetime.datetime(2016, 3, 20))



    @timeout(10)
    def test_bond_price_loader(self):
        from core.market_data.market_data_loader import BondPriceLoader
        priceseries=BondPriceLoader(name='NO0010664428',
               source='MDS',
               startd=dt.datetime(2016,12,3),
               endd=dt.datetime(2016,12,5))

    @timeout(10)
    def test_cash_flow_loader(self):
        from core.market_data.market_data_loader import CashFlowLoader
        cashflowdynamic = CashFlowLoader(name='NO0010673726', source='orca', startd=dt.datetime(2017, 2, 1),
                                         endd=dt.datetime(2017, 2, 6))

    @timeout(10)
    def test_fx_rate_loader(self):
        import core.market_data.market_data_loader as market_data_loader
        my_fx_data = market_data_loader.FxSpotLoader(name=['DKK', 'SEK'],
                                                     source='INFOP',
                                                     startd=dt.datetime(2009, 1, 12),
                                                     endd=dt.datetime(2009, 1, 15),
                                                     ).data

    @timeout(10)
    def test_bond_cash_flow_loader(self):
        import core.market_data.market_data_loader as market_data_loader
        isins = ['XS1368469570', 'DK0008919913']
        cfs = market_data_loader.ORCABondCashFlowLoader(names=isins,
                                                        startd=dt.datetime(2017, 12, 27),
                                                        endd=dt.datetime(2017, 12, 27)).data
        self.assertEqual(len(cfs),2)

    @timeout(10)
    def test_bond_price_loader_m(self):
        import core.market_data.market_data_loader as market_data_loader
        isins = ['XS1368469570', 'DK0008919913']
        ps = market_data_loader.BondPriceMatrixLoader(names=isins, startd=dt.datetime(2017, 12, 27),
                                                      endd=dt.datetime(2017, 12, 27)).data
        self.assertEqual(len(ps),2)