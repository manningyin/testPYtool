# -*- coding: utf-8 -*-

"""
Get access to databases both using common and personal database / sign-on credentials

Actual credentials are stored in the credentials module.

Notes:
    Author: g50444 and g48606

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       21sep2016   g50444      Initial creation
    2       22nov2016   g48454      Add support to private login (only ask user input in)
    3       05dec2016   g50091      Add the possibility of having a config file on C drive:'c:/temp/qToolkit_Config/DB.txt'
                                    with username and password. Mainly done with DAMDP
    4       02jan2017   g50444      Restructure to match new development standards
                                    Re-thinking personal credentials setup. Moving functionality to separate "credentials"
                                    module.
    5       05jan2018   g48606      Re-design of the "get_string" function to generalize such that it works for a broader
                                    set of database types (Oracle, SQL server, etc.)
    ======= =========   =========   ========================================================================================

"""
import os
import sqlalchemy as alc
import pyodbc
from core.connection import credentials
from core.utils import version_independent
from core.utils import encryption
from core.caching.cache_driver import memory_cache


def get_string(database_alias, test_connection=True, manual_input=False, info=0):
    """
    This function returns the connection string for a specified database_alias (e.g. INFOP).

    This connection string can then be used through core.database_extract or pyodbc.connection to open a connection
    to the database.

    Args:
        database_alias      (str):      Name/abbreviation for the database_alias that calling module which to connect to.
        test_connection     (bool):     Should the connection string be tested - through signon to database? (True/False)
        manual_input        (bool):     If True, user will always be prompted for credentials manually.
                                        If False (default), function will attempt to collect previously stored credentials
        info                (int):      Level of information printed. The higher, the more information is printed

    Returns:
        str:     String that can be used for connecting to the external database_alias

    Example:
        The module is called (from python) like this::

            from core.connection import database_connect
            connection_string = database_connect.get_string(database_alias = 'INFOP')

    Notes:
        Author: g48606 (Oskar Rosendal)
    """

    database_alias = database_alias.upper()
    connection_info = credentials.get_connection_info(connection_alias=database_alias, info=info)
    stored_in_personal_folder = True if connection_info.get('PASSWORD') == 'STORED_IN_PERSONAL_FOLDER' else False
    call_horn_of_winter = True if connection_info.get('PASSWORD') == 'STORED_IN_HORN_OF_WINTER' else False

    # =========================================================================================== #
    # As user is allowed to re-type password if credentials are invalid, this part of the code can
    # re-run. While loop is broken by either function return or raising of an error
    #
    # 1) Fetching username and password:
    #     - If user chose manual input, core.connection.credentials.user_input_credentials will be called
    #     - If password in connection info is set to 'STORED_IN_PERSONAL_FOLDER',
    #       core.connection.credentials.get_personal_credentials will be called
    #     - If manual input is not selected, and temp_pwd is not 'STORED_IN_PERSONAL_FOLDER', we
    #       use the password found in connection info
    # 2) 'construct_signon_string' is called, using the following inputs:
    #     - database_alias to determine if database is in the system DSN
    #     - database_type to determine the proper odbc driver
    #     - connection info used for generating the string (e.g. server, username, password, etc.)
    # 3) if user chose to test connection, we get connection status from 'database_connection_test,
    #    if not, break while loop and return the signon string
    #     - Go through logic to for various connection errors, including allowing user to manually
    #       re-type their password

    #  4) Horn of Winter System:
    #       Horn of winter system is way to distribute your personal password to other users without show the password to them.
    #       In <A Song of Ice and Fire>, horn of winter is used by hopeless free folk to break the great wall..
    #       I really hope no one will use it ---
    #       This is not optimal but sometime useful and efficient.
    #       The way it works is to distribute the pyc file (compiled python) but without the original py file,
    #       once you would like to release personal password, do the following:
    #       - compile a horn_of_winter.pyc locally (see an example of horn_of_winter in below
    #       - copy horn_of_winter.pyc file to the core.connection on either test/prod env or target user's local computer
    #       - configure a special database link in core.credentials with password type 'STORED_IN_HORN_OF_WINTER'
    #       - remember change the password from time to time :)

    # Example of horn_of_winter.py
    #   def return_credential(database_alias):
    #        _password = {"DAMDS_WH": ("g-logon","password")}
    #        return _password[database_alias]

    # =========================================================================================== #
    while True:
        if manual_input:
            db_credentials = credentials.user_input_credentials(connection_alias=database_alias, info=info)
            connection_info['USER'] = db_credentials['USER']
            connection_info['PASSWORD'] = db_credentials['PASSWORD']
            connection_info['ENCRYPTION_TYPE'] = db_credentials['ENCRYPTION_TYPE']
        elif stored_in_personal_folder:
            db_credentials = credentials.get_personal_credentials(connection_alias=database_alias, info=info)
            connection_info['USER'] = db_credentials['USER']
            connection_info['PASSWORD'] = db_credentials['PASSWORD']
            connection_info['ENCRYPTION_TYPE'] = db_credentials['ENCRYPTION_TYPE']
        elif call_horn_of_winter:
            import horn_of_winter
            connection_info['USER'],connection_info['PASSWORD'] = horn_of_winter.return_credential(database_alias)
            print("-------------------------------")
            print("-- you are using horn of winter system now---")
            print("-------------------------------")

        database_type = connection_info.pop('DB_TYPE', 'ORACLE')  # Use oracle as default db_type if none is specified
        connection_string = construct_signon_string(database_alias=database_alias, database_type=database_type,
                                                    info=info, **connection_info)

        if not test_connection:
            break
        else:
            connection_status = database_connection_test(connection_string=connection_string, info=info)
            if connection_status == 'OK':
                break

            # =========================================================================================== #
            # If the connection fails and the issue is password related, the user is asked whether to
            # manually input a new combination of user and password. If 'Y' is chosen, the while loop
            # re-initiates and tries connection with new credentials. If 'N' is chosen, an error is raised
            # =========================================================================================== #
            elif connection_status == 'PASSWORD_ISSUE':
                if manual_input or stored_in_personal_folder:
                    update_pw = version_independent.get_input(
                        input_box_border() + "\n The credentials for '%s' did not provide access.\n The issue seems to "
                        "be password related.\n\n Would you like to input your credentials manually and try again? "
                        "(Y/N): " % database_alias).upper()
                    if update_pw == 'Y':
                        # =========================================================================================== #
                        # If user chooses to input new user and password, and the password was fetched from personal
                        # folder, the previously stored credentials are deleted first
                        # =========================================================================================== #
                        if not manual_input:
                            credentials.delete_personal_credentials(connection_alias=database_alias, info=info)
                    else:
                        raise UserWarning("Not able to connect to '%s' due to what seems to be a password issue"
                                          % database_alias)
                else:
                    # =========================================================================================== #
                    # In case the password was fetched directly from the core.connection.credentials module, and not
                    # input manually or found in personal folder, the user is NOT asked to input new credentials,
                    # and instead a warning is immediately raised and the code terminates
                    # =========================================================================================== #
                    raise UserWarning("Not able to connect to '%s' using password from CREDENTIALS module, due to what "
                                      "seems to be a password issue" % database_alias)

            else:
                # =========================================================================================== #
                # If the connection fails and the issue is NOT password related, an error is raised printing the
                # experienced connection issue, and the code terminates
                # =========================================================================================== #
                raise Exception('Not able to connect to %(database_alias)s with connection_status: '
                                '%(connection_status)s' % locals())
    return connection_string


def input_box_border():
    return '\n' + '='*60


def database_connection_test(connection_string, info=0):
    """
    Testing if connection string provides access to a database

    Args:
        connection_string       (str):      String that can be used by pyodbc module to connect to a database
        info                    (int):      Level of information printed.
                                            The higher, the more information is printed

    Returns:
        (str):   Connection status: "OK", "PASSWORD_ISSUE" or "UNIDENTIFIED_ISSUE"

    Example:
        The module is called (from python) like this::
            conn_string = 'Driver={Oracle in OraHome11gR2_64Bit_1}; Dbq=INFO3D; Uid=MARS_TEST; Pwd=secret_password;'
            connection_status = test_database_connection(connection_string=conn_string, info=0)

    Notes:
        Author: g50444
    """
    try:
        connection  = pyodbc.connect(connection_string)
        cursor      = connection.cursor()

        # If no issues have occurred at this point, the connection string is ok...
        test_result = 'OK'

        # Closing down connection
        cursor.close()
        connection.close()
    except Exception as e:
        # ==============================================================================================
        # Some problem occurred while testing connection string
        # We are interested in getting some information about what went wrong
        #
        # The Exception raised by pyodbc has no information about the real problem ...
        # ... so we need to examine the exception text string to translate the database error message
        # into something meaningful...
        # ==============================================================================================
        exception_text = str(e)
        if info > 0:
            print('Exception Text:',exception_text)
        if exception_text.find('ORA-01017') >= 0:
            # It seems that password or user-name is wrong...
            test_result = 'PASSWORD_ISSUE'
        elif exception_text.find('ORA-1217') >= 0:
            test_result = 'TIMEOUT'
        elif exception_text.find('ORA-28000') >= 0:
            test_result = 'LOCKED_ACCOUNT'
        elif exception_text.find('ORA-28001') >= 0:
            test_result = 'EXPIRED_PASSWORD'
        else:
            test_result = 'UNIDENTIFIED_ISSUE: ' + exception_text
    return test_result


@memory_cache
def return_trmp_string():
    """
    Seems some one in nordea is using trusted connection but other has personal credential
    This function firstly try the trusted connection, if not work will read the personal credentia;
    Notes:
        Author: g48454
    """
    try:
        string = get_string('TRMP_TRUST',test_connection=True)
    except:
        string = get_string('TRMP',test_connection=True)
    return string


def get_odbc_driver(database_type='Oracle', info=0):
    """
    Get the name of an ODBC driver for a specific source (database or similar)

    There are different ways of determining a locally (on "this pc") working database driver.
    This module first attempts to find it the "simplest" way (looking into a specific file on c:\)
    If that does not work, it tries a more complex method (looking into the windows registry)

    Args:
        database_type   (str):      The type of the sql database (e.g. ORACLE, SQL Server, etc.)
        info            (int):      Level of information printed. The higher, the more information is printed

    Returns:
        (str):  Name of ODBC driver for the given source

    Example:
        The module is called (from python) like this::
            my_driver = get_odbc_driver(source_name = 'infop')

    Notes:
        Author: g50444
    """

    driver_name = None
    if database_type.upper() == 'ORACLE':
        # ===================================================================================
        # First trying to find ODBC drivers known by windows registry
        # ===================================================================================
        try:
            ora_drivers = []
            for driver in pyodbc.drivers():
                if 'ORACLE IN' in driver.upper() and 'TERADATA' not in driver.upper():
                    ora_drivers.append(driver)
            if len(ora_drivers) > 1:
                driver_name = max(ora_drivers, key=lambda x: int(x[x.find('OraClient')+9:x.find('Home')]))
            elif len(ora_drivers) == 1:
                driver_name = ora_drivers[0]

        except:
            driver_name = None

        if driver_name in (None,'',[]):
            # ===================================================================================
            # Second attempt - looking up specific driver for 'infop'
            # ===================================================================================
            try:
                driver_name = pyodbc.dataSources()['infop']

                if info > 0:
                    print('Driver found by looking up driver used for infop')
            except:
                driver_name = None
    elif database_type.upper() == 'SQL_SERVER':
        try:
            driver_name = next(x for x in pyodbc.drivers() if not x.find('ODBC') and x.find('SQL Server'))
            if info > 0:
                print('Driver found when looking for ODBC SQL Server driver')
        except:
            driver_name = None
    elif database_type.upper() == 'TERADATA':
        if 'Teradata' in pyodbc.drivers():
            driver_name = 'Teradata'
            if info > 0:
                print('Driver found when looking for Teradata driver')
        else:
            driver_name = None
    else:
        raise NotImplemented('Currently only supporting finding drivers for Oracle, SQL Server and Teradata')

    if driver_name in (None, '', []):
        err_msg = 'Not able to find ' + database_type + ' database driver. Please contact code development team.'
        raise KeyError(err_msg)

    if info > 0:
        print('driver_name:',driver_name)
    return driver_name


def known_odbc_source(db_name):
    """
    Checks if a database is known by ODBC (DNS) or not.

    Args:
        db_name             (str):      Name of the database

    Returns:
        (bool):   True if database is known by DNS / ODBC - False if not

    Example:
        The module is called (from python) like this::

            from core.connection import database_connect
            db = 'info3d'
            if database_connect.known_odbc_source(db) == False:
                raise Exception('The database "' + db + '" is not set up as ODBC data source')

    Notes:
        Author: g50444
    """

    try:
        # ===================================================================================
        # pyodbc.dataSources() returns a dictionary of all known ODBC source.
        # The key (Data Source Names) are made case-insensitive, and we look up the chosen
        # database.
        # If the database is not set up as source, the lookup will return a KeyError
        # ===================================================================================

        x = {k.upper(): v for k, v in pyodbc.dataSources().items()}[db_name.upper()]
        return True
    except KeyError:
        return False


def construct_signon_string(database_alias, database_type, info=0, **kwargs):
    """
    Combines the sign-on information into an actual connection string

    Args:
        database_alias          (str):      Alias for the database
        database_type           (str):      The database type (e.g. 'ORACLE', 'SQL_SERVER')
        info                    (int):      Level of information
        kwargs                 (dict):      Keyword arguments to be included in the connection string
                                            TODO: Consider adding the required kwargs here (i.e. USER, PASSWORD etc.)

    Returns:
        (str):     The sign-on string used for the given database

    Notes:
        Author: g48606 (Oskar Rosendal)
    """

    # =========================================================================================== #
    # If user and password exists in kwargs, rename to UID and PWD as this is correct key name in
    # the connection string
    # =========================================================================================== #
    encryption_type = kwargs.pop('ENCRYPTION_TYPE', None)
    if 'USER' in kwargs:
        kwargs['UID'] = kwargs.pop('USER')
    if 'PASSWORD' in kwargs:
        encrypted_pwd = kwargs.pop('PASSWORD')
        kwargs['PWD'] = encryption.decrypt(encrypted_pwd, encryption_type)

    # =========================================================================================== #
    # If the database alias is in the system DSN, a special sign-on string is generated as
    # driver and extra keywords are unnecessary in this case. This can be disabled by adding the
    # "FORCE_NO_DSN == True" keyword argument to the signon info.
    #
    # Else, the driver is fetched for the given database_type, and the signon_string is
    # generated from driver and keywords.
    # =========================================================================================== #
    if known_odbc_source(kwargs['DBQ']) and kwargs.get('FORCE_NO_DSN',False) == False:
        signon_string = 'DSN=%s; ' % kwargs['DBQ']
        try:
            signon_string += '%s=%s; ' % ('UID', kwargs['UID'])
            signon_string += '%s=%s; ' % ('PWD', kwargs['PWD'])
        except:
            # Accepting that no user or password has been inserted (which is the case for OS authentication)
            pass

    else:
        if 'FORCE_NO_DSN' in kwargs:
            # This keyword is not required in the sign-on string. We remove it to make the final string more clean.
            kwargs.pop('FORCE_NO_DSN')
        driver = get_odbc_driver(database_type=database_type, info=info)
        signon_string = 'Driver={' + driver + '}; '
        for key in sorted(kwargs.keys()):
            signon_string += '%s=%s; ' % (key, kwargs[key])

    return signon_string


def credential_test(database_alias):
    """
    Availability test for credential

    Args:
        connection_alias        (str):              Name/alias for the connection that you want credentials for.

    Returns:
        test_result:   (boolean)  True or False

    Example:
        The module is called (from python) like this::
            result = test_credential(database_alias = "TWP")

    Notes:
        Author: g48454
    """
    connection_string = get_string(database_alias=database_alias, test_connection= False)
    test_result = database_connection_test(connection_string=connection_string)
    if test_result == "OK":
        return True
    else:
        return False


def return_sql_engine(connection_alias='INFOP'):
    # ===================================================================================
    # return the sql credential engine
    # ===================================================================================
    # use the infop password!
    env_user = os.getenv('MARSP_USER')
    env_pass = os.getenv('MARSP_PASS')
    env_conn_string = os.getenv('MARSP_URL')
    conn_string = env_conn_string if env_conn_string is not None else connection_alias
    user = env_user if env_user is not None else credentials.get_personal_credentials(connection_alias)['USER']
    password = env_pass if env_pass is not None else encryption.decrypt(credentials.get_personal_credentials(connection_alias)['PASSWORD'])
    import six
    if six.PY2:
        password = password.encode('utf-8')
    return alc.create_engine('oracle://{}:{}@{}'.format(user, password, conn_string))


def write_df_to_db_fast(df, schema, table_name, source='INFOP', log_email=None, verbose=False, batch_size=400):  # adding optional log_email
    """
    Inserts the input DataFrame to a given database. Insertion batch row by batch, and in case a batch fails (for
    example due to primary key violation), the code will run row by row upload function which deals more carefully.

    Notes:
        Author: g01571
    """
    from core.system import mail
    col_names = [x.upper() for x in df.columns]
    cols_string = "(" + ",".join(col_names) + ")"
    placeholder_list = [':'+ str(i+1) for i in range(len(col_names))]
    placeholder_string = "(" + ",".join(placeholder_list) + ")"
    schema_and_table = schema + '.' + table_name
    connection = pyodbc.connect(get_string(source))

    insert_sql = "INSERT INTO " + schema_and_table + cols_string + " VALUES " + placeholder_string
    failed_rows = 0
    no_rows = 0
    last_print = 0
    for b in range(0,len(df), batch_size):
        df_upload = df.iloc[b:b+batch_size]
        values = df_upload.values.tolist()
        cursor = connection.cursor()
        no_rows += len(df_upload)
        try:
            cursor.executemany(insert_sql, values)
            cursor.close()
        except Exception as e:
            print("Failed batch upload now trying write_df_to_db function")
            failed_rows += write_df_to_db(df_upload, schema, table_name, source, log_email, verbose)
        if last_print * 10000 <= no_rows:
            print("Finished processing %s rows" % no_rows)
            last_print += 1
    connection.commit()
    connection.close()
    ins_rows = no_rows - failed_rows
    output_str = "In total %(ins_rows)s rows have been inserted to source %(source)s and table %(schema_and_table)s" % locals()
    print(output_str)
    print("Number of rows where insertion failed: %s" % failed_rows)
    if log_email is not None:
        mail.mail_simple_msg(log_email, output_str,
                             "Row insertion job to table %(schema_and_table)s on %(source)s" % locals())




def write_df_to_db(df, schema, table_name, source='INFOP', log_email=None, verbose=False):  # adding optional log_email
    """
    Inserts the input DataFrame to a given database. Insertion works row by row, and in case a row fails (for
    example due to primary key violation), the code will simply continue on to the next row. This way it is
    possible to insert values from a DataFrame where some rows overlap with the data already in the database

    The current implementation allows for insertion into INFOP, DAMDS and SQLITE, but is thought of to be expandable in
    a quite simple way.

    Notes:
        Author: g48606
    """
    from core.utils import error_handler
    from core.system import mail
    col_names = [x.upper() for x in df.columns]
    cols_string = "(" + ",".join(col_names) + ")"
    placeholder_list = ["?"] * len(col_names)
    placeholder_string = "(" + ",".join(placeholder_list) + ")"
    schema_and_table = schema + '.' + table_name
    connection = pyodbc.connect(get_string(source))

    insert_sql = "INSERT INTO " + schema_and_table + cols_string + " VALUES " + placeholder_string

    no_rows, failed_rows = 0, 0
    for index, row in df.iterrows():
        extracted_row = list(row)
        cursor = connection.cursor()
        try:
            cursor.execute(insert_sql, extracted_row)
            cursor.close()
        except pyodbc.IntegrityError:
            failed_rows += 1
            cursor.close()
        except Exception as e:
            print("Unexpected error: " + str(e) + str(extracted_row))
            error_handler.track_error(error_message=str(e), identifier=str(extracted_row), comments="Error inserting row")
            failed_rows += 1
            cursor.close()

        no_rows += 1
        if no_rows % 10000 == 0 and verbose:
            print("Finished processing %s rows" % no_rows)
    connection.commit()
    connection.close()
    ins_rows = no_rows - failed_rows
    output_str = "In total %(ins_rows)s rows have been inserted to source %(source)s and table %(schema_and_table)s" % locals()
    print(output_str)
    print("Number of rows where insertion failed: %s" % failed_rows)
    if log_email is not None:
        mail.mail_simple_msg(log_email, output_str, "Row insertion job to table %(schema_and_table)s on %(source)s" % locals())
    return  failed_rows


if __name__ == '__main__':
    # get_odbc_driver('infod', info=1)
    # get_odbc_driver('info3d', info=3)

    # print(return_trmp_string())
    # print(get_odbc_driver(database_type='Oracle', info=0))
    print(get_string(database_alias='INFOP', test_connection=True, manual_input=False, info=0))