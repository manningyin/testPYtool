# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd
import oracledb
from sqlalchemy import create_engine

os.chdir('C:\\Users\\z006554\\OneDrive - Nordea\\pythonProject\\_ValidationCodes\\SA_TDI')

# # USERPROFILE is set by default to 'C:\users\gXXXXX'
wallet_path = os.path.join(os.getenv('USERPROFILE'), 'oracle')
os.environ["TNS_ADMIN"] = wallet_path
# print(os.getenv('TNS_ADMIN'))

# Check that TNS_ADMIN is set and points towards both sqlnet.ora and tnsnames.ora
print(os.getenv('TNS_ADMIN'))

# Initialize oracledb so that your custom files are loaded
oracledb.init_oracle_client()

# Create an infop connection. Note that no credentials are inserted.
infop_connection = oracledb.connect(user='', password='', dsn='infop')
#######################################################################################################################
# GENERIC_QUERY = "SELECT *  FROM MARSP.SA_TDI_CAPITAL WHERE EOD_DATE = '31-MAY-24' AND ISSUE_TYPE = 'GOVM'"
SQL_QUERY_SA_TDI_CAPITAL = "SELECT *  FROM MARSP.SA_TDI_CAPITAL WHERE EOD_DATE = '31-MAY-24'"
SQL_QUERY_POSITION_MV_H = "SELECT *  FROM MARSP.POSITION_MV_H WHERE EOD_DATE = '31-MAY-24'"
SQL_QUERY_RC_RISK_CORR = "SELECT *  FROM MARSP.RC_RISK_CORR WHERE EOD_DATE = '31-MAY-24'"

#######################################################################################################################
connection = create_engine('oracle+oracledb://' + 'infop')

df_SA_TDI_CAPITAL = pd.read_sql(SQL_QUERY_SA_TDI_CAPITAL, connection)
df_SA_TDI_CAPITAL.to_csv('df_SA_TDI_CAPITAL_EOD_MAY31.csv')

df_POS = pd.read_sql(SQL_QUERY_POSITION_MV_H, connection)
df_POS = df_POS.to_csv('df_POS_EOD_MAY31.csv')

df_RC_RISK_CORR = pd.read_sql(SQL_QUERY_RC_RISK_CORR, connection)


df_MARS_raw = pd.read_sql(SQL_QUERY, connection)


dfTmp = pd.read_csv('df_SA_TDI_CAPITAL_EOD_MAY31.csv')


dfTmp.describe()

# print(df)
#######################################################################################################################
SQL_FILE = 'fetchMARSrawData.sql'
a = pd.read_sql(SQL_FILE, connection)

# Open the .sql file
sql_file = open('fetchMARSrawData.sql','r')

# Create an empty command string
sql_command = ''

# Iterate over all lines in the sql file
for line in sql_file:
    # Ignore commented lines
    if not line.startswith('--') and line.strip('\n'):
        # Append line to the command string
        sql_command += line.strip('\n')

        # If the command string ends with ';', it is a full statement
        if sql_command.endswith(';'):
            # Try to execute statement and commit it
            try:
                session.execute(text(sql_command))
                session.commit()

            # Assert in case of error
            except:
                print('Ops')

            # Finally, clear command string
            finally:
                sql_command = ''


sql_command = sql_command.replace("%(date_sql)s", "2024-06-03")


a = pd.read_sql(sql_command, connection)
###########################################################################################

from sqlalchemy import text
def parse_sql(txt: str,**kwargs):
    sql_raw = ''
    if txt.__contains__('.sql'):
        with open(txt, 'r') as con:
            sql_raw = con.read()
    else:
        sql_raw = txt
    for kstr in kwargs.keys():
        sql_raw = sql_raw.replace(kstr, kwargs[kstr])
    return text(sql_raw)


fetchMARSrawData.sql
kwargs = {
    '%(date_sql)s': '2024-06-03'
}
sql_query = parse_sql('fetchMARSrawData.sql',**kwargs)

raw_data_final = pd.read_sql_query(sql_query, connection)




