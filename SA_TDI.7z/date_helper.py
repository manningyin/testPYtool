'''
Various date operation functions



Warning:
    The calendar functions are NOT based on real holiday calendars which is the correct way to do it.
    Not all functions are currently used, and quality could therefore be lower than wanted.
    Please improve quality when using module.

Notes:
    Author: g46987

    ======= =========   =========   ========================================================================================
    Version Date        Developer   Comment
    ======= =========   =========   ========================================================================================
    1       15NOV2016   g46987      Initial creation
    2       21DEC2016   g50444      Renamed sql date function, and changed output to to_date() string
    3       28feb2017   g50444      Changed date_format function into supporting more output formats.
                                    Adding today_as_date() function as alternative to today(), which returns a text-string
    4       23jun2017   g50444      Changing last_business_day() so it takes data as optional input parameter
    ======= =========   =========   ========================================================================================

Review:
    ======= =========   ========    =========   ============================================================================
    Version Date        Reviewer    Outcome     Comment
    ======= =========   ========    =========   ============================================================================
    x       ddmonyyyy   Gxxxxx      OK/Error    (optional comment)
    ======= =========   ========    =========   ============================================================================
'''
import datetime
from core.utils import version_independent
from datetime import date, timedelta
import pandas as pd
import pytz
import logging
import six
TIMEZONE = pytz.timezone("CET")


def date_format(x, format = 'YYYY-MM-DD'):
    """
    Format date as a standardized string. Default is year-month-day format.
    
    The default format, YYYY-MM-DD conforms to ISO 8601 calendar date representation.
    Clear benefit is, that the dates are correctly sortable in its string representation.

    Supported formats are YYYY-MM-DD (default), YYYYMMDD, DD-MM-YYYY and DDMMYYYY.
    Args:
        x : date as a datetime object (could be datetime.date)
    Returns:
        (str): date formatted as a string
    """

    if type(x) == datetime.datetime:
        try:
            x = x.astimezone(TIMEZONE)
        except ValueError:
            x = TIMEZONE.localize(x)

    if format.upper() == 'YYYY-MM-DD':
        strftime_format = "%Y-%m-%d"
        output_on_error = '0000-00-00'
    elif format.upper() == 'YYYYMMDD':
        strftime_format = "%Y%m%d"
        output_on_error = '00000000'
    elif format.upper() == 'YYYYMM':
        strftime_format = "%Y%m"
        output_on_error = '0000-00-00'
    elif format.upper() == 'DD-MM-YYYY':
        strftime_format = "%d-%m-%Y"
        output_on_error = '00-00-0000'
    elif format.upper() == 'DDMMYYYY':
        strftime_format = "%d%m%Y"
        output_on_error = '00000000'
    elif format.upper() == 'DDMONYYYY':
        strftime_format = "%d%b%Y"
        output_on_error = '00000000'
    else:
        raise KeyError("Non-supported output date-format:" + format.upper())

    try:
        date_str = x.strftime(strftime_format)
    except:
        logging.exception("ERROR formatting date "+str(x))
        date_str = output_on_error

    return date_str


def today():
    """
    Return today's date as a string

    Returns:
        str: today's date formatted as a string
    """
    return date_format(to_datetime(date.today()))


def today_as_date():
    """
    Return today's date as a datetime.date

    Returns:
        (datetime.date): today's date
    """
    return to_datetime(date.today())

def yesterday_as_date():
    """
    Return yesterday's date as a datetime.date

    Returns:
        (datetime.date): Yesterdays's date

    Warning:
        This function does not consider holidays.
    """

    today = today_as_date()
    yesterday = today - timedelta(days=1)
    return yesterday

def yesterday_as_bdate():
    from pandas.tseries.offsets import BDay
    today = today_as_date()
    return today - BDay(1)

LAST_BUSINESS_DAY = "LastBD"


def to_datetime(date):
    """
    Convert date to a datetime object.
    
    This attempts to automatically convert input to a datetime object.
    It supports various string representations of a date and as well 

    Args:
        date: date can be a string, datetime.date , datetime.datetime or panda.timestamp
    Returns:
        datetime.datetime: date converted to datetime object
    """
    if isinstance(date, six.string_types):
        if date == LAST_BUSINESS_DAY:
            return to_datetime(last_business_day())
        for f in ["%Y-%m-%d",
                  "%Y-%m-%d %H:%M:%S",
                  "%Y-%m-%d %H:%M:%S,%f",
                  "%y-%m-%d",
                  "%y-%m-%d %H:%M:%S",
                  "%y-%m-%d %H:%M:%S,%f",
                  "%Y%m%d",
                  "%Y/%m/%d",
                  "%d/%m/%Y"
                  ]:
            try:            
                return datetime.datetime.strptime(date,f)
            except ValueError:
                pass
        if "," in date: # Fallback - Oracle is using nanoseconds and time zoned sometimes...
            assert(len(date.split(",")) == 2)
            return to_datetime(date.split(",")[0])
        raise Exception("Date format not supported: %s"%str(date))
    elif type(date) is datetime.datetime:
        return date
    elif type(date) is datetime.date:
        return datetime.datetime(date.year, date.month, date.day)
    elif type(date) is pd.Timestamp:
        return date.to_pydatetime()
    else:
        logging.error("Unsupported date type %s; data: %s" % (type(date), date))
        raise Exception("Unsupported date type: %s"% type(date))


def is_holiday(date):
    """Returns True if date is on holiday.
    
    Currently only weekends are supported.

    Args:
        date: date can be a string, datetime.date or datetime.datetime
    Returns:
        bool: true if date is a holiday
    """
    if to_datetime(date).weekday() in (5, 6): # Saturday, Sunday
        return True
    return False


def subtract_one_business_day(date):
    """
    Return yesterday's date or last Friday if yesterday was a holiday.
    
    Args:
        date: date can be a string, datetime.date or datetime.datetime
    Returns:
        str: date of one business day before date
    """
    d=to_datetime(date) - timedelta(days=1)
    while is_holiday(d):
        d-= timedelta(days=1)
    return date_format(d)


def last_business_day(date=None):
    """
    Finding last business day before "today" - or manually chosen date.

    Args:
        date   (str):    [default: today()] The "basis" date, used when finding last business date (before this date)

    Returns:
        (str):   Date of one business day before "today"

    Raises:

    Example:
        The module is called (from python) like this::

            from core.utils import datetime_helper

            actual_eod_date = datetime_helper.last_business_day()

    Warning:

    Notes:
        Author: g50444
    """

    if date is None:
        d = today()
    else:
        d = date

    return subtract_one_business_day(d)


def oracle_to_date(x):
    """
    Converts datetime to Oracle to_date()-format

    Function takes datetime.datetime format in, but does not need the time-part
    The output string always contain the time-part, which is "zero" (00:00:00) if there is not time-part in the input.
    That works fine for Oracle.

    Args:
        x   (datetime, date or timestamp):    Date that should be transformed

    Returns:
        (str):  Date string in sql "to_date" format

    Example:
        The function is used like this::

            date_in_sql_format = oracle_to_date(dt.datetime(2016,12,1))
            # Output: to_date('2016-12-01 00:00:00','yyyy-mm-dd hh24:mi:ss')

            date_in_sql_format = oracle_to_date(dt.datetime(2016,12,1,12,30,00))
            # to_date('2016-12-01 12:30:00','yyyy-mm-dd hh24:mi:ss')
    Notes:
        Author: g50444
    """

    try:
        date_string = x.strftime("%Y-%m-%d %H:%M:%S")
    except:
        logging.exception("ERROR formatting date " + str(x))
        date_string = '0000-00-00 00:00:00'
    return "to_date('" + date_string + "','yyyy-mm-dd hh24:mi:ss')"


def to_date_str(x):
    """
        Convert date to date str

        Args:
        date: date can be a string, datetime.date or datetime.datetime

        Returns:
            (str):  DateString
    """

    x_datetime=to_datetime(x)
    x_date=x_datetime.date()
    return x_date.strftime('%Y-%m-%d')
    
    
def last_day_of_month(date):
    """
    Return last day of month.
    
    Args:
        date: date can be a string, datetime.date or datetime.datetime
    Returns:
        str: last day of month
    """
    date = to_datetime(date)
    date = datetime.datetime(date.year, date.month, 28)
    day=timedelta(days=1)
    for i in range(32):
        nextday=date + day
        if nextday.month != date.month:
            return date_format(date)
        date=nextday
        

def add_years(date, years):
    """
    Adds an integer of years to a date.

    Created since adding one year to the 29th February on a leap year would cause a
    value error when the 29th doesn't exist in the following year

    Args:
        date         (date):   The input date. Can pass as string, datetime.date or datetime.datetime
        years         (int):   How many years should be added to the date

    Returns:
        (date):   The anniversary date
    Example:
        The function is called (from python) like this::

            from core.utils import datetime_helper
            import datetime

            return1 = datetime_helper.add_year(datetime.date(2017, 2, 28), 1)
            return2 = datetime_helper.add_year(datetime.date(2016, 2, 29), 1)
    Notes:
        Author: g48606
    """
    return_date = to_datetime(date)
    if not isinstance(years, int):
        raise ValueError("Years must be passed as an integer.")
    try:
        return return_date.replace(year=return_date.year + years)
    except ValueError:
        return return_date + (datetime.datetime(return_date.year + years, 1, 1) - datetime.datetime(return_date.year, 1, 2))


def add_tenor(date, tenor):
    """
    Adds a tenor to a date.

    Note, when adding a month to a date, the anniversary date will just have its month shifted. If the shifted date
    doesn't exist in the following month, the function instead selects the last day of the month. Similarly, when
    adding a year to february the 29th, the anniversary date will be february the 28th in the following year. Examples
    of results for different inputs are given below::
    
        date = '2010-1-31', tenor = '1M' --- returns: '2010-2-28'
        date = '2008-2-29', tenor = '1M' --- returns: '2010-3-29'
        date = '2010-3-31', tenor = '1M' --- returns: '2010-4-30'
        date = '2008-2-29', tenor = '1Y' --- returns: '2009-2-28'

    Args:
        date                (date):    The input date. Can pass as string, datetime.date or datetime.datetime
        tenor             (string):    Can be days, weeks, months or years (e.g. 1D, 1W, 1M, 1Y)

    Returns:
        (datetime):   The anniversary date
    Example:
        The function is called (from python) like this::

            from core.utils import datetime_helper
            import datetime

            return = datetime_helper.add_tenor(datetime.date(2010, 1, 31), '1M')
    Notes:
        Author: g48606
    """
    from dateutil.relativedelta import relativedelta
    date = to_datetime(date)
    tenor_type = tenor[-1].upper()
    try:
        tenor_number = int(tenor[:-1])
    except ValueError:
        raise ValueError("Wrong tenor type submitted! Possible choices are an integer followed by 'D', 'W', 'M' or 'Y'")

    if tenor_type == "D":
        ann_date = date + relativedelta(days=tenor_number)
    elif tenor_type == "W":
        ann_date = date + relativedelta(weeks=tenor_number)
    elif tenor_type == "M":
        ann_date = date + relativedelta(months=tenor_number)
    elif tenor_type == "Y":
        ann_date = add_years(date, tenor_number)
    else:
        raise ValueError("Wrong tenor type submitted! Possible choices are an integer followed by 'D', 'W', 'M' or 'Y'")

    return ann_date


def to_business_date(date, day_rule):
    """
    Adjusts a date to the closest weekday according to the day rule.

    If the day_rule is passed as integer, instead of adjusting the date to a weekday, it will just replace the day of
    the date with given integer.

    Args:
        date                (datetime):    The date
        day_rule              (string):    Which day rule that should be used if the anniversary date is not a business
                                           day. The following choices are possible:
                                           Previous (p), following (f), modified following (mf) or an integer. If an
                                           integer is given, replaces the day with given integer.

    Returns:
        (datetime):   The adjusted date
    Example:
        The function is called (from python) like this::

            from core.utils import datetime_helper
            import datetime

            return = datetime_helper.to_business_date(datetime.date(2010, 1, 31), 'mf')
    Notes:
        Author: g48606
    """
    date = to_datetime(date)
    if isinstance(day_rule, int):
        return date.replace(day=day_rule)
    elif day_rule.lower() == "p":
        if date.weekday() < 5:
            day_add = 0
        elif date.weekday() == 5:
            day_add = -1
        else:
            day_add = -2
    elif day_rule.lower() == "f" or day_rule.lower() == "mf":
        if date.weekday() < 5:
            day_add = 0
        elif date.weekday() == 5:
            day_add = 2
        else:
            day_add = 1
    else:
        raise ValueError("Wrong day rule submitted. Valid choices are 'p', 'f', 'mf' or an integer")

    end_date = date + timedelta(days=day_add)

    if end_date.month != date.month and day_rule.lower() == "mf":
        end_date = date + timedelta(days=day_add - 3)

    return end_date


def day_count(start_date, end_date, count_convention):
    """
    Calculates the coverage of a full year between 2 chosen dates.

    By choice of day count convention, function calculates the amount of days that has passed between 2 dates, as a
    fraction of one year.

    Args:
        start_date          (datetime):    The start date
        end_date            (datetime):    The end date
        count_convention      (string):    Which day count convention should be used for calculating the coverage.
                                           Choices: act/360, act/365, act/365.25 and 30/360

    Returns:
        (float):   The coverage
    Example:
        The function is called (from python) like this::

            from core.utils import datetime_helper
            import datetime

            return = datetime_helper.day_count(datetime.date(2010, 1, 31), datetime.date(2010, 4, 15), 'act/360')
    Notes:
        Author: g48606
    """
    start_date = to_datetime(start_date)
    end_date = to_datetime(end_date)
    if start_date > end_date:
        raise ValueError("End_date must be strictly larger than start date")
    if count_convention.lower() == "act/360":
        return (end_date - start_date).days / 360.0
    elif count_convention.lower() == "act/365":
        return (end_date - start_date).days / 365.0
    elif count_convention.lower() == "act/365.25":
        return (end_date - start_date).days / 365.25
    elif count_convention.lower() == "30/360":
        return ((end_date.year - start_date.year) * 360 + (end_date.month - start_date.month) * 30
                + min(30, end_date.day) - min(30, start_date.day)) / 360.0
    else:
        raise ValueError("Wrong day count basis. Valid choices are 'act/360', 'act/365', 'act/365.25' and '30/360'")


class Interpolate(object):
    """
    An interpolation class for datetimes (or floats).

    The class currently only supporting linear interpolation, with extrapolation at the end points.

    The class is initiated with 2 arguments: the known x values (which must be sorted), and the known y values .
    The generated class object can then be called in the point you want to interpolate on.

    Args:
        x_list   (list of floats or datetimes):  sorted list of x values
        y_list   (list of floats):               list of y values

    Returns:
        (object):  Interpolation object that can be called for an x value to get the interpolated y value

    Example:
        The class is called (from python) like this::

            from core.utils import datetime_helper
            import datetime

            x_list = [datetime.date(2017, 1, 1), datetime.date(2017, 1, 5), datetime.date(2017, 2, 1),
                                datetime.date(2017, 2, 12), datetime.date(2017, 3, 6)]
            y_list = [0.2, 0.5, 0.3, 0.1, 0.5]
            intpol = datetime_helper.Interpolate(x_list, y_list)
            interpolated_value_1 = intpol[datetime.datetime(2017,1,15)]
            interpolated_value_2 = intpol[datetime.datetime(2017,1,17)]
            interpolated_value_3 = intpol[datetime.datetime(2017,3,15)]

    Notes:
        Author: g48606
    """
    def __init__(self, x_list, y_list):
        # Accept dates as input when interpolating
        if isinstance(x_list[0], datetime.date):
            x_list = [self.date_to_float(x) for x in x_list]

        if any([y - x <= 0 for x, y in zip(x_list, x_list[1:])]):
            raise ValueError("x_list must be in strictly ascending order!")
        x_list = self.x_list = list(map(float, x_list))
        y_list = self.y_list = list(map(float, y_list))
        intervals = zip(x_list, x_list[1:], y_list, y_list[1:])
        self.slopes = [(y2 - y1)/(x2 - x1) for x1, x2, y1, y2 in intervals]

    def __getitem__(self, x):
        from bisect import bisect_left
        # Accept dates as output
        if isinstance(x, datetime.datetime):
            x = self.date_to_float(x)

        # Allow extrapolation at endpoints
        if x <= self.x_list[0]:
            return self.y_list[0]
        elif x >= self.x_list[-1]:
            return self.y_list[-1]

        # Linearly interpolates, using the bisect_left function natively in Python
        else:
            i = bisect_left(self.x_list, x) - 1
            return self.y_list[i] + self.slopes[i] * (x - self.x_list[i])

    @staticmethod
    def date_to_float(date):
        # Convert datetime to a float
        date = to_datetime(date)
        temp = datetime.datetime(1899, 12, 30)
        delta = date - temp
        return float(delta.days) + (float(delta.seconds) / 86400)


def to_timestamp(d):
    """Convert date/datetime to miliseconds since epoch.

    Args:
        d   (string, date or datetime):  date to convert

    Returns:
        (float):  Milliseconds since epoch
    
    Example:
        Call with a date, datetime or a string::
            
            assert(int(to_timestamp("2017-08-17"))==1502928000000)
    """
    epoch = datetime.datetime.utcfromtimestamp(0)
    dt = to_datetime(d)
    return (dt - epoch).total_seconds() * 1000.0


def ordinalrange(start, end):
    """
    List of ordinal dates (= integers) between "start" and "end", both inclusive, in ascending order.

    If end > start, returns [], i.e. empty list. Does *not* take weekends or holidays into account.
    Args:
        start (valid argument to *datetime_helper.to_datetime()*)  --  start date
        end   (valid argument to *datetime_helper.to_datetime()*)  --  end date
    Returns:
        Generator xrange(start, end+1) as ordinal dates in ascending order.
    """

    try: # Python 2 & 3 compatibility:
        xrange
    except NameError:
        xrange = range

    start_ord = to_datetime(start).date().toordinal()
    end_ord = to_datetime(end).date().toordinal()

    return xrange(start_ord, end_ord+1)


def sort_tenors(tenors):
    """
    Sort a list of tenors provided as strings in ascending order

    Takes a list of tenors on the form 'xy' where x is an integer, and y is a tenor type string (D, B, W, M, Y), eg.
    '1Y' or '2M' or '15W'. The sort is performed by weighting each tenor according to its type (using 1 month as the
    normalized value), and then sorting the weights in ascending order.

    NB: It is assumed that a month has 30 days and 21 business days

    Args:
        tenors  (iterable):  List of unsorted tenors

    Returns:
        (list): List of sorted tenors

    Notes:
        Author: g48606
    """
    # Decodes possible bytes/unicode
    tenors = [t.decode() if not isinstance(t, str) and isinstance(t, version_independent.string_types) else t for t in tenors]

    if not all(isinstance(x, version_independent.string_types) for x in tenors):
        return sorted(tenors)

    # Check if _all_ strings in input list are of _any_ of the below tenor types. If not, just return default sorting
    # of strings.
    tenor_types = ['ON', 'TN', 'SN', 'SW', 'Y', 'M', 'W', 'D', 'B', 'IO']
    if not all(any(tenor.endswith(tenor_type) for tenor_type in tenor_types) for tenor in tenors):
        return sorted(tenors)
    return sorted(tenors, key=tenor_to_float)


def tenor_to_float(tenor):
    """
    Function used to weight each tenor in order to allow sorting by their weight

    Args:
        tenor (string, unicode):  Some tenor as a string

    Returns:
        (float): The weighted tenor, normalized using 1 month as default

    Notes:
        Author: g48606
    """
    assert isinstance(tenor, version_independent.string_types)
    # Hard-coded cases that do not align with the standard tenor format.
    if tenor == 'ON':
        tenor = '1B'
    elif tenor == 'TN':
        tenor = '2B'
    elif tenor == 'SN':
        tenor = '3B'
    elif tenor == 'SW':
        tenor = '1W'
    elif tenor == 'IO':
        tenor = '35Y'

    _value, _type = float(tenor[:-1]), tenor[-1]
    if _type == 'Y':
        _weight = 12
    elif _type == 'M':
        _weight = 1
    elif _type == 'W':
        _weight = 1.0 / 52 * 12
    elif _type == 'D':
        _weight = 1.0 / 30
    elif _type == 'B':
        _weight = 1.0 / 21
    else:
        raise TypeError(f"Tenor type={_type} not recognized. Supported tenors are Y, M, W, D, B.")
    return _value * _weight


def holidays_between(startd, endd, ccy='EUR'):
    from core.utils.shock_days import ORCA_holidays
    import quantum as qt

    startd, endd = to_datetime(startd), to_datetime(endd)
    qt_ccy = getattr(qt.Currency, ccy.upper())
    global_holidays = [to_datetime(x) for x in ORCA_holidays([qt_ccy])[qt_ccy].getDates()]
    return [x for x in global_holidays if startd <= x <= endd]


def business_date_range(start=None, end=None, periods=None, ccy='EUR'):
    pandas_bdates = pd.bdate_range(start=start, end=end, periods=periods)
    holiday_list = holidays_between(startd=pandas_bdates[0], endd=pandas_bdates[-1], ccy=ccy)

    out = [x for x in pandas_bdates if x not in holiday_list]
    return out


def now_as_str():
    """
    Gives you "now" as a string of format: yyyy-mm-dd hh24:mi:ss

    Returns:
        (str): Date and time as string.

    Notes:
        Author: JBrandt (g50444)
    """
    now = datetime.datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")

    return now_str


def numpy_date64_to_datetime(dt64):
    """
    Numpy uses date64 format which is not direct to convert to datetime object This function returns datetime object
    given date64 object

    Args:
        dt64    (type): datetime64

    Returns:
        (type): datetime

    Example:
        The module is called (from python) like this::
        all_scenario_dates = mars_helper.get_mars_sc_start_end_days(scenario_type=observation_period, eod_date=eod_date).values
        all_scenario_dates = [[date_helper.numpy_date64_to_datetime(d) for d in i] for i in all_scenario_dates]
        OR: map(dutils.numpy_date64_to_datetime, calendar.START_DATE.values) # calendar.START_DATE is column of a pd.DataFrame

    Notes:
        Author: g01571 (ABaglan)
    """

    l = pd.DatetimeIndex([dt64])
    year = l.year[0]
    month = l.month[0]
    day = l.day[0]
    out = datetime.datetime(year, month, day)
    return out

def numpy_date64_to_date(dt64):
    return numpy_date64_to_datetime(dt64).date()